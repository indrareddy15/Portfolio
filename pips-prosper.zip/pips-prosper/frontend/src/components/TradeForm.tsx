import { useState, useEffect, useCallback, useMemo } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { CalendarDays, DollarSign, TrendingUp, TrendingDown, Copy, Keyboard, Calculator } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/useAuth";
import { useAccountsRealtime } from "@/hooks/useRealtime";
import { forexEngine } from "@/utils/forexEngine";
import { pnlEngine } from "@/utils/pnlCalculationEngine";
import { InstrumentSelector } from "@/components/InstrumentSelector";
import { useAccountContext } from "@/hooks/useAccountContext";
import { useTradeSharing } from "@/hooks/useTradeSharing";
import { z } from "zod";

// Trade validation schema
const tradeSchema = z.object({
  instrument: z.string().min(1, "Instrument is required"),
  side: z.enum(["long", "short"], { required_error: "Side is required" }),
  entry_price: z.number().positive("Entry price must be positive"),
  exit_price: z.number().positive("Exit price must be positive").optional(),
  size: z.number().positive("Size must be positive"),
  stop_loss: z.number().positive().optional(),
  take_profit: z.number().positive().optional(),
  risk_percent: z.number().min(0).max(100).optional(),
});

interface TradeFormProps {
  onTradeAdded?: () => void;
}

export function TradeForm({ onTradeAdded }: TradeFormProps) {
  const [isLoading, setIsLoading] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [monthlyTradeCount, setMonthlyTradeCount] = useState(0);
  const [validationErrors, setValidationErrors] = useState<Record<string, string>>({});
  const [lastTrade, setLastTrade] = useState<any>(null);
  const [instruments, setInstruments] = useState<any[]>([]);
  const [accounts, setAccounts] = useState<any[]>([]);
  const [strategies, setStrategies] = useState<any[]>([]);
  const [previewData, setPreviewData] = useState<any>(null);
  const [formData, setFormData] = useState<any>({
    trade_type: 'broker'
  });
  const [dataLoaded, setDataLoaded] = useState(false);
  const [propChallenges, setPropChallenges] = useState<any[]>([]);
  const { toast } = useToast();
  const { user, subscriptionData } = useAuth();
  const { selectedAccountId } = useAccountContext();
  const { createTradeShare, generateCertificate } = useTradeSharing();

  // Optimized data loading with caching
  useEffect(() => {
    const loadData = async () => {
      if (!user || dataLoaded) return;
      
      setIsLoading(true);
      try {
        // Parallel loading for better performance
        const [instrumentsResponse, accountsResponse, strategiesResponse, tradesResponse, challengesResponse] = await Promise.all([
          supabase.from('instruments').select('*').eq('is_active', true).order('symbol'),
          supabase.from('accounts').select('*').eq('user_id', user.id).eq('archived', false).order('name'),
          supabase.from('strategies').select('*').eq('user_id', user.id).eq('active', true).order('name'),
          supabase.from('trades').select('id').eq('user_id', user.id).gte('created_at', `${new Date().toISOString().slice(0, 7)}-01`).lt('created_at', `${new Date().toISOString().slice(0, 7)}-32`),
          supabase.from('prop_challenges').select('*').eq('user_id', user.id).eq('status', 'active').order('created_at', { ascending: false })
        ]);
        
        setInstruments(instrumentsResponse.data || []);
        setAccounts(accountsResponse.data || []);
        setStrategies(strategiesResponse.data || []);
        setMonthlyTradeCount(tradesResponse.data?.length || 0);
        setPropChallenges(challengesResponse.data || []);
        setDataLoaded(true);
      } catch (error) {
        console.error('Error loading data:', error);
      } finally {
        setIsLoading(false);
      }
    };
    
    loadData();
  }, [user, dataLoaded]);

  // Keyboard shortcut for new trade (Ctrl/Cmd + N)
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.ctrlKey || e.metaKey) && e.key === 'n') {
        e.preventDefault();
        document.getElementById('instrument-input')?.focus();
      }
    };
    
    document.addEventListener('keydown', handleKeyDown);
    return () => document.removeEventListener('keydown', handleKeyDown);
  }, []);

  // Real-time updates for accounts (for balance updates)
  useAccountsRealtime(
    (payload) => {
      if (payload.new.user_id === user?.id) {
        console.log('Account updated:', payload.new);
        toast({
          title: "Account Updated",
          description: `${payload.new.name} balance updated`,
        });
      }
    },
    (payload) => {
      if (payload.new.user_id === user?.id) {
        console.log('Account balance changed:', payload.new);
      }
    }
  );

  // Real-time updates for strategies
  useEffect(() => {
    if (!user) return;

    const channel = supabase
      .channel('strategies-changes')
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'strategies',
          filter: `user_id=eq.${user.id}`
        },
        (payload) => {
          console.log('Strategy updated:', payload);
          
          if (payload.eventType === 'INSERT') {
            setStrategies(prev => [...prev, payload.new as any].sort((a, b) => a.name.localeCompare(b.name)));
            toast({
              title: "New Strategy Added",
              description: `${payload.new.name} is now available in trade forms`,
            });
          } else if (payload.eventType === 'UPDATE') {
            setStrategies(prev => prev.map(s => s.id === payload.new.id ? payload.new as any : s));
            toast({
              title: "Strategy Updated",
              description: `${payload.new.name} has been updated`,
            });
          } else if (payload.eventType === 'DELETE') {
            setStrategies(prev => prev.filter(s => s.id !== payload.old.id));
            if (formData.strategy_id === payload.old.id) {
              setFormData(prev => ({ ...prev, strategy_id: "" }));
            }
            toast({
              title: "Strategy Removed",
              description: `Strategy has been removed from trade forms`,
            });
          }
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [user]);

  // Debounced preview calculation for better performance
  const calculatePreview = useCallback(
    async (instrument: string, side: string, entryPrice: number, size: number, exitPrice?: number) => {
      if (!instrument || !side || !entryPrice || !size || !exitPrice) {
        setPreviewData(null);
        return;
      }

      try {
        const calculation = await forexEngine.calculateTrade({
          symbol: instrument,
          side: side as 'long' | 'short',
          lots: size,
          entryPrice: entryPrice,
          exitPrice: exitPrice,
          accountCurrency: 'USD'
        });
        
        setPreviewData(calculation);
      } catch (error) {
        console.warn('Preview calculation failed:', error);
        setPreviewData(null);
      }
    }, []
  );

  // Debounced input handler for preview calculations
  const handleInputChange = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
    const form = e.target.form;
    if (!form) return;
    
    const formDataObj = new FormData(form);
    const exitPrice = parseFloat(formDataObj.get("exit_price") as string);
    const instrument = formData.instrument || formDataObj.get("instrument") as string;
    const side = formData.side || formDataObj.get("side") as string;
    const entryPrice = parseFloat(formData.entry_price || formDataObj.get("entry_price") as string);
    const size = parseFloat(formDataObj.get("size") as string);
    
    if (exitPrice && instrument && side && entryPrice && size) {
      // Debounce preview calculation
      setTimeout(() => {
        calculatePreview(instrument, side, entryPrice, size, exitPrice);
      }, 300);
    }
  }, [formData, calculatePreview]);

  const duplicateLastTrade = () => {
    if (!lastTrade) return;
    
    const form = document.querySelector('form') as HTMLFormElement;
    if (!form) return;
    
    // Fill form with last trade data
    (form.instrument as any).value = lastTrade.instrument;
    (form.side as any).value = lastTrade.side;
    (form.entry_price as any).value = lastTrade.entry_price;
    (form.size as any).value = lastTrade.size;
    if (lastTrade.stop_loss) (form.stop_loss as any).value = lastTrade.stop_loss;
    if (lastTrade.take_profit) (form.take_profit as any).value = lastTrade.take_profit;
    
    toast({
      title: "Trade Duplicated",
      description: "Last trade has been copied to the form",
    });
  };

  const handleSubmit = useCallback(async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    if (!user || isSubmitting) return;

    // Check trade limits for free users
    const isFreePlan = !subscriptionData?.subscribed;
    if (isFreePlan && monthlyTradeCount >= 200) {
      toast({
        title: "Monthly Trade Limit Reached",
        description: "Upgrade to Pro to add unlimited trades.",
        variant: "destructive",
      });
      return;
    }

    setIsSubmitting(true);
    setValidationErrors({});
    
    // Show immediate feedback
    toast({
      title: "Adding trade...",
      description: "Your trade is being processed",
    });

    const formDataEvent = new FormData(e.currentTarget);
    
    const rawData = {
      instrument: formData.instrument || formDataEvent.get("instrument") as string,
      side: formData.side || formDataEvent.get("side") as string,
      entry_price: parseFloat(formData.entry_price || formDataEvent.get("entry_price") as string),
      exit_price: formData.exit_price ? parseFloat(formData.exit_price) : formDataEvent.get("exit_price") ? parseFloat(formDataEvent.get("exit_price") as string) : undefined,
      size: parseFloat(formData.size || formDataEvent.get("size") as string),
      stop_loss: formData.stop_loss ? parseFloat(formData.stop_loss) : formDataEvent.get("stop_loss") ? parseFloat(formDataEvent.get("stop_loss") as string) : undefined,
      take_profit: formData.take_profit ? parseFloat(formData.take_profit) : formDataEvent.get("take_profit") ? parseFloat(formDataEvent.get("take_profit") as string) : undefined,
      account_id: formData.account_id || formDataEvent.get("account_id") as string,
    };

    // Quick validation
    try {
      tradeSchema.parse(rawData);
    } catch (error) {
      if (error instanceof z.ZodError) {
        const errors: Record<string, string> = {};
        error.errors.forEach((err) => {
          if (err.path[0]) {
            errors[err.path[0] as string] = err.message;
          }
        });
        setValidationErrors(errors);
        setIsSubmitting(false);
        return;
      }
    }

    const tradeData: any = {
      user_id: user.id,
      instrument: rawData.instrument,
      side: rawData.side,
      entry_price: rawData.entry_price,
      exit_price: rawData.exit_price || null,
      size: rawData.size,
      stop_loss: rawData.stop_loss || null,
      take_profit: rawData.take_profit || null,
      opened_at: formDataEvent.get("opened_at") as string,
      closed_at: formDataEvent.get("closed_at") as string || null,
      notes_pre: formDataEvent.get("notes_pre") as string,
      notes_post: formDataEvent.get("notes_post") as string,
      account_id: rawData.account_id || null,
      strategy_id: formData.strategy_id || null,
      trade_type: formData.trade_type || 'broker',
      prop_challenge_id: formData.trade_type === 'prop_firm' ? formData.prop_challenge_id || null : null,
    };

    try {
      // Optimistic update - reset form immediately
      e.currentTarget.reset();
      setFormData({});
      setMonthlyTradeCount(prev => prev + 1);
      onTradeAdded?.();

      // Background processing
      const promises = [];
      
      // Forex calculation in background (non-blocking)
      if (tradeData.exit_price && rawData.instrument) {
        promises.push(
          forexEngine.calculateTrade({
            symbol: rawData.instrument,
            side: rawData.side as 'long' | 'short',
            lots: rawData.size,
            entryPrice: rawData.entry_price,
            exitPrice: tradeData.exit_price,
            accountCurrency: 'USD'
          }).then(calculation => {
            tradeData.pnl = calculation.convertedPnL;
            tradeData.pips = calculation.pips;
            tradeData.result = calculation.convertedPnL > 0 ? 'win' : calculation.convertedPnL < 0 ? 'loss' : 'breakeven';
          }).catch(error => {
            console.warn('Forex calculation failed, using simple calculation:', error);
            const priceDiff = tradeData.side === 'long' 
              ? tradeData.exit_price - tradeData.entry_price
              : tradeData.entry_price - tradeData.exit_price;
            tradeData.pnl = priceDiff * tradeData.size;
            tradeData.result = tradeData.pnl > 0 ? 'win' : tradeData.pnl < 0 ? 'loss' : 'breakeven';
          })
        );
      }

      // Wait for calculations to complete, then insert
      await Promise.all(promises);
      
      const { data: insertedTrade, error } = await supabase
        .from("trades")
        .insert([tradeData])
        .select("id,instrument,pnl,side,entry_price,exit_price,size")
        .single();

      if (error) {
        console.error('Trade insertion error:', error);
        toast({
          variant: "destructive",
          title: "Error adding trade",
          description: error.message,
        });
        // Revert optimistic update
        setMonthlyTradeCount(prev => prev - 1);
      } else {
        toast({
          title: "✅ Trade added successfully!",
          description: `${accounts.find(acc => acc.id === rawData.account_id)?.nickname || 'Account'} updated`,
        });

        // Auto-create share link in background
        setTimeout(async () => {
          try {
            const share = await createTradeShare({
              trade_id: insertedTrade!.id,
              title: `${insertedTrade!.pnl && insertedTrade!.pnl > 0 ? 'Profitable' : 'Learning'} ${insertedTrade!.instrument} Trade`,
              description: `Shared via PipTrackr — P&L: $${(insertedTrade!.pnl || 0).toFixed(2)}`,
              is_public: true,
            });

            if (share) {
              // Build public URL for the share page
              const hostname = window.location.hostname;
              let base = window.location.origin;
              if (hostname.startsWith('app.')) {
                base = base.replace('//app.', '//');
              }
              const shareUrl = `${base}/shared/trade/${share.share_token}`;

              toast({
                title: "🔗 Share link created",
                description: shareUrl,
              });

              // Kick off certificate generation (non-blocking)
              generateCertificate(share.id);
            }
          } catch (e) {
            console.warn('Auto-share failed', e);
          }
        }, 0);
      }
    } catch (error: any) {
      console.error('Submission error:', error);
      toast({
        variant: "destructive",
        title: "Error adding trade",
        description: error.message || "Please try again",
      });
      // Revert optimistic update
      setMonthlyTradeCount(prev => prev - 1);
    } finally {
      setIsSubmitting(false);
    }
  }, [user, subscriptionData, monthlyTradeCount, formData, accounts, onTradeAdded, toast, isSubmitting]);

  return (
    <Card className="glass-card border-card-border">
      <CardHeader>
        <CardTitle className="flex items-center gap-2 text-xl font-poppins">
          <DollarSign className="w-5 h-5 text-primary" />
          Add New Trade
          {previewData && (
            <Badge variant="outline" className="ml-auto">
              <Calculator className="w-4 h-4 mr-1" />
              {previewData.pips > 0 ? '+' : ''}{previewData.pips.toFixed(1)} pips
            </Badge>
          )}
        </CardTitle>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="instrument">Instrument</Label>
              <InstrumentSelector
                value={formData.instrument || ""}
                onChange={(value) => setFormData({...formData, instrument: value})}
                accountId={formData.account_id}
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="trade_type">Trade Type</Label>
              <Select 
                name="trade_type" 
                value={formData.trade_type || "broker"}
                onValueChange={(value) => setFormData({...formData, trade_type: value, prop_challenge_id: ""})}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select trade type" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="broker">
                    <div className="flex items-center gap-2">
                      <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
                      <span>Broker Account</span>
                    </div>
                  </SelectItem>
                  <SelectItem value="prop_firm">
                    <div className="flex items-center gap-2">
                      <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                      <span>Prop Firm Challenge</span>
                    </div>
                  </SelectItem>
                </SelectContent>
              </Select>
            </div>

            {formData.trade_type === 'prop_firm' && (
              <div className="space-y-2">
                <Label htmlFor="prop_challenge_id">Challenge</Label>
                <Select 
                  name="prop_challenge_id" 
                  value={formData.prop_challenge_id || ""}
                  onValueChange={(value) => setFormData({...formData, prop_challenge_id: value})}
                  required={formData.trade_type === 'prop_firm'}
                >
                  <SelectTrigger className="border-green-200 focus:border-green-500">
                    <SelectValue placeholder="Select prop challenge" />
                  </SelectTrigger>
                  <SelectContent>
                    {propChallenges.length === 0 ? (
                      <SelectItem value="" disabled>
                        <div className="text-muted-foreground">No active challenges found</div>
                      </SelectItem>
                    ) : (
                      propChallenges.map((challenge) => (
                        <SelectItem key={challenge.id} value={challenge.id}>
                          <div className="flex items-center justify-between w-full">
                            <span>{challenge.challenge_name}</span>
                            <Badge variant="outline" className="ml-2 text-xs">
                              {challenge.status}
                            </Badge>
                          </div>
                        </SelectItem>
                      ))
                    )}
                  </SelectContent>
                </Select>
              </div>
            )}

            <div className="space-y-2">
              <Label htmlFor="strategy_id">Strategy</Label>
              <Select 
                name="strategy_id" 
                value={formData.strategy_id || "none"}
                onValueChange={(value) => setFormData({...formData, strategy_id: value === "none" ? "" : value})}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select strategy (optional)" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="none">
                    <div className="text-muted-foreground">None (No Strategy)</div>
                  </SelectItem>
                  {strategies.map((strategy) => (
                    <SelectItem key={strategy.id} value={strategy.id}>
                      <div className="flex items-center justify-between w-full">
                        <span>{strategy.name}</span>
                        {strategy.description && (
                          <span className="text-xs text-muted-foreground ml-2 truncate">
                            {strategy.description.slice(0, 30)}...
                          </span>
                        )}
                      </div>
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="account_id">Account <span className="text-destructive">*</span></Label>
              <Select 
                name="account_id" 
                value={formData.account_id || selectedAccountId || undefined}
                onValueChange={(value) => setFormData({...formData, account_id: value})}
                required
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select account" />
                </SelectTrigger>
                <SelectContent>
                  {accounts.map((acc) => (
                    <SelectItem key={acc.id} value={acc.id}>
                      {acc.nickname || acc.name} ({acc.currency})
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="side">Side</Label>
              <Select 
                name="side" 
                value={formData.side || undefined}
                onValueChange={(value) => setFormData({...formData, side: value})}
                required
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select side" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="long">
                    <div className="flex items-center gap-2">
                      <TrendingUp className="w-4 h-4 text-green-500" />
                      Long (Buy)
                    </div>
                  </SelectItem>
                  <SelectItem value="short">
                    <div className="flex items-center gap-2">
                      <TrendingDown className="w-4 h-4 text-red-500" />
                      Short (Sell)
                    </div>
                  </SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="entry_price">Entry Price</Label>
              <Input 
                id="entry_price"
                name="entry_price"
                type="number"
                step="0.00001"
                placeholder="1.08450"
                value={formData.entry_price || ""}
                onChange={(e) => {
                  setFormData({...formData, entry_price: e.target.value});
                  handleInputChange(e);
                }}
                required 
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="size">Lot Size</Label>
              <Input 
                id="size"
                name="size"
                type="number"
                step="0.01"
                placeholder="0.10 lots"
                onChange={handleInputChange}
                required 
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="stop_loss">Stop Loss</Label>
              <Input 
                id="stop_loss"
                name="stop_loss"
                type="number"
                step="0.00001"
                placeholder="1.08200"
                onChange={handleInputChange}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="take_profit">Take Profit</Label>
              <Input 
                id="take_profit"
                name="take_profit"
                type="number"
                step="0.00001"
                placeholder="1.08700"
                onChange={handleInputChange}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="opened_at">Open Time</Label>
              <Input 
                id="opened_at"
                name="opened_at"
                type="datetime-local"
                required 
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="closed_at">Close Time (if closed)</Label>
              <Input 
                id="closed_at"
                name="closed_at"
                type="datetime-local"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="exit_price">Exit Price (if closed)</Label>
              <Input 
                id="exit_price"
                name="exit_price"
                type="number"
                step="0.00001"
                placeholder="1.08650"
                onChange={handleInputChange}
              />
              {previewData && (
                <div className="mt-2 p-3 bg-muted/50 rounded-lg">
                  <div className="grid grid-cols-2 gap-4 text-sm">
                    <div>
                      <span className="text-muted-foreground">Pips:</span>
                      <span className={`ml-2 font-medium ${previewData.pips >= 0 ? 'text-success' : 'text-danger'}`}>
                        {previewData.pips > 0 ? '+' : ''}{previewData.pips.toFixed(1)}
                      </span>
                    </div>
                    <div>
                      <span className="text-muted-foreground">P&L:</span>
                      <span className={`ml-2 font-medium ${previewData.convertedPnL >= 0 ? 'text-success' : 'text-danger'}`}>
                        ${previewData.convertedPnL.toFixed(2)}
                      </span>
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="notes_pre">Pre-Trade Notes</Label>
            <Textarea 
              id="notes_pre"
              name="notes_pre"
              placeholder="Why did you take this trade? What was your analysis?"
              rows={3}
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="notes_post">Post-Trade Notes</Label>
            <Textarea 
              id="notes_post"
              name="notes_post"
              placeholder="How did the trade go? What did you learn?"
              rows={3}
            />
          </div>

          <Button 
            type="submit" 
            className="w-full animate-fade-in hover-scale" 
            variant="primary"
            disabled={isLoading || !dataLoaded || isSubmitting}
          >
            {isSubmitting ? (
              <div className="flex items-center gap-2">
                <div className="w-4 h-4 border-2 border-white/20 border-t-white rounded-full animate-spin" />
                Processing...
              </div>
            ) : isLoading ? (
              "Loading..."
            ) : (
              "Add Trade"
            )}
          </Button>
        </form>
      </CardContent>
    </Card>
  );
}