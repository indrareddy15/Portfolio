import { useState, useEffect, useMemo } from "react";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter } from "@/components/ui/dialog";
import { Plus } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/components/ui/use-toast";

interface InstrumentSelectorProps {
  value?: string;
  onChange: (value: string) => void;
  accountId?: string;
  required?: boolean;
}

export function InstrumentSelector({ 
  value, 
  onChange, 
  accountId,
  required = false 
}: InstrumentSelectorProps) {
  const [instrumentClasses, setInstrumentClasses] = useState<any[]>([]);
  const [instruments, setInstruments] = useState<any[]>([]);
  const [selectedClass, setSelectedClass] = useState<string>("");
  const [allowedInstruments, setAllowedInstruments] = useState<any>({});
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [newSymbol, setNewSymbol] = useState("");
  const [newDescription, setNewDescription] = useState("");
  const { toast } = useToast();

  // Load data
  useEffect(() => {
    console.log('InstrumentSelector: Loading data, accountId:', accountId);
    loadInstrumentClasses();
    loadInstruments();
    if (accountId) {
      loadAccountSettings();
    }
  }, [accountId]);

  // Reset symbol when class changes
  useEffect(() => {
    if (selectedClass && value) {
      // Only reset if we have a current value that doesn't belong to the new class
      const currentInstruments = instruments.filter(inst => inst.class_name === selectedClass);
      const isCurrentValueValid = currentInstruments.some(inst => inst.symbol === value);
      
      if (!isCurrentValueValid) {
        onChange("");
      }
    }
  }, [selectedClass, onChange, value, instruments]);

  const loadInstrumentClasses = async () => {
    console.log('InstrumentSelector: Loading instrument classes...');
    const { data, error } = await supabase
      .from('instrument_classes')
      .select('*')
      .order('name');
    
    if (error) {
      console.error('Error loading instrument classes:', error);
      toast({
        title: "Error loading instrument classes",
        description: error.message,
        variant: "destructive",
      });
    } else {
      console.log('InstrumentSelector: Loaded classes:', data);
      setInstrumentClasses(data || []);
    }
  };

  const loadInstruments = async () => {
    console.log('InstrumentSelector: Loading instruments...');
    const { data, error } = await supabase
      .from('instruments')
      .select('*')
      .eq('is_active', true)
      .order('class_name, symbol');
    
    if (error) {
      console.error('Error loading instruments:', error);
      toast({
        title: "Error loading instruments",
        description: error.message,
        variant: "destructive",
      });
    } else {
      console.log('InstrumentSelector: Loaded instruments:', data);
      setInstruments(data || []);
    }
  };

  const loadAccountSettings = async () => {
    const { data, error } = await supabase
      .from('accounts')
      .select('allowed_instruments')
      .eq('id', accountId)
      .maybeSingle();
    
    if (error) {
      console.error('Error loading account settings:', error);
    } else if (data) {
      setAllowedInstruments(data?.allowed_instruments || {});
    }
  };

  // Get filtered instruments for selected class
  const getFilteredInstruments = () => {
    if (!selectedClass) return [];
    
    // Filter by class_name
    let classInstruments = instruments.filter(inst => inst.class_name === selectedClass);
    
    // Only apply account filtering if we have both accountId and allowedInstruments data
    if (accountId && allowedInstruments && Object.keys(allowedInstruments).length > 0) {
      // If the class is explicitly set to false, filter it out
      if (allowedInstruments[selectedClass] === false) {
        return [];
      }
      // If the class is not in allowedInstruments at all, allow it (default behavior)
      // If the class is set to true, allow it
    }
    
    return classInstruments;
  };

  // Handle adding custom symbol
  const handleAddCustomSymbol = async () => {
    if (!newSymbol.trim() || !selectedClass) {
      toast({
        title: "Validation Error",
        description: "Symbol and class are required",
        variant: "destructive",
      });
      return;
    }

    const instrumentData = {
      symbol: newSymbol.toUpperCase(),
      description: newDescription || newSymbol.toUpperCase(),
      class_name: selectedClass,
      base_ccy: newSymbol.substring(0, 3).toUpperCase(),
      quote_ccy: newSymbol.length >= 6 ? newSymbol.substring(3, 6).toUpperCase() : 'USD',
      is_active: true
    };

    const { error } = await supabase
      .from('instruments')
      .insert([instrumentData]);

    if (error) {
      toast({
        title: "Error adding instrument",
        description: error.message,
        variant: "destructive",
      });
    } else {
      toast({
        title: "Instrument added",
        description: `${newSymbol.toUpperCase()} has been added successfully`,
      });
      setIsAddDialogOpen(false);
      setNewSymbol("");
      setNewDescription("");
      loadInstruments();
      onChange(newSymbol.toUpperCase());
    }
  };

  // Check if class is allowed for current account
  const isClassAllowed = (className: string) => {
    if (!accountId || Object.keys(allowedInstruments).length === 0) return true;
    return allowedInstruments[className] === true;
  };

  return (
    <div className="space-y-4">
      {/* Class Selection */}
      <div className="space-y-2">
        <Label>Instrument Class</Label>
        <Select value={selectedClass} onValueChange={(value) => {
          console.log('InstrumentSelector: Class selected:', value);
          setSelectedClass(value);
        }}>
          <SelectTrigger>
            <SelectValue placeholder="Select instrument class" />
          </SelectTrigger>
          <SelectContent className="bg-popover border-border">
            {instrumentClasses.length === 0 ? (
              <SelectItem value="loading" disabled>
                Loading classes...
              </SelectItem>
            ) : (
              instrumentClasses.map((cls) => (
                <SelectItem 
                  key={cls.name} 
                  value={cls.name}
                  disabled={!isClassAllowed(cls.name)}
                >
                  <div className="flex items-center justify-between w-full">
                    <span>{cls.display_name}</span>
                    {!isClassAllowed(cls.name) && (
                      <span className="text-xs text-muted-foreground ml-2">
                        (Not allowed)
                      </span>
                    )}
                  </div>
                </SelectItem>
              ))
            )}
          </SelectContent>
        </Select>
        {accountId && !isClassAllowed(selectedClass) && selectedClass && (
          <p className="text-xs text-warning">
            This instrument class is not enabled for the selected account. 
            Enable it in account settings.
          </p>
        )}
      </div>

      {/* Symbol Selection */}
      <div className="space-y-2">
        <div className="flex items-center justify-between">
          <Label>Symbol/Pair</Label>
          {selectedClass && (
            <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
              <DialogTrigger asChild>
                <Button variant="outline" size="sm">
                  <Plus className="h-3 w-3 mr-1" />
                  Add Custom
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>Add Custom Symbol</DialogTitle>
                </DialogHeader>
                <div className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="symbol">Symbol</Label>
                    <Input
                      id="symbol"
                      value={newSymbol}
                      onChange={(e) => setNewSymbol(e.target.value)}
                      placeholder="e.g., BTCUSD, EURUSD"
                      className="uppercase"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="description">Description (Optional)</Label>
                    <Input
                      id="description"
                      value={newDescription}
                      onChange={(e) => setNewDescription(e.target.value)}
                      placeholder="e.g., Bitcoin vs US Dollar"
                    />
                  </div>
                </div>
                <DialogFooter>
                  <Button variant="outline" onClick={() => setIsAddDialogOpen(false)}>
                    Cancel
                  </Button>
                  <Button onClick={handleAddCustomSymbol}>
                    Add Symbol
                  </Button>
                </DialogFooter>
              </DialogContent>
            </Dialog>
          )}
        </div>
        
        <Select 
          value={value || ""} 
          onValueChange={(newValue) => {
            console.log('InstrumentSelector: Instrument selected:', newValue);
            if (newValue && newValue !== 'select-class-first' && newValue !== 'no-instruments') {
              onChange(newValue);
            }
          }}
          disabled={!selectedClass}
        >
          <SelectTrigger>
            <SelectValue 
              placeholder={
                !selectedClass 
                  ? "First select an instrument class above" 
                  : getFilteredInstruments().length === 0 && selectedClass
                    ? "No instruments available for this class"
                    : "Choose your trading pair"
              } 
            />
          </SelectTrigger>
          <SelectContent className="bg-popover border-border">
            {!selectedClass ? (
              <SelectItem value="select-class-first" disabled>
                Select a class first
              </SelectItem>
            ) : getFilteredInstruments().length === 0 ? (
              <SelectItem value="no-instruments" disabled>
                No instruments available for this class
              </SelectItem>
            ) : (
              getFilteredInstruments().map((instrument) => (
                <SelectItem 
                  key={`${instrument.id}-${instrument.symbol}`} 
                  value={instrument.symbol}
                >
                  <div className="flex items-center justify-between w-full">
                    <span className="font-medium">{instrument.symbol}</span>
                    {instrument.description && (
                      <span className="text-xs text-muted-foreground ml-2">
                        {instrument.description}
                      </span>
                    )}
                  </div>
                </SelectItem>
              ))
            )}
          </SelectContent>
        </Select>
        
        {selectedClass && getFilteredInstruments().length === 0 && isClassAllowed(selectedClass) && (
          <p className="text-xs text-muted-foreground">
            No instruments found for this class. You can add a custom symbol.
          </p>
        )}
      </div>
    </div>
  );
}