import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { 
  Shield, 
  AlertTriangle, 
  TrendingDown, 
  Target,
  Activity,
  BarChart3,
  Zap
} from "lucide-react";

interface PropRiskMetricsProps {
  challenge: any;
  dailyResults: any[];
  accountSize: number;
}

export function PropRiskMetrics({ challenge, dailyResults, accountSize }: PropRiskMetricsProps) {
  // Calculate advanced risk metrics
  const calculateRiskMetrics = () => {
    if (dailyResults.length === 0) return null;

    const pnlValues = dailyResults.map(r => r.daily_pnl);
    const winningDays = pnlValues.filter(p => p > 0);
    const losingDays = pnlValues.filter(p => p < 0);
    
    // Calculate cumulative P&L for drawdown analysis
    let cumulativePnL = 0;
    let maxEquity = accountSize;
    let maxDrawdown = 0;
    const drawdownSeries = [];
    
    dailyResults.forEach(result => {
      cumulativePnL += result.daily_pnl;
      const currentEquity = accountSize + cumulativePnL;
      
      if (currentEquity > maxEquity) {
        maxEquity = currentEquity;
      }
      
      const drawdown = maxEquity - currentEquity;
      if (drawdown > maxDrawdown) {
        maxDrawdown = drawdown;
      }
      
      drawdownSeries.push({
        date: result.date,
        drawdown: drawdown,
        drawdownPercent: (drawdown / accountSize) * 100
      });
    });

    // Risk metrics calculations
    const avgWin = winningDays.length > 0 ? winningDays.reduce((a, b) => a + b, 0) / winningDays.length : 0;
    const avgLoss = losingDays.length > 0 ? Math.abs(losingDays.reduce((a, b) => a + b, 0) / losingDays.length) : 0;
    const winRate = (winningDays.length / pnlValues.length) * 100;
    const profitFactor = avgLoss > 0 ? (avgWin * winningDays.length) / (avgLoss * losingDays.length) : 0;
    
    // Sharpe ratio approximation (simplified)
    const avgDailyReturn = pnlValues.reduce((a, b) => a + b, 0) / pnlValues.length;
    const variance = pnlValues.reduce((sum, pnl) => sum + Math.pow(pnl - avgDailyReturn, 2), 0) / pnlValues.length;
    const standardDeviation = Math.sqrt(variance);
    const sharpeRatio = standardDeviation > 0 ? (avgDailyReturn / standardDeviation) * Math.sqrt(252) : 0; // Annualized
    
    // Consistency metrics
    const consecutiveWins = getMaxConsecutive(pnlValues, (p) => p > 0);
    const consecutiveLosses = getMaxConsecutive(pnlValues, (p) => p < 0);
    
    // Risk-to-reward ratio
    const riskReward = avgLoss > 0 ? avgWin / avgLoss : 0;
    
    return {
      maxDrawdown,
      maxDrawdownPercent: (maxDrawdown / accountSize) * 100,
      avgWin,
      avgLoss,
      winRate,
      profitFactor,
      sharpeRatio,
      consecutiveWins,
      consecutiveLosses,
      riskReward,
      totalTrades: pnlValues.length,
      drawdownSeries
    };
  };

  const getMaxConsecutive = (array: number[], condition: (val: number) => boolean): number => {
    let maxStreak = 0;
    let currentStreak = 0;
    
    array.forEach(val => {
      if (condition(val)) {
        currentStreak++;
        maxStreak = Math.max(maxStreak, currentStreak);
      } else {
        currentStreak = 0;
      }
    });
    
    return maxStreak;
  };

  const riskMetrics = calculateRiskMetrics();

  if (!riskMetrics) {
    return (
      <Card className="glass-card border-card-border">
        <CardContent className="p-12 text-center">
          <Shield className="w-16 h-16 mx-auto mb-4 text-muted-foreground" />
          <h3 className="text-xl font-semibold mb-2">No Risk Data Available</h3>
          <p className="text-muted-foreground">
            Start trading to see comprehensive risk analysis and metrics.
          </p>
        </CardContent>
      </Card>
    );
  }

  // Risk level assessment
  const getRiskLevel = (drawdownPercent: number) => {
    if (drawdownPercent < 2) return { level: 'Low', color: 'success', badge: 'default' };
    if (drawdownPercent < 5) return { level: 'Moderate', color: 'warning', badge: 'secondary' };
    return { level: 'High', color: 'danger', badge: 'destructive' };
  };

  const riskLevel = getRiskLevel(riskMetrics.maxDrawdownPercent);

  return (
    <div className="space-y-6">
      {/* Risk Overview Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <Card className="glass-card border-card-border">
          <CardContent className="p-6">
            <div className="flex items-center gap-2 mb-3">
              <TrendingDown className="w-5 h-5 text-danger" />
              <span className="text-sm font-medium">Max Drawdown</span>
            </div>
            <div className="space-y-2">
              <div className="text-2xl font-bold text-danger">
                {riskMetrics.maxDrawdownPercent.toFixed(2)}%
              </div>
              <div className="text-sm text-muted-foreground">
                ${riskMetrics.maxDrawdown.toLocaleString()}
              </div>
              <Badge variant={riskLevel.badge as any} className="text-xs">
                {riskLevel.level} Risk
              </Badge>
            </div>
          </CardContent>
        </Card>

        <Card className="glass-card border-card-border">
          <CardContent className="p-6">
            <div className="flex items-center gap-2 mb-3">
              <Target className="w-5 h-5 text-info" />
              <span className="text-sm font-medium">Win Rate</span>
            </div>
            <div className="space-y-2">
              <div className="text-2xl font-bold text-info">
                {riskMetrics.winRate.toFixed(1)}%
              </div>
              <Progress value={riskMetrics.winRate} className="h-2" />
              <div className="text-sm text-muted-foreground">
                {dailyResults.filter(d => d.daily_pnl > 0).length} winning days
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="glass-card border-card-border">
          <CardContent className="p-6">
            <div className="flex items-center gap-2 mb-3">
              <BarChart3 className="w-5 h-5 text-success" />
              <span className="text-sm font-medium">Profit Factor</span>
            </div>
            <div className="space-y-2">
              <div className={`text-2xl font-bold ${
                riskMetrics.profitFactor > 1.5 ? 'text-success' : 
                riskMetrics.profitFactor > 1 ? 'text-warning' : 'text-danger'
              }`}>
                {riskMetrics.profitFactor.toFixed(2)}
              </div>
              <div className="text-sm text-muted-foreground">
                {riskMetrics.profitFactor > 1 ? 'Profitable' : 'Needs Improvement'}
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="glass-card border-card-border">
          <CardContent className="p-6">
            <div className="flex items-center gap-2 mb-3">
              <Zap className="w-5 h-5 text-primary" />
              <span className="text-sm font-medium">Sharpe Ratio</span>
            </div>
            <div className="space-y-2">
              <div className={`text-2xl font-bold ${
                riskMetrics.sharpeRatio > 1 ? 'text-success' : 
                riskMetrics.sharpeRatio > 0.5 ? 'text-warning' : 'text-danger'
              }`}>
                {riskMetrics.sharpeRatio.toFixed(2)}
              </div>
              <div className="text-sm text-muted-foreground">
                Risk-adjusted returns
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Detailed Risk Analysis */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Risk Breakdown */}
        <Card className="glass-card border-card-border">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Shield className="w-5 h-5 text-primary" />
              Risk Breakdown
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="text-center p-3 bg-success/10 rounded-lg">
                <div className="text-lg font-bold text-success">
                  ${riskMetrics.avgWin.toFixed(2)}
                </div>
                <div className="text-sm text-muted-foreground">Avg Win</div>
              </div>
              <div className="text-center p-3 bg-danger/10 rounded-lg">
                <div className="text-lg font-bold text-danger">
                  ${riskMetrics.avgLoss.toFixed(2)}
                </div>
                <div className="text-sm text-muted-foreground">Avg Loss</div>
              </div>
            </div>

            <div className="space-y-3">
              <div className="flex justify-between">
                <span className="text-sm">Risk/Reward Ratio</span>
                <span className={`text-sm font-medium ${
                  riskMetrics.riskReward > 2 ? 'text-success' : 
                  riskMetrics.riskReward > 1 ? 'text-warning' : 'text-danger'
                }`}>
                  1:{riskMetrics.riskReward.toFixed(2)}
                </span>
              </div>
              
              <div className="flex justify-between">
                <span className="text-sm">Max Daily Loss Limit</span>
                <span className="text-sm font-medium">
                  ${challenge.max_daily_loss.toLocaleString()}
                </span>
              </div>
              
              <div className="flex justify-between">
                <span className="text-sm">Current Daily Loss</span>
                <span className={`text-sm font-medium ${
                  Math.abs(challenge.current_daily_loss) > challenge.max_daily_loss * 0.8 
                  ? 'text-danger' : 'text-success'
                }`}>
                  ${Math.abs(challenge.current_daily_loss).toLocaleString()}
                </span>
              </div>
              
              <Progress 
                value={(Math.abs(challenge.current_daily_loss) / challenge.max_daily_loss) * 100}
                className="h-2"
              />
            </div>
          </CardContent>
        </Card>

        {/* Consistency Metrics */}
        <Card className="glass-card border-card-border">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Activity className="w-5 h-5 text-primary" />
              Consistency Analysis
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="text-center p-3 bg-info/10 rounded-lg">
                <div className="text-lg font-bold text-info">
                  {riskMetrics.consecutiveWins}
                </div>
                <div className="text-sm text-muted-foreground">Max Win Streak</div>
              </div>
              <div className="text-center p-3 bg-warning/10 rounded-lg">
                <div className="text-lg font-bold text-warning">
                  {riskMetrics.consecutiveLosses}
                </div>
                <div className="text-sm text-muted-foreground">Max Loss Streak</div>
              </div>
            </div>

            <div className="space-y-3">
              <div className="flex justify-between">
                <span className="text-sm">Total Trading Days</span>
                <span className="text-sm font-medium">{riskMetrics.totalTrades}</span>
              </div>
              
              <div className="flex justify-between">
                <span className="text-sm">Winning Days</span>
                <span className="text-sm font-medium text-success">
                  {dailyResults.filter(d => d.daily_pnl > 0).length}
                </span>
              </div>
              
              <div className="flex justify-between">
                <span className="text-sm">Losing Days</span>
                <span className="text-sm font-medium text-danger">
                  {dailyResults.filter(d => d.daily_pnl < 0).length}
                </span>
              </div>
              
              <div className="flex justify-between">
                <span className="text-sm">Rule Violations</span>
                <span className="text-sm font-medium text-warning">
                  {dailyResults.filter(d => !d.passed).length}
                </span>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Risk Warnings */}
      {(riskMetrics.maxDrawdownPercent > 3 || challenge.current_daily_loss / challenge.max_daily_loss > 0.8) && (
        <Card className="glass-card border-destructive bg-destructive/5">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-destructive">
              <AlertTriangle className="w-5 h-5" />
              Risk Warnings
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-2">
            {riskMetrics.maxDrawdownPercent > 5 && (
              <div className="flex items-center gap-2 text-destructive">
                <AlertTriangle className="w-4 h-4" />
                <span className="text-sm">High drawdown detected. Consider reducing position sizes.</span>
              </div>
            )}
            {Math.abs(challenge.current_daily_loss) / challenge.max_daily_loss > 0.8 && (
              <div className="flex items-center gap-2 text-destructive">
                <AlertTriangle className="w-4 h-4" />
                <span className="text-sm">Approaching daily loss limit. Trade with caution.</span>
              </div>
            )}
            {riskMetrics.consecutiveLosses > 3 && (
              <div className="flex items-center gap-2 text-warning">
                <AlertTriangle className="w-4 h-4" />
                <span className="text-sm">Extended losing streak. Consider taking a break or reviewing strategy.</span>
              </div>
            )}
          </CardContent>
        </Card>
      )}
    </div>
  );
}