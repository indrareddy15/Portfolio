import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { 
  Target, 
  TrendingUp,
  Shield,
  AlertTriangle,
  Clock,
  BarChart3,
  PieChart,
  Activity,
  Zap,
  RefreshCw,
  Award,
  TrendingDown
} from "lucide-react";
import { usePropChallenges } from "@/hooks/usePropChallenges";
import { useToast } from "@/hooks/use-toast";
import { PropChallengeCharts } from "./PropChallengeCharts";
import { PropRiskMetrics } from "./PropRiskMetrics";
import { PropPerformanceStats } from "./PropPerformanceStats";
import { PropTradeHistory } from "./PropTradeHistory";
import { format } from "date-fns";

export function PropMetricsDashboard() {
  const {
    challenges,
    dailyResults,
    selectedChallenge,
    setSelectedChallenge,
    loading,
    updateChallengeFromTrades
  } = usePropChallenges();

  const [isUpdating, setIsUpdating] = useState(false);
  const { toast } = useToast();

  const updateMetrics = async () => {
    if (isUpdating) return;
    
    setIsUpdating(true);
    try {
      await updateChallengeFromTrades();
      toast({
        title: "Metrics Updated ⚡",
        description: "All prop firm metrics refreshed in real-time",
      });
    } catch (error: any) {
      toast({
        variant: "destructive",
        title: "Update failed",
        description: error.message,
      });
    } finally {
      setIsUpdating(false);
    }
  };

  const currentChallenge = challenges.find(c => c.id === selectedChallenge);
  const daysRemaining = currentChallenge && currentChallenge.end_date ? 
    Math.max(0, Math.ceil((new Date(currentChallenge.end_date).getTime() - new Date().getTime()) / (1000 * 60 * 60 * 24))) : null;

  // Calculate additional metrics
  const accountSize = currentChallenge ? 
    ((currentChallenge as any).account_size === "custom" 
      ? parseFloat((currentChallenge as any).custom_account_size || "0")
      : parseFloat((currentChallenge as any).account_size || "100000")) : 100000;

  const progressPercentage = currentChallenge?.target_profit ? 
    Math.max(0, Math.min(100, (currentChallenge.current_profit / currentChallenge.target_profit) * 100)) : 0;

  const riskPercentage = accountSize > 0 ? 
    Math.abs((currentChallenge?.current_profit || 0) / accountSize * 100) : 0;

  if (loading) {
    return (
      <div className="space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          {[1, 2, 3, 4].map(i => (
            <Card key={i} className="animate-pulse">
              <CardContent className="p-6">
                <div className="h-4 bg-muted rounded w-3/4 mb-2"></div>
                <div className="h-8 bg-muted rounded w-1/2"></div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    );
  }

  if (!currentChallenge) {
    return (
      <Card className="glass-card border-card-border">
        <CardContent className="p-12 text-center">
          <Target className="w-16 h-16 mx-auto mb-4 text-muted-foreground" />
          <h3 className="text-xl font-semibold mb-2">No Challenge Selected</h3>
          <p className="text-muted-foreground mb-4">
            Select a prop firm challenge to view comprehensive metrics and analytics.
          </p>
          <select 
            value={selectedChallenge}
            onChange={(e) => setSelectedChallenge(e.target.value)}
            className="px-4 py-2 border rounded-md bg-background"
          >
            <option value="">Select a challenge...</option>
            {challenges.map(challenge => (
              <option key={challenge.id} value={challenge.id}>
                {challenge.challenge_name} ({challenge.status})
              </option>
            ))}
          </select>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      {/* Challenge Selection - Top Priority */}
      <Card className="glass-card border-card-border">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Target className="w-5 h-5 text-primary" />
            Active Challenge Selection
            <Badge variant="outline" className="ml-2 text-xs">
              <Zap className="w-3 h-3 mr-1" />
              Real-time
            </Badge>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex items-center gap-4">
            <div className="flex-1">
              <select 
                value={selectedChallenge}
                onChange={(e) => setSelectedChallenge(e.target.value)}
                className="w-full px-4 py-3 border rounded-lg bg-background text-lg font-medium"
              >
                <option value="">Choose your active prop challenge...</option>
                {challenges.map(challenge => (
                  <option key={challenge.id} value={challenge.id}>
                    {challenge.challenge_name} - {challenge.status.toUpperCase()}
                  </option>
                ))}
              </select>
            </div>
            <Button 
              variant="outline" 
              size="sm" 
              onClick={updateMetrics}
              disabled={isUpdating}
            >
              <RefreshCw className={`w-4 h-4 mr-2 ${isUpdating ? 'animate-spin' : ''}`} />
              {isUpdating ? 'Syncing...' : 'Sync'}
            </Button>
          </div>
          {challenges.length === 0 && (
            <div className="mt-4 p-4 bg-muted/20 rounded-lg text-center">
              <p className="text-muted-foreground">
                No challenges found. Create your first prop firm challenge to get started.
              </p>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Header with Real-time Controls */}
      <Card className="glass-card border-card-border">
        <CardHeader>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <div className="flex items-center gap-2">
                <Target className="w-6 h-6 text-primary" />
                <div>
                  <h2 className="text-2xl font-bold">{currentChallenge.challenge_name}</h2>
                  <p className="text-sm text-muted-foreground">
                    Account Size: ${accountSize.toLocaleString()}
                  </p>
                </div>
              </div>
              <Badge variant={currentChallenge.status === 'active' ? 'default' : 
                             currentChallenge.status === 'passed' ? 'secondary' : 'destructive'}
                     className="text-sm">
                {currentChallenge.status.toUpperCase()}
              </Badge>
            </div>
            <div className="flex items-center gap-2">
              <Badge variant="outline" className="text-xs">
                <Zap className="w-3 h-3 mr-1" />
                Live Metrics
              </Badge>
              <Button 
                variant="outline" 
                size="sm" 
                onClick={updateMetrics}
                disabled={isUpdating}
              >
                <RefreshCw className={`w-4 h-4 mr-2 ${isUpdating ? 'animate-spin' : ''}`} />
                {isUpdating ? 'Syncing...' : 'Refresh'}
              </Button>
            </div>
          </div>
        </CardHeader>
      </Card>

      {/* Key Performance Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {/* Profit Progress */}
        <Card className="glass-card border-card-border relative overflow-hidden">
          <div className="absolute top-2 right-2">
            <div className="h-2 w-2 bg-green-500 rounded-full animate-pulse"></div>
          </div>
          <CardContent className="p-6">
            <div className="flex items-center gap-2 mb-3">
              <TrendingUp className="w-5 h-5 text-success" />
              <span className="text-sm font-medium">Profit Progress</span>
            </div>
            <div className="space-y-2">
              <div className="flex items-baseline gap-2">
                <span className={`text-2xl font-bold ${currentChallenge.current_profit >= 0 ? 'text-success' : 'text-danger'}`}>
                  ${currentChallenge.current_profit.toLocaleString()}
                </span>
                <span className="text-sm text-muted-foreground">
                  / ${currentChallenge.target_profit?.toLocaleString() || '0'}
                </span>
              </div>
              <Progress value={progressPercentage} className="h-2" />
              <div className="text-sm text-muted-foreground">
                {progressPercentage.toFixed(1)}% Complete
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Risk Management */}
        <Card className="glass-card border-card-border relative overflow-hidden">
          <div className="absolute top-2 right-2">
            <div className={`h-2 w-2 rounded-full animate-pulse ${
              riskPercentage > 5 ? 'bg-red-500' : riskPercentage > 3 ? 'bg-yellow-500' : 'bg-green-500'
            }`}></div>
          </div>
          <CardContent className="p-6">
            <div className="flex items-center gap-2 mb-3">
              <Shield className="w-5 h-5 text-warning" />
              <span className="text-sm font-medium">Account Risk</span>
            </div>
            <div className="space-y-2">
              <div className="text-2xl font-bold text-warning">
                {riskPercentage.toFixed(2)}%
              </div>
              <div className="text-sm text-muted-foreground">
                Max Daily: ${currentChallenge.max_daily_loss.toLocaleString()}
              </div>
              <div className="text-sm text-muted-foreground">
                Current Daily: ${Math.abs(currentChallenge.current_daily_loss).toLocaleString()}
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Trading Days */}
        <Card className="glass-card border-card-border relative overflow-hidden">
          <div className="absolute top-2 right-2">
            <div className={`h-2 w-2 rounded-full animate-pulse ${
              currentChallenge.trading_days_count >= currentChallenge.min_trading_days 
              ? 'bg-green-500' : 'bg-yellow-500'
            }`}></div>
          </div>
          <CardContent className="p-6">
            <div className="flex items-center gap-2 mb-3">
              <Clock className="w-5 h-5 text-info" />
              <span className="text-sm font-medium">Trading Progress</span>
            </div>
            <div className="space-y-2">
              <div className="text-2xl font-bold text-info">
                {currentChallenge.trading_days_count}
              </div>
              <Progress 
                value={(currentChallenge.trading_days_count / currentChallenge.min_trading_days) * 100} 
                className="h-2" 
              />
              <div className="text-sm text-muted-foreground">
                {currentChallenge.min_trading_days} days required
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Time Remaining */}
        <Card className="glass-card border-card-border relative overflow-hidden">
          <div className="absolute top-2 right-2">
            <div className={`h-2 w-2 rounded-full animate-pulse ${
              daysRemaining === null ? 'bg-blue-500' : daysRemaining > 7 ? 'bg-green-500' : daysRemaining > 3 ? 'bg-yellow-500' : 'bg-red-500'
            }`}></div>
          </div>
          <CardContent className="p-6">
            <div className="flex items-center gap-2 mb-3">
              <AlertTriangle className="w-5 h-5 text-secondary" />
              <span className="text-sm font-medium">Time Status</span>
            </div>
            <div className="space-y-2">
              <div className="text-2xl font-bold text-secondary">
                {daysRemaining !== null ? daysRemaining : "∞"}
              </div>
              <div className="text-sm text-muted-foreground">
                {daysRemaining !== null 
                  ? `Days until ${format(new Date(currentChallenge.end_date), "MMM dd")}`
                  : "Unlimited Time Challenge"
                }
              </div>
              {daysRemaining !== null && (
                <Progress 
                  value={Math.max(0, 100 - (daysRemaining / 30) * 100)} 
                  className="h-2" 
                />
              )}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Tabbed Analytics */}
      <Tabs defaultValue="overview" className="space-y-6">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="overview" className="flex items-center gap-2">
            <BarChart3 className="w-4 h-4" />
            Overview
          </TabsTrigger>
          <TabsTrigger value="performance" className="flex items-center gap-2">
            <TrendingUp className="w-4 h-4" />
            Performance
          </TabsTrigger>
          <TabsTrigger value="risk" className="flex items-center gap-2">
            <Shield className="w-4 h-4" />
            Risk Analysis
          </TabsTrigger>
          <TabsTrigger value="charts" className="flex items-center gap-2">
            <PieChart className="w-4 h-4" />
            Charts
          </TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Challenge Summary */}
            <Card className="glass-card border-card-border">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Award className="w-5 h-5 text-primary" />
                  Challenge Summary
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="text-center p-3 bg-success/10 rounded-lg">
                    <div className="text-lg font-bold text-success">
                      {dailyResults.filter(d => d.passed).length}
                    </div>
                    <div className="text-sm text-muted-foreground">Passed Days</div>
                  </div>
                  <div className="text-center p-3 bg-danger/10 rounded-lg">
                    <div className="text-lg font-bold text-danger">
                      {dailyResults.filter(d => !d.passed).length}
                    </div>
                    <div className="text-sm text-muted-foreground">Failed Days</div>
                  </div>
                </div>
                
                <div className="space-y-2">
                  <div className="flex justify-between">
                    <span className="text-sm">Success Rate</span>
                    <span className="text-sm font-medium">
                      {dailyResults.length > 0 ? 
                        ((dailyResults.filter(d => d.passed).length / dailyResults.length) * 100).toFixed(1) : 0}%
                    </span>
                  </div>
                  <Progress 
                    value={dailyResults.length > 0 ? 
                      (dailyResults.filter(d => d.passed).length / dailyResults.length) * 100 : 0} 
                  />
                </div>
              </CardContent>
            </Card>

            {/* Recent Performance */}
            <Card className="glass-card border-card-border">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Activity className="w-5 h-5 text-primary" />
                  Recent Performance
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="max-h-64 overflow-y-auto space-y-2">
                  {dailyResults.slice(0, 5).map(result => (
                    <div key={result.id} className="flex items-center justify-between p-3 bg-muted/20 rounded-lg">
                      <div className="flex items-center gap-3">
                        {result.passed ? (
                          <div className="w-3 h-3 bg-success rounded-full"></div>
                        ) : (
                          <div className="w-3 h-3 bg-danger rounded-full"></div>
                        )}
                        <span className="text-sm font-medium">
                          {format(new Date(result.date), "MMM dd")}
                        </span>
                      </div>
                      <div className="text-right">
                        <div className={`text-sm font-semibold ${
                          result.daily_pnl >= 0 ? 'text-success' : 'text-danger'
                        }`}>
                          ${result.daily_pnl.toFixed(2)}
                        </div>
                        <div className="text-xs text-muted-foreground">
                          {result.trades_count} trades
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="performance">
          <PropPerformanceStats 
            challenge={currentChallenge} 
            dailyResults={dailyResults}
            accountSize={accountSize}
          />
        </TabsContent>

        <TabsContent value="risk">
          <PropRiskMetrics 
            challenge={currentChallenge} 
            dailyResults={dailyResults}
            accountSize={accountSize}
          />
        </TabsContent>

        <TabsContent value="charts">
          <PropChallengeCharts 
            challenge={currentChallenge} 
            dailyResults={dailyResults}
            accountSize={accountSize}
          />
        </TabsContent>
      </Tabs>

      {/* Trade History Section */}
      {currentChallenge && (
        <div className="mt-6">
          <PropTradeHistory 
            challengeId={currentChallenge.id}
            onTradeUpdate={updateMetrics}
          />
        </div>
      )}
    </div>
  );
}