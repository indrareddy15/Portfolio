import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger, DropdownMenuSeparator } from "@/components/ui/dropdown-menu";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from "@/components/ui/alert-dialog";
import { 
  Target, 
  TrendingDown, 
  Calendar as CalendarIcon,
  AlertTriangle,
  CheckCircle,
  XCircle,
  Download,
  Plus,
  Timer,
  RefreshCw,
  Activity,
  DollarSign,
  Zap,
  Trash2,
  MoreVertical
} from "lucide-react";
import { format } from "date-fns";
import { cn } from "@/lib/utils";
import { usePropChallenges } from "@/hooks/usePropChallenges";
import { useToast } from "@/components/ui/use-toast";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";

export function PropChallengeTracker() {
  const {
    challenges,
    dailyResults,
    selectedChallenge,
    setSelectedChallenge,
    loading,
    refetchChallenges,
    updateChallengeFromTrades,
    deleteChallenge
  } = usePropChallenges();

  const { user } = useAuth();
  const [showCreateForm, setShowCreateForm] = useState(false);
  const [isUpdating, setIsUpdating] = useState(false);
  const { toast } = useToast();
  
  const [newChallenge, setNewChallenge] = useState({
    challenge_name: "",
    start_date: new Date(),
    end_date: null as Date | null,
    target_profit: "",
    max_daily_loss: "",
    max_overall_loss: "",
    min_trading_days: "10",
    max_lot_size: "",
    account_size: "",
    custom_account_size: "",
    max_margin_usage: "30",
    consistency_target: "85",
    enable_consistency: true,
    unlimited_time: true,
  });

  const createChallenge = async () => {
    if (!user) return;

    try {
      const payload: any = {
        user_id: user.id,
        challenge_name: newChallenge.challenge_name,
        start_date: format(newChallenge.start_date, "yyyy-MM-dd"),
        target_profit: newChallenge.target_profit ? parseFloat(newChallenge.target_profit) : null,
        max_daily_loss: parseFloat(newChallenge.max_daily_loss),
        max_overall_loss: parseFloat(newChallenge.max_overall_loss),
        min_trading_days: parseInt(newChallenge.min_trading_days),
        max_lot_size: newChallenge.max_lot_size ? parseFloat(newChallenge.max_lot_size) : null,
      };

      // Only include end_date if not unlimited
      if (!newChallenge.unlimited_time && newChallenge.end_date) {
        payload.end_date = format(newChallenge.end_date, "yyyy-MM-dd");
      }

      const { error } = await supabase
        .from("prop_challenges")
        .insert(payload);

      if (error) throw error;

      toast({
        title: "Challenge Created",
        description: "Your prop firm challenge has been set up successfully.",
      });

      setShowCreateForm(false);
      setNewChallenge({
        challenge_name: "",
        start_date: new Date(),
        end_date: null,
        target_profit: "",
        max_daily_loss: "",
        max_overall_loss: "",
        min_trading_days: "10",
        max_lot_size: "",
        account_size: "",
        custom_account_size: "",
        max_margin_usage: "30",
        consistency_target: "85",
        enable_consistency: true,
        unlimited_time: true,
      });
      refetchChallenges();
    } catch (error: any) {
      toast({
        variant: "destructive",
        title: "Error creating challenge",
        description: error.message,
      });
    }
  };

  const updateChallengeStatus = async () => {
    if (isUpdating) return;
    
    setIsUpdating(true);
    try {
      await updateChallengeFromTrades();
      toast({
        title: "Challenge Updated ⚡",
        description: "Challenge status updated with latest trades in real-time",
      });
    } catch (error: any) {
      toast({
        variant: "destructive",
        title: "Update failed",
        description: error.message,
      });
    } finally {
      setIsUpdating(false);
    }
  };

  const generateReport = () => {
    const challenge = challenges.find(c => c.id === selectedChallenge);
    if (!challenge) return;

    // Generate PDF report (placeholder)
    toast({
      title: "Report Generated",
      description: "Your prop firm readiness report is being prepared.",
    });
  };

  const currentChallenge = challenges.find(c => c.id === selectedChallenge);
  const daysRemaining = currentChallenge && currentChallenge.end_date ? 
    Math.max(0, Math.ceil((new Date(currentChallenge.end_date).getTime() - new Date().getTime()) / (1000 * 60 * 60 * 24))) : null;

  return (
    <div className="space-y-6">
      {/* Challenge Selection - Moved to Top */}
      <Card className="glass-card border-card-border">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Target className="w-5 h-5 text-primary" />
            Select Active Challenge
            <Badge variant="outline" className="ml-2 text-xs">
              <Zap className="w-3 h-3 mr-1" />
              Real-time
            </Badge>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex items-center gap-4">
            <div className="flex-1">
              <select 
                value={selectedChallenge}
                onChange={(e) => setSelectedChallenge(e.target.value)}
                className="w-full px-4 py-3 border rounded-lg bg-background text-base font-medium hover:border-primary/50 focus:border-primary transition-colors"
              >
                <option value="">Choose your active challenge...</option>
                {challenges.map(challenge => (
                  <option key={challenge.id} value={challenge.id}>
                    {challenge.challenge_name} - {challenge.status?.toUpperCase() || 'UNKNOWN'}
                  </option>
                ))}
              </select>
            </div>
            <Button 
              variant="outline" 
              size="sm" 
              onClick={updateChallengeStatus}
              disabled={isUpdating}
              className="hover:bg-primary hover:text-primary-foreground transition-colors"
            >
              <RefreshCw className={`w-4 h-4 mr-2 ${isUpdating ? 'animate-spin' : ''}`} />
              {isUpdating ? 'Syncing...' : 'Sync'}
            </Button>
            <Button variant="outline" onClick={generateReport} className="hover:bg-info hover:text-info-foreground transition-colors">
              <Download className="w-4 h-4 mr-2" />
              Report
            </Button>
            <Button onClick={() => {
              setShowCreateForm(true)
              setTimeout(() => {
                const formElement = document.getElementById('challenge-form')
                if (formElement) {
                  formElement.scrollIntoView({ behavior: 'smooth', block: 'start' })
                }
              }, 100)
            }} className="bg-primary hover:bg-primary-dark transition-colors">
              <Plus className="w-4 h-4 mr-2" />
              New Challenge
            </Button>
            
            {/* Challenge Actions Dropdown */}
            {selectedChallenge && (
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="outline" size="sm">
                    <MoreVertical className="w-4 h-4" />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end" className="w-48">
                  <DropdownMenuItem onClick={generateReport}>
                    <Download className="w-4 h-4 mr-2" />
                    Export Report
                  </DropdownMenuItem>
                  <DropdownMenuSeparator />
                  <AlertDialog>
                    <AlertDialogTrigger asChild>
                      <DropdownMenuItem onSelect={(e) => e.preventDefault()} className="text-danger focus:text-danger">
                        <Trash2 className="w-4 h-4 mr-2" />
                        Delete Challenge
                      </DropdownMenuItem>
                    </AlertDialogTrigger>
                    <AlertDialogContent>
                      <AlertDialogHeader>
                        <AlertDialogTitle>Delete Challenge</AlertDialogTitle>
                        <AlertDialogDescription>
                          Are you sure you want to delete this challenge? This will permanently remove the challenge and all associated daily results. This action cannot be undone.
                        </AlertDialogDescription>
                      </AlertDialogHeader>
                      <AlertDialogFooter>
                        <AlertDialogCancel>Cancel</AlertDialogCancel>
                        <AlertDialogAction
                          className="bg-danger hover:bg-danger/90"
                          onClick={() => deleteChallenge(selectedChallenge)}
                        >
                          Delete Challenge
                        </AlertDialogAction>
                      </AlertDialogFooter>
                    </AlertDialogContent>
                  </AlertDialog>
                </DropdownMenuContent>
              </DropdownMenu>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Info Section - Moved below Challenge Selection */}
      <Card className="glass-card border-card-border">
        <CardContent className="p-4">
          <div className="p-4 bg-blue-50 dark:bg-blue-950/20 rounded-lg border border-blue-200 dark:border-blue-800">
            <h4 className="font-medium text-blue-900 dark:text-blue-100 mb-2 flex items-center gap-2">
              <Activity className="w-4 h-4" />
              Real-time Prop Challenge Tracking
            </h4>
            <div className="text-sm text-blue-800 dark:text-blue-200 space-y-1">
              <p>• <strong>Auto-sync</strong>: Trades update challenges instantly when added/edited</p>
              <p>• <strong>Margin Usage</strong>: Real-time calculation of margin utilization vs account size</p>
              <p>• <strong>Consistency Score</strong>: Daily performance consistency tracking for prop firm evaluation</p>
              <p>• <strong>Rule Compliance</strong>: Live monitoring of daily loss, lot size, and trading day violations</p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Challenge Overview with Real-time Updates */}
      {currentChallenge && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <Card className="glass-card border-card-border relative overflow-hidden">
            <div className="absolute top-2 right-2">
              <div className="h-2 w-2 bg-green-500 rounded-full animate-pulse"></div>
            </div>
            <CardContent className="p-6">
              <div className="flex items-center gap-2 mb-2">
                <Timer className="w-4 h-4 text-primary" />
                <span className="text-sm text-muted-foreground">
                  {daysRemaining !== null ? "Days Remaining" : "Time Limit"}
                </span>
              </div>
              <div className="text-3xl font-bold">
                {daysRemaining !== null ? daysRemaining : "∞"}
              </div>
              <div className="text-sm text-muted-foreground">
                {daysRemaining !== null ? "days left" : "Unlimited Time"}
              </div>
              <Badge variant={currentChallenge.status === 'active' ? 'default' : 
                            currentChallenge.status === 'passed' ? 'secondary' : 'destructive'}>
                {currentChallenge.status?.toUpperCase() || 'UNKNOWN'}
              </Badge>
            </CardContent>
          </Card>

          <Card className="glass-card border-card-border relative overflow-hidden">
            <div className="absolute top-2 right-2">
              <div className="h-2 w-2 bg-green-500 rounded-full animate-pulse"></div>
            </div>
            <CardContent className="p-6">
              <div className="flex items-center gap-2 mb-2">
                <DollarSign className="w-4 h-4 text-primary" />
                <span className="text-sm text-muted-foreground">Current Profit</span>
              </div>
              <div className={`text-3xl font-bold ${currentChallenge.current_profit >= 0 ? 'text-success' : 'text-danger'}`}>
                ${currentChallenge.current_profit.toFixed(2)}
              </div>
              {currentChallenge.target_profit && (
                <div className="text-sm text-muted-foreground">
                  Target: ${currentChallenge.target_profit.toFixed(2)}
                </div>
              )}
            </CardContent>
          </Card>

          <Card className="glass-card border-card-border relative overflow-hidden">
            <div className="absolute top-2 right-2">
              <div className={`h-2 w-2 rounded-full animate-pulse ${
                Math.abs(currentChallenge.current_daily_loss) > currentChallenge.max_daily_loss * 0.8 
                ? 'bg-red-500' : 'bg-green-500'
              }`}></div>
            </div>
            <CardContent className="p-6">
              <div className="flex items-center gap-2 mb-2">
                <AlertTriangle className="w-4 h-4 text-warning" />
                <span className="text-sm text-muted-foreground">Daily Loss Limit</span>
              </div>
              <div className="text-3xl font-bold text-warning">
                ${currentChallenge.max_daily_loss.toFixed(2)}
              </div>
              <div className={`text-sm ${
                Math.abs(currentChallenge.current_daily_loss) > currentChallenge.max_daily_loss * 0.8 
                ? 'text-red-600 font-semibold' : 'text-muted-foreground'
              }`}>
                Current: ${Math.abs(currentChallenge.current_daily_loss).toFixed(2)}
              </div>
            </CardContent>
          </Card>

          <Card className="glass-card border-card-border relative overflow-hidden">
            <div className="absolute top-2 right-2">
              <div className={`h-2 w-2 rounded-full animate-pulse ${
                currentChallenge.trading_days_count >= currentChallenge.min_trading_days 
                ? 'bg-green-500' : 'bg-yellow-500'
              }`}></div>
            </div>
            <CardContent className="p-6">
              <div className="flex items-center gap-2 mb-2">
                <CalendarIcon className="w-4 h-4 text-info" />
                <span className="text-sm text-muted-foreground">Trading Days</span>
              </div>
              <div className="text-3xl font-bold text-info">
                {currentChallenge.trading_days_count}
              </div>
              <div className="text-sm text-muted-foreground">
                Required: {currentChallenge.min_trading_days}
              </div>
            </CardContent>
          </Card>
        </div>
      )}

      {/* Progress Bars */}
      {currentChallenge && (
        <Card className="glass-card border-card-border">
          <CardHeader>
            <CardTitle>Challenge Progress</CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            {currentChallenge.target_profit && (
              <div className="space-y-2">
                <div className="flex justify-between">
                  <span>Profit Target</span>
                  <span>${currentChallenge.current_profit.toFixed(2)} / ${currentChallenge.target_profit.toFixed(2)}</span>
                </div>
                <Progress 
                  value={Math.max(0, Math.min(100, (currentChallenge.current_profit / currentChallenge.target_profit) * 100))} 
                />
              </div>
            )}
            
            <div className="space-y-2">
              <div className="flex justify-between">
                <span>Trading Days</span>
                <span>{currentChallenge.trading_days_count} / {currentChallenge.min_trading_days}</span>
              </div>
              <Progress 
                value={(currentChallenge.trading_days_count / currentChallenge.min_trading_days) * 100} 
              />
            </div>

            {daysRemaining !== null && (
              <div className="space-y-2">
                <div className="flex justify-between">
                  <span>Time Remaining</span>
                  <span>{daysRemaining} days</span>
                </div>
                <Progress 
                  value={Math.max(0, 100 - (daysRemaining / 30) * 100)} 
                />
              </div>
            )}
          </CardContent>
        </Card>
      )}

      {/* Daily Results */}
      {dailyResults.length > 0 && (
        <Card className="glass-card border-card-border">
          <CardHeader>
            <CardTitle>Daily Results</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {dailyResults.slice(0, 10).map(result => (
                <div key={result.id} className="flex items-center justify-between p-3 bg-muted/20 rounded-lg">
                  <div className="flex items-center gap-3">
                    {result.passed ? (
                      <CheckCircle className="w-5 h-5 text-success" />
                    ) : (
                      <XCircle className="w-5 h-5 text-danger" />
                    )}
                    <div>
                      <div className="font-semibold">{format(new Date(result.date), "MMM dd, yyyy")}</div>
                      {result.fail_reasons.length > 0 && (
                        <div className="text-sm text-danger">
                          {result.fail_reasons.join(", ")}
                        </div>
                      )}
                    </div>
                  </div>
                  <div className="text-right">
                    <div className={`font-semibold ${result.daily_pnl >= 0 ? 'text-success' : 'text-danger'}`}>
                      ${result.daily_pnl.toFixed(2)}
                    </div>
                    <div className="text-sm text-muted-foreground">
                      {result.trades_count} trades
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Create Challenge Form */}
      {showCreateForm && (
        <Card id="challenge-form" className="glass-card border-card-border">
          <CardHeader>
            <CardTitle>Create New Challenge</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Label htmlFor="challenge-name">Challenge Name</Label>
                <Input
                  id="challenge-name"
                  value={newChallenge.challenge_name}
                  onChange={(e) => setNewChallenge(prev => ({ ...prev, challenge_name: e.target.value }))}
                  placeholder="e.g., FTMO $100K Challenge"
                />
              </div>

              <div>
                <Label htmlFor="account-size">Account Size</Label>
                <select
                  id="account-size"
                  value={newChallenge.account_size}
                  onChange={(e) => setNewChallenge(prev => ({ ...prev, account_size: e.target.value }))}
                  className="w-full px-3 py-2 border rounded-md bg-background"
                >
                  <option value="">Select account size...</option>
                  <option value="5000">$5,000</option>
                  <option value="10000">$10,000</option>
                  <option value="25000">$25,000</option>
                  <option value="50000">$50,000</option>
                  <option value="100000">$100,000</option>
                  <option value="200000">$200,000</option>
                  <option value="400000">$400,000</option>
                  <option value="custom">Custom Amount</option>
                </select>
              </div>

              {newChallenge.account_size === "custom" && (
                <div>
                  <Label htmlFor="custom-account-size">Custom Account Size ($)</Label>
                  <Input
                    id="custom-account-size"
                    type="number"
                    value={newChallenge.custom_account_size || ""}
                    onChange={(e) => setNewChallenge(prev => ({ ...prev, custom_account_size: e.target.value }))}
                    placeholder="Enter custom amount"
                  />
                </div>
              )}

              <div>
                <Label htmlFor="target-profit">Target Profit ($)</Label>
                <Input
                  id="target-profit"
                  type="number"
                  value={newChallenge.target_profit}
                  onChange={(e) => setNewChallenge(prev => ({ ...prev, target_profit: e.target.value }))}
                  placeholder="10000"
                />
              </div>

              <div>
                <Label htmlFor="max-daily-loss">Max Daily Loss ($)</Label>
                <Input
                  id="max-daily-loss"
                  type="number"
                  value={newChallenge.max_daily_loss}
                  onChange={(e) => setNewChallenge(prev => ({ ...prev, max_daily_loss: e.target.value }))}
                  placeholder="5000"
                  required
                />
              </div>

              <div>
                <Label htmlFor="max-overall-loss">Max Overall Loss ($)</Label>
                <Input
                  id="max-overall-loss"
                  type="number"
                  value={newChallenge.max_overall_loss}
                  onChange={(e) => setNewChallenge(prev => ({ ...prev, max_overall_loss: e.target.value }))}
                  placeholder="10000"
                  required
                />
              </div>

              <div>
                <Label htmlFor="min-trading-days">Min Trading Days</Label>
                <Input
                  id="min-trading-days"
                  type="number"
                  value={newChallenge.min_trading_days}
                  onChange={(e) => setNewChallenge(prev => ({ ...prev, min_trading_days: e.target.value }))}
                  placeholder="10"
                />
              </div>

              <div>
                <Label htmlFor="max-lot-size">Max Lot Size (optional)</Label>
                <Input
                  id="max-lot-size"
                  type="number"
                  step="0.01"
                  value={newChallenge.max_lot_size}
                  onChange={(e) => setNewChallenge(prev => ({ ...prev, max_lot_size: e.target.value }))}
                  placeholder="2.0"
                />
              </div>

              <div>
                <Label htmlFor="max-margin-usage">Max Margin Usage (%)</Label>
                <Input
                  id="max-margin-usage"
                  type="number"
                  min="1"
                  max="100"
                  value={newChallenge.max_margin_usage}
                  onChange={(e) => setNewChallenge(prev => ({ ...prev, max_margin_usage: e.target.value }))}
                  placeholder="30"
                />
                <div className="text-xs text-muted-foreground mt-1">
                  Maximum margin usage allowed (typically 20-50%)
                </div>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="flex items-center space-x-2">
                <input
                  type="checkbox"
                  id="enable-consistency"
                  checked={newChallenge.enable_consistency}
                  onChange={(e) => setNewChallenge(prev => ({ ...prev, enable_consistency: e.target.checked }))}
                  className="rounded"
                />
                <Label htmlFor="enable-consistency">Enable Consistency Score</Label>
              </div>

              {newChallenge.enable_consistency && (
                <div>
                  <Label htmlFor="consistency-target">Consistency Target (%)</Label>
                  <Input
                    id="consistency-target"
                    type="number"
                    min="50"
                    max="100"
                    value={newChallenge.consistency_target}
                    onChange={(e) => setNewChallenge(prev => ({ ...prev, consistency_target: e.target.value }))}
                    placeholder="85"
                  />
                  <div className="text-xs text-muted-foreground mt-1">
                    Minimum daily consistency score required (50-100%)
                  </div>
                </div>
              )}
            </div>

            <div className="space-y-4">
              <div className="flex items-center space-x-3">
                <input
                  type="checkbox"
                  id="unlimited-time"
                  checked={newChallenge.unlimited_time}
                  onChange={(e) => setNewChallenge(prev => ({ 
                    ...prev, 
                    unlimited_time: e.target.checked,
                    end_date: e.target.checked ? null : new Date()
                  }))}
                  className="rounded"
                />
                <Label htmlFor="unlimited-time" className="text-sm font-medium">
                  Unlimited Time Challenge (Most Common)
                </Label>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label>Start Date</Label>
                <Popover>
                  <PopoverTrigger asChild>
                    <Button
                      variant="outline"
                      className={cn(
                        "w-full justify-start text-left font-normal",
                        !newChallenge.start_date && "text-muted-foreground"
                      )}
                    >
                      <CalendarIcon className="mr-2 h-4 w-4" />
                      {newChallenge.start_date ? format(newChallenge.start_date, "PPP") : <span>Pick a date</span>}
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className="w-auto p-0">
                    <Calendar
                      mode="single"
                      selected={newChallenge.start_date}
                      onSelect={(date) => date && setNewChallenge(prev => ({ ...prev, start_date: date }))}
                      initialFocus
                      className="pointer-events-auto"
                    />
                  </PopoverContent>
                </Popover>
                </div>

                {!newChallenge.unlimited_time && (
                  <div>
                    <Label>End Date (Optional)</Label>
                    <Popover>
                      <PopoverTrigger asChild>
                        <Button
                          variant="outline"
                          className={cn(
                            "w-full justify-start text-left font-normal",
                            !newChallenge.end_date && "text-muted-foreground"
                          )}
                        >
                          <CalendarIcon className="mr-2 h-4 w-4" />
                          {newChallenge.end_date ? format(newChallenge.end_date, "PPP") : <span>Pick end date</span>}
                        </Button>
                      </PopoverTrigger>
                      <PopoverContent className="w-auto p-0">
                        <Calendar
                          mode="single"
                          selected={newChallenge.end_date}
                          onSelect={(date) => setNewChallenge(prev => ({ ...prev, end_date: date }))}
                          initialFocus
                          className="pointer-events-auto"
                        />
                      </PopoverContent>
                    </Popover>
                     <div className="text-xs text-muted-foreground mt-1">
                       Leave empty for unlimited time challenge
                     </div>
                   </div>
                 )}
               </div>
            </div>

            <div className="flex justify-end gap-2">
              <Button variant="outline" onClick={() => setShowCreateForm(false)}>
                Cancel
              </Button>
              <Button onClick={createChallenge}>
                Create Challenge
              </Button>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}