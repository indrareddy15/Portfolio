import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Menu, X, BarChart3, BookOpen, Settings, LogOut, User, Crown, Home, Brain, Beaker, Sparkles, Upload } from "lucide-react";
import { useAuth } from "@/hooks/useAuth";
import { useSystemSettings } from "@/hooks/useSystemSettings";
import { useLogoSettings } from "@/hooks/useLogoSettings";
import { Link, useNavigate } from "react-router-dom";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Badge } from "@/components/ui/badge";
import { ThemeToggle } from "@/components/ThemeToggle";

export const Navigation = () => {
  const [isOpen, setIsOpen] = useState(false);
  const { user, signOut, subscriptionData } = useAuth();
  const { getMainLogo } = useLogoSettings();
  const { isAffiliateEnabled } = useSystemSettings();
  const navigate = useNavigate();
  
  const mainLogo = getMainLogo();

  return (
    <nav className="fixed top-0 left-0 right-0 z-50 glass-card border-b border-card-border backdrop-blur-xl">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo & Brand */}
          <Link to="/" className="flex items-center gap-3 hover:opacity-80 transition-opacity">
            {mainLogo ? (
              <img 
                src={mainLogo.logo_url} 
                alt={mainLogo.logo_alt} 
                loading="lazy"
                className="h-8 w-auto"
                style={{
                  maxWidth: mainLogo.width ? `${mainLogo.width}px` : 'auto',
                  maxHeight: mainLogo.height ? `${mainLogo.height}px` : '32px'
                }}
              />
            ) : (
              <img 
                src="/lovable-uploads/6c66d095-1b1a-4b06-860b-9f973847053f.png" 
                alt="Pip Trackr.com Logo" 
                loading="lazy"
                className="h-8 w-auto"
              />
            )}
            <span className="font-poppins font-bold text-xl text-foreground hidden sm:block">
              Pip Trackr.com
            </span>
          </Link>

          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center space-x-8">
            {user ? (
              /* Authenticated User Navigation */
              <>
                <Link
                  to="/"
                  className="text-muted-foreground hover:text-foreground transition-colors flex items-center gap-2"
                >
                  <Home className="w-4 h-4" />
                  Home
                </Link>
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button variant="ghost" className="text-muted-foreground hover:text-foreground">
                      <BarChart3 className="w-4 h-4 mr-2" />
                      Dashboard
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="center">
                    <DropdownMenuItem onClick={() => navigate('/app/')}>
                      <BarChart3 className="w-4 h-4 mr-2" />
                      Overview
                    </DropdownMenuItem>
                    <DropdownMenuItem onClick={() => navigate('/app/journal')}>
                      <BookOpen className="w-4 h-4 mr-2" />
                      Journal
                    </DropdownMenuItem>
                    <DropdownMenuItem onClick={() => navigate('/app/analytics')}>
                      <BarChart3 className="w-4 h-4 mr-2" />
                      Analytics
                    </DropdownMenuItem>
                    <DropdownMenuItem onClick={() => navigate('/app/psychology')}>
                      <Brain className="w-4 h-4 mr-2" />
                      Psychology
                    </DropdownMenuItem>
                    <DropdownMenuItem onClick={() => navigate('/app/strategy')}>
                      <Beaker className="w-4 h-4 mr-2" />
                      Strategy
                    </DropdownMenuItem>
                    <DropdownMenuItem onClick={() => navigate('/app/ai')}>
                      <Sparkles className="w-4 h-4 mr-2" />
                      AI Coach
                    </DropdownMenuItem>
                    <DropdownMenuItem onClick={() => navigate('/app/imports')}>
                      <Upload className="w-4 h-4 mr-2" />
                      Imports
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
                <Link
                  to="/blog"
                  className="text-muted-foreground hover:text-foreground transition-colors"
                >
                  Blog
                </Link>
              </>
            ) : (
              /* Non-Authenticated User Navigation */
              <>
                <Link
                  to="/"
                  className="text-muted-foreground hover:text-foreground transition-colors flex items-center gap-2"
                >
                  <Home className="w-4 h-4" />
                  Home
                </Link>
                <a
                  href="#features"
                  className="text-muted-foreground hover:text-foreground transition-colors"
                >
                  Features
                </a>
                <a
                  href="#pricing"
                  className="text-muted-foreground hover:text-foreground transition-colors"
                >
                  Pricing
                </a>
                <a
                  href="#integrations"
                  className="text-muted-foreground hover:text-foreground transition-colors"
                >
                  Integrations
                </a>
                <Link
                  to="/blog"
                  className="text-muted-foreground hover:text-foreground transition-colors"
                >
                  Blog
                </Link>
              </>
            )}
          </div>

          {/* Auth Buttons */}
          <div className="hidden md:flex items-center space-x-4">
            <ThemeToggle />
            {user ? (
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="ghost" className="flex items-center space-x-2">
                    <User className="w-4 h-4" />
                    <span>{user.email}</span>
                    {subscriptionData?.subscribed && (
                      <Badge variant="secondary" className="ml-2">
                        {subscriptionData.subscription_tier}
                      </Badge>
                    )}
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end">
                  <DropdownMenuLabel>My Account</DropdownMenuLabel>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem onClick={() => navigate('/app/')}>
                    <BarChart3 className="w-4 h-4 mr-2" />
                    Dashboard
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={() => navigate('/subscription')}>
                    <Crown className="w-4 h-4 mr-2" />
                    Subscription
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={() => navigate('/app/settings')}>
                    <Settings className="w-4 h-4 mr-2" />
                    Settings
                  </DropdownMenuItem>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem onClick={signOut}>
                    <LogOut className="w-4 h-4 mr-2" />
                    Sign Out
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            ) : (
              <>
                <Button variant="ghost" asChild>
                  <Link to="/auth">Sign In</Link>
                </Button>
                <Button 
                  variant="primary" 
                  className="glow-hover"
                  asChild
                >
                  <Link to="/auth">Get Started</Link>
                </Button>
              </>
            )}
          </div>

          {/* Mobile Menu Button */}
          <button
            className="md:hidden p-2"
            onClick={() => setIsOpen(!isOpen)}
          >
            {isOpen ? (
              <X className="w-6 h-6 text-foreground" />
            ) : (
              <Menu className="w-6 h-6 text-foreground" />
            )}
          </button>
        </div>

        {/* Mobile Navigation */}
        {isOpen && (
          <div className="md:hidden py-4 space-y-4">
            {user ? (
              /* Authenticated User Mobile Navigation */
              <>
                <Link
                  to="/"
                  className="block text-muted-foreground hover:text-foreground transition-colors flex items-center gap-2"
                  onClick={() => setIsOpen(false)}
                >
                  <Home className="w-4 h-4" />
                  Home
                </Link>
                <Button variant="ghost" className="w-full justify-start" onClick={() => { navigate('/app/'); setIsOpen(false); }}>
                  <BarChart3 className="w-4 h-4 mr-2" />
                  Dashboard
                </Button>
                <Button variant="ghost" className="w-full justify-start" onClick={() => { navigate('/app/journal'); setIsOpen(false); }}>
                  <BookOpen className="w-4 h-4 mr-2" />
                  Journal
                </Button>
                <Button variant="ghost" className="w-full justify-start" onClick={() => { navigate('/app/analytics'); setIsOpen(false); }}>
                  <BarChart3 className="w-4 h-4 mr-2" />
                  Analytics
                </Button>
                <Button variant="ghost" className="w-full justify-start" onClick={() => { navigate('/app/psychology'); setIsOpen(false); }}>
                  <Brain className="w-4 h-4 mr-2" />
                  Psychology
                </Button>
                <Button variant="ghost" className="w-full justify-start" onClick={() => { navigate('/app/strategy'); setIsOpen(false); }}>
                  <Beaker className="w-4 h-4 mr-2" />
                  Strategy
                </Button>
                <Button variant="ghost" className="w-full justify-start" onClick={() => { navigate('/app/ai'); setIsOpen(false); }}>
                  <Sparkles className="w-4 h-4 mr-2" />
                  AI Coach
                </Button>
                <Link
                  to="/blog"
                  className="block text-muted-foreground hover:text-foreground transition-colors"
                  onClick={() => setIsOpen(false)}
                >
                  Blog
                </Link>
              </>
            ) : (
              /* Non-Authenticated User Mobile Navigation */
              <>
                <Link
                  to="/"
                  className="block text-muted-foreground hover:text-foreground transition-colors flex items-center gap-2"
                  onClick={() => setIsOpen(false)}
                >
                  <Home className="w-4 h-4" />
                  Home
                </Link>
                <a
                  href="#features"
                  className="block text-muted-foreground hover:text-foreground transition-colors"
                  onClick={() => setIsOpen(false)}
                >
                  Features
                </a>
                <a
                  href="#pricing"
                  className="block text-muted-foreground hover:text-foreground transition-colors"
                  onClick={() => setIsOpen(false)}
                >
                  Pricing
                </a>
                <a
                  href="#integrations"
                  className="block text-muted-foreground hover:text-foreground transition-colors"
                  onClick={() => setIsOpen(false)}
                >
                  Integrations
                </a>
                <Link
                  to="/blog"
                  className="block text-muted-foreground hover:text-foreground transition-colors"
                  onClick={() => setIsOpen(false)}
                >
                  Blog
                </Link>
              </>
            )}
            <div className="flex flex-col space-y-2 pt-4 border-t border-card-border">
              <div className="flex justify-center pb-2">
                <ThemeToggle />
              </div>
              {user ? (
                <>
                  <Button variant="ghost" className="w-full justify-start" onClick={() => { navigate('/subscription'); setIsOpen(false); }}>
                    <Crown className="w-4 h-4 mr-2" />
                    Subscription
                  </Button>
                  <Button variant="ghost" className="w-full justify-start" onClick={() => { navigate('/app/settings'); setIsOpen(false); }}>
                    <Settings className="w-4 h-4 mr-2" />
                    Settings
                  </Button>
                  <Button variant="ghost" className="w-full justify-start" onClick={signOut}>
                    <LogOut className="w-4 h-4 mr-2" />
                    Sign Out
                  </Button>
                </>
              ) : (
                <>
                  <Button variant="ghost" className="w-full justify-start" asChild>
                    <Link to="/auth">Sign In</Link>
                  </Button>
                  <Button 
                    variant="primary" 
                    className="w-full"
                    asChild
                  >
                    <Link to="/auth">Get Started</Link>
                  </Button>
                </>
              )}
            </div>
          </div>
        )}
      </div>
    </nav>
  );
};