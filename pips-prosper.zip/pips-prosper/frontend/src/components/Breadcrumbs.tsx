import { useLocation, Link } from "react-router-dom"
import { ChevronRight, Home } from "lucide-react"
import {
  Breadcrumb,
  BreadcrumbEllipsis,
  BreadcrumbItem,
  BreadcrumbLink,
  BreadcrumbList,
  BreadcrumbPage,
  BreadcrumbSeparator,
} from "@/components/ui/breadcrumb"

// Route mapping for breadcrumb titles
const routeMap: Record<string, string> = {
  app: "Dashboard",
  journal: "Journal",
  imports: "Imports",
  analytics: "Analytics",
  overview: "Overview",
  instruments: "Instruments", 
  sessions: "Sessions",
  calendar: "Calendar",
  risk: "Risk",
  mistakes: "Mistakes",
  strategy: "Strategy",
  "goals-rules": "Goals",
  psychology: "Psychology",
  ai: "AI Coach",
  prop: "Prop Metrics", 
  templates: "Templates",
  leaderboards: "Leaderboards",
  export: "Export",
  settings: "Settings",
  profile: "Profile",
  accounts: "Accounts",
  integrations: "Integrations",
  goals: "Goals",
  billing: "Billing",
  data: "Data",
}

export function Breadcrumbs() {
  const location = useLocation()
  const pathSegments = location.pathname.split('/').filter(Boolean)
  
  // Don't show breadcrumbs on main dashboard
  if (pathSegments.length <= 1 || location.pathname === '/app') {
    return null
  }

  // Generate breadcrumb items from path segments
  const breadcrumbItems = pathSegments.map((segment, index) => {
    const path = '/' + pathSegments.slice(0, index + 1).join('/')
    const title = routeMap[segment] || segment
    
    return {
      title,
      path,
      isLast: index === pathSegments.length - 1
    }
  })

  return (
    <div className="border-b border-border bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60 sticky top-16 z-30">
      <div className="container mx-auto px-4 py-3">
        <Breadcrumb>
          <BreadcrumbList>
            <BreadcrumbItem>
              <BreadcrumbLink asChild>
                <Link to="/app" className="flex items-center gap-1 hover:text-primary transition-colors">
                  <Home className="h-3 w-3" />
                  Dashboard
                </Link>
              </BreadcrumbLink>
            </BreadcrumbItem>
            
            {breadcrumbItems.slice(1).map((item, index) => (
              <div key={item.path} className="flex items-center">
                <BreadcrumbSeparator>
                  <ChevronRight className="h-4 w-4" />
                </BreadcrumbSeparator>
                <BreadcrumbItem>
                  {item.isLast ? (
                    <BreadcrumbPage className="font-medium text-foreground">
                      {item.title}
                    </BreadcrumbPage>
                  ) : (
                    <BreadcrumbLink asChild>
                      <Link 
                        to={item.path} 
                        className="hover:text-primary transition-colors"
                      >
                        {item.title}
                      </Link>
                    </BreadcrumbLink>
                  )}
                </BreadcrumbItem>
              </div>
            ))}
          </BreadcrumbList>
        </Breadcrumb>
      </div>
    </div>
  )
}