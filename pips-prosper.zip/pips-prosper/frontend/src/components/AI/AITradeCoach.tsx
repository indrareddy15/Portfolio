import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import { 
  Brain, 
  TrendingUp, 
  AlertTriangle, 
  Lightbulb,
  CheckCircle,
  RefreshCw,
  MessageSquare,
  Target
} from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";

interface AIInsight {
  id: string;
  insight_type: string;
  title: string;
  content: string;
  metadata: any;
  is_read: boolean;
  created_at: string;
}

const INSIGHT_TYPES = {
  daily: { icon: <Brain className="w-4 h-4" />, color: "bg-primary", label: "Daily Insight" },
  pattern: { icon: <TrendingUp className="w-4 h-4" />, color: "bg-success", label: "Pattern Analysis" },
  warning: { icon: <AlertTriangle className="w-4 h-4" />, color: "bg-warning", label: "Risk Warning" },
  recommendation: { icon: <Lightbulb className="w-4 h-4" />, color: "bg-info", label: "Recommendation" },
};

export function AITradeCoach() {
  const [insights, setInsights] = useState<AIInsight[]>([]);
  const [isGenerating, setIsGenerating] = useState(false);
  const [improvementPlan, setImprovementPlan] = useState<string[]>([]);
  const [customPrompt, setCustomPrompt] = useState("");
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  
  const { user } = useAuth();
  const { toast } = useToast();

  useEffect(() => {
    if (user) {
      loadInsights();
      generateDailyInsight();
    }
  }, [user]);

  const loadInsights = async () => {
    if (!user) return;

    try {
      const { data, error } = await supabase
        .from("ai_insights")
        .select("*")
        .eq("user_id", user.id)
        .order("created_at", { ascending: false })
        .limit(10);

      if (error) throw error;
      setInsights(data || []);
    } catch (error: any) {
      toast({
        variant: "destructive",
        title: "Error loading insights",
        description: error.message,
      });
    }
  };

  const generateDailyInsight = async () => {
    if (!user || isGenerating) return;

    // Check if we already have a daily insight for today
    const today = new Date().toDateString();
    const hasToday = insights.some(insight => 
      insight.insight_type === 'daily' && 
      new Date(insight.created_at).toDateString() === today
    );

    if (hasToday) return;

    setIsGenerating(true);

    try {
      // Get user's recent trades for analysis
      const { data: trades } = await supabase
        .from("trades")
        .select("*")
        .eq("user_id", user.id)
        .order("opened_at", { ascending: false })
        .limit(50);

      if (!trades || trades.length === 0) {
        await createInsight(
          "daily",
          "Welcome to AI Trade Coach!",
          "Start recording your trades to receive personalized insights and recommendations. The AI will analyze your trading patterns and provide actionable feedback to improve your performance.",
          { suggestion: "Add your first trade to get started" }
        );
        setIsGenerating(false);
        loadInsights();
        return;
      }

      // Analyze patterns
      const insights = await analyzeTrading(trades);
      
      // Create AI insight
      await createInsight(
        "daily",
        insights.title,
        insights.content,
        insights.metadata
      );

      loadInsights();
    } catch (error: any) {
      toast({
        variant: "destructive",
        title: "Error generating insight",
        description: error.message,
      });
    } finally {
      setIsGenerating(false);
    }
  };

  const analyzeTrading = async (trades: any[]): Promise<{ title: string; content: string; metadata: any }> => {
    const completedTrades = trades.filter(t => t.pnl !== null);
    
    if (completedTrades.length === 0) {
      return {
        title: "Start Your Trading Journey",
        content: "Complete some trades to receive detailed AI analysis and insights.",
        metadata: { suggestion: "Focus on completing trades with proper risk management" }
      };
    }

    // Analyze win/loss patterns
    const wins = completedTrades.filter(t => (t.pnl || 0) > 0);
    const losses = completedTrades.filter(t => (t.pnl || 0) < 0);
    const winRate = wins.length / completedTrades.length;

    // Analyze by time/session
    const sessionAnalysis: { [key: string]: { wins: number; losses: number; pnl: number } } = {};
    completedTrades.forEach(trade => {
      const hour = new Date(trade.opened_at).getHours();
      let session = 'Other';
      
      if (hour >= 2 && hour < 5) session = 'Sydney';
      else if (hour >= 8 && hour < 12) session = 'London';
      else if (hour >= 13 && hour < 17) session = 'New York';
      else if (hour >= 20 && hour < 24) session = 'Asian';

      if (!sessionAnalysis[session]) {
        sessionAnalysis[session] = { wins: 0, losses: 0, pnl: 0 };
      }

      if ((trade.pnl || 0) > 0) sessionAnalysis[session].wins++;
      else if ((trade.pnl || 0) < 0) sessionAnalysis[session].losses++;
      sessionAnalysis[session].pnl += trade.pnl || 0;
    });

    // Find best and worst sessions
    const sessions = Object.entries(sessionAnalysis);
    const bestSession = sessions.reduce((best, current) => 
      current[1].pnl > best[1].pnl ? current : best
    );
    const worstSession = sessions.reduce((worst, current) => 
      current[1].pnl < worst[1].pnl ? current : worst
    );

    // Analyze instruments
    const instrumentAnalysis: { [key: string]: { wins: number; losses: number; pnl: number } } = {};
    completedTrades.forEach(trade => {
      if (!instrumentAnalysis[trade.instrument]) {
        instrumentAnalysis[trade.instrument] = { wins: 0, losses: 0, pnl: 0 };
      }
      
      if ((trade.pnl || 0) > 0) instrumentAnalysis[trade.instrument].wins++;
      else if ((trade.pnl || 0) < 0) instrumentAnalysis[trade.instrument].losses++;
      instrumentAnalysis[trade.instrument].pnl += trade.pnl || 0;
    });

    const worstInstrument = Object.entries(instrumentAnalysis)
      .reduce((worst, current) => current[1].pnl < worst[1].pnl ? current : worst);

    // Generate insights
    let title = "Daily Trading Analysis";
    let content = `Based on your recent ${completedTrades.length} trades:\n\n`;
    
    if (winRate < 0.4) {
      title = "⚠️ Low Win Rate Alert";
      content += `Your current win rate is ${(winRate * 100).toFixed(1)}%, which is below optimal levels. `;
      
      if (worstSession[1].pnl < -100) {
        content += `Consider avoiding trades during ${worstSession[0]} session - you've lost $${Math.abs(worstSession[1].pnl).toFixed(2)} during this time. `;
      }
      
      if (worstInstrument[1].pnl < -100) {
        content += `Also, consider reducing exposure to ${worstInstrument[0]} as it's been your worst performing instrument with $${Math.abs(worstInstrument[1].pnl).toFixed(2)} in losses.`;
      }
    } 
    else if (bestSession[1].pnl > 200) {
      title = "✨ Trading Strength Identified";
      content += `Excellent performance during ${bestSession[0]} session! You've made $${bestSession[1].pnl.toFixed(2)} with a ${((bestSession[1].wins / (bestSession[1].wins + bestSession[1].losses)) * 100).toFixed(1)}% win rate. Consider focusing more trades during this time window.`;
    }
    else {
      title = "📊 Performance Summary";
      content += `Your win rate is ${(winRate * 100).toFixed(1)}% - solid performance! `;
      
      if (bestSession[1].pnl > 0) {
        content += `Your strongest session is ${bestSession[0]} with $${bestSession[1].pnl.toFixed(2)} profit. `;
      }
    }

    return {
      title,
      content,
      metadata: {
        winRate: winRate * 100,
        bestSession: bestSession[0],
        worstSession: worstSession[0],
        totalTrades: completedTrades.length,
        analysis_type: "pattern_recognition"
      }
    };
  };

  const createInsight = async (type: string, title: string, content: string, metadata: any) => {
    if (!user) return;

    try {
      const { error } = await supabase
        .from("ai_insights")
        .insert({
          user_id: user.id,
          insight_type: type,
          title,
          content,
          metadata,
          is_read: false,
        });

      if (error) throw error;
    } catch (error: any) {
      throw error;
    }
  };

  const generateImprovementPlan = async () => {
    if (!user) return;

    setIsAnalyzing(true);

    try {
      // Get recent trades and performance data
      const { data: trades } = await supabase
        .from("trades")
        .select("*")
        .eq("user_id", user.id)
        .order("opened_at", { ascending: false })
        .limit(100);

      if (!trades || trades.length === 0) {
        setImprovementPlan([
          "Record at least 20 trades to get meaningful analysis",
          "Focus on consistent risk management (1-2% per trade)",
          "Document your trading psychology after each trade",
          "Set up a trading journal routine"
        ]);
        return;
      }

      const completedTrades = trades.filter(t => t.pnl !== null);
      const wins = completedTrades.filter(t => (t.pnl || 0) > 0);
      const losses = completedTrades.filter(t => (t.pnl || 0) < 0);
      const winRate = wins.length / completedTrades.length;
      
      const avgWin = wins.length > 0 ? wins.reduce((sum, t) => sum + (t.pnl || 0), 0) / wins.length : 0;
      const avgLoss = losses.length > 0 ? Math.abs(losses.reduce((sum, t) => sum + (t.pnl || 0), 0) / losses.length) : 0;
      const rrRatio = avgLoss > 0 ? avgWin / avgLoss : 0;

      const plan: string[] = [];

      // Win rate analysis
      if (winRate < 0.4) {
        plan.push("🎯 PRIORITY: Improve trade selection - aim for 45%+ win rate");
        plan.push("📚 Study price action and wait for better setups");
        plan.push("⏱️ Reduce trading frequency, focus on quality over quantity");
      } else if (winRate > 0.7) {
        plan.push("🚀 Excellent win rate! Consider increasing position sizes gradually");
      }

      // Risk-reward analysis
      if (rrRatio < 1.5) {
        plan.push("💰 Improve risk-reward ratio - aim for 1.5:1 minimum");
        plan.push("🛑 Set wider stop losses or tighter take profits");
        plan.push("📈 Let winners run longer before taking profits");
      }

      // Risk management
      const largeLosses = losses.filter(t => Math.abs(t.pnl || 0) > 100);
      if (largeLosses.length > 0) {
        plan.push("⚠️ Reduce position sizes - max 2% risk per trade");
        plan.push("🔒 Always use stop losses on every trade");
      }

      // Psychology
      const consecutiveLosses = getMaxConsecutiveLosses(completedTrades);
      if (consecutiveLosses > 3) {
        plan.push("🧠 Implement trading break after 3 consecutive losses");
        plan.push("📝 Journal emotions after each losing trade");
        plan.push("🎯 Practice meditation or stress management techniques");
      }

      // Consistency
      const tradingDays = new Set(trades.map(t => t.opened_at.split('T')[0])).size;
      if (tradingDays < 10) {
        plan.push("📅 Trade more consistently - aim for 15+ trading days per month");
        plan.push("⏰ Set a regular trading schedule");
      }

      // Add general best practices
      plan.push("📊 Review this analysis weekly to track improvement");
      plan.push("🎓 Continue education - read 1 trading book per month");

      setImprovementPlan(plan);

      // Save as insight
      await createInsight(
        "recommendation",
        "Personalized Improvement Plan Generated",
        `Based on analysis of ${completedTrades.length} trades, here's your custom improvement plan focusing on your specific weaknesses and strengths.`,
        { plan, generatedAt: new Date().toISOString() }
      );

      loadInsights();

    } catch (error: any) {
      toast({
        variant: "destructive",
        title: "Error generating plan",
        description: error.message,
      });
    } finally {
      setIsAnalyzing(false);
    }
  };

  const getMaxConsecutiveLosses = (trades: any[]): number => {
    let maxConsecutive = 0;
    let currentConsecutive = 0;

    trades.forEach(trade => {
      if ((trade.pnl || 0) < 0) {
        currentConsecutive++;
        maxConsecutive = Math.max(maxConsecutive, currentConsecutive);
      } else {
        currentConsecutive = 0;
      }
    });

    return maxConsecutive;
  };

  const markAsRead = async (insightId: string) => {
    try {
      const { error } = await supabase
        .from("ai_insights")
        .update({ is_read: true })
        .eq("id", insightId);

      if (error) throw error;
      
      setInsights(prev => prev.map(insight => 
        insight.id === insightId ? { ...insight, is_read: true } : insight
      ));
    } catch (error: any) {
      toast({
        variant: "destructive",
        title: "Error updating insight",
        description: error.message,
      });
    }
  };

  return (
    <div className="space-y-6">
      {/* AI Daily Insight Card */}
      <Card className="glass-card border-card-border">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Brain className="w-5 h-5 text-primary" />
            AI Daily Insight
          </CardTitle>
        </CardHeader>
        <CardContent>
          {insights.length > 0 && insights[0].insight_type === 'daily' ? (
            <div className="space-y-4">
              <div className="p-4 bg-primary/5 border border-primary/20 rounded-lg">
                <h3 className="font-semibold text-primary mb-2">{insights[0].title}</h3>
                <p className="text-sm text-muted-foreground whitespace-pre-line">
                  {insights[0].content}
                </p>
              </div>
              
              {!insights[0].is_read && (
                <Button 
                  variant="outline" 
                  size="sm"
                  onClick={() => markAsRead(insights[0].id)}
                >
                  <CheckCircle className="w-4 h-4 mr-2" />
                  Mark as Read
                </Button>
              )}
            </div>
          ) : (
            <div className="text-center py-8">
              <Button onClick={generateDailyInsight} disabled={isGenerating}>
                {isGenerating ? (
                  <>
                    <RefreshCw className="w-4 h-4 mr-2 animate-spin" />
                    Analyzing...
                  </>
                ) : (
                  <>
                    <Brain className="w-4 h-4 mr-2" />
                    Generate Daily Insight
                  </>
                )}
              </Button>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Improvement Plan Generator */}
      <Card className="glass-card border-card-border">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Target className="w-5 h-5 text-primary" />
            Personalized Improvement Plan
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <Button 
            onClick={generateImprovementPlan}
            disabled={isAnalyzing}
            className="w-full"
          >
            {isAnalyzing ? (
              <>
                <RefreshCw className="w-4 h-4 mr-2 animate-spin" />
                Analyzing Trading Patterns...
              </>
            ) : (
              <>
                <Lightbulb className="w-4 h-4 mr-2" />
                Generate Improvement Plan
              </>
            )}
          </Button>

          {improvementPlan.length > 0 && (
            <div className="space-y-3">
              <h3 className="font-semibold">Your Personalized Action Items:</h3>
              <div className="space-y-2">
                {improvementPlan.map((item, index) => (
                  <div key={index} className="flex items-start gap-3 p-3 bg-muted/20 rounded-lg">
                    <div className="flex-shrink-0 w-6 h-6 bg-primary/20 text-primary rounded-full flex items-center justify-center text-sm font-semibold">
                      {index + 1}
                    </div>
                    <span className="text-sm">{item}</span>
                  </div>
                ))}
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Recent Insights */}
      <Card className="glass-card border-card-border">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <MessageSquare className="w-5 h-5 text-primary" />
            Recent AI Insights
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {insights.length > 0 ? (
              <>
                {insights.map(insight => {
                  const config = INSIGHT_TYPES[insight.insight_type as keyof typeof INSIGHT_TYPES] || INSIGHT_TYPES.daily;
                  
                  return (
                    <div key={insight.id} className={`p-4 rounded-lg border ${insight.is_read ? 'bg-muted/10 border-muted/20' : 'bg-primary/5 border-primary/20'}`}>
                      <div className="flex items-start justify-between mb-2">
                        <div className="flex items-center gap-2">
                          <div className={`p-1 rounded-full text-white ${config.color}`}>
                            {config.icon}
                          </div>
                          <h3 className="font-semibold">{insight.title}</h3>
                        </div>
                        <div className="flex items-center gap-2">
                          <Badge variant="outline" className="text-xs">
                            {config.label}
                          </Badge>
                          {!insight.is_read && (
                            <div className="w-2 h-2 bg-primary rounded-full"></div>
                          )}
                        </div>
                      </div>
                      <p className="text-sm text-muted-foreground mb-2 whitespace-pre-line">
                        {insight.content}
                      </p>
                      <div className="flex items-center justify-between">
                        <span className="text-xs text-muted-foreground">
                          {new Date(insight.created_at).toLocaleDateString()}
                        </span>
                        {!insight.is_read && (
                          <Button 
                            variant="ghost" 
                            size="sm"
                            onClick={() => markAsRead(insight.id)}
                          >
                            Mark as Read
                          </Button>
                        )}
                      </div>
                    </div>
                  );
                })}
              </>
            ) : (
              <div className="text-center py-8 text-muted-foreground">
                <Brain className="w-12 h-12 mx-auto mb-4 opacity-50" />
                <p>No insights yet. Start trading to receive AI-powered analysis!</p>
              </div>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}