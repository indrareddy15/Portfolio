import { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { X, TrendingUp } from "lucide-react";
import { Button } from "@/components/ui/button";
import { supabase } from "@/integrations/supabase/client";

interface CMSBlock {
  key: string;
  content_json: {
    enabled?: boolean;
    title?: string;
    subtitle?: string;
    cta?: string;
  };
}

export const AffiliateTopStrip = () => {
  const [visible, setVisible] = useState(false);
  const [content, setContent] = useState({
    title: "Become a PipTrackr.com Affiliate",
    subtitle: "Earn 30% recurring commissions",
    cta: "Learn More"
  });

  useEffect(() => {
    const fetchContent = async () => {
      const { data } = await supabase
        .from('cms_blocks')
        .select('*')
        .eq('key', 'home_affiliate_strip')
        .single();
      
      if (data?.content_json && typeof data.content_json === 'object') {
        const contentJson = data.content_json as any;
        if (contentJson.enabled) {
          setContent({
            title: contentJson.title || content.title,
            subtitle: contentJson.subtitle || content.subtitle,
            cta: contentJson.cta || content.cta
          });
          setVisible(true);
        }
      }
    };

    fetchContent();
  }, []);

  if (!visible) return null;

  return (
    <div className="bg-gradient-primary text-white relative overflow-hidden">
      <div className="absolute inset-0 bg-black/10" />
      <div className="relative container mx-auto px-4 py-3">
        <div className="flex items-center justify-between max-w-6xl mx-auto">
          <div className="flex items-center gap-3">
            <div className="p-1.5 bg-white/20 rounded-lg">
              <TrendingUp className="h-4 w-4" />
            </div>
            <div className="flex flex-col sm:flex-row sm:items-center gap-1 sm:gap-3">
              <span className="font-semibold text-sm sm:text-base">
                {content.title}
              </span>
              <span className="text-xs sm:text-sm text-white/90">
                {content.subtitle}
              </span>
            </div>
          </div>
          
          <div className="flex items-center gap-3">
            <Button 
              asChild 
              variant="outline" 
              size="sm"
              className="bg-white/10 border-white/20 text-white hover:bg-white/20 text-xs sm:text-sm"
            >
              <Link to="/affiliates">
                {content.cta}
              </Link>
            </Button>
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setVisible(false)}
              className="text-white hover:bg-white/10 p-1"
            >
              <X className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
};