import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { 
  Target, 
  TrendingUp, 
  TrendingDown,
  BarChart3,
  Filter,
  ArrowUpDown
} from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/components/ui/use-toast";

interface StrategyPerformance {
  id: string;
  name: string;
  winRate: number;
  avgRR: number;
  totalPnL: number;
  netProfit: number;
  tradeCount: number;
  active: boolean;
}

interface StrategyPerformanceTableProps {
  onStrategySelect?: (strategyId: string | null) => void;
  selectedStrategy?: string | null;
}

export function StrategyPerformanceTable({ 
  onStrategySelect, 
  selectedStrategy 
}: StrategyPerformanceTableProps) {
  const [strategies, setStrategies] = useState<StrategyPerformance[]>([]);
  const [loading, setLoading] = useState(true);
  const [sortBy, setSortBy] = useState<keyof StrategyPerformance>("totalPnL");
  const [sortOrder, setSortOrder] = useState<"asc" | "desc">("desc");
  const { user } = useAuth();
  const { toast } = useToast();

  const fetchStrategyPerformance = async () => {
    if (!user) return;

    try {
      // Fetch strategies
      const { data: strategiesData, error: strategiesError } = await supabase
        .from("strategies")
        .select("*")
        .eq("user_id", user.id)
        .order("created_at", { ascending: false });

      if (strategiesError) throw strategiesError;

      // Calculate performance for each strategy
      const strategiesWithPerformance = await Promise.all(
        (strategiesData || []).map(async (strategy) => {
          const { data: trades, error: tradesError } = await supabase
            .from("trades")
            .select("pnl, result, entry_price, exit_price, stop_loss, take_profit")
            .eq("user_id", user.id)
            .eq("strategy_id", strategy.id)
            .not("pnl", "is", null);

          if (tradesError) {
            console.error("Error fetching trades for strategy:", tradesError);
            return {
              id: strategy.id,
              name: strategy.name,
              active: strategy.active,
              winRate: 0,
              avgRR: 0,
              totalPnL: 0,
              netProfit: 0,
              tradeCount: 0
            };
          }

          const tradeCount = trades?.length || 0;
          const winningTrades = trades?.filter(t => (t.pnl || 0) > 0).length || 0;
          const winRate = tradeCount > 0 ? (winningTrades / tradeCount) * 100 : 0;
          const totalPnL = trades?.reduce((sum, t) => sum + (t.pnl || 0), 0) || 0;
          const grossProfit = trades?.filter(t => (t.pnl || 0) > 0).reduce((sum, t) => sum + (t.pnl || 0), 0) || 0;
          const grossLoss = trades?.filter(t => (t.pnl || 0) < 0).reduce((sum, t) => sum + Math.abs(t.pnl || 0), 0) || 0;
          const netProfit = grossProfit - grossLoss;

          // Calculate average risk-reward ratio
          const rrTrades = trades?.filter(t => t.entry_price && t.take_profit && t.stop_loss) || [];
          const avgRR = rrTrades.length > 0 
            ? rrTrades.reduce((sum, t) => {
                const reward = Math.abs((t.take_profit || 0) - (t.entry_price || 0));
                const risk = Math.abs((t.entry_price || 0) - (t.stop_loss || 0));
                return sum + (risk > 0 ? reward / risk : 0);
              }, 0) / rrTrades.length
            : 0;

          return {
            id: strategy.id,
            name: strategy.name,
            active: strategy.active,
            winRate,
            avgRR,
            totalPnL,
            netProfit,
            tradeCount
          };
        })
      );

      setStrategies(strategiesWithPerformance);
    } catch (error: any) {
      toast({
        variant: "destructive",
        title: "Error loading strategy performance",
        description: error.message,
      });
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchStrategyPerformance();
  }, [user]);

  // Real-time updates for strategies and trades
  useEffect(() => {
    if (!user) return;

    const strategiesChannel = supabase
      .channel('strategy-performance-updates')
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'strategies',
          filter: `user_id=eq.${user.id}`
        },
        () => {
          fetchStrategyPerformance();
        }
      )
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'trades',
          filter: `user_id=eq.${user.id}`
        },
        () => {
          fetchStrategyPerformance();
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(strategiesChannel);
    };
  }, [user]);

  const handleSort = (field: keyof StrategyPerformance) => {
    if (sortBy === field) {
      setSortOrder(sortOrder === "asc" ? "desc" : "asc");
    } else {
      setSortBy(field);
      setSortOrder("desc");
    }
  };

  const sortedStrategies = [...strategies].sort((a, b) => {
    const aValue = a[sortBy];
    const bValue = b[sortBy];
    
    if (typeof aValue === 'string' && typeof bValue === 'string') {
      return sortOrder === "asc" 
        ? aValue.localeCompare(bValue)
        : bValue.localeCompare(aValue);
    }
    
    if (typeof aValue === 'number' && typeof bValue === 'number') {
      return sortOrder === "asc" ? aValue - bValue : bValue - aValue;
    }
    
    return 0;
  });

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 2,
    }).format(amount);
  };

  if (loading) {
    return (
      <Card className="glass-card border-card-border">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <BarChart3 className="w-5 h-5 text-primary" />
            Strategy Performance
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="animate-pulse space-y-4">
            {[1, 2, 3].map(i => (
              <div key={i} className="h-12 bg-muted rounded"></div>
            ))}
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="glass-card border-card-border">
      <CardHeader>
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <CardTitle className="flex items-center gap-2 text-lg sm:text-xl">
            <BarChart3 className="w-4 h-4 sm:w-5 sm:h-5 text-primary" />
            <span className="hidden sm:inline">Strategy Performance Table</span>
            <span className="sm:hidden">Strategies</span>
          </CardTitle>
          {onStrategySelect && (
            <div className="flex items-center gap-2 w-full sm:w-auto">
              <Filter className="w-3 h-3 sm:w-4 sm:h-4 text-muted-foreground" />
              <Select value={selectedStrategy || "all"} onValueChange={(value) => onStrategySelect(value === "all" ? null : value)}>
                <SelectTrigger className="w-full sm:w-[180px]">
                  <SelectValue placeholder="Filter by strategy" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Strategies</SelectItem>
                  {strategies.map((strategy) => (
                    <SelectItem key={strategy.id} value={strategy.id}>
                      {strategy.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          )}
        </div>
      </CardHeader>
      <CardContent>
        {strategies.length === 0 ? (
          <div className="text-center py-6 sm:py-8 animate-fade-in">
            <Target className="w-8 h-8 sm:w-12 sm:h-12 mx-auto mb-3 sm:mb-4 text-muted-foreground opacity-50" />
            <h3 className="text-base sm:text-lg font-semibold mb-2">No Strategies Found</h3>
            <p className="text-sm sm:text-base text-muted-foreground px-4">
              Create strategies to track and compare their performance.
            </p>
          </div>
        ) : (
          <>
            {/* Mobile Card View */}
            <div className="block sm:hidden space-y-3 animate-fade-in">
              {sortedStrategies.map((strategy, index) => (
                <div 
                  key={strategy.id}
                  className={`glass-card p-4 hover:shadow-glow transition-all duration-300 hover-scale ${
                    selectedStrategy === strategy.id ? 'bg-primary/5 border-primary/20' : ''
                  }`}
                >
                  <div className="flex items-center justify-between mb-3">
                    <div className="flex items-center gap-2">
                      <div className={`w-2 h-2 rounded-full ${strategy.active ? 'bg-success' : 'bg-muted-foreground'}`} />
                      <span className="font-semibold text-sm">{strategy.name}</span>
                    </div>
                    <Badge variant={strategy.active ? "default" : "secondary"} className="text-xs">
                      {strategy.active ? "Active" : "Inactive"}
                    </Badge>
                  </div>
                  
                  <div className="grid grid-cols-2 gap-3 text-xs">
                    <div className="flex items-center justify-between">
                      <span className="text-muted-foreground">Win Rate:</span>
                      <div className="flex items-center gap-1">
                        {strategy.winRate >= 50 ? 
                          <TrendingUp className="w-3 h-3 text-success" /> : 
                          <TrendingDown className="w-3 h-3 text-danger" />
                        }
                        <span className={`font-semibold ${
                          strategy.winRate >= 50 ? 'text-success' : 'text-danger'
                        }`}>
                          {strategy.winRate.toFixed(1)}%
                        </span>
                      </div>
                    </div>
                    
                    <div className="flex items-center justify-between">
                      <span className="text-muted-foreground">Avg RR:</span>
                      <span className={`font-medium ${
                        strategy.avgRR >= 1 ? 'text-success' : 'text-muted-foreground'
                      }`}>
                        {strategy.avgRR.toFixed(2)}
                      </span>
                    </div>
                    
                    <div className="flex items-center justify-between">
                      <span className="text-muted-foreground">Total P&L:</span>
                      <span className={`font-bold text-xs ${
                        strategy.totalPnL >= 0 ? 'text-success' : 'text-danger'
                      }`}>
                        {formatCurrency(strategy.totalPnL)}
                      </span>
                    </div>
                    
                    <div className="flex items-center justify-between">
                      <span className="text-muted-foreground">Net Profit:</span>
                      <span className={`font-medium text-xs ${
                        strategy.netProfit >= 0 ? 'text-success' : 'text-danger'
                      }`}>
                        {formatCurrency(strategy.netProfit)}
                      </span>
                    </div>
                    
                    <div className="flex items-center justify-between col-span-2">
                      <span className="text-muted-foreground">Trades:</span>
                      <Badge variant="outline" className="text-xs">
                        {strategy.tradeCount}
                      </Badge>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            {/* Desktop Table View */}
            <div className="hidden sm:block overflow-x-auto animate-fade-in">
              <table className="w-full">
                <thead>
                  <tr className="border-b border-border">
                    <th className="text-left py-3 px-2">
                      <Button 
                        variant="ghost" 
                        size="sm" 
                        className="h-auto p-0 font-semibold text-xs sm:text-sm hover-scale"
                        onClick={() => handleSort('name')}
                      >
                        Strategy Name
                        <ArrowUpDown className="ml-1 h-3 w-3" />
                      </Button>
                    </th>
                    <th className="text-center py-3 px-2">
                      <Button 
                        variant="ghost" 
                        size="sm" 
                        className="h-auto p-0 font-semibold text-xs sm:text-sm hover-scale"
                        onClick={() => handleSort('winRate')}
                      >
                        Win %
                        <ArrowUpDown className="ml-1 h-3 w-3" />
                      </Button>
                    </th>
                    <th className="text-center py-3 px-2 hidden md:table-cell">
                      <Button 
                        variant="ghost" 
                        size="sm" 
                        className="h-auto p-0 font-semibold text-xs sm:text-sm hover-scale"
                        onClick={() => handleSort('avgRR')}
                      >
                        Avg RR
                        <ArrowUpDown className="ml-1 h-3 w-3" />
                      </Button>
                    </th>
                    <th className="text-center py-3 px-2">
                      <Button 
                        variant="ghost" 
                        size="sm" 
                        className="h-auto p-0 font-semibold text-xs sm:text-sm hover-scale"
                        onClick={() => handleSort('totalPnL')}
                      >
                        <span className="hidden sm:inline">Total P&L</span>
                        <span className="sm:hidden">P&L</span>
                        <ArrowUpDown className="ml-1 h-3 w-3" />
                      </Button>
                    </th>
                    <th className="text-center py-3 px-2 hidden lg:table-cell">
                      <Button 
                        variant="ghost" 
                        size="sm" 
                        className="h-auto p-0 font-semibold text-xs sm:text-sm hover-scale"
                        onClick={() => handleSort('netProfit')}
                      >
                        Net Profit
                        <ArrowUpDown className="ml-1 h-3 w-3" />
                      </Button>
                    </th>
                    <th className="text-center py-3 px-2">
                      <Button 
                        variant="ghost" 
                        size="sm" 
                        className="h-auto p-0 font-semibold text-xs sm:text-sm hover-scale"
                        onClick={() => handleSort('tradeCount')}
                      >
                        Trades
                        <ArrowUpDown className="ml-1 h-3 w-3" />
                      </Button>
                    </th>
                    <th className="text-center py-3 px-2">Status</th>
                  </tr>
                </thead>
                <tbody>
                  {sortedStrategies.map((strategy, index) => (
                    <tr 
                      key={strategy.id}
                      className={`border-b border-border hover:bg-muted/50 transition-all duration-300 hover-scale ${
                        selectedStrategy === strategy.id ? 'bg-primary/5 border-primary/20' : ''
                      }`}
                    >
                      <td className="py-3 sm:py-4 px-2">
                        <div className="flex items-center gap-2">
                          <div className={`w-2 h-2 rounded-full ${strategy.active ? 'bg-success' : 'bg-muted-foreground'}`} />
                          <span className="font-medium text-xs sm:text-sm">{strategy.name}</span>
                        </div>
                      </td>
                      <td className="text-center py-3 sm:py-4 px-2">
                        <div className="flex items-center justify-center gap-1">
                          {strategy.winRate >= 50 ? 
                            <TrendingUp className="w-3 h-3 text-success" /> : 
                            <TrendingDown className="w-3 h-3 text-danger" />
                          }
                          <span className={`font-semibold text-xs sm:text-sm ${
                            strategy.winRate >= 50 ? 'text-success' : 'text-danger'
                          }`}>
                            {strategy.winRate.toFixed(1)}%
                          </span>
                        </div>
                      </td>
                      <td className="text-center py-3 sm:py-4 px-2 hidden md:table-cell">
                        <span className={`font-medium text-xs sm:text-sm ${
                          strategy.avgRR >= 1 ? 'text-success' : 'text-muted-foreground'
                        }`}>
                          {strategy.avgRR.toFixed(2)}
                        </span>
                      </td>
                      <td className="text-center py-3 sm:py-4 px-2">
                        <span className={`font-bold text-xs sm:text-sm ${
                          strategy.totalPnL >= 0 ? 'text-success' : 'text-danger'
                        }`}>
                          {formatCurrency(strategy.totalPnL)}
                        </span>
                      </td>
                      <td className="text-center py-3 sm:py-4 px-2 hidden lg:table-cell">
                        <span className={`font-medium text-xs sm:text-sm ${
                          strategy.netProfit >= 0 ? 'text-success' : 'text-danger'
                        }`}>
                          {formatCurrency(strategy.netProfit)}
                        </span>
                      </td>
                      <td className="text-center py-3 sm:py-4 px-2">
                        <Badge variant="outline" className="text-xs font-medium">
                          {strategy.tradeCount}
                        </Badge>
                      </td>
                      <td className="text-center py-3 sm:py-4 px-2">
                        <Badge variant={strategy.active ? "default" : "secondary"} className="text-xs">
                          {strategy.active ? "Active" : "Inactive"}
                        </Badge>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </>
        )}
      </CardContent>
    </Card>
  );
}