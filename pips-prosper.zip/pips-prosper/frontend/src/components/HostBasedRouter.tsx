import { useEffect } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';

export const HostBasedRouter = () => {
  const navigate = useNavigate();
  const location = useLocation();

  useEffect(() => {
    const hostname = window.location.hostname;
    const currentPath = location.pathname;

    // Admin subdomain routing
    if (hostname === 'admin.piptrackr.com' || hostname === 'admin.piptrackr.localhost') {
      if (!currentPath.startsWith('/admin')) {
        navigate('/admin', { replace: true });
      }
      return;
    }

    // App subdomain routing  
    if (hostname === 'app.piptrackr.com' || hostname === 'app.piptrackr.localhost') {
      if (!currentPath.startsWith('/app')) {
        navigate('/app', { replace: true });
      }
      return;
    }

    // Main domain - redirect app/admin paths to appropriate subdomains
    if (hostname === 'piptrackr.com' || hostname === 'piptrackr.localhost' || hostname.includes('lovable.app')) {
      // If user is on admin path, redirect to admin subdomain
      if (currentPath.startsWith('/admin')) {
        const adminUrl = hostname.includes('localhost') 
          ? `http://admin.piptrackr.localhost:${window.location.port}${currentPath}`
          : `https://admin.piptrackr.com${currentPath}`;
        window.location.href = adminUrl;
        return;
      }
      
      // If user is on app path, redirect to app subdomain  
      if (currentPath.startsWith('/app')) {
        const appUrl = hostname.includes('localhost')
          ? `http://app.piptrackr.localhost:${window.location.port}${currentPath}`
          : `https://app.piptrackr.com${currentPath}`;
        window.location.href = appUrl;
        return;
      }
    }
  }, [navigate, location.pathname]);

  return null;
};