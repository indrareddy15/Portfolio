import { useState, useEffect, useCallback } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { DollarSign, TrendingUp, TrendingDown, Calculator, AlertTriangle, Save } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/useAuth";
import { forexEngine, type ForexCalculationResult } from "@/utils/forexEngine";
import { useTradeSharing } from "@/hooks/useTradeSharing";

interface ForexTradeFormProps {
  onTradeAdded?: () => void;
}

export function ForexTradeForm({ onTradeAdded }: ForexTradeFormProps) {
  const [isLoading, setIsLoading] = useState(false);
  const [calculation, setCalculation] = useState<ForexCalculationResult | null>(null);
  const [calculationError, setCalculationError] = useState<string>("");
  const [formData, setFormData] = useState({
    symbol: "",
    side: "" as "long" | "short" | "",
    entryPrice: "",
    exitPrice: "",
    lots: "0.1",
    stopLoss: "",
    takeProfit: "",
    accountCurrency: "USD",
    openedAt: "",
    closedAt: "",
    notesPre: "",
    notesPost: ""
  });

  const { toast } = useToast();
  const { user, subscriptionData } = useAuth();
  const { createTradeShare, generateCertificate } = useTradeSharing();

  // Real-time calculation when form data changes
  const calculateMetrics = useCallback(async () => {
    if (!formData.symbol || !formData.side || !formData.entryPrice || !formData.lots) {
      setCalculation(null);
      return;
    }

    try {
      setCalculationError("");
      const result = await forexEngine.calculateTrade({
        symbol: formData.symbol,
        side: formData.side,
        entryPrice: parseFloat(formData.entryPrice),
        exitPrice: formData.exitPrice ? parseFloat(formData.exitPrice) : undefined,
        stopLoss: formData.stopLoss ? parseFloat(formData.stopLoss) : undefined,
        takeProfit: formData.takeProfit ? parseFloat(formData.takeProfit) : undefined,
        lots: parseFloat(formData.lots),
        accountCurrency: formData.accountCurrency
      });
      
      setCalculation(result);
    } catch (error: any) {
      setCalculationError(error.message);
      setCalculation(null);
    }
  }, [formData]);

  useEffect(() => {
    const timer = setTimeout(calculateMetrics, 500); // Debounce
    return () => clearTimeout(timer);
  }, [calculateMetrics]);

  // Set default open time to now
  useEffect(() => {
    if (!formData.openedAt) {
      const now = new Date();
      now.setMinutes(now.getMinutes() - now.getTimezoneOffset());
      setFormData(prev => ({ ...prev, openedAt: now.toISOString().slice(0, 16) }));
    }
  }, []);

  const handleInputChange = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handlePersistAutoConfig = async () => {
    if (!calculation?.autoConfigured) return;
    
    try {
      await forexEngine.persistAutoConfig(calculation.instrumentConfig);
      toast({
        title: "Instrument Saved",
        description: `${calculation.instrumentConfig.symbol} configuration has been saved to the database.`
      });
      // Recalculate to update the auto-configured flag
      await calculateMetrics();
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive"
      });
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user || !calculation) return;

    setIsLoading(true);

    try {
      const tradeData = {
        user_id: user.id,
        instrument: formData.symbol.toUpperCase(),
        side: formData.side,
        entry_price: parseFloat(formData.entryPrice),
        exit_price: formData.exitPrice ? parseFloat(formData.exitPrice) : null,
        size: parseFloat(formData.lots),
        stop_loss: formData.stopLoss ? parseFloat(formData.stopLoss) : null,
        take_profit: formData.takeProfit ? parseFloat(formData.takeProfit) : null,
        opened_at: formData.openedAt,
        closed_at: formData.closedAt || null,
        notes_pre: formData.notesPre || null,
        notes_post: formData.notesPost || null,
        // Enhanced Forex fields
        account_currency: formData.accountCurrency,
        quote_currency: calculation.instrumentConfig.quoteCcy,
        pips: calculation.pips,
        pip_value: calculation.pipValue,
        raw_pnl: calculation.rawPnL,
        converted_pnl: calculation.convertedPnL,
        pnl: calculation.convertedPnL, // Main PnL field for compatibility
        fx_rate_used: calculation.fxRateUsed,
        auto_configured: calculation.autoConfigured,
        commission: 0 // Can be extended later
      };

      // Set result based on PnL
      let result = null;
      if (tradeData.exit_price) {
        result = tradeData.pnl > 0 ? 'win' : tradeData.pnl < 0 ? 'loss' : 'breakeven';
      }

      const finalTradeData = {
        ...tradeData,
        result
      };

      const { data: insertedTrade, error } = await supabase
        .from("trades")
        .insert([finalTradeData])
        .select("id,instrument,pnl,side,entry_price,exit_price,size")
        .single();

      if (error) throw error;

      toast({
        title: "Forex Trade Added",
        description: `Trade recorded with ${calculation.pips > 0 ? '+' : ''}${calculation.pips} pips (${formData.accountCurrency} ${calculation.convertedPnL > 0 ? '+' : ''}${calculation.convertedPnL.toFixed(2)})`
      });

      // Reset form and notify
      setFormData({
        symbol: "",
        side: "",
        entryPrice: "",
        exitPrice: "",
        lots: "0.1",
        stopLoss: "",
        takeProfit: "",
        accountCurrency: "USD",
        openedAt: "",
        closedAt: "",
        notesPre: "",
        notesPost: ""
      });
      setCalculation(null);
      onTradeAdded?.();

      // Auto-create share link in background
      setTimeout(async () => {
        try {
          const share = await createTradeShare({
            trade_id: insertedTrade!.id,
            title: `${(insertedTrade!.pnl || 0) > 0 ? 'Profitable' : 'Learning'} ${insertedTrade!.instrument} Trade`,
            description: `Shared via PipTrackr — P&L: $${(insertedTrade!.pnl || 0).toFixed(2)}`,
            is_public: true,
          });

          if (share) {
            const hostname = window.location.hostname;
            let base = window.location.origin;
            if (hostname.startsWith('app.')) {
              base = base.replace('//app.', '//');
            }
            const shareUrl = `${base}/shared/trade/${share.share_token}`;

            toast({
              title: "🔗 Share link created",
              description: shareUrl,
            });

            generateCertificate(share.id);
          }
        } catch (e) {
          console.warn('Auto-share failed', e);
        }
      }, 0);

    } catch (error: any) {
      toast({
        title: "Error Adding Trade",
        description: error.message,
        variant: "destructive"
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      <Card className="glass-card border-card-border">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-xl font-poppins">
            <DollarSign className="w-5 h-5 text-primary" />
            Add Forex Trade
          </CardTitle>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="symbol">Symbol *</Label>
                <Input
                  id="symbol"
                  value={formData.symbol}
                  onChange={(e) => handleInputChange("symbol", e.target.value.toUpperCase())}
                  placeholder="EURUSD"
                  maxLength={6}
                  required
                />
                {calculation?.autoConfigured && (
                  <div className="flex items-center gap-2">
                    <Badge variant="outline" className="text-orange-600">Auto-configured</Badge>
                    <Button
                      type="button"
                      variant="ghost"
                      size="sm"
                      onClick={handlePersistAutoConfig}
                      className="h-6 px-2 text-xs"
                    >
                      <Save className="w-3 h-3 mr-1" />
                      Save Config
                    </Button>
                  </div>
                )}
              </div>

              <div className="space-y-2">
                <Label htmlFor="side">Side *</Label>
                <Select value={formData.side} onValueChange={(value: "long" | "short") => handleInputChange("side", value)}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select side" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="long">
                      <div className="flex items-center gap-2">
                        <TrendingUp className="w-4 h-4 text-green-500" />
                        Long (Buy)
                      </div>
                    </SelectItem>
                    <SelectItem value="short">
                      <div className="flex items-center gap-2">
                        <TrendingDown className="w-4 h-4 text-red-500" />
                        Short (Sell)
                      </div>
                    </SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="entryPrice">Entry Price *</Label>
                <Input
                  id="entryPrice"
                  type="number"
                  step="0.00001"
                  value={formData.entryPrice}
                  onChange={(e) => handleInputChange("entryPrice", e.target.value)}
                  placeholder="1.08450"
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="lots">Lot Size *</Label>
                <Input
                  id="lots"
                  type="number"
                  step="0.01"
                  value={formData.lots}
                  onChange={(e) => handleInputChange("lots", e.target.value)}
                  placeholder="0.10"
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="stopLoss">Stop Loss</Label>
                <Input
                  id="stopLoss"
                  type="number"
                  step="0.00001"
                  value={formData.stopLoss}
                  onChange={(e) => handleInputChange("stopLoss", e.target.value)}
                  placeholder="1.08200"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="takeProfit">Take Profit</Label>
                <Input
                  id="takeProfit"
                  type="number"  
                  step="0.00001"
                  value={formData.takeProfit}
                  onChange={(e) => handleInputChange("takeProfit", e.target.value)}
                  placeholder="1.08700"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="accountCurrency">Account Currency</Label>
                <Select value={formData.accountCurrency} onValueChange={(value) => handleInputChange("accountCurrency", value)}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="USD">USD</SelectItem>
                    <SelectItem value="EUR">EUR</SelectItem>
                    <SelectItem value="GBP">GBP</SelectItem>
                    <SelectItem value="JPY">JPY</SelectItem>
                    <SelectItem value="AUD">AUD</SelectItem>
                    <SelectItem value="CAD">CAD</SelectItem>
                    <SelectItem value="CHF">CHF</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="openedAt">Open Time *</Label>
                <Input
                  id="openedAt"
                  type="datetime-local"
                  value={formData.openedAt}
                  onChange={(e) => handleInputChange("openedAt", e.target.value)}
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="exitPrice">Exit Price (if closed)</Label>
                <Input
                  id="exitPrice"
                  type="number"
                  step="0.00001"
                  value={formData.exitPrice}
                  onChange={(e) => handleInputChange("exitPrice", e.target.value)}
                  placeholder="1.08650"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="closedAt">Close Time (if closed)</Label>
                <Input
                  id="closedAt"
                  type="datetime-local"
                  value={formData.closedAt}
                  onChange={(e) => handleInputChange("closedAt", e.target.value)}
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="notesPre">Pre-Trade Notes</Label>
              <Textarea
                id="notesPre"
                value={formData.notesPre}
                onChange={(e) => handleInputChange("notesPre", e.target.value)}
                placeholder="Why did you take this trade? What was your analysis?"
                rows={3}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="notesPost">Post-Trade Notes</Label>
              <Textarea
                id="notesPost"
                value={formData.notesPost}
                onChange={(e) => handleInputChange("notesPost", e.target.value)}
                placeholder="How did the trade go? What did you learn?"
                rows={3}
              />
            </div>

            <Button
              type="submit"
              className="w-full"
              disabled={isLoading || !calculation}
            >
              {isLoading ? "Adding Trade..." : "Add Forex Trade"}
            </Button>
          </form>
        </CardContent>
      </Card>

      {/* Live Preview Card */}
      {(calculation || calculationError) && (
        <Card className="glass-card border-card-border">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-lg">
              <Calculator className="w-5 h-5 text-primary" />
              Live Trade Preview
            </CardTitle>
          </CardHeader>
          <CardContent>
            {calculationError && (
              <Alert className="mb-4">
                <AlertTriangle className="h-4 w-4" />
                <AlertDescription>{calculationError}</AlertDescription>
              </Alert>
            )}

            {calculation && (
              <div className="space-y-4">
                {/* Instrument Info */}
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4 p-4 bg-muted/30 rounded-lg">
                  <div>
                    <div className="text-sm text-muted-foreground">Lot Units</div>
                    <div className="font-semibold">{calculation.instrumentConfig.lotUnits.toLocaleString()}</div>
                  </div>
                  <div>
                    <div className="text-sm text-muted-foreground">Pip Size</div>
                    <div className="font-semibold">{calculation.instrumentConfig.pipSize}</div>
                  </div>
                  <div>
                    <div className="text-sm text-muted-foreground">Pip Value ({calculation.instrumentConfig.quoteCcy})</div>
                    <div className="font-semibold">{calculation.pipValue}</div>
                  </div>
                  <div>
                    <div className="text-sm text-muted-foreground">FX Rate Used</div>
                    <div className="font-semibold">{calculation.fxRateUsed}</div>
                  </div>
                </div>

                {/* Risk/Reward Analysis */}
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  {calculation.riskAmount > 0 && (
                    <Card className="bg-red-50 dark:bg-red-950/20 border-red-200 dark:border-red-800">
                      <CardContent className="p-4">
                        <div className="text-sm text-red-600 dark:text-red-400">Risk Amount</div>
                        <div className="text-xl font-bold text-red-700 dark:text-red-300">
                          {formData.accountCurrency} {calculation.riskAmount.toFixed(2)}
                        </div>
                      </CardContent>
                    </Card>
                  )}

                  {calculation.rewardAmount > 0 && (
                    <Card className="bg-green-50 dark:bg-green-950/20 border-green-200 dark:border-green-800">
                      <CardContent className="p-4">
                        <div className="text-sm text-green-600 dark:text-green-400">Reward Amount</div>
                        <div className="text-xl font-bold text-green-700 dark:text-green-300">
                          {formData.accountCurrency} {calculation.rewardAmount.toFixed(2)}
                        </div>
                      </CardContent>
                    </Card>
                  )}

                  {calculation.riskRewardRatio > 0 && (
                    <Card className="bg-blue-50 dark:bg-blue-950/20 border-blue-200 dark:border-blue-800">
                      <CardContent className="p-4">
                        <div className="text-sm text-blue-600 dark:text-blue-400">Risk:Reward</div>
                        <div className="text-xl font-bold text-blue-700 dark:text-blue-300">
                          1:{calculation.riskRewardRatio.toFixed(2)}
                        </div>
                      </CardContent>
                    </Card>
                  )}
                </div>

                {/* Current PnL (if exit price provided) */}
                {calculation.pips !== 0 && (
                  <Card className={`${calculation.convertedPnL >= 0 ? 'bg-green-50 dark:bg-green-950/20 border-green-200 dark:border-green-800' : 'bg-red-50 dark:bg-red-950/20 border-red-200 dark:border-red-800'}`}>
                    <CardContent className="p-4">
                      <div className="flex justify-between items-center">
                        <div>
                          <div className="text-sm text-muted-foreground">Expected PnL</div>
                          <div className={`text-2xl font-bold ${calculation.convertedPnL >= 0 ? 'text-green-700 dark:text-green-300' : 'text-red-700 dark:text-red-300'}`}>
                            {formData.accountCurrency} {calculation.convertedPnL > 0 ? '+' : ''}{calculation.convertedPnL.toFixed(2)}
                          </div>
                        </div>
                        <div className="text-right">
                          <div className="text-sm text-muted-foreground">Pips</div>
                          <div className={`text-xl font-bold ${calculation.pips >= 0 ? 'text-green-700 dark:text-green-300' : 'text-red-700 dark:text-red-300'}`}>
                            {calculation.pips > 0 ? '+' : ''}{calculation.pips}
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                )}
              </div>
            )}
          </CardContent>
        </Card>
      )}
    </div>
  );
}