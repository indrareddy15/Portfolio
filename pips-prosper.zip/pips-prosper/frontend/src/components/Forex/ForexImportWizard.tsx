import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Progress } from "@/components/ui/progress";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Upload, FileText, CheckCircle, AlertTriangle } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";

interface ImportResult {
  total: number;
  imported: number;
  skipped: number;
  errors: string[];
}

export function ForexImportWizard() {
  const [file, setFile] = useState<File | null>(null);
  const [importing, setImporting] = useState(false);
  const [progress, setProgress] = useState(0);
  const [result, setResult] = useState<ImportResult | null>(null);
  const { toast } = useToast();

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const uploadedFile = e.target.files?.[0];
    if (uploadedFile) {
      setFile(uploadedFile);
      setResult(null);
    }
  };

  const parseForexPairs = (data: any[]): any[] => {
    return data.map((item: any) => {
      // Handle different JSON formats
      const symbol = item.symbol || item.Symbol || item.SYMBOL || '';
      const baseCcy = item.baseCcy || item.base_ccy || item.base || symbol.substring(0, 3);
      const quoteCcy = item.quoteCcy || item.quote_ccy || item.quote || symbol.substring(3, 6);

      return {
        symbol: symbol.toUpperCase(),
        class: item.class || 'forex',
        pricing_mode: item.pricingMode || item.pricing_mode || 'forex',
        base_ccy: baseCcy.toUpperCase(),
        quote_ccy: quoteCcy.toUpperCase(),
        lot_units: item.lotUnits || item.lot_units || 100000,
        pip_size: item.pipSize || item.pip_size || (quoteCcy.toUpperCase() === 'JPY' ? 0.01 : 0.0001),
        price_precision: item.pricePrecision || item.price_precision || (quoteCcy.toUpperCase() === 'JPY' ? 3 : 5),
        pip_precision: item.pipPrecision || item.pip_precision || (quoteCcy.toUpperCase() === 'JPY' ? 2 : 1),
        description: item.description || `${baseCcy.toUpperCase()} vs ${quoteCcy.toUpperCase()}`,
        is_active: true
      };
    });
  };

  const handleImport = async () => {
    if (!file) return;

    setImporting(true);
    setProgress(0);
    
    try {
      const text = await file.text();
      const rawData = JSON.parse(text);
      
      if (!Array.isArray(rawData)) {
        throw new Error("File must contain a JSON array of instrument objects");
      }

      const instruments = parseForexPairs(rawData);
      const total = instruments.length;
      let imported = 0;
      let skipped = 0;
      const errors: string[] = [];

      // Process in batches of 50 to avoid timeout
      const batchSize = 50;
      for (let i = 0; i < instruments.length; i += batchSize) {
        const batch = instruments.slice(i, i + batchSize);
        
        try {
          const { data, error } = await supabase
            .from('instruments')
            .upsert(batch, { 
              onConflict: 'symbol',
              ignoreDuplicates: false 
            });

          if (error) {
            errors.push(`Batch ${Math.floor(i/batchSize) + 1}: ${error.message}`);
            skipped += batch.length;
          } else {
            imported += batch.length;
          }
        } catch (batchError: any) {
          errors.push(`Batch ${Math.floor(i/batchSize) + 1}: ${batchError.message}`);
          skipped += batch.length;
        }

        setProgress(Math.round(((i + batch.length) / total) * 100));
      }

      const finalResult: ImportResult = {
        total,
        imported,
        skipped,
        errors
      };

      setResult(finalResult);

      toast({
        title: "Import Complete",
        description: `Successfully imported ${imported} out of ${total} instruments`,
        variant: errors.length > 0 ? "destructive" : "default"
      });

    } catch (error: any) {
      toast({
        title: "Import Error",
        description: error.message,
        variant: "destructive"
      });
    } finally {
      setImporting(false);
      setProgress(0);
    }
  };

  return (
    <div className="max-w-2xl mx-auto space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Upload className="w-5 h-5 text-primary" />
            Import Forex Instruments
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <Alert>
            <FileText className="w-4 h-4" />
            <AlertDescription>
              Upload a JSON file containing Forex instrument configurations. The file should contain an array of objects with fields like: symbol, baseCcy, quoteCcy, lotUnits, pipSize, etc.
            </AlertDescription>
          </Alert>

          <div>
            <Label htmlFor="forex-file">JSON File</Label>
            <Input
              id="forex-file"
              type="file"
              accept=".json"
              onChange={handleFileUpload}
              disabled={importing}
            />
          </div>

          {importing && (
            <div className="space-y-2">
              <div className="flex justify-between text-sm">
                <span>Importing...</span>
                <span>{progress}%</span>
              </div>
              <Progress value={progress} />
            </div>
          )}

          <Button
            onClick={handleImport}
            disabled={!file || importing}
            className="w-full"
          >
            {importing ? "Importing..." : "Import Instruments"}
          </Button>

          {result && (
            <Card className="mt-4">
              <CardContent className="p-4">
                <div className="space-y-3">
                  <div className="flex items-center gap-2">
                    <CheckCircle className="w-5 h-5 text-green-500" />
                    <span className="font-semibold">Import Results</span>
                  </div>
                  
                  <div className="grid grid-cols-3 gap-4 text-sm">
                    <div>
                      <div className="text-muted-foreground">Total</div>
                      <div className="font-semibold">{result.total}</div>
                    </div>
                    <div>
                      <div className="text-muted-foreground">Imported</div>
                      <div className="font-semibold text-green-600">{result.imported}</div>
                    </div>
                    <div>
                      <div className="text-muted-foreground">Skipped</div>
                      <div className="font-semibold text-orange-600">{result.skipped}</div>
                    </div>
                  </div>

                  {result.errors.length > 0 && (
                    <div className="space-y-2">
                      <div className="text-sm font-medium text-red-600">Errors:</div>
                      {result.errors.map((error, index) => (
                        <div key={index} className="text-xs text-red-600 bg-red-50 p-2 rounded">
                          {error}
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          )}
        </CardContent>
      </Card>

      {/* Sample JSON format */}
      <Card>
        <CardHeader>
          <CardTitle>Expected JSON Format</CardTitle>
        </CardHeader>
        <CardContent>
          <pre className="text-xs bg-muted p-4 rounded-md overflow-x-auto">
{`[
  {
    "symbol": "EURUSD",
    "baseCcy": "EUR", 
    "quoteCcy": "USD",
    "lotUnits": 100000,
    "pipSize": 0.0001,
    "pricePrecision": 5,
    "pipPrecision": 1,
    "description": "Euro vs US Dollar"
  },
  {
    "symbol": "USDJPY",
    "baseCcy": "USD",
    "quoteCcy": "JPY", 
    "lotUnits": 100000,
    "pipSize": 0.01,
    "pricePrecision": 3,
    "pipPrecision": 2,
    "description": "US Dollar vs Japanese Yen"
  }
]`}
          </pre>
        </CardContent>
      </Card>
    </div>
  );
}