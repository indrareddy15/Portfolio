import React from "react";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  LineChart,
  Line,
  Area,
  AreaChart,
  ComposedChart,
  Legend,
  ReferenceLine,
} from "recharts";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { TrendingUp, TrendingDown, BarChart3, PieChartIcon } from "lucide-react";

// Chart color configuration using design system tokens
const CHART_COLORS = {
  primary: "hsl(var(--primary))",
  primaryGlow: "hsl(var(--primary-glow))",
  success: "hsl(var(--success))",
  danger: "hsl(var(--danger))",
  warning: "hsl(var(--warning))",
  muted: "hsl(var(--muted-foreground))",
  background: "hsl(var(--background))",
  cardBg: "hsl(var(--card))",
};

const PIE_COLORS = [
  CHART_COLORS.primary,
  CHART_COLORS.success,
  CHART_COLORS.danger,
  CHART_COLORS.warning,
  CHART_COLORS.primaryGlow,
  CHART_COLORS.muted,
];

interface Trade {
  id: string;
  instrument: string;
  side: string;
  pnl: number;
  result: string;
  opened_at: string;
  size: number;
}

interface TradingChartsProps {
  trades: Trade[];
}

// Enhanced Custom Tooltip Component
const CustomTooltip = ({ active, payload, label }: any) => {
  if (active && payload && payload.length) {
    return (
      <div className="glass-card p-3 shadow-lg border-card-border">
        <p className="text-sm font-medium text-foreground">{label}</p>
        {payload.map((entry: any, index: number) => (
          <p key={index} className="text-sm" style={{ color: entry.color }}>
            {entry.name}: {typeof entry.value === 'number' ? entry.value.toFixed(2) : entry.value}
          </p>
        ))}
      </div>
    );
  }
  return null;
};

// P&L Bar Chart Component
export const PnLBarChart: React.FC<TradingChartsProps> = ({ trades }) => {
  const monthlyData = React.useMemo(() => {
    const grouped = trades.reduce((acc, trade) => {
      const month = new Date(trade.opened_at).toLocaleDateString('en-US', { 
        month: 'short', 
        year: 'numeric' 
      });
      if (!acc[month]) {
        acc[month] = { month, profit: 0, loss: 0, net: 0, trades: 0 };
      }
      acc[month].trades += 1;
      if (trade.pnl > 0) {
        acc[month].profit += trade.pnl;
      } else {
        acc[month].loss += Math.abs(trade.pnl);
      }
      acc[month].net += trade.pnl;
      return acc;
    }, {} as Record<string, any>);

    return Object.values(grouped).slice(-12); // Last 12 months
  }, [trades]);

  return (
    <Card className="glass-card border-card-border">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <BarChart3 className="h-5 w-5 text-primary" />
          Monthly P&L Performance
        </CardTitle>
      </CardHeader>
      <CardContent>
        <ResponsiveContainer width="100%" height={300}>
          <ComposedChart data={monthlyData}>
            <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
            <XAxis 
              dataKey="month" 
              stroke="hsl(var(--muted-foreground))"
              fontSize={12}
            />
            <YAxis stroke="hsl(var(--muted-foreground))" fontSize={12} />
            <Tooltip content={<CustomTooltip />} />
            <Legend />
            <Bar 
              dataKey="profit" 
              fill={CHART_COLORS.success} 
              name="Profit" 
              radius={[2, 2, 0, 0]}
            />
            <Bar 
              dataKey="loss" 
              fill={CHART_COLORS.danger} 
              name="Loss" 
              radius={[2, 2, 0, 0]}
            />
            <Line 
              type="monotone" 
              dataKey="net" 
              stroke={CHART_COLORS.primary} 
              strokeWidth={3}
              name="Net P&L"
              dot={{ fill: CHART_COLORS.primary, strokeWidth: 2, r: 4 }}
            />
          </ComposedChart>
        </ResponsiveContainer>
      </CardContent>
    </Card>
  );
};

// Instrument Distribution Pie Chart
export const InstrumentPieChart: React.FC<TradingChartsProps> = ({ trades }) => {
  const instrumentData = React.useMemo(() => {
    const grouped = trades.reduce((acc, trade) => {
      const instrument = trade.instrument || 'Unknown';
      if (!acc[instrument]) {
        acc[instrument] = { name: instrument, value: 0, trades: 0 };
      }
      acc[instrument].value += Math.abs(trade.pnl);
      acc[instrument].trades += 1;
      return acc;
    }, {} as Record<string, any>);

    return Object.values(grouped);
  }, [trades]);

  const renderCustomLabel = ({ cx, cy, midAngle, innerRadius, outerRadius, percent }: any) => {
    if (percent < 0.05) return null; // Don't show labels for slices < 5%
    
    const RADIAN = Math.PI / 180;
    const radius = innerRadius + (outerRadius - innerRadius) * 0.5;
    const x = cx + radius * Math.cos(-midAngle * RADIAN);
    const y = cy + radius * Math.sin(-midAngle * RADIAN);

    return (
      <text 
        x={x} 
        y={y} 
        fill="white" 
        textAnchor={x > cx ? 'start' : 'end'} 
        dominantBaseline="central"
        fontSize={12}
        fontWeight="500"
      >
        {`${(percent * 100).toFixed(0)}%`}
      </text>
    );
  };

  return (
    <Card className="glass-card border-card-border">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <PieChartIcon className="h-5 w-5 text-primary" />
          Trading Volume by Instrument
        </CardTitle>
      </CardHeader>
      <CardContent>
        <ResponsiveContainer width="100%" height={300}>
          <PieChart>
            <Pie
              data={instrumentData}
              cx="50%"
              cy="50%"
              labelLine={false}
              label={renderCustomLabel}
              outerRadius={100}
              fill="#8884d8"
              dataKey="value"
            >
              {instrumentData.map((entry, index) => (
                <Cell 
                  key={`cell-${index}`} 
                  fill={PIE_COLORS[index % PIE_COLORS.length]} 
                />
              ))}
            </Pie>
            <Tooltip 
              content={({ active, payload }) => {
                if (active && payload && payload.length) {
                  const data = payload[0].payload;
                  return (
                    <div className="glass-card p-3 shadow-lg border-card-border">
                      <p className="font-medium">{data.name}</p>
                      <p className="text-sm">Trades: {data.trades}</p>
                      <p className="text-sm">Volume: ${data.value.toFixed(2)}</p>
                    </div>
                  );
                }
                return null;
              }}
            />
            <Legend />
          </PieChart>
        </ResponsiveContainer>
      </CardContent>
    </Card>
  );
};

// Equity Curve Chart
export const EquityCurveChart: React.FC<TradingChartsProps> = ({ trades }) => {
  const equityCurveData = React.useMemo(() => {
    const sortedTrades = [...trades].sort((a, b) => 
      new Date(a.opened_at).getTime() - new Date(b.opened_at).getTime()
    );

    let runningTotal = 0;
    return sortedTrades.map((trade, index) => {
      runningTotal += trade.pnl;
      return {
        trade: index + 1,
        equity: runningTotal,
        pnl: trade.pnl,
        date: new Date(trade.opened_at).toLocaleDateString(),
        instrument: trade.instrument,
      };
    });
  }, [trades]);

  return (
    <Card className="glass-card border-card-border">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <TrendingUp className="h-5 w-5 text-primary" />
          Equity Curve
        </CardTitle>
      </CardHeader>
      <CardContent>
        <ResponsiveContainer width="100%" height={300}>
          <AreaChart data={equityCurveData}>
            <defs>
              <linearGradient id="equityGradient" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor={CHART_COLORS.primary} stopOpacity={0.3}/>
                <stop offset="95%" stopColor={CHART_COLORS.primary} stopOpacity={0}/>
              </linearGradient>
            </defs>
            <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
            <XAxis 
              dataKey="trade" 
              stroke="hsl(var(--muted-foreground))"
              fontSize={12}
            />
            <YAxis stroke="hsl(var(--muted-foreground))" fontSize={12} />
            <Tooltip 
              content={({ active, payload, label }) => {
                if (active && payload && payload.length) {
                  const data = payload[0].payload;
                  return (
                    <div className="glass-card p-3 shadow-lg border-card-border">
                      <p className="font-medium">Trade #{label}</p>
                      <p className="text-sm">Date: {data.date}</p>
                      <p className="text-sm">Instrument: {data.instrument}</p>
                      <p className="text-sm">Trade P&L: ${data.pnl.toFixed(2)}</p>
                      <p className="text-sm font-medium">Total Equity: ${data.equity.toFixed(2)}</p>
                    </div>
                  );
                }
                return null;
              }}
            />
            <Area
              type="monotone"
              dataKey="equity"
              stroke={CHART_COLORS.primary}
              strokeWidth={2}
              fillOpacity={1}
              fill="url(#equityGradient)"
            />
            <ReferenceLine y={0} stroke={CHART_COLORS.muted} strokeDasharray="2 2" />
          </AreaChart>
        </ResponsiveContainer>
      </CardContent>
    </Card>
  );
};

// Win/Loss Ratio Histogram
export const WinLossHistogram: React.FC<TradingChartsProps> = ({ trades }) => {
  const histogramData = React.useMemo(() => {
    // Create P&L buckets
    const buckets: Record<string, number> = {};
    const bucketSize = 100; // $100 buckets
    
    trades.forEach(trade => {
      const bucket = Math.floor(trade.pnl / bucketSize) * bucketSize;
      const bucketKey = `$${bucket}`;
      buckets[bucketKey] = (buckets[bucketKey] || 0) + 1;
    });

    return Object.entries(buckets)
      .map(([range, count]) => ({ range, count, pnl: parseInt(range.slice(1)) }))
      .sort((a, b) => a.pnl - b.pnl);
  }, [trades]);

  return (
    <Card className="glass-card border-card-border">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <BarChart3 className="h-5 w-5 text-primary" />
          P&L Distribution Histogram
        </CardTitle>
      </CardHeader>
      <CardContent>
        <ResponsiveContainer width="100%" height={300}>
          <BarChart data={histogramData}>
            <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
            <XAxis 
              dataKey="range" 
              stroke="hsl(var(--muted-foreground))"
              fontSize={12}
              angle={-45}
              textAnchor="end"
              height={60}
            />
            <YAxis stroke="hsl(var(--muted-foreground))" fontSize={12} />
            <Tooltip content={<CustomTooltip />} />
            <Bar 
              dataKey="count" 
              fill={CHART_COLORS.primary}
              name="Trade Count"
              radius={[2, 2, 0, 0]}
            />
          </BarChart>
        </ResponsiveContainer>
      </CardContent>
    </Card>
  );
};

// Daily Trading Activity Heatmap-style Chart
export const DailyActivityChart: React.FC<TradingChartsProps> = ({ trades }) => {
  const dailyData = React.useMemo(() => {
    const grouped = trades.reduce((acc, trade) => {
      const date = new Date(trade.opened_at).toLocaleDateString();
      if (!acc[date]) {
        acc[date] = { 
          date, 
          trades: 0, 
          totalPnL: 0, 
          wins: 0, 
          losses: 0,
          winRate: 0 
        };
      }
      acc[date].trades += 1;
      acc[date].totalPnL += trade.pnl;
      if (trade.pnl > 0) acc[date].wins += 1;
      else if (trade.pnl < 0) acc[date].losses += 1;
      acc[date].winRate = acc[date].wins / acc[date].trades * 100;
      return acc;
    }, {} as Record<string, any>);

    return Object.values(grouped)
      .sort((a: any, b: any) => new Date(a.date).getTime() - new Date(b.date).getTime())
      .slice(-30); // Last 30 days
  }, [trades]);

  return (
    <Card className="glass-card border-card-border">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <TrendingUp className="h-5 w-5 text-primary" />
          Daily Trading Activity (Last 30 Days)
        </CardTitle>
      </CardHeader>
      <CardContent>
        <ResponsiveContainer width="100%" height={300}>
          <ComposedChart data={dailyData}>
            <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
            <XAxis 
              dataKey="date" 
              stroke="hsl(var(--muted-foreground))"
              fontSize={10}
              angle={-45}
              textAnchor="end"
              height={80}
            />
            <YAxis yAxisId="left" stroke="hsl(var(--muted-foreground))" fontSize={12} />
            <YAxis yAxisId="right" orientation="right" stroke="hsl(var(--muted-foreground))" fontSize={12} />
            <Tooltip content={<CustomTooltip />} />
            <Legend />
            <Bar 
              yAxisId="left"
              dataKey="trades" 
              fill={CHART_COLORS.primary} 
              name="Daily Trades"
              radius={[2, 2, 0, 0]}
            />
            <Line 
              yAxisId="right"
              type="monotone" 
              dataKey="winRate" 
              stroke={CHART_COLORS.success} 
              strokeWidth={2}
              name="Win Rate %"
              dot={{ fill: CHART_COLORS.success, strokeWidth: 2, r: 3 }}
            />
          </ComposedChart>
        </ResponsiveContainer>
      </CardContent>
    </Card>
  );
};