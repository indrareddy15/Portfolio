import React, { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import {
  LineChart,
  Line,
  AreaChart,
  Area,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
} from "recharts";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import {
  TrendingUp,
  TrendingDown,
  DollarSign,
  Activity,
  BarChart3,
  PieChartIcon,
  Target,
  Calendar,
} from "lucide-react";

// Chart colors using design system
const CHART_COLORS = {
  primary: "hsl(var(--primary))",
  success: "hsl(var(--success))",
  danger: "hsl(var(--danger))",
  warning: "hsl(var(--warning))",
  muted: "hsl(var(--muted-foreground))",
};

const PIE_COLORS = [
  CHART_COLORS.primary,
  CHART_COLORS.success,
  CHART_COLORS.danger,
  CHART_COLORS.warning,
  "hsl(var(--primary-glow))",
  CHART_COLORS.muted,
];

interface Trade {
  id: string;
  instrument: string;
  pnl: number;
  result: string;
  opened_at: string;
  side: string;
}

interface DashboardStats {
  totalTrades: number;
  winRate: number;
  totalPnL: number;
  monthlyPnL: number;
}

// Custom Tooltip
const CustomTooltip = ({ active, payload, label }: any) => {
  if (active && payload && payload.length) {
    return (
      <div className="glass-card p-3 shadow-lg border-card-border">
        <p className="text-sm font-medium text-foreground">{label}</p>
        {payload.map((entry: any, index: number) => (
          <p key={index} className="text-sm" style={{ color: entry.color }}>
            {entry.name}: {typeof entry.value === 'number' ? 
              (entry.name.includes('Rate') || entry.name.includes('%') ? 
                `${entry.value.toFixed(1)}%` : 
                `$${entry.value.toFixed(2)}`
              ) : entry.value}
          </p>
        ))}
      </div>
    );
  }
  return null;
};

// Main Dashboard Charts Component
export const DashboardCharts: React.FC = () => {
  const { user } = useAuth();
  const [trades, setTrades] = useState<Trade[]>([]);
  const [stats, setStats] = useState<DashboardStats>({
    totalTrades: 0,
    winRate: 0,
    totalPnL: 0,
    monthlyPnL: 0,
  });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (user) {
      fetchData();
    }
  }, [user]);

  const fetchData = async () => {
    try {
      setLoading(true);
      
      // Fetch trades
      const { data: tradesData, error } = await supabase
        .from('trades')
        .select('*')
        .eq('user_id', user?.id)
        .order('opened_at', { ascending: true });

      if (error) throw error;

      setTrades(tradesData || []);
      
      // Calculate stats
      if (tradesData && tradesData.length > 0) {
        const totalTrades = tradesData.length;
        const wins = tradesData.filter(t => t.pnl > 0).length;
        const winRate = (wins / totalTrades) * 100;
        const totalPnL = tradesData.reduce((sum, t) => sum + t.pnl, 0);
        
        // Calculate monthly P&L
        const currentMonth = new Date().getMonth();
        const currentYear = new Date().getFullYear();
        const monthlyPnL = tradesData
          .filter(t => {
            const tradeDate = new Date(t.opened_at);
            return tradeDate.getMonth() === currentMonth && 
                   tradeDate.getFullYear() === currentYear;
          })
          .reduce((sum, t) => sum + t.pnl, 0);

        setStats({ totalTrades, winRate, totalPnL, monthlyPnL });
      }
    } catch (error) {
      console.error('Error fetching data:', error);
    } finally {
      setLoading(false);
    }
  };

  // Prepare chart data
  const weeklyData = React.useMemo(() => {
    if (!trades.length) return [];
    
    const last7Days = Array.from({ length: 7 }, (_, i) => {
      const date = new Date();
      date.setDate(date.getDate() - (6 - i));
      return {
        date: date.toLocaleDateString('en-US', { weekday: 'short' }),
        pnl: 0,
        trades: 0,
        wins: 0,
        losses: 0,
      };
    });

    trades.forEach(trade => {
      const tradeDate = new Date(trade.opened_at);
      const dayIndex = Math.floor((Date.now() - tradeDate.getTime()) / (1000 * 60 * 60 * 24));
      
      if (dayIndex >= 0 && dayIndex < 7) {
        const dataIndex = 6 - dayIndex;
        last7Days[dataIndex].pnl += trade.pnl;
        last7Days[dataIndex].trades += 1;
        if (trade.pnl > 0) {
          last7Days[dataIndex].wins += 1;
        } else if (trade.pnl < 0) {
          last7Days[dataIndex].losses += 1;
        }
      }
    });

    return last7Days;
  }, [trades]);

  const instrumentData = React.useMemo(() => {
    if (!trades.length) return [];
    
    const grouped = trades.reduce((acc, trade) => {
      const instrument = trade.instrument || 'Unknown';
      if (!acc[instrument]) {
        acc[instrument] = { name: instrument, trades: 0, pnl: 0 };
      }
      acc[instrument].trades += 1;
      acc[instrument].pnl += trade.pnl;
      return acc;
    }, {} as Record<string, any>);

    return Object.values(grouped).slice(0, 6); // Top 6 instruments
  }, [trades]);

  if (loading) {
    return (
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="h-96 bg-muted/20 animate-pulse rounded-lg" />
        <div className="h-96 bg-muted/20 animate-pulse rounded-lg" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Enhanced Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <Card className="glass-card border-card-border glow-hover">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              Total Trades
            </CardTitle>
            <Activity className="h-4 w-4 text-primary" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-foreground">{stats.totalTrades}</div>
            <div className="flex items-center pt-1">
              <TrendingUp className="h-3 w-3 text-success mr-1" />
              <p className="text-xs text-success">
                +{weeklyData.reduce((sum, day) => sum + day.trades, 0)} this week
              </p>
            </div>
          </CardContent>
        </Card>

        <Card className="glass-card border-card-border glow-hover">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              Win Rate
            </CardTitle>
            <Target className="h-4 w-4 text-primary" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-foreground">
              {stats.winRate.toFixed(1)}%
            </div>
            <div className="flex items-center pt-1">
              <Badge variant={stats.winRate >= 50 ? "default" : "destructive"} className="text-xs">
                {stats.winRate >= 50 ? 'Good' : 'Needs Work'}
              </Badge>
            </div>
          </CardContent>
        </Card>

        <Card className="glass-card border-card-border glow-hover">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              Total P&L
            </CardTitle>
            <DollarSign className="h-4 w-4 text-primary" />
          </CardHeader>
          <CardContent>
            <div className={`text-2xl font-bold ${
              stats.totalPnL >= 0 ? 'text-success' : 'text-danger'
            }`}>
              ${stats.totalPnL.toFixed(2)}
            </div>
            <div className="flex items-center pt-1">
              {stats.totalPnL >= 0 ? (
                <TrendingUp className="h-3 w-3 text-success mr-1" />
              ) : (
                <TrendingDown className="h-3 w-3 text-danger mr-1" />
              )}
              <p className={`text-xs ${stats.totalPnL >= 0 ? 'text-success' : 'text-danger'}`}>
                {stats.totalPnL >= 0 ? 'Profitable' : 'Loss'}
              </p>
            </div>
          </CardContent>
        </Card>

        <Card className="glass-card border-card-border glow-hover">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              This Month
            </CardTitle>
            <Calendar className="h-4 w-4 text-primary" />
          </CardHeader>
          <CardContent>
            <div className={`text-2xl font-bold ${
              stats.monthlyPnL >= 0 ? 'text-success' : 'text-danger'
            }`}>
              ${stats.monthlyPnL.toFixed(2)}
            </div>
            <div className="flex items-center pt-1">
              <Badge 
                variant={stats.monthlyPnL >= 0 ? "default" : "destructive"} 
                className="text-xs"
              >
                {new Date().toLocaleDateString('en-US', { month: 'short' })}
              </Badge>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Charts Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Weekly Performance Chart */}
        <Card className="glass-card border-card-border">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <BarChart3 className="h-5 w-5 text-primary" />
              Weekly Performance
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={280}>
              <AreaChart data={weeklyData}>
                <defs>
                  <linearGradient id="pnlGradient" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor={CHART_COLORS.primary} stopOpacity={0.3}/>
                    <stop offset="95%" stopColor={CHART_COLORS.primary} stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                <XAxis 
                  dataKey="date" 
                  stroke="hsl(var(--muted-foreground))"
                  fontSize={12}
                />
                <YAxis stroke="hsl(var(--muted-foreground))" fontSize={12} />
                <Tooltip content={<CustomTooltip />} />
                <Area
                  type="monotone"
                  dataKey="pnl"
                  stroke={CHART_COLORS.primary}
                  strokeWidth={2}
                  fillOpacity={1}
                  fill="url(#pnlGradient)"
                  name="Daily P&L"
                />
              </AreaChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Instrument Distribution */}
        <Card className="glass-card border-card-border">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <PieChartIcon className="h-5 w-5 text-primary" />
              Top Instruments
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={280}>
              <PieChart>
                <Pie
                  data={instrumentData}
                  cx="50%"
                  cy="50%"
                  innerRadius={60}
                  outerRadius={100}
                  paddingAngle={5}
                  dataKey="trades"
                >
                  {instrumentData.map((entry, index) => (
                    <Cell 
                      key={`cell-${index}`} 
                      fill={PIE_COLORS[index % PIE_COLORS.length]} 
                    />
                  ))}
                </Pie>
                <Tooltip 
                  content={({ active, payload }) => {
                    if (active && payload && payload.length) {
                      const data = payload[0].payload;
                      return (
                        <div className="glass-card p-3 shadow-lg border-card-border">
                          <p className="font-medium">{data.name}</p>
                          <p className="text-sm">Trades: {data.trades}</p>
                          <p className="text-sm">P&L: ${data.pnl.toFixed(2)}</p>
                        </div>
                      );
                    }
                    return null;
                  }}
                />
              </PieChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Win/Loss Breakdown */}
        <Card className="glass-card border-card-border">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Target className="h-5 w-5 text-primary" />
              Win/Loss Breakdown
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={280}>
              <BarChart data={weeklyData}>
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                <XAxis 
                  dataKey="date" 
                  stroke="hsl(var(--muted-foreground))"
                  fontSize={12}
                />
                <YAxis stroke="hsl(var(--muted-foreground))" fontSize={12} />
                <Tooltip content={<CustomTooltip />} />
                <Bar 
                  dataKey="wins" 
                  stackId="a"
                  fill={CHART_COLORS.success} 
                  name="Wins"
                  radius={[0, 0, 0, 0]}
                />
                <Bar 
                  dataKey="losses" 
                  stackId="a"
                  fill={CHART_COLORS.danger} 
                  name="Losses"
                  radius={[4, 4, 0, 0]}
                />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Trading Activity Trend */}
        <Card className="glass-card border-card-border">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Activity className="h-5 w-5 text-primary" />
              Trading Activity
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={280}>
              <LineChart data={weeklyData}>
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                <XAxis 
                  dataKey="date" 
                  stroke="hsl(var(--muted-foreground))"
                  fontSize={12}
                />
                <YAxis stroke="hsl(var(--muted-foreground))" fontSize={12} />
                <Tooltip content={<CustomTooltip />} />
                <Line 
                  type="monotone" 
                  dataKey="trades" 
                  stroke={CHART_COLORS.primary} 
                  strokeWidth={3}
                  name="Daily Trades"
                  dot={{ fill: CHART_COLORS.primary, strokeWidth: 2, r: 4 }}
                  activeDot={{ r: 6, stroke: CHART_COLORS.primary, strokeWidth: 2 }}
                />
              </LineChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};