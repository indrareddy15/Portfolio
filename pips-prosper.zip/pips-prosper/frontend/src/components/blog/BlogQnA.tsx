import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { 
  MessageCircle, 
  ThumbsUp, 
  User, 
  Clock,
  CheckCircle,
  Star
} from "lucide-react";
import { format } from "date-fns";

interface BlogQnAProps {
  qnaId: string;
}

interface QnASection {
  id: string;
  title: string;
  description?: string;
  is_active: boolean;
  allow_anonymous: boolean;
  moderated: boolean;
}

interface Question {
  id: string;
  user_id?: string;
  author_name?: string;
  author_email?: string;
  question: string;
  is_approved: boolean;
  is_featured: boolean;
  upvotes: number;
  created_at: string;
  answers?: Answer[];
}

interface Answer {
  id: string;
  author_id?: string;
  answer: string;
  is_official: boolean;
  created_at: string;
  author?: {
    name: string;
  };
}

export default function BlogQnA({ qnaId }: BlogQnAProps) {
  const [qna, setQna] = useState<QnASection | null>(null);
  const [questions, setQuestions] = useState<Question[]>([]);
  const [showQuestionForm, setShowQuestionForm] = useState(false);
  const [submittingQuestion, setSubmittingQuestion] = useState(false);
  const [questionData, setQuestionData] = useState({
    question: '',
    author_name: '',
    author_email: ''
  });

  useEffect(() => {
    fetchQnASection();
    fetchQuestions();
  }, [qnaId]);

  const fetchQnASection = async () => {
    try {
      const { data, error } = await supabase
        .from('blog_qna')
        .select('*')
        .eq('id', qnaId)
        .eq('is_active', true)
        .single();

      if (error) throw error;
      setQna(data);
    } catch (error) {
      console.error('Error fetching Q&A section:', error);
      toast.error('Failed to load Q&A section');
    }
  };

  const fetchQuestions = async () => {
    try {
      const { data, error } = await supabase
        .from('blog_qna_questions')
        .select(`
          *,
          answers:blog_qna_answers(
            *,
            author:blog_authors(name)
          )
        `)
        .eq('qna_id', qnaId)
        .eq('is_approved', true)
        .order('is_featured', { ascending: false })
        .order('upvotes', { ascending: false })
        .order('created_at', { ascending: false });

      if (error) throw error;
      setQuestions(data || []);
    } catch (error) {
      console.error('Error fetching questions:', error);
    }
  };

  const handleSubmitQuestion = async () => {
    if (!questionData.question.trim()) {
      toast.error('Please enter your question');
      return;
    }

    if (!qna?.allow_anonymous && (!questionData.author_name || !questionData.author_email)) {
      toast.error('Please provide your name and email');
      return;
    }

    setSubmittingQuestion(true);
    try {
      const { data: { user } } = await supabase.auth.getUser();
      
      const submitData: any = {
        qna_id: qnaId,
        question: questionData.question.trim(),
        is_approved: !qna?.moderated // Auto-approve if not moderated
      };

      if (user) {
        submitData.user_id = user.id;
      } else {
        submitData.author_name = questionData.author_name.trim();
        submitData.author_email = questionData.author_email.trim();
      }

      const { error } = await supabase
        .from('blog_qna_questions')
        .insert(submitData);

      if (error) throw error;

      toast.success(
        qna?.moderated 
          ? 'Question submitted! It will appear after approval.'
          : 'Question submitted successfully!'
      );

      setQuestionData({ question: '', author_name: '', author_email: '' });
      setShowQuestionForm(false);
      
      if (!qna?.moderated) {
        await fetchQuestions();
      }
    } catch (error) {
      console.error('Error submitting question:', error);
      toast.error('Failed to submit question');
    } finally {
      setSubmittingQuestion(false);
    }
  };

  const handleUpvoteQuestion = async (questionId: string) => {
    // This would typically check if user has already upvoted
    // For now, we'll implement basic upvoting
    try {
      const question = questions.find(q => q.id === questionId);
      if (!question) return;

      const { error } = await supabase
        .from('blog_qna_questions')
        .update({ upvotes: question.upvotes + 1 })
        .eq('id', questionId);

      if (error) throw error;

      setQuestions(prev => prev.map(q => 
        q.id === questionId ? { ...q, upvotes: q.upvotes + 1 } : q
      ));

      toast.success('Question upvoted!');
    } catch (error) {
      console.error('Error upvoting question:', error);
      toast.error('Failed to upvote question');
    }
  };

  if (!qna) {
    return (
      <Card>
        <CardContent className="p-6">
          <div className="text-center text-muted-foreground">
            Loading Q&A section...
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="my-6">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          ❓ {qna.title}
        </CardTitle>
        {qna.description && (
          <p className="text-muted-foreground">{qna.description}</p>
        )}
      </CardHeader>

      <CardContent className="space-y-6">
        {/* Ask Question Section */}
        <div className="space-y-4">
          {!showQuestionForm ? (
            <Button 
              onClick={() => setShowQuestionForm(true)}
              className="w-full"
            >
              <MessageCircle className="w-4 h-4 mr-2" />
              Ask a Question
            </Button>
          ) : (
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Ask Your Question</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <Label htmlFor="question">Your Question *</Label>
                  <Textarea
                    id="question"
                    value={questionData.question}
                    onChange={(e) => setQuestionData(prev => ({ 
                      ...prev, 
                      question: e.target.value 
                    }))}
                    placeholder="What would you like to know?"
                    rows={3}
                  />
                </div>

                {!qna.allow_anonymous && (
                  <>
                    <div>
                      <Label htmlFor="author-name">Your Name *</Label>
                      <Input
                        id="author-name"
                        value={questionData.author_name}
                        onChange={(e) => setQuestionData(prev => ({ 
                          ...prev, 
                          author_name: e.target.value 
                        }))}
                        placeholder="Your name"
                      />
                    </div>

                    <div>
                      <Label htmlFor="author-email">Your Email *</Label>
                      <Input
                        id="author-email"
                        type="email"
                        value={questionData.author_email}
                        onChange={(e) => setQuestionData(prev => ({ 
                          ...prev, 
                          author_email: e.target.value 
                        }))}
                        placeholder="your.email@example.com"
                      />
                    </div>
                  </>
                )}

                {qna.moderated && (
                  <div className="text-sm text-muted-foreground p-3 bg-muted rounded-md">
                    <strong>Note:</strong> Questions are moderated and will appear after approval.
                  </div>
                )}

                <div className="flex gap-2">
                  <Button 
                    onClick={handleSubmitQuestion} 
                    disabled={submittingQuestion}
                    className="flex-1"
                  >
                    {submittingQuestion ? 'Submitting...' : 'Submit Question'}
                  </Button>
                  <Button 
                    variant="outline" 
                    onClick={() => setShowQuestionForm(false)}
                  >
                    Cancel
                  </Button>
                </div>
              </CardContent>
            </Card>
          )}
        </div>

        {/* Questions & Answers */}
        <div className="space-y-6">
          <h3 className="text-lg font-semibold">
            Questions & Answers ({questions.length})
          </h3>

          {questions.length === 0 ? (
            <div className="text-center text-muted-foreground p-8">
              No questions yet. Be the first to ask!
            </div>
          ) : (
            <div className="space-y-6">
              {questions.map((question) => (
                <Card key={question.id} className="relative">
                  {question.is_featured && (
                    <div className="absolute top-2 right-2">
                      <Badge variant="secondary" className="gap-1">
                        <Star className="w-3 h-3" />
                        Featured
                      </Badge>
                    </div>
                  )}

                  <CardHeader className="pb-3">
                    <div className="flex items-start justify-between gap-4">
                      <div className="flex-1">
                        <p className="text-base leading-relaxed">{question.question}</p>
                      </div>
                    </div>
                    
                    <div className="flex items-center justify-between text-sm text-muted-foreground">
                      <div className="flex items-center gap-2">
                        <User className="w-3 h-3" />
                        <span>{question.author_name || 'Anonymous'}</span>
                        <Clock className="w-3 h-3" />
                        <span>{format(new Date(question.created_at), 'MMM d, yyyy')}</span>
                      </div>
                      
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => handleUpvoteQuestion(question.id)}
                        className="flex items-center gap-1 text-muted-foreground hover:text-foreground"
                      >
                        <ThumbsUp className="w-3 h-3" />
                        {question.upvotes}
                      </Button>
                    </div>
                  </CardHeader>

                  {question.answers && question.answers.length > 0 && (
                    <CardContent className="pt-0">
                      <div className="space-y-4">
                        <div className="border-t pt-4">
                          <h4 className="text-sm font-medium flex items-center gap-2 mb-3">
                            <MessageCircle className="w-4 h-4" />
                            Answers ({question.answers.length})
                          </h4>
                          
                          <div className="space-y-3">
                            {question.answers.map((answer) => (
                              <div 
                                key={answer.id} 
                                className={`p-3 rounded-md ${
                                  answer.is_official 
                                    ? 'bg-primary/5 border border-primary/20' 
                                    : 'bg-muted'
                                }`}
                              >
                                <div className="flex items-start justify-between gap-2 mb-2">
                                  <div className="flex items-center gap-2">
                                    {answer.is_official && (
                                      <Badge variant="default" className="gap-1">
                                        <CheckCircle className="w-3 h-3" />
                                        Official Answer
                                      </Badge>
                                    )}
                                    {answer.author?.name && (
                                      <span className="text-sm font-medium">
                                        {answer.author.name}
                                      </span>
                                    )}
                                  </div>
                                  <span className="text-xs text-muted-foreground">
                                    {format(new Date(answer.created_at), 'MMM d, yyyy')}
                                  </span>
                                </div>
                                
                                <p className="text-sm leading-relaxed">{answer.answer}</p>
                              </div>
                            ))}
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  )}
                </Card>
              ))}
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
}