import { useState, useEffect } from "react";
import { 
  Dialog, 
  DialogContent, 
  DialogHeader, 
  DialogTitle,
  DialogFooter
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { X, Plus } from "lucide-react";
import { toast } from "sonner";

interface Poll {
  id?: string;
  title: string;
  description?: string;
  poll_type: 'single' | 'multiple';
  options_json: string[];
  allow_custom_answers: boolean;
  expires_at?: string;
  is_active: boolean;
  position: number;
}

interface PollDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onSave: (poll: Omit<Poll, 'id'>) => void;
  poll?: Poll | null;
}

export default function PollDialog({ open, onOpenChange, onSave, poll }: PollDialogProps) {
  const [formData, setFormData] = useState<Omit<Poll, 'id'>>({
    title: '',
    description: '',
    poll_type: 'single',
    options_json: ['', ''],
    allow_custom_answers: false,
    expires_at: '',
    is_active: true,
    position: 0
  });

  useEffect(() => {
    if (poll) {
      setFormData({
        title: poll.title,
        description: poll.description || '',
        poll_type: poll.poll_type,
        options_json: poll.options_json,
        allow_custom_answers: poll.allow_custom_answers,
        expires_at: poll.expires_at || '',
        is_active: poll.is_active,
        position: poll.position
      });
    } else {
      setFormData({
        title: '',
        description: '',
        poll_type: 'single',
        options_json: ['', ''],
        allow_custom_answers: false,
        expires_at: '',
        is_active: true,
        position: 0
      });
    }
  }, [poll, open]);

  const handleAddOption = () => {
    if (formData.options_json.length < 10) {
      setFormData(prev => ({
        ...prev,
        options_json: [...prev.options_json, '']
      }));
    } else {
      toast.error('Maximum 10 options allowed');
    }
  };

  const handleRemoveOption = (index: number) => {
    if (formData.options_json.length > 2) {
      setFormData(prev => ({
        ...prev,
        options_json: prev.options_json.filter((_, i) => i !== index)
      }));
    } else {
      toast.error('Minimum 2 options required');
    }
  };

  const handleOptionChange = (index: number, value: string) => {
    setFormData(prev => ({
      ...prev,
      options_json: prev.options_json.map((opt, i) => i === index ? value : opt)
    }));
  };

  const handleSave = () => {
    if (!formData.title.trim()) {
      toast.error('Poll title is required');
      return;
    }

    const validOptions = formData.options_json.filter(opt => opt.trim());
    if (validOptions.length < 2) {
      toast.error('At least 2 options are required');
      return;
    }

    onSave({
      ...formData,
      options_json: validOptions
    });
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl max-h-[80vh] overflow-auto">
        <DialogHeader>
          <DialogTitle>{poll ? 'Edit Poll' : 'Create Poll'}</DialogTitle>
        </DialogHeader>

        <div className="space-y-4">
          <div>
            <Label htmlFor="poll-title">Title *</Label>
            <Input
              id="poll-title"
              value={formData.title}
              onChange={(e) => setFormData(prev => ({ ...prev, title: e.target.value }))}
              placeholder="What's your question?"
            />
          </div>

          <div>
            <Label htmlFor="poll-description">Description (optional)</Label>
            <Textarea
              id="poll-description"
              value={formData.description}
              onChange={(e) => setFormData(prev => ({ ...prev, description: e.target.value }))}
              placeholder="Additional context for your poll..."
              rows={2}
            />
          </div>

          <div>
            <Label>Poll Type</Label>
            <RadioGroup
              value={formData.poll_type}
              onValueChange={(value: 'single' | 'multiple') => 
                setFormData(prev => ({ ...prev, poll_type: value }))
              }
              className="flex gap-6 mt-2"
            >
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="single" id="single" />
                <Label htmlFor="single">Single Choice</Label>
              </div>
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="multiple" id="multiple" />
                <Label htmlFor="multiple">Multiple Choice</Label>
              </div>
            </RadioGroup>
          </div>

          <div>
            <div className="flex items-center justify-between mb-2">
              <Label>Options *</Label>
              <Button
                type="button"
                variant="outline"
                size="sm"
                onClick={handleAddOption}
                disabled={formData.options_json.length >= 10}
              >
                <Plus className="w-3 h-3 mr-1" />
                Add Option
              </Button>
            </div>
            
            <div className="space-y-2">
              {formData.options_json.map((option, index) => (
                <div key={index} className="flex gap-2">
                  <Input
                    value={option}
                    onChange={(e) => handleOptionChange(index, e.target.value)}
                    placeholder={`Option ${index + 1}`}
                    className="flex-1"
                  />
                  {formData.options_json.length > 2 && (
                    <Button
                      type="button"
                      variant="outline"
                      size="sm"
                      onClick={() => handleRemoveOption(index)}
                    >
                      <X className="w-3 h-3" />
                    </Button>
                  )}
                </div>
              ))}
            </div>
          </div>

          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <Switch
                id="allow-custom"
                checked={formData.allow_custom_answers}
                onCheckedChange={(checked) => 
                  setFormData(prev => ({ ...prev, allow_custom_answers: checked }))
                }
              />
              <Label htmlFor="allow-custom">Allow custom answers</Label>
            </div>

            <div className="flex items-center space-x-2">
              <Switch
                id="is-active"
                checked={formData.is_active}
                onCheckedChange={(checked) => 
                  setFormData(prev => ({ ...prev, is_active: checked }))
                }
              />
              <Label htmlFor="is-active">Active</Label>
            </div>
          </div>

          <div>
            <Label htmlFor="expires-at">Expires At (optional)</Label>
            <Input
              id="expires-at"
              type="datetime-local"
              value={formData.expires_at}
              onChange={(e) => setFormData(prev => ({ ...prev, expires_at: e.target.value }))}
            />
          </div>
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            Cancel
          </Button>
          <Button onClick={handleSave}>
            {poll ? 'Update Poll' : 'Create Poll'}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}