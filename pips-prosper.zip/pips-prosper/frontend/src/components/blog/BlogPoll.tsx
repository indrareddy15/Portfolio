import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Progress } from "@/components/ui/progress";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Checkbox } from "@/components/ui/checkbox";
import { Label } from "@/components/ui/label";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { Clock, Users } from "lucide-react";

interface PollOption {
  text: string;
  votes: number;
}

interface BlogPollProps {
  pollId: string;
}

interface Poll {
  id: string;
  title: string;
  description?: string;
  poll_type: 'single' | 'multiple';
  options_json: string[];
  allow_custom_answers: boolean;
  expires_at?: string;
  is_active: boolean;
  total_votes: number;
}

interface Vote {
  selected_options: number[];
  custom_answer?: string;
}

export default function BlogPoll({ pollId }: BlogPollProps) {
  const [poll, setPoll] = useState<Poll | null>(null);
  const [pollResults, setPollResults] = useState<PollOption[]>([]);
  const [userVote, setUserVote] = useState<Vote | null>(null);
  const [selectedOptions, setSelectedOptions] = useState<number[]>([]);
  const [customAnswer, setCustomAnswer] = useState('');
  const [showResults, setShowResults] = useState(false);
  const [voting, setVoting] = useState(false);
  const [hasVoted, setHasVoted] = useState(false);

  useEffect(() => {
    fetchPoll();
    checkUserVote();
  }, [pollId]);

  const fetchPoll = async () => {
    try {
      const { data: pollData, error } = await supabase
        .from('blog_polls')
        .select('*')
        .eq('id', pollId)
        .eq('is_active', true)
        .single();

      if (error) throw error;

      if (pollData) {
        setPoll(pollData as Poll);
        await fetchPollResults(pollData as Poll);
        
        // Check if poll has expired
        if (pollData.expires_at && new Date(pollData.expires_at) < new Date()) {
          setShowResults(true);
        }
      }
    } catch (error) {
      console.error('Error fetching poll:', error);
      toast.error('Failed to load poll');
    }
  };

  const fetchPollResults = async (pollData: Poll) => {
    try {
      const { data: votes, error } = await supabase
        .from('blog_poll_votes')
        .select('selected_options, custom_answer')
        .eq('poll_id', pollId);

      if (error) throw error;

      // Calculate vote counts for each option
      const optionCounts: { [key: number]: number } = {};
      pollData.options_json.forEach((_, index) => {
        optionCounts[index] = 0;
      });

      votes?.forEach(vote => {
        // Safely parse selected_options from Json to number[]
        const options = Array.isArray(vote.selected_options) 
          ? (vote.selected_options as any[]).filter(item => typeof item === 'number') 
          : [];
        
        options.forEach((optionIndex: number) => {
          if (optionCounts[optionIndex] !== undefined) {
            optionCounts[optionIndex]++;
          }
        });
      });

      const results: PollOption[] = pollData.options_json.map((text, index) => ({
        text,
        votes: optionCounts[index] || 0
      }));

      setPollResults(results);
    } catch (error) {
      console.error('Error fetching poll results:', error);
    }
  };

  const checkUserVote = async () => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      
      if (user) {
        const { data: vote } = await supabase
          .from('blog_poll_votes')
          .select('selected_options, custom_answer')
          .eq('poll_id', pollId)
          .eq('user_id', user.id)
          .single();

        if (vote) {
          // Safely parse selected_options from Json to number[]
          const selectedOptions = Array.isArray(vote.selected_options) 
            ? (vote.selected_options as any[]).filter(item => typeof item === 'number')
            : [];
          
          setUserVote({
            selected_options: selectedOptions,
            custom_answer: vote.custom_answer || undefined
          });
          setHasVoted(true);
          setShowResults(true);
        }
      } else {
        // Check for anonymous vote by IP (simplified - you might want to use localStorage)
        const anonymousVoteKey = `poll_vote_${pollId}`;
        const storedVote = localStorage.getItem(anonymousVoteKey);
        if (storedVote) {
          setUserVote(JSON.parse(storedVote));
          setHasVoted(true);
          setShowResults(true);
        }
      }
    } catch (error) {
      console.error('Error checking user vote:', error);
    }
  };

  const handleVote = async () => {
    if (selectedOptions.length === 0) {
      toast.error('Please select at least one option');
      return;
    }

    setVoting(true);
    try {
      const { data: { user } } = await supabase.auth.getUser();
      
      const voteData: any = {
        poll_id: pollId,
        selected_options: selectedOptions,
        custom_answer: customAnswer || null
      };

      if (user) {
        voteData.user_id = user.id;
      } else {
        // Store IP for anonymous voting (handled by RLS policies)
        voteData.ip_address = null; // Will be set by the server
      }

      const { error } = await supabase
        .from('blog_poll_votes')
        .insert(voteData);

      if (error) throw error;

      // Store vote locally for anonymous users
      if (!user) {
        const anonymousVoteKey = `poll_vote_${pollId}`;
        localStorage.setItem(anonymousVoteKey, JSON.stringify({
          selected_options: selectedOptions,
          custom_answer: customAnswer
        }));
      }

      setUserVote({ selected_options: selectedOptions, custom_answer: customAnswer });
      setHasVoted(true);
      setShowResults(true);
      
      // Update total votes
      if (poll) {
        const { error: updateError } = await supabase
          .from('blog_polls')
          .update({ total_votes: poll.total_votes + 1 })
          .eq('id', pollId);

        if (!updateError) {
          setPoll({ ...poll, total_votes: poll.total_votes + 1 });
        }
      }

      await fetchPoll(); // Refresh results
      toast.success('Vote recorded successfully!');
    } catch (error) {
      console.error('Error voting:', error);
      toast.error('Failed to record vote');
    } finally {
      setVoting(false);
    }
  };

  const handleOptionChange = (optionIndex: number, checked: boolean) => {
    if (poll?.poll_type === 'single') {
      setSelectedOptions(checked ? [optionIndex] : []);
    } else {
      setSelectedOptions(prev => 
        checked 
          ? [...prev, optionIndex]
          : prev.filter(i => i !== optionIndex)
      );
    }
  };

  const getVotePercentage = (votes: number) => {
    if (poll && poll.total_votes > 0) {
      return Math.round((votes / poll.total_votes) * 100);
    }
    return 0;
  };

  const isExpired = poll?.expires_at && new Date(poll.expires_at) < new Date();

  if (!poll) {
    return (
      <Card>
        <CardContent className="p-6">
          <div className="text-center text-muted-foreground">
            Loading poll...
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="my-6">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          📊 {poll.title}
        </CardTitle>
        {poll.description && (
          <p className="text-muted-foreground">{poll.description}</p>
        )}
        <div className="flex items-center gap-4 text-sm text-muted-foreground">
          <div className="flex items-center gap-1">
            <Users className="w-3 h-3" />
            {poll.total_votes} votes
          </div>
          {poll.expires_at && !isExpired && (
            <div className="flex items-center gap-1">
              <Clock className="w-3 h-3" />
              Expires {new Date(poll.expires_at).toLocaleDateString()}
            </div>
          )}
          {isExpired && (
            <div className="text-red-600">Expired</div>
          )}
        </div>
      </CardHeader>

      <CardContent>
        {!showResults && !hasVoted && !isExpired ? (
          <div className="space-y-4">
            <div className="space-y-3">
              {poll.poll_type === 'single' ? (
                <RadioGroup
                  value={selectedOptions[0]?.toString()}
                  onValueChange={(value) => setSelectedOptions([parseInt(value)])}
                >
                  {poll.options_json.map((option, index) => (
                    <div key={index} className="flex items-center space-x-2">
                      <RadioGroupItem value={index.toString()} id={`option-${index}`} />
                      <Label htmlFor={`option-${index}`} className="flex-1 cursor-pointer">
                        {option}
                      </Label>
                    </div>
                  ))}
                </RadioGroup>
              ) : (
                <div className="space-y-2">
                  {poll.options_json.map((option, index) => (
                    <div key={index} className="flex items-center space-x-2">
                      <Checkbox
                        id={`option-${index}`}
                        checked={selectedOptions.includes(index)}
                        onCheckedChange={(checked) => handleOptionChange(index, checked as boolean)}
                      />
                      <Label htmlFor={`option-${index}`} className="flex-1 cursor-pointer">
                        {option}
                      </Label>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {poll.allow_custom_answers && (
              <div>
                <Label htmlFor="custom-answer">Custom answer (optional)</Label>
                <Input
                  id="custom-answer"
                  value={customAnswer}
                  onChange={(e) => setCustomAnswer(e.target.value)}
                  placeholder="Your custom answer..."
                />
              </div>
            )}

            <div className="flex gap-2">
              <Button 
                onClick={handleVote} 
                disabled={voting || selectedOptions.length === 0}
                className="flex-1"
              >
                {voting ? 'Voting...' : 'Vote'}
              </Button>
              <Button 
                variant="outline" 
                onClick={() => setShowResults(true)}
              >
                View Results
              </Button>
            </div>
          </div>
        ) : (
          <div className="space-y-4">
            <div className="space-y-3">
              {pollResults.map((result, index) => (
                <div key={index} className="space-y-1">
                  <div className="flex justify-between items-center">
                    <span className={`${
                      userVote?.selected_options.includes(index) ? 'font-medium text-primary' : ''
                    }`}>
                      {result.text}
                      {userVote?.selected_options.includes(index) && ' ✓'}
                    </span>
                    <span className="text-sm text-muted-foreground">
                      {result.votes} ({getVotePercentage(result.votes)}%)
                    </span>
                  </div>
                  <Progress value={getVotePercentage(result.votes)} className="h-2" />
                </div>
              ))}
            </div>

            {userVote?.custom_answer && (
              <div className="p-3 bg-muted rounded-md">
                <div className="text-sm font-medium">Your custom answer:</div>
                <div className="text-sm">{userVote.custom_answer}</div>
              </div>
            )}

            {!hasVoted && !isExpired && (
              <Button 
                variant="outline" 
                onClick={() => setShowResults(false)}
                className="w-full"
              >
                Back to Voting
              </Button>
            )}
          </div>
        )}
      </CardContent>
    </Card>
  );
}