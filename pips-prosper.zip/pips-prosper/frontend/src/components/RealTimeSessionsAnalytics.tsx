import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { 
  Clock, 
  Globe, 
  Sunrise, 
  Sun, 
  Moon,
  TrendingUp,
  Activity,
  Wifi,
  BarChart3
} from "lucide-react";

interface SessionStats {
  session: string;
  trades: number;
  pnl: number;
  winRate: number;
  avgPnl: number;
}

export function RealTimeSessionsAnalytics() {
  const [sessionStats, setSessionStats] = useState<SessionStats[]>([]);
  const [loading, setLoading] = useState(true);
  const [lastUpdate, setLastUpdate] = useState(new Date());
  const { user } = useAuth();
  const { toast } = useToast();

  const getSessionIcon = (session: string) => {
    switch (session.toLowerCase()) {
      case 'asian': return <Sunrise className="h-4 w-4" />;
      case 'london': return <Sun className="h-4 w-4" />;
      case 'ny': case 'new york': return <Moon className="h-4 w-4" />;
      default: return <Globe className="h-4 w-4" />;
    }
  };

  const getSessionColor = (session: string) => {
    switch (session.toLowerCase()) {
      case 'asian': return 'bg-orange-500/10 text-orange-700 border-orange-200';
      case 'london': return 'bg-blue-500/10 text-blue-700 border-blue-200';
      case 'ny': case 'new york': return 'bg-purple-500/10 text-purple-700 border-purple-200';
      default: return 'bg-gray-500/10 text-gray-700 border-gray-200';
    }
  };

  const fetchSessionAnalytics = async () => {
    if (!user) return;

    try {
      setLoading(true);

      // Fetch all trades with session data
      const { data: trades, error } = await supabase
        .from('trades')
        .select('*')
        .eq('user_id', user.id)
        .not('closed_at', 'is', null)
        .not('pnl', 'is', null);

      if (error) throw error;

      // Calculate session statistics
      const sessionMap = new Map<string, {
        trades: any[];
        totalPnl: number;
        winningTrades: number;
      }>();

      trades?.forEach(trade => {
        // Determine session based on time (simplified logic)
        const tradeTime = new Date(trade.opened_at);
        const hour = tradeTime.getUTCHours();
        
        let session = 'Other';
        if (hour >= 22 || hour < 6) session = 'Asian';
        else if (hour >= 6 && hour < 14) session = 'London';
        else if (hour >= 14 && hour < 22) session = 'NY';

        if (!sessionMap.has(session)) {
          sessionMap.set(session, { trades: [], totalPnl: 0, winningTrades: 0 });
        }

        const sessionData = sessionMap.get(session)!;
        sessionData.trades.push(trade);
        sessionData.totalPnl += trade.pnl || 0;
        if ((trade.pnl || 0) > 0) sessionData.winningTrades++;
      });

      // Convert to SessionStats array
      const stats: SessionStats[] = Array.from(sessionMap.entries()).map(([session, data]) => ({
        session,
        trades: data.trades.length,
        pnl: data.totalPnl,
        winRate: data.trades.length > 0 ? (data.winningTrades / data.trades.length) * 100 : 0,
        avgPnl: data.trades.length > 0 ? data.totalPnl / data.trades.length : 0
      }));

      // Sort by total P&L descending
      stats.sort((a, b) => b.pnl - a.pnl);

      setSessionStats(stats);
      setLastUpdate(new Date());
    } catch (error: any) {
      console.error('Error fetching session analytics:', error);
      toast({
        variant: "destructive",
        title: "Error loading session analytics",
        description: error.message,
      });
    } finally {
      setLoading(false);
    }
  };

  // Real-time subscription
  useEffect(() => {
    fetchSessionAnalytics();

    if (!user) return;

    const channel = supabase
      .channel(`sessions-analytics-${user.id}`)
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'trades',
          filter: `user_id=eq.${user.id}`,
        },
        (payload) => {
          console.log('Real-time sessions update:', payload);
          fetchSessionAnalytics();
          
          if (payload.eventType === 'INSERT' || payload.eventType === 'UPDATE') {
            toast({
              title: "📊 Session Data Updated",
              description: "Trading session analytics refreshed",
              duration: 2000,
            });
          }
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [user]);

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 2
    }).format(value);
  };

  const formatPercent = (value: number) => {
    return `${value.toFixed(1)}%`;
  };

  if (loading) {
    return (
      <div className="space-y-6">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Clock className="h-5 w-5" />
              Trading Sessions Analytics
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {[1,2,3,4].map(i => (
                <div key={i} className="animate-pulse">
                  <div className="h-20 bg-muted rounded-lg"></div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="flex items-center gap-2">
              <Clock className="h-5 w-5 text-primary" />
              Real-Time Trading Sessions Analytics
              <Badge variant="outline" className="ml-2 text-xs">
                <Wifi className="w-3 h-3 mr-1" />
                Live
              </Badge>
            </CardTitle>
            <div className="flex items-center gap-2 text-xs text-muted-foreground">
              <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
              Updated: {lastUpdate.toLocaleTimeString()}
            </div>
          </div>
          <p className="text-sm text-muted-foreground">
            Performance breakdown by trading sessions - updates automatically with new trades
          </p>
        </CardHeader>
        <CardContent>
          {sessionStats.length > 0 ? (
            <div className="space-y-4">
              {sessionStats.map((session, index) => (
                <div key={session.session} 
                     className="flex items-center justify-between p-4 border rounded-lg hover:bg-muted/50 transition-colors">
                  <div className="flex items-center gap-4">
                    <div className={`p-2 rounded-lg ${getSessionColor(session.session)}`}>
                      {getSessionIcon(session.session)}
                    </div>
                    <div>
                      <h3 className="font-semibold">{session.session} Session</h3>
                      <p className="text-sm text-muted-foreground">
                        {session.trades} trades • Avg: {formatCurrency(session.avgPnl)}
                      </p>
                    </div>
                  </div>
                  
                  <div className="text-right space-y-2 min-w-[120px]">
                    <div className={`text-lg font-bold ${
                      session.pnl >= 0 ? 'text-success' : 'text-danger'
                    }`}>
                      {formatCurrency(session.pnl)}
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="text-sm text-muted-foreground">Win Rate:</span>
                      <Badge variant={session.winRate >= 50 ? "default" : "destructive"} className="text-xs">
                        {formatPercent(session.winRate)}
                      </Badge>
                    </div>
                  </div>
                </div>
              ))}
              
              {/* Session Performance Summary */}
              <div className="mt-6 p-4 bg-primary/5 rounded-lg border border-primary/10">
                <h4 className="font-semibold text-primary mb-2 flex items-center gap-2">
                  <BarChart3 className="h-4 w-4" />
                  Session Performance Summary
                </h4>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
                  <div>
                    <p className="text-muted-foreground">Best Session:</p>
                    <p className="font-medium">
                      {sessionStats[0]?.session} ({formatCurrency(sessionStats[0]?.pnl || 0)})
                    </p>
                  </div>
                  <div>
                    <p className="text-muted-foreground">Total Trades:</p>
                    <p className="font-medium">
                      {sessionStats.reduce((sum, s) => sum + s.trades, 0)}
                    </p>
                  </div>
                  <div>
                    <p className="text-muted-foreground">Overall P&L:</p>
                    <p className={`font-medium ${
                      sessionStats.reduce((sum, s) => sum + s.pnl, 0) >= 0 ? 'text-success' : 'text-danger'
                    }`}>
                      {formatCurrency(sessionStats.reduce((sum, s) => sum + s.pnl, 0))}
                    </p>
                  </div>
                </div>
              </div>
            </div>
          ) : (
            <div className="text-center py-12">
              <Activity className="h-12 w-12 mx-auto mb-4 text-muted-foreground/50" />
              <h3 className="text-lg font-medium mb-2">No Trading Sessions Data</h3>
              <p className="text-muted-foreground">
                Complete some trades to see your session-based performance analytics
              </p>
              <div className="mt-4 p-3 bg-blue-50 dark:bg-blue-950/20 rounded-lg border border-blue-200 dark:border-blue-800">
                <div className="flex items-center gap-2 text-blue-900 dark:text-blue-100 text-sm">
                  <Wifi className="w-4 h-4" />
                  <span className="font-medium">Real-time Ready</span>
                </div>
                <p className="text-xs text-blue-800 dark:text-blue-200 mt-1">
                  Session analytics will appear here automatically when you add trades
                </p>
              </div>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}