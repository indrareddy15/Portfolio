import { useState, useRef } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useToast } from "@/hooks/use-toast";
import { useLogoSettings } from "@/hooks/useLogoSettings";
import { supabase } from "@/integrations/supabase/client";
import { Upload, Eye, Edit, Trash2, MapPin, Ruler } from "lucide-react";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Textarea } from "@/components/ui/textarea";

export function LogoManager() {
  const { logos, loading, refetch } = useLogoSettings();
  const { toast } = useToast();
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [uploading, setUploading] = useState(false);
  const [editingLogo, setEditingLogo] = useState<any>(null);
  const [newLogo, setNewLogo] = useState({
    logo_type: 'main',
    logo_alt: 'Logo',
    width: 200,
    height: 50,
    usage_locations: ['navigation', 'footer', 'auth']
  });

  const handleFileUpload = async (file: File) => {
    if (!file) return null;
    
    setUploading(true);
    try {
      // Upload to Supabase Storage
      const fileExt = file.name.split('.').pop();
      const fileName = `${Date.now()}-${Math.random().toString(36).substring(2)}.${fileExt}`;
      
      const { data, error } = await supabase.storage
        .from('logos')
        .upload(fileName, file, {
          cacheControl: '3600',
          upsert: false
        });

      if (error) throw error;

      // Get public URL
      const { data: { publicUrl } } = supabase.storage
        .from('logos')
        .getPublicUrl(data.path);
      
      toast({
        title: "File uploaded",
        description: "Logo file has been uploaded successfully",
      });
      
      return publicUrl;
    } catch (error) {
      console.error('Upload error:', error);
      toast({
        title: "Upload failed",
        description: "Failed to upload logo file",
        variant: "destructive"
      });
      return null;
    } finally {
      setUploading(false);
    }
  };

  const handleCreateLogo = async (logoUrl: string) => {
    try {
      const { error } = await supabase
        .from('logo_settings')
        .insert({
          logo_type: newLogo.logo_type,
          logo_url: logoUrl,
          logo_alt: newLogo.logo_alt,
          width: newLogo.width,
          height: newLogo.height,
          usage_locations: newLogo.usage_locations,
          is_active: true
        });

      if (error) throw error;

      toast({
        title: "Logo created",
        description: "New logo has been added successfully",
      });

      refetch();
    } catch (error) {
      console.error('Create error:', error);
      toast({
        title: "Creation failed",
        description: "Failed to create logo setting",
        variant: "destructive"
      });
    }
  };

  const handleUpdateLogo = async (id: string, updates: any) => {
    try {
      const { error } = await supabase
        .from('logo_settings')
        .update(updates)
        .eq('id', id);

      if (error) throw error;

      toast({
        title: "Logo updated",
        description: "Logo settings have been updated successfully",
      });

      setEditingLogo(null);
      refetch();
    } catch (error) {
      console.error('Update error:', error);
      toast({
        title: "Update failed",
        description: "Failed to update logo settings",
        variant: "destructive"
      });
    }
  };

  const handleDeleteLogo = async (id: string) => {
    try {
      const { error } = await supabase
        .from('logo_settings')
        .update({ is_active: false })
        .eq('id', id);

      if (error) throw error;

      toast({
        title: "Logo deactivated",
        description: "Logo has been deactivated successfully",
      });

      refetch();
    } catch (error) {
      console.error('Delete error:', error);
      toast({
        title: "Deactivation failed",
        description: "Failed to deactivate logo",
        variant: "destructive"
      });
    }
  };

  const handleFileSelect = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    const logoUrl = await handleFileUpload(file);
    if (logoUrl) {
      await handleCreateLogo(logoUrl);
    }
  };

  if (loading) {
    return <div>Loading logo settings...</div>;
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-start">
        <div>
          <h1 className="text-3xl font-bold">Logo Management</h1>
          <p className="text-muted-foreground">Manage logos across your entire website with real-time updates</p>
        </div>
        <div className="space-y-2 text-right">
          <Button
            onClick={() => fileInputRef.current?.click()}
            disabled={uploading}
            className="flex items-center gap-2"
          >
            <Upload className="w-4 h-4" />
            {uploading ? "Uploading..." : "Upload New Logo"}
          </Button>
          <div className="text-xs text-muted-foreground max-w-xs">
            <p>• PNG/JPG format recommended</p>
            <p>• Transparent background preferred</p>
            <p>• High resolution for best quality</p>
          </div>
        </div>
        <input
          ref={fileInputRef}
          type="file"
          accept="image/*"
          onChange={handleFileSelect}
          className="hidden"
        />
      </div>

      <Tabs defaultValue="current" className="w-full">
        <TabsList>
          <TabsTrigger value="current">Current Logos</TabsTrigger>
          <TabsTrigger value="usage">Usage Overview</TabsTrigger>
          <TabsTrigger value="settings">Settings</TabsTrigger>
        </TabsList>

        <TabsContent value="current" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {logos.map((logo) => (
              <Card key={logo.id} className="overflow-hidden">
                <CardHeader className="pb-3">
                  <div className="flex justify-between items-start">
                    <div>
                      <CardTitle className="text-lg capitalize">{logo.logo_type} Logo</CardTitle>
                      <CardDescription>{logo.logo_alt}</CardDescription>
                    </div>
                    <Badge variant="secondary">{logo.logo_type}</Badge>
                  </div>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="aspect-video bg-muted rounded-lg flex items-center justify-center overflow-hidden">
                    <img
                      src={logo.logo_url}
                      alt={logo.logo_alt}
                      className="max-w-full max-h-full object-contain"
                      style={{
                        width: logo.width ? `${Math.min(logo.width, 200)}px` : 'auto',
                        height: logo.height ? `${Math.min(logo.height, 100)}px` : 'auto'
                      }}
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <div className="flex items-center justify-between text-sm">
                      <div className="flex items-center gap-2 text-muted-foreground">
                        <Ruler className="w-4 h-4" />
                        <span>{logo.width}×{logo.height}px</span>
                      </div>
                      <Badge variant={logo.is_active ? "default" : "secondary"} className="text-xs">
                        {logo.is_active ? "Active" : "Inactive"}
                      </Badge>
                    </div>
                    
                    <div className="space-y-1">
                      <div className="flex items-center gap-2 text-xs text-muted-foreground">
                        <MapPin className="w-3 h-3" />
                        <span className="font-medium">Used in:</span>
                      </div>
                      <div className="flex flex-wrap gap-1">
                        {logo.usage_locations?.map((location) => (
                          <Badge key={location} variant="outline" className="text-xs capitalize">
                            {location}
                          </Badge>
                        ))}
                      </div>
                    </div>
                    
                    {/* Size validation indicator */}
                    <div className="pt-1">
                      {logo.usage_locations?.map((location) => {
                        const isGoodSize = location === 'navigation' || location === 'footer' 
                          ? logo.height <= 32 && logo.width <= 200
                          : location === 'auth'
                          ? logo.height <= 48 && logo.width <= 300
                          : logo.height <= 28 && logo.width <= 180;
                        
                        if (!isGoodSize) {
                          return (
                            <div key={location} className="text-xs text-amber-600 dark:text-amber-400 flex items-center gap-1">
                              ⚠️ Size may be too large for {location}
                            </div>
                          );
                        }
                        return null;
                      })}
                    </div>
                  </div>

                  <div className="flex gap-2">
                    <Dialog>
                      <DialogTrigger asChild>
                        <Button variant="outline" size="sm" className="flex-1">
                          <Eye className="w-4 h-4 mr-1" />
                          Preview
                        </Button>
                      </DialogTrigger>
                      <DialogContent className="max-w-2xl">
                        <DialogHeader>
                          <DialogTitle>Logo Preview</DialogTitle>
                          <DialogDescription>
                            Preview how this logo appears across different components
                          </DialogDescription>
                        </DialogHeader>
                        <div className="space-y-4">
                          <div className="p-4 border rounded-lg">
                            <h4 className="font-medium mb-2">Navigation</h4>
                            <div className="bg-muted p-2 rounded flex items-center">
                              <img
                                src={logo.logo_url}
                                alt={logo.logo_alt}
                                className="h-8 w-auto"
                              />
                            </div>
                          </div>
                          <div className="p-4 border rounded-lg">
                            <h4 className="font-medium mb-2">Footer</h4>
                            <div className="bg-muted p-2 rounded flex items-center">
                              <img
                                src={logo.logo_url}
                                alt={logo.logo_alt}
                                className="h-8 w-auto"
                              />
                            </div>
                          </div>
                        </div>
                      </DialogContent>
                    </Dialog>

                    <Button 
                      variant="outline" 
                      size="sm"
                      onClick={() => setEditingLogo(logo)}
                    >
                      <Edit className="w-4 h-4" />
                    </Button>

                    <Button 
                      variant="outline" 
                      size="sm"
                      onClick={() => handleDeleteLogo(logo.id)}
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="usage" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Logo Usage & Size Specifications</CardTitle>
              <CardDescription>See where your logos are used with recommended sizes for each location</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {[
                  {
                    location: 'navigation',
                    title: 'Navigation Bar',
                    description: 'Main website navigation - visible on all pages',
                    recommendedSize: '32px height (auto width)',
                    maxSize: 'Max 200px width × 32px height',
                    usage: 'Navigation.tsx component'
                  },
                  {
                    location: 'footer',
                    title: 'Footer',
                    description: 'Website footer - appears at bottom of all pages',
                    recommendedSize: '32px height (auto width)',
                    maxSize: 'Max 150px width × 32px height',
                    usage: 'Footer.tsx component'
                  },
                  {
                    location: 'auth',
                    title: 'Authentication Page',
                    description: 'Login/signup page - first impression for users',
                    recommendedSize: '48px height on desktop, 40px on mobile',
                    maxSize: 'Max 300px width × 48px height',
                    usage: 'Auth.tsx page'
                  },
                  {
                    location: 'dashboard',
                    title: 'User Dashboard',
                    description: 'User dashboard header and sidebar',
                    recommendedSize: '28px height (auto width)',
                    maxSize: 'Max 180px width × 28px height',
                    usage: 'Dashboard layouts'
                  },
                  {
                    location: 'admin',
                    title: 'Admin Panel',
                    description: 'Admin dashboard and management pages',
                    recommendedSize: '28px height (auto width)',
                    maxSize: 'Max 180px width × 28px height',
                    usage: 'AdminLayout.tsx'
                  }
                ].map((spec) => {
                  const logoCount = logos.filter(logo => 
                    logo.usage_locations?.includes(spec.location)
                  ).length;
                  const activeLogo = logos.find(logo => 
                    logo.usage_locations?.includes(spec.location) && logo.is_active
                  );
                  
                  return (
                    <div key={spec.location} className="p-4 border rounded-lg space-y-3">
                      <div className="flex justify-between items-start">
                        <div className="flex-1">
                          <div className="flex items-center gap-3 mb-2">
                            <h4 className="font-medium">{spec.title}</h4>
                            <Badge variant={logoCount > 0 ? "default" : "secondary"}>
                              {logoCount} logo{logoCount !== 1 ? 's' : ''}
                            </Badge>
                          </div>
                          <p className="text-sm text-muted-foreground mb-2">
                            {spec.description}
                          </p>
                          <div className="space-y-1 text-xs">
                            <div className="flex items-center gap-2">
                              <Badge variant="outline" className="text-xs">Recommended</Badge>
                              <span className="text-green-600 font-medium">{spec.recommendedSize}</span>
                            </div>
                            <div className="flex items-center gap-2">
                              <Badge variant="outline" className="text-xs">Maximum</Badge>
                              <span className="text-orange-600">{spec.maxSize}</span>
                            </div>
                            <div className="flex items-center gap-2">
                              <Badge variant="outline" className="text-xs">Component</Badge>
                              <span className="text-blue-600">{spec.usage}</span>
                            </div>
                          </div>
                        </div>
                        {activeLogo && (
                          <div className="ml-4 p-2 bg-muted rounded flex items-center justify-center" style={{minWidth: '80px', height: '40px'}}>
                            <img
                              src={activeLogo.logo_url}
                              alt={activeLogo.logo_alt}
                              className="max-w-full max-h-full object-contain"
                              style={{
                                maxHeight: '32px',
                                maxWidth: '70px'
                              }}
                            />
                          </div>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
              
              <div className="mt-6 p-4 bg-blue-50 dark:bg-blue-950/20 rounded-lg border border-blue-200 dark:border-blue-800">
                <h4 className="font-medium text-blue-900 dark:text-blue-100 mb-2 flex items-center gap-2">
                  <Ruler className="w-4 h-4" />
                  Size Guidelines
                </h4>
                <div className="text-sm text-blue-800 dark:text-blue-200 space-y-1">
                  <p>• <strong>PNG/JPG format</strong> recommended for best compatibility</p>
                  <p>• <strong>Transparent background</strong> (PNG) works best for dark/light themes</p>
                  <p>• <strong>High resolution</strong> logos (2x) provide sharp display on retina screens</p>
                  <p>• <strong>Horizontal logos</strong> work better in navigation areas</p>
                  <p>• <strong>Real-time updates</strong> - changes apply immediately across the website</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="settings" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Global Logo Settings</CardTitle>
              <CardDescription>Configure default settings for new logos</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="default-width">Default Width (px)</Label>
                  <Input
                    id="default-width"
                    type="number"
                    value={newLogo.width}
                    onChange={(e) => setNewLogo({...newLogo, width: parseInt(e.target.value)})}
                  />
                </div>
                <div>
                  <Label htmlFor="default-height">Default Height (px)</Label>
                  <Input
                    id="default-height"
                    type="number"
                    value={newLogo.height}
                    onChange={(e) => setNewLogo({...newLogo, height: parseInt(e.target.value)})}
                  />
                </div>
              </div>
              <div>
                <Label htmlFor="default-alt">Default Alt Text</Label>
                <Input
                  id="default-alt"
                  value={newLogo.logo_alt}
                  onChange={(e) => setNewLogo({...newLogo, logo_alt: e.target.value})}
                />
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Edit Dialog */}
      {editingLogo && (
        <Dialog open={!!editingLogo} onOpenChange={() => setEditingLogo(null)}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Edit Logo Settings</DialogTitle>
              <DialogDescription>
                Update the logo configuration and usage details
              </DialogDescription>
            </DialogHeader>
            <div className="space-y-4">
              <div>
                <Label htmlFor="edit-alt">Alt Text</Label>
                <Input
                  id="edit-alt"
                  value={editingLogo.logo_alt}
                  onChange={(e) => setEditingLogo({...editingLogo, logo_alt: e.target.value})}
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="edit-width">Width (px)</Label>
                  <Input
                    id="edit-width"
                    type="number"
                    value={editingLogo.width}
                    onChange={(e) => setEditingLogo({...editingLogo, width: parseInt(e.target.value)})}
                  />
                </div>
                <div>
                  <Label htmlFor="edit-height">Height (px)</Label>
                  <Input
                    id="edit-height"
                    type="number"
                    value={editingLogo.height}
                    onChange={(e) => setEditingLogo({...editingLogo, height: parseInt(e.target.value)})}
                  />
                </div>
              </div>
              <div>
                <Label htmlFor="edit-locations">Usage Locations (comma-separated)</Label>
                <Textarea
                  id="edit-locations"
                  value={editingLogo.usage_locations?.join(', ')}
                  onChange={(e) => setEditingLogo({...editingLogo, usage_locations: e.target.value.split(', ')})}
                />
              </div>
              <div className="flex justify-end gap-2">
                <Button variant="outline" onClick={() => setEditingLogo(null)}>
                  Cancel
                </Button>
                <Button onClick={() => handleUpdateLogo(editingLogo.id, editingLogo)}>
                  Save Changes
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      )}
    </div>
  );
}