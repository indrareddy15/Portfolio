import { 
  LayoutDashboard, 
  Users2, 
  Handshake, 
  StickyNote,
  FileCheck2,
  UserSquare2,
  BadgeDollarSign,
  Wallet,
  ImageDown,
  Settings2,
  CreditCard,
  TicketPercent,
  Megaphone,
  Mail,
  Home,
  Leaf,
  HelpCircle,
  Newspaper,
  Webhook,
  SlidersHorizontal,
  ShieldCheck,
  SunMoon,
  Bell,
  LogOut,
  ChevronRight,
  DollarSign,
  TrendingUp,
  Palette,
  UserCog,
  FileText,
  Tags,
  FolderOpen,
  Image,
  Link
} from "lucide-react";
import { NavLink, useLocation } from "react-router-dom";
import {
  Sidebar,
  SidebarContent,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarTrigger,
  useSidebar,
} from "@/components/ui/sidebar";
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible";
import { Button } from "@/components/ui/button";
import { ThemeToggle } from "@/components/ThemeToggle";
import { useAuth } from "@/hooks/useAuth";
import { usePermissions, hasPermission } from "@/hooks/usePermissions";
import { useSystemSettings } from "@/hooks/useSystemSettings";
import { useState } from "react";

const adminMenuItems = [
  {
    title: "Overview",
    url: "/admin",
    icon: LayoutDashboard,
    permission: "view_all"
  },
  {
    title: "Team Management",
    url: "/admin/system/team",
    icon: UserCog,
    permission: "manage_roles"
  },
  {
    title: "CRM",
    icon: Users2,
    permission: "manage_crm",
    children: [
      { title: "Users", url: "/admin/crm/users", icon: Users2, permission: "view_users" },
      { title: "Affiliates", url: "/admin/crm/affiliates", icon: Handshake, permission: "manage_crm" },
      { title: "Notes", url: "/admin/crm/notes", icon: StickyNote, permission: "manage_crm" },
    ],
  },
  {
    title: "Affiliates",
    icon: Handshake,
    permission: "manage_affiliates",
    children: [
      { title: "Applications", url: "/admin/affiliates/applications", icon: FileCheck2, permission: "manage_affiliates" },
      { title: "Directory", url: "/admin/affiliates/directory", icon: UserSquare2, permission: "manage_affiliates" },
      { title: "Commissions", url: "/admin/affiliates/commissions", icon: BadgeDollarSign, permission: "manage_affiliates" },
      { title: "Payouts", url: "/admin/affiliates/payouts", icon: Wallet, permission: "manage_affiliates" },
      { title: "Creatives", url: "/admin/affiliates/creatives", icon: ImageDown, permission: "manage_affiliates" },
      { title: "Settings", url: "/admin/affiliates/settings", icon: Settings2, permission: "manage_affiliates" },
    ],
  },
  {
    title: "Subscriptions",
    url: "/admin/subscriptions",
    icon: CreditCard,
    permission: "view_analytics"
  },
  {
    title: "Pricing & Plans",
    url: "/admin/pricing",
    icon: DollarSign,
    permission: "manage_pricing"
  },
  {
    title: "Forex Engine",
    url: "/admin/forex",
    icon: TrendingUp,
    permission: "manage_forex"
  },
  {
    title: "Content",
    icon: FileText,
    permission: "manage_content",
    children: [
      { title: "Posts", url: "/admin/content/blog/posts", icon: FileText, permission: "manage_content" },
      { title: "Categories", url: "/admin/content/blog/categories", icon: FolderOpen, permission: "manage_content" },
      { title: "Tags", url: "/admin/content/blog/tags", icon: Tags, permission: "manage_content" },
      { title: "Media", url: "/admin/content/blog/media", icon: Image, permission: "manage_content" },
      { title: "Redirects", url: "/admin/content/blog/redirects", icon: Link, permission: "manage_content" },
    ],
  },
  {
    title: "Marketing",
    icon: Megaphone,
    permission: "manage_marketing",
    children: [
      { title: "Coupons / Promo Codes", url: "/admin/marketing/coupons", icon: TicketPercent, permission: "manage_marketing" },
      { title: "Campaigns", url: "/admin/marketing/campaigns", icon: Megaphone, permission: "manage_marketing" },
      { title: "Email Templates", url: "/admin/marketing/emails", icon: Mail, permission: "manage_marketing" },
    ],
  },
  {
    title: "CMS / Site",
    icon: Home,
    permission: "manage_settings",
    children: [
      { title: "Homepage Blocks", url: "/admin/cms/home", icon: Home, permission: "manage_settings" },
      { title: "Footer & Links", url: "/admin/cms/footer", icon: Leaf, permission: "manage_settings" },
      { title: "FAQs", url: "/admin/cms/faq", icon: HelpCircle, permission: "manage_settings" },
      { title: "Blog", url: "/admin/cms/blog", icon: Newspaper, permission: "manage_settings" },
    ],
  },
  {
    title: "Branding",
    icon: Palette,
    permission: "manage_branding",
    children: [
      { title: "Logo Manager", url: "/admin/branding/logos", icon: ImageDown, permission: "manage_branding" },
    ],
  },
  {
    title: "System",
    icon: SlidersHorizontal,
    permission: "manage_settings",
    children: [
      { title: "Notices", url: "/admin/system/notices", icon: Bell, permission: "manage_settings" },
      { title: "Webhooks", url: "/admin/system/webhooks", icon: Webhook, permission: "manage_settings" },
      { title: "Settings", url: "/admin/system/settings", icon: SlidersHorizontal, permission: "manage_settings" },
      { title: "Audit Log", url: "/admin/system/audit", icon: ShieldCheck, permission: "manage_settings" },
    ],
  },
];

export function AdminSidebar() {
  const { state } = useSidebar();
  const location = useLocation();
  const { signOut } = useAuth();
  const { permissions } = usePermissions();
  const { isAffiliateEnabled } = useSystemSettings();
  const currentPath = location.pathname;
  const collapsed = state === "collapsed";
  
  // Filter menu items based on permissions and system settings
  const filteredMenuItems = adminMenuItems.filter(item => {
    if (!isAffiliateEnabled && (
      item.title === "Affiliates" || 
      (item.title === "CRM" && item.children?.some(child => child.title === "Affiliates"))
    )) {
      return false;
    }
    
    if (item.permission && !hasPermission(permissions, item.permission)) {
      return false;
    }
    
    if (item.children) {
      item.children = item.children.filter(child => {
        if (!isAffiliateEnabled && child.title === "Affiliates") {
          return false;
        }
        return !child.permission || hasPermission(permissions, child.permission);
      });
      return item.children.length > 0 || !item.permission;
    }
    
    return true;
  });
  
  const [openGroups, setOpenGroups] = useState<string[]>(() => {
    const currentGroup = filteredMenuItems.find(item => 
      item.children?.some(child => currentPath.startsWith(child.url))
    );
    return currentGroup ? [currentGroup.title] : [];
  });

  const isActive = (path: string) => {
    if (path === "/admin") {
      return currentPath === "/admin";
    }
    return currentPath.startsWith(path);
  };

  const toggleGroup = (groupTitle: string) => {
    setOpenGroups(prev => 
      prev.includes(groupTitle)
        ? prev.filter(title => title !== groupTitle)
        : [...prev, groupTitle]
    );
  };

  const getNavClasses = (path: string) => {
    return isActive(path)
      ? "bg-primary text-primary-foreground hover:bg-primary/90"
      : "text-sidebar-foreground hover:text-sidebar-primary hover:bg-sidebar-accent";
  };

  const handleSignOut = async () => {
    await signOut();
  };

  return (
    <Sidebar 
      className={`${collapsed ? 'w-16' : 'w-64'} bg-card border-r`}
      collapsible="icon"
    >
      {/* Clean Header */}
      <div className="p-4 border-b">
        {!collapsed ? (
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center">
              <span className="text-primary-foreground font-semibold text-sm">A</span>
            </div>
            <div>
              <h2 className="font-semibold text-foreground">Admin</h2>
              <p className="text-xs text-muted-foreground">Control Panel</p>
            </div>
          </div>
        ) : (
          <div className="flex justify-center">
            <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center">
              <span className="text-primary-foreground font-semibold text-sm">A</span>
            </div>
          </div>
        )}
      </div>

      <SidebarContent className="p-4">
        <SidebarGroup>
          <SidebarGroupContent>
            <SidebarMenu className="space-y-1">
              {filteredMenuItems.map((item) => (
                <SidebarMenuItem key={item.title}>
                  {!item.children ? (
                    <SidebarMenuButton asChild>
                      <NavLink to={item.url!} className={`flex items-center gap-3 px-3 py-2 rounded-lg transition-colors ${getNavClasses(item.url!)}`}>
                        <item.icon className="h-4 w-4" />
                        {!collapsed && <span className="font-medium">{item.title}</span>}
                      </NavLink>
                    </SidebarMenuButton>
                  ) : (
                    <Collapsible
                      open={!collapsed && openGroups.includes(item.title)}
                      onOpenChange={() => !collapsed && toggleGroup(item.title)}
                    >
                      <CollapsibleTrigger asChild>
                        <SidebarMenuButton className="w-full justify-between px-3 py-2 rounded-lg">
                          <div className="flex items-center gap-3">
                            <item.icon className="h-4 w-4" />
                            {!collapsed && <span className="font-medium">{item.title}</span>}
                          </div>
                          {!collapsed && (
                            <ChevronRight 
                              className={`h-4 w-4 transition-transform ${
                                openGroups.includes(item.title) ? "rotate-90" : ""
                              }`} 
                            />
                          )}
                        </SidebarMenuButton>
                      </CollapsibleTrigger>
                      
                      {!collapsed && (
                        <CollapsibleContent>
                          <div className="ml-4 mt-1 space-y-1">
                            {item.children.map((child) => (
                              <SidebarMenuButton key={child.url} asChild size="sm">
                                <NavLink 
                                  to={child.url} 
                                  className={`flex items-center gap-3 px-3 py-2 rounded-md text-sm transition-colors ${getNavClasses(child.url)}`}
                                >
                                  <child.icon className="h-3.5 w-3.5" />
                                  <span>{child.title}</span>
                                </NavLink>
                              </SidebarMenuButton>
                            ))}
                          </div>
                        </CollapsibleContent>
                      )}
                    </Collapsible>
                  )}
                </SidebarMenuItem>
              ))}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>
      </SidebarContent>

      {/* Clean Bottom */}
      <div className="mt-auto p-4 border-t">
        {!collapsed ? (
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <ThemeToggle />
              <Button variant="ghost" size="sm">
                <Bell className="h-4 w-4" />
              </Button>
            </div>
            <Button
              variant="outline"
              size="sm"
              onClick={handleSignOut}
              className="w-full"
            >
              <LogOut className="h-4 w-4 mr-2" />
              Sign Out
            </Button>
          </div>
        ) : (
          <div className="space-y-2 flex flex-col">
            <ThemeToggle />
            <Button variant="ghost" size="sm">
              <Bell className="h-4 w-4" />
            </Button>
            <Button variant="ghost" size="sm" onClick={handleSignOut}>
              <LogOut className="h-4 w-4" />
            </Button>
          </div>
        )}
      </div>
    </Sidebar>
  );
}