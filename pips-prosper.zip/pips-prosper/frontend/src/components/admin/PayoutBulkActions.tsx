import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card } from "@/components/ui/card";
import { CheckCircle, RefreshCw, Download, X } from "lucide-react";
import { toast } from "@/hooks/use-toast";

interface PayoutBulkActionsProps {
  selectedPayouts: string[];
  onClearSelection: () => void;
  onBulkAction: (action: string) => Promise<void>;
  loading?: boolean;
}

export function PayoutBulkActions({ 
  selectedPayouts, 
  onClearSelection, 
  onBulkAction, 
  loading = false 
}: PayoutBulkActionsProps) {
  if (selectedPayouts.length === 0) return null;

  const handleExportSelected = () => {
    // Create CSV export of selected payouts
    const csv = `ID,Affiliate,Amount,Currency,Method,Status,Created At\n${selectedPayouts.join('\n')}`;
    const blob = new Blob([csv], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `payouts-${new Date().toISOString().split('T')[0]}.csv`;
    a.click();
    URL.revokeObjectURL(url);
    
    toast({
      title: "Export Complete",
      description: `Exported ${selectedPayouts.length} payouts to CSV`,
    });
  };

  return (
    <Card className="p-4 bg-muted/50 border-dashed">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <Badge variant="secondary">
            {selectedPayouts.length} selected
          </Badge>
          <div className="flex gap-2">
            <Button
              size="sm"
              variant="outline"
              disabled={loading}
              onClick={() => onBulkAction('approve')}
            >
              <CheckCircle className="w-3 h-3 mr-1" />
              Approve All
            </Button>
            <Button
              size="sm"
              variant="outline"
              disabled={loading}
              onClick={() => onBulkAction('process')}
            >
              <RefreshCw className="w-3 h-3 mr-1" />
              Process All
            </Button>
            <Button
              size="sm"
              variant="outline"
              onClick={handleExportSelected}
            >
              <Download className="w-3 h-3 mr-1" />
              Export
            </Button>
          </div>
        </div>
        <Button
          size="sm"
          variant="ghost"
          onClick={onClearSelection}
        >
          <X className="w-3 h-3 mr-1" />
          Clear
        </Button>
      </div>
    </Card>
  );
}