import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { toast } from "@/hooks/use-toast";
import { UserPlus, Mail, Shield, Trash2, Clock } from "lucide-react";

interface TeamMember {
  id: string;
  user_id: string;
  email: string;
  display_name?: string;
  role: string;
  created_at: string;
}

interface TeamInvitation {
  id: string;
  email: string;
  role: string;
  status: string;
  expires_at: string;
  created_at: string;
  invited_by: string;
}

const roleColors = {
  admin: "bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200",
  developer: "bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200",
  sales: "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200",
  support: "bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200",
  marketing: "bg-purple-100 text-purple-800 dark:bg-purple-900 dark:text-purple-200",
  finance: "bg-orange-100 text-orange-800 dark:bg-orange-900 dark:text-orange-200",
};

const rolePermissions = {
  admin: ["Full Access", "User Management", "Role Management"],
  developer: ["View Users", "Settings", "Analytics", "Forex"],
  sales: ["View Users", "CRM", "Analytics", "Affiliate"],
  support: ["View Users", "CRM", "Analytics"],
  marketing: ["Affiliate", "Marketing", "Branding", "Analytics"],
  finance: ["Analytics", "Pricing", "View Users"],
};

export function TeamManager() {
  const [teamMembers, setTeamMembers] = useState<TeamMember[]>([]);
  const [invitations, setInvitations] = useState<TeamInvitation[]>([]);
  const [isInviteDialogOpen, setIsInviteDialogOpen] = useState(false);
  const [inviteEmail, setInviteEmail] = useState("");
  const [inviteRole, setInviteRole] = useState("");
  const [loading, setLoading] = useState(true);

  const fetchTeamData = async () => {
    try {
      // Fetch user roles first
      const { data: userRoles, error: rolesError } = await supabase
        .from("user_roles")
        .select("user_id, role")
        .neq("role", "user");

      if (rolesError) throw rolesError;

      // Fetch profiles for these users
      const userIds = userRoles?.map(ur => ur.user_id) || [];
      const { data: profiles, error: profilesError } = await supabase
        .from("profiles")
        .select("user_id, display_name")
        .in("user_id", userIds);

      if (profilesError) throw profilesError;

      // Create a map of user roles and profiles
      const roleMap = new Map(userRoles?.map(ur => [ur.user_id, ur.role]) || []);
      const profileMap = new Map(profiles?.map(p => [p.user_id, p]) || []);

      // Get user emails (this is simplified - in production you'd handle this differently)
      const teamMembersData: TeamMember[] = [];
      
      for (const userId of userIds) {
        const profile = profileMap.get(userId);
        const role = roleMap.get(userId);
        
        teamMembersData.push({
          id: userId,
          user_id: userId,
          email: `user-${userId.slice(0, 8)}@domain.com`, // Placeholder
          display_name: profile?.display_name,
          role: role || "user",
          created_at: new Date().toISOString(),
        });
      }

      setTeamMembers(teamMembersData);

      // Fetch pending invitations
      const { data: inviteData, error: inviteError } = await supabase
        .from("team_invitations")
        .select("*")
        .eq("status", "pending")
        .gt("expires_at", new Date().toISOString());

      if (inviteError) throw inviteError;

      setInvitations(inviteData || []);
    } catch (error) {
      console.error("Error fetching team data:", error);
      toast({
        title: "Error",
        description: "Failed to load team data",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchTeamData();

    // Set up real-time subscription for invitations
    const channel = supabase
      .channel("team-changes")
      .on(
        "postgres_changes",
        {
          event: "*",
          schema: "public",
          table: "team_invitations",
        },
        () => {
          fetchTeamData();
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, []);

  const handleInviteTeamMember = async () => {
    if (!inviteEmail || !inviteRole) {
      toast({
        title: "Error",
        description: "Please fill in both email and role",
        variant: "destructive",
      });
      return;
    }

    try {
      const currentUser = await supabase.auth.getUser();
      
      const { error } = await supabase.from("team_invitations").insert({
        email: inviteEmail,
        role: inviteRole as any, // Type assertion for enum
        invited_by: currentUser.data.user?.id || "",
      });

      if (error) throw error;

      toast({
        title: "Success",
        description: `Invitation sent to ${inviteEmail} for ${inviteRole} role`,
      });

      setInviteEmail("");
      setInviteRole("");
      setIsInviteDialogOpen(false);
      fetchTeamData();
    } catch (error) {
      console.error("Error inviting team member:", error);
      toast({
        title: "Error",
        description: "Error inviting team member",
        variant: "destructive",
      });
    }
  };

  const handleDeleteInvitation = async (invitationId: string) => {
    try {
      const { error } = await supabase
        .from("team_invitations")
        .delete()
        .eq("id", invitationId);

      if (error) throw error;

      toast({
        title: "Success",
        description: "Invitation deleted successfully",
      });

      fetchTeamData();
    } catch (error) {
      console.error("Error deleting invitation:", error);
      toast({
        title: "Error",
        description: "Error deleting invitation",
        variant: "destructive",
      });
    }
  };

  const handleRemoveTeamMember = async (userId: string) => {
    try {
      const { error } = await supabase
        .from("user_roles")
        .delete()
        .eq("user_id", userId)
        .neq("role", "user");

      if (error) throw error;

      toast({
        title: "Success",
        description: "Team member removed successfully",
      });

      fetchTeamData();
    } catch (error) {
      console.error("Error removing team member:", error);
      toast({
        title: "Error",
        description: "Error removing team member",
        variant: "destructive",
      });
    }
  };

  if (loading) {
    return <div className="p-6">Loading team data...</div>;
  }

  return (
    <div className="p-6 space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold">Team Management</h1>
          <p className="text-muted-foreground">
            Manage your team members and set their roles
          </p>
        </div>
        <Dialog open={isInviteDialogOpen} onOpenChange={setIsInviteDialogOpen}>
          <DialogTrigger asChild>
            <Button>
              <UserPlus className="w-4 h-4 mr-2" />
              Invite Team Member
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Invite New Team Member</DialogTitle>
              <DialogDescription>
                Select the team member's email and role
              </DialogDescription>
            </DialogHeader>
            <div className="space-y-4">
              <div>
                <Label htmlFor="email">Email Address</Label>
                <Input
                  id="email"
                  type="email"
                  value={inviteEmail}
                  onChange={(e) => setInviteEmail(e.target.value)}
                  placeholder="team@example.com"
                />
              </div>
              <div>
                <Label htmlFor="role">Role</Label>
                <Select value={inviteRole} onValueChange={setInviteRole}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select a role" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="developer">Developer</SelectItem>
                    <SelectItem value="sales">Sales Team</SelectItem>
                    <SelectItem value="support">Support Team</SelectItem>
                    <SelectItem value="marketing">Marketing Team</SelectItem>
                    <SelectItem value="finance">Finance Team</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              {inviteRole && (
                <div className="p-3 bg-muted rounded-lg">
                  <h4 className="font-semibold mb-2">Role Permissions:</h4>
                  <div className="flex flex-wrap gap-1">
                    {rolePermissions[inviteRole as keyof typeof rolePermissions]?.map((permission) => (
                      <Badge key={permission} variant="secondary" className="text-xs">
                        {permission}
                      </Badge>
                    ))}
                  </div>
                </div>
              )}
              <div className="flex justify-end space-x-2">
                <Button variant="outline" onClick={() => setIsInviteDialogOpen(false)}>
                  Cancel
                </Button>
                <Button onClick={handleInviteTeamMember}>
                  <Mail className="w-4 h-4 mr-2" />
                  Send Invite
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Team Members */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Shield className="w-5 h-5" />
              Team Members ({teamMembers.length})
            </CardTitle>
            <CardDescription>
              Active team members and their roles
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Name/Email</TableHead>
                    <TableHead>Role</TableHead>
                    <TableHead>Action</TableHead>
                  </TableRow>
                </TableHeader>
              <TableBody>
                {teamMembers.map((member) => (
                  <TableRow key={member.id}>
                    <TableCell>
                      <div>
                        <div className="font-medium">
                          {member.display_name || "No Name"}
                        </div>
                        <div className="text-sm text-muted-foreground">
                          {member.email}
                        </div>
                      </div>
                    </TableCell>
                    <TableCell>
                      <Badge 
                        className={roleColors[member.role as keyof typeof roleColors] || "bg-gray-100 text-gray-800"}
                      >
                        {member.role}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      {member.role !== "admin" && (
                        <Button
                          size="sm"
                          variant="ghost"
                          onClick={() => handleRemoveTeamMember(member.user_id)}
                        >
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      )}
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>

        {/* Pending Invitations */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Clock className="w-5 h-5" />
              Pending Invitations ({invitations.length})
            </CardTitle>
            <CardDescription>
              Sent invitations awaiting response
            </CardDescription>
          </CardHeader>
          <CardContent>
            {invitations.length === 0 ? (
              <p className="text-muted-foreground text-center py-4">
                No pending invitations
              </p>
            ) : (
              <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Email</TableHead>
                      <TableHead>Role</TableHead>
                      <TableHead>Action</TableHead>
                    </TableRow>
                  </TableHeader>
                <TableBody>
                  {invitations.map((invitation) => (
                    <TableRow key={invitation.id}>
                      <TableCell>
                        <div className="font-medium">{invitation.email}</div>
                        <div className="text-sm text-muted-foreground">
                          Expires on {new Date(invitation.expires_at).toLocaleDateString("en-US")}
                        </div>
                      </TableCell>
                      <TableCell>
                        <Badge 
                          className={roleColors[invitation.role as keyof typeof roleColors] || "bg-gray-100 text-gray-800"}
                        >
                          {invitation.role}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <Button
                          size="sm"
                          variant="ghost"
                          onClick={() => handleDeleteInvitation(invitation.id)}
                        >
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Role Permissions Overview */}
      <Card>
        <CardHeader>
          <CardTitle>Role Permissions Overview</CardTitle>
          <CardDescription>
            View permissions for each role
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {Object.entries(rolePermissions).map(([role, permissions]) => (
              <div key={role} className="p-4 border rounded-lg">
                <Badge 
                  className={`mb-3 ${roleColors[role as keyof typeof roleColors] || "bg-gray-100 text-gray-800"}`}
                >
                  {role}
                </Badge>
                <div className="space-y-1">
                  {permissions.map((permission) => (
                    <div key={permission} className="text-sm text-muted-foreground">
                      • {permission}
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}