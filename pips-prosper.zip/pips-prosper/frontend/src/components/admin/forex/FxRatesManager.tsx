import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Switch } from "@/components/ui/switch";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Plus, Edit, Trash2, Search, RefreshCw } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { useRealtime } from "@/hooks/useRealtime";

interface FxRate {
  id: string;
  from_currency: string;
  to_currency: string;
  rate: number;
  updated_at: string;
  created_by?: string;
  is_active: boolean;
}

const CURRENCIES = [
  'USD', 'EUR', 'GBP', 'JPY', 'AUD', 'CAD', 'CHF', 'NZD',
  'CNH', 'HKD', 'SGD', 'SEK', 'NOK', 'DKK', 'ZAR', 'MXN',
  'TRY', 'PLN', 'HUF', 'CZK', 'INR', 'THB', 'MYR', 'IDR',
  'PHP', 'KRW', 'TWD'
];

export function FxRatesManager() {
  const [fxRates, setFxRates] = useState<FxRate[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedRate, setSelectedRate] = useState<FxRate | null>(null);
  const [showDialog, setShowDialog] = useState(false);
  const { toast } = useToast();

  const fetchFxRates = async () => {
    try {
      const { data, error } = await supabase
        .from('fx_rates')
        .select('*')
        .order('from_currency, to_currency');
      
      if (error) throw error;
      setFxRates(data || []);
    } catch (error: any) {
      toast({
        title: "Error",
        description: "Failed to load FX rates",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  // Real-time updates
  useRealtime([
    {
      table: 'fx_rates',
      events: ['INSERT', 'UPDATE', 'DELETE'],
      onInsert: () => fetchFxRates(),
      onUpdate: () => fetchFxRates(),
      onDelete: () => fetchFxRates(),
      showToasts: false
    }
  ]);

  useEffect(() => {
    fetchFxRates();
  }, []);

  const filteredRates = fxRates.filter(rate =>
    rate.from_currency.toLowerCase().includes(searchTerm.toLowerCase()) ||
    rate.to_currency.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const formData = new FormData(e.currentTarget);
    
    const rateData = {
      from_currency: formData.get("from_currency") as string,
      to_currency: formData.get("to_currency") as string,
      rate: parseFloat(formData.get("rate") as string),
      is_active: formData.get("is_active") === "on"
    };

    try {
      let result;
      if (selectedRate) {
        result = await supabase
          .from('fx_rates')
          .update(rateData)
          .eq('id', selectedRate.id);
      } else {
        result = await supabase
          .from('fx_rates')
          .insert([rateData]);
      }

      if (result.error) throw result.error;

      toast({
        title: "Success",
        description: `FX rate ${selectedRate ? 'updated' : 'created'} successfully`
      });

      setShowDialog(false);
      setSelectedRate(null);
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive"
      });
    }
  };

  const handleDelete = async (rate: FxRate) => {
    if (!confirm(`Are you sure you want to delete ${rate.from_currency}/${rate.to_currency}?`)) return;

    try {
      const { error } = await supabase
        .from('fx_rates')
        .delete()
        .eq('id', rate.id);

      if (error) throw error;

      toast({
        title: "Success",
        description: "FX rate deleted successfully"
      });
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive"
      });
    }
  };

  const bulkUpdateRates = async () => {
    // This is a placeholder for integrating with a real FX API
    toast({
      title: "Feature Coming Soon",
      description: "Bulk rate updates from live FX providers will be available soon.",
    });
  };

  if (loading) {
    return <div className="animate-pulse">Loading FX rates...</div>;
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold">FX Rates</h2>
          <p className="text-muted-foreground">Manage currency exchange rates for PnL conversion</p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" onClick={bulkUpdateRates}>
            <RefreshCw className="w-4 h-4 mr-2" />
            Update All Rates
          </Button>
          <Dialog open={showDialog} onOpenChange={setShowDialog}>
            <DialogTrigger asChild>
              <Button onClick={() => setSelectedRate(null)}>
                <Plus className="w-4 h-4 mr-2" />
                Add Rate
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>
                  {selectedRate ? 'Edit FX Rate' : 'Add New FX Rate'}
                </DialogTitle>
              </DialogHeader>
              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="from_currency">From Currency *</Label>
                    <Select name="from_currency" defaultValue={selectedRate?.from_currency}>
                      <SelectTrigger>
                        <SelectValue placeholder="Select currency" />
                      </SelectTrigger>
                      <SelectContent>
                        {CURRENCIES.map(currency => (
                          <SelectItem key={currency} value={currency}>
                            {currency}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label htmlFor="to_currency">To Currency *</Label>
                    <Select name="to_currency" defaultValue={selectedRate?.to_currency}>
                      <SelectTrigger>
                        <SelectValue placeholder="Select currency" />
                      </SelectTrigger>
                      <SelectContent>
                        {CURRENCIES.map(currency => (
                          <SelectItem key={currency} value={currency}>
                            {currency}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                <div>
                  <Label htmlFor="rate">Exchange Rate *</Label>
                  <Input
                    id="rate"
                    name="rate"
                    type="number"
                    step="0.000001"
                    defaultValue={selectedRate?.rate}
                    placeholder="1.08450"
                    required
                  />
                </div>
                <div className="flex items-center space-x-2">
                  <Switch
                    id="is_active"
                    name="is_active"
                    defaultChecked={selectedRate?.is_active ?? true}
                  />
                  <Label htmlFor="is_active">Active</Label>
                </div>
                <div className="flex justify-end space-x-2">
                  <Button type="button" variant="outline" onClick={() => setShowDialog(false)}>
                    Cancel
                  </Button>
                  <Button type="submit">
                    {selectedRate ? 'Update' : 'Create'}
                  </Button>
                </div>
              </form>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle>Exchange Rates ({filteredRates.length})</CardTitle>
            <div className="flex items-center space-x-2">
              <Search className="w-4 h-4 text-muted-foreground" />
              <Input
                placeholder="Search rates..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-64"
              />
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Currency Pair</TableHead>
                <TableHead>Rate</TableHead>
                <TableHead>Updated</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredRates.map((rate) => (
                <TableRow key={rate.id}>
                  <TableCell className="font-mono font-semibold">
                    {rate.from_currency}/{rate.to_currency}
                  </TableCell>
                  <TableCell className="font-mono">
                    {Number(rate.rate).toFixed(6)}
                  </TableCell>
                  <TableCell className="text-sm text-muted-foreground">
                    {new Date(rate.updated_at).toLocaleDateString()} {new Date(rate.updated_at).toLocaleTimeString()}
                  </TableCell>
                  <TableCell>
                    <Badge variant={rate.is_active ? "default" : "secondary"}>
                      {rate.is_active ? "Active" : "Inactive"}
                    </Badge>
                  </TableCell>
                  <TableCell>
                    <div className="flex space-x-2">
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => {
                          setSelectedRate(rate);
                          setShowDialog(true);
                        }}
                      >
                        <Edit className="w-4 h-4" />
                      </Button>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => handleDelete(rate)}
                        className="text-red-600 hover:text-red-700"
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
}