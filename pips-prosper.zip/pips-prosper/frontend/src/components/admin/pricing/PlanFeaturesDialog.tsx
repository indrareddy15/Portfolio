import { useState, useEffect } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Card, CardContent } from "@/components/ui/card";
import { Plus, Trash2, GripVertical } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "@/hooks/use-toast";

interface Plan {
  id: string;
  name: string;
  price_amount: number;
  price_currency: string;
  billing_cycle: string;
}

interface PlanFeature {
  id: string;
  plan_id: string;
  label: string;
  is_included: boolean;
  sort_order: number;
}

interface PlanFeaturesDialogProps {
  plan: Plan | null;
  features: PlanFeature[];
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onSuccess: () => void;
}

export function PlanFeaturesDialog({ plan, features, open, onOpenChange, onSuccess }: PlanFeaturesDialogProps) {
  const [localFeatures, setLocalFeatures] = useState<Array<PlanFeature & { isNew?: boolean; toDelete?: boolean }>>([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (open && plan) {
      setLocalFeatures(features.map(f => ({ ...f })));
    }
  }, [features, open, plan]);

  const addFeature = () => {
    const newFeature = {
      id: `temp-${Date.now()}`,
      plan_id: plan?.id || '',
      label: '',
      is_included: true,
      sort_order: localFeatures.length + 1,
      isNew: true
    };
    setLocalFeatures(prev => [...prev, newFeature]);
  };

  const updateFeature = (index: number, updates: Partial<PlanFeature>) => {
    setLocalFeatures(prev => prev.map((feature, i) => 
      i === index ? { ...feature, ...updates } : feature
    ));
  };

  const removeFeature = (index: number) => {
    const feature = localFeatures[index];
    if (feature.isNew) {
      // Remove new features immediately
      setLocalFeatures(prev => prev.filter((_, i) => i !== index));
    } else {
      // Mark existing features for deletion
      setLocalFeatures(prev => prev.map((f, i) => 
        i === index ? { ...f, toDelete: true } : f
      ));
    }
  };

  const handleSubmit = async () => {
    if (!plan) return;

    setLoading(true);
    try {
      // Filter out features marked for deletion and empty labels
      const validFeatures = localFeatures.filter(f => !f.toDelete && f.label.trim());

      // Delete features marked for deletion
      const toDelete = localFeatures.filter(f => f.toDelete && !f.isNew);
      if (toDelete.length > 0) {
        const { error: deleteError } = await supabase
          .from('plan_features')
          .delete()
          .in('id', toDelete.map(f => f.id));
        if (deleteError) throw deleteError;
      }

      // Update existing features
      const toUpdate = validFeatures.filter(f => !f.isNew);
      for (const feature of toUpdate) {
        const { error } = await supabase
          .from('plan_features')
          .update({
            label: feature.label,
            is_included: feature.is_included,
            sort_order: feature.sort_order
          })
          .eq('id', feature.id);
        if (error) throw error;
      }

      // Insert new features
      const toInsert = validFeatures.filter(f => f.isNew).map(f => ({
        plan_id: plan.id,
        label: f.label,
        is_included: f.is_included,
        sort_order: f.sort_order
      }));
      
      if (toInsert.length > 0) {
        const { error } = await supabase
          .from('plan_features')
          .insert(toInsert);
        if (error) throw error;
      }

      toast({
        title: "Success",
        description: "Plan features updated successfully"
      });

      onSuccess();
    } catch (error: any) {
      console.error('Error updating features:', error);
      toast({
        title: "Error",
        description: error.message || "Failed to update features",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const formatPrice = (amount: number, currency: string, cycle: string) => {
    const formattedAmount = new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: currency
    }).format(amount);
    
    return amount === 0 ? 'Free' : `${formattedAmount}/${cycle}`;
  };

  if (!plan) return null;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[700px] max-h-[80vh]">
        <DialogHeader>
          <DialogTitle>
            Edit Features - {plan.name}
          </DialogTitle>
          <p className="text-sm text-muted-foreground">
            {formatPrice(plan.price_amount, plan.price_currency, plan.billing_cycle)}
          </p>
        </DialogHeader>

        <div className="space-y-4 overflow-y-auto max-h-[60vh]">
          {localFeatures.filter(f => !f.toDelete).map((feature, index) => (
            <Card key={feature.id}>
              <CardContent className="p-4">
                <div className="flex items-center space-x-3">
                  <GripVertical className="w-4 h-4 text-muted-foreground cursor-move" />
                  
                  <div className="flex-1 space-y-2">
                    <Input
                      value={feature.label}
                      onChange={(e) => updateFeature(index, { label: e.target.value })}
                      placeholder="Feature name"
                      className={feature.isNew && !feature.label ? 'border-orange-200' : ''}
                    />
                  </div>

                  <div className="flex items-center space-x-2">
                    <Switch
                      checked={feature.is_included}
                      onCheckedChange={(checked) => updateFeature(index, { is_included: checked })}
                    />
                    <Label className="text-sm">
                      {feature.is_included ? 'Included' : 'Not included'}
                    </Label>
                  </div>

                  <Button
                    type="button"
                    variant="outline"
                    size="sm"
                    onClick={() => removeFeature(index)}
                  >
                    <Trash2 className="w-4 h-4" />
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}

          <div className="flex space-x-2">
            <Button
              type="button"
              variant="outline"
              onClick={addFeature}
              className="flex-1"
            >
              <Plus className="w-4 h-4 mr-2" />
              Add Feature
            </Button>
            <Button
              type="button"
              variant="outline"
              onClick={() => {
                const newFeatures = [
                  'Unlimited trades',
                  'Advanced analytics',
                  'CSV imports',
                  'Priority support',
                  'API access'
                ].map((label, i) => ({
                  id: `temp-bulk-${Date.now()}-${i}`,
                  plan_id: plan?.id || '',
                  label,
                  is_included: true,
                  sort_order: localFeatures.length + i + 1,
                  isNew: true
                }));
                setLocalFeatures(prev => [...prev, ...newFeatures]);
              }}
            >
              Add Common Features
            </Button>
          </div>
        </div>

        <div className="flex justify-end space-x-2 pt-4">
          <Button
            type="button"
            variant="outline"
            onClick={() => onOpenChange(false)}
            disabled={loading}
          >
            Cancel
          </Button>
          <Button onClick={handleSubmit} disabled={loading}>
            {loading ? 'Saving...' : 'Save Features'}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}