import { useEffect, useState } from "react";
import { Navigate, useLocation } from "react-router-dom";
import { useAuth } from "@/hooks/useAuth";
import { usePermissions, hasAnyPermission } from "@/hooks/usePermissions";
import { toast } from "@/hooks/use-toast";

interface ProtectedAdminRouteProps {
  children: React.ReactNode;
  requiredPermissions?: string[];
}

export function ProtectedAdminRoute({ children, requiredPermissions = ["view_all"] }: ProtectedAdminRouteProps) {
  const { user, loading } = useAuth();
  const { permissions, loading: permissionsLoading } = usePermissions();
  const [hasAccess, setHasAccess] = useState<boolean | null>(null);
  const location = useLocation();

  useEffect(() => {
    if (!user) {
      setHasAccess(false);
      return;
    }

    if (permissionsLoading) {
      return;
    }

    const access = hasAnyPermission(permissions, requiredPermissions);
    setHasAccess(access);

    if (!access) {
      toast({
        title: "Access Denied",
        description: "आपको इस पेज को access करने की permission नहीं है।",
        variant: "destructive",
      });
    }
  }, [user, permissions, permissionsLoading, requiredPermissions]);

  if (loading || permissionsLoading || hasAccess === null) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
      </div>
    );
  }

  if (!user || !hasAccess) {
    return <Navigate to="/auth" replace state={{ from: location }} />;
  }

  return <>{children}</>;
}