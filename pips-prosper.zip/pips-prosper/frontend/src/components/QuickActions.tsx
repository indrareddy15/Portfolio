import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Plus, BarChart3, Upload, ShieldCheck, Calendar, TrendingUp, Download, Settings } from "lucide-react"
import { useNavigate } from "react-router-dom"
import { useToast } from "@/hooks/use-toast"

export function QuickActions() {
  const navigate = useNavigate()
  const { toast } = useToast()

  const quickActions = [
    {
      title: "Add Trade",
      description: "Log a new trade",
      icon: Plus,
      onClick: () => {
        navigate("/app/journal")
        toast({
          title: "Add Trade",
          description: "Navigate to journal to add a new trade",
        })
      },
      variant: "default" as const
    },
    {
      title: "Import CSV",
      description: "Import trade data",
      icon: Upload,
      onClick: () => {
        navigate("/app/imports")
        toast({
          title: "Import System",
          description: "Loading import wizard",
        })
      },
      variant: "outline" as const
    },
    {
      title: "Analytics",
      description: "View performance",
      icon: BarChart3,
      onClick: () => {
        navigate("/app/analytics")
        toast({
          title: "Analytics Dashboard",
          description: "Loading your trading analytics",
        })
      },
      variant: "outline" as const
    },
    {
      title: "Prop Metrics",
      description: "Check challenge",
      icon: ShieldCheck,
      onClick: () => {
        navigate("/app/prop")
        toast({
          title: "Prop Metrics",
          description: "Loading prop firm challenge tracker",
        })
      },
      variant: "outline" as const
    }
  ]

  return (
    <Card className="hover:shadow-md transition-all duration-300">
      <CardHeader className="pb-4">
        <CardTitle className="text-lg font-poppins flex items-center gap-2">
          <TrendingUp className="h-5 w-5 text-primary" />
          Quick Actions
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-3">
        <div className="grid grid-cols-1 gap-2">
          {quickActions.map((action) => (
            <Button
              key={action.title}
              variant={action.variant}
              onClick={action.onClick}
              className="justify-start h-auto p-3 group transition-all duration-200"
            >
              <div className="flex items-center gap-3 w-full">
                <div className="p-1.5 rounded-md bg-primary/10 group-hover:bg-primary/20 transition-colors">
                  <action.icon className="h-4 w-4 text-primary" />
                </div>
                <div className="text-left flex-1 min-w-0">
                  <div className="font-medium text-sm">{action.title}</div>
                  <div className="text-xs text-muted-foreground truncate">
                    {action.description}
                  </div>
                </div>
              </div>
            </Button>
          ))}
        </div>
        
        <div className="pt-2 border-t border-border">
          <Button 
            variant="ghost" 
            size="sm" 
            onClick={() => navigate("/app/settings")}
            className="w-full justify-start text-muted-foreground hover:text-foreground"
          >
            <Settings className="h-4 w-4 mr-2" />
            More Settings
          </Button>
        </div>
      </CardContent>
    </Card>
  )
}