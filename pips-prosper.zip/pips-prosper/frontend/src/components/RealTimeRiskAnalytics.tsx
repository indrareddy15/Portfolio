import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { 
  Shield, 
  AlertTriangle, 
  TrendingDown,
  Target,
  Activity,
  Wifi,
  DollarSign,
  BarChart3,
  Zap
} from "lucide-react";

interface RiskMetrics {
  maxDrawdown: number;
  currentDrawdown: number;
  riskOfRuin: number;
  sharpeRatio: number;
  volatility: number;
  averageRisk: number;
  maxRisk: number;
  consecutiveLosses: number;
  riskRewardRatio: number;
  riskScore: 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL';
}

export function RealTimeRiskAnalytics() {
  const [riskMetrics, setRiskMetrics] = useState<RiskMetrics | null>(null);
  const [loading, setLoading] = useState(true);
  const [lastUpdate, setLastUpdate] = useState(new Date());
  const { user } = useAuth();
  const { toast } = useToast();

  const calculateRiskMetrics = (trades: any[]): RiskMetrics => {
    if (trades.length === 0) {
      return {
        maxDrawdown: 0,
        currentDrawdown: 0,
        riskOfRuin: 0,
        sharpeRatio: 0,
        volatility: 0,
        averageRisk: 0,
        maxRisk: 0,
        consecutiveLosses: 0,
        riskRewardRatio: 0,
        riskScore: 'LOW'
      };
    }

    // Calculate running equity for drawdown analysis
    let runningPnL = 0;
    let peak = 0;
    let maxDrawdown = 0;
    let currentDrawdown = 0;
    
    const pnlArray: number[] = [];
    const riskArray: number[] = [];
    
    trades.forEach((trade, index) => {
      const tradePnl = trade.pnl || 0;
      runningPnL += tradePnl;
      
      if (runningPnL > peak) {
        peak = runningPnL;
      }
      
      const drawdown = peak - runningPnL;
      if (drawdown > maxDrawdown) {
        maxDrawdown = drawdown;
      }
      
      // Current drawdown (from peak to current)
      if (index === trades.length - 1) {
        currentDrawdown = drawdown;
      }
      
      pnlArray.push(tradePnl);
      
      // Calculate risk per trade (assume 1% of account if no risk_percent)
      const riskAmount = Math.abs(trade.entry_price - (trade.stop_loss || trade.entry_price * 0.99));
      riskArray.push(riskAmount);
    });

    // Calculate volatility (standard deviation of P&L)
    const avgPnL = pnlArray.reduce((sum, pnl) => sum + pnl, 0) / pnlArray.length;
    const variance = pnlArray.reduce((sum, pnl) => sum + Math.pow(pnl - avgPnL, 2), 0) / pnlArray.length;
    const volatility = Math.sqrt(variance);

    // Calculate Sharpe Ratio (simplified)
    const sharpeRatio = volatility > 0 ? avgPnL / volatility : 0;

    // Calculate consecutive losses
    let maxConsecutiveLosses = 0;
    let currentConsecutiveLosses = 0;
    
    trades.forEach(trade => {
      if ((trade.pnl || 0) < 0) {
        currentConsecutiveLosses++;
        maxConsecutiveLosses = Math.max(maxConsecutiveLosses, currentConsecutiveLosses);
      } else {
        currentConsecutiveLosses = 0;
      }
    });

    // Calculate average and max risk
    const averageRisk = riskArray.length > 0 ? riskArray.reduce((sum, risk) => sum + risk, 0) / riskArray.length : 0;
    const maxRisk = riskArray.length > 0 ? Math.max(...riskArray) : 0;

    // Calculate Risk/Reward Ratio
    const winningTrades = trades.filter(t => (t.pnl || 0) > 0);
    const losingTrades = trades.filter(t => (t.pnl || 0) < 0);
    
    const avgWin = winningTrades.length > 0 ? 
      winningTrades.reduce((sum, t) => sum + (t.pnl || 0), 0) / winningTrades.length : 0;
    const avgLoss = losingTrades.length > 0 ? 
      Math.abs(losingTrades.reduce((sum, t) => sum + (t.pnl || 0), 0) / losingTrades.length) : 0;
    
    const riskRewardRatio = avgLoss > 0 ? avgWin / avgLoss : 0;

    // Risk of Ruin calculation (simplified Kelly Criterion)
    const winRate = trades.length > 0 ? winningTrades.length / trades.length : 0;
    const riskOfRuin = winRate < 0.5 ? 100 : Math.max(0, 100 * Math.pow((1 - winRate) / winRate, 10));

    // Calculate overall risk score
    let riskScore: 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL' = 'LOW';
    
    if (maxDrawdown > 5000 || riskOfRuin > 50 || maxConsecutiveLosses > 10) {
      riskScore = 'CRITICAL';
    } else if (maxDrawdown > 2000 || riskOfRuin > 20 || maxConsecutiveLosses > 5) {
      riskScore = 'HIGH';
    } else if (maxDrawdown > 500 || riskOfRuin > 5 || maxConsecutiveLosses > 3) {
      riskScore = 'MEDIUM';
    }

    return {
      maxDrawdown,
      currentDrawdown,
      riskOfRuin,
      sharpeRatio,
      volatility,
      averageRisk,
      maxRisk,
      consecutiveLosses: maxConsecutiveLosses,
      riskRewardRatio,
      riskScore
    };
  };

  const fetchRiskAnalytics = async () => {
    if (!user) return;

    try {
      setLoading(true);

      const { data: trades, error } = await supabase
        .from('trades')
        .select('*')
        .eq('user_id', user.id)
        .not('closed_at', 'is', null)
        .not('pnl', 'is', null)
        .order('closed_at', { ascending: true });

      if (error) throw error;

      const metrics = calculateRiskMetrics(trades || []);
      setRiskMetrics(metrics);
      setLastUpdate(new Date());
    } catch (error: any) {
      console.error('Error fetching risk analytics:', error);
      toast({
        variant: "destructive",
        title: "Error loading risk analytics",
        description: error.message,
      });
    } finally {
      setLoading(false);
    }
  };

  // Real-time subscription
  useEffect(() => {
    fetchRiskAnalytics();

    if (!user) return;

    const channel = supabase
      .channel(`risk-analytics-${user.id}`)
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'trades',
          filter: `user_id=eq.${user.id}`,
        },
        (payload) => {
          console.log('Real-time risk update:', payload);
          fetchRiskAnalytics();
          
          if (payload.eventType === 'INSERT' || payload.eventType === 'UPDATE') {
            toast({
              title: "🛡️ Risk Analysis Updated",
              description: "Risk metrics recalculated with latest trade data",
              duration: 2000,
            });
          }
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [user]);

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 2
    }).format(value);
  };

  const formatPercent = (value: number) => {
    return `${value.toFixed(1)}%`;
  };

  const getRiskScoreColor = (score: string) => {
    switch (score) {
      case 'LOW': return 'bg-success/10 text-success border-success/20';
      case 'MEDIUM': return 'bg-warning/10 text-warning border-warning/20';
      case 'HIGH': return 'bg-danger/10 text-danger border-danger/20';
      case 'CRITICAL': return 'bg-red-600/10 text-red-600 border-red-600/20 animate-pulse';
      default: return 'bg-muted/10 text-muted-foreground border-muted/20';
    }
  };

  if (loading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Shield className="h-5 w-5" />
            Risk Analytics
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {[1,2,3,4].map(i => (
              <div key={i} className="animate-pulse">
                <div className="h-16 bg-muted rounded-lg"></div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    );
  }

  if (!riskMetrics) return null;

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="flex items-center gap-2">
              <Shield className="h-5 w-5 text-primary" />
              Real-Time Risk Analytics
              <Badge variant="outline" className="ml-2 text-xs">
                <Wifi className="w-3 h-3 mr-1" />
                Live
              </Badge>
            </CardTitle>
            <div className="flex items-center gap-2">
              <Badge className={`${getRiskScoreColor(riskMetrics.riskScore)} text-xs font-medium`}>
                Risk: {riskMetrics.riskScore}
              </Badge>
              <div className="text-xs text-muted-foreground">
                Updated: {lastUpdate.toLocaleTimeString()}
              </div>
            </div>
          </div>
          <p className="text-sm text-muted-foreground">
            Comprehensive risk assessment with real-time updates
          </p>
        </CardHeader>
        <CardContent>
          {/* Risk Score Alert */}
          {riskMetrics.riskScore === 'CRITICAL' && (
            <Alert className="mb-6 border-red-200 bg-red-50 dark:bg-red-950/20">
              <AlertTriangle className="h-4 w-4 text-red-600" />
              <AlertDescription className="text-red-800 dark:text-red-200">
                <strong>Critical Risk Level Detected!</strong> Immediate attention required. 
                Consider reducing position sizes and reviewing risk management strategies.
              </AlertDescription>
            </Alert>
          )}

          {/* Key Risk Metrics Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mb-6">
            {/* Max Drawdown */}
            <Card className="p-4">
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm font-medium text-muted-foreground">Max Drawdown</span>
                <TrendingDown className="h-4 w-4 text-danger" />
              </div>
              <div className={`text-2xl font-bold ${riskMetrics.maxDrawdown > 1000 ? 'text-danger' : 'text-warning'}`}>
                {formatCurrency(riskMetrics.maxDrawdown)}
              </div>
              <div className="text-xs text-muted-foreground mt-1">
                Current: {formatCurrency(riskMetrics.currentDrawdown)}
              </div>
            </Card>

            {/* Risk of Ruin */}
            <Card className="p-4">
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm font-medium text-muted-foreground">Risk of Ruin</span>
                <AlertTriangle className="h-4 w-4 text-warning" />
              </div>
              <div className={`text-2xl font-bold ${riskMetrics.riskOfRuin > 20 ? 'text-danger' : riskMetrics.riskOfRuin > 5 ? 'text-warning' : 'text-success'}`}>
                {formatPercent(riskMetrics.riskOfRuin)}
              </div>
              <Progress value={Math.min(riskMetrics.riskOfRuin, 100)} className="mt-2" />
            </Card>

            {/* Sharpe Ratio */}
            <Card className="p-4">
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm font-medium text-muted-foreground">Sharpe Ratio</span>
                <BarChart3 className="h-4 w-4 text-primary" />
              </div>
              <div className={`text-2xl font-bold ${riskMetrics.sharpeRatio > 1 ? 'text-success' : riskMetrics.sharpeRatio > 0 ? 'text-warning' : 'text-danger'}`}>
                {riskMetrics.sharpeRatio.toFixed(2)}
              </div>
              <div className="text-xs text-muted-foreground mt-1">
                Risk-adjusted returns
              </div>
            </Card>
          </div>

          {/* Additional Risk Metrics */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card className="p-4">
              <h4 className="font-semibold mb-3 flex items-center gap-2">
                <Target className="h-4 w-4" />
                Risk Management
              </h4>
              <div className="space-y-3">
                <div className="flex justify-between items-center">
                  <span className="text-sm text-muted-foreground">Avg Risk per Trade:</span>
                  <span className="font-medium">{formatCurrency(riskMetrics.averageRisk)}</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm text-muted-foreground">Max Risk Taken:</span>
                  <span className="font-medium text-warning">{formatCurrency(riskMetrics.maxRisk)}</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm text-muted-foreground">Risk:Reward Ratio:</span>
                  <span className={`font-medium ${riskMetrics.riskRewardRatio > 1 ? 'text-success' : 'text-danger'}`}>
                    1:{riskMetrics.riskRewardRatio.toFixed(2)}
                  </span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm text-muted-foreground">Max Consecutive Losses:</span>
                  <Badge variant={riskMetrics.consecutiveLosses > 5 ? "destructive" : riskMetrics.consecutiveLosses > 3 ? "secondary" : "default"}>
                    {riskMetrics.consecutiveLosses}
                  </Badge>
                </div>
              </div>
            </Card>

            <Card className="p-4">
              <h4 className="font-semibold mb-3 flex items-center gap-2">
                <Activity className="h-4 w-4" />
                Volatility Analysis
              </h4>
              <div className="space-y-3">
                <div className="flex justify-between items-center">
                  <span className="text-sm text-muted-foreground">P&L Volatility:</span>
                  <span className="font-medium">{formatCurrency(riskMetrics.volatility)}</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm text-muted-foreground">Risk Score:</span>
                  <Badge className={getRiskScoreColor(riskMetrics.riskScore)}>
                    {riskMetrics.riskScore}
                  </Badge>
                </div>
                <div className="mt-4 p-3 bg-blue-50 dark:bg-blue-950/20 rounded-lg border border-blue-200 dark:border-blue-800">
                  <div className="flex items-center gap-2 text-blue-900 dark:text-blue-100 text-sm">
                    <Zap className="w-4 h-4" />
                    <span className="font-medium">Real-time Monitoring</span>
                  </div>
                  <p className="text-xs text-blue-800 dark:text-blue-200 mt-1">
                    Risk metrics update automatically with each trade
                  </p>
                </div>
              </div>
            </Card>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}