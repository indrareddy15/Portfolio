import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Check, Zap, Crown, Star } from "lucide-react";
import { useAuth } from "@/hooks/useAuth";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "@/hooks/use-toast";

const plans = [
  {
    name: "FREE Forever",
    monthlyPrice: "$0",
    yearlyPrice: "$0",
    period: "forever",
    description: "Everything you need - completely FREE",
    icon: Star,
    features: [
      "✅ Unlimited trades & accounts",
      "✅ Advanced analytics & charts", 
      "✅ CSV imports (MT4/MT5/cTrader)",
      "✅ AI Trading Coach",
      "✅ Prop-firm readiness tracking",
      "✅ Psychology analysis",
      "✅ Session analysis",
      "✅ Unlimited screenshots",
      "✅ Email & priority support",
      "✅ All current features included"
    ],
    limitations: [],
    cta: "Get Started FREE",
    variant: "primary" as const,
    popular: true,
    current: true
  },
  {
    name: "Premium", 
    monthlyPrice: "$29",
    yearlyPrice: "$290",
    period: "per month",
    description: "🚀 Coming Soon - Advanced features",
    icon: Zap,
    features: [
      "🔄 Auto Trade Sync (All platforms)",
      "📊 Real-time portfolio tracking",
      "🤖 Advanced AI insights",
      "📈 Predictive analytics",
      "⚡ Instant notifications",
      "🔗 API integrations",
      "📱 Mobile app priority access",
      "☁️ Cloud backups"
    ],
    limitations: [],
    cta: "Coming Soon",
    variant: "outline" as const,
    popular: false,
    future: true
  },
  {
    name: "Enterprise",
    monthlyPrice: "$99",
    yearlyPrice: "$990", 
    period: "per month",
    description: "🚀 Coming Soon - For trading firms",
    icon: Crown,
    features: [
      "🏢 Everything in Premium",
      "👥 Team collaboration",
      "🎨 White-label options",
      "📊 Custom reporting",
      "🔐 Advanced security",
      "☎️ Dedicated support",
      "🔌 Custom integrations",
      "📈 Portfolio management"
    ],
    limitations: [],
    cta: "Coming Soon",
    variant: "glass" as const,
    popular: false,
    future: true
  }
];

export const PricingSection = () => {
  const [isYearly, setIsYearly] = useState(false);
  const [loading, setLoading] = useState<string | null>(null);
  const navigate = useNavigate();
  const { user } = useAuth();

  const handleChoosePlan = async (plan: typeof plans[0]) => {
    setLoading(plan.name);
    
    // For current free plan, redirect to signup
    if (plan.current) {
      if (!user) {
        toast({
          title: "Get Started FREE! 🎉",
          description: "Redirecting to create your free account",
          duration: 2000,
        });
        navigate("/auth");
      } else {
        toast({
          title: "Welcome Back! 🚀",
          description: "Redirecting to your dashboard",
          duration: 2000,
        });
        navigate("/app");
      }
      setTimeout(() => setLoading(null), 1000);
      return;
    }

    // For future plans, show coming soon message
    if (plan.future) {
      toast({
        title: "Coming Soon! 🚀",
        description: `${plan.name} plan will be available soon. For now, enjoy all features FREE!`,
        duration: 4000,
      });
      setTimeout(() => setLoading(null), 1000);
      return;
    }

    // Fallback for any other plans
    if (!user) {
      navigate("/auth");
      setTimeout(() => setLoading(null), 1000);
      return;
    }

    navigate("/subscription");
    setTimeout(() => setLoading(null), 1000);
  };

  const handleStartFreeNow = () => {
    if (!user) {
      toast({
        title: "Get Started FREE! 🎉",
        description: "Creating your free account with all premium features",
        duration: 3000,
      });
      navigate("/auth");
    } else {
      toast({
        title: "Welcome Back! 🚀",
        description: "Accessing your dashboard with all features",
        duration: 2000,
      });
      navigate("/app");
    }
  };

  const handleJoinWaitlist = () => {
    toast({
      title: "Waitlist Joined! 📧",
      description: "We'll notify you when premium features are ready. For now, enjoy everything FREE!",
      duration: 4000,
    });
  };

  const handleContactSupport = () => {
    toast({
      title: "Contact Support 💬",
      description: "Opening support chat to help with any questions",
      duration: 3000,
    });
    // Could integrate with support system later
  };

  return (
    <section id="pricing" className="py-20 relative">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center mb-12 sm:mb-16 px-4 sm:px-0">
          <h2 className="text-2xl sm:text-3xl md:text-4xl lg:text-5xl font-poppins font-bold mb-4 sm:mb-6">
            <span className="bg-gradient-primary bg-clip-text text-transparent">
              Everything FREE
            </span>
            {" "}Right Now + Future Plans
          </h2>
          <p className="text-lg sm:text-xl text-muted-foreground max-w-4xl mx-auto mb-6 sm:mb-8 leading-relaxed">
            🎉 <span className="text-success font-semibold">All features are currently 100% FREE!</span> 
            We're building something amazing for traders. Enjoy unlimited access to everything while we develop 
            premium features like Auto Trade Sync.
          </p>
          
          <div className="bg-gradient-to-r from-success/10 to-primary/10 border border-success/20 rounded-2xl p-4 sm:p-6 mb-8 max-w-3xl mx-auto">
            <div className="text-center">
              <h3 className="text-lg sm:text-xl font-bold text-success mb-2">
                🚀 Limited Time: Everything FREE Forever!
              </h3>
              <p className="text-sm sm:text-base text-muted-foreground">
                No credit card required • No hidden costs • Full premium features included
              </p>
            </div>
          </div>
          
          {/* Future Plans Toggle */}
          <div className="inline-flex items-center bg-muted rounded-lg p-1">
            <button 
              onClick={() => setIsYearly(false)}
              className={`px-3 sm:px-4 py-2 text-xs sm:text-sm font-medium transition-colors ${
                !isYearly 
                  ? 'bg-success text-success-foreground rounded-md' 
                  : 'text-muted-foreground hover:text-foreground'
              }`}
            >
              Current (FREE)
            </button>
            <button 
              onClick={() => setIsYearly(true)}
              className={`px-3 sm:px-4 py-2 text-xs sm:text-sm font-medium transition-colors ${
                isYearly 
                  ? 'bg-warning text-warning-foreground rounded-md' 
                  : 'text-muted-foreground hover:text-foreground'
              }`}
            >
              Future Plans
            </button>
          </div>
        </div>

        {/* Pricing Cards */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 sm:gap-8 max-w-6xl mx-auto px-4 sm:px-0">
          {plans.map((plan, index) => {
            const IconComponent = plan.icon;
            const showPlan = isYearly ? plan.future : plan.current;
            if (!showPlan && !(!isYearly && !plan.current && !plan.future)) {
              if (isYearly && !plan.future) return null;
              if (!isYearly && !plan.current && plan.future) return null;
            }
            
            return (
              <div 
                key={index}
                className={`relative glass-card p-6 sm:p-8 transition-all duration-300 ${
                  plan.popular 
                    ? 'ring-2 ring-primary shadow-glow scale-105' 
                    : 'hover:shadow-card'
                } ${plan.future && !isYearly ? 'opacity-60' : ''} ${
                  plan.future ? 'border-warning/30 bg-warning/5' : ''
                } ${plan.current ? 'border-success/30 bg-success/5' : ''}`}
              >
                {/* Popular/Current/Future Badge */}
                {plan.popular && plan.current && (
                  <div className="absolute -top-3 sm:-top-4 left-1/2 transform -translate-x-1/2">
                    <div className="bg-gradient-to-r from-success to-primary text-white px-3 sm:px-4 py-1 rounded-full text-xs sm:text-sm font-semibold animate-pulse">
                      FREE NOW! 🎉
                    </div>
                  </div>
                )}
                {plan.future && (
                  <div className="absolute -top-3 sm:-top-4 left-1/2 transform -translate-x-1/2">
                    <div className="bg-gradient-to-r from-warning to-orange-500 text-white px-3 sm:px-4 py-1 rounded-full text-xs sm:text-sm font-semibold">
                      Coming Soon 🚀
                    </div>
                  </div>
                )}

                {/* Plan Header */}
                <div className="text-center mb-6 sm:mb-8">
                  <div className={`w-10 h-10 sm:w-12 sm:h-12 rounded-lg bg-gradient-glass flex items-center justify-center mx-auto mb-3 sm:mb-4 ${
                    plan.popular ? 'glow' : ''
                  } ${plan.future ? 'animate-pulse' : ''}`}>
                    <IconComponent className={`w-5 h-5 sm:w-6 sm:h-6 ${
                      plan.current ? 'text-success' : plan.future ? 'text-warning' : 'text-primary'
                    }`} />
                  </div>
                  <h3 className="text-xl sm:text-2xl font-poppins font-bold text-foreground mb-2">
                    {plan.name}
                  </h3>
                  <div className="mb-2">
                    <span className={`text-2xl sm:text-3xl lg:text-4xl font-bold ${
                      plan.current ? 'text-success' : 'text-foreground'
                    }`}>
                      {plan.current ? 'FREE' : (isYearly ? plan.yearlyPrice : plan.monthlyPrice)}
                    </span>
                    {!plan.current && (
                      <span className="text-sm sm:text-base text-muted-foreground">
                        /{isYearly ? 'year' : plan.period}
                      </span>
                    )}
                  </div>
                  <p className="text-sm sm:text-base text-muted-foreground">{plan.description}</p>
                </div>

                {/* Features List */}
                <div className="space-y-3 sm:space-y-4 mb-6 sm:mb-8">
                  {plan.features.map((feature, featureIndex) => (
                    <div key={featureIndex} className="flex items-start space-x-3">
                      <Check className={`w-4 h-4 sm:w-5 sm:h-5 flex-shrink-0 mt-0.5 ${
                        plan.current ? 'text-success' : plan.future ? 'text-warning' : 'text-success'
                      }`} />
                      <span className="text-sm sm:text-base text-foreground">{feature}</span>
                    </div>
                  ))}
                </div>

                {/* CTA Button */}
                <Button 
                  variant={plan.current ? 'primary' : plan.future ? 'outline' : plan.variant} 
                  className={`w-full text-sm sm:text-base ${
                    plan.current ? 'glow-hover bg-success hover:bg-success/90' : 
                    plan.future ? 'border-warning text-warning hover:bg-warning/10' : 
                    plan.popular ? 'glow-hover' : ''
                  }`}
                  size="lg"
                  onClick={() => handleChoosePlan(plan)}
                  disabled={loading === plan.name}
                >
                  {loading === plan.name ? 'Loading...' : plan.cta}
                </Button>
              </div>
            );
          })}
        </div>

        {/* Bottom CTA */}
        <div className="text-center mt-12 sm:mt-16 px-4 sm:px-0">
          <div className="bg-gradient-to-r from-success/10 to-primary/10 border border-success/20 rounded-2xl p-6 sm:p-8 max-w-2xl mx-auto mb-8">
            <h3 className="text-xl sm:text-2xl font-bold text-success mb-4">
              🎉 Everything FREE While We Build The Future!
            </h3>
            <p className="text-sm sm:text-base text-muted-foreground mb-4">
              We're working hard on Auto Trade Sync and other premium features. 
              Until then, enjoy everything completely FREE with no limitations.
            </p>
            <div className="flex flex-col sm:flex-row gap-3 justify-center">
              <Button 
                variant="primary" 
                size="lg" 
                className="glow-hover"
                onClick={handleStartFreeNow}
              >
                Start Using FREE Now
              </Button>
              <Button 
                variant="outline" 
                size="lg"
                onClick={handleJoinWaitlist}
              >
                Join Waitlist for Premium
              </Button>
            </div>
          </div>
          
          <p className="text-sm sm:text-base text-muted-foreground mb-4">
            Questions about our plans? We're here to help.
          </p>
          <Button 
            variant="ghost" 
            className="text-sm sm:text-base"
            onClick={handleContactSupport}
          >
            Contact Support
          </Button>
        </div>
      </div>
    </section>
  );
};