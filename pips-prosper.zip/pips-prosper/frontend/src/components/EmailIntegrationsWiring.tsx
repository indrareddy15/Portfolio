import { useEffect } from 'react';
import { useSupabaseAuth } from '@/hooks/useSupabaseAuth';
import { useEmailService } from '@/hooks/useEmailService';
import { supabase } from '@/integrations/supabase/client';

// This component wires up email sending for various app flows
export function EmailIntegrationsWiring() {
  const emailService = useEmailService();

  useEffect(() => {
    // Wire up affiliate approval emails
    const handleAffiliateApproval = async (payload: any) => {
      if (payload.eventType === 'INSERT' && payload.new.status === 'active') {
        try {
          // Get user email and affiliate details
          const { data: profile } = await supabase
            .from('profiles')
            .select('display_name')
            .eq('user_id', payload.new.user_id)
            .single();

          const { data: user } = await supabase.auth.admin.getUserById(payload.new.user_id);
          
          if (user?.user?.email) {
            const referralLink = `${window.location.origin}?ref=${payload.new.code}`;
            await emailService.sendAffiliateApproval(
              user.user.email,
              payload.new.code,
              payload.new.default_rate_pct,
              referralLink
            );
          }
        } catch (error) {
          console.error('Failed to send affiliate approval email:', error);
        }
      }
    };

    // Wire up team invite emails
    const handleTeamInvites = async (payload: any) => {
      if (payload.eventType === 'INSERT') {
        try {
          // Handle team invitation logic here
          // This would be implemented based on your team invite system
          console.log('Team invite created:', payload.new);
        } catch (error) {
          console.error('Failed to send team invite email:', error);
        }
      }
    };

    // Wire up subscription emails
    const handleSubscriptionEmails = async (payload: any) => {
      if (payload.eventType === 'INSERT' || payload.eventType === 'UPDATE') {
        try {
          // Handle subscription confirmation/upgrade emails
          console.log('Subscription event:', payload);
        } catch (error) {
          console.error('Failed to send subscription email:', error);
        }
      }
    };

    // Set up realtime listeners for various tables
    const affiliateChannel = supabase
      .channel('affiliate-emails')
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'affiliates'
        },
        handleAffiliateApproval
      )
      .subscribe();

    return () => {
      supabase.removeChannel(affiliateChannel);
    };
  }, [emailService]);

  return null; // This is a headless component
}

// Hook to manually trigger emails from components
export function useEmailTriggers() {
  const emailService = useEmailService();

  const triggerWelcomeEmail = async (userEmail: string, userName: string) => {
    const dashboardUrl = `${window.location.origin}/app/dashboard`;
    return await emailService.sendWelcomeEmail(userEmail, userName, dashboardUrl);
  };

  const triggerPasswordReset = async (userEmail: string, resetToken: string, userName?: string) => {
    const resetUrl = `${window.location.origin}/auth/reset-password?token=${resetToken}`;
    return await emailService.sendPasswordReset(userEmail, resetUrl, userName);
  };

  const triggerEmailVerification = async (userEmail: string, verificationToken: string, userName?: string) => {
    const verificationUrl = `${window.location.origin}/auth/verify-email?token=${verificationToken}`;
    return await emailService.sendEmailVerification(userEmail, verificationUrl, userName);
  };

  const triggerTeamInvite = async (inviteeEmail: string, inviterName: string, teamName: string, inviteToken: string) => {
    const inviteUrl = `${window.location.origin}/team/join?token=${inviteToken}`;
    return await emailService.sendTeamInvite(inviteeEmail, inviterName, teamName, inviteUrl);
  };

  return {
    triggerWelcomeEmail,
    triggerPasswordReset,
    triggerEmailVerification,
    triggerTeamInvite,
    isLoading: emailService.isLoading
  };
}