import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { 
  Share2, 
  Copy, 
  Eye,
  Lock,
  Globe,
  Calendar,
  Users,
  Link,
  Shield,
  Download,
  ExternalLink
} from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";

interface PublicJournal {
  id: string;
  display_name: string | null;
  bio: string | null;
  is_public: boolean;
  public_link: string | null;
  view_count: number;
}

interface ShareLink {
  id: string;
  link_type: string;
  share_token: string;
  password_hash: string | null;
  expires_at: string | null;
  permissions: any;
  view_count: number;
  last_viewed_at: string | null;
  created_at: string;
}

const SHARE_PERMISSIONS = {
  trades: "View Trades",
  analytics: "View Analytics", 
  psychology: "View Psychology",
  consistency: "View Consistency Score",
  challenges: "View Prop Challenges",
  calendar: "View Trading Calendar"
};

export function SharingDashboard() {
  const [publicJournal, setPublicJournal] = useState<PublicJournal | null>(null);
  const [shareLinks, setShareLinks] = useState<ShareLink[]>([]);
  const [showCreateLink, setShowCreateLink] = useState(false);
  const [leaderboard, setLeaderboard] = useState<any[]>([]);
  const [joinedLeaderboard, setJoinedLeaderboard] = useState(false);
  
  // Form states
  const [journalSettings, setJournalSettings] = useState({
    display_name: "",
    bio: "",
    is_public: false,
  });

  const [newShareLink, setNewShareLink] = useState({
    link_type: "private",
    password: "",
    expires_days: "30",
    permissions: {
      trades: true,
      analytics: true,
      psychology: false,
      consistency: true,
      challenges: false,
      calendar: true
    }
  });

  const { user } = useAuth();
  const { toast } = useToast();

  useEffect(() => {
    if (user) {
      loadPublicJournal();
      loadShareLinks();
      loadLeaderboard();
    }
  }, [user]);

  const loadPublicJournal = async () => {
    if (!user) return;

    try {
      const { data, error } = await supabase
        .from("public_journals")
        .select("*")
        .eq("user_id", user.id)
        .maybeSingle();

      if (error) throw error;
      
      if (data) {
        setPublicJournal(data);
        setJournalSettings({
          display_name: data.display_name || "",
          bio: data.bio || "",
          is_public: data.is_public,
        });
      }
    } catch (error: any) {
      toast({
        variant: "destructive",
        title: "Error loading public journal",
        description: error.message,
      });
    }
  };

  const loadShareLinks = async () => {
    if (!user) return;

    try {
      const { data, error } = await supabase
        .from("share_links")
        .select("*")
        .eq("user_id", user.id)
        .order("created_at", { ascending: false });

      if (error) throw error;
      setShareLinks(data || []);
    } catch (error: any) {
      toast({
        variant: "destructive",
        title: "Error loading share links",
        description: error.message,
      });
    }
  };

  const loadLeaderboard = async () => {
    try {
      // This would be a more complex query in production
      const { data, error } = await supabase
        .from("public_journals")
        .select(`
          display_name,
          view_count,
          user_id
        `)
        .eq("is_public", true)
        .order("view_count", { ascending: false })
        .limit(10);

      if (error) throw error;
      setLeaderboard(data || []);
      
      setJoinedLeaderboard(data?.some(item => item.user_id === user?.id) || false);
    } catch (error: any) {
      // Leaderboard is optional, don't show error
      setLeaderboard([]);
    }
  };

  const savePublicJournal = async () => {
    if (!user) return;

    try {
      const publicLink = journalSettings.is_public && !publicJournal?.public_link
        ? `journal_${Array.from(crypto.getRandomValues(new Uint8Array(16)))
            .map(b => b.toString(16).padStart(2, '0'))
            .join('')}`
        : publicJournal?.public_link;

      const { error } = await supabase
        .from("public_journals")
        .upsert({
          user_id: user.id,
          display_name: journalSettings.display_name,
          bio: journalSettings.bio,
          is_public: journalSettings.is_public,
          public_link: publicLink,
        });

      if (error) throw error;

      toast({
        title: "Journal settings updated",
        description: journalSettings.is_public 
          ? "Your journal is now public!" 
          : "Your journal is now private.",
      });

      loadPublicJournal();
      loadLeaderboard();
    } catch (error: any) {
      toast({
        variant: "destructive",
        title: "Error updating journal",
        description: error.message,
      });
    }
  };

  const createShareLink = async () => {
    if (!user) return;

    try {
      const shareToken = Array.from(crypto.getRandomValues(new Uint8Array(32)))
        .map(b => b.toString(16).padStart(2, '0'))
        .join('');

      const expiresAt = newShareLink.expires_days !== "never" 
        ? new Date(Date.now() + parseInt(newShareLink.expires_days) * 24 * 60 * 60 * 1000).toISOString()
        : null;

      const { error } = await supabase
        .from("share_links")
        .insert({
          user_id: user.id,
          link_type: newShareLink.link_type,
          share_token: shareToken,
          password_hash: newShareLink.password ? btoa(newShareLink.password) : null, // In production, use proper hashing
          expires_at: expiresAt,
          permissions: newShareLink.permissions
        });

      if (error) throw error;

      toast({
        title: "Share link created",
        description: "Your private share link has been generated.",
      });

      setShowCreateLink(false);
      setNewShareLink({
        link_type: "private",
        password: "",
        expires_days: "30",
        permissions: {
          trades: true,
          analytics: true,
          psychology: false,
          consistency: true,
          challenges: false,
          calendar: true
        }
      });
      loadShareLinks();
    } catch (error: any) {
      toast({
        variant: "destructive",
        title: "Error creating share link",
        description: error.message,
      });
    }
  };

  const copyToClipboard = (text: string, label: string) => {
    navigator.clipboard.writeText(text);
    toast({
      title: "Copied!",
      description: `${label} copied to clipboard.`,
    });
  };

  const deleteShareLink = async (linkId: string) => {
    try {
      const { error } = await supabase
        .from("share_links")
        .delete()
        .eq("id", linkId);

      if (error) throw error;

      toast({
        title: "Share link deleted",
        description: "The share link has been removed.",
      });

      loadShareLinks();
    } catch (error: any) {
      toast({
        variant: "destructive",
        title: "Error deleting share link",
        description: error.message,
      });
    }
  };

  const getShareUrl = (token: string) => {
    return `${window.location.origin}/shared/${token}`;
  };

  const getPublicJournalUrl = () => {
    return publicJournal?.public_link 
      ? `${window.location.origin}/journal/${publicJournal.public_link}`
      : "";
  };

  return (
    <div className="space-y-6">
      {/* Public Journal Settings */}
      <Card className="glass-card border-card-border">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Globe className="w-5 h-5 text-primary" />
            Public Trading Journal
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <Label htmlFor="public-toggle" className="text-base font-semibold">
                Make Journal Public
              </Label>
              <p className="text-sm text-muted-foreground">
                Allow others to view your anonymized trading performance
              </p>
            </div>
            <Switch
              id="public-toggle"
              checked={journalSettings.is_public}
              onCheckedChange={(checked) => 
                setJournalSettings(prev => ({ ...prev, is_public: checked }))
              }
            />
          </div>

          {journalSettings.is_public && (
            <div className="space-y-4">
              <div>
                <Label htmlFor="display-name">Display Name</Label>
                <Input
                  id="display-name"
                  placeholder="Your trading name (optional)"
                  value={journalSettings.display_name}
                  onChange={(e) => setJournalSettings(prev => ({ ...prev, display_name: e.target.value }))}
                />
              </div>

              <div>
                <Label htmlFor="bio">Bio</Label>
                <Textarea
                  id="bio"
                  placeholder="Tell others about your trading style..."
                  value={journalSettings.bio}
                  onChange={(e) => setJournalSettings(prev => ({ ...prev, bio: e.target.value }))}
                  rows={3}
                />
              </div>

              {publicJournal?.public_link && (
                <div className="p-4 bg-primary/5 border border-primary/20 rounded-lg">
                  <Label className="text-sm font-medium">Public URL:</Label>
                  <div className="flex items-center gap-2 mt-1">
                    <Input 
                      value={getPublicJournalUrl()}
                      readOnly 
                      className="font-mono text-sm"
                    />
                    <Button 
                      size="sm" 
                      variant="outline"
                      onClick={() => copyToClipboard(getPublicJournalUrl(), "Public journal URL")}
                    >
                      <Copy className="w-4 h-4" />
                    </Button>
                    <Button 
                      size="sm" 
                      variant="outline"
                      onClick={() => window.open(getPublicJournalUrl(), '_blank')}
                    >
                      <ExternalLink className="w-4 h-4" />
                    </Button>
                  </div>
                  <p className="text-xs text-muted-foreground mt-2">
                    Views: {publicJournal.view_count}
                  </p>
                </div>
              )}
            </div>
          )}

          <Button onClick={savePublicJournal}>
            Save Journal Settings
          </Button>
        </CardContent>
      </Card>

      {/* Private Share Links */}
      <Card className="glass-card border-card-border">
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="flex items-center gap-2">
              <Lock className="w-5 h-5 text-primary" />
              Private Share Links
            </CardTitle>
            <Button onClick={() => setShowCreateLink(true)}>
              <Link className="w-4 h-4 mr-2" />
              Create Link
            </Button>
          </div>
        </CardHeader>
        <CardContent className="space-y-4">
          {shareLinks.length > 0 ? (
            <>
              {shareLinks.map(link => (
                <div key={link.id} className="p-4 bg-muted/10 border border-muted/20 rounded-lg">
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center gap-2">
                      <Badge variant="outline" className="capitalize">
                        {link.link_type}
                      </Badge>
                      {link.password_hash && (
                        <Badge variant="secondary">
                          <Shield className="w-3 h-3 mr-1" />
                          Password Protected
                        </Badge>
                      )}
                    </div>
                    <div className="flex items-center gap-2 text-sm text-muted-foreground">
                      <Eye className="w-4 h-4" />
                      {link.view_count} views
                    </div>
                  </div>

                  <div className="flex items-center gap-2 mb-2">
                    <Input 
                      value={getShareUrl(link.share_token)}
                      readOnly 
                      className="font-mono text-sm"
                    />
                    <Button 
                      size="sm" 
                      variant="outline"
                      onClick={() => copyToClipboard(getShareUrl(link.share_token), "Share link")}
                    >
                      <Copy className="w-4 h-4" />
                    </Button>
                    <Button 
                      size="sm" 
                      variant="destructive"
                      onClick={() => deleteShareLink(link.id)}
                    >
                      Delete
                    </Button>
                  </div>

                  <div className="flex items-center justify-between text-sm text-muted-foreground">
                    <span>
                      Created: {new Date(link.created_at).toLocaleDateString()}
                    </span>
                    {link.expires_at && (
                      <span>
                        Expires: {new Date(link.expires_at).toLocaleDateString()}
                      </span>
                    )}
                  </div>

                  <div className="flex flex-wrap gap-1 mt-2">
                    {Object.entries(link.permissions).map(([key, enabled]) => 
                      enabled && (
                        <Badge key={key} variant="outline" className="text-xs">
                          {SHARE_PERMISSIONS[key as keyof typeof SHARE_PERMISSIONS]}
                        </Badge>
                      )
                    )}
                  </div>
                </div>
              ))}
            </>
          ) : (
            <div className="text-center py-8 text-muted-foreground">
              <Link className="w-12 h-12 mx-auto mb-4 opacity-50" />
              <p>No private share links created yet.</p>
              <p className="text-sm">Create links for coaches, investors, or prop firms.</p>
            </div>
          )}

          {/* Create Link Form */}
          {showCreateLink && (
            <div className="p-4 bg-primary/5 border border-primary/20 rounded-lg space-y-4">
              <h3 className="font-semibold">Create New Share Link</h3>
              
              <div>
                <Label>Link Type</Label>
                <Select 
                  value={newShareLink.link_type} 
                  onValueChange={(value) => setNewShareLink(prev => ({ ...prev, link_type: value }))}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="private">Private Link</SelectItem>
                    <SelectItem value="coach">Trading Coach</SelectItem>
                    <SelectItem value="investor">Investor/Prop Firm</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label>Password (Optional)</Label>
                  <Input
                    type="password"
                    placeholder="Leave empty for no password"
                    value={newShareLink.password}
                    onChange={(e) => setNewShareLink(prev => ({ ...prev, password: e.target.value }))}
                  />
                </div>

                <div>
                  <Label>Expires In</Label>
                  <Select 
                    value={newShareLink.expires_days} 
                    onValueChange={(value) => setNewShareLink(prev => ({ ...prev, expires_days: value }))}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="7">7 days</SelectItem>
                      <SelectItem value="30">30 days</SelectItem>
                      <SelectItem value="90">90 days</SelectItem>
                      <SelectItem value="365">1 year</SelectItem>
                      <SelectItem value="never">Never</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div>
                <Label className="mb-2 block">Permissions</Label>
                <div className="grid grid-cols-2 gap-3">
                  {Object.entries(SHARE_PERMISSIONS).map(([key, label]) => (
                    <div key={key} className="flex items-center space-x-2">
                      <Switch
                        id={key}
                        checked={newShareLink.permissions[key as keyof typeof newShareLink.permissions]}
                        onCheckedChange={(checked) => 
                          setNewShareLink(prev => ({
                            ...prev,
                            permissions: { ...prev.permissions, [key]: checked }
                          }))
                        }
                      />
                      <Label htmlFor={key} className="text-sm">{label}</Label>
                    </div>
                  ))}
                </div>
              </div>

              <div className="flex gap-2">
                <Button onClick={createShareLink}>
                  Create Link
                </Button>
                <Button variant="outline" onClick={() => setShowCreateLink(false)}>
                  Cancel
                </Button>
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Leaderboard */}
      <Card className="glass-card border-card-border">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Users className="w-5 h-5 text-primary" />
            Community Leaderboard
          </CardTitle>
        </CardHeader>
        <CardContent>
          {leaderboard.length > 0 ? (
            <div className="space-y-3">
              {leaderboard.map((trader, index) => (
                <div key={trader.user_id} className="flex items-center justify-between p-3 bg-muted/10 rounded-lg">
                  <div className="flex items-center gap-3">
                    <div className={`w-8 h-8 rounded-full flex items-center justify-center text-white font-bold ${
                      index === 0 ? 'bg-yellow-500' : 
                      index === 1 ? 'bg-gray-400' : 
                      index === 2 ? 'bg-orange-600' : 'bg-muted'
                    }`}>
                      {index + 1}
                    </div>
                    <div>
                      <div className="font-semibold">
                        {trader.display_name || `Trader #${trader.user_id.slice(-6)}`}
                      </div>
                      {trader.user_id === user?.id && (
                        <Badge variant="outline" className="text-xs">You</Badge>
                      )}
                    </div>
                  </div>
                  <div className="text-sm text-muted-foreground">
                    {trader.view_count} views
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-8 text-muted-foreground">
              <Users className="w-12 h-12 mx-auto mb-4 opacity-50" />
              <p>No public journals yet.</p>
              <p className="text-sm">Be the first to make your journal public!</p>
            </div>
          )}

          {!joinedLeaderboard && (
            <div className="mt-4 p-4 bg-info/5 border border-info/20 rounded-lg">
              <p className="text-sm text-info">
                💡 Make your journal public to join the leaderboard and inspire other traders!
              </p>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}