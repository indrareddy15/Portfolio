import React, { useEffect, useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts";
import { useRealtimeMetrics } from "@/hooks/useRealtimeMetrics";
import { useAccountContext } from "@/hooks/useAccountContext";
import { TrendingUp, Zap, Activity, AlertCircle } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";

export function RealTimeEquityChart() {
  const { equityData, loading } = useRealtimeMetrics();
  const { selectedAccountId } = useAccountContext();
  const { user } = useAuth();
  const { toast } = useToast();
  const [isGenerating, setIsGenerating] = useState(false);
  const [hasTradesButNoEquity, setHasTradesButNoEquity] = useState(false);
  
  // Check if user has trades but no equity data
  useEffect(() => {
    const checkTradesAndEquity = async () => {
      if (!user || loading) return;
      
      try {
        // Check if user has any trades
        const { data: trades, error: tradesError } = await supabase
          .from('trades')
          .select('id')
          .eq('user_id', user.id)
          .limit(1);
          
        if (tradesError) throw tradesError;
        
        // If user has trades but no equity data, show generation option
        if (trades && trades.length > 0 && equityData.length === 0) {
          setHasTradesButNoEquity(true);
        } else {
          setHasTradesButNoEquity(false);
        }
      } catch (error) {
        console.error('Error checking trades and equity:', error);
      }
    };
    
    checkTradesAndEquity();
  }, [user, equityData.length, loading]);
  
  // Generate equity snapshots from existing trades
  const generateEquitySnapshots = async () => {
    if (!user || isGenerating) return;
    
    setIsGenerating(true);
    try {
      // Call the realtime metrics engine to generate equity snapshots
      const { error } = await supabase.functions.invoke('realtime-metrics-engine', {
        body: { 
          user_id: user.id, 
          action: 'generate_equity_snapshots'
        }
      });
      
      if (error) throw error;
      
      toast({
        title: "Equity Data Generated ⚡",
        description: "Real-time equity snapshots have been created from your trades",
      });
      
      setHasTradesButNoEquity(false);
    } catch (error: any) {
      console.error('Error generating equity snapshots:', error);
      toast({
        variant: "destructive",
        title: "Generation failed",
        description: error.message || "Failed to generate equity snapshots",
      });
    } finally {
      setIsGenerating(false);
    }
  };

  if (loading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <TrendingUp className="h-5 w-5" />
            Equity Curve
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="h-64 animate-pulse bg-muted rounded" />
        </CardContent>
      </Card>
    );
  }

  // Prepare chart data
  const chartData = equityData.map(snapshot => ({
    timestamp: new Date(snapshot.time_utc).getTime(),
    date: new Date(snapshot.time_utc).toLocaleDateString(),
    equity: snapshot.equity_account,
    balance: snapshot.equity_account,
  }));

  // Calculate running balance for equity curve
  let runningBalance = 0;
  const equityCurveData = chartData.map(point => {
    runningBalance += point.equity;
    return {
      ...point,
      cumulativeEquity: runningBalance,
    };
  });

  // Calculate drawdown
  let peak = 0;
  const equityWithDrawdown = equityCurveData.map(point => {
    if (point.cumulativeEquity > peak) {
      peak = point.cumulativeEquity;
    }
    const drawdown = peak > 0 ? ((peak - point.cumulativeEquity) / peak) * 100 : 0;
    return {
      ...point,
      drawdown: -drawdown, // Negative for display
    };
  });

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(value);
  };

  const formatPercent = (value: number) => {
    return `${value.toFixed(1)}%`;
  };

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center gap-2">
            <TrendingUp className="h-5 w-5 text-primary" />
            Real-Time Equity Curve
            {selectedAccountId && selectedAccountId !== 'all' && (
              <span className="text-sm font-normal text-muted-foreground">
                (Selected Account)
              </span>
            )}
            <Badge variant="outline" className="ml-2 text-xs">
              <Zap className="w-3 h-3 mr-1" />
              Live
            </Badge>
          </CardTitle>
          <div className="flex items-center gap-2">
            <div className="h-2 w-2 bg-green-500 rounded-full animate-pulse"></div>
            <span className="text-xs text-muted-foreground">Real-time</span>
          </div>
        </div>
        <p className="text-sm text-muted-foreground">
          {selectedAccountId && selectedAccountId !== 'all' 
            ? 'Account-specific equity progression with drawdown analysis - updates automatically when trades are added'
            : 'Live equity progression with drawdown analysis - updates automatically when trades are added'
          }
        </p>
      </CardHeader>
      <CardContent>
        {equityWithDrawdown.length > 0 ? (
          <ResponsiveContainer width="100%" height={300}>
            <LineChart data={equityWithDrawdown}>
              <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
              <XAxis 
                dataKey="date"
                stroke="hsl(var(--muted-foreground))"
                fontSize={12}
                tickLine={false}
                axisLine={false}
              />
              <YAxis
                yAxisId="equity"
                stroke="hsl(var(--muted-foreground))"
                fontSize={12}
                tickLine={false}
                axisLine={false}
                tickFormatter={formatCurrency}
              />
              <YAxis
                yAxisId="drawdown"
                orientation="right"
                stroke="hsl(var(--muted-foreground))"
                fontSize={12}
                tickLine={false}
                axisLine={false}
                tickFormatter={formatPercent}
              />
              <Tooltip 
                content={({ active, payload, label }) => {
                  if (active && payload && payload.length) {
                    return (
                      <div className="bg-background border border-border rounded-lg p-3 shadow-lg">
                        <p className="font-medium">{label}</p>
                        {payload.map((entry, index) => (
                          <p key={index} style={{ color: entry.color }} className="text-sm">
                            {entry.dataKey === 'cumulativeEquity' ? 'Equity: ' : 'Drawdown: '}
                            {entry.dataKey === 'cumulativeEquity' 
                              ? formatCurrency(entry.value as number)
                              : formatPercent(entry.value as number)
                            }
                          </p>
                        ))}
                      </div>
                    );
                  }
                  return null;
                }}
              />
              <Line
                yAxisId="equity"
                type="monotone"
                dataKey="cumulativeEquity"
                stroke="hsl(var(--primary))"
                strokeWidth={2}
                dot={false}
                activeDot={{ r: 4, fill: "hsl(var(--primary))" }}
                name="Equity"
              />
              <Line
                yAxisId="drawdown"
                type="monotone"
                dataKey="drawdown"
                stroke="hsl(var(--danger))"
                strokeWidth={1.5}
                dot={false}
                strokeDasharray="5 5"
                name="Drawdown"
              />
            </LineChart>
          </ResponsiveContainer>
        ) : (
          <div className="h-64 flex items-center justify-center text-muted-foreground">
            <div className="text-center space-y-4">
              {hasTradesButNoEquity ? (
                <>
                  <AlertCircle className="h-12 w-12 mx-auto mb-2 text-amber-500" />
                  <div>
                    <p className="font-medium text-foreground mb-2">Equity data not generated yet</p>
                    <p className="text-sm mb-4">You have trades, but equity snapshots need to be created for real-time tracking</p>
                    <Button 
                      onClick={generateEquitySnapshots}
                      disabled={isGenerating}
                      className="gap-2"
                    >
                      {isGenerating ? (
                        <>
                          <Activity className="h-4 w-4 animate-spin" />
                          Generating...
                        </>
                      ) : (
                        <>
                          <Zap className="h-4 w-4" />
                          Generate Equity Data
                        </>
                      )}
                    </Button>
                  </div>
                </>
              ) : (
                <>
                  <TrendingUp className="h-12 w-12 mx-auto mb-2 opacity-50" />
                  <div>
                    <p className="font-medium text-foreground mb-2">No trades yet</p>
                    <p className="text-sm">Add your first trade to start tracking your real-time equity curve</p>
                    <div className="mt-4 p-3 bg-blue-50 dark:bg-blue-950/20 rounded-lg border border-blue-200 dark:border-blue-800">
                      <div className="flex items-center gap-2 text-blue-900 dark:text-blue-100 text-sm">
                        <Zap className="w-4 h-4" />
                        <span className="font-medium">Real-time Ready</span>
                      </div>
                      <p className="text-xs text-blue-800 dark:text-blue-200 mt-1">
                        Your equity curve will update automatically when you add trades
                      </p>
                    </div>
                  </div>
                </>
              )}
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}