import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Skeleton } from "@/components/ui/skeleton";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/components/ui/use-toast";
import {
  TrendingUp,
  TrendingDown,
  Target,
  DollarSign,
  Activity,
  AlertTriangle,
  Calendar,
  BarChart3,
  PieChart as PieChartIcon,
} from "lucide-react";
import { 
  PnLBarChart, 
  InstrumentPieChart, 
  EquityCurveChart, 
  WinLossHistogram,
  DailyActivityChart 
} from "@/components/Charts/TradingCharts";

interface Trade {
  id: string;
  instrument: string;
  side: string;
  entry_price: number;
  exit_price: number | null;
  size: number;
  pnl: number | null;
  pips: number | null;
  result: string | null;
  opened_at: string;
  closed_at: string | null;
  account_id: string | null;
}

interface AnalyticsData {
  totalTrades: number;
  winningTrades: number;
  losingTrades: number;
  totalPnL: number;
  totalPips: number;
  winRate: number;
  profitFactor: number;
  averageWin: number;
  averageLoss: number;
  largestWin: number;
  largestLoss: number;
  averageRR: number;
  maxDrawdown: number;
  averagePips: number;
  instrumentBreakdown: { [key: string]: { trades: number; pnl: number; pips: number; winRate: number } };
  monthlyPnL: { [key: string]: number };
}

export function AnalyticsDashboard() {
  const [analytics, setAnalytics] = useState<AnalyticsData | null>(null);
  const [trades, setTrades] = useState<Trade[]>([]);
  const [loading, setLoading] = useState(true);
  const [dateRange, setDateRange] = useState("30d");
  const { user } = useAuth();
  const { toast } = useToast();

  const calculateAnalytics = (trades: Trade[]): AnalyticsData => {
    const closedTrades = trades.filter(t => t.closed_at && t.pnl !== null);
    const winningTrades = closedTrades.filter(t => (t.pnl || 0) > 0);
    const losingTrades = closedTrades.filter(t => (t.pnl || 0) < 0);
    
    const totalPnL = closedTrades.reduce((sum, t) => sum + (t.pnl || 0), 0);
    const totalPips = closedTrades.reduce((sum, t) => sum + (t.pips || 0), 0);
    const winRate = closedTrades.length > 0 ? (winningTrades.length / closedTrades.length) * 100 : 0;
    
    const grossProfit = winningTrades.reduce((sum, t) => sum + (t.pnl || 0), 0);
    const grossLoss = Math.abs(losingTrades.reduce((sum, t) => sum + (t.pnl || 0), 0));
    const profitFactor = grossLoss > 0 ? grossProfit / grossLoss : 0;
    
    const averageWin = winningTrades.length > 0 ? grossProfit / winningTrades.length : 0;
    const averageLoss = losingTrades.length > 0 ? grossLoss / losingTrades.length : 0;
    
    const largestWin = winningTrades.length > 0 ? Math.max(...winningTrades.map(t => t.pnl || 0)) : 0;
    const largestLoss = losingTrades.length > 0 ? Math.min(...losingTrades.map(t => t.pnl || 0)) : 0;
    
    const averageRR = averageLoss > 0 ? averageWin / averageLoss : 0;
    const averagePips = closedTrades.length > 0 ? totalPips / closedTrades.length : 0;
    
    // Calculate running equity for drawdown
    let runningPnL = 0;
    let peak = 0;
    let maxDrawdown = 0;
    
    closedTrades.forEach(trade => {
      runningPnL += trade.pnl || 0;
      if (runningPnL > peak) peak = runningPnL;
      const currentDrawdown = peak - runningPnL;
      if (currentDrawdown > maxDrawdown) maxDrawdown = currentDrawdown;
    });
    
    // Instrument breakdown
    const instrumentBreakdown: { [key: string]: { trades: number; pnl: number; pips: number; winRate: number } } = {};
    closedTrades.forEach(trade => {
      if (!instrumentBreakdown[trade.instrument]) {
        instrumentBreakdown[trade.instrument] = { trades: 0, pnl: 0, pips: 0, winRate: 0 };
      }
      instrumentBreakdown[trade.instrument].trades++;
      instrumentBreakdown[trade.instrument].pnl += trade.pnl || 0;
      instrumentBreakdown[trade.instrument].pips += trade.pips || 0;
    });
    
    // Calculate win rates for each instrument
    Object.keys(instrumentBreakdown).forEach(instrument => {
      const instrumentTrades = closedTrades.filter(t => t.instrument === instrument);
      const instrumentWins = instrumentTrades.filter(t => (t.pnl || 0) > 0).length;
      instrumentBreakdown[instrument].winRate = (instrumentWins / instrumentTrades.length) * 100;
    });
    
    // Monthly P&L
    const monthlyPnL: { [key: string]: number } = {};
    closedTrades.forEach(trade => {
      const month = new Date(trade.closed_at!).toISOString().slice(0, 7); // YYYY-MM
      monthlyPnL[month] = (monthlyPnL[month] || 0) + (trade.pnl || 0);
    });
    
    return {
      totalTrades: trades.length,
      winningTrades: winningTrades.length,
      losingTrades: losingTrades.length,
      totalPnL,
      totalPips,
      winRate,
      profitFactor,
      averageWin,
      averageLoss,
      largestWin,
      largestLoss,
      averageRR,
      maxDrawdown,
      averagePips,
      instrumentBreakdown,
      monthlyPnL
    };
  };

  const fetchAnalytics = async () => {
    if (!user) return;

    try {
      setLoading(true);
      
      let query = supabase
        .from("trades")
        .select("*")
        .eq("user_id", user.id)
        .order("opened_at", { ascending: false });

      // Apply date range filter
      if (dateRange !== "all") {
        const days = parseInt(dateRange.replace("d", ""));
        const fromDate = new Date();
        fromDate.setDate(fromDate.getDate() - days);
        query = query.gte("opened_at", fromDate.toISOString());
      }

      const { data: trades, error } = await query;
      
      if (error) throw error;
      
      setTrades(trades || []);
      const analyticsData = calculateAnalytics(trades || []);
      setAnalytics(analyticsData);
      
    } catch (error: any) {
      toast({
        variant: "destructive",
        title: "Error loading analytics",
        description: error.message,
      });
    } finally {
      setLoading(false);
    }
  };

  // Enhanced real-time subscriptions for comprehensive updates
  useEffect(() => {
    fetchAnalytics();

    if (!user) return;

    // Set up real-time subscriptions for multiple tables
    const channel = supabase
      .channel(`analytics-realtime-${user.id}`)
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'trades',
          filter: `user_id=eq.${user.id}`,
        },
        (payload) => {
          console.log('Real-time trades update:', payload);
          fetchAnalytics();
          
          // Show real-time notifications for trade events
          if (payload.eventType === 'INSERT') {
            toast({
              title: "📊 New Trade Added",
              description: `${payload.new.instrument} trade recorded - Analytics updated`,
              duration: 3000,
            });
          } else if (payload.eventType === 'UPDATE') {
            toast({
              title: "📈 Trade Updated", 
              description: `${payload.new.instrument} trade modified - Recalculating metrics`,
              duration: 2000,
            });
          }
        }
      )
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'accounts',
          filter: `user_id=eq.${user.id}`,
        },
        (payload) => {
          console.log('Real-time accounts update:', payload);
          fetchAnalytics(); // Refetch when accounts change as it affects calculations
        }
      )
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'strategies',
          filter: `user_id=eq.${user.id}`,
        },
        (payload) => {
          console.log('Real-time strategies update:', payload);
          fetchAnalytics(); // Refetch when strategies change
        }
      )
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'metrics_summary',
          filter: `user_id=eq.${user.id}`,
        },
        (payload) => {
          console.log('Real-time metrics update:', payload);
          fetchAnalytics(); // Refetch when metrics are updated
        }
      )
      .subscribe((status) => {
        if (status === 'SUBSCRIBED') {
          console.log('Analytics real-time subscriptions active');
          toast({
            title: "⚡ Real-time Analytics Active",
            description: "Live updates for all trading data enabled",
            duration: 2000,
          });
        }
      });

    return () => {
      supabase.removeChannel(channel);
    };
  }, [user, dateRange, toast]);

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 2,
    }).format(amount);
  };

  const formatPercentage = (value: number) => {
    return `${value.toFixed(1)}%`;
  };

  if (loading) {
    return (
      <div className="space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {[1,2,3,4].map(i => (
            <Card key={i} className="glass-card border-card-border">
              <CardContent className="p-6">
                <div className="animate-pulse space-y-4">
                  <div className="h-4 bg-muted rounded"></div>
                  <div className="h-8 bg-muted rounded"></div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    );
  }

  if (!analytics) return null;

  return (
    <div className="space-y-8">
      {/* Date Range Selector */}
      <div className="flex items-center gap-4">
        <span className="text-sm font-medium">Time Period:</span>
        {["7d", "30d", "90d", "365d", "all"].map((range) => (
          <Button
            key={range}
            variant={dateRange === range ? "primary" : "outline"}
            size="sm"
            onClick={() => setDateRange(range)}
          >
            {range === "all" ? "All Time" : range.toUpperCase()}
          </Button>
        ))}
      </div>

      <Tabs defaultValue="overview" className="space-y-6">
        <TabsList className="grid w-full grid-cols-5">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="instruments">Instruments</TabsTrigger>
          <TabsTrigger value="performance">Performance</TabsTrigger>
          <TabsTrigger value="risk">Risk</TabsTrigger>
          <TabsTrigger value="calendar">Calendar</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-6">
          {/* Key Metrics */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            <Card className="glass-card border-card-border">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium text-muted-foreground">Total Trades</CardTitle>
                <Activity className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{analytics.totalTrades}</div>
                <p className="text-xs text-muted-foreground">
                  {analytics.winningTrades}W / {analytics.losingTrades}L
                </p>
              </CardContent>
            </Card>

            <Card className="glass-card border-card-border">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium text-muted-foreground">Win Rate</CardTitle>
                <Target className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className={`text-2xl font-bold ${analytics.winRate >= 50 ? 'text-green-600' : 'text-red-600'}`}>
                  {formatPercentage(analytics.winRate)}
                </div>
                <p className="text-xs text-muted-foreground">
                  {analytics.winRate >= 60 ? 'Excellent' : analytics.winRate >= 50 ? 'Good' : 'Needs improvement'}
                </p>
              </CardContent>
            </Card>

            <Card className="glass-card border-card-border">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium text-muted-foreground">Total P&L</CardTitle>
                <DollarSign className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className={`text-2xl font-bold ${analytics.totalPnL >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                  {formatCurrency(analytics.totalPnL)}
                </div>
                <p className="text-xs text-muted-foreground">
                  Avg: {formatCurrency(analytics.totalPnL / Math.max(analytics.totalTrades, 1))}
                </p>
              </CardContent>
            </Card>

            <Card className="glass-card border-card-border">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium text-muted-foreground">Profit Factor</CardTitle>
                <TrendingUp className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className={`text-2xl font-bold ${analytics.profitFactor >= 1.5 ? 'text-green-600' : analytics.profitFactor >= 1 ? 'text-yellow-600' : 'text-red-600'}`}>
                  {analytics.profitFactor.toFixed(2)}
                </div>
                <p className="text-xs text-muted-foreground">
                  {analytics.profitFactor >= 2 ? 'Excellent' : analytics.profitFactor >= 1.5 ? 'Good' : analytics.profitFactor >= 1 ? 'Break-even' : 'Losing'}
                </p>
              </CardContent>
            </Card>
          </div>

          {/* Additional Metrics */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <Card className="glass-card border-card-border">
              <CardHeader>
                <CardTitle>Win/Loss Analysis</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Average Win:</span>
                  <span className="font-medium text-green-600">{formatCurrency(analytics.averageWin)}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Average Loss:</span>
                  <span className="font-medium text-red-600">{formatCurrency(-analytics.averageLoss)}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Largest Win:</span>
                  <span className="font-medium text-green-600">{formatCurrency(analytics.largestWin)}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Largest Loss:</span>
                  <span className="font-medium text-red-600">{formatCurrency(analytics.largestLoss)}</span>
                </div>
              </CardContent>
            </Card>

            <Card className="glass-card border-card-border">
              <CardHeader>
                <CardTitle>Risk Metrics</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Avg R:R Ratio:</span>
                  <span className="font-medium">{analytics.averageRR.toFixed(2)}:1</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Max Drawdown:</span>
                  <span className={`font-medium ${analytics.maxDrawdown > 1000 ? 'text-red-600' : 'text-yellow-600'}`}>
                    {formatCurrency(-analytics.maxDrawdown)}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Risk Score:</span>
                  <Badge variant={analytics.maxDrawdown < 500 ? "default" : analytics.maxDrawdown < 1000 ? "secondary" : "destructive"}>
                    {analytics.maxDrawdown < 500 ? 'Low' : analytics.maxDrawdown < 1000 ? 'Medium' : 'High'}
                  </Badge>
                </div>
              </CardContent>
            </Card>

            <Card className="glass-card border-card-border">
              <CardHeader>
                <CardTitle>Performance Summary</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-center space-y-2">
                  <div className={`text-3xl font-bold ${analytics.totalPnL >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                    {analytics.totalPnL >= 0 ? '+' : ''}{formatPercentage((analytics.totalPnL / 10000) * 100)}
                  </div>
                  <p className="text-sm text-muted-foreground">Return on $10k account</p>
                  {analytics.totalTrades === 0 && (
                    <p className="text-sm text-yellow-600 mt-4">
                      <AlertTriangle className="w-4 h-4 inline mr-1" />
                      Add trades to see detailed analytics
                    </p>
                  )}
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="instruments" className="space-y-6">
          <InstrumentPieChart trades={trades} />
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {Object.entries(analytics.instrumentBreakdown).map(([instrument, data]) => (
              <Card key={instrument} className="glass-card border-card-border">
                <CardHeader>
                  <CardTitle className="text-lg">{instrument}</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-muted-foreground">Trades</span>
                    <Badge variant="outline">{data.trades}</Badge>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-muted-foreground">Win Rate</span>
                    <Badge variant={data.winRate >= 50 ? "default" : "destructive"}>
                      {data.winRate.toFixed(1)}%
                    </Badge>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-muted-foreground">P&L</span>
                    <span className={`font-semibold ${
                      data.pnl >= 0 ? 'text-success' : 'text-danger'
                    }`}>
                      {formatCurrency(data.pnl)}
                    </span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-muted-foreground">Pips</span>
                    <span className={`font-semibold ${
                      data.pips >= 0 ? 'text-success' : 'text-danger'
                    }`}>
                      {data.pips > 0 ? '+' : ''}{data.pips.toFixed(1)}
                    </span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-muted-foreground">Avg Trade</span>
                    <span className={`text-sm ${
                      (data.pnl / data.trades) >= 0 ? 'text-success' : 'text-danger'
                    }`}>
                      {formatCurrency(data.pnl / data.trades)}
                    </span>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="performance" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <EquityCurveChart trades={trades} />
            <DailyActivityChart trades={trades} />
          </div>
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <PnLBarChart trades={trades} />
            <WinLossHistogram trades={trades} />
          </div>
        </TabsContent>

        <TabsContent value="risk" className="space-y-6">
          <Card className="glass-card border-card-border">
            <CardHeader>
              <CardTitle>Risk Analysis</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-4">
                  <h4 className="font-semibold">Drawdown Analysis</h4>
                  <div className="space-y-2">
                    <div className="flex justify-between">
                      <span className="text-sm text-muted-foreground">Maximum Drawdown:</span>
                      <span className="font-medium text-red-600">{formatCurrency(-analytics.maxDrawdown)}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-sm text-muted-foreground">As % of Total P&L:</span>
                      <span className="font-medium">
                        {analytics.totalPnL > 0 ? formatPercentage((analytics.maxDrawdown / analytics.totalPnL) * 100) : 'N/A'}
                      </span>
                    </div>
                  </div>
                </div>
                
                <div className="space-y-4">
                  <h4 className="font-semibold">Risk Recommendations</h4>
                  <div className="space-y-2 text-sm">
                    {analytics.maxDrawdown > 1000 && (
                      <div className="flex items-start gap-2 text-red-600">
                        <AlertTriangle className="w-4 h-4 mt-0.5 flex-shrink-0" />
                        <span>Consider reducing position size</span>
                      </div>
                    )}
                    {analytics.winRate < 40 && (
                      <div className="flex items-start gap-2 text-yellow-600">
                        <AlertTriangle className="w-4 h-4 mt-0.5 flex-shrink-0" />
                        <span>Low win rate - review strategy</span>
                      </div>
                    )}
                    {analytics.averageRR < 1 && (
                      <div className="flex items-start gap-2 text-yellow-600">
                        <AlertTriangle className="w-4 h-4 mt-0.5 flex-shrink-0" />
                        <span>Improve risk/reward ratio</span>
                      </div>
                    )}
                    {analytics.profitFactor > 1.5 && analytics.winRate > 50 && (
                      <div className="flex items-start gap-2 text-green-600">
                        <TrendingUp className="w-4 h-4 mt-0.5 flex-shrink-0" />
                        <span>Strong performance metrics</span>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="calendar" className="space-y-6">
          <Card className="glass-card border-card-border">
            <CardHeader>
              <CardTitle>Monthly P&L Calendar</CardTitle>
            </CardHeader>
            <CardContent>
              {Object.keys(analytics.monthlyPnL).length === 0 ? (
                <div className="text-center py-8 text-muted-foreground">
                  <Calendar className="w-12 h-12 mx-auto mb-4 opacity-50" />
                  <p>No monthly data available</p>
                  <p className="text-sm">Complete some trades to see monthly breakdown</p>
                </div>
              ) : (
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                  {Object.entries(analytics.monthlyPnL)
                    .sort(([a], [b]) => b.localeCompare(a))
                    .map(([month, pnl]) => (
                    <Card key={month} className="p-4">
                      <div className="text-center">
                        <div className="text-sm text-muted-foreground mb-1">
                          {new Date(month + '-01').toLocaleDateString('en-US', { 
                            month: 'long', 
                            year: 'numeric' 
                          })}
                        </div>
                        <div className={`text-lg font-semibold ${pnl >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                          {formatCurrency(pnl)}
                        </div>
                      </div>
                    </Card>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}