import { useEffect, useState, useCallback } from "react";
import { Link } from "react-router-dom";
import { X, ExternalLink, Info, AlertTriangle, CheckCircle, AlertCircle, Bell } from "lucide-react";
import { Button } from "@/components/ui/button";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";

interface Notice {
  id: string;
  title: string;
  message: string;
  link_url?: string;
  link_text?: string;
  type: 'info' | 'success' | 'warning' | 'error';
  priority: number;
  show_on_website: boolean;
  show_on_dashboard: boolean;
  expires_at?: string;
}

interface NotificationBannerProps {
  location: 'website' | 'dashboard';
}

export const NotificationBanner = ({ location }: NotificationBannerProps) => {
  const [notices, setNotices] = useState<Notice[]>([]);
  const [dismissedNotices, setDismissedNotices] = useState<string[]>(() => {
    try {
      const saved = localStorage.getItem(`dismissed-notices-${location}`);
      return saved ? JSON.parse(saved) : [];
    } catch (error) {
      console.warn('Failed to parse dismissed notices from localStorage:', error);
      return [];
    }
  });
  const [currentNoticeIndex, setCurrentNoticeIndex] = useState(0);
  const [isVisible, setIsVisible] = useState(true);
  const [isAnimating, setIsAnimating] = useState(false);
  const { toast } = useToast();

  const fetchNotices = useCallback(async () => {
    try {
      const { data, error } = await supabase
        .from('notices')
        .select('*')
        .eq('is_active', true)
        .eq(location === 'website' ? 'show_on_website' : 'show_on_dashboard', true)
        .order('priority', { ascending: false })
        .order('created_at', { ascending: false });

      if (error) {
        console.error('Error fetching notices:', error);
        return;
      }

      if (data) {
        const validNotices = data.filter(notice => 
          !notice.expires_at || new Date(notice.expires_at) > new Date()
        ).map(notice => ({
          ...notice,
          type: notice.type as 'info' | 'success' | 'warning' | 'error'
        }));
        setNotices(validNotices);
        setCurrentNoticeIndex(0); // Reset to first notice when data changes
      }
    } catch (error) {
      console.error('Failed to fetch notices:', error);
    }
  }, [location]);

  useEffect(() => {
    fetchNotices();

    // Real-time updates with better error handling
    const channel = supabase
      .channel(`notices-realtime-${location}`)
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'notices'
        },
        (payload) => {
          console.log('Notice updated:', payload);
          fetchNotices(); // Refetch when notices change
        }
      )
      .subscribe((status) => {
        if (status === 'SUBSCRIBED') {
          console.log('Successfully subscribed to notices realtime updates');
        } else if (status === 'CHANNEL_ERROR') {
          console.error('Failed to subscribe to notices realtime updates');
        }
      });

    return () => {
      supabase.removeChannel(channel);
    };
  }, [fetchNotices]);

  // Auto-hide banner after 3 seconds once visible on page load
  useEffect(() => {
    if (!isVisible) return;
    const hideTimer = setTimeout(() => setIsVisible(false), 3000);
    return () => clearTimeout(hideTimer);
  }, [isVisible]);

  // Auto-rotate notices every 6 seconds with animation
  useEffect(() => {
    const activeNotices = notices.filter(notice => !dismissedNotices.includes(notice.id));
    if (activeNotices.length <= 1) return;

    const interval = setInterval(() => {
      setIsAnimating(true);
      setTimeout(() => {
        setCurrentNoticeIndex((prev) => (prev + 1) % activeNotices.length);
        setIsAnimating(false);
      }, 200);
    }, 6000);

    return () => clearInterval(interval);
  }, [notices, dismissedNotices]);

  const getIcon = (type: string) => {
    switch (type) {
      case 'success':
        return <CheckCircle className="h-4 w-4" />;
      case 'warning':
        return <AlertTriangle className="h-4 w-4" />;
      case 'error':
        return <AlertCircle className="h-4 w-4" />;
      default:
        return <Info className="h-4 w-4" />;
    }
  };

  const getStyles = (type: string) => {
    switch (type) {
      case 'success':
        return 'bg-gradient-to-r from-green-600 to-green-500 text-white border-green-400/30 shadow-green-500/20';
      case 'warning':
        return 'bg-gradient-to-r from-amber-600 to-yellow-500 text-white border-amber-400/30 shadow-amber-500/20';
      case 'error':
        return 'bg-gradient-to-r from-red-600 to-red-500 text-white border-red-400/30 shadow-red-500/20';
      default:
        return 'bg-gradient-to-r from-blue-600 to-blue-500 text-white border-blue-400/30 shadow-blue-500/20';
    }
  };

  const dismissNotice = useCallback((noticeId: string) => {
    try {
      const updatedDismissed = [...dismissedNotices, noticeId];
      setDismissedNotices(updatedDismissed);
      localStorage.setItem(`dismissed-notices-${location}`, JSON.stringify(updatedDismissed));
      
      // Show toast confirmation
      toast({
        title: "Notice dismissed",
        description: "You won't see this notification again.",
        duration: 2000,
      });
      
      // If this was the last notice, hide the banner gracefully
      const remainingNotices = notices.filter(notice => !updatedDismissed.includes(notice.id));
      if (remainingNotices.length === 0) {
        setIsVisible(false);
      }
    } catch (error) {
      console.error('Failed to dismiss notice:', error);
      toast({
        title: "Error",
        description: "Failed to dismiss notification. Please try again.",
        variant: "destructive",
        duration: 3000,
      });
    }
  }, [dismissedNotices, location, notices, toast]);

  const activeNotices = notices.filter(notice => !dismissedNotices.includes(notice.id));
  
  if (activeNotices.length === 0 || !isVisible) return null;

  const currentNotice = activeNotices[currentNoticeIndex % activeNotices.length];

  return (
    <div 
      className={`relative w-full ${getStyles(currentNotice.type)} border-b transition-all duration-300 ${
        isAnimating ? 'opacity-95' : 'opacity-100'
      }`}
    >
      <div className="container mx-auto px-4 py-3">
        <div className="flex items-center justify-between gap-4">
          {/* Compact Icon and Content */}
          <div className="flex items-center gap-3 flex-1 min-w-0">
            <div className="flex-shrink-0">
              <div className="p-2 bg-white/15 rounded-lg border border-white/20">
                {getIcon(currentNotice.type)}
              </div>
            </div>
            
            <div className="flex-1 min-w-0">
              <div className="flex flex-col sm:flex-row sm:items-center gap-1 sm:gap-3">
                <h3 className="font-semibold text-sm leading-tight">
                  {currentNotice.title}
                </h3>
                <p className="text-xs opacity-90 leading-relaxed">
                  {currentNotice.message}
                </p>
              </div>
            </div>
          </div>
          
          {/* Compact Actions */}
          <div className="flex items-center gap-2 flex-shrink-0">
            {/* Action Button */}
            {currentNotice.link_url && (
              <>
                {currentNotice.link_url.startsWith('http') ? (
                  <a
                    href={currentNotice.link_url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-1 px-3 py-1.5 bg-white/20 hover:bg-white/30 rounded-lg text-xs font-medium transition-all duration-200 border border-white/20"
                  >
                    {currentNotice.link_text || 'Learn More'}
                    <ExternalLink className="h-3 w-3" />
                  </a>
                ) : (
                  <Button
                    asChild
                    variant="ghost"
                    size="sm"
                    className="bg-white/20 hover:bg-white/30 text-current border border-white/20 text-xs px-3 py-1.5 h-auto rounded-lg"
                  >
                    <Link to={currentNotice.link_url}>
                      {currentNotice.link_text || 'Learn More'}
                    </Link>
                  </Button>
                )}
              </>
            )}
            
            {/* Notice counter */}
            {activeNotices.length > 1 && (
              <div className="flex items-center gap-1 px-2 py-1 bg-white/15 rounded-md text-xs font-medium border border-white/20">
                <span>{currentNoticeIndex + 1}/{activeNotices.length}</span>
              </div>
            )}
            
            {/* Dismiss Button */}
            <Button
              variant="ghost"
              size="sm"
              onClick={() => dismissNotice(currentNotice.id)}
              className="text-current hover:bg-white/20 p-1.5 h-auto rounded-lg transition-all duration-200 border border-white/20"
              title="Dismiss notification"
            >
              <X className="h-4 w-4" />
            </Button>
          </div>
        </div>
        
        {/* Compact Progress bar */}
        {activeNotices.length > 1 && (
          <div className="mt-2 w-full bg-white/15 rounded-full h-1 overflow-hidden">
            <div 
              className="bg-white/60 h-full rounded-full transition-all duration-300" 
              style={{ 
                animation: 'progress 6s linear infinite'
              }}
            />
          </div>
        )}
      </div>
    </div>
  );
};