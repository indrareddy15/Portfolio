import { useState, useEffect } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { TrendingUp, Trophy, Target } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";

interface TierInfo {
  current: number;
  level: number;
  rate: number;
  nextLevel?: number;
  nextRate?: number;
  nextTarget?: number;
  progress: number;
}

export const TierProgressWidget = () => {
  const [tierInfo, setTierInfo] = useState<TierInfo>({
    current: 0,
    level: 1,
    rate: 10,
    progress: 0
  });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchTierInfo = async () => {
      try {
        // Get current user's affiliate info
        const { data: affiliate } = await supabase
          .from('affiliates')
          .select('lifetime_approved_count, override_mode, flat_pct')
          .eq('user_id', (await supabase.auth.getUser()).data.user?.id)
          .single();

        if (affiliate) {
          const count = affiliate.lifetime_approved_count || 0;
          let level = 1;
          let rate = 10;
          let nextLevel;
          let nextRate;
          let nextTarget;
          let progress = 0;

          // Calculate tier level and rate
          if (count >= 201) {
            level = 3;
            rate = 20;
          } else if (count >= 51) {
            level = 2;
            rate = 15;
            nextLevel = 3;
            nextRate = 20;
            nextTarget = 201;
            progress = ((count - 51) / (201 - 51)) * 100;
          } else {
            level = 1;
            rate = 10;
            nextLevel = 2;
            nextRate = 15;
            nextTarget = 51;
            progress = (count / 51) * 100;
          }

          // Check for overrides
          if (affiliate.override_mode === 'flat' && affiliate.flat_pct) {
            rate = affiliate.flat_pct;
          }

          setTierInfo({
            current: count,
            level,
            rate,
            nextLevel,
            nextRate,
            nextTarget,
            progress: Math.min(progress, 100)
          });
        }
      } catch (error) {
        console.error('Error fetching tier info:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchTierInfo();
  }, []);

  if (loading) {
    return (
      <Card>
        <CardContent className="p-6">
          <div className="animate-pulse space-y-3">
            <div className="h-4 bg-muted rounded w-1/2" />
            <div className="h-8 bg-muted rounded" />
            <div className="h-4 bg-muted rounded w-3/4" />
          </div>
        </CardContent>
      </Card>
    );
  }

  const getTierColor = (level: number) => {
    switch (level) {
      case 1: return "text-blue-600 bg-blue-100 border-blue-200";
      case 2: return "text-primary bg-primary/10 border-primary/20";
      case 3: return "text-green-600 bg-green-100 border-green-200";
      default: return "text-blue-600 bg-blue-100 border-blue-200";
    }
  };

  return (
    <Card className="relative overflow-hidden">
      <CardContent className="p-6">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <Trophy className="h-5 w-5 text-primary" />
            <span className="font-semibold">Commission Tier</span>
          </div>
          <Badge className={`${getTierColor(tierInfo.level)} font-medium`}>
            Tier {tierInfo.level}
          </Badge>
        </div>

        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <div className="text-2xl font-bold text-primary">
                {tierInfo.rate}%
              </div>
              <div className="text-sm text-muted-foreground">
                Current commission rate
              </div>
            </div>
            <div className="text-right">
              <div className="text-lg font-semibold">
                {tierInfo.current}
              </div>
              <div className="text-sm text-muted-foreground">
                Approved customers
              </div>
            </div>
          </div>

          {tierInfo.nextLevel && (
            <>
              <div className="space-y-2">
                <div className="flex items-center justify-between text-sm">
                  <span>Progress to Tier {tierInfo.nextLevel}</span>
                  <span className="font-medium">
                    {tierInfo.current}/{tierInfo.nextTarget}
                  </span>
                </div>
                <Progress value={tierInfo.progress} className="h-2" />
              </div>

              <div className="bg-muted/50 rounded-lg p-3">
                <div className="flex items-center gap-2 mb-1">
                  <Target className="h-4 w-4 text-muted-foreground" />
                  <span className="text-sm font-medium">Next Milestone</span>
                </div>
                <div className="text-sm text-muted-foreground">
                  {(tierInfo.nextTarget! - tierInfo.current)} more customers to unlock{" "}
                  <span className="font-semibold text-primary">
                    {tierInfo.nextRate}%
                  </span>{" "}
                  commission rate
                </div>
              </div>
            </>
          )}

          {tierInfo.level === 3 && (
            <div className="bg-green-50 dark:bg-green-950/20 rounded-lg p-3 border border-green-200 dark:border-green-800">
              <div className="flex items-center gap-2">
                <TrendingUp className="h-4 w-4 text-green-600" />
                <span className="text-sm font-medium text-green-700 dark:text-green-300">
                  Maximum tier achieved! 
                </span>
              </div>
              <div className="text-sm text-green-600 dark:text-green-400 mt-1">
                You're earning the highest commission rate available.
              </div>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
};