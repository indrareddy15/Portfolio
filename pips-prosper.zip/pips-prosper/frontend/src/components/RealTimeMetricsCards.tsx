import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { 
  TrendingUp, 
  TrendingDown, 
  DollarSign, 
  Target, 
  Activity,
  BarChart3,
  ArrowUpDown,
  TrendingUpIcon
} from "lucide-react";
import { useRealtimeMetrics } from "@/hooks/useRealtimeMetrics";
import { useAccountContext } from "@/hooks/useAccountContext";
import { useAccountMetrics } from "@/hooks/useAccountMetrics";
import { CrossAccountComparison } from "@/components/CrossAccountComparison";

export function RealTimeMetricsCards() {
  const { selectedAccountId } = useAccountContext();
  const { metricsSummary, loading: realtimeLoading } = useRealtimeMetrics();
  const { metrics: accountMetrics, loading: accountLoading } = useAccountMetrics(selectedAccountId);
  
  // Use account-specific metrics if an account is selected, otherwise use combined metrics
  const loading = selectedAccountId && selectedAccountId !== 'all' ? accountLoading : realtimeLoading;
  const metrics = selectedAccountId && selectedAccountId !== 'all' ? accountMetrics : metricsSummary;

  if (loading) {
  return (
    <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4" data-metrics-cards>
        {Array.from({ length: 6 }).map((_, i) => (
          <Card key={i} className="animate-pulse">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <div className="h-4 bg-muted rounded w-20"></div>
              <div className="h-4 w-4 bg-muted rounded"></div>
            </CardHeader>
            <CardContent>
              <div className="h-6 bg-muted rounded w-24 mb-1"></div>
              <div className="h-3 bg-muted rounded w-16"></div>
            </CardContent>
          </Card>
        ))}
      </div>
    );
  }

  // Initialize with default values if no data
  const finalMetrics = metrics || {
    net_pnl: 0,
    win_rate: 0,
    avg_rr: 0,
    profit_factor: 0,
    expectancy: 0,
    max_dd: 0,
    trade_count: 0
  };

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 2
    }).format(value);
  };

  const formatPercent = (value: number) => {
    return `${(value * 100).toFixed(1)}%`;
  };

  const formatRatio = (value: number) => {
    return `${value.toFixed(2)}:1`;
  };

  return (
    <div className="space-y-6">
      {/* Account Comparison - Show when "All Accounts" is selected */}
      {(!selectedAccountId || selectedAccountId === 'all') && (
        <CrossAccountComparison />
      )}
      
      {/* Metrics Cards */}
      <div className="grid gap-3 sm:gap-4 grid-cols-2 md:grid-cols-3 lg:grid-cols-6" data-metrics-cards>
        {/* Net P&L */}
        <Card className="transition-all duration-200 hover:shadow-lg">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">
              Net P&L
              {selectedAccountId && selectedAccountId !== 'all' && (
                <span className="text-xs text-muted-foreground block">
                  (This Account)
                </span>
              )}
            </CardTitle>
            {(finalMetrics.net_pnl || 0) >= 0 ? (
              <TrendingUp className="h-4 w-4 text-success" />
            ) : (
              <TrendingDown className="h-4 w-4 text-danger" />
            )}
          </CardHeader>
          <CardContent>
            <div 
              className={`text-2xl font-bold ${(finalMetrics.net_pnl || 0) >= 0 ? 'text-success' : 'text-danger'}`}
            >
              {formatCurrency(finalMetrics.net_pnl || 0)}
            </div>
            <p className="text-xs text-muted-foreground">
              {selectedAccountId && selectedAccountId !== 'all' ? 'Account performance' : 'All time performance'}
            </p>
          </CardContent>
        </Card>

        {/* Win Rate */}
        <Card className="transition-all duration-200 hover:shadow-lg">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Win Rate</CardTitle>
            <Target className="h-4 w-4 text-primary" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {formatPercent(finalMetrics.win_rate || 0)}
            </div>
            <p className="text-xs text-muted-foreground">
              Winning trades percentage
            </p>
          </CardContent>
        </Card>

        {/* Average R:R */}
        <Card className="transition-all duration-200 hover:shadow-lg">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Avg R:R</CardTitle>
            <ArrowUpDown className="h-4 w-4 text-primary" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {formatRatio(finalMetrics.avg_rr || 0)}
            </div>
            <p className="text-xs text-muted-foreground">
              Risk to reward ratio
            </p>
          </CardContent>
        </Card>

        {/* Profit Factor */}
        <Card className="transition-all duration-200 hover:shadow-lg">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Profit Factor</CardTitle>
            <BarChart3 className="h-4 w-4 text-primary" />
          </CardHeader>
          <CardContent>
            <div className={`text-2xl font-bold ${
              (finalMetrics.profit_factor || 0) >= 1 ? 'text-success' : 'text-danger'
            }`}>
              {(finalMetrics.profit_factor || 0).toFixed(2)}
            </div>
            <p className="text-xs text-muted-foreground">
              Gross profit / gross loss
            </p>
          </CardContent>
        </Card>

        {/* Expectancy */}
        <Card className="transition-all duration-200 hover:shadow-lg">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Expectancy</CardTitle>
            <TrendingUpIcon className="h-4 w-4 text-primary" />
          </CardHeader>
          <CardContent>
            <div className={`text-2xl font-bold ${
              (finalMetrics.expectancy || 0) >= 0 ? 'text-success' : 'text-danger'
            }`}>
              {formatCurrency(finalMetrics.expectancy || 0)}
            </div>
            <p className="text-xs text-muted-foreground">
              Expected value per trade
            </p>
          </CardContent>
        </Card>

        {/* Max Drawdown */}
        <Card className="transition-all duration-200 hover:shadow-lg">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Max DD</CardTitle>
            <Activity className="h-4 w-4 text-danger" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-danger">
              -{formatPercent(Math.abs(finalMetrics.max_dd || 0))}
            </div>
            <p className="text-xs text-muted-foreground">
              Maximum drawdown
            </p>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}