import { Button } from "@/components/ui/button"
import { useAuth } from "@/hooks/useAuth"
import { 
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { User, Settings, LogOut, Crown } from "lucide-react"
import { useNavigate } from "react-router-dom"
import { Badge } from "@/components/ui/badge"
import { ThemeToggle } from "@/components/ThemeToggle"
import { SidebarTrigger } from "@/components/ui/sidebar";
import { AccountSwitcher } from "@/components/AccountSwitcher";
import { useAccountContext } from "@/hooks/useAccountContext";
import { ShareMetricsDialog } from "@/components/ShareMetricsDialog";
import { useAccounts } from "@/hooks/useAccounts";

interface DashboardHeaderProps {
  title?: string
}

export function DashboardHeader({ title = "Dashboard" }: DashboardHeaderProps) {
  const { user, signOut, subscriptionData } = useAuth()
  const { selectedAccountId, setSelectedAccountId } = useAccountContext()
  const { accounts } = useAccounts()
  const navigate = useNavigate()

  return (
    <header className="sticky top-0 z-50 w-full border-b border-border bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="flex h-14 items-center justify-between px-2 sm:px-4">
        <div className="flex items-center gap-2 sm:gap-3 min-w-0">
          <SidebarTrigger className="h-8 w-8 flex-shrink-0" />
          <div className="flex items-center space-x-2 min-w-0">
            <span className="font-semibold text-foreground text-sm sm:text-base truncate">{title}</span>
          </div>
        </div>

        <div className="flex items-center gap-1 sm:gap-2 md:gap-3">
          <div className="hidden sm:block">
            <AccountSwitcher
              selectedAccountId={selectedAccountId}
              onAccountChange={setSelectedAccountId}
              onAddAccount={() => navigate('/app/settings/accounts')}
            />
          </div>
          <ShareMetricsDialog 
            accounts={accounts} 
            defaultAccountId={selectedAccountId} 
          />
          <div className="hidden md:block">
            <ThemeToggle />
          </div>
          
          {user && (
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button 
                  variant="outline" 
                  className="flex items-center space-x-1 sm:space-x-2 h-8 sm:h-9 px-2 sm:px-3 bg-background border-border hover:bg-accent hover:text-accent-foreground shadow-sm"
                >
                  <div className="w-5 h-5 sm:w-6 sm:h-6 rounded-full bg-primary/10 flex items-center justify-center flex-shrink-0">
                    <User className="w-3 h-3 text-primary" />
                  </div>
                  <span className="hidden sm:inline-block text-xs sm:text-sm font-medium truncate max-w-20 md:max-w-none">
                    {user.email?.split('@')[0]}
                  </span>
                  {subscriptionData?.subscribed && (
                    <Badge variant="secondary" className="text-xs hidden md:inline-flex">
                      {subscriptionData.subscription_tier}
                    </Badge>
                  )}
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent 
                align="end" 
                className="w-64 p-2 bg-background border border-border shadow-xl rounded-lg"
                sideOffset={5}
              >
                <DropdownMenuLabel className="font-normal p-3 bg-muted/50 rounded-md mb-2">
                  <div className="flex flex-col space-y-1">
                    <p className="text-sm font-medium leading-none text-foreground">My Account</p>
                    <p className="text-xs leading-none text-muted-foreground">
                      {user.email}
                    </p>
                  </div>
                </DropdownMenuLabel>
                
                {/* Mobile-only items */}
                <div className="sm:hidden">
                  <DropdownMenuItem className="cursor-pointer rounded-md p-2 hover:bg-accent hover:text-accent-foreground">
                    <div className="w-full">
                      <AccountSwitcher
                        selectedAccountId={selectedAccountId}
                        onAccountChange={setSelectedAccountId}
                        onAddAccount={() => navigate('/app/settings/accounts')}
                      />
                    </div>
                  </DropdownMenuItem>
                  <DropdownMenuSeparator className="my-2" />
                </div>
                
                <DropdownMenuItem 
                  onClick={() => navigate('/subscription')} 
                  className="cursor-pointer rounded-md p-2 hover:bg-accent hover:text-accent-foreground"
                >
                  <Crown className="w-4 h-4 mr-3 text-amber-500" />
                  <span>Subscription</span>
                </DropdownMenuItem>
                <DropdownMenuItem 
                  onClick={() => navigate('/app/settings')} 
                  className="cursor-pointer rounded-md p-2 hover:bg-accent hover:text-accent-foreground"
                >
                  <Settings className="w-4 h-4 mr-3 text-muted-foreground" />
                  <span>Settings</span>
                </DropdownMenuItem>
                <DropdownMenuSeparator className="my-2" />
                <DropdownMenuItem 
                  onClick={signOut} 
                  className="cursor-pointer rounded-md p-2 hover:bg-destructive/10 hover:text-destructive focus:bg-destructive/10 focus:text-destructive"
                >
                  <LogOut className="w-4 h-4 mr-3" />
                  <span>Sign Out</span>
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          )}
        </div>
      </div>
    </header>
  )
}