import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, BarChart, Bar, PieChart, Pie, Cell } from "recharts";
import { useAuth } from "@/hooks/useAuth";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { AlertTriangle, TrendingUp, TrendingDown, Calendar, Target } from "lucide-react";
import { useAccountContext } from "@/hooks/useAccountContext";

interface PsychologyEntry {
  id: string;
  user_id: string;
  trade_id: string;
  mood_pre: number;
  mood_post: number;
  adherence_score: number;
  mistake_tags: string[];
  comments: string;
  created_at: string;
  updated_at: string;
}

const MISTAKE_TAGS = [
  'Revenge Trading',
  'FOMO Entry', 
  'No Stop Loss',
  'Over Leveraged',
  'Emotional Exit',
  'Poor Timing',
  'Against Trend',
  'No Plan',
  'Risk Too High',
  'Impatient',
  'Overconfident',
  'Analysis Paralysis'
];

const COLORS = ['#ef4444', '#f97316', '#eab308', '#84cc16', '#22c55e', '#06b6d4', '#3b82f6', '#8b5cf6', '#ec4899', '#f43f5e', '#64748b', '#94a3b8'];

export function RealTimeMistakesAnalytics() {
  const { user } = useAuth();
  const { toast } = useToast();
  const { selectedAccountId } = useAccountContext();
  const [entries, setEntries] = useState<PsychologyEntry[]>([]);
  const [loading, setLoading] = useState(true);
  const [mistakeAnalysis, setMistakeAnalysis] = useState<{ [key: string]: number }>({});
  const [timelineData, setTimelineData] = useState<any[]>([]);
  const [totalMistakes, setTotalMistakes] = useState(0);

  useEffect(() => {
    if (user) {
      fetchEntries();
      setupRealtimeSubscription();
    }
  }, [user, selectedAccountId]);

  useEffect(() => {
    if (entries.length > 0) {
      analyzeMistakes();
      generateTimeline();
    }
  }, [entries]);

  const fetchEntries = async () => {
    try {
      setLoading(true);
      
      let query = supabase
        .from("psychology_entries")
        .select(`
          *,
          trades!inner(account_id, opened_at, pnl)
        `)
        .eq("user_id", user!.id)
        .order("created_at", { ascending: false });

      if (selectedAccountId) {
        query = query.eq("trades.account_id", selectedAccountId);
      }

      const { data, error } = await query;
      if (error) throw error;

      setEntries(data || []);
    } catch (error: any) {
      toast({
        variant: "destructive",
        title: "Error loading mistakes data",
        description: error.message,
      });
    } finally {
      setLoading(false);
    }
  };

  const setupRealtimeSubscription = () => {
    const channel = supabase
      .channel('mistakes-analytics')
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'psychology_entries',
          filter: `user_id=eq.${user!.id}`
        },
        () => {
          fetchEntries();
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  };

  const analyzeMistakes = () => {
    const analysis: { [key: string]: number } = {};
    let total = 0;
    
    entries.forEach(entry => {
      entry.mistake_tags.forEach(tag => {
        analysis[tag] = (analysis[tag] || 0) + 1;
        total++;
      });
    });

    setMistakeAnalysis(analysis);
    setTotalMistakes(total);
  };

  const generateTimeline = () => {
    const last30Days = Array.from({ length: 30 }, (_, i) => {
      const date = new Date();
      date.setDate(date.getDate() - (29 - i));
      return date.toISOString().split('T')[0];
    });

    const timeline = last30Days.map(date => {
      const dayEntries = entries.filter(entry => 
        new Date(entry.created_at).toISOString().split('T')[0] === date
      );
      
      const dayMistakes = dayEntries.reduce((acc, entry) => 
        acc + entry.mistake_tags.length, 0
      );

      return {
        date: new Date(date).toLocaleDateString('en-US', { month: 'short', day: 'numeric' }),
        mistakes: dayMistakes,
        trades: dayEntries.length
      };
    });

    setTimelineData(timeline);
  };

  const topMistakes = Object.entries(mistakeAnalysis)
    .sort(([, a], [, b]) => b - a)
    .slice(0, 6);

  const pieData = topMistakes.map(([mistake, count], index) => ({
    name: mistake,
    value: count,
    fill: COLORS[index % COLORS.length]
  }));

  const improvementRate = () => {
    if (timelineData.length < 15) return null;
    
    const firstHalf = timelineData.slice(0, 15);
    const secondHalf = timelineData.slice(15);
    
    const firstHalfAvg = firstHalf.reduce((acc, day) => acc + day.mistakes, 0) / firstHalf.length;
    const secondHalfAvg = secondHalf.reduce((acc, day) => acc + day.mistakes, 0) / secondHalf.length;
    
    return ((firstHalfAvg - secondHalfAvg) / firstHalfAvg) * 100;
  };

  const improvement = improvementRate();

  if (loading) {
    return (
      <div className="space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          {Array.from({ length: 4 }).map((_, i) => (
            <Card key={i}>
              <CardContent className="p-6">
                <div className="h-20 bg-muted animate-pulse rounded"></div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Stats Overview */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card className="bg-gradient-to-br from-red-50 to-red-100 border-red-200 dark:from-red-950/30 dark:to-red-900/30 dark:border-red-800">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-red-700 dark:text-red-300">Total Mistakes</p>
                <p className="text-2xl font-bold text-red-900 dark:text-red-100">{totalMistakes}</p>
              </div>
              <AlertTriangle className="h-8 w-8 text-red-600 dark:text-red-400" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-orange-50 to-orange-100 border-orange-200 dark:from-orange-950/30 dark:to-orange-900/30 dark:border-orange-800">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-orange-700 dark:text-orange-300">Mistake Types</p>
                <p className="text-2xl font-bold text-orange-900 dark:text-orange-100">{Object.keys(mistakeAnalysis).length}</p>
              </div>
              <Target className="h-8 w-8 text-orange-600 dark:text-orange-400" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-blue-50 to-blue-100 border-blue-200 dark:from-blue-950/30 dark:to-blue-900/30 dark:border-blue-800">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-blue-700 dark:text-blue-300">Avg per Entry</p>
                <p className="text-2xl font-bold text-blue-900 dark:text-blue-100">
                  {entries.length > 0 ? (totalMistakes / entries.length).toFixed(1) : '0.0'}
                </p>
              </div>
              <Calendar className="h-8 w-8 text-blue-600 dark:text-blue-400" />
            </div>
          </CardContent>
        </Card>

        <Card className={`bg-gradient-to-br ${improvement && improvement > 0 ? 'from-green-50 to-green-100 border-green-200 dark:from-green-950/30 dark:to-green-900/30 dark:border-green-800' : 'from-gray-50 to-gray-100 border-gray-200 dark:from-gray-950/30 dark:to-gray-900/30 dark:border-gray-800'}`}>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className={`text-sm font-medium ${improvement && improvement > 0 ? 'text-green-700 dark:text-green-300' : 'text-gray-700 dark:text-gray-300'}`}>
                  Improvement
                </p>
                <p className={`text-2xl font-bold ${improvement && improvement > 0 ? 'text-green-900 dark:text-green-100' : 'text-gray-900 dark:text-gray-100'}`}>
                  {improvement ? `${improvement > 0 ? '+' : ''}${improvement.toFixed(1)}%` : 'N/A'}
                </p>
              </div>
              {improvement && improvement > 0 ? (
                <TrendingUp className="h-8 w-8 text-green-600 dark:text-green-400" />
              ) : (
                <TrendingDown className="h-8 w-8 text-gray-600 dark:text-gray-400" />
              )}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Mistakes Timeline (Last 30 Days)</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <LineChart data={timelineData}>
                <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
                <XAxis 
                  dataKey="date" 
                  className="text-xs fill-muted-foreground"
                />
                <YAxis className="text-xs fill-muted-foreground" />
                <Tooltip 
                  contentStyle={{
                    backgroundColor: 'hsl(var(--background))',
                    border: '1px solid hsl(var(--border))',
                    borderRadius: '6px'
                  }}
                />
                <Line 
                  type="monotone" 
                  dataKey="mistakes" 
                  stroke="hsl(var(--destructive))" 
                  strokeWidth={2}
                  dot={{ fill: 'hsl(var(--destructive))', strokeWidth: 2 }}
                />
              </LineChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Most Common Mistakes</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={topMistakes.map(([name, value]) => ({ name, value }))}>
                <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
                <XAxis 
                  dataKey="name" 
                  className="text-xs fill-muted-foreground"
                  tick={{ fontSize: 10 }}
                  angle={-45}
                  textAnchor="end"
                />
                <YAxis className="text-xs fill-muted-foreground" />
                <Tooltip 
                  contentStyle={{
                    backgroundColor: 'hsl(var(--background))',
                    border: '1px solid hsl(var(--border))',
                    borderRadius: '6px'
                  }}
                />
                <Bar dataKey="value" fill="hsl(var(--destructive))" />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>

      {/* Mistake Distribution and Top Mistakes List */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Mistake Distribution</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <PieChart>
                <Pie
                  data={pieData}
                  cx="50%"
                  cy="50%"
                  innerRadius={60}
                  outerRadius={120}
                  paddingAngle={5}
                  dataKey="value"
                >
                  {pieData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.fill} />
                  ))}
                </Pie>
                <Tooltip 
                  contentStyle={{
                    backgroundColor: 'hsl(var(--background))',
                    border: '1px solid hsl(var(--border))',
                    borderRadius: '6px'
                  }}
                />
              </PieChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Top Mistake Categories</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {topMistakes.map(([mistake, count], index) => (
                <div key={mistake} className="flex items-center justify-between p-3 rounded-lg bg-muted/30">
                  <div className="flex items-center gap-3">
                    <div 
                      className="w-4 h-4 rounded-full" 
                      style={{ backgroundColor: COLORS[index % COLORS.length] }}
                    />
                    <span className="font-medium">{mistake}</span>
                  </div>
                  <Badge variant="destructive">{count} times</Badge>
                </div>
              ))}
              
              {topMistakes.length === 0 && (
                <div className="text-center py-8">
                  <p className="text-muted-foreground">No mistakes recorded yet!</p>
                  <p className="text-sm text-muted-foreground mt-1">
                    Start adding psychology entries to track your trading mistakes.
                  </p>
                </div>
              )}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}