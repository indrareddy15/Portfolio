import { useEffect } from 'react';

interface SEOHeadProps {
  title?: string;
  description?: string;
  keywords?: string;
  canonical?: string;
  robots?: string;
  ogTitle?: string;
  ogDescription?: string;
  ogImage?: string;
  structuredData?: object;
  author?: string;
}

export const SEOHead = ({
  title = "100% FREE Trading Journal for Forex, MT4, MT5 & Prop Firms | PipTrackr.com",
  description = "FREE forever! Advanced forex trading journal for MT4, MT5, prop firms & brokers. Track trades, analyze performance, get AI insights. 100% free - no premium plans required. Join 12,000+ successful traders worldwide.",
  keywords = "free forex trading journal, trading journal, forex journal, mt5 journal, mt4 journal, free trade journal, prop firm journal, broker journal, forex trading, trading analytics, free trading tools",
  canonical,
  robots = "index, follow",
  ogTitle,
  ogDescription,
  ogImage = "https://piptrakr.com/lovable-uploads/6c66d095-1b1a-4b06-860b-9f973847053f.png",
  structuredData,
  author = "PipTrackr.com"
}: SEOHeadProps) => {
  useEffect(() => {
    // Update document title
    document.title = title;
    
    // Update meta description
    const metaDescription = document.querySelector('meta[name="description"]');
    if (metaDescription) {
      metaDescription.setAttribute('content', description);
    }
    
    // Update meta keywords
    const metaKeywords = document.querySelector('meta[name="keywords"]');
    if (metaKeywords) {
      metaKeywords.setAttribute('content', keywords);
    }
    
    // Update meta author
    const metaAuthor = document.querySelector('meta[name="author"]');
    if (metaAuthor) {
      metaAuthor.setAttribute('content', author);
    }
    
    // Update robots meta tag
    let robotsMeta = document.querySelector('meta[name="robots"]');
    if (!robotsMeta) {
      robotsMeta = document.createElement('meta');
      robotsMeta.setAttribute('name', 'robots');
      document.head.appendChild(robotsMeta);
    }
    robotsMeta.setAttribute('content', robots);
    
    // Update canonical URL
    if (canonical) {
      let canonicalLink = document.querySelector('link[rel="canonical"]');
      if (!canonicalLink) {
        canonicalLink = document.createElement('link');
        canonicalLink.setAttribute('rel', 'canonical');
        document.head.appendChild(canonicalLink);
      }
      canonicalLink.setAttribute('href', canonical);
    }
    
    // Update Open Graph tags
    const ogTitleElement = document.querySelector('meta[property="og:title"]');
    if (ogTitleElement) {
      ogTitleElement.setAttribute('content', ogTitle || title);
    }
    
    const ogDescriptionElement = document.querySelector('meta[property="og:description"]');
    if (ogDescriptionElement) {
      ogDescriptionElement.setAttribute('content', ogDescription || description);
    }
    
    const ogImageElement = document.querySelector('meta[property="og:image"]');
    if (ogImageElement) {
      ogImageElement.setAttribute('content', ogImage);
    }
    
    // Update Twitter tags
    const twitterTitle = document.querySelector('meta[name="twitter:title"]');
    if (twitterTitle) {
      twitterTitle.setAttribute('content', title);
    }
    
    const twitterDescription = document.querySelector('meta[name="twitter:description"]');
    if (twitterDescription) {
      twitterDescription.setAttribute('content', description);
    }
    
    const twitterImage = document.querySelector('meta[name="twitter:image"]');
    if (twitterImage) {
      twitterImage.setAttribute('content', ogImage);
    }
    
    // Update structured data if provided
    if (structuredData) {
      let structuredDataScript = document.querySelector('script[data-seo="structured-data"]');
      if (!structuredDataScript) {
        structuredDataScript = document.createElement('script');
        structuredDataScript.setAttribute('type', 'application/ld+json');
        structuredDataScript.setAttribute('data-seo', 'structured-data');
        document.head.appendChild(structuredDataScript);
      }
      structuredDataScript.textContent = JSON.stringify(structuredData);
    }
  }, [title, description, keywords, canonical, robots, ogTitle, ogDescription, ogImage, structuredData, author]);
  
  return null;
};