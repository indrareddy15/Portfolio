import { useState, useEffect } from "react"
import { X, ChevronLeft, ChevronRight } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { useAuth } from "@/hooks/useAuth"
import { useToast } from "@/hooks/use-toast"

interface CoachmarkStep {
  id: string
  title: string
  description: string
  target: string // CSS selector
  position: 'top' | 'bottom' | 'left' | 'right'
}

const coachmarkSteps: CoachmarkStep[] = [
  {
    id: "welcome",
    title: "Welcome to PipTrackr! 🎉",
    description: "This is your trading command center. Let's explore the key features that will help you track and improve your trading performance.",
    target: "[data-sidebar]",
    position: "right"
  },
  {
    id: "sidebar-nav",
    title: "Navigation Hub",
    description: "All your trading tools are organized here. From journal entries to analytics, everything is just one click away.",
    target: "[data-sidebar]",
    position: "right"
  },
  {
    id: "collapse-sidebar", 
    title: "Maximize Your Space",
    description: "Click here or use [ and ] keys to collapse the sidebar. Perfect for when you need more screen space for charts and data.",
    target: "[data-sidebar-trigger]",
    position: "right"
  },
  {
    id: "quick-actions",
    title: "Quick Actions Panel",
    description: "Your most-used actions are right here! Quickly add trades, import data, or jump to analytics without navigating through menus.",
    target: "[data-quick-actions]",
    position: "left"
  },
  {
    id: "dashboard-cards",
    title: "Performance Overview",
    description: "These cards show your key trading metrics at a glance. Click on any card to dive deeper into that specific area.",
    target: "[data-metrics-cards]",
    position: "top"
  }
]

export function OnboardingCoachmarks() {
  const [isVisible, setIsVisible] = useState(false)
  const [currentStep, setCurrentStep] = useState(0)
  const [targetElement, setTargetElement] = useState<HTMLElement | null>(null)
  const [isFirstLogin, setIsFirstLogin] = useState(false)
  const { user } = useAuth()
  const { toast } = useToast()

  useEffect(() => {
    if (!user?.id) return

    // Check if this is first login for this user
    const userOnboardingKey = `onboarding-completed-${user.id}`
    const completed = localStorage.getItem(userOnboardingKey)
    const lastLoginKey = `last-login-${user.id}`
    const lastLogin = localStorage.getItem(lastLoginKey)
    
    // If user has never completed onboarding and no previous login record
    if (!completed && !lastLogin) {
      setIsFirstLogin(true)
      // Mark that user has logged in
      localStorage.setItem(lastLoginKey, Date.now().toString())
      
      // Small delay to ensure DOM is ready
      setTimeout(() => {
        // Check if we're in the app layout (target elements exist)
        const sidebarElement = document.querySelector("[data-sidebar]")
        if (sidebarElement) {
          setIsVisible(true)
          updateTargetElement()
          toast({
            title: "Welcome to PipTrackr! 🎉",
            description: "Let's take a quick tour of your new trading dashboard.",
            duration: 3000,
          })
        }
      }, 2000)
    }
  }, [user, toast])

  useEffect(() => {
    if (isVisible) {
      updateTargetElement()
    }
  }, [currentStep, isVisible])

  const updateTargetElement = () => {
    const step = coachmarkSteps[currentStep]
    if (step) {
      // Wait for element to be available with retry logic
      let attempts = 0
      const maxAttempts = 10
      
      const findElement = () => {
        const element = document.querySelector(step.target) as HTMLElement
        if (element) {
          setTargetElement(element)
          // Add highlight effect
          element.classList.add('onboarding-highlight')
          // Scroll element into view if needed
          element.scrollIntoView({ behavior: 'smooth', block: 'center' })
        } else if (attempts < maxAttempts) {
          attempts++
          setTimeout(findElement, 200)
        } else {
          console.warn(`Onboarding target not found: ${step.target}`)
          // Skip to next step if element not found
          if (currentStep < coachmarkSteps.length - 1) {
            setCurrentStep(prev => prev + 1)
          } else {
            completeOnboarding()
          }
        }
      }
      
      findElement()
    }
  }

  const nextStep = () => {
    // Remove highlight from current element
    if (targetElement) {
      targetElement.classList.remove('onboarding-highlight')
    }

    if (currentStep < coachmarkSteps.length - 1) {
      setCurrentStep(prev => prev + 1)
    } else {
      completeOnboarding()
    }
  }

  const previousStep = () => {
    if (targetElement) {
      targetElement.classList.remove('onboarding-highlight')
    }

    if (currentStep > 0) {
      setCurrentStep(prev => prev - 1)
    }
  }

  const completeOnboarding = () => {
    if (targetElement) {
      targetElement.classList.remove('onboarding-highlight')
    }
    setIsVisible(false)
    
    // Store completion status for this specific user
    if (user?.id) {
      localStorage.setItem(`onboarding-completed-${user.id}`, 'true')
      toast({
        title: "Tour Complete! ✨",
        description: "You're all set! Start logging your trades to unlock powerful insights.",
        duration: 4000,
      })
    }
  }

  const skipTour = () => {
    completeOnboarding()
  }

  if (!isVisible || !targetElement) {
    return null
  }

  const step = coachmarkSteps[currentStep]
  const rect = targetElement.getBoundingClientRect()
  
  // Calculate position based on step position preference with viewport boundaries
  const getCoachmarkStyle = () => {
    const offset = 20
    const cardWidth = 320 // Approximate card width
    const cardHeight = 200 // Approximate card height
    
    let style: React.CSSProperties = {}
    
    switch (step.position) {
      case 'right':
        style = {
          left: Math.min(rect.right + offset, window.innerWidth - cardWidth - 20),
          top: Math.max(20, Math.min(rect.top, window.innerHeight - cardHeight - 20)),
        }
        break
      case 'left':
        style = {
          left: Math.max(20, rect.left - cardWidth - offset),
          top: Math.max(20, Math.min(rect.top, window.innerHeight - cardHeight - 20)),
        }
        break
      case 'bottom':
        style = {
          left: Math.max(20, Math.min(rect.left, window.innerWidth - cardWidth - 20)),
          top: Math.min(rect.bottom + offset, window.innerHeight - cardHeight - 20),
        }
        break
      case 'top':
        style = {
          left: Math.max(20, Math.min(rect.left, window.innerWidth - cardWidth - 20)),
          top: Math.max(20, rect.top - cardHeight - offset),
        }
        break
      default:
        style = {
          left: Math.min(rect.right + offset, window.innerWidth - cardWidth - 20),
          top: Math.max(20, Math.min(rect.top, window.innerHeight - cardHeight - 20)),
        }
    }
    
    return style
  }

  return (
    <>
      {/* Overlay */}
      <div 
        className="fixed inset-0 bg-black/20 z-50 backdrop-blur-sm"
        onClick={completeOnboarding}
      />
      
      {/* Spotlight effect */}
      <div 
        className="fixed z-50 pointer-events-none border-4 border-primary rounded-lg animate-pulse-glow"
        style={{
          left: rect.left - 8,
          top: rect.top - 8,
          width: rect.width + 16,
          height: rect.height + 16,
        }}
      />

      {/* Coachmark Card */}
      <Card 
        className="fixed z-50 w-80 shadow-2xl border-primary/20 animate-in fade-in-0 slide-in-from-bottom-4"
        style={getCoachmarkStyle()}
      >
        <CardHeader className="pb-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Badge variant="secondary" className="bg-primary/10 text-primary">
                {currentStep + 1} of {coachmarkSteps.length}
              </Badge>
              <CardTitle className="text-lg font-poppins">{step.title}</CardTitle>
            </div>
            <Button
              variant="ghost"
              size="icon"
              onClick={completeOnboarding}
              className="h-6 w-6"
            >
              <X className="h-4 w-4" />
            </Button>
          </div>
        </CardHeader>
        
        <CardContent className="space-y-4">
          <p className="text-sm text-muted-foreground leading-relaxed">
            {step.description}
          </p>
          
          <div className="flex items-center justify-between">
            <Button 
              variant="ghost" 
              size="sm" 
              onClick={skipTour}
              className="text-muted-foreground hover:text-foreground"
            >
              Skip Tour
            </Button>
            
            <div className="flex items-center gap-2">
              {currentStep > 0 && (
                <Button
                  variant="outline"
                  size="sm"
                  onClick={previousStep}
                >
                  <ChevronLeft className="h-4 w-4 mr-1" />
                  Back
                </Button>
              )}
              
              <Button
                onClick={nextStep}
                size="sm"
                className="bg-primary hover:bg-primary-dark"
              >
                {currentStep < coachmarkSteps.length - 1 ? (
                  <>
                    Next
                    <ChevronRight className="h-4 w-4 ml-1" />
                  </>
                ) : (
                  "Got it!"
                )}
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      <style>{`
        .onboarding-highlight {
          position: relative !important;
          z-index: 51 !important;
          box-shadow: 0 0 0 4px rgba(0, 143, 253, 0.3) !important;
          border-radius: 8px !important;
        }
      `}</style>
    </>
  )
}