import { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { ArrowRight, DollarSign, Clock, BarChart3 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { supabase } from "@/integrations/supabase/client";

interface CMSBlock {
  key: string;
  content_json: {
    enabled?: boolean;
    title?: string;
    bullets?: string[];
    cta?: string;
  };
}

export const AffiliateEarnSection = () => {
  const [visible, setVisible] = useState(false);
  const [content, setContent] = useState({
    title: "Partner with PipTrackr.com",
    bullets: ["10% recurring commissions", "30-day cookie window", "Real-time dashboard"],
    cta: "Join Affiliate Program"
  });

  useEffect(() => {
    const fetchContent = async () => {
      const { data } = await supabase
        .from('cms_blocks')
        .select('*')
        .eq('key', 'home_affiliate_section')
        .single();
      
      if (data?.content_json && typeof data.content_json === 'object') {
        const contentJson = data.content_json as any;
        if (contentJson.enabled) {
          setContent({
            title: contentJson.title || content.title,
            bullets: contentJson.bullets || content.bullets,
            cta: contentJson.cta || content.cta
          });
          setVisible(true);
        }
      }
    };

    fetchContent();
  }, []);

  if (!visible) return null;

  const icons = [DollarSign, Clock, BarChart3];

  return (
    <section className="py-12 sm:py-16 md:py-20 bg-muted/20">
      <div className="container mx-auto px-4 sm:px-6">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-2xl sm:text-3xl md:text-4xl font-bold mb-4 sm:mb-6 bg-gradient-to-r from-foreground via-primary to-foreground bg-clip-text text-transparent leading-tight">
            {content.title}
          </h2>
          <p className="text-base sm:text-lg md:text-xl text-muted-foreground mb-8 sm:mb-10 md:mb-12 leading-relaxed">
            Partner with us and earn substantial recurring income by promoting 
            the world's most advanced trading journal to your audience.
          </p>

          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4 sm:gap-6 md:gap-8 mb-8 sm:mb-10 md:mb-12">
            {content.bullets.map((bullet, index) => {
              const Icon = icons[index % icons.length];
              return (
                <Card key={index} className="text-center p-4 sm:p-6 hover:shadow-lg transition-shadow">
                  <CardContent className="space-y-3 sm:space-y-4">
                    <div className="w-10 h-10 sm:w-12 sm:h-12 bg-primary/10 rounded-lg flex items-center justify-center mx-auto">
                      <Icon className="h-5 w-5 sm:h-6 sm:w-6 text-primary" />
                    </div>
                    <p className="text-base sm:text-lg font-medium">{bullet}</p>
                  </CardContent>
                </Card>
              );
            })}
          </div>

          <div className="flex flex-col sm:flex-row gap-3 sm:gap-4 justify-center">
            <Button asChild size="lg" className="text-sm sm:text-base lg:text-lg px-6 sm:px-8 w-full sm:w-auto">
              <Link to="/affiliates">
                {content.cta} <ArrowRight className="ml-2 h-4 w-4 sm:h-5 sm:w-5" />
              </Link>
            </Button>
            <Button variant="outline" size="lg" className="text-sm sm:text-base lg:text-lg px-6 sm:px-8 w-full sm:w-auto" asChild>
              <Link to="/affiliates/apply">
                Apply Now
              </Link>
            </Button>
          </div>
        </div>
      </div>
    </section>
  );
};