import { useEffect, useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "@/hooks/use-toast";
import { 
  Plus, 
  Edit, 
  Trash2, 
  Eye, 
  EyeOff, 
  Calendar,
  Globe,
  Monitor,
  AlertCircle,
  CheckCircle,
  Info,
  AlertTriangle
} from "lucide-react";

interface Notice {
  id: string;
  title: string;
  message: string;
  link_url?: string;
  link_text?: string;
  type: 'info' | 'success' | 'warning' | 'error';
  priority: number;
  is_active: boolean;
  show_on_website: boolean;
  show_on_dashboard: boolean;
  expires_at?: string;
  created_at: string;
  updated_at: string;
}

export default function AdminNotices() {
  const [notices, setNotices] = useState<Notice[]>([]);
  const [loading, setLoading] = useState(true);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingNotice, setEditingNotice] = useState<Notice | null>(null);
  const [formData, setFormData] = useState({
    title: '',
    message: '',
    link_url: '',
    link_text: 'Learn More',
    type: 'info' as 'info' | 'success' | 'warning' | 'error',
    priority: 1,
    is_active: true,
    show_on_website: true,
    show_on_dashboard: true,
    expires_at: ''
  });

  const fetchNotices = async () => {
    try {
      const { data, error } = await supabase
        .from('notices')
        .select('*')
        .order('priority', { ascending: false })
        .order('created_at', { ascending: false });

      if (error) throw error;
      setNotices((data || []).map(notice => ({
        ...notice,
        type: notice.type as 'info' | 'success' | 'warning' | 'error'
      })));
    } catch (error) {
      console.error('Error fetching notices:', error);
      toast({
        title: "Error",
        description: "Failed to fetch notices",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchNotices();

    // Real-time updates
    const channel = supabase
      .channel('admin-notices-realtime')
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'notices'
        },
        () => {
          fetchNotices();
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, []);

  const resetForm = () => {
    setFormData({
      title: '',
      message: '',
      link_url: '',
      link_text: 'Learn More',
      type: 'info',
      priority: 1,
      is_active: true,
      show_on_website: true,
      show_on_dashboard: true,
      expires_at: ''
    });
    setEditingNotice(null);
  };

  const openDialog = (notice?: Notice) => {
    if (notice) {
      setEditingNotice(notice);
      setFormData({
        title: notice.title,
        message: notice.message,
        link_url: notice.link_url || '',
        link_text: notice.link_text || 'Learn More',
        type: notice.type,
        priority: notice.priority,
        is_active: notice.is_active,
        show_on_website: notice.show_on_website,
        show_on_dashboard: notice.show_on_dashboard,
        expires_at: notice.expires_at ? notice.expires_at.split('T')[0] : ''
      });
    } else {
      resetForm();
    }
    setDialogOpen(true);
  };

  const handleSubmit = async () => {
    try {
      const payload = {
        ...formData,
        expires_at: formData.expires_at ? new Date(formData.expires_at).toISOString() : null,
        created_by: (await supabase.auth.getUser()).data.user?.id
      };

      if (editingNotice) {
        const { error } = await supabase
          .from('notices')
          .update(payload)
          .eq('id', editingNotice.id);

        if (error) throw error;

        toast({
          title: "Success",
          description: "Notice updated successfully",
        });
      } else {
        const { error } = await supabase
          .from('notices')
          .insert(payload);

        if (error) throw error;

        toast({
          title: "Success",
          description: "Notice created successfully",
        });
      }

      setDialogOpen(false);
      resetForm();
    } catch (error) {
      console.error('Error saving notice:', error);
      toast({
        title: "Error",
        description: "Failed to save notice",
        variant: "destructive",
      });
    }
  };

  const deleteNotice = async (noticeId: string) => {
    if (!window.confirm('Are you sure you want to delete this notice?')) return;

    try {
      const { error } = await supabase
        .from('notices')
        .delete()
        .eq('id', noticeId);

      if (error) throw error;

      toast({
        title: "Success",
        description: "Notice deleted successfully",
      });
    } catch (error) {
      console.error('Error deleting notice:', error);
      toast({
        title: "Error",
        description: "Failed to delete notice",
        variant: "destructive",
      });
    }
  };

  const toggleNoticeStatus = async (noticeId: string, currentStatus: boolean) => {
    try {
      const { error } = await supabase
        .from('notices')
        .update({ is_active: !currentStatus })
        .eq('id', noticeId);

      if (error) throw error;

      toast({
        title: "Success",
        description: `Notice ${!currentStatus ? 'activated' : 'deactivated'} successfully`,
      });
    } catch (error) {
      console.error('Error updating notice status:', error);
      toast({
        title: "Error",
        description: "Failed to update notice status",
        variant: "destructive",
      });
    }
  };

  const getTypeIcon = (type: string) => {
    switch (type) {
      case 'success':
        return <CheckCircle className="h-4 w-4 text-green-500" />;
      case 'warning':
        return <AlertTriangle className="h-4 w-4 text-yellow-500" />;
      case 'error':
        return <AlertCircle className="h-4 w-4 text-red-500" />;
      default:
        return <Info className="h-4 w-4 text-blue-500" />;
    }
  };

  const getTypeBadge = (type: string) => {
    const variants = {
      info: 'outline',
      success: 'default',
      warning: 'secondary',
      error: 'destructive'
    } as const;

    return (
      <Badge variant={variants[type as keyof typeof variants]} className="flex items-center gap-1">
        {getTypeIcon(type)}
        {type}
      </Badge>
    );
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-foreground">Notice Management</h1>
          <p className="text-muted-foreground">
            Create and manage real-time notifications for website and dashboard
          </p>
        </div>
        <Button onClick={() => openDialog()}>
          <Plus className="w-4 h-4 mr-2" />
          Create Notice
        </Button>
      </div>

      <Card className="glass-card border-card-border">
        <CardHeader>
          <CardTitle>Active Notices</CardTitle>
          <CardDescription>
            Manage notifications that appear on your website and dashboard
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Title</TableHead>
                  <TableHead>Type</TableHead>
                  <TableHead>Priority</TableHead>
                  <TableHead>Visibility</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Expires</TableHead>
                  <TableHead>Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {notices.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={7} className="text-center py-8 text-muted-foreground">
                      No notices found. Create your first notice to get started.
                    </TableCell>
                  </TableRow>
                ) : (
                  notices.map((notice) => (
                    <TableRow key={notice.id}>
                      <TableCell>
                        <div>
                          <div className="font-medium">{notice.title}</div>
                          <div className="text-sm text-muted-foreground line-clamp-1">
                            {notice.message}
                          </div>
                        </div>
                      </TableCell>
                      <TableCell>{getTypeBadge(notice.type)}</TableCell>
                      <TableCell>
                        <Badge variant="outline">{notice.priority}</Badge>
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center gap-2">
                          {notice.show_on_website && (
                            <div className="flex items-center gap-1 text-xs bg-muted px-2 py-1 rounded">
                              <Globe className="h-3 w-3" />
                              Website
                            </div>
                          )}
                          {notice.show_on_dashboard && (
                            <div className="flex items-center gap-1 text-xs bg-muted px-2 py-1 rounded">
                              <Monitor className="h-3 w-3" />
                              Dashboard
                            </div>
                          )}
                        </div>
                      </TableCell>
                      <TableCell>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => toggleNoticeStatus(notice.id, notice.is_active)}
                          className={`flex items-center gap-1 ${
                            notice.is_active ? 'text-green-600' : 'text-muted-foreground'
                          }`}
                        >
                          {notice.is_active ? (
                            <>
                              <Eye className="h-4 w-4" />
                              Active
                            </>
                          ) : (
                            <>
                              <EyeOff className="h-4 w-4" />
                              Inactive
                            </>
                          )}
                        </Button>
                      </TableCell>
                      <TableCell>
                        {notice.expires_at ? (
                          <div className="flex items-center gap-1 text-xs">
                            <Calendar className="h-3 w-3" />
                            {new Date(notice.expires_at).toLocaleDateString()}
                          </div>
                        ) : (
                          <span className="text-muted-foreground text-xs">Never</span>
                        )}
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center gap-2">
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => openDialog(notice)}
                          >
                            <Edit className="h-4 w-4" />
                          </Button>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => deleteNotice(notice.id)}
                            className="text-destructive hover:text-destructive"
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>

      {/* Create/Edit Dialog */}
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>
              {editingNotice ? 'Edit Notice' : 'Create New Notice'}
            </DialogTitle>
            <DialogDescription>
              Create real-time notifications that will appear on your website and dashboard
            </DialogDescription>
          </DialogHeader>

          <div className="grid gap-4 py-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="title">Title</Label>
                <Input
                  id="title"
                  value={formData.title}
                  onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                  placeholder="Notice title"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="type">Type</Label>
                <Select 
                  value={formData.type} 
                  onValueChange={(value: 'info' | 'success' | 'warning' | 'error') => 
                    setFormData({ ...formData, type: value })
                  }
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="info">Info</SelectItem>
                    <SelectItem value="success">Success</SelectItem>
                    <SelectItem value="warning">Warning</SelectItem>
                    <SelectItem value="error">Error</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="message">Message</Label>
              <Textarea
                id="message"
                value={formData.message}
                onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                placeholder="Notice message"
                rows={3}
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="link_url">Link URL (Optional)</Label>
                <Input
                  id="link_url"
                  value={formData.link_url}
                  onChange={(e) => setFormData({ ...formData, link_url: e.target.value })}
                  placeholder="/pricing or https://example.com"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="link_text">Link Text</Label>
                <Input
                  id="link_text"
                  value={formData.link_text}
                  onChange={(e) => setFormData({ ...formData, link_text: e.target.value })}
                  placeholder="Learn More"
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="priority">Priority (1-10)</Label>
                <Input
                  id="priority"
                  type="number"
                  min="1"
                  max="10"
                  value={formData.priority}
                  onChange={(e) => setFormData({ ...formData, priority: parseInt(e.target.value) || 1 })}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="expires_at">Expires At (Optional)</Label>
                <Input
                  id="expires_at"
                  type="date"
                  value={formData.expires_at}
                  onChange={(e) => setFormData({ ...formData, expires_at: e.target.value })}
                />
              </div>
            </div>

            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label htmlFor="is_active">Active</Label>
                  <p className="text-sm text-muted-foreground">
                    Whether this notice is currently active
                  </p>
                </div>
                <Switch
                  id="is_active"
                  checked={formData.is_active}
                  onCheckedChange={(checked) => setFormData({ ...formData, is_active: checked })}
                />
              </div>

              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label htmlFor="show_on_website">Show on Website</Label>
                  <p className="text-sm text-muted-foreground">
                    Display this notice on the public website
                  </p>
                </div>
                <Switch
                  id="show_on_website"
                  checked={formData.show_on_website}
                  onCheckedChange={(checked) => setFormData({ ...formData, show_on_website: checked })}
                />
              </div>

              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label htmlFor="show_on_dashboard">Show on Dashboard</Label>
                  <p className="text-sm text-muted-foreground">
                    Display this notice on user dashboards
                  </p>
                </div>
                <Switch
                  id="show_on_dashboard"
                  checked={formData.show_on_dashboard}
                  onCheckedChange={(checked) => setFormData({ ...formData, show_on_dashboard: checked })}
                />
              </div>
            </div>
          </div>

          <DialogFooter>
            <Button variant="outline" onClick={() => setDialogOpen(false)}>
              Cancel
            </Button>
            <Button onClick={handleSubmit}>
              {editingNotice ? 'Update Notice' : 'Create Notice'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}