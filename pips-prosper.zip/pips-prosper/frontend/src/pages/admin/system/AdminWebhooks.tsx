import { useEffect, useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { 
  Webhook, 
  Search, 
  Filter, 
  CheckCircle, 
  XCircle, 
  Clock,
  RefreshCw
} from "lucide-react";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "@/hooks/use-toast";

interface WebhookLog {
  id: string;
  webhook_url: string;
  method: string;
  payload: any;
  response_status: number | null;
  response_body: string | null;
  error_message: string | null;
  created_at: string;
}

export default function AdminWebhooks() {
  const [webhookLogs, setWebhookLogs] = useState<WebhookLog[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState("");

  const fetchWebhookLogs = async () => {
    try {
      const { data, error } = await supabase
        .from('webhook_logs')
        .select('*')
        .order('created_at', { ascending: false })
        .limit(100);

      if (error) throw error;
      setWebhookLogs(data || []);
    } catch (error) {
      console.error('Error fetching webhook logs:', error);
      toast({
        title: "Error",
        description: "Failed to fetch webhook logs",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchWebhookLogs();
  }, []);

  const getStatusBadge = (status: number | null, errorMessage: string | null) => {
    if (errorMessage) {
      return (
        <Badge variant="outline" className="text-destructive border-destructive">
          <XCircle className="w-3 h-3 mr-1" />
          Error
        </Badge>
      );
    }
    
    if (status === null) {
      return (
        <Badge variant="outline" className="text-warning border-warning">
          <Clock className="w-3 h-3 mr-1" />
          Pending
        </Badge>
      );
    }
    
    if (status >= 200 && status < 300) {
      return (
        <Badge variant="outline" className="text-success border-success">
          <CheckCircle className="w-3 h-3 mr-1" />
          Success
        </Badge>
      );
    }
    
    return (
      <Badge variant="outline" className="text-destructive border-destructive">
        <XCircle className="w-3 h-3 mr-1" />
        Failed
      </Badge>
    );
  };

  const filteredLogs = webhookLogs.filter(log =>
    log.webhook_url.toLowerCase().includes(searchTerm.toLowerCase()) ||
    log.method.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const stats = {
    total: webhookLogs.length,
    successful: webhookLogs.filter(log => log.response_status && log.response_status >= 200 && log.response_status < 300).length,
    failed: webhookLogs.filter(log => log.error_message || (log.response_status && log.response_status >= 400)).length,
    pending: webhookLogs.filter(log => log.response_status === null && !log.error_message).length
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-foreground">System Webhooks</h1>
          <p className="text-muted-foreground">
            Monitor webhook delivery logs and system integrations
          </p>
        </div>
        <Button onClick={fetchWebhookLogs}>
          <RefreshCw className="w-4 h-4 mr-2" />
          Refresh
        </Button>
      </div>

      {/* Webhook Stats */}
      <div className="grid gap-4 md:grid-cols-4">
        <Card className="glass-card border-card-border">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              Total Webhooks
            </CardTitle>
            <Webhook className="h-4 w-4 text-primary" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-foreground">{stats.total}</div>
          </CardContent>
        </Card>

        <Card className="glass-card border-card-border">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              Successful
            </CardTitle>
            <CheckCircle className="h-4 w-4 text-success" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-foreground">{stats.successful}</div>
            <p className="text-xs text-success">
              {stats.total > 0 ? Math.round((stats.successful / stats.total) * 100) : 0}% success rate
            </p>
          </CardContent>
        </Card>

        <Card className="glass-card border-card-border">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              Failed
            </CardTitle>
            <XCircle className="h-4 w-4 text-destructive" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-foreground">{stats.failed}</div>
          </CardContent>
        </Card>

        <Card className="glass-card border-card-border">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              Pending
            </CardTitle>
            <Clock className="h-4 w-4 text-warning" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-foreground">{stats.pending}</div>
          </CardContent>
        </Card>
      </div>

      {/* Search */}
      <Card className="glass-card border-card-border">
        <CardContent className="pt-6">
          <div className="flex space-x-4">
            <div className="flex-1">
              <div className="relative">
                <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="Search webhooks by URL or method..."
                  className="pl-8"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                />
              </div>
            </div>
            <Button variant="outline">
              <Filter className="w-4 h-4 mr-2" />
              Filter
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Webhook Logs Table */}
      <Card className="glass-card border-card-border">
        <CardHeader>
          <CardTitle>Webhook Delivery Logs</CardTitle>
          <CardDescription>
            Recent webhook deliveries and their status
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>URL</TableHead>
                <TableHead>Method</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Response</TableHead>
                <TableHead>Time</TableHead>
                <TableHead>Error</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredLogs.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={6} className="text-center text-muted-foreground">
                    No webhook logs found
                  </TableCell>
                </TableRow>
              ) : (
                filteredLogs.map((log) => (
                  <TableRow key={log.id}>
                    <TableCell className="font-mono text-xs">
                      {log.webhook_url.length > 50 
                        ? `${log.webhook_url.substring(0, 50)}...` 
                        : log.webhook_url
                      }
                    </TableCell>
                    <TableCell>
                      <Badge variant="secondary">{log.method}</Badge>
                    </TableCell>
                    <TableCell>
                      {getStatusBadge(log.response_status, log.error_message)}
                    </TableCell>
                    <TableCell>
                      {log.response_status && (
                        <code className="bg-muted px-2 py-1 rounded text-xs">
                          {log.response_status}
                        </code>
                      )}
                    </TableCell>
                    <TableCell className="text-xs text-muted-foreground">
                      {new Date(log.created_at).toLocaleString()}
                    </TableCell>
                    <TableCell className="text-xs text-destructive">
                      {log.error_message && (
                        <span title={log.error_message}>
                          {log.error_message.length > 30 
                            ? `${log.error_message.substring(0, 30)}...` 
                            : log.error_message
                          }
                        </span>
                      )}
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
}