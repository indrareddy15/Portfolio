import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { AlertCircle, ExternalLink, Save, Eye, Code } from "lucide-react";
import { Alert, AlertDescription } from "@/components/ui/alert";

interface PageMeta {
  path: string;
  title: string;
  description: string;
  keywords: string[];
  lastUpdated: string;
}

// Mock SEO data
const pageMetas: PageMeta[] = [
  {
    path: '/',
    title: 'PipTrackr - Professional Trading Journal & Analytics Platform',
    description: 'Track your trades, analyze performance, and grow as a trader with PipTrackr. Advanced analytics, multi-account support, and affiliate program.',
    keywords: ['trading journal', 'forex tracker', 'trading analytics', 'prop firm tracking'],
    lastUpdated: '2024-01-15'
  },
  {
    path: '/pricing',
    title: 'Pricing Plans - PipTrackr Trading Journal',
    description: 'Choose the perfect plan for your trading journey. Free, Pro, and Elite plans with advanced features for serious traders.',
    keywords: ['trading journal pricing', 'forex tracker cost', 'subscription plans'],
    lastUpdated: '2024-01-10'
  },
  {
    path: '/affiliates',
    title: 'Affiliate Program - Earn with PipTrackr',
    description: 'Join our affiliate program and earn commissions by referring traders to PipTrackr. High payouts, marketing materials included.',
    keywords: ['affiliate program', 'trading referrals', 'earn commission'],
    lastUpdated: '2024-01-05'
  }
];

const sampleFAQSchema = {
  "@context": "https://schema.org",
  "@type": "FAQPage",
  "mainEntity": [
    {
      "@type": "Question",
      "name": "Is PipTrackr suitable for beginners?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "Yes! PipTrackr is designed for traders of all levels. Our intuitive interface and comprehensive guides make it easy for beginners to start tracking their trades and analyzing their performance."
      }
    },
    {
      "@type": "Question", 
      "name": "What trading platforms does PipTrackr support?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "PipTrackr supports MT4, MT5, cTrader, TradingView, and many other popular trading platforms. You can also import trades manually or via CSV files."
      }
    }
  ]
};

export default function MarketingSEO() {
  const [selectedPage, setSelectedPage] = useState(pageMetas[0]);
  const [faqSchema, setFaqSchema] = useState(JSON.stringify(sampleFAQSchema, null, 2));
  const [gscVerification, setGscVerification] = useState('google-site-verification=abc123def456');

  const savePageMeta = () => {
    // In production, this would save to the database
    console.log('Saving page meta:', selectedPage);
  };

  const saveFAQSchema = () => {
    try {
      JSON.parse(faqSchema);
      // Save to database
      console.log('Saving FAQ schema');
    } catch (error) {
      alert('Invalid JSON schema');
    }
  };

  const saveGSCVerification = () => {
    // Save verification meta tag
    console.log('Saving GSC verification:', gscVerification);
  };

  const sitemapContent = `<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
  <url>
    <loc>https://piptrackr.com/</loc>
    <lastmod>2024-01-15</lastmod>
    <priority>1.0</priority>
  </url>
  <url>
    <loc>https://piptrackr.com/pricing</loc>
    <lastmod>2024-01-10</lastmod>
    <priority>0.9</priority>
  </url>
  <url>
    <loc>https://piptrackr.com/affiliates</loc>
    <lastmod>2024-01-05</lastmod>
    <priority>0.8</priority>
  </url>
  <url>
    <loc>https://piptrackr.com/auth</loc>
    <lastmod>2024-01-01</lastmod>
    <priority>0.7</priority>
  </url>
</urlset>`;

  const robotsContent = `User-agent: *
Allow: /
Disallow: /admin/
Disallow: /app/

Sitemap: https://piptrackr.com/sitemap.xml`;

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-semibold">SEO Management</h2>
          <p className="text-muted-foreground">
            Manage meta tags, structured data, and search engine optimization
          </p>
        </div>
        <Button asChild variant="outline">
          <a 
            href="https://search.google.com/search-console" 
            target="_blank" 
            rel="noopener noreferrer"
            className="flex items-center gap-2"
          >
            <ExternalLink className="h-4 w-4" />
            Google Search Console
          </a>
        </Button>
      </div>

      <Tabs defaultValue="meta" className="space-y-6">
        <TabsList>
          <TabsTrigger value="meta">Page Meta</TabsTrigger>
          <TabsTrigger value="schema">Structured Data</TabsTrigger>
          <TabsTrigger value="sitemap">Sitemap & Robots</TabsTrigger>
          <TabsTrigger value="gsc">Search Console</TabsTrigger>
        </TabsList>

        <TabsContent value="meta" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Page List */}
            <Card>
              <CardHeader>
                <CardTitle>Pages</CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                {pageMetas.map((page) => (
                  <div
                    key={page.path}
                    className={`p-3 border rounded-lg cursor-pointer hover:bg-muted/50 ${
                      selectedPage.path === page.path ? 'bg-primary/10 border-primary' : ''
                    }`}
                    onClick={() => setSelectedPage(page)}
                  >
                    <div className="font-medium">{page.path}</div>
                    <div className="text-sm text-muted-foreground truncate">{page.title}</div>
                  </div>
                ))}
              </CardContent>
            </Card>

            {/* Meta Editor */}
            <Card className="lg:col-span-2">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Code className="h-5 w-5" />
                  Edit Meta Tags: {selectedPage.path}
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="title">Title Tag</Label>
                  <Input
                    id="title"
                    value={selectedPage.title}
                    onChange={(e) => setSelectedPage(prev => ({ ...prev, title: e.target.value }))}
                    maxLength={60}
                  />
                  <div className="text-xs text-muted-foreground">
                    {selectedPage.title.length}/60 characters
                    {selectedPage.title.length > 60 && (
                      <span className="text-red-500 ml-2">Too long for optimal display</span>
                    )}
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="description">Meta Description</Label>
                  <Textarea
                    id="description"
                    value={selectedPage.description}
                    onChange={(e) => setSelectedPage(prev => ({ ...prev, description: e.target.value }))}
                    maxLength={160}
                    rows={3}
                  />
                  <div className="text-xs text-muted-foreground">
                    {selectedPage.description.length}/160 characters
                    {selectedPage.description.length > 160 && (
                      <span className="text-red-500 ml-2">Too long for optimal display</span>
                    )}
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="keywords">Keywords (comma-separated)</Label>
                  <Input
                    id="keywords"
                    value={selectedPage.keywords.join(', ')}
                    onChange={(e) => setSelectedPage(prev => ({ 
                      ...prev, 
                      keywords: e.target.value.split(',').map(k => k.trim()).filter(Boolean)
                    }))}
                    placeholder="keyword1, keyword2, keyword3"
                  />
                </div>

                <div className="flex gap-2">
                  <Button onClick={savePageMeta}>
                    <Save className="h-4 w-4 mr-2" />
                    Save Changes
                  </Button>
                  <Button variant="outline" asChild>
                    <a href={`https://piptrackr.com${selectedPage.path}`} target="_blank">
                      <Eye className="h-4 w-4 mr-2" />
                      Preview Page
                    </a>
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* SEO Preview */}
          <Card>
            <CardHeader>
              <CardTitle>Search Result Preview</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="p-4 border rounded-lg bg-muted/30">
                <div className="text-blue-600 text-lg font-medium hover:underline cursor-pointer">
                  {selectedPage.title}
                </div>
                <div className="text-green-700 text-sm">
                  https://piptrackr.com{selectedPage.path}
                </div>
                <div className="text-gray-700 text-sm mt-1">
                  {selectedPage.description}
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="schema" className="space-y-6">
          <Alert>
            <AlertCircle className="h-4 w-4" />
            <AlertDescription>
              Structured data helps search engines understand your content better. Always validate your JSON-LD before publishing.
            </AlertDescription>
          </Alert>

          <Card>
            <CardHeader>
              <CardTitle>FAQ Schema (JSON-LD)</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="faq-schema">FAQ Structured Data</Label>
                <Textarea
                  id="faq-schema"
                  value={faqSchema}
                  onChange={(e) => setFaqSchema(e.target.value)}
                  rows={20}
                  className="font-mono text-sm"
                />
              </div>

              <div className="flex gap-2">
                <Button onClick={saveFAQSchema}>
                  <Save className="h-4 w-4 mr-2" />
                  Save Schema
                </Button>
                <Button variant="outline" asChild>
                  <a 
                    href="https://search.google.com/test/rich-results" 
                    target="_blank"
                    className="flex items-center gap-2"
                  >
                    <ExternalLink className="h-4 w-4" />
                    Test with Google
                  </a>
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="sitemap" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Sitemap */}
            <Card>
              <CardHeader>
                <CardTitle>Sitemap.xml</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label>Current Sitemap</Label>
                  <Textarea
                    value={sitemapContent}
                    readOnly
                    rows={12}
                    className="font-mono text-sm"
                  />
                </div>

                <div className="flex gap-2">
                  <Button variant="outline" asChild>
                    <a href="/sitemap.xml" target="_blank">
                      <ExternalLink className="h-4 w-4 mr-2" />
                      View Live Sitemap
                    </a>
                  </Button>
                  <Badge variant="secondary">Auto-generated</Badge>
                </div>
              </CardContent>
            </Card>

            {/* Robots.txt */}
            <Card>
              <CardHeader>
                <CardTitle>Robots.txt</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label>Current Robots.txt</Label>
                  <Textarea
                    value={robotsContent}
                    readOnly
                    rows={12}
                    className="font-mono text-sm"
                  />
                </div>

                <div className="flex gap-2">
                  <Button variant="outline" asChild>
                    <a href="/robots.txt" target="_blank">
                      <ExternalLink className="h-4 w-4 mr-2" />
                      View Live Robots.txt
                    </a>
                  </Button>
                  <Badge variant="secondary">Auto-generated</Badge>
                </div>
              </CardContent>
            </Card>
          </div>

          <Alert>
            <AlertCircle className="h-4 w-4" />
            <AlertDescription>
              Sitemap and robots.txt are automatically generated based on your public pages. 
              Submit your sitemap to Google Search Console for better indexing.
            </AlertDescription>
          </Alert>
        </TabsContent>

        <TabsContent value="gsc" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Google Search Console Setup</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="gsc-verification">Verification Meta Tag</Label>
                <Input
                  id="gsc-verification"
                  value={gscVerification}
                  onChange={(e) => setGscVerification(e.target.value)}
                  placeholder="google-site-verification=..."
                />
                <div className="text-sm text-muted-foreground">
                  Add this meta tag to verify your site ownership with Google Search Console
                </div>
              </div>

              <Button onClick={saveGSCVerification}>
                <Save className="h-4 w-4 mr-2" />
                Save Verification
              </Button>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Submit Sitemap to GSC</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="p-4 border rounded-lg">
                <h4 className="font-medium mb-2">Your Sitemap URL:</h4>
                <code className="text-sm bg-muted px-2 py-1 rounded">
                  https://piptrackr.com/sitemap.xml
                </code>
              </div>

              <div className="space-y-2">
                <p className="text-sm text-muted-foreground">
                  To submit your sitemap to Google Search Console:
                </p>
                <ol className="text-sm text-muted-foreground space-y-1 list-decimal list-inside">
                  <li>Go to Google Search Console</li>
                  <li>Select your property (piptrackr.com)</li>
                  <li>Navigate to Sitemaps in the left menu</li>
                  <li>Add the sitemap URL above</li>
                </ol>
              </div>

              <Button asChild>
                <a 
                  href="https://search.google.com/search-console/sitemaps"
                  target="_blank"
                  className="flex items-center gap-2"
                >
                  <ExternalLink className="h-4 w-4" />
                  Submit to Google Search Console
                </a>
              </Button>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}