import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Copy, ExternalLink, QrCode, Plus, Edit, Trash2 } from "lucide-react";
import { useAnalytics } from "@/hooks/useAnalytics";
import { useToast } from "@/hooks/use-toast";

interface UTMCampaign {
  id: string;
  name: string;
  baseUrl: string;
  utmSource: string;
  utmMedium: string;
  utmCampaign: string;
  utmContent?: string;
  utmTerm?: string;
  shortUrl: string;
  clicks: number;
  conversions: number;
  createdAt: string;
}

// Mock campaign data
const mockCampaigns: UTMCampaign[] = [
  {
    id: '1',
    name: 'Google Ads - Trading App',
    baseUrl: 'https://piptrackr.com/pricing',
    utmSource: 'google',
    utmMedium: 'cpc',
    utmCampaign: 'trading-app-signup',
    utmContent: 'text-ad-1',
    utmTerm: 'trading journal app',
    shortUrl: 'https://track.piptrackr.com/gads1',
    clicks: 1247,
    conversions: 32,
    createdAt: '2024-01-15'
  },
  {
    id: '2',
    name: 'Facebook - Community Campaign',
    baseUrl: 'https://piptrackr.com/',
    utmSource: 'facebook',
    utmMedium: 'social',
    utmCampaign: 'traders-community',
    shortUrl: 'https://track.piptrackr.com/fb1',
    clicks: 892,
    conversions: 18,
    createdAt: '2024-01-20'
  },
  {
    id: '3',
    name: 'YouTube Tutorial Series',
    baseUrl: 'https://piptrackr.com/affiliates',
    utmSource: 'youtube',
    utmMedium: 'video',
    utmCampaign: 'tutorial-series',
    utmContent: 'description-link',
    shortUrl: 'https://track.piptrackr.com/yt1',
    clicks: 654,
    conversions: 24,
    createdAt: '2024-01-10'
  }
];

export default function MarketingCampaigns() {
  const [campaigns, setCampaigns] = useState<UTMCampaign[]>(mockCampaigns);
  const [isBuilding, setIsBuilding] = useState(false);
  const { trackUTMLinkCreated } = useAnalytics();
  const { toast } = useToast();
  
  // Form state for UTM builder
  const [formData, setFormData] = useState({
    name: '',
    baseUrl: 'https://piptrackr.com/',
    utmSource: '',
    utmMedium: '',
    utmCampaign: '',
    utmContent: '',
    utmTerm: ''
  });

  const generateUTMUrl = () => {
    const params = new URLSearchParams();
    if (formData.utmSource) params.set('utm_source', formData.utmSource);
    if (formData.utmMedium) params.set('utm_medium', formData.utmMedium);
    if (formData.utmCampaign) params.set('utm_campaign', formData.utmCampaign);
    if (formData.utmContent) params.set('utm_content', formData.utmContent);
    if (formData.utmTerm) params.set('utm_term', formData.utmTerm);

    return `${formData.baseUrl}${formData.baseUrl.includes('?') ? '&' : '?'}${params.toString()}`;
  };

  const generateShortUrl = () => {
    // In production, this would call your URL shortener service
    const hash = Math.random().toString(36).substring(7);
    return `https://track.piptrackr.com/${hash}`;
  };

  const createCampaign = () => {
    if (!formData.name || !formData.utmSource || !formData.utmMedium || !formData.utmCampaign) {
      toast({
        title: "Missing Required Fields",
        description: "Please fill in campaign name, source, medium, and campaign.",
        variant: "destructive"
      });
      return;
    }

    const newCampaign: UTMCampaign = {
      id: Date.now().toString(),
      name: formData.name,
      baseUrl: formData.baseUrl,
      utmSource: formData.utmSource,
      utmMedium: formData.utmMedium,
      utmCampaign: formData.utmCampaign,
      utmContent: formData.utmContent || undefined,
      utmTerm: formData.utmTerm || undefined,
      shortUrl: generateShortUrl(),
      clicks: 0,
      conversions: 0,
      createdAt: new Date().toISOString().split('T')[0]
    };

    setCampaigns(prev => [newCampaign, ...prev]);
    
    // Track the event
    trackUTMLinkCreated(formData.utmCampaign, formData.utmSource, formData.utmMedium);
    
    // Reset form
    setFormData({
      name: '',
      baseUrl: 'https://piptrackr.com/',
      utmSource: '',
      utmMedium: '',
      utmCampaign: '',
      utmContent: '',
      utmTerm: ''
    });

    toast({
      title: "Campaign Created",
      description: "Your UTM campaign has been created successfully."
    });
  };

  const copyToClipboard = (text: string, label: string) => {
    navigator.clipboard.writeText(text);
    toast({
      title: "Copied!",
      description: `${label} copied to clipboard.`
    });
  };

  const deleteCampaign = (id: string) => {
    setCampaigns(prev => prev.filter(c => c.id !== id));
    toast({
      title: "Campaign Deleted",
      description: "The campaign has been removed."
    });
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-semibold">Campaign Management</h2>
          <p className="text-muted-foreground">
            Create UTM-tracked links and manage your marketing campaigns
          </p>
        </div>
      </div>

      <Tabs defaultValue="builder" className="space-y-6">
        <TabsList>
          <TabsTrigger value="builder">UTM Builder</TabsTrigger>
          <TabsTrigger value="campaigns">Campaign List</TabsTrigger>
        </TabsList>

        <TabsContent value="builder" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Plus className="h-5 w-5" />
                Create New UTM Campaign
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {/* Campaign Name */}
                <div className="space-y-2">
                  <Label htmlFor="name">Campaign Name *</Label>
                  <Input
                    id="name"
                    placeholder="e.g., Google Ads - Trading App"
                    value={formData.name}
                    onChange={(e) => setFormData(prev => ({ ...prev, name: e.target.value }))}
                  />
                </div>

                {/* Base URL */}
                <div className="space-y-2">
                  <Label htmlFor="baseUrl">Base URL *</Label>
                  <Select value={formData.baseUrl} onValueChange={(value) => setFormData(prev => ({ ...prev, baseUrl: value }))}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="https://piptrackr.com/">Home Page</SelectItem>
                      <SelectItem value="https://piptrackr.com/pricing">Pricing Page</SelectItem>
                      <SelectItem value="https://piptrackr.com/affiliates">Affiliates Page</SelectItem>
                      <SelectItem value="https://piptrackr.com/auth">Sign Up Page</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {/* UTM Source */}
                <div className="space-y-2">
                  <Label htmlFor="utmSource">UTM Source *</Label>
                  <Input
                    id="utmSource"
                    placeholder="e.g., google, facebook, newsletter"
                    value={formData.utmSource}
                    onChange={(e) => setFormData(prev => ({ ...prev, utmSource: e.target.value }))}
                  />
                </div>

                {/* UTM Medium */}
                <div className="space-y-2">
                  <Label htmlFor="utmMedium">UTM Medium *</Label>
                  <Select value={formData.utmMedium} onValueChange={(value) => setFormData(prev => ({ ...prev, utmMedium: value }))}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select medium" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="cpc">CPC (Paid Search)</SelectItem>
                      <SelectItem value="social">Social Media</SelectItem>
                      <SelectItem value="email">Email</SelectItem>
                      <SelectItem value="referral">Referral</SelectItem>
                      <SelectItem value="display">Display Ads</SelectItem>
                      <SelectItem value="video">Video</SelectItem>
                      <SelectItem value="affiliate">Affiliate</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {/* UTM Campaign */}
                <div className="space-y-2">
                  <Label htmlFor="utmCampaign">UTM Campaign *</Label>
                  <Input
                    id="utmCampaign"
                    placeholder="e.g., spring-sale, product-launch"
                    value={formData.utmCampaign}
                    onChange={(e) => setFormData(prev => ({ ...prev, utmCampaign: e.target.value }))}
                  />
                </div>

                {/* UTM Content */}
                <div className="space-y-2">
                  <Label htmlFor="utmContent">UTM Content (Optional)</Label>
                  <Input
                    id="utmContent"
                    placeholder="e.g., header-banner, sidebar-link"
                    value={formData.utmContent}
                    onChange={(e) => setFormData(prev => ({ ...prev, utmContent: e.target.value }))}
                  />
                </div>

                {/* UTM Term */}
                <div className="space-y-2 md:col-span-2">
                  <Label htmlFor="utmTerm">UTM Term (Optional)</Label>
                  <Input
                    id="utmTerm"
                    placeholder="e.g., trading journal app, forex tracker"
                    value={formData.utmTerm}
                    onChange={(e) => setFormData(prev => ({ ...prev, utmTerm: e.target.value }))}
                  />
                </div>
              </div>

              {/* Preview */}
              {(formData.utmSource || formData.utmMedium || formData.utmCampaign) && (
                <div className="space-y-3 p-4 border rounded-lg bg-muted/50">
                  <Label>Preview URL:</Label>
                  <div className="p-3 bg-background rounded border font-mono text-sm break-all">
                    {generateUTMUrl()}
                  </div>
                  <div className="flex gap-2">
                    <Button 
                      variant="outline" 
                      size="sm"
                      onClick={() => copyToClipboard(generateUTMUrl(), "UTM URL")}
                    >
                      <Copy className="h-4 w-4 mr-2" />
                      Copy URL
                    </Button>
                  </div>
                </div>
              )}

              <div className="flex gap-3">
                <Button onClick={createCampaign} disabled={!formData.name || !formData.utmSource}>
                  Create Campaign
                </Button>
                <Button 
                  variant="outline"
                  onClick={() => setFormData({
                    name: '',
                    baseUrl: 'https://piptrackr.com/',
                    utmSource: '',
                    utmMedium: '',
                    utmCampaign: '',
                    utmContent: '',
                    utmTerm: ''
                  })}
                >
                  Clear Form
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="campaigns" className="space-y-6">
          {/* Campaign Stats */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-muted-foreground">Active Campaigns</p>
                    <p className="text-2xl font-bold">{campaigns.length}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-muted-foreground">Total Clicks</p>
                    <p className="text-2xl font-bold">{campaigns.reduce((sum, c) => sum + c.clicks, 0).toLocaleString()}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-muted-foreground">Total Conversions</p>
                    <p className="text-2xl font-bold">{campaigns.reduce((sum, c) => sum + c.conversions, 0)}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Campaigns Table */}
          <Card>
            <CardHeader>
              <CardTitle>All Campaigns</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="overflow-x-auto">
                <table className="w-full text-left">
                  <thead>
                    <tr className="border-b">
                      <th className="pb-3 text-sm font-medium text-muted-foreground">Campaign</th>
                      <th className="pb-3 text-sm font-medium text-muted-foreground">Source/Medium</th>
                      <th className="pb-3 text-sm font-medium text-muted-foreground">Short URL</th>
                      <th className="pb-3 text-sm font-medium text-muted-foreground text-right">Clicks</th>
                      <th className="pb-3 text-sm font-medium text-muted-foreground text-right">Conversions</th>
                      <th className="pb-3 text-sm font-medium text-muted-foreground text-right">CVR</th>
                      <th className="pb-3 text-sm font-medium text-muted-foreground">Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {campaigns.map((campaign) => (
                      <tr key={campaign.id} className="border-b last:border-b-0">
                        <td className="py-3">
                          <div>
                            <div className="font-medium">{campaign.name}</div>
                            <div className="text-sm text-muted-foreground">{campaign.utmCampaign}</div>
                          </div>
                        </td>
                        <td className="py-3">
                          <div className="flex gap-1">
                            <Badge variant="outline" className="text-xs">{campaign.utmSource}</Badge>
                            <Badge variant="secondary" className="text-xs">{campaign.utmMedium}</Badge>
                          </div>
                        </td>
                        <td className="py-3">
                          <div className="flex items-center gap-2">
                            <span className="font-mono text-sm">{campaign.shortUrl}</span>
                            <Button 
                              variant="ghost" 
                              size="sm" 
                              className="h-6 w-6 p-0"
                              onClick={() => copyToClipboard(campaign.shortUrl, "Short URL")}
                            >
                              <Copy className="h-3 w-3" />
                            </Button>
                          </div>
                        </td>
                        <td className="py-3 text-right font-medium">{campaign.clicks.toLocaleString()}</td>
                        <td className="py-3 text-right font-medium text-primary">{campaign.conversions}</td>
                        <td className="py-3 text-right">
                          <Badge variant={campaign.clicks > 0 && (campaign.conversions / campaign.clicks) * 100 > 2 ? "default" : "secondary"}>
                            {campaign.clicks > 0 ? ((campaign.conversions / campaign.clicks) * 100).toFixed(1) : '0.0'}%
                          </Badge>
                        </td>
                        <td className="py-3">
                          <div className="flex items-center gap-1">
                            <Button variant="ghost" size="sm" className="h-8 w-8 p-0">
                              <ExternalLink className="h-4 w-4" />
                            </Button>
                            <Button 
                              variant="ghost" 
                              size="sm" 
                              className="h-8 w-8 p-0"
                              onClick={() => deleteCampaign(campaign.id)}
                            >
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}