import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Progress } from "@/components/ui/progress";
import { FlaskConical, Play, Pause, BarChart3, Download, Plus } from "lucide-react";
import { useAnalytics } from "@/hooks/useAnalytics";

interface Experiment {
  id: string;
  name: string;
  description: string;
  status: 'draft' | 'running' | 'paused' | 'completed';
  targetRoute: string;
  variantA: {
    name: string;
    traffic: number;
    conversions: number;
    participants: number;
  };
  variantB: {
    name: string;
    traffic: number;
    conversions: number;
    participants: number;
  };
  startDate: string;
  endDate?: string;
  significance: number;
  winner?: 'A' | 'B' | null;
}

// Mock experiment data
const mockExperiments: Experiment[] = [
  {
    id: '1',
    name: 'Pricing Page CTA Button',
    description: 'Testing "Start Free Trial" vs "Get Started Now" button text',
    status: 'running',
    targetRoute: '/pricing',
    variantA: {
      name: 'Start Free Trial',
      traffic: 50,
      conversions: 23,
      participants: 487
    },
    variantB: {
      name: 'Get Started Now',
      traffic: 50,
      conversions: 31,
      participants: 492
    },
    startDate: '2024-01-10',
    significance: 78,
    winner: null
  },
  {
    id: '2',
    name: 'Landing Page Hero Section',
    description: 'Testing different hero headlines and value propositions',
    status: 'completed',
    targetRoute: '/',
    variantA: {
      name: 'Track Your Trades',
      traffic: 50,
      conversions: 45,
      participants: 1200
    },
    variantB: {
      name: 'Grow Your Trading',
      traffic: 50,
      conversions: 67,
      participants: 1184
    },
    startDate: '2023-12-15',
    endDate: '2024-01-05',
    significance: 95,
    winner: 'B'
  },
  {
    id: '3',
    name: 'Signup Flow Steps',
    description: 'Testing 2-step vs 3-step registration process',
    status: 'paused',
    targetRoute: '/auth',
    variantA: {
      name: '2-Step Signup',
      traffic: 50,
      conversions: 12,
      participants: 156
    },
    variantB: {
      name: '3-Step Signup',
      traffic: 50,
      conversions: 8,
      participants: 142
    },
    startDate: '2024-01-20',
    significance: 45,
    winner: null
  }
];

export default function MarketingExperiments() {
  const [experiments, setExperiments] = useState<Experiment[]>(mockExperiments);
  const [showCreateForm, setShowCreateForm] = useState(false);
  const { trackExperimentStarted, trackExperimentEnded } = useAnalytics();

  const [newExperiment, setNewExperiment] = useState({
    name: '',
    description: '',
    targetRoute: '/',
    variantAName: 'Control',
    variantBName: 'Variant',
    trafficSplit: 50
  });

  const toggleExperiment = (id: string, action: 'start' | 'pause' | 'stop') => {
    setExperiments(prev => prev.map(exp => {
      if (exp.id === id) {
        const newStatus = action === 'start' ? 'running' : action === 'pause' ? 'paused' : 'completed';
        
        if (action === 'start') {
          trackExperimentStarted(exp.name, 'A'); // Track start
        } else if (action === 'stop') {
          trackExperimentEnded(exp.name, exp.winner || 'inconclusive');
        }
        
        return { ...exp, status: newStatus as any };
      }
      return exp;
    }));
  };

  const createExperiment = () => {
    if (!newExperiment.name || !newExperiment.description) return;

    const experiment: Experiment = {
      id: Date.now().toString(),
      name: newExperiment.name,
      description: newExperiment.description,
      status: 'draft',
      targetRoute: newExperiment.targetRoute,
      variantA: {
        name: newExperiment.variantAName,
        traffic: newExperiment.trafficSplit,
        conversions: 0,
        participants: 0
      },
      variantB: {
        name: newExperiment.variantBName,
        traffic: 100 - newExperiment.trafficSplit,
        conversions: 0,
        participants: 0
      },
      startDate: new Date().toISOString().split('T')[0],
      significance: 0,
      winner: null
    };

    setExperiments(prev => [experiment, ...prev]);
    setShowCreateForm(false);
    setNewExperiment({
      name: '',
      description: '',
      targetRoute: '/',
      variantAName: 'Control',
      variantBName: 'Variant',
      trafficSplit: 50
    });
  };

  const calculateConversionRate = (conversions: number, participants: number) => {
    return participants > 0 ? (conversions / participants * 100).toFixed(2) : '0.00';
  };

  const getStatusColor = (status: Experiment['status']) => {
    switch (status) {
      case 'running': return 'default';
      case 'paused': return 'secondary';
      case 'completed': return 'outline';
      default: return 'secondary';
    }
  };

  const getSignificanceColor = (significance: number) => {
    if (significance >= 95) return 'text-green-600';
    if (significance >= 80) return 'text-yellow-600';
    return 'text-gray-600';
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-semibold flex items-center gap-2">
            <FlaskConical className="h-6 w-6" />
            A/B Testing Experiments
          </h2>
          <p className="text-muted-foreground">
            Design and manage A/B tests to optimize conversion rates
          </p>
        </div>
        <Button onClick={() => setShowCreateForm(true)}>
          <Plus className="h-4 w-4 mr-2" />
          New Experiment
        </Button>
      </div>

      {/* Stats Overview */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-6">
            <div className="text-2xl font-bold">{experiments.length}</div>
            <p className="text-sm text-muted-foreground">Total Experiments</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-6">
            <div className="text-2xl font-bold">
              {experiments.filter(e => e.status === 'running').length}
            </div>
            <p className="text-sm text-muted-foreground">Currently Running</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-6">
            <div className="text-2xl font-bold">
              {experiments.filter(e => e.status === 'completed').length}
            </div>
            <p className="text-sm text-muted-foreground">Completed</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-6">
            <div className="text-2xl font-bold">
              {experiments.filter(e => e.winner).length}
            </div>
            <p className="text-sm text-muted-foreground">With Winners</p>
          </CardContent>
        </Card>
      </div>

      {/* Create Experiment Form */}
      {showCreateForm && (
        <Card>
          <CardHeader>
            <CardTitle>Create New Experiment</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="exp-name">Experiment Name</Label>
                <Input
                  id="exp-name"
                  value={newExperiment.name}
                  onChange={(e) => setNewExperiment(prev => ({ ...prev, name: e.target.value }))}
                  placeholder="e.g., Pricing Page Button Test"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="exp-route">Target Route</Label>
                <Select 
                  value={newExperiment.targetRoute}
                  onValueChange={(value) => setNewExperiment(prev => ({ ...prev, targetRoute: value }))}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="/">Home Page</SelectItem>
                    <SelectItem value="/pricing">Pricing Page</SelectItem>
                    <SelectItem value="/auth">Sign Up Page</SelectItem>
                    <SelectItem value="/affiliates">Affiliates Page</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="exp-description">Description</Label>
              <Textarea
                id="exp-description"
                value={newExperiment.description}
                onChange={(e) => setNewExperiment(prev => ({ ...prev, description: e.target.value }))}
                placeholder="Describe what you're testing and why..."
                rows={2}
              />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="space-y-2">
                <Label htmlFor="variant-a">Variant A (Control)</Label>
                <Input
                  id="variant-a"
                  value={newExperiment.variantAName}
                  onChange={(e) => setNewExperiment(prev => ({ ...prev, variantAName: e.target.value }))}
                  placeholder="Control"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="variant-b">Variant B (Test)</Label>
                <Input
                  id="variant-b"
                  value={newExperiment.variantBName}
                  onChange={(e) => setNewExperiment(prev => ({ ...prev, variantBName: e.target.value }))}
                  placeholder="Variant"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="traffic-split">Traffic Split (%)</Label>
                <Input
                  id="traffic-split"
                  type="number"
                  min="10"
                  max="90"
                  value={newExperiment.trafficSplit}
                  onChange={(e) => setNewExperiment(prev => ({ ...prev, trafficSplit: parseInt(e.target.value) || 50 }))}
                />
              </div>
            </div>

            <div className="flex gap-3">
              <Button onClick={createExperiment}>Create Experiment</Button>
              <Button variant="outline" onClick={() => setShowCreateForm(false)}>
                Cancel
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Experiments List */}
      <div className="space-y-4">
        {experiments.map((experiment) => (
          <Card key={experiment.id}>
            <CardHeader>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <CardTitle className="text-lg">{experiment.name}</CardTitle>
                  <Badge variant={getStatusColor(experiment.status)}>
                    {experiment.status}
                  </Badge>
                  {experiment.winner && (
                    <Badge variant="default">
                      Winner: {experiment.winner}
                    </Badge>
                  )}
                </div>
                <div className="flex items-center gap-2">
                  {experiment.status === 'running' && (
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => toggleExperiment(experiment.id, 'pause')}
                    >
                      <Pause className="h-4 w-4 mr-2" />
                      Pause
                    </Button>
                  )}
                  {experiment.status === 'paused' && (
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => toggleExperiment(experiment.id, 'start')}
                    >
                      <Play className="h-4 w-4 mr-2" />
                      Resume
                    </Button>
                  )}
                  {experiment.status === 'draft' && (
                    <Button
                      size="sm"
                      onClick={() => toggleExperiment(experiment.id, 'start')}
                    >
                      <Play className="h-4 w-4 mr-2" />
                      Start
                    </Button>
                  )}
                  {(experiment.status === 'running' || experiment.status === 'paused') && (
                    <Button
                      variant="destructive"
                      size="sm"
                      onClick={() => toggleExperiment(experiment.id, 'stop')}
                    >
                      Stop
                    </Button>
                  )}
                </div>
              </div>
              <p className="text-muted-foreground">{experiment.description}</p>
            </CardHeader>
            <CardContent className="space-y-4">
              {/* Experiment Info */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
                <div>
                  <span className="font-medium">Target Route:</span>{' '}
                  <code>{experiment.targetRoute}</code>
                </div>
                <div>
                  <span className="font-medium">Start Date:</span>{' '}
                  {new Date(experiment.startDate).toLocaleDateString()}
                </div>
                <div>
                  <span className="font-medium">Statistical Significance:</span>{' '}
                  <span className={getSignificanceColor(experiment.significance)}>
                    {experiment.significance}%
                  </span>
                </div>
              </div>

              {/* Results */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {/* Variant A */}
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <h4 className="font-medium">Variant A: {experiment.variantA.name}</h4>
                    <Badge variant="outline">{experiment.variantA.traffic}% traffic</Badge>
                  </div>
                  <div className="grid grid-cols-2 gap-4 text-sm">
                    <div>
                      <div className="text-muted-foreground">Participants</div>
                      <div className="font-medium">{experiment.variantA.participants.toLocaleString()}</div>
                    </div>
                    <div>
                      <div className="text-muted-foreground">Conversions</div>
                      <div className="font-medium">{experiment.variantA.conversions}</div>
                    </div>
                  </div>
                  <div>
                    <div className="flex justify-between text-sm mb-2">
                      <span>Conversion Rate</span>
                      <span className="font-medium">
                        {calculateConversionRate(experiment.variantA.conversions, experiment.variantA.participants)}%
                      </span>
                    </div>
                    <Progress 
                      value={parseFloat(calculateConversionRate(experiment.variantA.conversions, experiment.variantA.participants))} 
                      className="h-2"
                    />
                  </div>
                </div>

                {/* Variant B */}
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <h4 className="font-medium">Variant B: {experiment.variantB.name}</h4>
                    <Badge variant="outline">{experiment.variantB.traffic}% traffic</Badge>
                  </div>
                  <div className="grid grid-cols-2 gap-4 text-sm">
                    <div>
                      <div className="text-muted-foreground">Participants</div>
                      <div className="font-medium">{experiment.variantB.participants.toLocaleString()}</div>
                    </div>
                    <div>
                      <div className="text-muted-foreground">Conversions</div>
                      <div className="font-medium">{experiment.variantB.conversions}</div>
                    </div>
                  </div>
                  <div>
                    <div className="flex justify-between text-sm mb-2">
                      <span>Conversion Rate</span>
                      <span className="font-medium">
                        {calculateConversionRate(experiment.variantB.conversions, experiment.variantB.participants)}%
                      </span>
                    </div>
                    <Progress 
                      value={parseFloat(calculateConversionRate(experiment.variantB.conversions, experiment.variantB.participants))} 
                      className="h-2"
                    />
                  </div>
                </div>
              </div>

              {experiment.status === 'completed' && (
                <div className="flex gap-2">
                  <Button variant="outline" size="sm">
                    <BarChart3 className="h-4 w-4 mr-2" />
                    View Details
                  </Button>
                  <Button variant="outline" size="sm">
                    <Download className="h-4 w-4 mr-2" />
                    Export Results
                  </Button>
                </div>
              )}
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}