import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { ExternalLink, TrendingUp, Users, MousePointer } from "lucide-react";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';

// Mock UTM tracking data
const utmData = [
  { 
    source: 'google', 
    medium: 'cpc', 
    campaign: 'trading-app-signup', 
    sessions: 1247, 
    users: 1089, 
    signups: 32, 
    subscriptions: 8,
    conversionRate: 2.56 
  },
  { 
    source: 'facebook', 
    medium: 'social', 
    campaign: 'traders-community', 
    sessions: 892, 
    users: 743, 
    signups: 18, 
    subscriptions: 3,
    conversionRate: 2.02 
  },
  { 
    source: 'youtube', 
    medium: 'video', 
    campaign: 'tutorial-series', 
    sessions: 654, 
    users: 521, 
    signups: 24, 
    subscriptions: 6,
    conversionRate: 3.67 
  },
  { 
    source: 'linkedin', 
    medium: 'social', 
    campaign: 'professional-traders', 
    sessions: 432, 
    users: 387, 
    signups: 15, 
    subscriptions: 5,
    conversionRate: 3.47 
  },
  { 
    source: 'twitter', 
    medium: 'social', 
    campaign: 'trading-tips', 
    sessions: 321, 
    users: 298, 
    signups: 8, 
    subscriptions: 2,
    conversionRate: 2.49 
  }
];

const channelPerformance = [
  { channel: 'Paid Search', sessions: 2100, conversions: 45, cpa: 28.50 },
  { channel: 'Social Media', sessions: 1800, conversions: 32, cpa: 35.20 },
  { channel: 'Organic Search', sessions: 1500, conversions: 28, cpa: 0 },
  { channel: 'Email', sessions: 900, conversions: 24, cpa: 12.80 },
  { channel: 'Referral', sessions: 600, conversions: 12, cpa: 22.10 }
];

export default function MarketingAcquisition() {
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-semibold">Acquisition Analysis</h2>
          <p className="text-muted-foreground">
            Track traffic sources, UTM campaigns, and conversion performance
          </p>
        </div>
        <Button asChild>
          <a href="/admin/marketing/campaigns" className="flex items-center gap-2">
            <ExternalLink className="h-4 w-4" />
            UTM Builder
          </a>
        </Button>
      </div>

      {/* Channel Performance Overview */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Total Sessions</p>
                <p className="text-2xl font-bold">6,900</p>
              </div>
              <MousePointer className="h-8 w-8 text-primary" />
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">New Users</p>
                <p className="text-2xl font-bold">5,230</p>
              </div>
              <Users className="h-8 w-8 text-primary" />
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Conversions</p>
                <p className="text-2xl font-bold">141</p>
              </div>
              <TrendingUp className="h-8 w-8 text-primary" />
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Avg. CPA</p>
                <p className="text-2xl font-bold">$24.80</p>
              </div>
              <TrendingUp className="h-8 w-8 text-primary" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* UTM Campaign Performance */}
      <Card>
        <CardHeader>
          <CardTitle>UTM Campaign Performance</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <table className="w-full text-left">
              <thead>
                <tr className="border-b">
                  <th className="pb-3 text-sm font-medium text-muted-foreground">Source</th>
                  <th className="pb-3 text-sm font-medium text-muted-foreground">Medium</th>
                  <th className="pb-3 text-sm font-medium text-muted-foreground">Campaign</th>
                  <th className="pb-3 text-sm font-medium text-muted-foreground text-right">Sessions</th>
                  <th className="pb-3 text-sm font-medium text-muted-foreground text-right">Users</th>
                  <th className="pb-3 text-sm font-medium text-muted-foreground text-right">Signups</th>
                  <th className="pb-3 text-sm font-medium text-muted-foreground text-right">Subscriptions</th>
                  <th className="pb-3 text-sm font-medium text-muted-foreground text-right">Conv. Rate</th>
                </tr>
              </thead>
              <tbody>
                {utmData.map((campaign, index) => (
                  <tr key={index} className="border-b last:border-b-0">
                    <td className="py-3">
                      <Badge variant="outline">{campaign.source}</Badge>
                    </td>
                    <td className="py-3 text-sm text-muted-foreground">{campaign.medium}</td>
                    <td className="py-3 text-sm font-medium max-w-[200px] truncate">{campaign.campaign}</td>
                    <td className="py-3 text-sm text-right">{campaign.sessions.toLocaleString()}</td>
                    <td className="py-3 text-sm text-right">{campaign.users.toLocaleString()}</td>
                    <td className="py-3 text-sm text-right font-medium">{campaign.signups}</td>
                    <td className="py-3 text-sm text-right font-medium text-primary">{campaign.subscriptions}</td>
                    <td className="py-3 text-sm text-right">
                      <Badge variant={campaign.conversionRate > 3 ? "default" : "secondary"}>
                        {campaign.conversionRate}%
                      </Badge>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>

      {/* Channel Performance Chart */}
      <Card>
        <CardHeader>
          <CardTitle>Channel Performance Comparison</CardTitle>
        </CardHeader>
        <CardContent>
          <ResponsiveContainer width="100%" height={400}>
            <BarChart data={channelPerformance}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="channel" />
              <YAxis />
              <Tooltip />
              <Bar dataKey="sessions" fill="#008ffd" />
              <Bar dataKey="conversions" fill="#00d4aa" />
            </BarChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>
    </div>
  );
}