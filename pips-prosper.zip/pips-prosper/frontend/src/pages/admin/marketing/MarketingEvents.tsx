import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Progress } from "@/components/ui/progress";
import { Activity, TrendingDown, Users, ArrowRight, RefreshCw } from "lucide-react";

// Mock event data
const eventData = [
  { 
    event: 'page_view', 
    count: 45230, 
    users: 8901, 
    conversionRate: 0, 
    category: 'engagement' 
  },
  { 
    event: 'signup_started', 
    count: 1247, 
    users: 1247, 
    conversionRate: 71.3, 
    category: 'conversion' 
  },
  { 
    event: 'signup_completed', 
    count: 889, 
    users: 889, 
    conversionRate: 17.8, 
    category: 'conversion' 
  },
  { 
    event: 'import_started', 
    count: 654, 
    users: 521, 
    conversionRate: 89.1, 
    category: 'engagement' 
  },
  { 
    event: 'import_done', 
    count: 583, 
    users: 464, 
    conversionRate: 15.3, 
    category: 'engagement' 
  },
  { 
    event: 'subscription_created', 
    count: 158, 
    users: 158, 
    conversionRate: 0, 
    category: 'conversion' 
  },
  { 
    event: 'affiliate_click', 
    count: 324, 
    users: 298, 
    conversionRate: 12.7, 
    category: 'affiliate' 
  },
  { 
    event: 'commission_created', 
    count: 89, 
    users: 67, 
    conversionRate: 0, 
    category: 'affiliate' 
  }
];

// Mock funnel data
const funnelSteps = [
  { step: 'Visit Landing Page', users: 10000, percentage: 100, dropoff: 0 },
  { step: 'Start Signup', users: 1247, percentage: 12.47, dropoff: 87.53 },
  { step: 'Complete Signup', users: 889, percentage: 8.89, dropoff: 28.71 },
  { step: 'First Import', users: 583, percentage: 5.83, dropoff: 34.42 },
  { step: 'Subscribe', users: 158, percentage: 1.58, dropoff: 72.90 }
];

export default function MarketingEvents() {
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-semibold">Events & Funnels</h2>
          <p className="text-muted-foreground">
            Track user behavior and conversion funnels across your application
          </p>
        </div>
        <Button variant="outline" size="sm">
          <RefreshCw className="h-4 w-4 mr-2" />
          Refresh Data
        </Button>
      </div>

      <Tabs defaultValue="events" className="space-y-6">
        <TabsList>
          <TabsTrigger value="events">Event Analytics</TabsTrigger>
          <TabsTrigger value="funnels">Conversion Funnels</TabsTrigger>
        </TabsList>

        <TabsContent value="events" className="space-y-6">
          {/* Event Categories */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-muted-foreground">Total Events</p>
                    <p className="text-2xl font-bold">49,373</p>
                  </div>
                  <Activity className="h-8 w-8 text-primary" />
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-muted-foreground">Unique Users</p>
                    <p className="text-2xl font-bold">12,545</p>
                  </div>
                  <Users className="h-8 w-8 text-primary" />
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-muted-foreground">Avg Events/User</p>
                    <p className="text-2xl font-bold">3.93</p>
                  </div>
                  <TrendingDown className="h-8 w-8 text-primary" />
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Events Table */}
          <Card>
            <CardHeader>
              <CardTitle>Event Performance</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="overflow-x-auto">
                <table className="w-full text-left">
                  <thead>
                    <tr className="border-b">
                      <th className="pb-3 text-sm font-medium text-muted-foreground">Event Name</th>
                      <th className="pb-3 text-sm font-medium text-muted-foreground">Category</th>
                      <th className="pb-3 text-sm font-medium text-muted-foreground text-right">Count</th>
                      <th className="pb-3 text-sm font-medium text-muted-foreground text-right">Users</th>
                      <th className="pb-3 text-sm font-medium text-muted-foreground text-right">Conversion Rate</th>
                    </tr>
                  </thead>
                  <tbody>
                    {eventData.map((event, index) => (
                      <tr key={index} className="border-b last:border-b-0">
                        <td className="py-3">
                          <span className="font-mono text-sm">{event.event}</span>
                        </td>
                        <td className="py-3">
                          <Badge 
                            variant={
                              event.category === 'conversion' ? 'default' : 
                              event.category === 'affiliate' ? 'destructive' : 
                              'secondary'
                            }
                          >
                            {event.category}
                          </Badge>
                        </td>
                        <td className="py-3 text-sm text-right font-medium">{event.count.toLocaleString()}</td>
                        <td className="py-3 text-sm text-right">{event.users.toLocaleString()}</td>
                        <td className="py-3 text-sm text-right">
                          {event.conversionRate > 0 ? (
                            <Badge variant={event.conversionRate > 50 ? "default" : "secondary"}>
                              {event.conversionRate}%
                            </Badge>
                          ) : (
                            <span className="text-muted-foreground">N/A</span>
                          )}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="funnels" className="space-y-6">
          {/* Conversion Funnel */}
          <Card>
            <CardHeader>
              <CardTitle>User Acquisition Funnel</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                {funnelSteps.map((step, index) => (
                  <div key={index} className="space-y-2">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <div className="w-8 h-8 rounded-full bg-primary text-primary-foreground flex items-center justify-center text-sm font-medium">
                          {index + 1}
                        </div>
                        <span className="font-medium">{step.step}</span>
                      </div>
                      <div className="text-right">
                        <div className="text-lg font-bold">{step.users.toLocaleString()}</div>
                        <div className="text-sm text-muted-foreground">{step.percentage}% of total</div>
                      </div>
                    </div>
                    
                    <Progress value={step.percentage} className="h-3" />
                    
                    {index < funnelSteps.length - 1 && (
                      <div className="flex items-center justify-center py-2">
                        <div className="flex items-center gap-2 text-sm text-muted-foreground">
                          <ArrowRight className="h-4 w-4" />
                          <span>{step.dropoff.toFixed(1)}% drop-off</span>
                        </div>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Funnel Insights */}
          <Card>
            <CardHeader>
              <CardTitle>Funnel Insights</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="p-4 border rounded-lg">
                  <h4 className="font-medium text-green-600">Highest Converting Step</h4>
                  <p className="text-sm text-muted-foreground mt-1">
                    Start Signup → Complete Signup (71.3% completion rate)
                  </p>
                </div>
                <div className="p-4 border rounded-lg">
                  <h4 className="font-medium text-red-600">Biggest Drop-off</h4>
                  <p className="text-sm text-muted-foreground mt-1">
                    Landing Page → Start Signup (87.5% drop-off)
                  </p>
                </div>
              </div>
              
              <div className="p-4 border rounded-lg bg-muted/50">
                <h4 className="font-medium mb-2">Optimization Recommendations</h4>
                <ul className="text-sm text-muted-foreground space-y-1">
                  <li>• Improve landing page CTA to reduce initial drop-off</li>
                  <li>• Add retargeting campaigns for users who start but don't complete signup</li>
                  <li>• Implement onboarding improvements to increase import adoption</li>
                </ul>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}