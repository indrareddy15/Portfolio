import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { 
  Settings, 
  Eye, 
  TestTube, 
  CheckCircle, 
  XCircle, 
  AlertCircle,
  Shield,
  Cookie
} from "lucide-react";
import { trackEvent } from "@/components/GoogleTracking";

interface PixelConfig {
  id: string;
  name: string;
  type: 'gtm' | 'ga4' | 'google_ads' | 'facebook' | 'linkedin' | 'twitter';
  enabled: boolean;
  pixelId: string;
  status: 'active' | 'error' | 'testing';
  events: string[];
  lastFired?: string;
}

// Mock pixel configurations
const mockPixels: PixelConfig[] = [
  {
    id: '1',
    name: 'Google Tag Manager',
    type: 'gtm',
    enabled: true,
    pixelId: 'GTM-XXXXXXX',
    status: 'active',
    events: ['page_view', 'signup_completed', 'subscription_created'],
    lastFired: '2 minutes ago'
  },
  {
    id: '2',
    name: 'Google Analytics 4',
    type: 'ga4',
    enabled: true,
    pixelId: 'G-XXXXXXXXXX',
    status: 'active',
    events: ['page_view', 'signup_started', 'subscription_created'],
    lastFired: '1 minute ago'
  },
  {
    id: '3',
    name: 'Google Ads',
    type: 'google_ads',
    enabled: true,
    pixelId: 'AW-XXXXXXXXX',
    status: 'active',
    events: ['subscription_created', 'signup_completed'],
    lastFired: '5 minutes ago'
  },
  {
    id: '4',
    name: 'Facebook Pixel',
    type: 'facebook',
    enabled: false,
    pixelId: '1234567890123456',
    status: 'testing',
    events: ['page_view', 'signup_completed'],
    lastFired: undefined
  },
  {
    id: '5',
    name: 'LinkedIn Insight Tag',
    type: 'linkedin',
    enabled: false,
    pixelId: '123456',
    status: 'testing',
    events: ['page_view'],
    lastFired: undefined
  }
];

// Mock consent state
const mockConsentState = {
  analytics: true,
  advertising: true,
  functional: true,
  lastUpdated: '2024-01-15T10:30:00Z'
};

export default function MarketingPixels() {
  const [pixels, setPixels] = useState<PixelConfig[]>(mockPixels);
  const [consentState, setConsentState] = useState(mockConsentState);
  const [testingMode, setTestingMode] = useState(false);

  const togglePixel = (id: string) => {
    setPixels(prev => prev.map(pixel => 
      pixel.id === id 
        ? { ...pixel, enabled: !pixel.enabled }
        : pixel
    ));
  };

  const updatePixelId = (id: string, newPixelId: string) => {
    setPixels(prev => prev.map(pixel => 
      pixel.id === id 
        ? { ...pixel, pixelId: newPixelId }
        : pixel
    ));
  };

  const testPixel = (pixelId: string, pixelType: string) => {
    setTestingMode(true);
    
    // Fire test event
    trackEvent('test_event', {
      pixel_type: pixelType,
      pixel_id: pixelId,
      test_mode: true
    });
    
    // Update pixel status
    setPixels(prev => prev.map(pixel => 
      pixel.id === pixelId 
        ? { ...pixel, status: 'testing', lastFired: 'Testing now...' }
        : pixel
    ));
    
    // Simulate test completion
    setTimeout(() => {
      setPixels(prev => prev.map(pixel => 
        pixel.id === pixelId 
          ? { ...pixel, status: 'active', lastFired: 'Just now' }
          : pixel
      ));
      setTestingMode(false);
    }, 3000);
  };

  const getPixelIcon = (type: PixelConfig['type']) => {
    switch (type) {
      case 'gtm': return '🏷️';
      case 'ga4': return '📊';
      case 'google_ads': return '🎯';
      case 'facebook': return '📘';
      case 'linkedin': return '💼';
      case 'twitter': return '🐦';
      default: return '🔗';
    }
  };

  const getStatusColor = (status: PixelConfig['status']) => {
    switch (status) {
      case 'active': return 'default';
      case 'error': return 'destructive';
      case 'testing': return 'secondary';
      default: return 'outline';
    }
  };

  const getStatusIcon = (status: PixelConfig['status']) => {
    switch (status) {
      case 'active': return <CheckCircle className="h-4 w-4 text-green-500" />;
      case 'error': return <XCircle className="h-4 w-4 text-red-500" />;
      case 'testing': return <TestTube className="h-4 w-4 text-yellow-500" />;
      default: return <AlertCircle className="h-4 w-4 text-gray-500" />;
    }
  };

  const updateConsent = (type: 'analytics' | 'advertising', value: boolean) => {
    setConsentState(prev => ({
      ...prev,
      [type]: value,
      lastUpdated: new Date().toISOString()
    }));
    
    // In production, this would update the actual consent mode
    console.log('Updating consent:', type, value);
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-semibold">Pixels & Tracking Management</h2>
          <p className="text-muted-foreground">
            Configure marketing pixels and test consent mode integration
          </p>
        </div>
        <Badge variant={testingMode ? "secondary" : "outline"}>
          {testingMode ? "Testing Mode Active" : "Live Mode"}
        </Badge>
      </div>

      {/* Consent Mode Test Panel */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Shield className="h-5 w-5" />
            Consent Mode Testing
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <Alert>
            <Cookie className="h-4 w-4" />
            <AlertDescription>
              Use this panel to test how your pixels respond to different consent settings. 
              Changes here simulate user consent choices.
            </AlertDescription>
          </Alert>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-4">
              <div className="flex items-center justify-between p-3 border rounded-lg">
                <div>
                  <h4 className="font-medium">Analytics Storage</h4>
                  <p className="text-sm text-muted-foreground">GA4, GTM analytics events</p>
                </div>
                <Switch
                  checked={consentState.analytics}
                  onCheckedChange={(checked) => updateConsent('analytics', checked)}
                />
              </div>
              
              <div className="flex items-center justify-between p-3 border rounded-lg">
                <div>
                  <h4 className="font-medium">Ad Storage</h4>
                  <p className="text-sm text-muted-foreground">Google Ads, Facebook, LinkedIn</p>
                </div>
                <Switch
                  checked={consentState.advertising}
                  onCheckedChange={(checked) => updateConsent('advertising', checked)}
                />
              </div>
            </div>

            <div className="p-4 bg-muted/30 rounded-lg">
              <h4 className="font-medium mb-2">Current Consent State</h4>
              <div className="text-sm space-y-1">
                <div>Analytics: {consentState.analytics ? '✅ Granted' : '❌ Denied'}</div>
                <div>Advertising: {consentState.advertising ? '✅ Granted' : '❌ Denied'}</div>
                <div className="text-muted-foreground mt-2">
                  Last updated: {new Date(consentState.lastUpdated).toLocaleString()}
                </div>
              </div>
            </div>
          </div>

          <div className="flex gap-2">
            <Button 
              variant="outline" 
              onClick={() => {
                trackEvent('consent_test', { 
                  analytics: consentState.analytics, 
                  advertising: consentState.advertising 
                });
              }}
            >
              <TestTube className="h-4 w-4 mr-2" />
              Fire Test Event
            </Button>
            <Button variant="outline" asChild>
              <a href="https://developers.google.com/tag-platform/tag-manager/web/consent" target="_blank">
                <Eye className="h-4 w-4 mr-2" />
                View GTM Debug
              </a>
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Pixel Configuration */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {pixels.map((pixel) => (
          <Card key={pixel.id} className={pixel.enabled ? '' : 'opacity-60'}>
            <CardHeader>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <span className="text-2xl">{getPixelIcon(pixel.type)}</span>
                  <div>
                    <CardTitle className="text-lg">{pixel.name}</CardTitle>
                    <div className="flex items-center gap-2 mt-1">
                      {getStatusIcon(pixel.status)}
                      <Badge variant={getStatusColor(pixel.status)} className="text-xs">
                        {pixel.status}
                      </Badge>
                    </div>
                  </div>
                </div>
                <Switch
                  checked={pixel.enabled}
                  onCheckedChange={() => togglePixel(pixel.id)}
                />
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              {/* Pixel ID */}
              <div className="space-y-2">
                <Label>Pixel ID</Label>
                <div className="flex gap-2">
                  <Input
                    value={pixel.pixelId}
                    onChange={(e) => updatePixelId(pixel.id, e.target.value)}
                    className="font-mono text-sm"
                    placeholder={`Enter ${pixel.type.toUpperCase()} ID`}
                  />
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => testPixel(pixel.id, pixel.type)}
                    disabled={!pixel.enabled || testingMode}
                  >
                    <TestTube className="h-4 w-4" />
                  </Button>
                </div>
              </div>

              {/* Events */}
              <div className="space-y-2">
                <Label>Tracked Events</Label>
                <div className="flex flex-wrap gap-1">
                  {pixel.events.map((event, index) => (
                    <Badge key={index} variant="outline" className="text-xs">
                      {event}
                    </Badge>
                  ))}
                </div>
              </div>

              {/* Last Fired */}
              {pixel.lastFired && (
                <div className="text-sm text-muted-foreground">
                  Last fired: {pixel.lastFired}
                </div>
              )}

              {/* Consent Requirements */}
              <div className="text-xs text-muted-foreground">
                Consent required: {
                  ['gtm', 'ga4'].includes(pixel.type) 
                    ? 'Analytics' 
                    : 'Analytics + Advertising'
                }
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Environment Variables */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Settings className="h-5 w-5" />
            Environment Configuration
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <Alert>
            <AlertCircle className="h-4 w-4" />
            <AlertDescription>
              These environment variables control pixel integration. Update them in your project settings.
            </AlertDescription>
          </Alert>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
            <div className="space-y-2">
              <h4 className="font-medium">Google Tracking</h4>
              <div className="space-y-1 font-mono text-xs">
                <div>VITE_GTM_ID</div>
                <div>VITE_GA4_ID</div>
                <div>VITE_GOOGLE_ADS_ID</div>
                <div>VITE_GOOGLE_ADS_CONVERSION_LABEL</div>
                <div>VITE_GSC_VERIFICATION</div>
              </div>
            </div>

            <div className="space-y-2">
              <h4 className="font-medium">Social Media Pixels</h4>
              <div className="space-y-1 font-mono text-xs">
                <div>VITE_FACEBOOK_PIXEL_ID</div>
                <div>VITE_LINKEDIN_INSIGHT_TAG</div>
                <div>VITE_TWITTER_PIXEL_ID</div>
              </div>
            </div>
          </div>

          <Button variant="outline" size="sm">
            <Settings className="h-4 w-4 mr-2" />
            Manage Environment Variables
          </Button>
        </CardContent>
      </Card>

      {/* Testing Instructions */}
      <Card>
        <CardHeader>
          <CardTitle>Testing & Debugging</CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <div className="text-sm space-y-2">
            <p><strong>To test your tracking setup:</strong></p>
            <ol className="list-decimal list-inside space-y-1 text-muted-foreground">
              <li>Enable browser developer tools and check the Console tab</li>
              <li>Use the consent toggles above to test different scenarios</li>
              <li>Fire test events using the test buttons</li>
              <li>Verify events appear in GA4 Real-time reports</li>
              <li>Check Google Tag Manager Preview mode for detailed debugging</li>
            </ol>
          </div>

          <div className="flex gap-2">
            <Button variant="outline" size="sm" asChild>
              <a href="https://analytics.google.com/analytics/web/#/realtime" target="_blank">
                GA4 Real-time
              </a>
            </Button>
            <Button variant="outline" size="sm" asChild>
              <a href="https://tagmanager.google.com" target="_blank">
                GTM Debug
              </a>
            </Button>
            <Button variant="outline" size="sm" asChild>
              <a href="https://developers.facebook.com/tools/debug/events" target="_blank">
                FB Events Debug
              </a>
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}