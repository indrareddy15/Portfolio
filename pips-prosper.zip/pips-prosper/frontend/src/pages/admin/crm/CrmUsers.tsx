import { useEffect, useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { 
  Search, 
  Filter, 
  MoreHorizontal, 
  UserCheck, 
  UserX, 
  Mail,
  Download
} from "lucide-react";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "@/hooks/use-toast";
import { useRealtime } from "@/hooks/useRealtime";

interface UserProfile {
  id: string;
  user_id: string;
  display_name: string;
  created_at: string;
  updated_at: string;
  subscriber?: {
    subscribed: boolean;
    subscription_tier: string | null;
    email: string;
  };
}

export default function CrmUsers() {
  const [users, setUsers] = useState<UserProfile[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState("");

  const fetchUsers = async () => {
    try {
      // First get profiles
      const { data: profiles, error: profilesError } = await supabase
        .from('profiles')
        .select('*')
        .order('created_at', { ascending: false });

      if (profilesError) throw profilesError;

      // Then get subscriber data for each user
      const { data: subscribers, error: subscribersError } = await supabase
        .from('subscribers')
        .select('user_id, subscribed, subscription_tier, email');

      if (subscribersError) throw subscribersError;

      // Combine the data
      const usersWithSubscriptions = profiles?.map(profile => ({
        ...profile,
        subscriber: subscribers?.find(sub => sub.user_id === profile.user_id)
      })) || [];

      setUsers(usersWithSubscriptions);
    } catch (error) {
      console.error('Error fetching users:', error);
      toast({
        title: "Error",
        description: "Failed to fetch users",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchUsers();
  }, []);

  // Real-time subscriptions
  useRealtime([
    {
      table: 'profiles',
      events: ['INSERT', 'UPDATE', 'DELETE'],
      onInsert: (payload) => {
        console.log('New user profile created:', payload.new);
        fetchUsers(); // Refetch to get complete data with joins
        toast({
          title: "New User Registered! 👤",
          description: `${payload.new.display_name || 'New user'} has joined`,
        });
      },
      onUpdate: (payload) => {
        console.log('User profile updated:', payload.new);
        setUsers(prev => prev.map(user => 
          user.user_id === payload.new.user_id 
            ? { ...user, ...payload.new } 
            : user
        ));
      },
      onDelete: (payload) => {
        console.log('User profile deleted:', payload.old);
        setUsers(prev => prev.filter(user => user.user_id !== payload.old.user_id));
        toast({
          title: "User Removed",
          description: "A user profile has been deleted",
        });
      },
      channelName: 'crm-users-realtime'
    },
    {
      table: 'subscribers',
      events: ['INSERT', 'UPDATE', 'DELETE'],
      onInsert: (payload) => {
        console.log('New subscriber:', payload.new);
        fetchUsers(); // Refetch to update subscription data
        toast({
          title: "New Subscription! 💳",
          description: `${payload.new.email} subscribed to ${payload.new.subscription_tier}`,
        });
      },
      onUpdate: (payload) => {
        console.log('Subscriber updated:', payload.new);
        fetchUsers(); // Refetch to update subscription data
        if (payload.old.subscribed !== payload.new.subscribed) {
          toast({
            title: payload.new.subscribed ? "Subscription Activated" : "Subscription Cancelled",
            description: `${payload.new.email} subscription status changed`,
          });
        }
      },
      channelName: 'crm-users-realtime'
    }
  ]);

  const filteredUsers = users.filter(user =>
    user.display_name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    user.subscriber?.email?.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const exportUsers = () => {
    const csv = [
      ['Name', 'Email', 'Status', 'Subscription', 'Joined'].join(','),
      ...filteredUsers.map(user => [
        user.display_name || 'N/A',
        user.subscriber?.email || 'N/A',
        'Active',
        user.subscriber?.subscription_tier || 'Free',
        new Date(user.created_at).toLocaleDateString()
      ].join(','))
    ].join('\n');

    const blob = new Blob([csv], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'users-export.csv';
    a.click();
    window.URL.revokeObjectURL(url);

    toast({
      title: "Success",
      description: "Users exported successfully",
    });
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
      </div>
    );
  }
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-foreground">Users Management</h1>
          <p className="text-muted-foreground">
            Manage user accounts, subscriptions, and activity
          </p>
        </div>
        <div className="flex space-x-2">
          <Button variant="outline" size="sm" onClick={exportUsers}>
            <Download className="w-4 h-4 mr-2" />
            Export
          </Button>
          <Button variant="outline" size="sm">
            <Filter className="w-4 h-4 mr-2" />
            Filter
          </Button>
        </div>
      </div>

      {/* Search and Filters */}
      <Card className="glass-card border-card-border">
        <CardContent className="pt-6">
          <div className="flex space-x-4">
            <div className="flex-1">
              <div className="relative">
                <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="Search users by name, email, or ID..."
                  className="pl-8"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                />
              </div>
            </div>
            <Button>Search</Button>
          </div>
        </CardContent>
      </Card>

      {/* Users Table */}
      <Card className="glass-card border-card-border">
        <CardHeader>
          <CardTitle>All Users</CardTitle>
          <CardDescription>
            A list of all registered users and their account status
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>User</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Subscription</TableHead>
                <TableHead>Last Active</TableHead>
                <TableHead>Joined</TableHead>
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredUsers.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={6} className="text-center text-muted-foreground">
                    {searchTerm ? "No users found matching your search" : "No users found"}
                  </TableCell>
                </TableRow>
              ) : (
                filteredUsers.map((user) => (
                  <TableRow key={user.id}>
                    <TableCell className="font-medium">
                      <div>
                        <p className="font-medium">{user.display_name || 'No name'}</p>
                        <p className="text-sm text-muted-foreground">{user.subscriber?.email || 'No email'}</p>
                      </div>
                    </TableCell>
                    <TableCell>
                      <Badge variant="outline" className="text-success border-success">
                        <UserCheck className="w-3 h-3 mr-1" />
                        Active
                      </Badge>
                    </TableCell>
                    <TableCell>
                      <Badge variant={user.subscriber?.subscribed ? "default" : "secondary"}>
                        {user.subscriber?.subscription_tier || 'Free'}
                      </Badge>
                    </TableCell>
                    <TableCell className="text-sm text-muted-foreground">
                      {new Date(user.updated_at).toLocaleDateString()}
                    </TableCell>
                    <TableCell className="text-sm text-muted-foreground">
                      {new Date(user.created_at).toLocaleDateString()}
                    </TableCell>
                    <TableCell className="text-right">
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" className="h-8 w-8 p-0">
                            <MoreHorizontal className="h-4 w-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          <DropdownMenuItem>
                            <Mail className="mr-2 h-4 w-4" />
                            Send Email
                          </DropdownMenuItem>
                          <DropdownMenuItem>
                            <UserX className="mr-2 h-4 w-4" />
                            Suspend Account
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
}