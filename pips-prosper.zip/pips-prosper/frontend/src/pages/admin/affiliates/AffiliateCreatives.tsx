import { useEffect, useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { 
  ImageDown, 
  Upload, 
  Eye,
  Filter,
  Search,
  Plus,
  Download,
  Copy
} from "lucide-react";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "@/hooks/use-toast";

interface Creative {
  id: string;
  title: string;
  description: string | null;
  type: string;
  url: string;
  thumbnail_url: string | null;
  dimensions: string | null;
  file_size: number | null;
  category: string;
  status: string;
  created_at: string;
  updated_at: string;
}

interface CreativeStats {
  totalCreatives: number;
  activeCreatives: number;
  totalDownloads: number;
  categories: number;
}

export default function AffiliateCreatives() {
  const [creatives, setCreatives] = useState<Creative[]>([]);
  const [stats, setStats] = useState<CreativeStats>({
    totalCreatives: 0,
    activeCreatives: 0,
    totalDownloads: 0,
    categories: 0
  });
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState("");

  const fetchCreatives = async () => {
    try {
      // For demo purposes, using mock data since affiliate_creatives table doesn't exist
      const mockCreatives: Creative[] = [
        {
          id: '1',
          title: 'PipTrackr.com Banner 728x90',
          description: 'Standard banner for website placement',
          type: 'banner',
          url: '/banners/728x90.png',
          thumbnail_url: '/banners/728x90-thumb.png',
          dimensions: '728x90',
          file_size: 45000,
          category: 'web_banners',
          status: 'active',
          created_at: new Date().toISOString(),
          updated_at: new Date().toISOString()
        },
        {
          id: '2',
          title: 'Trading Journal Social Post',
          description: 'Instagram/Facebook ready social media post',
          type: 'social',
          url: '/social/ig-post-1.png',
          thumbnail_url: '/social/ig-post-1-thumb.png',
          dimensions: '1080x1080',
          file_size: 120000,
          category: 'social_media',
          status: 'active',
          created_at: new Date().toISOString(),
          updated_at: new Date().toISOString()
        },
        {
          id: '3',
          title: 'Email Header Template',
          description: 'Professional email header for newsletters',
          type: 'email',
          url: '/email/header-template.png',
          thumbnail_url: '/email/header-template-thumb.png',
          dimensions: '600x200',
          file_size: 35000,
          category: 'email_marketing',
          status: 'active',
          created_at: new Date().toISOString(),
          updated_at: new Date().toISOString()
        }
      ];

      setCreatives(mockCreatives);

      // Calculate stats
      const totalCreatives = mockCreatives.length;
      const activeCreatives = mockCreatives.filter(c => c.status === 'active').length;
      const totalDownloads = 1247; // Mock data
      const categories = new Set(mockCreatives.map(c => c.category)).size;

      setStats({ totalCreatives, activeCreatives, totalDownloads, categories });
    } catch (error) {
      console.error('Error fetching creatives:', error);
      toast({
        title: "Error",
        description: "Failed to fetch creatives",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const copyToClipboard = (url: string) => {
    navigator.clipboard.writeText(url);
    toast({
      title: "Success",
      description: "URL copied to clipboard",
    });
  };

  const toggleCreativeStatus = async (id: string, currentStatus: string) => {
    const newStatus = currentStatus === 'active' ? 'inactive' : 'active';
    
    setCreatives(prev => 
      prev.map(creative => 
        creative.id === id 
          ? { ...creative, status: newStatus }
          : creative
      )
    );

    toast({
      title: "Success",
      description: `Creative ${newStatus === 'active' ? 'activated' : 'deactivated'} successfully`,
    });
  };

  useEffect(() => {
    fetchCreatives();
  }, []);

  const filteredCreatives = creatives.filter(creative =>
    creative.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
    creative.category.toLowerCase().includes(searchTerm.toLowerCase()) ||
    creative.type.toLowerCase().includes(searchTerm.toLowerCase())
  );

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6 p-2 sm:p-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-bold text-foreground">Affiliate Creatives</h1>
          <p className="text-muted-foreground">
            Manage marketing materials and assets for affiliates
          </p>
        </div>
        <Button className="sm:w-auto">
          <Upload className="w-4 h-4 mr-2" />
          Upload Creative
        </Button>
      </div>

      {/* Creative Stats */}
      <div className="grid gap-4 grid-cols-2 lg:grid-cols-4">
        <Card className="glass-card border-card-border">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              Total Creatives
            </CardTitle>
            <ImageDown className="h-4 w-4 text-primary" />
          </CardHeader>
          <CardContent>
            <div className="text-xl sm:text-2xl font-bold text-foreground">{stats.totalCreatives}</div>
            <p className="text-xs text-muted-foreground">Available assets</p>
          </CardContent>
        </Card>

        <Card className="glass-card border-card-border">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              Active Creatives
            </CardTitle>
            <Plus className="h-4 w-4 text-success" />
          </CardHeader>
          <CardContent>
            <div className="text-xl sm:text-2xl font-bold text-foreground">{stats.activeCreatives}</div>
            <p className="text-xs text-success">Ready to use</p>
          </CardContent>
        </Card>

        <Card className="glass-card border-card-border">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              Total Downloads
            </CardTitle>
            <Download className="h-4 w-4 text-primary" />
          </CardHeader>
          <CardContent>
            <div className="text-xl sm:text-2xl font-bold text-foreground">{stats.totalDownloads}</div>
            <p className="text-xs text-muted-foreground">All time</p>
          </CardContent>
        </Card>

        <Card className="glass-card border-card-border">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              Categories
            </CardTitle>
            <Filter className="h-4 w-4 text-primary" />
          </CardHeader>
          <CardContent>
            <div className="text-xl sm:text-2xl font-bold text-foreground">{stats.categories}</div>
            <p className="text-xs text-muted-foreground">Different types</p>
          </CardContent>
        </Card>
      </div>

      {/* Search and Filters */}
      <Card className="glass-card border-card-border">
        <CardContent className="pt-6">
          <div className="flex flex-col sm:flex-row gap-4">
            <div className="flex-1">
              <div className="relative">
                <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="Search creatives by title, category, or type..."
                  className="pl-8"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                />
              </div>
            </div>
            <Button variant="outline" className="sm:w-auto">
              <Filter className="w-4 h-4 mr-2" />
              Filter
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Creatives Grid */}
      <div className="grid gap-6 grid-cols-1 md:grid-cols-2 lg:grid-cols-3">
        {filteredCreatives.length === 0 ? (
          <Card className="glass-card border-card-border col-span-full">
            <CardContent className="text-center py-12">
              <ImageDown className="w-12 h-12 mx-auto text-muted-foreground mb-4" />
              <p className="text-muted-foreground">
                {searchTerm ? "No creatives found matching your search" : "No creatives available"}
              </p>
            </CardContent>
          </Card>
        ) : (
          filteredCreatives.map((creative) => (
            <Card key={creative.id} className="glass-card border-card-border overflow-hidden">
              <div className="aspect-video bg-muted flex items-center justify-center">
                {creative.thumbnail_url ? (
                  <img 
                    src={creative.thumbnail_url} 
                    alt={creative.title}
                    className="w-full h-full object-cover"
                  />
                ) : (
                  <ImageDown className="w-12 h-12 text-muted-foreground" />
                )}
              </div>
              <CardHeader className="pb-3">
                <div className="flex items-start justify-between">
                  <CardTitle className="text-lg">{creative.title}</CardTitle>
                  <Badge 
                    variant="outline"
                    className={creative.status === 'active' ? "text-success border-success" : "text-muted-foreground"}
                  >
                    {creative.status}
                  </Badge>
                </div>
                {creative.description && (
                  <CardDescription>{creative.description}</CardDescription>
                )}
              </CardHeader>
              <CardContent className="pt-0">
                <div className="space-y-3">
                  <div className="flex justify-between text-sm">
                    <span className="text-muted-foreground">Type:</span>
                    <Badge variant="secondary">{creative.type}</Badge>
                  </div>
                  {creative.dimensions && (
                    <div className="flex justify-between text-sm">
                      <span className="text-muted-foreground">Dimensions:</span>
                      <span className="font-medium">{creative.dimensions}</span>
                    </div>
                  )}
                  {creative.file_size && (
                    <div className="flex justify-between text-sm">
                      <span className="text-muted-foreground">File Size:</span>
                      <span className="font-medium">{(creative.file_size / 1000).toFixed(1)}KB</span>
                    </div>
                  )}
                  <div className="flex space-x-2 pt-2">
                    <Button variant="outline" size="sm" className="flex-1">
                      <Eye className="w-3 h-3 mr-1" />
                      Preview
                    </Button>
                    <Button 
                      variant="outline" 
                      size="sm"
                      onClick={() => copyToClipboard(creative.url)}
                    >
                      <Copy className="w-3 h-3" />
                    </Button>
                    <Button variant="outline" size="sm">
                      <Download className="w-3 h-3" />
                    </Button>
                  </div>
                  <Button 
                    variant={creative.status === 'active' ? 'destructive' : 'default'}
                    size="sm" 
                    className="w-full"
                    onClick={() => toggleCreativeStatus(creative.id, creative.status)}
                  >
                    {creative.status === 'active' ? 'Deactivate' : 'Activate'}
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))
        )}
      </div>
    </div>
  );
}