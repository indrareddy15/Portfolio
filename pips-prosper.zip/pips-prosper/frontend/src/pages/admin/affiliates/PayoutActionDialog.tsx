import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";

interface PayoutActionDialogProps {
  isOpen: boolean;
  onClose: () => void;
  onConfirm: (data: any) => void;
  action: 'approve' | 'process' | 'mark_paid' | 'reject' | 'cancel' | null;
  payout: any;
  loading?: boolean;
}

export function PayoutActionDialog({ 
  isOpen, 
  onClose, 
  onConfirm, 
  action, 
  payout, 
  loading = false 
}: PayoutActionDialogProps) {
  const [reference, setReference] = useState("");
  const [notes, setNotes] = useState("");
  const [rejectionReason, setRejectionReason] = useState("");

  const handleConfirm = () => {
    const data: any = {};
    
    if (action === 'mark_paid') {
      data.reference = reference;
      data.notes = notes;
    } else if (action === 'reject') {
      data.rejection_reason = rejectionReason;
    } else if (action === 'cancel') {
      data.notes = notes;
    }
    
    onConfirm(data);
  };

  const getTitle = () => {
    switch (action) {
      case 'approve': return 'Approve Payout';
      case 'process': return 'Mark as Processing';
      case 'mark_paid': return 'Mark as Paid';
      case 'reject': return 'Reject Payout';
      case 'cancel': return 'Cancel Payout';
      default: return 'Confirm Action';
    }
  };

  const getDescription = () => {
    const amount = payout ? `$${payout.amount.toFixed(2)}` : '';
    const affiliate = payout?.affiliate?.code || 'Unknown';
    
    switch (action) {
      case 'approve':
        return `Approve the payout of ${amount} for affiliate ${affiliate}? This will mark it as processing.`;
      case 'process':
        return `Mark the payout of ${amount} for affiliate ${affiliate} as processing?`;
      case 'mark_paid':
        return `Mark the payout of ${amount} for affiliate ${affiliate} as paid? Please provide transaction reference.`;
      case 'reject':
        return `Reject the payout of ${amount} for affiliate ${affiliate}? Please provide a reason.`;
      case 'cancel':
        return `Cancel the payout of ${amount} for affiliate ${affiliate}?`;
      default:
        return 'Are you sure you want to perform this action?';
    }
  };

  const requiresInput = action === 'mark_paid' || action === 'reject' || action === 'cancel';
  const isFormValid = () => {
    if (action === 'mark_paid') return reference.trim().length > 0;
    if (action === 'reject') return rejectionReason.trim().length > 0;
    return true;
  };

  return (
    <AlertDialog open={isOpen} onOpenChange={() => !loading && onClose()}>
      <AlertDialogContent>
        <AlertDialogHeader>
          <AlertDialogTitle>{getTitle()}</AlertDialogTitle>
          <AlertDialogDescription>
            {getDescription()}
          </AlertDialogDescription>
        </AlertDialogHeader>

        {requiresInput && (
          <div className="space-y-4 py-4">
            {action === 'mark_paid' && (
              <>
                <div className="space-y-2">
                  <Label htmlFor="reference">Transaction Reference *</Label>
                  <Input
                    id="reference"
                    placeholder="Enter transaction ID or reference"
                    value={reference}
                    onChange={(e) => setReference(e.target.value)}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="notes">Notes (Optional)</Label>
                  <Textarea
                    id="notes"
                    placeholder="Additional notes about the payment"
                    value={notes}
                    onChange={(e) => setNotes(e.target.value)}
                  />
                </div>
              </>
            )}

            {action === 'reject' && (
              <div className="space-y-2">
                <Label htmlFor="rejection_reason">Rejection Reason *</Label>
                <Textarea
                  id="rejection_reason"
                  placeholder="Explain why this payout is being rejected"
                  value={rejectionReason}
                  onChange={(e) => setRejectionReason(e.target.value)}
                />
              </div>
            )}

            {action === 'cancel' && (
              <div className="space-y-2">
                <Label htmlFor="cancel_notes">Notes (Optional)</Label>
                <Textarea
                  id="cancel_notes"
                  placeholder="Reason for cancellation"
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                />
              </div>
            )}
          </div>
        )}

        <AlertDialogFooter>
          <AlertDialogCancel disabled={loading}>Cancel</AlertDialogCancel>
          <AlertDialogAction
            onClick={handleConfirm}
            disabled={loading || !isFormValid()}
            className={action === 'reject' || action === 'cancel' ? 'bg-destructive hover:bg-destructive/90' : ''}
          >
            {loading ? 'Processing...' : getTitle()}
          </AlertDialogAction>
        </AlertDialogFooter>
      </AlertDialogContent>
    </AlertDialog>
  );
}