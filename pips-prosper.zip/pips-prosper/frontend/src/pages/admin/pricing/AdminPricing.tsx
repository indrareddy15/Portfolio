import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Plus, Edit, Eye, EyeOff, Copy, Trash2 } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "@/hooks/use-toast";
import { PlanEditDialog } from "@/components/admin/pricing/PlanEditDialog";
import { PlanFeaturesDialog } from "@/components/admin/pricing/PlanFeaturesDialog";
import { useRealtime } from "@/hooks/useRealtime";

interface Plan {
  id: string;
  name: string;
  description: string;
  price_amount: number;
  price_currency: string;
  billing_cycle: string;
  stripe_product_id?: string;
  stripe_price_id?: string;
  is_active: boolean;
  sort_order: number;
  created_at: string;
  updated_at: string;
}

interface PlanFeature {
  id: string;
  plan_id: string;
  label: string;
  is_included: boolean;
  sort_order: number;
}

export default function AdminPricing() {
  const [plans, setPlans] = useState<Plan[]>([]);
  const [features, setFeatures] = useState<PlanFeature[]>([]);
  const [loading, setLoading] = useState(true);
  const [generatingPlans, setGeneratingPlans] = useState(false);
  const [selectedPlan, setSelectedPlan] = useState<Plan | null>(null);
  const [showPlanDialog, setShowPlanDialog] = useState(false);
  const [showFeaturesDialog, setShowFeaturesDialog] = useState(false);
  const [viewMode, setViewMode] = useState<'monthly' | 'yearly' | 'all'>('all');

  // Real-time updates for plans and features
  useRealtime([
    {
      table: 'plans',
      events: ['INSERT', 'UPDATE', 'DELETE'],
      onInsert: () => fetchPlans(),
      onUpdate: () => fetchPlans(),
      onDelete: () => fetchPlans(),
      showToasts: false
    },
    {
      table: 'plan_features',
      events: ['INSERT', 'UPDATE', 'DELETE'],
      onInsert: () => fetchFeatures(),
      onUpdate: () => fetchFeatures(),
      onDelete: () => fetchFeatures(),
      showToasts: false
    }
  ]);

  const fetchPlans = async () => {
    try {
      const { data, error } = await supabase
        .from('plans')
        .select('*')
        .order('sort_order');
      
      if (error) throw error;
      setPlans(data || []);
    } catch (error) {
      console.error('Error fetching plans:', error);
      toast({
        title: "Error",
        description: "Failed to load pricing plans",
        variant: "destructive"
      });
    }
  };

  const fetchFeatures = async () => {
    try {
      const { data, error } = await supabase
        .from('plan_features')
        .select('*')
        .order('plan_id, sort_order');
      
      if (error) throw error;
      setFeatures(data || []);
    } catch (error) {
      console.error('Error fetching features:', error);
    }
  };

  useEffect(() => {
    const loadData = async () => {
      setLoading(true);
      await Promise.all([fetchPlans(), fetchFeatures()]);
      setLoading(false);
    };
    loadData();
  }, []);

  const handleToggleActive = async (plan: Plan) => {
    try {
      const { error } = await supabase
        .from('plans')
        .update({ is_active: !plan.is_active })
        .eq('id', plan.id);

      if (error) throw error;

      toast({
        title: "Success",
        description: `Plan ${!plan.is_active ? 'activated' : 'deactivated'} successfully`
      });
    } catch (error) {
      console.error('Error toggling plan:', error);
      toast({
        title: "Error",
        description: "Failed to update plan status",
        variant: "destructive"
      });
    }
  };

  const handleDuplicatePlan = async (plan: Plan) => {
    try {
      const newPlan = {
        name: `${plan.name} Copy`,
        description: plan.description,
        price_amount: plan.price_amount,
        price_currency: plan.price_currency,
        billing_cycle: plan.billing_cycle as "monthly" | "yearly",
        is_active: false,
        sort_order: plans.length + 1
      };

      const { data, error } = await supabase
        .from('plans')
        .insert(newPlan)
        .select()
        .single();

      if (error) throw error;

      // Copy features
      const planFeatures = features.filter(f => f.plan_id === plan.id);
      if (planFeatures.length > 0) {
        const newFeatures = planFeatures.map(f => ({
          plan_id: data.id,
          label: f.label,
          is_included: f.is_included,
          sort_order: f.sort_order
        }));

        await supabase.from('plan_features').insert(newFeatures);
      }

      toast({
        title: "Success",
        description: "Plan duplicated successfully"
      });
    } catch (error) {
      console.error('Error duplicating plan:', error);
      toast({
        title: "Error",
        description: "Failed to duplicate plan",
        variant: "destructive"
      });
    }
  };

  const formatPrice = (amount: number, currency: string, cycle: string) => {
    const formattedAmount = new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: currency
    }).format(amount);
    
    return amount === 0 ? 'Free' : `${formattedAmount}/${cycle}`;
  };

  const handleBulkCreateYearlyPlans = async () => {
    if (generatingPlans) return;
    
    setGeneratingPlans(true);
    
    try {
      console.log('Starting yearly plans generation...');
      
      const monthlyPlans = plans.filter(p => p.billing_cycle === 'monthly' && p.price_amount > 0);
      console.log(`Found ${monthlyPlans.length} monthly plans to process`);
      
      if (monthlyPlans.length === 0) {
        toast({
          title: "Info",
          description: "No monthly plans found to generate yearly versions"
        });
        return;
      }

      const plansToCreate = [];
      
      for (const monthlyPlan of monthlyPlans) {
        // More robust duplicate checking
        const yearlyExists = plans.some(p => 
          (p.name.includes(monthlyPlan.name) && p.billing_cycle === 'yearly') ||
          p.name === `${monthlyPlan.name} (Yearly)` ||
          p.name === `${monthlyPlan.name} Annual`
        );
        
        if (!yearlyExists) {
          console.log(`Creating yearly version of: ${monthlyPlan.name}`);
          
          // Calculate yearly price with 17% discount (10 months price for 12 months)
          const yearlyPrice = Math.round(monthlyPlan.price_amount * 10);
          
          const yearlyPlan = {
            name: `${monthlyPlan.name} (Yearly)`,
            description: monthlyPlan.description 
              ? `${monthlyPlan.description} - Save 17% with annual billing`
              : `Annual ${monthlyPlan.name} plan - Save 17% with yearly billing`,
            price_amount: yearlyPrice,
            price_currency: monthlyPlan.price_currency,
            billing_cycle: 'yearly' as const,
            is_active: monthlyPlan.is_active,
            sort_order: monthlyPlan.sort_order + 0.5
          };

          plansToCreate.push({ monthlyPlan, yearlyPlan });
        } else {
          console.log(`Yearly version already exists for: ${monthlyPlan.name}`);
        }
      }

      if (plansToCreate.length === 0) {
        toast({
          title: "Info",
          description: "All monthly plans already have yearly versions"
        });
        return;
      }

      console.log(`Creating ${plansToCreate.length} yearly plans...`);

      // Create plans in parallel for better performance
      const results = await Promise.all(
        plansToCreate.map(async ({ monthlyPlan, yearlyPlan }) => {
          const { data: newPlan, error: planError } = await supabase
            .from('plans')
            .insert(yearlyPlan)
            .select()
            .single();

          if (planError) {
            console.error(`Error creating yearly plan for ${monthlyPlan.name}:`, planError);
            throw planError;
          }

          // Copy features from monthly plan
          const monthlyFeatures = features.filter(f => f.plan_id === monthlyPlan.id);
          
          if (monthlyFeatures.length > 0) {
            const yearlyFeatures = monthlyFeatures.map(f => ({
              plan_id: newPlan.id,
              label: f.label,
              is_included: f.is_included,
              sort_order: f.sort_order
            }));

            const { error: featuresError } = await supabase
              .from('plan_features')
              .insert(yearlyFeatures);

            if (featuresError) {
              console.error(`Error copying features for ${monthlyPlan.name}:`, featuresError);
              throw featuresError;
            }

            console.log(`Copied ${monthlyFeatures.length} features for ${newPlan.name}`);
          }

          return newPlan;
        })
      );

      console.log(`Successfully created ${results.length} yearly plans`);

      toast({
        title: "Success",
        description: `Successfully created ${results.length} yearly plan${results.length > 1 ? 's' : ''}`
      });

      // Force refresh data to ensure UI updates
      await Promise.all([fetchPlans(), fetchFeatures()]);
      
    } catch (error) {
      console.error('Error creating yearly plans:', error);
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to create yearly plans",
        variant: "destructive"
      });
    } finally {
      setGeneratingPlans(false);
    }
  };

  const filteredPlans = plans.filter(plan => {
    if (viewMode === 'all') return true;
    return plan.billing_cycle === viewMode;
  });

  const getPlanFeatures = (planId: string) => {
    return features.filter(f => f.plan_id === planId);
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Pricing & Plans</h1>
          <p className="text-muted-foreground">
            Manage subscription plans and features for PipTrackr.com
          </p>
        </div>
        <div className="flex space-x-2">
          <Button onClick={() => { setSelectedPlan(null); setShowPlanDialog(true); }}>
            <Plus className="w-4 h-4 mr-2" />
            Create Plan
          </Button>
          <Button 
            variant="outline" 
            onClick={handleBulkCreateYearlyPlans}
            disabled={generatingPlans}
          >
            {generatingPlans ? (
              <>
                <div className="w-4 h-4 mr-2 animate-spin rounded-full border-2 border-current opacity-25 border-t-current" />
                Generating...
              </>
            ) : (
              'Generate Yearly Plans'
            )}
          </Button>
        </div>
      </div>

      <Tabs defaultValue="plans" className="space-y-6">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="plans">Plans</TabsTrigger>
          <TabsTrigger value="features">Features</TabsTrigger>
        </TabsList>

        <TabsContent value="plans" className="space-y-4">
          {/* Filter buttons */}
          <div className="flex space-x-2 mb-6">
            <Button
              variant={viewMode === 'all' ? 'default' : 'outline'}
              size="sm"
              onClick={() => setViewMode('all')}
            >
              All ({plans.length})
            </Button>
            <Button
              variant={viewMode === 'monthly' ? 'default' : 'outline'}
              size="sm"
              onClick={() => setViewMode('monthly')}
            >
              Monthly ({plans.filter(p => p.billing_cycle === 'monthly').length})
            </Button>
            <Button
              variant={viewMode === 'yearly' ? 'default' : 'outline'}
              size="sm"
              onClick={() => setViewMode('yearly')}
            >
              Yearly ({plans.filter(p => p.billing_cycle === 'yearly').length})
            </Button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredPlans.map((plan) => (
              <Card key={plan.id} className={`relative transition-all ${!plan.is_active ? 'opacity-60' : ''}`}>
                <CardHeader className="pb-2">
                  <div className="flex items-center justify-between">
                    <CardTitle className="text-lg">{plan.name}</CardTitle>
                    <div className="flex items-center space-x-2">
                      {plan.is_active ? (
                        <Badge variant="default">Active</Badge>
                      ) : (
                        <Badge variant="secondary">Inactive</Badge>
                      )}
                      {plan.stripe_price_id && (
                        <Badge variant="outline" className="text-xs">
                          Stripe
                        </Badge>
                      )}
                    </div>
                  </div>
                  {plan.description && (
                    <p className="text-sm text-muted-foreground">{plan.description}</p>
                  )}
                </CardHeader>

                <CardContent className="space-y-4">
                  <div>
                    <div className="text-2xl font-bold">
                      {formatPrice(plan.price_amount, plan.price_currency, plan.billing_cycle)}
                    </div>
                    <div className="text-sm text-muted-foreground">
                      Billed {plan.billing_cycle}
                    </div>
                  </div>

                  <div className="space-y-2">
                    <div className="text-sm font-medium">Features ({getPlanFeatures(plan.id).length})</div>
                    <div className="space-y-1">
                      {getPlanFeatures(plan.id).slice(0, 3).map((feature) => (
                        <div key={feature.id} className="flex items-center space-x-2 text-sm">
                          <span className={feature.is_included ? 'text-success' : 'text-muted-foreground'}>
                            {feature.is_included ? '✓' : '✗'}
                          </span>
                          <span className={!feature.is_included ? 'line-through text-muted-foreground' : ''}>
                            {feature.label}
                          </span>
                        </div>
                      ))}
                      {getPlanFeatures(plan.id).length > 3 && (
                        <div className="text-xs text-muted-foreground">
                          +{getPlanFeatures(plan.id).length - 3} more features
                        </div>
                      )}
                    </div>
                  </div>

                  <div className="flex space-x-2">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => { setSelectedPlan(plan); setShowPlanDialog(true); }}
                    >
                      <Edit className="w-4 h-4 mr-1" />
                      Edit
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => handleToggleActive(plan)}
                    >
                      {plan.is_active ? (
                        <>
                          <EyeOff className="w-4 h-4 mr-1" />
                          Hide
                        </>
                      ) : (
                        <>
                          <Eye className="w-4 h-4 mr-1" />
                          Show
                        </>
                      )}
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => handleDuplicatePlan(plan)}
                    >
                      <Copy className="w-4 h-4 mr-1" />
                      Copy
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="features" className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-lg font-semibold">Plan Features</h3>
              <p className="text-sm text-muted-foreground">
                Configure what's included in each plan
              </p>
            </div>
          </div>

          <div className="grid gap-6">
            {plans.map((plan) => (
              <Card key={plan.id}>
                <CardHeader className="pb-3">
                  <div className="flex items-center justify-between">
                    <div>
                      <CardTitle className="text-lg">{plan.name}</CardTitle>
                      <p className="text-sm text-muted-foreground">
                        {formatPrice(plan.price_amount, plan.price_currency, plan.billing_cycle)}
                      </p>
                    </div>
                    <Button
                      variant="outline"
                      onClick={() => { setSelectedPlan(plan); setShowFeaturesDialog(true); }}
                    >
                      <Edit className="w-4 h-4 mr-2" />
                      Edit Features
                    </Button>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-2">
                    {getPlanFeatures(plan.id).map((feature) => (
                      <div key={feature.id} className="flex items-center space-x-2 text-sm">
                        <span className={feature.is_included ? 'text-success' : 'text-muted-foreground'}>
                          {feature.is_included ? '✓' : '✗'}
                        </span>
                        <span className={!feature.is_included ? 'line-through text-muted-foreground' : ''}>
                          {feature.label}
                        </span>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>
      </Tabs>

      {/* Dialogs */}
      <PlanEditDialog
        plan={selectedPlan}
        open={showPlanDialog}
        onOpenChange={setShowPlanDialog}
        onSuccess={() => {
          setShowPlanDialog(false);
          setSelectedPlan(null);
        }}
      />

      <PlanFeaturesDialog
        plan={selectedPlan}
        features={selectedPlan ? getPlanFeatures(selectedPlan.id) : []}
        open={showFeaturesDialog}
        onOpenChange={setShowFeaturesDialog}
        onSuccess={() => {
          setShowFeaturesDialog(false);
          setSelectedPlan(null);
        }}
      />
    </div>
  );
}