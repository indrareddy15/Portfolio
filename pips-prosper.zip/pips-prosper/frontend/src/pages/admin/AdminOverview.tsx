import { useEffect, useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "@/hooks/use-toast";
import { useSystemSettings } from "@/hooks/useSystemSettings";
import { 
  Users2, 
  Handshake, 
  BadgeDollarSign, 
  TrendingUp,
  DollarSign,
  UserCheck,
  AlertCircle,
  Calendar,
  CalendarRange,
  Eye,
  Globe,
  MapPin,
  Activity,
  BarChart3,
  PieChart,
  TrendingDown,
  UserPlus,
  RefreshCw
} from "lucide-react";
import * as Recharts from "recharts";

// Mock world map data - in real app you'd use a proper map library
const WorldMap = ({ data }: { data: any[] }) => (
  <div className="w-full h-[300px] bg-gradient-to-br from-primary/5 to-secondary/5 rounded-lg border border-border/50 flex items-center justify-center relative overflow-hidden">
    <div className="absolute inset-0 bg-gradient-to-r from-primary/10 via-transparent to-secondary/10"></div>
    <div className="z-10 text-center space-y-4">
      <Globe className="h-16 w-16 text-primary mx-auto animate-pulse" />
      <div>
        <h3 className="text-lg font-semibold text-foreground">Global User Distribution</h3>
        <p className="text-sm text-muted-foreground">Real-time user activity across regions</p>
      </div>
      <div className="grid grid-cols-2 gap-4 mt-4">
        {data.slice(0, 4).map((region, index) => (
          <div key={index} className="text-center">
            <div className="flex items-center justify-center gap-2">
              <MapPin className="h-4 w-4 text-primary" />
              <span className="text-sm font-medium">{region.region}</span>
            </div>
            <p className="text-lg font-bold text-primary">{region.users}</p>
          </div>
        ))}
      </div>
    </div>
  </div>
);

interface DashboardStats {
  totalUsers: number;
  activeUsers: number;
  newRegistrations: number;
  activeAffiliates: number;
  monthlyRevenue: number;
  pendingPayouts: number;
  totalPageVisits: number;
  dailyPageVisits: number;
  recentApplications: any[];
  userGrowthData: any[];
  revenueData: any[];
  regionData: any[];
  trafficData: any[];
}

export default function AdminOverview() {
  const { isAffiliateEnabled } = useSystemSettings();
  const [stats, setStats] = useState<DashboardStats>({
    totalUsers: 0,
    activeUsers: 0,
    newRegistrations: 0,
    activeAffiliates: 0,
    monthlyRevenue: 0,
    pendingPayouts: 0,
    totalPageVisits: 0,
    dailyPageVisits: 0,
    recentApplications: [],
    userGrowthData: [],
    revenueData: [],
    regionData: [],
    trafficData: []
  });
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);

  const generateMockData = () => {
    // Mock user growth data for last 7 days
    const userGrowthData = Array.from({ length: 7 }, (_, i) => {
      const date = new Date();
      date.setDate(date.getDate() - (6 - i));
      return {
        date: date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' }),
        users: Math.floor(Math.random() * 50) + 20,
        registrations: Math.floor(Math.random() * 15) + 5
      };
    });

    // Mock revenue data
    const revenueData = Array.from({ length: 12 }, (_, i) => {
      const date = new Date();
      date.setMonth(date.getMonth() - (11 - i));
      return {
        month: date.toLocaleDateString('en-US', { month: 'short' }),
        revenue: Math.floor(Math.random() * 5000) + 2000,
        subscriptions: Math.floor(Math.random() * 100) + 50
      };
    });

    // Mock region data
    const regionData = [
      { region: 'North America', users: 1240, percentage: 35 },
      { region: 'Europe', users: 980, percentage: 28 },
      { region: 'Asia Pacific', users: 720, percentage: 20 },
      { region: 'Latin America', users: 380, percentage: 11 },
      { region: 'Middle East & Africa', users: 210, percentage: 6 }
    ];

    // Mock traffic data
    const trafficData = Array.from({ length: 24 }, (_, i) => ({
      hour: i,
      visits: Math.floor(Math.random() * 200) + 50,
      uniqueVisitors: Math.floor(Math.random() * 150) + 30
    }));

    return { userGrowthData, revenueData, regionData, trafficData };
  };

  const fetchDashboardStats = async () => {
    try {
      setRefreshing(true);

      // Fetch real data
      const [
        { count: userCount },
        { count: todayUsers },
        { data: subscribers },
      ] = await Promise.all([
        supabase.from('profiles').select('*', { count: 'exact', head: true }),
        supabase.from('profiles').select('*', { count: 'exact', head: true })
          .gte('created_at', new Date().toISOString().split('T')[0]),
        supabase.from('subscribers').select('subscription_tier').eq('subscribed', true)
      ]);

      // Fetch affiliate data if enabled
      let affiliateCount = 0;
      let pendingAmount = 0;
      let applications = [];

      if (isAffiliateEnabled) {
        const [
          { count: activeAffiliates },
          { data: payouts },
          { data: recentApps }
        ] = await Promise.all([
          supabase.from('affiliates').select('*', { count: 'exact', head: true }).eq('status', 'active'),
          supabase.from('payouts').select('amount').eq('status', 'requested'),
          supabase.from('affiliate_applications').select('*').order('created_at', { ascending: false }).limit(5)
        ]);

        affiliateCount = activeAffiliates || 0;
        pendingAmount = payouts?.reduce((acc, payout) => acc + Number(payout.amount), 0) || 0;
        applications = recentApps || [];
      }

      // Calculate revenue
      const revenue = subscribers?.reduce((acc, sub) => {
        const tierRevenue = sub.subscription_tier === 'pro' ? 29 : sub.subscription_tier === 'premium' ? 49 : 19;
        return acc + tierRevenue;
      }, 0) || 0;

      // Generate mock data for charts
      const mockData = generateMockData();

      setStats({
        totalUsers: userCount || 0,
        activeUsers: Math.floor((userCount || 0) * 0.3), // Mock active users as 30% of total
        newRegistrations: todayUsers || 0,
        activeAffiliates: affiliateCount,
        monthlyRevenue: revenue,
        pendingPayouts: pendingAmount,
        totalPageVisits: Math.floor(Math.random() * 10000) + 5000, // Mock data
        dailyPageVisits: Math.floor(Math.random() * 1000) + 500, // Mock data
        recentApplications: applications,
        ...mockData
      });
    } catch (error) {
      console.error('Error fetching dashboard stats:', error);
      toast({
        title: "Error",
        description: "Failed to fetch dashboard statistics",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  useEffect(() => {
    fetchDashboardStats();
    
    // Set up real-time updates
    const channel = supabase
      .channel('admin-overview-realtime')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'profiles' }, fetchDashboardStats)
      .on('postgres_changes', { event: '*', schema: 'public', table: 'subscribers' }, fetchDashboardStats)
      .on('postgres_changes', { event: '*', schema: 'public', table: 'affiliates' }, fetchDashboardStats)
      .on('postgres_changes', { event: '*', schema: 'public', table: 'affiliate_applications' }, fetchDashboardStats)
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [isAffiliateEnabled]);

  const COLORS = ['hsl(var(--primary))', 'hsl(var(--success))', 'hsl(var(--warning))', 'hsl(var(--danger))', 'hsl(var(--info))'];

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="flex items-center gap-3">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
          <span className="text-lg font-medium">Loading dashboard...</span>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold text-foreground">Admin Dashboard</h1>
          <p className="text-muted-foreground mt-1">
            Real-time analytics and platform insights
          </p>
        </div>
        <Button 
          variant="outline" 
          onClick={fetchDashboardStats}
          disabled={refreshing}
          className="flex items-center gap-2"
        >
          <RefreshCw className={`h-4 w-4 ${refreshing ? 'animate-spin' : ''}`} />
          Refresh Data
        </Button>
      </div>

      {/* Key Metrics Grid */}
      <div className="grid gap-4 grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 xl:grid-cols-6">
        <Card className="glass-card">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Users</CardTitle>
            <Users2 className="h-4 w-4 text-primary" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.totalUsers.toLocaleString()}</div>
            <p className="text-xs text-muted-foreground">Registered users</p>
          </CardContent>
        </Card>

        <Card className="glass-card">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Active Users</CardTitle>
            <Activity className="h-4 w-4 text-success" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.activeUsers.toLocaleString()}</div>
            <p className="text-xs text-success">Currently online</p>
          </CardContent>
        </Card>

        <Card className="glass-card">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">New Today</CardTitle>
            <UserPlus className="h-4 w-4 text-info" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.newRegistrations}</div>
            <p className="text-xs text-info">Today's registrations</p>
          </CardContent>
        </Card>

        <Card className="glass-card">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Revenue</CardTitle>
            <DollarSign className="h-4 w-4 text-success" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">${stats.monthlyRevenue.toLocaleString()}</div>
            <p className="text-xs text-success">Monthly MRR</p>
          </CardContent>
        </Card>

        <Card className="glass-card">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Page Views</CardTitle>
            <Eye className="h-4 w-4 text-primary" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.totalPageVisits.toLocaleString()}</div>
            <p className="text-xs text-muted-foreground">Total views</p>
          </CardContent>
        </Card>

        {isAffiliateEnabled && (
          <Card className="glass-card">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Affiliates</CardTitle>
              <Handshake className="h-4 w-4 text-warning" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stats.activeAffiliates}</div>
              <p className="text-xs text-warning">Active partners</p>
            </CardContent>
          </Card>
        )}
      </div>

      {/* Charts Section */}
      <div className="grid gap-6 grid-cols-1 lg:grid-cols-2">
        {/* User Growth Chart */}
        <Card className="glass-card">
          <CardHeader>
            <div className="flex items-center justify-between">
              <div>
                <CardTitle className="flex items-center gap-2">
                  <TrendingUp className="h-5 w-5 text-success" />
                  User Growth
                </CardTitle>
                <CardDescription>Daily user registrations and activity</CardDescription>
              </div>
              <Badge variant="secondary">Last 7 days</Badge>
            </div>
          </CardHeader>
          <CardContent>
            <Recharts.ResponsiveContainer width="100%" height={300}>
              <Recharts.AreaChart data={stats.userGrowthData}>
                <Recharts.CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                <Recharts.XAxis dataKey="date" stroke="hsl(var(--muted-foreground))" />
                <Recharts.YAxis stroke="hsl(var(--muted-foreground))" />
                <Recharts.Tooltip 
                  contentStyle={{
                    backgroundColor: 'hsl(var(--card))',
                    border: '1px solid hsl(var(--border))',
                    borderRadius: '8px'
                  }}
                />
                <Recharts.Area 
                  type="monotone" 
                  dataKey="users" 
                  stackId="1"
                  stroke="hsl(var(--primary))" 
                  fill="hsl(var(--primary) / 0.2)" 
                />
                <Recharts.Area 
                  type="monotone" 
                  dataKey="registrations" 
                  stackId="1"
                  stroke="hsl(var(--success))" 
                  fill="hsl(var(--success) / 0.2)" 
                />
              </Recharts.AreaChart>
            </Recharts.ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Revenue Chart */}
        <Card className="glass-card">
          <CardHeader>
            <div className="flex items-center justify-between">
              <div>
                <CardTitle className="flex items-center gap-2">
                  <BarChart3 className="h-5 w-5 text-primary" />
                  Revenue Analytics
                </CardTitle>
                <CardDescription>Monthly revenue and subscription trends</CardDescription>
              </div>
              <Badge variant="secondary">Last 12 months</Badge>
            </div>
          </CardHeader>
          <CardContent>
            <Recharts.ResponsiveContainer width="100%" height={300}>
              <Recharts.BarChart data={stats.revenueData}>
                <Recharts.CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                <Recharts.XAxis dataKey="month" stroke="hsl(var(--muted-foreground))" />
                <Recharts.YAxis stroke="hsl(var(--muted-foreground))" />
                <Recharts.Tooltip 
                  contentStyle={{
                    backgroundColor: 'hsl(var(--card))',
                    border: '1px solid hsl(var(--border))',
                    borderRadius: '8px'
                  }}
                />
                <Recharts.Bar dataKey="revenue" fill="hsl(var(--primary))" />
              </Recharts.BarChart>
            </Recharts.ResponsiveContainer>
          </CardContent>
        </Card>
      </div>

      {/* World Map and Traffic Analytics */}
      <div className="grid gap-6 grid-cols-1 lg:grid-cols-2">
        {/* World Map */}
        <Card className="glass-card">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Globe className="h-5 w-5 text-primary" />
              Global User Distribution
            </CardTitle>
            <CardDescription>Real-time user activity by region</CardDescription>
          </CardHeader>
          <CardContent>
            <WorldMap data={stats.regionData} />
          </CardContent>
        </Card>

        {/* Regional Breakdown */}
        <Card className="glass-card">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <PieChart className="h-5 w-5 text-success" />
              Regional Breakdown
            </CardTitle>
            <CardDescription>User distribution by geographical region</CardDescription>
          </CardHeader>
          <CardContent>
            <Recharts.ResponsiveContainer width="100%" height={300}>
              <Recharts.PieChart>
                <Recharts.Pie
                  data={stats.regionData}
                  cx="50%"
                  cy="50%"
                  outerRadius={80}
                  dataKey="users"
                  label={({ region, percentage }) => `${region}: ${percentage}%`}
                >
                  {stats.regionData.map((entry, index) => (
                    <Recharts.Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Recharts.Pie>
                <Recharts.Tooltip 
                  contentStyle={{
                    backgroundColor: 'hsl(var(--card))',
                    border: '1px solid hsl(var(--border))',
                    borderRadius: '8px'
                  }}
                />
              </Recharts.PieChart>
            </Recharts.ResponsiveContainer>
          </CardContent>
        </Card>
      </div>

      {/* Traffic Analytics */}
      <Card className="glass-card">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Activity className="h-5 w-5 text-info" />
            Traffic Analytics
          </CardTitle>
          <CardDescription>Hourly website traffic and user engagement</CardDescription>
        </CardHeader>
        <CardContent>
          <Recharts.ResponsiveContainer width="100%" height={300}>
            <Recharts.LineChart data={stats.trafficData}>
              <Recharts.CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
              <Recharts.XAxis 
                dataKey="hour" 
                stroke="hsl(var(--muted-foreground))"
                tickFormatter={(hour) => `${hour}:00`}
              />
              <Recharts.YAxis stroke="hsl(var(--muted-foreground))" />
              <Recharts.Tooltip 
                contentStyle={{
                  backgroundColor: 'hsl(var(--card))',
                  border: '1px solid hsl(var(--border))',
                  borderRadius: '8px'
                }}
                labelFormatter={(hour) => `${hour}:00`}
              />
              <Recharts.Legend />
              <Recharts.Line 
                type="monotone" 
                dataKey="visits" 
                stroke="hsl(var(--primary))" 
                strokeWidth={2}
                name="Page Visits"
              />
              <Recharts.Line 
                type="monotone" 
                dataKey="uniqueVisitors" 
                stroke="hsl(var(--success))" 
                strokeWidth={2}
                name="Unique Visitors"
              />
            </Recharts.LineChart>
          </Recharts.ResponsiveContainer>
        </CardContent>
      </Card>
    </div>
  );
}