import { LogoManager } from "@/components/admin/LogoManager";
import { SEOHead } from "@/components/SEOHead";

export default function AdminLogoManager() {
  return (
    <div className="space-y-6">
      <SEOHead 
        title="Logo Management - Admin Dashboard"
        description="Manage website logos and branding assets"
      />
      
      <LogoManager />
    </div>
  );
}