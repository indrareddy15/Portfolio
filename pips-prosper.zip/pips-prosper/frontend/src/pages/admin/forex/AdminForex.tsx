import { useState } from "react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { testCases } from "@/utils/forexEngine";
import { InstrumentManager } from "@/components/admin/forex/InstrumentManager";
import { FxRatesManager } from "@/components/admin/forex/FxRatesManager";
import { PlayCircle, CheckCircle, XCircle } from "lucide-react";

export default function AdminForex() {
  const [testResults, setTestResults] = useState<any[]>([]);
  const [testingInProgress, setTestingInProgress] = useState(false);

  const runUnitTests = async () => {
    setTestingInProgress(true);
    const results = [];

    // Import the forexEngine dynamically to avoid SSR issues
    const { forexEngine } = await import("@/utils/forexEngine");

    for (const testCase of testCases) {
      try {
        const result = await forexEngine.calculateTrade(testCase.input);
        
        const passed = {
          pips: Math.abs(result.pips - testCase.expected.pips) < 0.1,
          rawPnL: Math.abs(result.rawPnL - testCase.expected.rawPnL) < 0.01,
          convertedPnL: Math.abs(result.convertedPnL - testCase.expected.convertedPnL) < 0.01
        };

        results.push({
          name: testCase.name,
          passed: passed.pips && passed.rawPnL && passed.convertedPnL,
          expected: testCase.expected,
          actual: {
            pips: result.pips,
            rawPnL: result.rawPnL,
            convertedPnL: result.convertedPnL
          },
          details: passed
        });
      } catch (error: any) {
        results.push({
          name: testCase.name,
          passed: false,
          error: error.message,
          expected: testCase.expected
        });
      }
    }

    setTestResults(results);
    setTestingInProgress(false);
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Forex Configuration</h1>
          <p className="text-muted-foreground">
            Manage Forex instruments, exchange rates, and test calculation accuracy
          </p>
        </div>
      </div>

      <Tabs defaultValue="instruments" className="space-y-6">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="instruments">Instruments</TabsTrigger>
          <TabsTrigger value="rates">FX Rates</TabsTrigger>
          <TabsTrigger value="testing">Unit Tests</TabsTrigger>
        </TabsList>

        <TabsContent value="instruments">
          <InstrumentManager />
        </TabsContent>

        <TabsContent value="rates">
          <FxRatesManager />
        </TabsContent>

        <TabsContent value="testing">
          <div className="space-y-6">
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle>Forex Engine Unit Tests</CardTitle>
                    <p className="text-sm text-muted-foreground">
                      Validate calculation accuracy with predefined test cases
                    </p>
                  </div>
                  <Button onClick={runUnitTests} disabled={testingInProgress}>
                    <PlayCircle className="w-4 h-4 mr-2" />
                    {testingInProgress ? "Running Tests..." : "Run Tests"}
                  </Button>
                </div>
              </CardHeader>
              <CardContent>
                {testResults.length === 0 && (
                  <div className="text-center text-muted-foreground py-8">
                    Click "Run Tests" to validate the Forex engine calculations
                  </div>
                )}

                {testResults.length > 0 && (
                  <div className="space-y-4">
                    <div className="flex items-center gap-4">
                      <Badge variant={testResults.every(r => r.passed) ? "default" : "destructive"}>
                        {testResults.filter(r => r.passed).length} / {testResults.length} Passed
                      </Badge>
                      <span className="text-sm text-muted-foreground">
                        {testResults.every(r => r.passed) ? "All tests passed!" : "Some tests failed"}
                      </span>
                    </div>

                    <div className="space-y-3">
                      {testResults.map((result, index) => (
                        <Card key={index} className={`border-l-4 ${result.passed ? 'border-l-green-500' : 'border-l-red-500'}`}>
                          <CardContent className="p-4">
                            <div className="flex items-start justify-between">
                              <div className="space-y-2">
                                <div className="flex items-center gap-2">
                                  {result.passed ? (
                                    <CheckCircle className="w-5 h-5 text-green-500" />
                                  ) : (
                                    <XCircle className="w-5 h-5 text-red-500" />
                                  )}
                                  <span className="font-semibold">{result.name}</span>
                                </div>

                                {result.error && (
                                  <div className="text-sm text-red-600 bg-red-50 p-2 rounded">
                                    Error: {result.error}
                                  </div>
                                )}

                                {!result.error && (
                                  <div className="grid grid-cols-2 gap-4 text-sm">
                                    <div>
                                      <div className="font-medium text-muted-foreground">Expected:</div>
                                      <div>Pips: {result.expected.pips}</div>
                                      <div>Raw PnL: {result.expected.rawPnL}</div>
                                      <div>Converted PnL: {result.expected.convertedPnL}</div>
                                    </div>
                                    <div>
                                      <div className="font-medium text-muted-foreground">Actual:</div>
                                      <div className={result.details?.pips ? 'text-green-600' : 'text-red-600'}>
                                        Pips: {result.actual?.pips}
                                      </div>
                                      <div className={result.details?.rawPnL ? 'text-green-600' : 'text-red-600'}>
                                        Raw PnL: {result.actual?.rawPnL}
                                      </div>
                                      <div className={result.details?.convertedPnL ? 'text-green-600' : 'text-red-600'}>
                                        Converted PnL: {result.actual?.convertedPnL}
                                      </div>
                                    </div>
                                  </div>
                                )}
                              </div>
                            </div>
                          </CardContent>
                        </Card>
                      ))}
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}