import { useState, useEffect, useCallback, useRef } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { 
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { supabase } from "@/integrations/supabase/client";
import { 
  Save, 
  ArrowLeft, 
  Eye, 
  Upload,
  Clock,
  Calendar,
  X,
  Plus,
  Bold,
  Italic,
  Underline,
  Strikethrough,
  Link,
  Image,
  List,
  ListOrdered,
  Quote,
  Code,
  Heading1,
  Heading2,
  Heading3,
  Type,
  AlignLeft,
  AlignCenter,
  AlignRight,
  ChevronDown,
  Trash2,
  Download,
  Target,
  AlertTriangle
} from "lucide-react";
import { toast } from "sonner";
import { debounce } from "lodash";
import PollDialog from "@/components/blog/PollDialog";
import QnaDialog from "@/components/blog/QnaDialog";

interface BlogPost {
  id?: string;
  title: string;
  slug: string;
  excerpt: string;
  body_md: string;
  cover_url: string;
  status: 'draft' | 'published' | 'scheduled';
  publish_at: string;
  meta_title: string;
  meta_description: string;
  og_title: string;
  og_description: string;
  og_image_url: string;
  canonical_url: string;
  category_id: string;
  author_id: string;
  featured: boolean;
  reading_time: number;
  tags: string[];
}

interface Category {
  id: string;
  name: string;
}

interface Author {
  id: string;
  name: string;
}

interface Tag {
  id: string;
  name: string;
  slug: string;
}

interface MediaFile {
  id: string;
  url: string;
  alt?: string;
  file_size?: number;
  width?: number;
  height?: number;
  mime_type?: string;
  created_at: string;
}

interface Poll {
  id?: string;
  title: string;
  description?: string;
  poll_type: 'single' | 'multiple';
  options_json: string[];
  allow_custom_answers: boolean;
  expires_at?: string;
  is_active: boolean;
  position: number;
}

interface QnA {
  id?: string;
  title: string;
  description?: string;
  is_active: boolean;
  allow_anonymous: boolean;
  moderated: boolean;
  position: number;
}

export default function BlogPostEditor() {
  const { id } = useParams();
  const navigate = useNavigate();
  const isEditing = !!id && id !== 'new';

  const [post, setPost] = useState<BlogPost>({
    title: '',
    slug: '',
    excerpt: '',
    body_md: '',
    cover_url: '',
    status: 'draft',
    publish_at: '',
    meta_title: '',
    meta_description: '',
    og_title: '',
    og_description: '',
    og_image_url: '',
    canonical_url: '',
    category_id: '',
    author_id: '',
    featured: false,
    reading_time: 0,
    tags: []
  });

  const [categories, setCategories] = useState<Category[]>([]);
  const [authors, setAuthors] = useState<Author[]>([]);
  const [availableTags, setAvailableTags] = useState<Tag[]>([]);
  const [newTag, setNewTag] = useState('');
  const [saving, setSaving] = useState(false);
  const [previewMode, setPreviewMode] = useState(false);
  const [uploadingImage, setUploadingImage] = useState(false);
  const [imageValidation, setImageValidation] = useState<{
    isValid: boolean;
    warnings: string[];
    specs?: { width: number; height: number; size: number; format: string };
  }>({ isValid: true, warnings: [] });
  const [mediaFiles, setMediaFiles] = useState<MediaFile[]>([]);
  const [showMediaLibrary, setShowMediaLibrary] = useState(false);
  const [selectedText, setSelectedText] = useState('');
  const [cursorPosition, setCursorPosition] = useState({ start: 0, end: 0 });
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const [polls, setPolls] = useState<Poll[]>([]);
  const [qnas, setQnas] = useState<QnA[]>([]);
  const [showPollDialog, setShowPollDialog] = useState(false);
  const [showQnaDialog, setShowQnaDialog] = useState(false);
  const [editingPoll, setEditingPoll] = useState<Poll | null>(null);
  const [editingQna, setEditingQna] = useState<QnA | null>(null);

  useEffect(() => {
    fetchInitialData();
    fetchMediaFiles();
    if (isEditing) {
      fetchPost();
      fetchPollsAndQnas();
    }
  }, [id]);

  // Real-time media updates
  useEffect(() => {
    const channel = supabase
      .channel('media-changes')
      .on('postgres_changes', 
        { event: 'INSERT', schema: 'public', table: 'blog_media' },
        (payload) => {
          const newFile = payload.new as MediaFile;
          setMediaFiles(prev => [newFile, ...prev]);
        }
      )
      .on('postgres_changes', 
        { event: 'DELETE', schema: 'public', table: 'blog_media' },
        (payload) => {
          const deletedId = payload.old.id;
          setMediaFiles(prev => prev.filter(f => f.id !== deletedId));
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, []);

  // Auto-save functionality
  const debouncedSave = useCallback(
    debounce(async (postData: BlogPost) => {
      if (isEditing) {
        await savePost(postData, true); // Auto-save
      }
    }, 2000),
    [isEditing]
  );

  useEffect(() => {
    if (post.title && isEditing) {
      debouncedSave(post);
    }
  }, [post, debouncedSave]);

  const fetchInitialData = async () => {
    try {
      const [categoriesRes, authorsRes, tagsRes] = await Promise.all([
        supabase.from('blog_categories').select('id, name').order('name'),
        supabase.from('blog_authors').select('id, name').order('name'),
        supabase.from('blog_tags').select('*').order('name')
      ]);

      setCategories(categoriesRes.data || []);
      setAuthors(authorsRes.data || []);
      setAvailableTags(tagsRes.data || []);

      // Set default author if available
      if (authorsRes.data && authorsRes.data.length > 0) {
        setPost(prev => ({ ...prev, author_id: authorsRes.data[0].id }));
      }
    } catch (error) {
      console.error('Error fetching initial data:', error);
      toast.error('Failed to load editor data');
    }
  };

  const fetchMediaFiles = async () => {
    try {
      const { data, error } = await supabase
        .from('blog_media')
        .select('*')
        .order('created_at', { ascending: false })
        .limit(50);

      if (error) throw error;
      setMediaFiles(data || []);
    } catch (error) {
      console.error('Error fetching media files:', error);
      toast.error('Failed to load media files');
    }
  };

  const fetchPollsAndQnas = async () => {
    if (!id) return;
    
    try {
      const [pollsRes, qnasRes] = await Promise.all([
        supabase.from('blog_polls').select('*').eq('post_id', id).order('position'),
        supabase.from('blog_qna').select('*').eq('post_id', id).order('position')
      ]);

      setPolls((pollsRes.data as Poll[]) || []);
      setQnas((qnasRes.data as QnA[]) || []);
    } catch (error) {
      console.error('Error fetching polls and Q&As:', error);
      toast.error('Failed to load interactive content');
    }
  };

  const fetchPost = async () => {
    if (!id) return;

    try {
      const { data: postData, error } = await supabase
        .from('blog_posts')
        .select(`
          *,
          blog_post_tags(
            tag:blog_tags(id, name, slug)
          )
        `)
        .eq('id', id)
        .single();

      if (error) throw error;

      const tags = postData.blog_post_tags?.map((pt: any) => pt.tag.id) || [];

      setPost({
        ...postData,
        tags,
        publish_at: postData.publish_at || '',
        status: postData.status as 'draft' | 'published' | 'scheduled'
      });
    } catch (error) {
      console.error('Error fetching post:', error);
      toast.error('Failed to load post');
      navigate('/admin/content/blog/posts');
    }
  };

  const generateSlug = (title: string) => {
    return title
      .toLowerCase()
      .replace(/[^a-z0-9 -]/g, '')
      .replace(/\s+/g, '-')
      .replace(/-+/g, '-')
      .trim();
  };

  const calculateReadingTime = (content: string) => {
    const wordsPerMinute = 200;
    const words = content.trim().split(/\s+/).length;
    return Math.ceil(words / wordsPerMinute);
  };

  const handleTitleChange = (title: string) => {
    setPost(prev => ({
      ...prev,
      title,
      slug: prev.slug || generateSlug(title),
      meta_title: prev.meta_title || title,
      og_title: prev.og_title || title
    }));
  };

  const handleBodyChange = (body_md: string) => {
    const readingTime = calculateReadingTime(body_md);
    setPost(prev => ({
      ...prev,
      body_md,
      reading_time: readingTime
    }));
  };

  const validateImage = (file: File, img: HTMLImageElement) => {
    const warnings: string[] = [];
    const optimalWidth = 1200;
    const optimalHeight = 630;
    const maxFileSize = 2 * 1024 * 1024; // 2MB
    const aspectRatio = img.width / img.height;
    const optimalAspectRatio = optimalWidth / optimalHeight; // 1.904
    
    // Check file size
    if (file.size > maxFileSize) {
      warnings.push(`File size (${(file.size / 1024 / 1024).toFixed(1)}MB) exceeds recommended 2MB`);
    }
    
    // Check dimensions
    if (img.width < 1000 || img.height < 500) {
      warnings.push("Image resolution too low. Minimum 1000x500px recommended for quality");
    }
    
    // Check aspect ratio
    if (Math.abs(aspectRatio - optimalAspectRatio) > 0.2) {
      warnings.push("Consider 16:9 aspect ratio (1200x630px) for optimal social media display");
    }
    
    // Check format
    if (!['image/jpeg', 'image/jpg', 'image/png', 'image/webp'].includes(file.type)) {
      warnings.push("Use JPG, PNG, or WebP format for best compatibility");
    }
    
    return {
      isValid: warnings.length === 0,
      warnings,
      specs: {
        width: img.width,
        height: img.height,
        size: file.size,
        format: file.type
      }
    };
  };

  const handleImageUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    // Reset validation
    setImageValidation({ isValid: true, warnings: [] });
    
    setUploadingImage(true);
    try {
      const fileExt = file.name.split('.').pop();
      const fileName = `${Date.now()}.${fileExt}`;
      const filePath = `images/${new Date().getFullYear()}/${String(new Date().getMonth() + 1).padStart(2, '0')}/${fileName}`;

      const { error: uploadError } = await supabase.storage
        .from('blog-media')
        .upload(filePath, file);

      if (uploadError) throw uploadError;

      const { data: { publicUrl } } = supabase.storage
        .from('blog-media')
        .getPublicUrl(filePath);

      // Create image info and validate
      const img = document.createElement('img');
      img.onload = async () => {
        try {
          // Validate image
          const validation = validateImage(file, img);
          setImageValidation(validation);
          
          // Save to media database
          const { error: dbError } = await supabase
            .from('blog_media')
            .insert({
              url: publicUrl,
              alt: file.name.replace(/\.[^/.]+$/, ""),
              file_size: file.size,
              width: img.width,
              height: img.height,
              mime_type: file.type
            });

          if (dbError) throw dbError;
          
          // Show appropriate message
          if (validation.isValid) {
            toast.success('Perfect! Image uploaded with optimal specs');
          } else {
            toast.success('Image uploaded successfully', {
              description: `${validation.warnings.length} recommendations available`
            });
          }
        } catch (error) {
          console.error('Error saving image to database:', error);
          toast.error('Failed to save image info');
        }
      };
      img.src = publicUrl;

      // If it's for cover, set it
      if (event.target.id === 'cover-upload') {
        setPost(prev => ({ ...prev, cover_url: publicUrl }));
      }
    } catch (error) {
      console.error('Error uploading image:', error);
      toast.error('Failed to upload image');
    } finally {
      setUploadingImage(false);
    }
  };

  // Text selection handlers
  const handleTextSelect = () => {
    if (textareaRef.current) {
      const textarea = textareaRef.current;
      const start = textarea.selectionStart;
      const end = textarea.selectionEnd;
      const text = textarea.value.substring(start, end);
      
      setSelectedText(text);
      setCursorPosition({ start, end });
    }
  };

  // Rich text formatting functions
  const insertTextAtCursor = (beforeText: string, afterText: string = '', replaceSelection: boolean = true) => {
    if (!textareaRef.current) return;
    
    const textarea = textareaRef.current;
    const start = textarea.selectionStart;
    const end = textarea.selectionEnd;
    const currentText = textarea.value;
    
    let newText;
    let newCursorPos;
    
    if (replaceSelection && start !== end) {
      // Replace selected text
      newText = currentText.substring(0, start) + beforeText + currentText.substring(start, end) + afterText + currentText.substring(end);
      newCursorPos = start + beforeText.length + (end - start) + afterText.length;
    } else {
      // Insert at cursor
      newText = currentText.substring(0, start) + beforeText + afterText + currentText.substring(end);
      newCursorPos = start + beforeText.length;
    }
    
    handleBodyChange(newText);
    
    // Set cursor position
    setTimeout(() => {
      textarea.focus();
      textarea.setSelectionRange(newCursorPos, newCursorPos);
    }, 0);
  };

  const formatBold = () => insertTextAtCursor('**', '**');
  const formatItalic = () => insertTextAtCursor('*', '*');
  const formatUnderline = () => insertTextAtCursor('<u>', '</u>');
  const formatStrikethrough = () => insertTextAtCursor('~~', '~~');
  const formatCode = () => insertTextAtCursor('`', '`');
  const formatHeading1 = () => insertTextAtCursor('# ', '');
  const formatHeading2 = () => insertTextAtCursor('## ', '');
  const formatHeading3 = () => insertTextAtCursor('### ', '');
  const formatQuote = () => insertTextAtCursor('> ', '');
  const formatList = () => insertTextAtCursor('- ', '');
  const formatOrderedList = () => insertTextAtCursor('1. ', '');
  const formatUppercase = () => {
    if (selectedText) {
      const upperText = selectedText.toUpperCase();
      const textarea = textareaRef.current!;
      const start = textarea.selectionStart;
      const end = textarea.selectionEnd;
      const newText = textarea.value.substring(0, start) + upperText + textarea.value.substring(end);
      handleBodyChange(newText);
    }
  };

  const insertLink = () => {
    const url = prompt('Enter URL:');
    if (url) {
      const linkText = selectedText || 'link text';
      insertTextAtCursor(`[${linkText}](${url})`);
    }
  };

  const insertImageFromMedia = (mediaFile: MediaFile) => {
    const altText = mediaFile.alt || 'Image';
    insertTextAtCursor(`![${altText}](${mediaFile.url})`);
    setShowMediaLibrary(false);
  };

  const insertPoll = (pollId: string) => {
    insertTextAtCursor(`[POLL:${pollId}]`);
  };

  const insertQna = (qnaId: string) => {
    insertTextAtCursor(`[QNA:${qnaId}]`);
  };

  const savePoll = async (pollData: Omit<Poll, 'id'>) => {
    if (!id && !isEditing) {
      toast.error('Please save the post first before adding polls');
      return;
    }

    try {
      const saveData = {
        ...pollData,
        post_id: id,
        options_json: pollData.options_json
      };

      if (editingPoll?.id) {
        const { error } = await supabase
          .from('blog_polls')
          .update(saveData)
          .eq('id', editingPoll.id);
        
        if (error) throw error;
        toast.success('Poll updated');
      } else {
        const { data, error } = await supabase
          .from('blog_polls')
          .insert(saveData)
          .select('id')
          .single();
        
        if (error) throw error;
        toast.success('Poll created');
        
        if (data) {
          insertPoll(data.id);
        }
      }
      
      await fetchPollsAndQnas();
      setShowPollDialog(false);
      setEditingPoll(null);
    } catch (error) {
      console.error('Error saving poll:', error);
      toast.error('Failed to save poll');
    }
  };

  const saveQna = async (qnaData: Omit<QnA, 'id'>) => {
    if (!id && !isEditing) {
      toast.error('Please save the post first before adding Q&A');
      return;
    }

    try {
      const saveData = {
        ...qnaData,
        post_id: id
      };

      if (editingQna?.id) {
        const { error } = await supabase
          .from('blog_qna')
          .update(saveData)
          .eq('id', editingQna.id);
        
        if (error) throw error;
        toast.success('Q&A updated');
      } else {
        const { data, error } = await supabase
          .from('blog_qna')
          .insert(saveData)
          .select('id')
          .single();
        
        if (error) throw error;
        toast.success('Q&A created');
        
        if (data) {
          insertQna(data.id);
        }
      }
      
      await fetchPollsAndQnas();
      setShowQnaDialog(false);
      setEditingQna(null);
    } catch (error) {
      console.error('Error saving Q&A:', error);
      toast.error('Failed to save Q&A');
    }
  };

  const deletePoll = async (pollId: string) => {
    if (!confirm('Are you sure you want to delete this poll?')) return;
    
    try {
      const { error } = await supabase
        .from('blog_polls')
        .delete()
        .eq('id', pollId);
      
      if (error) throw error;
      toast.success('Poll deleted');
      await fetchPollsAndQnas();
    } catch (error) {
      console.error('Error deleting poll:', error);
      toast.error('Failed to delete poll');
    }
  };

  const deleteQna = async (qnaId: string) => {
    if (!confirm('Are you sure you want to delete this Q&A?')) return;
    
    try {
      const { error } = await supabase
        .from('blog_qna')
        .delete()
        .eq('id', qnaId);
      
      if (error) throw error;
      toast.success('Q&A deleted');
      await fetchPollsAndQnas();
    } catch (error) {
      console.error('Error deleting Q&A:', error);
      toast.error('Failed to delete Q&A');
    }
  };

  const deleteMediaFile = async (mediaFile: MediaFile) => {
    if (!confirm('Are you sure you want to delete this media file?')) return;
    
    try {
      // Delete from storage
      const urlParts = mediaFile.url.split('/');
      const pathParts = urlParts.slice(-4); // Get last 4 parts (images/year/month/filename)
      const filePath = pathParts.join('/');
      
      await supabase.storage.from('blog-media').remove([filePath]);
      
      // Delete from database
      const { error } = await supabase
        .from('blog_media')
        .delete()
        .eq('id', mediaFile.id);
      
      if (error) throw error;
      toast.success('Media file deleted');
    } catch (error) {
      console.error('Error deleting media file:', error);
      toast.error('Failed to delete media file');
    }
  };

  const addTag = async () => {
    if (!newTag.trim()) return;

    try {
      const slug = generateSlug(newTag);
      
      // Check if tag exists
      let { data: existingTag } = await supabase
        .from('blog_tags')
        .select('id')
        .eq('slug', slug)
        .single();

      let tagId = existingTag?.id;

      // Create tag if it doesn't exist
      if (!existingTag) {
        const { data: newTagData, error } = await supabase
          .from('blog_tags')
          .insert({ name: newTag.trim(), slug })
          .select('id')
          .single();

        if (error) throw error;
        tagId = newTagData.id;

        // Add to available tags
        setAvailableTags(prev => [...prev, { id: tagId, name: newTag.trim(), slug }]);
      }

      // Add to post tags
      if (tagId && !post.tags.includes(tagId)) {
        setPost(prev => ({ ...prev, tags: [...prev.tags, tagId] }));
      }

      setNewTag('');
    } catch (error) {
      console.error('Error adding tag:', error);
      toast.error('Failed to add tag');
    }
  };

  const removeTag = (tagId: string) => {
    setPost(prev => ({
      ...prev,
      tags: prev.tags.filter(t => t !== tagId)
    }));
  };

  const savePost = async (postData: BlogPost, isAutoSave = false) => {
    if (!postData.title.trim()) {
      if (!isAutoSave) toast.error('Title is required');
      return;
    }

    setSaving(true);
    try {
      // Exclude non-column fields (e.g., tags) from the upsert payload
      const { tags: _tags, ...postWithoutTags } = postData as any;
      const saveData = {
        ...postWithoutTags,
        slug: postWithoutTags.slug || generateSlug(postWithoutTags.title),
        publish_at:
          postWithoutTags.status === 'published' && !postWithoutTags.publish_at
            ? new Date().toISOString()
            : postWithoutTags.publish_at || null,
      };

      let currentPostId = id;

      if (isEditing) {
        const { error } = await supabase.from('blog_posts').update(saveData).eq('id', id);
        if (error) throw error;
      } else {
        // Insert and handle possible 204 No Content when RLS blocks returning rows
        const { data: newPost, error } = await supabase
          .from('blog_posts')
          .insert(saveData)
          .select('id')
          .maybeSingle();

        if (error && (error as any).code !== 'PGRST204') throw error;

        if (newPost?.id) {
          currentPostId = newPost.id;
          navigate(`/admin/content/blog/posts/${newPost.id}/edit`);
        } else {
          // Fallback: fetch by unique slug
          const { data: fetched, error: fetchError } = await supabase
            .from('blog_posts')
            .select('id')
            .eq('slug', saveData.slug)
            .order('created_at', { ascending: false })
            .limit(1)
            .maybeSingle();

          if (!fetchError && fetched?.id) {
            currentPostId = fetched.id;
            navigate(`/admin/content/blog/posts/${fetched.id}/edit`);
          }
        }
      }

      // Update tags for both new and existing posts
      if (currentPostId) {
        // Delete existing tags
        await supabase.from('blog_post_tags').delete().eq('post_id', currentPostId);
        
        // Insert new tags
        if (postData.tags.length > 0) {
          const { error: tagsError } = await supabase
            .from('blog_post_tags')
            .insert(postData.tags.map(tagId => ({ 
              post_id: currentPostId, 
              tag_id: tagId 
            })));
          
          if (tagsError) {
            console.error('Error saving tags:', tagsError);
          }
        }
      }

      if (!isAutoSave) {
        toast.success(isEditing ? 'Post updated successfully' : 'Post created successfully');
      }
    } catch (error) {
      console.error('Error saving post:', error);
      if (!isAutoSave) {
        toast.error(`Failed to save post: ${error.message || 'Unknown error'}`);
      }
    } finally {
      setSaving(false);
    }
  };
  // Quick status actions
  const quickSetStatus = async (status: 'draft' | 'published' | 'scheduled') => {
    const nowIso = new Date().toISOString();
    let updated: BlogPost = { ...post } as BlogPost;

    if (status === 'published') {
      updated = { ...updated, status: 'published', publish_at: nowIso } as BlogPost;
    } else if (status === 'draft') {
      updated = { ...updated, status: 'draft', publish_at: '' } as BlogPost;
    } else if (status === 'scheduled') {
      const scheduledAt = updated.publish_at && updated.publish_at !== '' 
        ? updated.publish_at 
        : new Date(Date.now() + 10 * 60 * 1000).toISOString(); // +10 min default
      updated = { ...updated, status: 'scheduled', publish_at: scheduledAt } as BlogPost;
    }

    setPost(updated);
    await savePost(updated);
    
    // Redirect to all posts after publishing
    if (status === 'published') {
      navigate('/admin/content/blog/posts');
    }
  };

  const renderMarkdownPreview = (markdown: string) => {
    // Process interactive content
    let processedMarkdown = markdown
      .replace(/\[POLL:([^\]]+)\]/g, '<div data-poll-id="$1" class="poll-placeholder">📊 Interactive Poll</div>')
      .replace(/\[QNA:([^\]]+)\]/g, '<div data-qna-id="$1" class="qna-placeholder">❓ Q&A Section</div>');
    
    // Simple markdown rendering
    return processedMarkdown
      .replace(/^# (.*$)/gim, '<h1 class="text-3xl font-bold mb-4 mt-8 first:mt-0">$1</h1>')
      .replace(/^## (.*$)/gim, '<h2 class="text-2xl font-semibold mb-3 mt-6">$1</h2>')
      .replace(/^### (.*$)/gim, '<h3 class="text-xl font-medium mb-2 mt-4">$1</h3>')
      .replace(/\*\*(.*)\*\*/gim, '<strong class="font-semibold">$1</strong>')
      .replace(/\*(.*)\*/gim, '<em class="italic">$1</em>')
      .replace(/^\* (.*$)/gim, '<li class="ml-4">$1</li>')
      .replace(/\n\n/g, '</p><p class="mb-4">')
      .replace(/^/, '<p class="mb-4">')
      .replace(/$/, '</p>');
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <Button 
            variant="ghost" 
            onClick={() => navigate('/admin/content/blog/posts')}
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back to Posts
          </Button>
          <div>
            <h1 className="text-3xl font-bold text-foreground">
              {isEditing ? 'Edit Post' : 'New Post'}
            </h1>
            {isEditing && (
              <p className="text-muted-foreground">ID: {id}</p>
            )}
          </div>
        </div>

        <div className="flex items-center gap-2 flex-wrap justify-end">
          <Button
            variant="outline"
            onClick={() => setPreviewMode(!previewMode)}
          >
            <Eye className="w-4 h-4 mr-2" />
            {previewMode ? 'Edit' : 'Preview'}
          </Button>

          <Button
            variant="outline"
            onClick={() => quickSetStatus('draft')}
            disabled={saving || !post.title.trim()}
            title="Save as Draft"
          >
            Draft
          </Button>

          <Button
            variant="outline"
            onClick={() => quickSetStatus('scheduled')}
            disabled={saving || !post.title.trim()}
            title="Schedule Publish"
          >
            Schedule
          </Button>

          <Button 
            onClick={() => quickSetStatus('published')} 
            disabled={saving || !post.title.trim()}
            title="Publish Now"
          >
            <Save className="w-4 h-4 mr-2" />
            {saving ? 'Saving...' : 'Publish Now'}
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Main Content */}
        <div className="lg:col-span-2 space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Content</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label htmlFor="title">Title *</Label>
                <Input
                  id="title"
                  value={post.title}
                  onChange={(e) => handleTitleChange(e.target.value)}
                  placeholder="Enter post title..."
                  className="text-lg font-semibold"
                />
              </div>

              <div>
                <Label htmlFor="slug">Slug</Label>
                <Input
                  id="slug"
                  value={post.slug}
                  onChange={(e) => setPost(prev => ({ ...prev, slug: e.target.value }))}
                  placeholder="post-slug"
                />
              </div>

              <div>
                <Label htmlFor="excerpt">Excerpt</Label>
                <Textarea
                  id="excerpt"
                  value={post.excerpt}
                  onChange={(e) => setPost(prev => ({ ...prev, excerpt: e.target.value }))}
                  placeholder="Brief description of the post..."
                  rows={3}
                />
              </div>

              {!previewMode ? (
                <div>
                  <Label htmlFor="body">Content *</Label>
                  
                  {/* Rich Text Toolbar */}
                  <div className="border rounded-t-md bg-muted/20 p-2 flex flex-wrap items-center gap-1">
                    <Button type="button" variant="ghost" size="sm" onClick={formatBold} title="Bold">
                      <Bold className="w-4 h-4" />
                    </Button>
                    <Button type="button" variant="ghost" size="sm" onClick={formatItalic} title="Italic">
                      <Italic className="w-4 h-4" />
                    </Button>
                    <Button type="button" variant="ghost" size="sm" onClick={formatUnderline} title="Underline">
                      <Underline className="w-4 h-4" />
                    </Button>
                    <Button type="button" variant="ghost" size="sm" onClick={formatStrikethrough} title="Strikethrough">
                      <Strikethrough className="w-4 h-4" />
                    </Button>
                    
                    <Separator orientation="vertical" className="h-6 mx-1" />
                    
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button type="button" variant="ghost" size="sm" title="Headings">
                          <Type className="w-4 h-4" />
                          <ChevronDown className="w-3 h-3 ml-1" />
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent>
                        <DropdownMenuItem onClick={formatHeading1}>
                          <Heading1 className="w-4 h-4 mr-2" />
                          Heading 1
                        </DropdownMenuItem>
                        <DropdownMenuItem onClick={formatHeading2}>
                          <Heading2 className="w-4 h-4 mr-2" />
                          Heading 2
                        </DropdownMenuItem>
                        <DropdownMenuItem onClick={formatHeading3}>
                          <Heading3 className="w-4 h-4 mr-2" />
                          Heading 3
                        </DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                    
                    <Button type="button" variant="ghost" size="sm" onClick={formatUppercase} title="UPPERCASE" disabled={!selectedText}>
                      <Type className="w-4 h-4" />
                    </Button>
                    
                    <Separator orientation="vertical" className="h-6 mx-1" />
                    
                    <Button type="button" variant="ghost" size="sm" onClick={formatList} title="Bullet List">
                      <List className="w-4 h-4" />
                    </Button>
                    <Button type="button" variant="ghost" size="sm" onClick={formatOrderedList} title="Numbered List">
                      <ListOrdered className="w-4 h-4" />
                    </Button>
                    <Button type="button" variant="ghost" size="sm" onClick={formatQuote} title="Quote">
                      <Quote className="w-4 h-4" />
                    </Button>
                    <Button type="button" variant="ghost" size="sm" onClick={formatCode} title="Code">
                      <Code className="w-4 h-4" />
                    </Button>
                    
                    <Separator orientation="vertical" className="h-6 mx-1" />
                    
                    <Button type="button" variant="ghost" size="sm" onClick={insertLink} title="Insert Link">
                      <Link className="w-4 h-4" />
                    </Button>
                    <Button type="button" variant="ghost" size="sm" onClick={() => setShowMediaLibrary(true)} title="Insert Image">
                      <Image className="w-4 h-4" />
                    </Button>
                    
                    <Separator orientation="vertical" className="h-6 mx-1" />
                    
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button type="button" variant="ghost" size="sm" title="Interactive Content">
                          <Plus className="w-4 h-4" />
                          <ChevronDown className="w-3 h-3 ml-1" />
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent>
                        <DropdownMenuItem onClick={() => setShowPollDialog(true)}>
                          📊 Add Poll
                        </DropdownMenuItem>
                        <DropdownMenuItem onClick={() => setShowQnaDialog(true)}>
                          ❓ Add Q&A Section
                        </DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </div>
                  
                  <Textarea
                    ref={textareaRef}
                    id="body"
                    value={post.body_md}
                    onChange={(e) => handleBodyChange(e.target.value)}
                    onSelect={handleTextSelect}
                    placeholder="Write your post content in Markdown..."
                    rows={20}
                    className="font-mono rounded-t-none"
                  />
                  <div className="text-sm text-muted-foreground mt-2">
                    <Clock className="w-3 h-3 inline mr-1" />
                    Estimated reading time: {post.reading_time} minutes
                  </div>
                </div>
              ) : (
                <div>
                  <Label>Preview</Label>
                  <div 
                    className="border rounded-md p-4 min-h-[400px] prose max-w-none"
                    dangerouslySetInnerHTML={{ 
                      __html: renderMarkdownPreview(post.body_md || 'No content yet...') 
                    }}
                  />
                </div>
              )}
            </CardContent>
          </Card>

          {/* SEO Settings */}
          <Card>
            <CardHeader>
              <CardTitle>SEO & Social</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label htmlFor="meta_title">Meta Title</Label>
                <Input
                  id="meta_title"
                  value={post.meta_title}
                  onChange={(e) => setPost(prev => ({ ...prev, meta_title: e.target.value }))}
                  placeholder="SEO title (defaults to post title)"
                />
              </div>

              <div>
                <Label htmlFor="meta_description">Meta Description</Label>
                <Textarea
                  id="meta_description"
                  value={post.meta_description}
                  onChange={(e) => setPost(prev => ({ ...prev, meta_description: e.target.value }))}
                  placeholder="SEO description..."
                  rows={2}
                />
              </div>

              <Separator />

              <div>
                <Label htmlFor="og_title">Open Graph Title</Label>
                <Input
                  id="og_title"
                  value={post.og_title}
                  onChange={(e) => setPost(prev => ({ ...prev, og_title: e.target.value }))}
                  placeholder="Social media title (defaults to post title)"
                />
              </div>

              <div>
                <Label htmlFor="og_description">Open Graph Description</Label>
                <Textarea
                  id="og_description"
                  value={post.og_description}
                  onChange={(e) => setPost(prev => ({ ...prev, og_description: e.target.value }))}
                  placeholder="Social media description..."
                  rows={2}
                />
              </div>

              <div>
                <Label htmlFor="canonical_url">Canonical URL</Label>
                <Input
                  id="canonical_url"
                  value={post.canonical_url}
                  onChange={(e) => setPost(prev => ({ ...prev, canonical_url: e.target.value }))}
                  placeholder="https://example.com/original-post"
                />
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Sidebar */}
        <div className="space-y-6">
          {/* Media Library Modal */}
          {showMediaLibrary && (
            <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
              <Card className="w-full max-w-4xl max-h-[80vh] overflow-hidden">
                <CardHeader className="flex flex-row items-center justify-between">
                  <CardTitle>Media Library</CardTitle>
                  <Button variant="ghost" size="sm" onClick={() => setShowMediaLibrary(false)}>
                    <X className="w-4 h-4" />
                  </Button>
                </CardHeader>
                <CardContent className="overflow-auto max-h-[60vh]">
                  <div className="mb-4">
                    <Label htmlFor="media-upload">Upload New Media</Label>
                    <Input
                      id="media-upload"
                      type="file"
                      accept="image/*"
                      onChange={handleImageUpload}
                      className="mt-2"
                    />
                  </div>
                  
                  <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
                    {mediaFiles.map((media) => (
                      <div key={media.id} className="relative group border rounded-lg overflow-hidden">
                        <img
                          src={media.url}
                          alt={media.alt || 'Media'}
                          className="w-full h-24 object-cover cursor-pointer hover:opacity-80"
                          onClick={() => insertImageFromMedia(media)}
                        />
                        <div className="absolute inset-0 bg-black/0 group-hover:bg-black/20 transition-colors flex items-center justify-center opacity-0 group-hover:opacity-100">
                          <div className="flex gap-1">
                            <Button
                              size="sm"
                              variant="secondary"
                              onClick={() => insertImageFromMedia(media)}
                            >
                              Insert
                            </Button>
                            <Button
                              size="sm"
                              variant="destructive"
                              onClick={() => deleteMediaFile(media)}
                            >
                              <Trash2 className="w-3 h-3" />
                            </Button>
                          </div>
                        </div>
                        <div className="p-2 text-xs text-muted-foreground">
                          <div className="truncate" title={media.alt}>{media.alt}</div>
                          {media.file_size && (
                            <div>{(media.file_size / 1024).toFixed(1)} KB</div>
                          )}
                          {media.width && media.height && (
                            <div>{media.width} × {media.height}</div>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                  
                  {mediaFiles.length === 0 && (
                    <div className="text-center text-muted-foreground py-8">
                      No media files found. Upload some images to get started.
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>
          )}
          {/* Publish Settings */}
          <Card>
            <CardHeader>
              <CardTitle>Publish</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label htmlFor="status">Status</Label>
                <select
                  id="status"
                  value={post.status}
                  onChange={(e) => setPost(prev => ({ 
                    ...prev, 
                    status: e.target.value as 'draft' | 'published' | 'scheduled'
                  }))}
                  className="w-full px-3 py-2 border border-input rounded-md bg-background"
                >
                  <option value="draft">Draft</option>
                  <option value="published">Published</option>
                  <option value="scheduled">Scheduled</option>
                </select>
              </div>

              {post.status === 'scheduled' && (
                <div>
                  <Label htmlFor="publish_at">Publish Date</Label>
                  <Input
                    id="publish_at"
                    type="datetime-local"
                    value={post.publish_at ? new Date(post.publish_at).toISOString().slice(0, 16) : ''}
                    onChange={(e) => setPost(prev => ({ 
                      ...prev, 
                      publish_at: e.target.value ? new Date(e.target.value).toISOString() : ''
                    }))}
                  />
                </div>
              )}

              <div className="flex items-center space-x-2">
                <Switch
                  id="featured"
                  checked={post.featured}
                  onCheckedChange={(checked) => setPost(prev => ({ ...prev, featured: checked }))}
                />
                <Label htmlFor="featured">Featured Post</Label>
              </div>
            </CardContent>
          </Card>

          {/* Categories & Tags */}
          <Card>
            <CardHeader>
              <CardTitle>Organization</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label htmlFor="category">Category</Label>
                <select
                  id="category"
                  value={post.category_id}
                  onChange={(e) => setPost(prev => ({ ...prev, category_id: e.target.value }))}
                  className="w-full px-3 py-2 border border-input rounded-md bg-background"
                >
                  <option value="">Select category</option>
                  {categories.map(category => (
                    <option key={category.id} value={category.id}>
                      {category.name}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <Label htmlFor="author">Author</Label>
                <select
                  id="author"
                  value={post.author_id}
                  onChange={(e) => setPost(prev => ({ ...prev, author_id: e.target.value }))}
                  className="w-full px-3 py-2 border border-input rounded-md bg-background"
                >
                  <option value="">Select author</option>
                  {authors.map(author => (
                    <option key={author.id} value={author.id}>
                      {author.name}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <Label>Tags</Label>
                <div className="flex flex-wrap gap-1 mb-2">
                  {post.tags.map(tagId => {
                    const tag = availableTags.find(t => t.id === tagId);
                    return tag ? (
                      <Badge key={tagId} variant="secondary" className="flex items-center gap-1">
                        {tag.name}
                        <button onClick={() => removeTag(tagId)}>
                          <X className="w-3 h-3" />
                        </button>
                      </Badge>
                    ) : null;
                  })}
                </div>
                <div className="flex gap-2">
                  <Input
                    value={newTag}
                    onChange={(e) => setNewTag(e.target.value)}
                    placeholder="Add new tag..."
                    onKeyPress={(e) => e.key === 'Enter' && addTag()}
                  />
                  <Button variant="outline" size="sm" onClick={addTag}>
                    <Plus className="w-4 h-4" />
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Featured Image */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Image className="w-5 h-5" />
                Featured Image
              </CardTitle>
              <div className="text-sm text-muted-foreground space-y-1">
                <p className="font-medium text-primary">📐 Optimal Size: 1200x630px (16:9 aspect ratio)</p>
                <p>🎯 Perfect for social media sharing (Facebook, Twitter, LinkedIn)</p>
                <p>📁 Formats: JPG, PNG, WebP | 📏 Max Size: 2MB | 📱 Min Size: 1000x500px</p>
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              {post.cover_url ? (
                <div className="space-y-3">
                  <img 
                    src={post.cover_url} 
                    alt="Cover" 
                    className="w-full aspect-video object-cover rounded-md border"
                  />
                  
                  {/* Image Specs Display */}
                  {imageValidation.specs && (
                    <div className="p-3 bg-muted rounded-md">
                      <div className="flex items-center justify-between text-sm">
                        <span className="font-medium">Current Image:</span>
                        <div className="flex items-center gap-4">
                          <span>{imageValidation.specs.width}×{imageValidation.specs.height}px</span>
                          <span>{(imageValidation.specs.size / 1024 / 1024).toFixed(1)}MB</span>
                          <span>{imageValidation.specs.format.split('/')[1].toUpperCase()}</span>
                          {imageValidation.isValid ? (
                            <Badge className="bg-green-100 text-green-700 border-green-200">✓ Optimal</Badge>
                          ) : (
                            <Badge variant="outline" className="border-yellow-500 text-yellow-700">
                              ⚠ {imageValidation.warnings.length} Issues
                            </Badge>
                          )}
                        </div>
                      </div>
                    </div>
                  )}
                  
                  {/* Validation Warnings */}
                  {imageValidation.warnings.length > 0 && (
                    <div className="p-3 border border-yellow-200 bg-yellow-50 rounded-md">
                      <div className="flex items-start gap-2">
                        <AlertTriangle className="w-4 h-4 text-yellow-600 mt-0.5" />
                        <div className="space-y-1">
                          <p className="text-sm font-medium text-yellow-800">Recommendations:</p>
                          {imageValidation.warnings.map((warning, index) => (
                            <p key={index} className="text-sm text-yellow-700">• {warning}</p>
                          ))}
                        </div>
                      </div>
                    </div>
                  )}
                  
                  <div className="flex gap-2">
                    <Button 
                      variant="outline" 
                      size="sm" 
                      className="flex-1"
                      onClick={() => {
                        setPost(prev => ({ ...prev, cover_url: '' }));
                        setImageValidation({ isValid: true, warnings: [] });
                      }}
                    >
                      <Trash2 className="w-4 h-4 mr-2" />
                      Remove Image
                    </Button>
                    <Button 
                      variant="outline" 
                      size="sm" 
                      onClick={() => document.getElementById('cover-upload')?.click()}
                      disabled={uploadingImage}
                    >
                      <Upload className="w-4 h-4 mr-2" />
                      Replace
                    </Button>
                  </div>
                </div>
              ) : (
                <div className="space-y-4">
                  <div className="border-2 border-dashed border-muted rounded-lg p-8 text-center space-y-4">
                    <div className="mx-auto w-12 h-12 bg-primary/10 rounded-full flex items-center justify-center">
                      <Image className="w-6 h-6 text-primary" />
                    </div>
                    <div>
                      <p className="text-lg font-medium">Upload Featured Image</p>
                      <p className="text-sm text-muted-foreground">
                        Best results with 1200×630px images in JPG, PNG, or WebP format
                      </p>
                    </div>
                    <input
                      type="file"
                      accept="image/jpeg,image/jpg,image/png,image/webp"
                      onChange={handleImageUpload}
                      className="hidden"
                      id="cover-upload"
                    />
                    <Button 
                      variant="outline" 
                      size="lg"
                      className="w-full"
                      onClick={() => document.getElementById('cover-upload')?.click()}
                      disabled={uploadingImage}
                    >
                      {uploadingImage ? (
                        <div className="flex items-center gap-2">
                          <div className="w-4 h-4 border-2 border-primary border-t-transparent rounded-full animate-spin" />
                          Uploading...
                        </div>
                      ) : (
                        <div className="flex items-center gap-2">
                          <Upload className="w-4 h-4" />
                          Choose Image
                        </div>
                      )}
                    </Button>
                  </div>
                  
                  {/* Quick Tips */}
                  <div className="grid grid-cols-2 gap-3">
                    <div className="p-3 bg-blue-50 border border-blue-200 rounded-md">
                      <div className="flex items-center gap-2 text-blue-700">
                        <Target className="w-4 h-4" />
                        <span className="text-sm font-medium">Perfect Size</span>
                      </div>
                      <p className="text-xs text-blue-600 mt-1">1200×630px</p>
                    </div>
                    <div className="p-3 bg-green-50 border border-green-200 rounded-md">
                      <div className="flex items-center gap-2 text-green-700">
                        <Download className="w-4 h-4" />
                        <span className="text-sm font-medium">File Size</span>
                      </div>
                      <p className="text-xs text-green-600 mt-1">Under 2MB</p>
                    </div>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Interactive Content Management */}
          {isEditing && (
            <Card>
              <CardHeader>
                <CardTitle>Interactive Content</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {/* Polls */}
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <Label>Polls ({polls.length})</Label>
                    <Button
                      type="button"
                      variant="outline"
                      size="sm"
                      onClick={() => {
                        setEditingPoll(null);
                        setShowPollDialog(true);
                      }}
                    >
                      <Plus className="w-3 h-3 mr-1" />
                      Add Poll
                    </Button>
                  </div>
                  
                  {polls.length > 0 ? (
                    <div className="space-y-2">
                      {polls.map((poll) => (
                        <div key={poll.id} className="flex items-center justify-between p-2 border rounded">
                          <div>
                            <div className="font-medium">{poll.title}</div>
                            <div className="text-sm text-muted-foreground">
                              {poll.options_json.length} options • {poll.poll_type} choice
                            </div>
                          </div>
                          <div className="flex gap-2">
                            <Button
                              type="button"
                              variant="ghost"
                              size="sm"
                              onClick={() => insertPoll(poll.id!)}
                            >
                              Insert
                            </Button>
                            <Button
                              type="button"
                              variant="ghost"
                              size="sm"
                              onClick={() => {
                                setEditingPoll(poll);
                                setShowPollDialog(true);
                              }}
                            >
                              Edit
                            </Button>
                            <Button
                              type="button"
                              variant="ghost"
                              size="sm"
                              onClick={() => deletePoll(poll.id!)}
                            >
                              <Trash2 className="w-3 h-3" />
                            </Button>
                          </div>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <p className="text-sm text-muted-foreground">No polls created yet</p>
                  )}
                </div>

                <Separator />

                {/* Q&A Sections */}
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <Label>Q&A Sections ({qnas.length})</Label>
                    <Button
                      type="button"
                      variant="outline"
                      size="sm"
                      onClick={() => {
                        setEditingQna(null);
                        setShowQnaDialog(true);
                      }}
                    >
                      <Plus className="w-3 h-3 mr-1" />
                      Add Q&A
                    </Button>
                  </div>
                  
                  {qnas.length > 0 ? (
                    <div className="space-y-2">
                      {qnas.map((qna) => (
                        <div key={qna.id} className="flex items-center justify-between p-2 border rounded">
                          <div>
                            <div className="font-medium">{qna.title}</div>
                            <div className="text-sm text-muted-foreground">
                              {qna.moderated ? 'Moderated' : 'Unmoderated'} • 
                              {qna.allow_anonymous ? ' Anonymous allowed' : ' Login required'}
                            </div>
                          </div>
                          <div className="flex gap-2">
                            <Button
                              type="button"
                              variant="ghost"
                              size="sm"
                              onClick={() => insertQna(qna.id!)}
                            >
                              Insert
                            </Button>
                            <Button
                              type="button"
                              variant="ghost"
                              size="sm"
                              onClick={() => {
                                setEditingQna(qna);
                                setShowQnaDialog(true);
                              }}
                            >
                              Edit
                            </Button>
                            <Button
                              type="button"
                              variant="ghost"
                              size="sm"
                              onClick={() => deleteQna(qna.id!)}
                            >
                              <Trash2 className="w-3 h-3" />
                            </Button>
                          </div>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <p className="text-sm text-muted-foreground">No Q&A sections created yet</p>
                  )}
                </div>
              </CardContent>
            </Card>
          )}
        </div>
      </div>

      {/* Poll Dialog */}
      <PollDialog
        open={showPollDialog}
        onOpenChange={setShowPollDialog}
        onSave={savePoll}
        poll={editingPoll}
      />

      {/* QnA Dialog */}
      <QnaDialog
        open={showQnaDialog}
        onOpenChange={setShowQnaDialog}
        onSave={saveQna}
        qna={editingQna}
      />
    </div>
  );
}