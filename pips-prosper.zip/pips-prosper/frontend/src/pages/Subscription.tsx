import { Navigation } from "@/components/Navigation";
import { SubscriptionManager } from "@/components/Subscription/SubscriptionManager";

const Subscription = () => {
  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-muted/5 to-primary/5">
      <Navigation />
      <main className="container mx-auto px-4 py-8">
        <div className="max-w-6xl mx-auto">
          <div className="mb-8 text-center">
            <div className="inline-flex items-center space-x-2 bg-success/10 border border-success/20 rounded-full px-4 py-2 mb-6">
              <span className="text-sm font-medium text-success">
                🎉 Everything is FREE Right Now!
              </span>
            </div>
            <h1 className="text-3xl font-bold tracking-tight mb-4">
              Current: <span className="text-success">100% FREE</span> • Future: Premium Plans
            </h1>
            <p className="text-muted-foreground max-w-3xl mx-auto leading-relaxed">
              We're building the ultimate trading platform. While we develop premium features like 
              Auto Trade Sync, enjoy complete access to everything - completely FREE!
            </p>
          </div>
          
          <div className="bg-gradient-to-r from-success/10 to-primary/10 border border-success/20 rounded-2xl p-6 sm:p-8 max-w-4xl mx-auto mb-8">
            <div className="text-center">
              <h2 className="text-xl sm:text-2xl font-bold text-success mb-4">
                🚀 What You Get FREE Right Now:
              </h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-left">
                <div className="space-y-2">
                  <div className="flex items-center gap-2">
                    <span className="text-success">✅</span>
                    <span className="text-sm">Unlimited trades & accounts</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="text-success">✅</span>
                    <span className="text-sm">Advanced analytics & AI insights</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="text-success">✅</span>
                    <span className="text-sm">MT4/MT5/cTrader imports</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="text-success">✅</span>
                    <span className="text-sm">Prop-firm readiness tracking</span>
                  </div>
                </div>
                <div className="space-y-2">
                  <div className="flex items-center gap-2">
                    <span className="text-success">✅</span>
                    <span className="text-sm">Psychology analysis</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="text-success">✅</span>
                    <span className="text-sm">Session analysis</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="text-success">✅</span>
                    <span className="text-sm">Priority support</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="text-warning">🚀</span>
                    <span className="text-sm">Auto Trade Sync (Coming Soon!)</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
          
          <SubscriptionManager />
          
          <div className="mt-12 text-center">
            <div className="bg-card/50 backdrop-blur-sm border rounded-2xl p-6 max-w-2xl mx-auto">
              <h3 className="text-lg font-bold mb-3">
                🤔 Why Everything FREE?
              </h3>
              <p className="text-muted-foreground text-sm leading-relaxed">
                We're passionate about helping traders succeed. While we develop game-changing features 
                like real-time Auto Trade Sync, we want you to experience the full power of our platform. 
                No restrictions, no limitations - just pure value for the trading community.
              </p>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
};

export default Subscription;