import { useEffect, useState } from "react";
import { useParams, useSearchParams } from "react-router-dom";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { TrendingUp, TrendingDown, BarChart3, DollarSign, Target, Activity, Lock } from "lucide-react";
import { SEOHead } from "@/components/SEOHead";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";

interface ShareData {
  shareLink: any;
  account: any;
  user: any;
  metrics: any;
  trades: any[];
}

export default function SharedMetrics() {
  const { token } = useParams<{ token: string }>();
  const [searchParams] = useSearchParams();
  const [data, setData] = useState<ShareData | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [requiresPasscode, setRequiresPasscode] = useState(false);
  const [passcode, setPasscode] = useState("");
  const [submittingPasscode, setSubmittingPasscode] = useState(false);

  const fetchData = async (passcodeParam?: string) => {
    if (!token) return;

    setLoading(true);
    try {
      const { data: result, error } = await supabase.functions.invoke('share-resolve', {
        body: { token, passcode: passcodeParam }
      });

      if (error) throw error;

      if (result?.success) {
        setData(result.data);
        setError(null);
        setRequiresPasscode(false);
        
        // Set up real-time subscription for metrics updates if data is loaded
        if (result.data?.shareLink) {
          setupRealtimeSubscription(result.data.shareLink);
        }
      } else {
        if (result?.requires_passcode) {
          setRequiresPasscode(true);
          setError(null);
        } else {
          throw new Error(result?.error || 'Failed to load shared metrics');
        }
      }
    } catch (err: any) {
      console.error('Error fetching shared data:', err);
      setError(err.message || 'Failed to load shared metrics');
    } finally {
      setLoading(false);
      setSubmittingPasscode(false);
    }
  };

  const setupRealtimeSubscription = (shareLink: any) => {
    // Subscribe to trades table for real-time updates
    const channel = supabase
      .channel('shared-metrics-realtime')
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'trades',
          filter: shareLink.account_id ? `account_id=eq.${shareLink.account_id}` : undefined
        },
        () => {
          // Refetch data when trades change
          fetchData();
        }
      )
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'accounts',
          filter: shareLink.account_id ? `id=eq.${shareLink.account_id}` : undefined
        },
        () => {
          // Refetch data when account changes
          fetchData();
        }
      )
      .subscribe();

    // Cleanup subscription
    return () => {
      supabase.removeChannel(channel);
    };
  };

  useEffect(() => {
    const passcodeFromUrl = searchParams.get('passcode');
    fetchData(passcodeFromUrl || undefined);

    // Cleanup function for real-time subscription
    let cleanupRealtime: (() => void) | undefined;

    return () => {
      if (cleanupRealtime) {
        cleanupRealtime();
      }
    };
  }, [token, searchParams]);

  const handlePasscodeSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubmittingPasscode(true);
    await fetchData(passcode);
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-background via-accent/5 to-secondary/10 flex items-center justify-center">
        <div className="text-center space-y-4">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto"></div>
          <p className="text-muted-foreground">Loading shared metrics...</p>
        </div>
      </div>
    );
  }

  if (requiresPasscode && !data) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-background via-accent/5 to-secondary/10 flex items-center justify-center p-4">
        <SEOHead 
          title="Protected Trading Metrics - PipTrackr"
          description="This trading metrics page is password protected."
          robots="noindex,nofollow"
        />
        
        <Card className="w-full max-w-md">
          <CardHeader className="text-center">
            <Lock className="h-8 w-8 mx-auto mb-2 text-muted-foreground" />
            <CardTitle>Protected Metrics</CardTitle>
            <CardDescription>
              This shared metrics page requires a passcode to view.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handlePasscodeSubmit} className="space-y-4">
              <Input
                type="password"
                placeholder="Enter passcode"
                value={passcode}
                onChange={(e) => setPasscode(e.target.value)}
                required
              />
              <Button type="submit" className="w-full" disabled={submittingPasscode}>
                {submittingPasscode ? "Verifying..." : "Access Metrics"}
              </Button>
            </form>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (error || !data) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-background via-accent/5 to-secondary/10 flex items-center justify-center p-4">
        <SEOHead 
          title="Shared Trading Metrics - PipTrackr"
          description="Trading metrics shared via PipTrackr."
          robots="noindex,nofollow"
        />
        
        <Card className="w-full max-w-md text-center">
          <CardHeader>
            <CardTitle>Link Unavailable</CardTitle>
            <CardDescription>
              {error || "This shared metrics link is invalid or has expired."}
            </CardDescription>
          </CardHeader>
        </Card>
      </div>
    );
  }

  const { metrics, user, account, shareLink, trades } = data;
  const permissions = shareLink.permissions || {};

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-accent/5 to-secondary/10">
      <SEOHead 
        title={`${user.display_name}'s Trading Metrics - PipTrackr`}
        description="Shared trading performance metrics and analytics."
        robots="noindex,nofollow"
        ogTitle={`${user.display_name}'s Trading Performance`}
        ogDescription="View shared trading metrics and performance analytics."
      />
      
      <div className="container max-w-6xl mx-auto p-4 py-8">
        {/* Header */}
        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold mb-2">{user.display_name}'s Trading Metrics</h1>
          <p className="text-muted-foreground">
            {shareLink.link_type === 'account' && account ? 
              `${account.nickname || account.name} • ${permissions.hide_brokers ? 'Hidden Broker' : account.broker_name}` :
              'Combined Account Performance'
            }
          </p>
          <div className="flex justify-center gap-2 mt-2">
            <Badge variant="secondary">Read-only</Badge>
            {shareLink.expires_at && (
              <Badge variant="outline">
                Expires {new Date(shareLink.expires_at).toLocaleDateString()}
              </Badge>
            )}
          </div>
        </div>

        {/* Metrics Cards */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium flex items-center gap-2">
                <BarChart3 className="h-4 w-4" />
                Total Trades
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{metrics.totalTrades}</div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium flex items-center gap-2">
                <Target className="h-4 w-4" />
                Win Rate
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-green-600">
                {metrics.winRate.toFixed(1)}%
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium flex items-center gap-2">
                <Activity className="h-4 w-4" />
                Profit Factor
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">
                {metrics.profitFactor.toFixed(2)}
              </div>
            </CardContent>
          </Card>

          {!permissions.mask_currency && (
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium flex items-center gap-2">
                  <DollarSign className="h-4 w-4" />
                  Net P&L
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className={`text-2xl font-bold ${metrics.totalPnL >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                  ${metrics.totalPnL.toFixed(2)}
                </div>
              </CardContent>
            </Card>
          )}
        </div>

        {/* Winning vs Losing Trades */}
        <div className="grid md:grid-cols-2 gap-6 mb-8">
          <Card>
            <CardHeader>
              <CardTitle className="text-lg flex items-center gap-2 text-green-600">
                <TrendingUp className="h-5 w-5" />
                Winning Trades
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-2">
              <div className="flex justify-between">
                <span>Count:</span>
                <span className="font-medium">{metrics.winningTrades}</span>
              </div>
              {!permissions.mask_currency && (
                <div className="flex justify-between">
                  <span>Gross Profit:</span>
                  <span className="font-medium text-green-600">+${metrics.grossProfit.toFixed(2)}</span>
                </div>
              )}
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-lg flex items-center gap-2 text-red-600">
                <TrendingDown className="h-5 w-5" />
                Losing Trades
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-2">
              <div className="flex justify-between">
                <span>Count:</span>
                <span className="font-medium">{metrics.losingTrades}</span>
              </div>
              {!permissions.mask_currency && (
                <div className="flex justify-between">
                  <span>Gross Loss:</span>
                  <span className="font-medium text-red-600">-${metrics.grossLoss.toFixed(2)}</span>
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Trades Table */}
        {permissions.include_trades && trades && trades.length > 0 && (
          <Card>
            <CardHeader>
              <CardTitle>Recent Trades</CardTitle>
              <CardDescription>
                Showing {Math.min(trades.length, 50)} most recent trades
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="border-b">
                      <th className="text-left p-2">Symbol</th>
                      <th className="text-left p-2">Type</th>
                      <th className="text-left p-2">Size</th>
                      <th className="text-left p-2">Entry</th>
                      <th className="text-left p-2">Exit</th>
                      <th className="text-left p-2">Duration</th>
                      {!permissions.mask_currency && <th className="text-left p-2">P&L</th>}
                      <th className="text-left p-2">Pips</th>
                    </tr>
                  </thead>
                  <tbody>
                    {trades.slice(0, 50).map((trade, index) => (
                      <tr key={index} className="border-b">
                        <td className="p-2 font-medium">{trade.symbol}</td>
                        <td className="p-2">
                          <Badge variant={trade.type === 'buy' ? 'default' : 'secondary'}>
                            {trade.type?.toUpperCase()}
                          </Badge>
                        </td>
                        <td className="p-2">{trade.lot_size}</td>
                        <td className="p-2">{trade.entry_price}</td>
                        <td className="p-2">{trade.exit_price || 'Open'}</td>
                        <td className="p-2">
                          {trade.closed_at ? 
                            `${Math.round((new Date(trade.closed_at).getTime() - new Date(trade.opened_at).getTime()) / (1000 * 60))}m` :
                            'Active'
                          }
                        </td>
                        {!permissions.mask_currency && (
                          <td className={`p-2 font-medium ${trade.pnl >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                            {trade.pnl ? `$${trade.pnl.toFixed(2)}` : '-'}
                          </td>
                        )}
                        <td className={`p-2 font-medium ${trade.pips >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                          {trade.pips ? `${trade.pips > 0 ? '+' : ''}${trade.pips.toFixed(1)}` : '-'}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Footer */}
        <div className="text-center mt-8 pt-4 border-t">
          <p className="text-sm text-muted-foreground">
            Powered by{" "}
            <a href="https://piptrakr.com" className="font-medium hover:underline">
              PipTrackr.com
            </a>{" "}
            • The Professional Trading Journal
          </p>
        </div>
      </div>
    </div>
  );
}