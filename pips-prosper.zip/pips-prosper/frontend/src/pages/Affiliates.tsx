import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { 
  Trophy, 
  DollarSign, 
  Users, 
  TrendingUp,
  Star,
  CheckCircle,
  ArrowRight,
  Zap,
  Shield,
  Clock
} from "lucide-react";
import { SEOHead } from "@/components/SEOHead";
import { Link } from "react-router-dom";

export default function Affiliates() {
  const [expandedFaq, setExpandedFaq] = useState<number | null>(null);

  const faqs = [
    {
      q: "How much can I earn as an affiliate?",
      a: "Our top affiliates earn $5,000+ monthly through our 30% recurring commission structure. Your earnings depend on the quality of traffic and conversions you generate."
    },
    {
      q: "When do I get paid?",
      a: "Commissions are paid monthly via bank transfer, PayPal, or crypto. There's a 14-day hold period for new conversions and a $100 minimum payout threshold."
    },
    {
      q: "What marketing materials do you provide?",
      a: "We provide banners, logos, email templates, landing page copy, and product mockups. All materials are brand-compliant and conversion-optimized."
    },
    {
      q: "How does the attribution work?",
      a: "We use 90-day cookie attribution with last-click priority. If a customer uses a promo code linked to your account, that takes precedence over cookies."
    },
    {
      q: "Can I promote on social media?",
      a: "Yes! Social media promotion is encouraged. We just ask that you follow our brand guidelines and avoid misleading claims about earnings or features."
    },
    {
      q: "Is there a minimum traffic requirement?",
      a: "No minimum traffic requirement. We welcome affiliates of all sizes, from individual traders to large financial websites and influencers."
    },
    {
      q: "How are commissions calculated?",
      a: "Percentage of net subscription revenue on paid invoices attributed to you. Discounts/taxes/refunds are excluded."
    },
    {
      q: "Do trials pay commissions?",
      a: "No, the first paid invoice triggers commission."
    },
    {
      q: "Can I use my own coupon?",
      a: "Yes—if a promotion code is mapped to you, it can override cookie attribution (when enabled by admin)."
    },
    {
      q: "Is self-referral allowed?",
      a: "No. Self-referrals and fraud are blocked and may lead to account termination."
    },
    {
      q: "What content is prohibited?",
      a: "Misleading claims, spam, brand-keyword bidding (without permission), trademark misuse, illegal activity."
    },
    {
      q: "What is the cookie window?",
      a: "90 days last-click."
    },
    {
      q: "How do refunds affect my commissions?",
      a: "Refunded invoices create a negative adjustment to reverse the commission."
    }
  ];

  return (
    <>
      <SEOHead 
        title="PipTrackr.com Affiliate Program - Earn 30% Recurring Commissions"
        description="Join the PipTrackr.com affiliate program and earn 30% recurring commissions on every referral. Get marketing materials, real-time tracking, and monthly payouts."
        keywords="affiliate program, trading affiliate, forex affiliate, recurring commissions, trading referrals"
      />
      
      <div className="min-h-screen bg-gradient-to-br from-background via-background to-muted/20">
        {/* Hero Section */}
        <section className="relative py-24 overflow-hidden">
          <div className="absolute inset-0 bg-gradient-to-r from-primary/5 via-transparent to-accent/5" />
          <div className="container mx-auto px-6 relative z-10">
            <div className="max-w-4xl mx-auto text-center">
              <Badge className="mb-6 bg-primary/10 text-primary hover:bg-primary/20">
                <Trophy className="h-4 w-4 mr-1" />
                #1 Trading Journal Affiliate Program
              </Badge>
              
              <h1 className="text-5xl md:text-6xl font-bold mb-6 bg-gradient-to-r from-foreground via-primary to-foreground bg-clip-text text-transparent">
                Earn 30% Recurring
                <span className="block">Commissions</span>
              </h1>
              
              <p className="text-xl text-muted-foreground mb-8 max-w-2xl mx-auto leading-relaxed">
                Partner with PipTrackr.com and earn substantial recurring income by promoting 
                the world's most advanced trading journal to your audience.
              </p>
              
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Button asChild size="lg" className="text-lg px-8">
                  <Link to="/affiliates/apply">
                    Apply Now <ArrowRight className="ml-2 h-5 w-5" />
                  </Link>
                </Button>
                <Button variant="outline" size="lg" className="text-lg px-8" asChild>
                  <Link to="/auth">
                    Sign In to Dashboard
                  </Link>
                </Button>
              </div>
            </div>
          </div>
        </section>

        {/* Stats Section */}
        <section className="py-16 bg-card/50">
          <div className="container mx-auto px-6">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
              <div className="text-center">
                <div className="text-3xl md:text-4xl font-bold text-primary mb-2">30%</div>
                <div className="text-sm text-muted-foreground">Recurring Commission</div>
              </div>
              <div className="text-center">
                <div className="text-3xl md:text-4xl font-bold text-primary mb-2">90</div>
                <div className="text-sm text-muted-foreground">Day Cookie Window</div>
              </div>
              <div className="text-center">
                <div className="text-3xl md:text-4xl font-bold text-primary mb-2">$100</div>
                <div className="text-sm text-muted-foreground">Minimum Payout</div>
              </div>
              <div className="text-center">
                <div className="text-3xl md:text-4xl font-bold text-primary mb-2">24h</div>
                <div className="text-sm text-muted-foreground">Approval Time</div>
              </div>
            </div>
          </div>
        </section>

        {/* Commission Structure */}
        <section className="py-20">
          <div className="container mx-auto px-6">
            <div className="text-center mb-16">
              <h2 className="text-4xl font-bold mb-4">Tiered Commission Structure</h2>
              <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
                Earn higher commissions as you grow. Our tiered system rewards top performers with increasing rates.
              </p>
            </div>

            <div className="grid md:grid-cols-3 gap-8 max-w-6xl mx-auto mb-12">
              {[
                { 
                  tier: "Tier 1", 
                  range: "1-50 referrals", 
                  rate: "10%", 
                  color: "border-l-blue-500",
                  bgColor: "bg-blue-50 dark:bg-blue-950/20"
                },
                { 
                  tier: "Tier 2", 
                  range: "51-200 referrals", 
                  rate: "15%", 
                  color: "border-l-primary",
                  bgColor: "bg-primary/5",
                  popular: true
                },
                { 
                  tier: "Tier 3", 
                  range: "201+ referrals", 
                  rate: "20%", 
                  color: "border-l-green-500",
                  bgColor: "bg-green-50 dark:bg-green-950/20"
                }
              ].map((tier) => (
                <Card key={tier.tier} className={`relative border-l-4 ${tier.color} ${tier.bgColor}`}>
                  {tier.popular && (
                    <div className="absolute -top-3 left-1/2 transform -translate-x-1/2">
                      <Badge className="bg-primary text-primary-foreground">
                        <Star className="h-3 w-3 mr-1" />
                        Most Achieved
                      </Badge>
                    </div>
                  )}
                  <CardHeader className="text-center pb-4">
                    <CardTitle className="text-2xl">{tier.tier}</CardTitle>
                    <div className="space-y-1">
                      <div className="text-3xl font-bold text-primary">{tier.rate}</div>
                      <div className="text-sm text-muted-foreground">recurring commission</div>
                    </div>
                  </CardHeader>
                  <CardContent className="text-center">
                    <div className="space-y-3">
                      <div className="font-medium">{tier.range}</div>
                      <div className="text-sm text-muted-foreground">
                        Approved paying customers
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>

            <div className="max-w-3xl mx-auto">
              <Card className="bg-muted/50">
                <CardContent className="p-8">
                  <h3 className="text-2xl font-bold mb-4 text-center">Example Monthly Earnings</h3>
                  <div className="grid md:grid-cols-3 gap-6">
                    {[
                      { plan: "Starter ($19/mo)", tier1: "$19", tier2: "$28.50", tier3: "$38" },
                      { plan: "Professional ($39/mo)", tier1: "$39", tier2: "$58.50", tier3: "$78" },
                      { plan: "Enterprise ($79/mo)", tier1: "$79", tier2: "$118.50", tier3: "$158" }
                    ].map((example) => (
                      <div key={example.plan} className="text-center space-y-2">
                        <div className="font-medium text-sm">{example.plan}</div>
                        <div className="space-y-1 text-sm">
                          <div>Tier 1: <span className="font-semibold">{example.tier1}</span></div>
                          <div>Tier 2: <span className="font-semibold text-primary">{example.tier2}</span></div>
                          <div>Tier 3: <span className="font-semibold text-green-600">{example.tier3}</span></div>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </section>

        {/* Benefits */}
        <section className="py-20 bg-muted/20">
          <div className="container mx-auto px-6">
            <div className="text-center mb-16">
              <h2 className="text-4xl font-bold mb-4">Why Partner With PipTrackr.com?</h2>
              <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
                Everything you need to succeed as a PipTrackr.com affiliate
              </p>
            </div>

            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
              {[
                {
                  icon: <DollarSign className="h-8 w-8" />,
                  title: "High Converting Product",
                  description: "Industry-leading conversion rates with a product traders actually love and use daily."
                },
                {
                  icon: <Zap className="h-8 w-8" />,
                  title: "Recurring Revenue",
                  description: "Earn 30% recurring commissions for as long as your referrals remain active subscribers."
                },
                {
                  icon: <Users className="h-8 w-8" />,
                  title: "Dedicated Support",
                  description: "Personal affiliate manager, marketing materials, and priority support for your campaigns."
                },
                {
                  icon: <TrendingUp className="h-8 w-8" />,
                  title: "Real-Time Tracking",
                  description: "Advanced analytics dashboard with real-time conversion tracking and detailed reporting."
                },
                {
                  icon: <Shield className="h-8 w-8" />,
                  title: "Anti-Fraud Protection",
                  description: "Sophisticated fraud detection ensures you get credited for legitimate referrals only."
                },
                {
                  icon: <Clock className="h-8 w-8" />,
                  title: "Fast Approval",
                  description: "Get approved within 24 hours and start earning immediately with our streamlined process."
                }
              ].map((benefit) => (
                <Card key={benefit.title} className="h-full">
                  <CardHeader>
                    <div className="text-primary mb-4">{benefit.icon}</div>
                    <CardTitle>{benefit.title}</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <CardDescription className="text-base leading-relaxed">
                      {benefit.description}
                    </CardDescription>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </section>

        {/* FAQ */}
        <section className="py-20">
          <div className="container mx-auto px-6">
            <div className="text-center mb-16">
              <h2 className="text-4xl font-bold mb-4">Frequently Asked Questions</h2>
              <p className="text-xl text-muted-foreground">
                Everything you need to know about our affiliate program
              </p>
            </div>

            <div className="max-w-3xl mx-auto space-y-4">
              {faqs.map((faq, index) => (
                <Card key={index} className="cursor-pointer" onClick={() => setExpandedFaq(expandedFaq === index ? null : index)}>
                  <CardHeader className="pb-3">
                    <div className="flex items-center justify-between">
                      <CardTitle className="text-lg">{faq.q}</CardTitle>
                      <CheckCircle className={`h-5 w-5 transition-transform ${expandedFaq === index ? 'rotate-180' : ''}`} />
                    </div>
                  </CardHeader>
                  {expandedFaq === index && (
                    <CardContent className="pt-0">
                      <CardDescription className="text-base leading-relaxed">
                        {faq.a}
                      </CardDescription>
                    </CardContent>
                  )}
                </Card>
              ))}
            </div>
          </div>
        </section>

        {/* CTA */}
        <section className="py-20 bg-primary/5">
          <div className="container mx-auto px-6">
            <div className="max-w-4xl mx-auto text-center">
              <h2 className="text-4xl font-bold mb-6">Ready to Start Earning?</h2>
              <p className="text-xl text-muted-foreground mb-8 leading-relaxed">
                Join hundreds of successful affiliates who are earning substantial recurring income 
                by promoting PipTrackr.com to traders worldwide.
              </p>
              
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Button asChild size="lg" className="text-lg px-8">
                  <Link to="/affiliates/apply">
                    Apply Now - It's Free <ArrowRight className="ml-2 h-5 w-5" />
                  </Link>
                </Button>
              </div>
              
              <p className="text-sm text-muted-foreground mt-6">
                By applying, you agree to our <Link to="/affiliates/terms" className="text-primary hover:underline">Affiliate Terms</Link>, 
                <Link to="/terms" className="text-primary hover:underline ml-1">Terms of Service</Link> and 
                <Link to="/privacy" className="text-primary hover:underline ml-1">Privacy Policy</Link>
              </p>
            </div>
          </div>
        </section>
      </div>
    </>
  );
}