import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { SEOHead } from "@/components/SEOHead";
import { Plus, Building, Trash2, Edit, DollarSign, Settings2 } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter } from "@/components/ui/dialog";
import { Checkbox } from "@/components/ui/checkbox";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/components/ui/use-toast";
import { useAccountsRealtime } from "@/hooks/useRealtime";

export default function AppAccounts() {
  const [accounts, setAccounts] = useState<any[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [editingAccount, setEditingAccount] = useState<any>(null);
  const { user } = useAuth();
  const { toast } = useToast();

  // Form state
  const [formData, setFormData] = useState({
    account_type: "broker",
    broker_name: "",
    nickname: "",
    currency: "USD",
    account_size: "",
    risk_preference: "1.0",
    allowed_instruments: {
      forex: true,
      crypto: true,
      indices: true,
      oil: true,
      metals: true
    }
  });

  // Load accounts
  const loadAccounts = async () => {
    if (!user) return;
    
    const { data, error } = await supabase
      .from('accounts')
      .select('*')
      .eq('user_id', user.id)
      .eq('archived', false)
      .order('created_at', { ascending: false });
    
    if (error) {
      console.error('Error loading accounts:', error);
      toast({
        title: "Error loading accounts",
        description: error.message,
        variant: "destructive",
      });
    } else {
      setAccounts(data || []);
    }
  };

  useEffect(() => {
    loadAccounts();
  }, [user]);

  // Real-time updates
  useAccountsRealtime(
    () => loadAccounts(),
    () => loadAccounts(),
    () => loadAccounts()
  );

  // Reset form
  const resetForm = () => {
    setFormData({
      account_type: "broker",
      broker_name: "",
      nickname: "",
      currency: "USD",
      account_size: "",
      risk_preference: "1.0",
      allowed_instruments: {
        forex: true,
        crypto: true,
        indices: true,
        oil: true,
        metals: true
      }
    });
    setEditingAccount(null);
  };

  // Handle form submission
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) return;

    // Validate required fields
    if (!formData.nickname.trim() || !formData.broker_name.trim()) {
      toast({
        title: "Validation Error",
        description: "Nickname and Broker/Prop Firm Name are required",
        variant: "destructive",
      });
      return;
    }

    setIsLoading(true);

    const accountData = {
      user_id: user.id,
      account_type: formData.account_type,
      broker_name: formData.broker_name,
      nickname: formData.nickname,
      currency: formData.currency,
      account_size: formData.account_size ? parseFloat(formData.account_size) : null,
      risk_preference: parseFloat(formData.risk_preference),
      allowed_instruments: formData.allowed_instruments,
      name: formData.nickname, // Use nickname as name
      balance: 0,
      is_active: true
    };

    let error;
    if (editingAccount) {
      const { error: updateError } = await supabase
        .from('accounts')
        .update(accountData)
        .eq('id', editingAccount.id);
      error = updateError;
    } else {
      const { error: insertError } = await supabase
        .from('accounts')
        .insert([accountData]);
      error = insertError;
    }

    if (error) {
      console.error('Error saving account:', error);
      toast({
        title: "Error saving account",
        description: error.message,
        variant: "destructive",
      });
    } else {
      toast({
        title: editingAccount ? "Account updated" : "Account added",
        description: `${formData.nickname} has been ${editingAccount ? 'updated' : 'added'} successfully`,
      });
      setIsAddDialogOpen(false);
      resetForm();
      loadAccounts();
    }

    setIsLoading(false);
  };

  // Handle delete
  const handleDelete = async (accountId: string) => {
    if (!confirm("Are you sure you want to delete this account? This action cannot be undone.")) {
      return;
    }

    const { error } = await supabase
      .from('accounts')
      .update({ archived: true })
      .eq('id', accountId);

    if (error) {
      toast({
        title: "Error deleting account",
        description: error.message,
        variant: "destructive",
      });
    } else {
      toast({
        title: "Account deleted",
        description: "Account has been removed successfully",
      });
      loadAccounts();
    }
  };

  // Handle edit
  const handleEdit = (account: any) => {
    setEditingAccount(account);
    setFormData({
      account_type: account.account_type || "broker",
      broker_name: account.broker_name || "",
      nickname: account.nickname || "",
      currency: account.currency || "USD",
      account_size: account.account_size ? account.account_size.toString() : "",
      risk_preference: account.risk_preference ? account.risk_preference.toString() : "1.0",
      allowed_instruments: account.allowed_instruments || {
        forex: true,
        crypto: true,
        indices: true,
        oil: true,
        metals: true
      }
    });
    setIsAddDialogOpen(true);
  };

  return (
    <div className="space-y-6">
      <SEOHead 
        title="Trading Accounts - Pip Trackr.com"
        description="Manage your trading accounts and broker connections"
      />
      
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-poppins font-bold text-foreground">
            Trading Accounts
          </h1>
          <p className="text-muted-foreground mt-1">
            Manage your trading accounts from different brokers and prop firms
          </p>
        </div>
        
        <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
          <DialogTrigger asChild>
            <Button className="bg-primary hover:bg-primary-dark" onClick={resetForm}>
              <Plus className="h-4 w-4 mr-2" />
              Add Account
            </Button>
          </DialogTrigger>
          
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle>
                {editingAccount ? "Edit Account" : "Add New Account"}
              </DialogTitle>
            </DialogHeader>
            
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="account_type">Account Type</Label>
                  <Select
                    value={formData.account_type}
                    onValueChange={(value) => setFormData({...formData, account_type: value})}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="broker">Broker</SelectItem>
                      <SelectItem value="prop_firm">Prop Firm</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="broker_name">
                    {formData.account_type === "prop_firm" ? "Prop Firm Name" : "Broker Name"}
                  </Label>
                  <Input
                    value={formData.broker_name}
                    onChange={(e) => setFormData({...formData, broker_name: e.target.value})}
                    placeholder={formData.account_type === "prop_firm" ? "e.g., FTMO, MyForexFunds" : "e.g., IC Markets, XM"}
                    required
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="nickname">Nickname <span className="text-destructive">*</span></Label>
                  <Input
                    value={formData.nickname}
                    onChange={(e) => setFormData({...formData, nickname: e.target.value})}
                    placeholder="e.g., ICM-1, FTMO-100K"
                    required
                  />
                  <p className="text-xs text-muted-foreground">
                    Unique identifier for this account (used in dropdowns)
                  </p>
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="currency">Account Currency</Label>
                  <Select
                    value={formData.currency}
                    onValueChange={(value) => setFormData({...formData, currency: value})}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="USD">USD</SelectItem>
                      <SelectItem value="EUR">EUR</SelectItem>
                      <SelectItem value="GBP">GBP</SelectItem>
                      <SelectItem value="JPY">JPY</SelectItem>
                      <SelectItem value="CAD">CAD</SelectItem>
                      <SelectItem value="AUD">AUD</SelectItem>
                      <SelectItem value="CHF">CHF</SelectItem>
                      <SelectItem value="INR">INR</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="account_size">
                    Account Size ({formData.currency})
                  </Label>
                  <Input
                    type="number"
                    step="0.01"
                    value={formData.account_size}
                    onChange={(e) => setFormData({...formData, account_size: e.target.value})}
                    placeholder="10000"
                  />
                  <p className="text-xs text-muted-foreground">
                    {formData.account_type === "prop_firm" ? "Recommended for prop firms" : "Optional for brokers"}
                  </p>
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="risk_preference">Default Risk % per Trade</Label>
                  <Input
                    type="number"
                    step="0.1"
                    min="0.1"
                    max="10"
                    value={formData.risk_preference}
                    onChange={(e) => setFormData({...formData, risk_preference: e.target.value})}
                    placeholder="1.0"
                  />
                  <p className="text-xs text-muted-foreground">
                    Default risk percentage for position sizing
                  </p>
                </div>
              </div>
              
              <div className="space-y-2">
                <Label>Allowed Instruments</Label>
                <div className="grid grid-cols-2 md:grid-cols-5 gap-4 p-4 border rounded-lg">
                  {Object.entries(formData.allowed_instruments).map(([key, value]) => (
                    <div key={key} className="flex items-center space-x-2">
                      <Checkbox
                        id={key}
                        checked={value}
                        onCheckedChange={(checked) => 
                          setFormData({
                            ...formData, 
                            allowed_instruments: {
                              ...formData.allowed_instruments,
                              [key]: checked as boolean
                            }
                          })
                        }
                      />
                      <Label 
                        htmlFor={key} 
                        className="text-sm font-medium capitalize cursor-pointer"
                      >
                        {key}
                      </Label>
                    </div>
                  ))}
                </div>
                <p className="text-xs text-muted-foreground">
                  Select which instrument classes are available for this account
                </p>
              </div>
              
              <DialogFooter>
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => {
                    setIsAddDialogOpen(false);
                    resetForm();
                  }}
                >
                  Cancel
                </Button>
                <Button type="submit" disabled={isLoading}>
                  {isLoading ? "Saving..." : editingAccount ? "Update Account" : "Add Account"}
                </Button>
              </DialogFooter>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      {/* Accounts List */}
      <div className="space-y-4">
        {accounts.length === 0 ? (
          <Card className="p-8 text-center">
            <div className="flex flex-col items-center gap-3">
              <Building className="h-12 w-12 text-muted-foreground" />
              <div>
                <h3 className="font-semibold">No accounts yet</h3>
                <p className="text-sm text-muted-foreground">
                  Add your first trading account to get started
                </p>
              </div>
            </div>
          </Card>
        ) : (
          accounts.map((account) => (
            <Card key={account.id}>
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-4">
                    <div className="p-2 bg-primary/10 rounded-lg">
                      {account.account_type === "prop_firm" ? (
                        <Settings2 className="h-6 w-6 text-primary" />
                      ) : (
                        <Building className="h-6 w-6 text-primary" />
                      )}
                    </div>
                    <div>
                      <h3 className="font-semibold">{account.nickname}</h3>
                      <p className="text-sm text-muted-foreground">
                        {account.broker_name} • {account.currency}
                        {account.account_size && ` • ${new Intl.NumberFormat().format(account.account_size)}`}
                      </p>
                      <div className="flex gap-2 mt-1">
                        <Badge variant="outline" className="text-xs">
                          {account.account_type === "prop_firm" ? "Prop Firm" : "Broker"}
                        </Badge>
                        <Badge variant="outline" className="text-xs">
                          Manual
                        </Badge>
                      </div>
                    </div>
                  </div>
                  
                  <div className="flex items-center gap-3">
                    <div className="text-right text-sm">
                      <div className="font-medium flex items-center gap-1">
                        <DollarSign className="h-3 w-3" />
                        {new Intl.NumberFormat().format(account.balance || 0)} {account.currency}
                      </div>
                      <div className="text-muted-foreground text-xs">
                        Risk: {account.risk_preference || 1}% per trade
                      </div>
                    </div>
                    
                    <div className="flex gap-2">
                      <Button 
                        variant="outline" 
                        size="sm"
                        onClick={() => handleEdit(account)}
                      >
                        <Edit className="h-4 w-4" />
                      </Button>
                      <Button 
                        variant="outline" 
                        size="sm"
                        onClick={() => handleDelete(account.id)}
                      >
                        <Trash2 className="h-4 w-4 text-destructive" />
                      </Button>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))
        )}
      </div>
    </div>
  );
}