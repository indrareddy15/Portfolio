import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { SEOHead } from "@/components/SEOHead"
import { CreditCard, Download, Calendar, Crown, AlertTriangle } from "lucide-react"
import { Badge } from "@/components/ui/badge"
import { Separator } from "@/components/ui/separator"

const billingHistory = [
  {
    id: 1,
    date: "2024-01-15",
    amount: 29.99,
    plan: "Pro Monthly",
    status: "Paid",
    invoice: "INV-2024-001"
  },
  {
    id: 2,
    date: "2023-12-15", 
    amount: 29.99,
    plan: "Pro Monthly",
    status: "Paid",
    invoice: "INV-2023-012"
  },
  {
    id: 3,
    date: "2023-11-15",
    amount: 29.99,
    plan: "Pro Monthly", 
    status: "Paid",
    invoice: "INV-2023-011"
  }
]

export default function AppBilling() {
  return (
    <div className="space-y-6">
      <SEOHead 
        title="Billing & Subscription - PipTrackr.com"
        description="Manage your subscription and billing information"
      />
      
      <div>
        <h1 className="text-3xl font-poppins font-bold text-foreground">
          Billing & Subscription
        </h1>
        <p className="text-muted-foreground mt-1">
          Manage your subscription plan and billing information
        </p>
      </div>

      {/* Current Plan */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Crown className="h-5 w-5 text-warning" />
            Current Plan
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex items-start justify-between">
            <div className="space-y-2">
              <div className="flex items-center gap-2">
                <h3 className="text-xl font-semibold">Pro Plan</h3>
                <Badge className="bg-success">Active</Badge>
              </div>
              <p className="text-muted-foreground">
                Full access to all premium features including advanced analytics, unlimited trades, and priority support.
              </p>
              <div className="flex items-center gap-4 text-sm text-muted-foreground">
                <span>$29.99/month</span>
                <span>•</span>
                <span>Next billing: Feb 15, 2024</span>
              </div>
            </div>
            <div className="flex gap-2">
              <Button variant="outline">Change Plan</Button>
              <Button variant="outline" className="text-destructive">
                Cancel Plan
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Payment Method */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <CreditCard className="h-5 w-5 text-primary" />
            Payment Method
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex items-center justify-between p-4 border rounded-lg">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-primary/10 rounded-lg">
                <CreditCard className="h-6 w-6 text-primary" />
              </div>
              <div>
                <p className="font-medium">•••• •••• •••• 4242</p>
                <p className="text-sm text-muted-foreground">Expires 12/25</p>
              </div>
            </div>
            <div className="flex gap-2">
              <Button variant="outline" size="sm">Update</Button>
              <Button variant="outline" size="sm">Remove</Button>
            </div>
          </div>
          
          <div className="mt-4">
            <Button variant="outline" className="w-full">
              <CreditCard className="h-4 w-4 mr-2" />
              Add Payment Method
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Usage & Limits */}
      <Card>
        <CardHeader>
          <CardTitle>Usage & Limits</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="p-4 border rounded-lg text-center">
              <p className="text-2xl font-bold text-primary">1,247</p>
              <p className="text-sm text-muted-foreground">Trades This Month</p>
              <p className="text-xs text-success">Unlimited</p>
            </div>
            <div className="p-4 border rounded-lg text-center">
              <p className="text-2xl font-bold text-warning">89%</p>
              <p className="text-sm text-muted-foreground">API Calls Used</p>
              <p className="text-xs text-muted-foreground">8,900 / 10,000</p>
            </div>
            <div className="p-4 border rounded-lg text-center">
              <p className="text-2xl font-bold text-success">12</p>
              <p className="text-sm text-muted-foreground">Connected Accounts</p>
              <p className="text-xs text-success">Unlimited</p>
            </div>
          </div>
          
          <div className="p-4 bg-warning/10 border border-warning/20 rounded-lg flex items-start gap-3">
            <AlertTriangle className="h-5 w-5 text-warning flex-shrink-0 mt-0.5" />
            <div className="text-sm">
              <p className="font-medium text-warning">API Usage Warning</p>
              <p className="text-muted-foreground mt-1">
                You're approaching your API limit. Consider upgrading to avoid service interruption.
              </p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Billing History */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="flex items-center gap-2">
              <Calendar className="h-5 w-5 text-info" />
              Billing History
            </CardTitle>
            <Button variant="outline" size="sm">
              <Download className="h-4 w-4 mr-2" />
              Download All
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {billingHistory.map((item, index) => (
              <div key={item.id}>
                <div className="flex items-center justify-between">
                  <div>
                    <p className="font-medium">{item.plan}</p>
                    <p className="text-sm text-muted-foreground">
                      {new Date(item.date).toLocaleDateString()} • {item.invoice}
                    </p>
                  </div>
                  <div className="flex items-center gap-3">
                    <div className="text-right">
                      <p className="font-medium">${item.amount}</p>
                      <Badge 
                        variant={item.status === "Paid" ? "default" : "secondary"}
                        className={item.status === "Paid" ? "bg-success" : ""}
                      >
                        {item.status}
                      </Badge>
                    </div>
                    <Button variant="outline" size="sm">
                      <Download className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
                {index < billingHistory.length - 1 && <Separator className="mt-4" />}
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}