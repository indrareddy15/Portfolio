import { useEffect, useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { 
  Wallet, 
  CreditCard,
  DollarSign,
  Clock,
  CheckCircle,
  XCircle,
  AlertCircle,
  Download,
  RefreshCw,
  Shield,
  FileText
} from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { Skeleton } from "@/components/ui/skeleton";
import { toast } from "@/hooks/use-toast";

interface PayoutData {
  availableBalance: number;
  pendingBalance: number;
  totalEarned: number;
  totalPaid: number;
  nextPayoutDate?: string;
  minimumPayout: number;
}

interface PayoutRequest {
  id: string;
  amount: number;
  currency: string;
  method: string;
  status: string;
  reference?: string;
  created_at: string;
  updated_at: string;
  details_json: any;
}

export default function AffiliatePayouts() {
  const { user } = useAuth();
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [requesting, setRequesting] = useState(false);
  const [affiliate, setAffiliate] = useState<any>(null);
  const [payoutData, setPayoutData] = useState<PayoutData | null>(null);
  const [payoutHistory, setPayoutHistory] = useState<PayoutRequest[]>([]);
  const [kycData, setKycData] = useState<any>(null);
  const [contractData, setContractData] = useState<any>(null);

  const fetchPayoutData = async () => {
    if (!user) return;

    try {
      setLoading(true);

      // Get affiliate profile
      const { data: affiliateData, error: affiliateError } = await supabase
        .from("affiliates")
        .select("*")
        .eq("user_id", user.id)
        .single();

      if (affiliateError) throw affiliateError;
      setAffiliate(affiliateData);

      if (affiliateData.status !== 'active') {
        setLoading(false);
        return;
      }

      // Get commissions
      const { data: commissionsData, error: commissionsError } = await supabase
        .from("commissions")
        .select("*")
        .eq("affiliate_id", affiliateData.id);

      if (commissionsError) throw commissionsError;

      // Get payout history
      const { data: payoutsData, error: payoutsError } = await supabase
        .from("payouts")
        .select("*")
        .eq("affiliate_id", affiliateData.id)
        .order("created_at", { ascending: false });

      if (payoutsError) throw payoutsError;

      // Get KYC data
      const { data: kycResult } = await supabase
        .from("affiliate_kyc")
        .select("*")
        .eq("affiliate_id", affiliateData.id)
        .maybeSingle();

      // Get contract data
      const { data: contractResult } = await supabase
        .from("affiliate_contracts")
        .select("*")
        .eq("affiliate_id", affiliateData.id)
        .eq("contract_type", "standard")
        .eq("status", "signed")
        .maybeSingle();

      setKycData(kycResult);
      setContractData(contractResult);

      // Calculate balances
      const totalEarned = commissionsData?.reduce((sum, c) => sum + parseFloat(c.amount.toString()), 0) || 0;
      const pendingBalance = commissionsData?.filter(c => c.status === 'pending').reduce((sum, c) => sum + parseFloat(c.amount.toString()), 0) || 0;
      const approvedBalance = commissionsData?.filter(c => c.status === 'approved').reduce((sum, c) => sum + parseFloat(c.amount.toString()), 0) || 0;
      const totalPaid = payoutsData?.filter(p => p.status === 'paid').reduce((sum, p) => sum + parseFloat(p.amount.toString()), 0) || 0;

      // Find next payout date (earliest hold_until date)
      const nextPayoutCommission = commissionsData
        ?.filter(c => c.status === 'pending' && c.hold_until)
        ?.sort((a, b) => new Date(a.hold_until).getTime() - new Date(b.hold_until).getTime())[0];

      setPayoutData({
        availableBalance: approvedBalance,
        pendingBalance,
        totalEarned,
        totalPaid,
        nextPayoutDate: nextPayoutCommission?.hold_until,
        minimumPayout: 100 // $100 minimum
      });

      setPayoutHistory(payoutsData || []);

    } catch (error) {
      console.error('Error fetching payout data:', error);
      toast({
        title: "Error",
        description: "Failed to load payout data",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const handleRefresh = async () => {
    setRefreshing(true);
    await fetchPayoutData();
    setRefreshing(false);
    toast({
      title: "Refreshed",
      description: "Payout data has been updated"
    });
  };

  const requestPayout = async () => {
    if (!affiliate || !payoutData) return;

    try {
      setRequesting(true);

      const { error } = await supabase
        .from("payouts")
        .insert({
          affiliate_id: affiliate.id,
          amount: payoutData.availableBalance,
          currency: 'USD',
          method: 'bank', // Default method
          status: 'requested',
          details_json: {
            requested_at: new Date().toISOString(),
            requested_amount: payoutData.availableBalance
          }
        });

      if (error) throw error;

      toast({
        title: "Payout Requested",
        description: `$${payoutData.availableBalance.toFixed(2)} payout has been requested. You'll receive an email confirmation shortly.`
      });

      // Refresh data
      await fetchPayoutData();

    } catch (error) {
      console.error('Error requesting payout:', error);
      toast({
        title: "Error",
        description: "Failed to request payout. Please try again.",
        variant: "destructive"
      });
    } finally {
      setRequesting(false);
    }
  };

  useEffect(() => {
    fetchPayoutData();
  }, [user]);

  if (loading) {
    return (
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <Skeleton className="h-8 w-32 mb-2" />
            <Skeleton className="h-4 w-48" />
          </div>
          <Skeleton className="h-10 w-24" />
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {[...Array(3)].map((_, i) => (
            <Card key={i}>
              <CardHeader className="pb-2">
                <Skeleton className="h-4 w-20 mb-2" />
                <Skeleton className="h-8 w-16" />
              </CardHeader>
            </Card>
          ))}
        </div>
      </div>
    );
  }

  if (!affiliate || affiliate.status !== 'active') {
    return (
      <div className="max-w-2xl mx-auto text-center py-12">
        <Wallet className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
        <h2 className="text-2xl font-semibold mb-2">Payouts Unavailable</h2>
        <p className="text-muted-foreground">
          Your affiliate account must be active to access payout features.
        </p>
      </div>
    );
  }

  const canRequestPayout = payoutData && 
    payoutData.availableBalance >= payoutData.minimumPayout &&
    kycData?.status === 'approved' &&
    contractData?.status === 'signed';

  const isKycVerified = kycData?.status === 'approved';
  const isContractSigned = contractData?.status === 'signed';

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Payouts & Wallet</h1>
          <p className="text-muted-foreground">
            Manage your earnings and payout requests
          </p>
        </div>
        <Button 
          onClick={handleRefresh} 
          disabled={refreshing}
          variant="outline"
        >
          <RefreshCw className={`h-4 w-4 mr-2 ${refreshing ? 'animate-spin' : ''}`} />
          Refresh
        </Button>
      </div>

      {/* Wallet Overview */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Available Balance</CardTitle>
            <Wallet className="h-4 w-4 text-green-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">
              ${payoutData?.availableBalance.toFixed(2) || '0.00'}
            </div>
            <p className="text-xs text-muted-foreground">
              Ready for withdrawal
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Pending</CardTitle>
            <Clock className="h-4 w-4 text-amber-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-amber-600">
              ${payoutData?.pendingBalance.toFixed(2) || '0.00'}
            </div>
            <p className="text-xs text-muted-foreground">
              In hold period
              {payoutData?.nextPayoutDate && (
                <span className="block">
                  Next: {new Date(payoutData.nextPayoutDate).toLocaleDateString()}
                </span>
              )}
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Earned</CardTitle>
            <DollarSign className="h-4 w-4 text-primary" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              ${payoutData?.totalEarned.toFixed(2) || '0.00'}
            </div>
            <p className="text-xs text-muted-foreground">
              ${payoutData?.totalPaid.toFixed(2) || '0.00'} paid out
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Progress to Minimum Payout */}
      {payoutData && payoutData.availableBalance < payoutData.minimumPayout && (
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Progress to Minimum Payout</CardTitle>
            <CardDescription>
              You need ${payoutData.minimumPayout} minimum to request a payout
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              <div className="flex justify-between text-sm">
                <span>Current balance</span>
                <span>${payoutData.availableBalance.toFixed(2)} / ${payoutData.minimumPayout}</span>
              </div>
              <Progress 
                value={(payoutData.availableBalance / payoutData.minimumPayout) * 100} 
                className="h-2"
              />
              <p className="text-xs text-muted-foreground">
                ${(payoutData.minimumPayout - payoutData.availableBalance).toFixed(2)} more needed
              </p>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Requirements Check */}
      {payoutData && payoutData.availableBalance >= payoutData.minimumPayout && (!isKycVerified || !isContractSigned) && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <AlertCircle className="h-5 w-5 text-amber-600" />
              Complete Requirements for Payouts
            </CardTitle>
            <CardDescription>
              You need to complete the following steps before requesting payouts
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-3">
              <div className={`flex items-center justify-between p-3 rounded-lg ${
                isKycVerified ? 'bg-green-50 border border-green-200' : 'bg-amber-50 border border-amber-200'
              }`}>
                <div className="flex items-center gap-3">
                  <Shield className={`h-5 w-5 ${isKycVerified ? 'text-green-600' : 'text-amber-600'}`} />
                  <div>
                    <h4 className="font-medium">KYC Verification</h4>
                    <p className="text-sm text-muted-foreground">Identity verification required for payouts</p>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  {isKycVerified ? (
                    <CheckCircle className="h-5 w-5 text-green-600" />
                  ) : (
                    <Button asChild size="sm">
                      <a href="/app/affiliate/kyc">Complete KYC</a>
                    </Button>
                  )}
                </div>
              </div>

              <div className={`flex items-center justify-between p-3 rounded-lg ${
                isContractSigned ? 'bg-green-50 border border-green-200' : 'bg-amber-50 border border-amber-200'
              }`}>
                <div className="flex items-center gap-3">
                  <FileText className={`h-5 w-5 ${isContractSigned ? 'text-green-600' : 'text-amber-600'}`} />
                  <div>
                    <h4 className="font-medium">Affiliate Contract</h4>
                    <p className="text-sm text-muted-foreground">Signed agreement required for payouts</p>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  {isContractSigned ? (
                    <CheckCircle className="h-5 w-5 text-green-600" />
                  ) : (
                    <Button asChild size="sm">
                      <a href="/app/affiliate/contract">Sign Contract</a>
                    </Button>
                  )}
                </div>
              </div>
            </div>

            {!isKycVerified && !isContractSigned ? (
              <Alert>
                <AlertCircle className="h-4 w-4" />
                <AlertDescription>
                  Complete both KYC verification and contract signing to unlock payout functionality.
                </AlertDescription>
              </Alert>
            ) : !isKycVerified ? (
              <Alert>
                <AlertCircle className="h-4 w-4" />
                <AlertDescription>
                  Complete KYC verification to request payouts. This helps us comply with financial regulations.
                </AlertDescription>
              </Alert>
            ) : (
              <Alert>
                <AlertCircle className="h-4 w-4" />
                <AlertDescription>
                  Sign the affiliate contract to activate payout functionality.
                </AlertDescription>
              </Alert>
            )}
          </CardContent>
        </Card>
      )}

      {/* Payout Request */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <CreditCard className="h-5 w-5" />
            Request Payout
          </CardTitle>
          <CardDescription>
            Withdraw your available earnings to your preferred payment method
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          {!canRequestPayout ? (
            <Alert>
              <AlertCircle className="h-4 w-4" />
              <AlertDescription>
                {payoutData?.availableBalance === 0 
                  ? "You don't have any available balance to withdraw."
                  : !isKycVerified 
                    ? "Complete KYC verification to request payouts."
                  : !isContractSigned
                    ? "Sign the affiliate contract to request payouts."
                    : `Minimum payout amount is $${payoutData?.minimumPayout}. Your current available balance is $${payoutData?.availableBalance.toFixed(2)}.`
                }
              </AlertDescription>
            </Alert>
          ) : (
            <div className="space-y-4">
              <Alert>
                <CheckCircle className="h-4 w-4" />
                <AlertDescription>
                  You can request a payout of <strong>${payoutData?.availableBalance.toFixed(2)}</strong>. 
                  Payouts are typically processed within 3-5 business days.
                </AlertDescription>
              </Alert>

              <div className="flex items-center justify-between p-4 border rounded-lg">
                <div>
                  <h4 className="font-semibold">Bank Transfer (ACH)</h4>
                  <p className="text-sm text-muted-foreground">
                    Free • 3-5 business days
                  </p>
                </div>
                <Badge variant="secondary">Default</Badge>
              </div>

              <Button 
                onClick={requestPayout}
                disabled={requesting}
                className="w-full"
                size="lg"
              >
                {requesting ? (
                  <>
                    <RefreshCw className="h-4 w-4 mr-2 animate-spin" />
                    Processing...
                  </>
                ) : (
                  <>
                    <Download className="h-4 w-4 mr-2" />
                    Request Payout of ${payoutData?.availableBalance.toFixed(2)}
                  </>
                )}
              </Button>

              <p className="text-xs text-muted-foreground text-center">
                By requesting a payout, you agree to our payout terms and conditions. 
                You'll receive an email confirmation once your request is processed.
              </p>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Payout History */}
      <Card>
        <CardHeader>
          <CardTitle>Payout History</CardTitle>
          <CardDescription>
            Track all your payout requests and their status
          </CardDescription>
        </CardHeader>
        <CardContent>
          {payoutHistory.length === 0 ? (
            <div className="text-center py-12">
              <CreditCard className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
              <h3 className="text-lg font-semibold mb-2">No Payouts Yet</h3>
              <p className="text-muted-foreground">
                Your payout requests will appear here once you start making withdrawals.
              </p>
            </div>
          ) : (
            <div className="rounded-md border">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Date Requested</TableHead>
                    <TableHead>Amount</TableHead>
                    <TableHead>Method</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Reference</TableHead>
                    <TableHead>Updated</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {payoutHistory.map((payout) => (
                    <TableRow key={payout.id}>
                      <TableCell>
                        <div className="font-medium">
                          {new Date(payout.created_at).toLocaleDateString()}
                        </div>
                        <div className="text-xs text-muted-foreground">
                          {new Date(payout.created_at).toLocaleTimeString()}
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="font-medium">
                          ${parseFloat(payout.amount.toString()).toFixed(2)}
                        </div>
                        <div className="text-xs text-muted-foreground uppercase">
                          {payout.currency}
                        </div>
                      </TableCell>
                      <TableCell>
                        <Badge variant="outline" className="capitalize">
                          {payout.method}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center gap-1">
                          {payout.status === 'paid' && <CheckCircle className="h-4 w-4 text-green-600" />}
                          {payout.status === 'processing' && <Clock className="h-4 w-4 text-amber-600" />}
                          {payout.status === 'requested' && <Clock className="h-4 w-4 text-blue-600" />}
                          {payout.status === 'failed' && <XCircle className="h-4 w-4 text-red-600" />}
                          <Badge 
                            variant={
                              payout.status === 'paid' ? 'default' :
                              payout.status === 'processing' ? 'secondary' :
                              payout.status === 'requested' ? 'outline' : 'destructive'
                            }
                          >
                            {payout.status}
                          </Badge>
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="font-mono text-xs">
                          {payout.reference || 'N/A'}
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="text-sm">
                          {new Date(payout.updated_at).toLocaleDateString()}
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Payment Methods Info */}
      <Card>
        <CardHeader>
          <CardTitle>Payment Methods</CardTitle>
          <CardDescription>
            Available payout methods and processing times
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="flex items-center justify-between p-4 border rounded-lg">
              <div>
                <h4 className="font-semibold">Bank Transfer (ACH)</h4>
                <p className="text-sm text-muted-foreground">
                  Direct deposit to your bank account
                </p>
              </div>
              <div className="text-right">
                <div className="font-medium">Free</div>
                <div className="text-xs text-muted-foreground">3-5 business days</div>
              </div>
            </div>

            <div className="flex items-center justify-between p-4 border rounded-lg opacity-50">
              <div>
                <h4 className="font-semibold">PayPal</h4>
                <p className="text-sm text-muted-foreground">
                  Instant transfer to PayPal account
                </p>
              </div>
              <div className="text-right">
                <div className="font-medium">2.9% fee</div>
                <div className="text-xs text-muted-foreground">
                  <Badge variant="outline">Coming Soon</Badge>
                </div>
              </div>
            </div>

            <div className="flex items-center justify-between p-4 border rounded-lg opacity-50">
              <div>
                <h4 className="font-semibold">Cryptocurrency</h4>
                <p className="text-sm text-muted-foreground">
                  Bitcoin, Ethereum, USDC
                </p>
              </div>
              <div className="text-right">
                <div className="font-medium">1% fee</div>
                <div className="text-xs text-muted-foreground">
                  <Badge variant="outline">Coming Soon</Badge>
                </div>
              </div>
            </div>
          </div>

          <Alert className="mt-6">
            <AlertCircle className="h-4 w-4" />
            <AlertDescription>
              To add or update your payment methods, please go to the{" "}
              <Button variant="link" className="p-0 h-auto font-medium">
                Settings page
              </Button>
              . You'll need to verify your identity for security purposes.
            </AlertDescription>
          </Alert>
        </CardContent>
      </Card>
    </div>
  );
}