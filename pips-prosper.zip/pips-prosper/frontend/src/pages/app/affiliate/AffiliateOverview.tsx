import { useEffect, useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { TierProgressWidget } from "@/components/TierProgressWidget";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Progress } from "@/components/ui/progress";
import { 
  TrendingUp, 
  Users, 
  DollarSign, 
  Eye, 
  MousePointer, 
  UserPlus,
  CreditCard,
  RefreshCw,
  AlertCircle,
  Clock
} from "lucide-react";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, BarChart, Bar } from "recharts";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { Skeleton } from "@/components/ui/skeleton";
import { toast } from "@/hooks/use-toast";
import { useAffiliateRealtime } from "@/hooks/useRealtime";

interface AffiliateStats {
  clicks: number;
  signups: number;
  conversions: number;
  activeSubs: number;
  totalCommissions: number;
  pendingCommissions: number;
  approvedCommissions: number;
  paidCommissions: number;
  conversionRate: number;
  avgCommissionValue: number;
}

interface ConversionData {
  id: string;
  customer_masked: string;
  plan: string;
  amount: number;
  commission_amount: number;
  status: string;
  created_at: string;
  hold_until?: string;
}

interface ChartData {
  date: string;
  clicks: number;
  conversions: number;
  revenue: number;
}

export default function AffiliateOverview() {
  const { user } = useAuth();
  const [loading, setLoading] = useState(true);
  const [affiliate, setAffiliate] = useState<any>(null);
  const [stats, setStats] = useState<AffiliateStats | null>(null);
  const [recentConversions, setRecentConversions] = useState<ConversionData[]>([]);
  const [chartData, setChartData] = useState<ChartData[]>([]);
  const [refreshing, setRefreshing] = useState(false);

  const fetchAffiliateData = async () => {
    if (!user) return;

    try {
      setLoading(true);

      // Get affiliate profile
      const { data: affiliateData, error: affiliateError } = await supabase
        .from("affiliates")
        .select("*")
        .eq("user_id", user.id)
        .single();

      if (affiliateError) {
        if (affiliateError.code === 'PGRST116') {
          // No affiliate record found
          setAffiliate(null);
          setLoading(false);
          return;
        }
        throw affiliateError;
      }

      setAffiliate(affiliateData);

      if (affiliateData.status !== 'active') {
        setLoading(false);
        return;
      }

      // Get clicks
      const { data: clicksData } = await supabase
        .from("affiliate_clicks")
        .select("id, created_at")
        .eq("affiliate_id", affiliateData.id);

      // Get commissions
      const { data: commissionsData } = await supabase
        .from("commissions")
        .select("*")
        .eq("affiliate_id", affiliateData.id);

      // Get recent conversions for display
      const { data: conversionsData } = await supabase
        .from("commissions")
        .select("*")
        .eq("affiliate_id", affiliateData.id)
        .eq("type", "rev_share")
        .order("created_at", { ascending: false })
        .limit(10);

      // Calculate stats
      const clicks = clicksData?.length || 0;
      const conversions = commissionsData?.filter(c => c.type === 'rev_share').length || 0;
      const totalCommissions = commissionsData?.reduce((sum, c) => sum + parseFloat(c.amount.toString()), 0) || 0;
      const pendingCommissions = commissionsData?.filter(c => c.status === 'pending').reduce((sum, c) => sum + parseFloat(c.amount.toString()), 0) || 0;
      const approvedCommissions = commissionsData?.filter(c => c.status === 'approved').reduce((sum, c) => sum + parseFloat(c.amount.toString()), 0) || 0;
      const paidCommissions = commissionsData?.filter(c => c.status === 'paid').reduce((sum, c) => sum + parseFloat(c.amount.toString()), 0) || 0;

      setStats({
        clicks,
        signups: conversions, // Simplified - each commission represents a signup
        conversions,
        activeSubs: conversions, // Simplified
        totalCommissions,
        pendingCommissions,
        approvedCommissions,
        paidCommissions,
        conversionRate: clicks > 0 ? (conversions / clicks) * 100 : 0,
        avgCommissionValue: conversions > 0 ? totalCommissions / conversions : 0
      });

      // Format conversions for display
      const formattedConversions: ConversionData[] = conversionsData?.map(c => ({
        id: c.id,
        customer_masked: `***${c.customer_user_id.slice(-4)}`,
        plan: c.notes?.includes('Premium') ? 'Premium' : c.notes?.includes('Pro') ? 'Pro' : 'Basic',
        amount: parseFloat(c.amount.toString()) / (parseFloat(c.rate_pct.toString()) / 100), // Calculate original amount
        commission_amount: parseFloat(c.amount.toString()),
        status: c.status,
        created_at: c.created_at,
        hold_until: c.hold_until
      })) || [];

      setRecentConversions(formattedConversions);

      // Generate chart data (last 30 days)
      const chartDataPoints: ChartData[] = [];
      for (let i = 29; i >= 0; i--) {
        const date = new Date();
        date.setDate(date.getDate() - i);
        const dateStr = date.toISOString().split('T')[0];
        
        const dayClicks = clicksData?.filter(c => 
          c.created_at.startsWith(dateStr)
        ).length || 0;
        
        const dayConversions = commissionsData?.filter(c => 
          c.created_at.startsWith(dateStr) && c.type === 'rev_share'
        ).length || 0;
        
        const dayRevenue = commissionsData?.filter(c => 
          c.created_at.startsWith(dateStr)
        ).reduce((sum, c) => sum + parseFloat(c.amount.toString()), 0) || 0;

        chartDataPoints.push({
          date: date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' }),
          clicks: dayClicks,
          conversions: dayConversions,
          revenue: dayRevenue
        });
      }

      setChartData(chartDataPoints);

    } catch (error) {
      console.error('Error fetching affiliate data:', error);
      toast({
        title: "Error",
        description: "Failed to load affiliate data",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const handleRefresh = async () => {
    setRefreshing(true);
    await fetchAffiliateData();
    setRefreshing(false);
    toast({
      title: "Refreshed",
      description: "Affiliate data has been updated"
    });
  };

  useEffect(() => {
    fetchAffiliateData();
  }, [user]);

  // Real-time affiliate updates
  useAffiliateRealtime(
    (payload) => {
      // Affiliate data updated
      if (payload.new.user_id === user?.id) {
        console.log('Affiliate profile updated:', payload.new);
        setAffiliate(payload.new);
        
        if (payload.old.status !== payload.new.status) {
          toast({
            title: "Affiliate Status Updated",
            description: `Your affiliate status is now ${payload.new.status}`,
          });
          
          // If status changed to active, refetch all data
          if (payload.new.status === 'active') {
            fetchAffiliateData();
          }
        }
      }
    },
    (payload) => {
      // Affiliate profile updated (same as insert for existing affiliates)
      if (payload.new.user_id === user?.id) {
        console.log('Affiliate updated:', payload.new);
        setAffiliate(payload.new);
      }
    },
    (payload) => {
      // New commission earned
      if (affiliate && payload.new.affiliate_id === affiliate.id) {
        console.log('New commission earned:', payload.new);
        
        // Update stats
        setStats(prev => {
          if (!prev) return prev;
          
          const newAmount = parseFloat(payload.new.amount.toString());
          return {
            ...prev,
            conversions: prev.conversions + 1,
            totalCommissions: prev.totalCommissions + newAmount,
            pendingCommissions: payload.new.status === 'pending' 
              ? prev.pendingCommissions + newAmount 
              : prev.pendingCommissions,
            approvedCommissions: payload.new.status === 'approved'
              ? prev.approvedCommissions + newAmount
              : prev.approvedCommissions,
            avgCommissionValue: (prev.totalCommissions + newAmount) / (prev.conversions + 1)
          };
        });

        // Add to recent conversions
        const newConversion: ConversionData = {
          id: payload.new.id,
          customer_masked: `***${payload.new.customer_user_id.slice(-4)}`,
          plan: payload.new.notes?.includes('Premium') ? 'Premium' : 
                payload.new.notes?.includes('Pro') ? 'Pro' : 'Basic',
          amount: parseFloat(payload.new.amount.toString()) / (parseFloat(payload.new.rate_pct.toString()) / 100),
          commission_amount: parseFloat(payload.new.amount.toString()),
          status: payload.new.status,
          created_at: payload.new.created_at,
          hold_until: payload.new.hold_until
        };
        
        setRecentConversions(prev => [newConversion, ...prev.slice(0, 9)]);

        toast({
          title: "New Commission Earned! 🎉",
          description: `$${payload.new.amount} commission from ${newConversion.plan} plan`,
        });
      }
    },
    (payload) => {
      // Payout status updated
      if (affiliate && payload.new.affiliate_id === affiliate.id) {
        console.log('Payout updated:', payload.new);
        
        // Update recent conversions status if it's a commission status change
        if (payload.old.status !== payload.new.status) {
          setRecentConversions(prev => 
            prev.map(conv => 
              conv.id === payload.new.id 
                ? { ...conv, status: payload.new.status }
                : conv
            )
          );

          // Update stats based on status change
          setStats(prev => {
            if (!prev) return prev;
            
            const amount = parseFloat(payload.new.amount.toString());
            let newStats = { ...prev };
            
            // Remove from old status
            if (payload.old.status === 'pending') {
              newStats.pendingCommissions -= amount;
            } else if (payload.old.status === 'approved') {
              newStats.approvedCommissions -= amount;
            } else if (payload.old.status === 'paid') {
              newStats.paidCommissions -= amount;
            }
            
            // Add to new status
            if (payload.new.status === 'pending') {
              newStats.pendingCommissions += amount;
            } else if (payload.new.status === 'approved') {
              newStats.approvedCommissions += amount;
            } else if (payload.new.status === 'paid') {
              newStats.paidCommissions += amount;
            }
            
            return newStats;
          });

          toast({
            title: "Commission Status Updated",
            description: `Commission ${payload.new.status === 'paid' ? 'paid out' : payload.new.status}`,
          });
        }
      }
    }
  );

  if (loading) {
    return (
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <Skeleton className="h-8 w-48 mb-2" />
            <Skeleton className="h-4 w-64" />
          </div>
          <Skeleton className="h-10 w-24" />
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {[...Array(4)].map((_, i) => (
            <Card key={i}>
              <CardHeader className="pb-2">
                <Skeleton className="h-4 w-20 mb-2" />
                <Skeleton className="h-8 w-16" />
              </CardHeader>
            </Card>
          ))}
        </div>
      </div>
    );
  }

  if (!affiliate) {
    return (
      <div className="max-w-2xl mx-auto text-center py-12">
        <AlertCircle className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
        <h2 className="text-2xl font-semibold mb-2">No Affiliate Account Found</h2>
        <p className="text-muted-foreground mb-6">
          You don't have an affiliate account yet. Apply to become an affiliate to start earning commissions.
        </p>
        <Button asChild>
          <a href="/affiliates/apply">Apply to Become an Affiliate</a>
        </Button>
      </div>
    );
  }

  if (affiliate.status === 'pending') {
    return (
      <div className="max-w-2xl mx-auto text-center py-12">
        <Clock className="h-12 w-12 text-amber-500 mx-auto mb-4" />
        <h2 className="text-2xl font-semibold mb-2">Application Under Review</h2>
        <p className="text-muted-foreground mb-6">
          Your affiliate application is currently being reviewed. You'll be notified once it's approved.
        </p>
        <Badge variant="secondary" className="text-sm">Status: {affiliate.status}</Badge>
      </div>
    );
  }

  if (affiliate.status !== 'active') {
    return (
      <div className="max-w-2xl mx-auto text-center py-12">
        <AlertCircle className="h-12 w-12 text-red-500 mx-auto mb-4" />
        <h2 className="text-2xl font-semibold mb-2">Account Suspended</h2>
        <p className="text-muted-foreground mb-6">
          Your affiliate account has been suspended. Please contact support for more information.
        </p>
        <Badge variant="destructive" className="text-sm">Status: {affiliate.status}</Badge>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Affiliate Overview</h1>
          <p className="text-muted-foreground">
            Track your affiliate performance and earnings
          </p>
        </div>
        <Button 
          onClick={handleRefresh} 
          disabled={refreshing}
          variant="outline"
        >
          <RefreshCw className={`h-4 w-4 mr-2 ${refreshing ? 'animate-spin' : ''}`} />
          Refresh
        </Button>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Clicks</CardTitle>
            <MousePointer className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats?.clicks || 0}</div>
            <p className="text-xs text-muted-foreground">
              +{chartData.slice(-7).reduce((sum, d) => sum + d.clicks, 0)} this week
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Conversions</CardTitle>
            <UserPlus className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats?.conversions || 0}</div>
            <p className="text-xs text-muted-foreground">
              {stats?.conversionRate.toFixed(1)}% conversion rate
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Earned</CardTitle>
            <DollarSign className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">${stats?.totalCommissions.toFixed(2) || '0.00'}</div>
            <p className="text-xs text-muted-foreground">
              ${stats?.avgCommissionValue.toFixed(2) || '0.00'} avg per conversion
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Available</CardTitle>
            <CreditCard className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">${stats?.approvedCommissions.toFixed(2) || '0.00'}</div>
            <p className="text-xs text-muted-foreground">
              Ready for payout
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Commission Breakdown */}
      <Card>
        <CardHeader>
          <CardTitle>Commission Breakdown</CardTitle>
          <CardDescription>Your earnings by status</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-sm font-medium">Pending</span>
                <Badge variant="secondary">${stats?.pendingCommissions.toFixed(2)}</Badge>
              </div>
              <Progress 
                value={(stats?.pendingCommissions || 0) / (stats?.totalCommissions || 1) * 100} 
                className="h-2"
              />
              <p className="text-xs text-muted-foreground">14-day hold period</p>
            </div>

            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-sm font-medium">Available</span>
                <Badge variant="default">${stats?.approvedCommissions.toFixed(2)}</Badge>
              </div>
              <Progress 
                value={(stats?.approvedCommissions || 0) / (stats?.totalCommissions || 1) * 100} 
                className="h-2"
              />
              <p className="text-xs text-muted-foreground">Ready for withdrawal</p>
            </div>

            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-sm font-medium">Paid</span>
                <Badge variant="outline">${stats?.paidCommissions.toFixed(2)}</Badge>
              </div>
              <Progress 
                value={(stats?.paidCommissions || 0) / (stats?.totalCommissions || 1) * 100} 
                className="h-2"
              />
              <p className="text-xs text-muted-foreground">Successfully withdrawn</p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Charts */}
      <Tabs defaultValue="performance" className="space-y-4">
        <TabsList>
          <TabsTrigger value="performance">Performance</TabsTrigger>
          <TabsTrigger value="revenue">Revenue</TabsTrigger>
        </TabsList>

        <TabsContent value="performance">
          <Card>
            <CardHeader>
              <CardTitle>Clicks vs Conversions (Last 30 Days)</CardTitle>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <LineChart data={chartData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="date" />
                  <YAxis />
                  <Tooltip />
                  <Line 
                    type="monotone" 
                    dataKey="clicks" 
                    stroke="hsl(var(--primary))" 
                    strokeWidth={2}
                    name="Clicks"
                  />
                  <Line 
                    type="monotone" 
                    dataKey="conversions" 
                    stroke="hsl(var(--chart-2))" 
                    strokeWidth={2}
                    name="Conversions"
                  />
                </LineChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="revenue">
          <Card>
            <CardHeader>
              <CardTitle>Daily Revenue (Last 30 Days)</CardTitle>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <BarChart data={chartData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="date" />
                  <YAxis />
                  <Tooltip formatter={(value) => [`$${value}`, 'Revenue']} />
                  <Bar 
                    dataKey="revenue" 
                    fill="hsl(var(--primary))"
                    name="Revenue"
                  />
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Recent Conversions */}
      <Card>
        <CardHeader>
          <CardTitle>Recent Conversions</CardTitle>
          <CardDescription>Your latest successful referrals</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {recentConversions.length === 0 ? (
              <p className="text-center text-muted-foreground py-8">
                No conversions yet. Share your referral links to start earning!
              </p>
            ) : (
              recentConversions.map((conversion) => (
                <div key={conversion.id} className="flex items-center justify-between p-4 border rounded-lg">
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <Badge variant="outline">{conversion.plan}</Badge>
                      <span className="text-sm font-medium">Customer {conversion.customer_masked}</span>
                    </div>
                    <p className="text-sm text-muted-foreground">
                      {new Date(conversion.created_at).toLocaleDateString()}
                      {conversion.hold_until && conversion.status === 'pending' && (
                        <span className="ml-2">
                          • Available {new Date(conversion.hold_until).toLocaleDateString()}
                        </span>
                      )}
                    </p>
                  </div>
                  <div className="text-right">
                    <div className="font-semibold">${conversion.commission_amount.toFixed(2)}</div>
                    <Badge 
                      variant={
                        conversion.status === 'paid' ? 'default' :
                        conversion.status === 'approved' ? 'secondary' :
                        conversion.status === 'pending' ? 'outline' : 'destructive'
                      }
                    >
                      {conversion.status}
                    </Badge>
                  </div>
                </div>
              ))
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}