import { useEffect, useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Checkbox } from "@/components/ui/checkbox";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { 
  FileText, 
  CheckCircle, 
  XCircle, 
  Clock,
  AlertCircle,
  RefreshCw,
  Download,
  PenTool
} from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { toast } from "@/hooks/use-toast";

interface ContractData {
  id: string;
  status: string;
  contract_type: string;
  contract_version: string;
  signed_at?: string;
  signed_ip?: string;
  created_at: string;
  updated_at: string;
}

interface AffiliateData {
  id: string;
  status: string;
  code: string;
}

export default function AffiliateContract() {
  const { user } = useAuth();
  const [loading, setLoading] = useState(true);
  const [affiliate, setAffiliate] = useState<AffiliateData | null>(null);
  const [contractData, setContractData] = useState<ContractData | null>(null);
  const [signing, setSigning] = useState(false);
  const [agreed, setAgreed] = useState(false);

  const fetchContractData = async () => {
    if (!user) return;

    try {
      setLoading(true);

      // Get affiliate profile
      const { data: affiliateData, error: affiliateError } = await supabase
        .from("affiliates")
        .select("*")
        .eq("user_id", user.id)
        .single();

      if (affiliateError) throw affiliateError;
      setAffiliate(affiliateData);

      if (affiliateData.status !== 'active') {
        setLoading(false);
        return;
      }

      // Get contract data
      const { data: contractResult, error: contractError } = await supabase
        .from("affiliate_contracts")
        .select("*")
        .eq("affiliate_id", affiliateData.id)
        .eq("contract_type", "standard")
        .order("created_at", { ascending: false })
        .maybeSingle();

      if (contractError) throw contractError;
      setContractData(contractResult as ContractData);

    } catch (error) {
      console.error('Error fetching contract data:', error);
      toast({
        title: "Error",
        description: "Failed to load contract data",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const signContract = async () => {
    if (!affiliate || !agreed) return;

    try {
      setSigning(true);

      const contractPayload = {
        affiliate_id: affiliate.id,
        contract_type: 'standard',
        contract_version: '1.0',
        signed_at: new Date().toISOString(),
        signed_ip: await fetch('https://api.ipify.org?format=json')
          .then(res => res.json())
          .then(data => data.ip)
          .catch(() => null),
        signed_user_agent: navigator.userAgent,
        status: 'signed',
        contract_data: {
          terms_version: '1.0',
          agreed_at: new Date().toISOString(),
          user_agent: navigator.userAgent
        }
      };

      let error;
      
      if (contractData) {
        // Update existing contract
        const result = await supabase
          .from("affiliate_contracts")
          .update(contractPayload)
          .eq("id", contractData.id);
        error = result.error;
      } else {
        // Create new contract
        const result = await supabase
          .from("affiliate_contracts")
          .insert(contractPayload);
        error = result.error;
      }

      if (error) throw error;

      toast({
        title: "Contract Signed",
        description: "Your affiliate contract has been successfully signed!"
      });

      await fetchContractData();

    } catch (error) {
      console.error('Error signing contract:', error);
      toast({
        title: "Error",
        description: "Failed to sign contract",
        variant: "destructive"
      });
    } finally {
      setSigning(false);
    }
  };

  useEffect(() => {
    fetchContractData();
  }, [user]);

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
      </div>
    );
  }

  if (!affiliate || affiliate.status !== 'active') {
    return (
      <div className="max-w-2xl mx-auto text-center py-12">
        <FileText className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
        <h2 className="text-2xl font-semibold mb-2">Contract Unavailable</h2>
        <p className="text-muted-foreground">
          Your affiliate account must be active to access contract signing.
        </p>
      </div>
    );
  }

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'signed':
        return <CheckCircle className="h-5 w-5 text-green-600" />;
      case 'rejected':
        return <XCircle className="h-5 w-5 text-red-600" />;
      default:
        return <AlertCircle className="h-5 w-5 text-muted-foreground" />;
    }
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'signed':
        return <Badge className="bg-green-100 text-green-800">Signed</Badge>;
      case 'rejected':
        return <Badge variant="destructive">Rejected</Badge>;
      default:
        return <Badge variant="outline">Pending</Badge>;
    }
  };

  const isContractSigned = contractData?.status === 'signed';
  const canSign = affiliate && affiliate.status === 'active' && !isContractSigned;

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Affiliate Contract</h1>
          <p className="text-muted-foreground">
            Review and sign your affiliate partnership agreement
          </p>
        </div>
        <Button 
          onClick={fetchContractData} 
          variant="outline"
          disabled={loading}
        >
          <RefreshCw className={`h-4 w-4 mr-2 ${loading ? 'animate-spin' : ''}`} />
          Refresh
        </Button>
      </div>

      {/* Contract Status */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <FileText className="h-6 w-6 text-primary" />
              <div>
                <CardTitle>Contract Status</CardTitle>
                <CardDescription>
                  Current state of your affiliate agreement
                </CardDescription>
              </div>
            </div>
            {contractData && getStatusIcon(contractData.status)}
          </div>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center justify-between">
            <span className="font-medium">Status</span>
            {contractData ? getStatusBadge(contractData.status) : getStatusBadge('pending')}
          </div>

          {contractData && (
            <>
              <div className="flex items-center justify-between">
                <span className="font-medium">Version</span>
                <span className="text-sm">{contractData.contract_version}</span>
              </div>
              
              {contractData.signed_at && (
                <div className="flex items-center justify-between">
                  <span className="font-medium">Signed Date</span>
                  <span className="text-sm text-muted-foreground">
                    {new Date(contractData.signed_at).toLocaleDateString()}
                  </span>
                </div>
              )}

              <div className="flex items-center justify-between">
                <span className="font-medium">Created</span>
                <span className="text-sm text-muted-foreground">
                  {new Date(contractData.created_at).toLocaleDateString()}
                </span>
              </div>
            </>
          )}
        </CardContent>
      </Card>

      {/* Contract Terms */}
      <Card>
        <CardHeader>
          <CardTitle>PipTrackr.com Affiliate Agreement</CardTitle>
          <CardDescription>
            Version 1.0 • Effective Date: {new Date().toLocaleDateString()}
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="prose prose-sm max-w-none">
            <h3 className="font-semibold">1. Agreement Overview</h3>
            <p className="text-muted-foreground">
              This Affiliate Agreement ("Agreement") is entered into between PipTrackr.com ("Company") 
              and you ("Affiliate") for the promotion of our trading journal and analytics platform.
            </p>

            <h3 className="font-semibold">2. Commission Structure</h3>
            <ul className="text-muted-foreground space-y-1">
              <li>• Default commission rate: 10% of subscription revenue</li>
              <li>• Cookie duration: 30 days from initial click</li>
              <li>• Minimum payout threshold: $100 USD</li>
              <li>• Payment processing: Monthly, within 30 days</li>
            </ul>

            <h3 className="font-semibold">3. Affiliate Responsibilities</h3>
            <ul className="text-muted-foreground space-y-1">
              <li>• Promote PipTrackr.com services ethically and accurately</li>
              <li>• Comply with FTC disclosure requirements</li>
              <li>• Maintain professional standards in marketing materials</li>
              <li>• Report any compliance issues promptly</li>
            </ul>

            <h3 className="font-semibold">4. Prohibited Activities</h3>
            <ul className="text-muted-foreground space-y-1">
              <li>• Spam marketing or unsolicited communications</li>
              <li>• False or misleading advertising claims</li>
              <li>• Brand bidding on Company trademarks</li>
              <li>• Cookie stuffing or fraudulent referral methods</li>
            </ul>

            <h3 className="font-semibold">5. Payment Terms</h3>
            <p className="text-muted-foreground">
              Commissions are calculated monthly and paid within 30 days of the month end, 
              provided the minimum threshold is met. Payments require completed KYC verification 
              and signed affiliate agreement.
            </p>

            <h3 className="font-semibold">6. Termination</h3>
            <p className="text-muted-foreground">
              Either party may terminate this agreement with 30 days written notice. 
              Unpaid commissions for completed transactions will be honored according to 
              the payment schedule.
            </p>

            <h3 className="font-semibold">7. Compliance & Legal</h3>
            <p className="text-muted-foreground">
              This agreement is governed by US law. Affiliates must comply with all applicable 
              local laws and regulations, including tax obligations and disclosure requirements.
            </p>
          </div>
        </CardContent>
      </Card>

      {/* Sign Contract */}
      {canSign && (
        <Card>
          <CardHeader>
            <CardTitle>Sign Agreement</CardTitle>
            <CardDescription>
              Review and accept the terms to activate your affiliate account
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-start space-x-2">
              <Checkbox
                id="agree-terms"
                checked={agreed}
                onCheckedChange={(checked) => setAgreed(checked as boolean)}
              />
              <label htmlFor="agree-terms" className="text-sm leading-5">
                I have read, understood, and agree to the terms and conditions of this 
                Affiliate Agreement. I acknowledge that this constitutes a legally binding 
                electronic signature.
              </label>
            </div>

            <Button 
              onClick={signContract}
              disabled={signing || !agreed}
              className="w-full"
              size="lg"
            >
              {signing ? (
                <>
                  <RefreshCw className="h-4 w-4 mr-2 animate-spin" />
                  Signing Contract...
                </>
              ) : (
                <>
                  <PenTool className="h-4 w-4 mr-2" />
                  Sign Affiliate Agreement
                </>
              )}
            </Button>

            <div className="text-xs text-muted-foreground text-center">
              <p>By signing, you agree to receive commission payments and legal notices electronically.</p>
              <p>Your IP address and browser information will be recorded for security purposes.</p>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Contract Signed */}
      {isContractSigned && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <CheckCircle className="h-5 w-5 text-green-600" />
              Contract Successfully Signed
            </CardTitle>
          </CardHeader>
          <CardContent>
            <Alert>
              <CheckCircle className="h-4 w-4" />
              <AlertDescription>
                Your affiliate contract has been signed and is now active! You can request 
                payouts once you complete KYC verification and reach the minimum threshold.
              </AlertDescription>
            </Alert>

            <div className="flex gap-2 mt-4">
              <Button variant="outline" size="sm">
                <Download className="h-4 w-4 mr-2" />
                Download Contract
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Help Section */}
      <Card>
        <CardHeader>
          <CardTitle>Questions About the Contract?</CardTitle>
          <CardDescription>
            Common questions about our affiliate agreement
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4 text-sm">
            <div>
              <h4 className="font-medium mb-1">Can I modify the contract terms?</h4>
              <p className="text-muted-foreground">
                The standard agreement terms are fixed, but custom arrangements may be available 
                for high-volume affiliates. Contact our affiliate team for details.
              </p>
            </div>
            <div>
              <h4 className="font-medium mb-1">What happens if I violate the terms?</h4>
              <p className="text-muted-foreground">
                Violations may result in commission forfeiture, account suspension, or termination. 
                We'll provide notice and opportunity to remedy minor violations when possible.
              </p>
            </div>
            <div>
              <h4 className="font-medium mb-1">How do I update my agreement?</h4>
              <p className="text-muted-foreground">
                When agreement updates are available, you'll be notified via email and dashboard. 
                Continued participation requires accepting updated terms.
              </p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}