import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Progress } from "@/components/ui/progress";
import { SEOHead } from "@/components/SEOHead";
import { 
  Target, 
  Plus, 
  Edit, 
  Trash2, 
  CheckCircle,
  DollarSign,
  Calendar,
  TrendingUp,
  Star,
  Trophy
} from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";

interface AccountGoal {
  id: string;
  account_id: string;
  goal_type: string;
  target_value: number;
  current_value: number;
  target_date: string | null;
  is_achieved: boolean;
  created_at: string;
  updated_at: string;
}

const goalTypes = [
  { value: "profit_target", label: "Profit Target", icon: DollarSign, color: "#22c55e" },
  { value: "win_rate", label: "Win Rate", icon: TrendingUp, color: "#3b82f6" },
  { value: "max_drawdown", label: "Max Drawdown", icon: Trophy, color: "#f59e0b" },
  { value: "risk_per_trade", label: "Risk Per Trade", icon: Star, color: "#8b5cf6" },
];

export default function AppGoalsRules() {
  const [goals, setGoals] = useState<AccountGoal[]>([]);
  const [accounts, setAccounts] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [isGoalDialogOpen, setIsGoalDialogOpen] = useState(false);
  const [editingGoal, setEditingGoal] = useState<AccountGoal | null>(null);
  const [selectedGoalType, setSelectedGoalType] = useState<string>("all");
  const { user } = useAuth();
  const { toast } = useToast();

  const [goalFormData, setGoalFormData] = useState({
    account_id: "",
    goal_type: "profit_target",
    target_value: 0,
    target_date: ""
  });

  const fetchGoals = async () => {
    if (!user) return;

    try {
      // Fetch goals
      const { data: goalsData, error: goalsError } = await supabase
        .from("account_goals")
        .select("*")
        .eq("user_id", user.id)
        .order("created_at", { ascending: false });

      if (goalsError) throw goalsError;

      // Fetch accounts for dropdown
      const { data: accountsData, error: accountsError } = await supabase
        .from("accounts")
        .select("*")
        .eq("user_id", user.id)
        .eq("is_active", true)
        .order("name", { ascending: true });

      if (accountsError) throw accountsError;

      setGoals(goalsData || []);
      setAccounts(accountsData || []);
    } catch (error: any) {
      toast({
        variant: "destructive",
        title: "Error loading data",
        description: error.message,
      });
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchGoals();
  }, [user]);

  // Auto-select first account when accounts are loaded
  useEffect(() => {
    if (accounts.length > 0 && goalFormData.account_id === "") {
      setGoalFormData(prev => ({ ...prev, account_id: accounts[0].id }));
    }
  }, [accounts, goalFormData.account_id]);

  // Real-time updates
  useEffect(() => {
    if (!user) return;

    const goalsChannel = supabase
      .channel('goals-realtime')
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'account_goals',
          filter: `user_id=eq.${user.id}`
        },
        (payload) => {
          console.log('Goal realtime update:', payload);
          
          if (payload.eventType === 'INSERT') {
            setGoals(prev => [payload.new as AccountGoal, ...prev]);
            toast({
              title: "✅ Goal Created",
              description: `New ${goalTypes.find(t => t.value === payload.new.goal_type)?.label || 'goal'} has been set successfully!`,
            });
          } else if (payload.eventType === 'UPDATE') {
            setGoals(prev => prev.map(goal => 
              goal.id === payload.new.id ? payload.new as AccountGoal : goal
            ));
            toast({
              title: "📊 Goal Updated",
              description: "Your goal has been updated successfully",
            });
          } else if (payload.eventType === 'DELETE') {
            setGoals(prev => prev.filter(goal => goal.id !== payload.old.id));
            toast({
              title: "🗑️ Goal Deleted",
              description: "Goal has been removed from your list",
            });
          }
        }
      )
      .subscribe((status) => {
        console.log('Goals realtime subscription status:', status);
      });

    return () => {
      supabase.removeChannel(goalsChannel);
    };
  }, [user, toast]);

  const handleGoalSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) return;

    // Validate account_id is selected
    if (!goalFormData.account_id) {
      toast({
        variant: "destructive",
        title: "Account Required",
        description: "Please select an account for this goal.",
      });
      return;
    }

    try {
      const goalData = {
        ...goalFormData,
        user_id: user.id,
        current_value: 0,
        is_achieved: false
      };

      if (editingGoal) {
        const { error } = await supabase
          .from("account_goals")
          .update(goalData)
          .eq("id", editingGoal.id);

        if (error) throw error;

        toast({
          title: "Goal Updated",
          description: "Your goal has been updated successfully.",
        });
      } else {
        const { error } = await supabase
          .from("account_goals")
          .insert([goalData]);

        if (error) throw error;

        toast({
          title: "Goal Created",
          description: "Your new goal has been created successfully.",
        });
      }

      setIsGoalDialogOpen(false);
      setEditingGoal(null);
      resetGoalForm();
    } catch (error: any) {
      toast({
        variant: "destructive",
        title: "Error saving goal",
        description: error.message,
      });
    }
  };

  const resetGoalForm = () => {
    const defaultAccountId = accounts.length > 0 ? accounts[0].id : "";
    setGoalFormData({
      account_id: defaultAccountId,
      goal_type: "profit_target",
      target_value: 0,
      target_date: ""
    });
  };

  const handleDeleteGoal = async (goal: AccountGoal) => {
    if (!confirm(`Are you sure you want to delete this goal?`)) return;

    try {
      const { error } = await supabase
        .from("account_goals")
        .delete()
        .eq("id", goal.id);

      if (error) throw error;
    } catch (error: any) {
      toast({
        variant: "destructive",
        title: "Error deleting goal",
        description: error.message,
      });
    }
  };

  const getGoalProgress = (goal: AccountGoal) => {
    if (goal.target_value === 0) return 0;
    return Math.min((goal.current_value / goal.target_value) * 100, 100);
  };

  const filteredGoals = selectedGoalType === "all" 
    ? goals 
    : goals.filter(goal => goal.goal_type === selectedGoalType);

  if (loading) {
    return (
      <div className="space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {[1, 2, 3, 4, 5, 6].map(i => (
            <Card key={i} className="glass-card border-card-border">
              <CardContent className="p-6">
                <div className="animate-pulse space-y-4">
                  <div className="h-4 bg-muted rounded"></div>
                  <div className="h-20 bg-muted rounded"></div>
                  <div className="h-4 bg-muted rounded w-1/2"></div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-8">
      <SEOHead 
        title="Trading Goals - PipTrackr.com"
        description="Set and track your trading goals for consistent success"
      />

      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-poppins font-bold text-foreground flex items-center gap-3">
            <Target className="h-8 w-8 text-primary" />
            Trading Goals
          </h1>
          <p className="text-muted-foreground mt-1">
            Set ambitious goals and track your progress towards trading success
          </p>
        </div>
      </div>

      {/* Goals Section */}
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div className="flex flex-wrap gap-2">
            <Button 
              variant={selectedGoalType === "all" ? "default" : "outline"}
              size="sm"
              onClick={() => setSelectedGoalType("all")}
            >
              All Goals ({goals.length})
            </Button>
            {goalTypes.map((type) => {
              const count = goals.filter(g => g.goal_type === type.value).length;
              return (
                <Button 
                  key={type.value}
                  variant={selectedGoalType === type.value ? "default" : "outline"}
                  size="sm"
                  onClick={() => setSelectedGoalType(type.value)}
                  className="flex items-center gap-2"
                >
                  <type.icon className="h-3 w-3" style={{ color: type.color }} />
                  {type.label} ({count})
                </Button>
              );
            })}
          </div>
          
          <Dialog open={isGoalDialogOpen} onOpenChange={setIsGoalDialogOpen}>
            <DialogTrigger asChild>
              <Button 
                variant="default"
                onClick={() => {
                  setEditingGoal(null);
                  resetGoalForm();
                }}
              >
                <Plus className="h-4 w-4 mr-2" />
                Add Goal
              </Button>
            </DialogTrigger>
            
            <DialogContent className="max-w-2xl">
              <DialogHeader>
                <DialogTitle className="flex items-center gap-2">
                  <Target className="h-5 w-5 text-primary" />
                  {editingGoal ? "Edit Goal" : "Create New Goal"}
                </DialogTitle>
              </DialogHeader>
              
              <form onSubmit={handleGoalSubmit} className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="account_id">Account</Label>
                    <Select value={goalFormData.account_id} onValueChange={(value) => setGoalFormData(prev => ({ ...prev, account_id: value }))}>
                      <SelectTrigger>
                        <SelectValue placeholder="Select account" />
                      </SelectTrigger>
                      <SelectContent className="bg-background border border-border shadow-lg z-50">
                        {accounts.map((account) => (
                          <SelectItem key={account.id} value={account.id}>
                            <div className="flex items-center gap-2">
                              <DollarSign className="h-4 w-4" />
                              {account.name} ({account.broker_name})
                            </div>
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="goal_type">Goal Type</Label>
                    <Select value={goalFormData.goal_type} onValueChange={(value) => setGoalFormData(prev => ({ ...prev, goal_type: value }))}>
                      <SelectTrigger>
                        <SelectValue placeholder="Select goal type" />
                      </SelectTrigger>
                      <SelectContent>
                        {goalTypes.map((type) => (
                          <SelectItem key={type.value} value={type.value}>
                            <div className="flex items-center gap-2">
                              <type.icon className="h-4 w-4" style={{ color: type.color }} />
                              {type.label}
                            </div>
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="target_value">Target Value</Label>
                    <Input
                      id="target_value"
                      type="number"
                      value={goalFormData.target_value}
                      onChange={(e) => setGoalFormData(prev => ({ ...prev, target_value: parseFloat(e.target.value) || 0 }))}
                      placeholder="Enter target value"
                      required
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="target_date">Target Date</Label>
                    <Input
                      id="target_date"
                      type="date"
                      value={goalFormData.target_date}
                      onChange={(e) => setGoalFormData(prev => ({ ...prev, target_date: e.target.value }))}
                    />
                  </div>
                </div>

                <div className="flex justify-end space-x-2">
                  <Button 
                    type="button" 
                    variant="outline" 
                    onClick={() => setIsGoalDialogOpen(false)}
                  >
                    Cancel
                  </Button>
                  <Button type="submit" variant="default">
                    {editingGoal ? "Update Goal" : "Create Goal"}
                  </Button>
                </div>
              </form>
            </DialogContent>
          </Dialog>
        </div>

        {/* Goals Grid */}
        {filteredGoals.length === 0 ? (
          <Card className="glass-card border-card-border">
            <CardContent className="p-12 text-center">
              <Target className="w-16 h-16 mx-auto mb-4 text-primary opacity-50" />
              <h3 className="text-lg font-semibold mb-2">No Goals Set Yet</h3>
              <p className="text-muted-foreground mb-6">
                Set your first trading goal to track your progress and stay motivated.
              </p>
              <Button onClick={() => setIsGoalDialogOpen(true)}>
                <Plus className="w-4 h-4 mr-2" />
                Create Your First Goal
              </Button>
            </CardContent>
          </Card>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredGoals.map((goal) => {
              const progress = getGoalProgress(goal);
              const typeInfo = goalTypes.find(t => t.value === goal.goal_type) || goalTypes[0];
              
              return (
                <Card 
                  key={goal.id} 
                  className="glass-card border-card-border hover:shadow-elegant transition-all duration-300"
                >
                  <CardHeader className="pb-3">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <typeInfo.icon className="h-5 w-5" style={{ color: typeInfo.color }} />
                        <Badge variant="secondary">{typeInfo.label}</Badge>
                      </div>
                      {goal.is_achieved && (
                        <CheckCircle className="h-5 w-5 text-success" />
                      )}
                    </div>
                  </CardHeader>
                  
                  <CardContent className="space-y-4">
                    <div>
                      <div className="flex justify-between text-sm mb-2">
                        <span>Progress</span>
                        <span className="font-medium">{progress.toFixed(1)}%</span>
                      </div>
                      <Progress value={progress} className="h-2" />
                    </div>
                    
                    <div className="flex justify-between text-sm">
                      <span>Current: {goal.current_value}</span>
                      <span>Target: {goal.target_value}</span>
                    </div>
                    
                    {goal.target_date && (
                      <div className="flex items-center gap-1 text-sm text-muted-foreground">
                        <Calendar className="h-4 w-4" />
                        <span>Due: {new Date(goal.target_date).toLocaleDateString()}</span>
                      </div>
                    )}
                    
                    <div className="flex gap-1">
                      <Button
                        variant="outline"
                        size="sm"
                        className="flex-1"
                        onClick={() => {
                          setEditingGoal(goal);
                          setGoalFormData({
                            account_id: goal.account_id,
                            goal_type: goal.goal_type,
                            target_value: goal.target_value,
                            target_date: goal.target_date || ""
                          });
                          setIsGoalDialogOpen(true);
                        }}
                      >
                        <Edit className="h-3 w-3 mr-1" />
                        Edit
                      </Button>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => handleDeleteGoal(goal)}
                        className="text-destructive hover:text-destructive"
                      >
                        <Trash2 className="h-3 w-3" />
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}