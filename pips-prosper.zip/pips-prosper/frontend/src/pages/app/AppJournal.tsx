import { useState } from "react"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { SEOHead } from "@/components/SEOHead"
import { TradesTable } from "@/components/TradesTable"
import { TradeForm } from "@/components/TradeForm"
import { StrategyFilteredMetrics } from "@/components/Dashboard/StrategyFilteredMetrics"
import { useAccountContext } from "@/hooks/useAccountContext"
import { useAccountDisplay } from "@/hooks/useAccountDisplay"
import { SharedTradesList } from "@/components/TradeSharing/SharedTradesList"

export default function AppJournal() {
  const [refreshTrigger, setRefreshTrigger] = useState(0);
  const [activeTab, setActiveTab] = useState("trades");
  const [selectedStrategy, setSelectedStrategy] = useState<string | null>(null);
  const { selectedAccountId } = useAccountContext();
  const { accountName } = useAccountDisplay(selectedAccountId);

  const handleTradeAdded = () => {
    setRefreshTrigger(prev => prev + 1);
  };

  return (
    <div className="space-y-6">
      <SEOHead 
        title="Trading Journal - PipTrackr.com"
        description="Manage and track your trading journal with detailed trade entries"
      />
      
      <div>
        <h1 className="text-3xl font-poppins font-bold text-foreground">
          Trading Journal
          {selectedAccountId && selectedAccountId !== 'all' && (
            <span className="text-lg font-normal text-muted-foreground ml-2">
              • {accountName}
            </span>
          )}
        </h1>
        <p className="text-muted-foreground mt-1">
          Track and manage your trading activity
          {selectedAccountId && selectedAccountId !== 'all' 
            ? ` for ${accountName}` 
            : ' across all accounts'
          }
        </p>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="performance">Performance</TabsTrigger>
          <TabsTrigger value="trades">Trade History</TabsTrigger>
          <TabsTrigger value="add">Add New Trade</TabsTrigger>
        </TabsList>

        <TabsContent value="performance" className="space-y-6">
          <StrategyFilteredMetrics 
            selectedStrategy={selectedStrategy}
            onStrategyChange={setSelectedStrategy}
          />
        </TabsContent>

        <TabsContent value="trades" className="space-y-6">
          <TradesTable refreshTrigger={refreshTrigger} />
        </TabsContent>

        <TabsContent value="add" className="space-y-6">
          <TradeForm onTradeAdded={handleTradeAdded} />
        </TabsContent>
      </Tabs>
    </div>
  )
}