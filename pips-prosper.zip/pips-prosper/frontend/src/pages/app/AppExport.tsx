import { useState, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Checkbox } from "@/components/ui/checkbox"
import { SEOHead } from "@/components/SEOHead"
import { Download, FileText, FileSpreadsheet, Image, Calendar, BarChart3, Loader2, CheckCircle2, AlertCircle } from "lucide-react"
import { Badge } from "@/components/ui/badge"
import { Separator } from "@/components/ui/separator"
import { Progress } from "@/components/ui/progress"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { supabase } from "@/integrations/supabase/client"
import { toast } from "sonner"
import { useAuth } from "@/hooks/useAuth"

const exportOptions = [
  {
    title: "Trading Journal Export",
    description: "Export all your trades in various formats",
    icon: FileText,
    formats: ["PDF", "CSV", "Excel"],
    color: "primary"
  },
  {
    title: "Performance Reports", 
    description: "Detailed analytics and performance metrics",
    icon: BarChart3,
    formats: ["PDF", "PNG", "JSON"],
    color: "success"
  },
  {
    title: "Tax Reports",
    description: "Generate reports for tax purposes",
    icon: FileSpreadsheet,
    formats: ["CSV", "Excel", "PDF"],
    color: "warning"
  },
  {
    title: "Strategy Backtest",
    description: "Export strategy performance data",
    icon: Calendar,
    formats: ["CSV", "JSON", "Excel"],
    color: "info"
  }
]

const quickExports = [
  { name: "Last 30 Days Trades", format: "CSV", type: "trading journal export" },
  { name: "Monthly P&L Summary", format: "PDF", type: "performance reports" },
  { name: "Risk Metrics Report", format: "Excel", type: "risk metrics report" },
  { name: "Performance Charts", format: "JSON", type: "performance reports" }
]

interface ExportJob {
  id: string;
  type: string;
  format: string;
  status: 'pending' | 'processing' | 'completed' | 'failed';
  progress: number;
  downloadUrl?: string;
  error?: string;
}

interface Account {
  id: string;
  name: string;
  broker_name: string;
}

export default function AppExport() {
  const { user } = useAuth()
  const [accounts, setAccounts] = useState<Account[]>([])
  const [selectedAccounts, setSelectedAccounts] = useState<string[]>([])
  const [dateRange, setDateRange] = useState({
    from: new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
    to: new Date().toISOString().split('T')[0]
  })
  const [exportJobs, setExportJobs] = useState<ExportJob[]>([])
  const [exporting, setExporting] = useState(false)
  const [includeAnalytics, setIncludeAnalytics] = useState(true)
  const [includeNotes, setIncludeNotes] = useState(false)

  useEffect(() => {
    if (user) {
      fetchAccounts()
    }
  }, [user])

  const fetchAccounts = async () => {
    try {
      const { data, error } = await supabase
        .from('accounts')
        .select('id, name, broker_name')
        .eq('user_id', user?.id)
        .eq('is_active', true)
        .order('name')

      if (error) throw error
      
      setAccounts(data || [])
      setSelectedAccounts(data?.map(acc => acc.id) || [])
    } catch (error) {
      console.error('Error fetching accounts:', error)
      toast.error('Failed to load accounts')
    }
  }

  const handleExport = async (type: string, format: string) => {
    if (selectedAccounts.length === 0) {
      toast.error('Please select at least one account')
      return
    }

    setExporting(true)
    const jobId = `export_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`
    
    // Add job to tracking
    const newJob: ExportJob = {
      id: jobId,
      type,
      format,
      status: 'processing',
      progress: 0
    }
    setExportJobs(prev => [newJob, ...prev])

    try {
      // Simulate progress updates
      const progressInterval = setInterval(() => {
        setExportJobs(prev => prev.map(job => 
          job.id === jobId ? { ...job, progress: Math.min(job.progress + 10, 90) } : job
        ))
      }, 200)

      const { data: { session } } = await supabase.auth.getSession()
      
      const response = await supabase.functions.invoke('export-data', {
        body: {
          type,
          format,
          dateRange,
          accountIds: selectedAccounts,
          includeAnalytics,
          includeNotes
        }
      })

      clearInterval(progressInterval)

      if (response.error) {
        throw new Error(response.error.message || 'Export failed')
      }

      // For now, create a simple downloadable file from the response data
      let fileContent: string
      let mimeType: string
      let fileExtension: string

      switch (format.toLowerCase()) {
        case 'csv':
          fileContent = generateCSVFromResponse(response.data, type)
          mimeType = 'text/csv'
          fileExtension = 'csv'
          break
        case 'json':
          fileContent = JSON.stringify(response.data, null, 2)
          mimeType = 'application/json'
          fileExtension = 'json'
          break
        default:
          fileContent = JSON.stringify(response.data, null, 2)
          mimeType = 'application/json'
          fileExtension = 'json'
      }

      const blob = new Blob([fileContent], { type: mimeType })
      const url = window.URL.createObjectURL(blob)
      const filename = `${type.toLowerCase().replace(/ /g, '_')}_${Date.now()}.${fileExtension}`

      const a = document.createElement('a')
      a.href = url
      a.download = filename
      document.body.appendChild(a)
      a.click()
      window.URL.revokeObjectURL(url)
      document.body.removeChild(a)

      // Update job status
      setExportJobs(prev => prev.map(job => 
        job.id === jobId ? { 
          ...job, 
          status: 'completed', 
          progress: 100,
          downloadUrl: url 
        } : job
      ))

      toast.success(`${format} export completed successfully!`)
      
    } catch (error: any) {
      console.error('Export error:', error)
      
      setExportJobs(prev => prev.map(job => 
        job.id === jobId ? { 
          ...job, 
          status: 'failed', 
          progress: 0,
          error: error.message 
        } : job
      ))

      toast.error(`Export failed: ${error.message}`)
    } finally {
      setExporting(false)
    }
  }

  const generateCSVFromResponse = (data: any, type: string): string => {
    if (data.type === 'trades' && data.data) {
      const headers = [
        'Date', 'Account', 'Instrument', 'Type', 'Quantity', 
        'Entry Price', 'Exit Price', 'PnL', 'Status'
      ]
      let csvContent = headers.join(',') + '\n'
      
      data.data.forEach((trade: any) => {
        const row = [
          trade.opened_at,
          trade.account?.name || '',
          trade.instrument,
          trade.type,
          trade.quantity,
          trade.entry,
          trade.exit || '',
          trade.pnl || 0,
          trade.status
        ]
        csvContent += row.map((field: any) => `"${field}"`).join(',') + '\n'
      })
      
      return csvContent
    }
    
    return JSON.stringify(data, null, 2)
  }

  return (
    <div className="space-y-6">
      <SEOHead 
        title="Export Data - PipTrackr.com"
        description="Export your trading data and reports in various formats"
      />
      
      <div>
        <h1 className="text-3xl font-poppins font-bold text-foreground">
          Export Data
        </h1>
        <p className="text-muted-foreground mt-1">
          Export your trading data, reports, and analytics in multiple formats
        </p>
      </div>

      {/* Quick Export Actions */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg font-poppins flex items-center gap-2">
            <Download className="h-5 w-5 text-primary" />
            Quick Exports
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {quickExports.map((item, index) => (
              <div key={index} className="flex items-center justify-between p-3 bg-muted/20 rounded-lg">
                <div>
                  <p className="font-medium text-sm">{item.name}</p>
                  <Badge variant="outline" className="mt-1 text-xs">
                    {item.format}
                  </Badge>
                </div>
                <Button 
                  size="sm" 
                  onClick={() => handleExport(item.type, item.format)}
                  disabled={exporting || selectedAccounts.length === 0}
                  className="ml-4"
                >
                  {exporting ? (
                    <Loader2 className="h-4 w-4 animate-spin" />
                  ) : (
                    <Download className="h-4 w-4" />
                  )}
                </Button>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Export Jobs Status */}
      {exportJobs.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="text-lg font-poppins">Export Status</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {exportJobs.slice(0, 5).map((job) => (
                <div key={job.id} className="flex items-center justify-between p-3 border rounded-lg">
                  <div className="flex-1">
                    <div className="flex items-center gap-2">
                      {job.status === 'completed' ? (
                        <CheckCircle2 className="h-4 w-4 text-green-500" />
                      ) : job.status === 'failed' ? (
                        <AlertCircle className="h-4 w-4 text-red-500" />
                      ) : (
                        <Loader2 className="h-4 w-4 animate-spin text-blue-500" />
                      )}
                      <span className="font-medium text-sm">{job.type}</span>
                      <Badge variant="outline" className="text-xs">{job.format}</Badge>
                    </div>
                    
                    {job.status === 'processing' && (
                      <Progress value={job.progress} className="mt-2 h-2" />
                    )}
                    
                    {job.error && (
                      <p className="text-red-500 text-xs mt-1">{job.error}</p>
                    )}
                  </div>
                  
                  <div className="text-xs text-muted-foreground">
                    {job.status === 'processing' ? `${job.progress}%` : 
                     job.status === 'completed' ? 'Done' : 
                     job.status === 'failed' ? 'Failed' : 'Pending'}
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      <Separator />

      {/* Detailed Export Options */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {exportOptions.map((option, index) => (
          <Card key={index} className="hover:shadow-md transition-all duration-300">
            <CardHeader className="pb-3">
              <div className="flex items-center gap-3">
                <div className={`p-2 rounded-lg bg-${option.color}/10`}>
                  <option.icon className={`h-6 w-6 text-${option.color}`} />
                </div>
                <div>
                  <CardTitle className="text-lg font-poppins">
                    {option.title}
                  </CardTitle>
                  <p className="text-sm text-muted-foreground">
                    {option.description}
                  </p>
                </div>
              </div>
            </CardHeader>
            
            <CardContent className="space-y-4">
              <div>
                <p className="text-sm font-medium mb-2">Available Formats:</p>
                <div className="flex flex-wrap gap-2">
                  {option.formats.map((format) => (
                    <Badge key={format} variant="secondary">
                      {format}
                    </Badge>
                  ))}
                </div>
              </div>
              
              <div className="flex gap-2">
                {option.formats.map((format) => (
                  <Button 
                    key={format}
                    variant="outline" 
                    size="sm"
                    onClick={() => handleExport(option.title, format)}
                    className="flex-1"
                  >
                    <Download className="h-4 w-4 mr-1" />
                    {format}
                  </Button>
                ))}
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Export Settings */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg font-poppins">Export Settings</CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Account Selection */}
          <div>
            <Label className="text-sm font-medium">Select Accounts</Label>
            <div className="mt-2 space-y-2 max-h-32 overflow-y-auto border rounded-md p-2">
              {accounts.map((account) => (
                <div key={account.id} className="flex items-center space-x-2">
                  <Checkbox
                    id={account.id}
                    checked={selectedAccounts.includes(account.id)}
                    onCheckedChange={(checked) => {
                      if (checked) {
                        setSelectedAccounts(prev => [...prev, account.id])
                      } else {
                        setSelectedAccounts(prev => prev.filter(id => id !== account.id))
                      }
                    }}
                  />
                  <Label htmlFor={account.id} className="text-sm cursor-pointer flex-1">
                    {account.name} ({account.broker_name})
                  </Label>
                </div>
              ))}
            </div>
            <div className="mt-2 flex gap-2">
              <Button 
                variant="outline" 
                size="sm"
                onClick={() => setSelectedAccounts(accounts.map(acc => acc.id))}
              >
                Select All
              </Button>
              <Button 
                variant="outline" 
                size="sm"
                onClick={() => setSelectedAccounts([])}
              >
                Clear All
              </Button>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* Date Range */}
            <div>
              <Label className="text-sm font-medium">Date Range</Label>
              <div className="mt-2 space-y-2">
                <div>
                  <Label htmlFor="from-date" className="text-xs text-muted-foreground">From</Label>
                  <Input
                    id="from-date"
                    type="date"
                    value={dateRange.from}
                    onChange={(e) => setDateRange(prev => ({ ...prev, from: e.target.value }))}
                  />
                </div>
                <div>
                  <Label htmlFor="to-date" className="text-xs text-muted-foreground">To</Label>
                  <Input
                    id="to-date"
                    type="date"
                    value={dateRange.to}
                    onChange={(e) => setDateRange(prev => ({ ...prev, to: e.target.value }))}
                  />
                </div>
              </div>
              <div className="mt-2 flex flex-wrap gap-1">
                <Button 
                  variant="outline" 
                  size="sm"
                  onClick={() => {
                    const today = new Date()
                    const thirtyDaysAgo = new Date(today.getTime() - 30 * 24 * 60 * 60 * 1000)
                    setDateRange({
                      from: thirtyDaysAgo.toISOString().split('T')[0],
                      to: today.toISOString().split('T')[0]
                    })
                  }}
                >
                  Last 30 Days
                </Button>
                <Button 
                  variant="outline" 
                  size="sm"
                  onClick={() => {
                    const today = new Date()
                    const sevenDaysAgo = new Date(today.getTime() - 7 * 24 * 60 * 60 * 1000)
                    setDateRange({
                      from: sevenDaysAgo.toISOString().split('T')[0],
                      to: today.toISOString().split('T')[0]
                    })
                  }}
                >
                  Last 7 Days
                </Button>
                <Button 
                  variant="outline" 
                  size="sm"
                  onClick={() => {
                    const today = new Date()
                    const startOfMonth = new Date(today.getFullYear(), today.getMonth(), 1)
                    setDateRange({
                      from: startOfMonth.toISOString().split('T')[0],
                      to: today.toISOString().split('T')[0]
                    })
                  }}
                >
                  This Month
                </Button>
              </div>
            </div>
            
            {/* Include Options */}
            <div>
              <Label className="text-sm font-medium">Include</Label>
              <div className="mt-2 space-y-3">
                <div className="flex items-center space-x-2">
                  <Checkbox 
                    id="trades" 
                    defaultChecked 
                    disabled
                  />
                  <Label htmlFor="trades" className="text-sm">Trade History (Always included)</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <Checkbox 
                    id="analytics" 
                    checked={includeAnalytics}
                    onCheckedChange={(checked) => setIncludeAnalytics(checked === true)}
                  />
                  <Label htmlFor="analytics" className="text-sm cursor-pointer">Analytics Data</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <Checkbox 
                    id="notes" 
                    checked={includeNotes}
                    onCheckedChange={(checked) => setIncludeNotes(checked === true)}
                  />
                  <Label htmlFor="notes" className="text-sm cursor-pointer">Notes & Comments</Label>
                </div>
              </div>
            </div>
          </div>
          
          <div className="pt-4 border-t">
            <div className="text-sm text-muted-foreground mb-2">
              Selected: {selectedAccounts.length} accounts • 
              Date range: {dateRange.from} to {dateRange.to}
            </div>
            <div className="flex gap-2">
              <Button 
                className="bg-primary hover:bg-primary-dark"
                onClick={() => handleExport('Trading Journal Export', 'CSV')}
                disabled={exporting || selectedAccounts.length === 0}
              >
                {exporting ? (
                  <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                ) : (
                  <Download className="h-4 w-4 mr-2" />
                )}
                Export as CSV
              </Button>
              <Button 
                variant="outline"
                onClick={() => handleExport('Performance Reports', 'PDF')}
                disabled={exporting || selectedAccounts.length === 0}
              >
                {exporting ? (
                  <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                ) : (
                  <Download className="h-4 w-4 mr-2" />
                )}
                Export as PDF
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}