import { Suspense, lazy } from "react"
import { Skeleton } from "@/components/ui/skeleton"
import { SEOHead } from "@/components/SEOHead"

const StrategyManager = lazy(() => 
  import("@/components/Strategy/StrategyManager").then(module => ({ default: module.StrategyManager }))
  .catch(error => {
    console.error('Failed to load StrategyManager:', error);
    return { default: () => <div>Error loading StrategyManager</div> };
  })
);

const LoadingSkeleton = () => (
  <div className="space-y-6">
    <Skeleton className="h-32 w-full" />
    <Skeleton className="h-64 w-full" />
  </div>
);

export default function AppStrategy() {
  return (
    <div className="space-y-4 sm:space-y-6">
      <SEOHead 
        title="Strategy Manager - PipTrackr.com"
        description="Manage and analyze your trading strategies"
      />
      
      <div className="px-2 sm:px-0">
        <h1 className="text-2xl sm:text-3xl font-poppins font-bold text-foreground">
          Strategy Manager
        </h1>
        <p className="text-muted-foreground mt-1 text-sm sm:text-base">
          Create, test, and optimize your trading strategies
        </p>
      </div>

      <Suspense fallback={<LoadingSkeleton />}>
        <StrategyManager />
      </Suspense>
    </div>
  )
}