import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { SEOHead } from "@/components/SEOHead";
import { Link } from "react-router-dom";
import { ArrowLeft, Mail, Shield, Users, DollarSign, AlertCircle, Clock, FileText, CheckCircle, XCircle } from "lucide-react";
import { Button } from "@/components/ui/button";

export default function AffiliateTerms() {
  return (
    <>
      <SEOHead 
        title="PipTrackr.com Affiliate Program — Terms & Conditions"
        description="Complete terms and conditions for the PipTrackr.com affiliate program. Commission structure, payment terms, prohibited activities, and compliance requirements."
        keywords="affiliate terms, affiliate agreement, commission terms, referral terms, trading affiliate program"
      />
      
      <div className="min-h-screen bg-gradient-to-br from-background via-background to-muted/20">
        <div className="container mx-auto px-6 py-12">
          <div className="max-w-4xl mx-auto">
            
            {/* Header */}
            <div className="mb-8">
              <Button variant="ghost" asChild className="mb-4">
                <Link to="/affiliates" className="flex items-center gap-2 text-muted-foreground hover:text-foreground">
                  <ArrowLeft className="h-4 w-4" />
                  Back to Affiliate Program
                </Link>
              </Button>
              
              <h1 className="text-4xl font-bold mb-4">
                PipTrackr.com Affiliate Program — Terms & Conditions
              </h1>
              
              <p className="text-lg text-muted-foreground leading-relaxed">
                Welcome to the PipTrackr.com Affiliate Program. By applying and participating, you agree to the terms below. 
                These terms protect our customers, brand, and partners, and help ensure accurate, fair attribution.
              </p>
            </div>

            <div className="space-y-8">
              
              {/* 1. Eligibility */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Users className="h-5 w-5 text-primary" />
                    1. Eligibility
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <p>• You must be 18+ and able to enter a binding agreement.</p>
                  <p>• One account per individual or entity.</p>
                  <p>• We may request ID/KYC or tax information before payouts.</p>
                </CardContent>
              </Card>

              {/* 2. Enrollment & Approval */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <CheckCircle className="h-5 w-5 text-primary" />
                    2. Enrollment & Approval
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <p>• Apply at <Link to="/affiliates/apply" className="text-primary hover:underline">/affiliates/apply</Link>.</p>
                  <p>• We review applications in 1–3 business days.</p>
                  <p>• We may accept, reject, pause, or ban accounts at our sole discretion.</p>
                </CardContent>
              </Card>

              {/* 3. Referral Links & Cookies */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <FileText className="h-5 w-5 text-primary" />
                    3. Referral Links & Cookies
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <p>• Supported formats: <code className="bg-muted px-2 py-1 rounded">/?ref=AFFCODE</code> or <code className="bg-muted px-2 py-1 rounded">/r/AFFCODE</code>.</p>
                  <p>• Cookie window: <strong>90 days</strong> (last-click attribution).</p>
                  <p>• If a <strong>promotion code</strong> mapped to you is used at checkout, it takes precedence (if enabled).</p>
                </CardContent>
              </Card>

              {/* 4. Commission & Payment */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <DollarSign className="h-5 w-5 text-primary" />
                    4. Commission & Payment
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <p>• Default commission: <strong>30% recurring</strong> of net subscription revenue (after discounts, taxes, refunds, chargebacks).</p>
                  <p>• Plan overrides may apply (e.g., Elite 25%).</p>
                  <p>• No commission on free trials ($0).</p>
                  <p>• Hold period: <strong>14 days</strong> after payment before commission becomes payable.</p>
                  <p>• Minimum payout threshold: <strong>$100</strong> (configurable).</p>
                  <p>• Payout methods: Bank/UPI/Crypto (as available).</p>
                  <p>• Payouts are processed after requested and approved; fees (if any) may be deducted.</p>
                </CardContent>
              </Card>

              {/* 5. Refunds, Chargebacks, Adjustments */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Clock className="h-5 w-5 text-primary" />
                    5. Refunds, Chargebacks, Adjustments
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <p>• If a payment is refunded/voided/charged-back, the related commission is <strong>reversed</strong> via negative adjustment.</p>
                  <p>• Prorated upgrades/downgrades are reflected in subsequent invoices/commissions.</p>
                </CardContent>
              </Card>

              {/* 6. Prohibited Activities */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <XCircle className="h-5 w-5 text-destructive" />
                    6. Prohibited Activities
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <p>• Self-referrals (same person, same payment source), coupon stacking abuse.</p>
                  <p>• Misleading claims (income guarantees, false endorsements).</p>
                  <p>• Spam, cookie-stuffing, forced clicks, or ad fraud.</p>
                  <p>• Bidding on our brand keywords ("PipTrackr.com", "PipTrackr", misspellings) without written permission.</p>
                  <p>• Using our trademarks in domain names, social handles, or deceptive pages.</p>
                  <p>• Any activity violating applicable laws/regulations.</p>
                </CardContent>
              </Card>

              {/* 7. Compliance & Disclosures */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Shield className="h-5 w-5 text-primary" />
                    7. Compliance & Disclosures
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <p>• You must clearly disclose affiliate relationships per FTC/ASA/local laws (e.g., "I may earn a commission…").</p>
                  <p>• Only use approved brand assets from the <strong>Creatives</strong> section.</p>
                  <p>• We may request edits/removals of non-compliant content.</p>
                </CardContent>
              </Card>

              {/* 8. Termination */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <AlertCircle className="h-5 w-5 text-primary" />
                    8. Termination
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <p>• We may pause or terminate affiliate accounts for violations, inactivity, or risk concerns.</p>
                  <p>• Outstanding <strong>approved</strong> commissions will be paid if not tied to fraud or refunds.</p>
                </CardContent>
              </Card>

              {/* 9. Data & Privacy */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Shield className="h-5 w-5 text-primary" />
                    9. Data & Privacy
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <p>• Cookies and tracking events are used for attribution.</p>
                  <p>• See our <Link to="/privacy" className="text-primary hover:underline">Privacy Policy</Link> for data practices.</p>
                  <p>• You must comply with data protection laws when handling user data.</p>
                </CardContent>
              </Card>

              {/* 10. Changes */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <FileText className="h-5 w-5 text-primary" />
                    10. Changes
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <p>• We may update these terms; continued participation constitutes acceptance.</p>
                  <p>• Material changes will be announced via email or dashboard notices.</p>
                </CardContent>
              </Card>

              {/* Contact */}
              <Card className="bg-primary/5 border-primary/20">
                <CardContent className="pt-6">
                  <div className="flex items-center gap-2 mb-3">
                    <Mail className="h-5 w-5 text-primary" />
                    <h3 className="font-semibold">Questions?</h3>
                  </div>
                  <p className="text-muted-foreground">
                    Contact us at <a href="mailto:support@piptrakr.com" className="text-primary hover:underline">support@piptrakr.com</a> or via the dashboard.
                  </p>
                </CardContent>
              </Card>
              
            </div>
          </div>
        </div>
      </div>
    </>
  );
}