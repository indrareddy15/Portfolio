import { useState, useCallback, useEffect, Suspense, lazy } from "react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { AlertCircle, TrendingUp, TrendingDown, Users, Activity, DollarSign, Percent, Target, BarChart3, ChartLine, RefreshCw, Wifi, WifiOff } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useRealTimeMarketData } from "@/hooks/useRealTimeMarketData";
import { HeroSection } from "@/components/HeroSection";
import { FeaturesSection } from "@/components/FeaturesSection";
import { IntegrationsSection } from "@/components/IntegrationsSection";
import { PricingSection } from "@/components/PricingSection";
import { Footer } from "@/components/Footer";
import { SEOHead } from "@/components/SEOHead";
import { Navigation } from "@/components/Navigation";
import { ConsentBanner } from "@/components/ConsentBanner";
import { NotificationBanner } from "@/components/NotificationBanner";
import { AffiliateTopStrip } from "@/components/AffiliateTopStrip";
import { Link } from "react-router-dom";
import { useNavigate } from "react-router-dom";

// Lazy load components for better performance
const AffiliateEarnSection = lazy(() => import("@/components/AffiliateEarnSection").then(m => ({ default: m.AffiliateEarnSection })));

// Loading skeleton component
const SectionSkeleton = () => (
  <div className="py-20">
    <div className="container mx-auto px-4">
      <div className="animate-pulse space-y-8">
        <div className="h-12 bg-muted rounded-lg w-1/3 mx-auto"></div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {[1, 2, 3].map(i => (
            <div key={i} className="h-32 bg-muted rounded-lg"></div>
          ))}
        </div>
      </div>
    </div>
  </div>
);

export default function Index() {
  const { toast } = useToast();
  const navigate = useNavigate();
  const handleAffiliateReferral = useCallback(() => {}, []);
  const isAffiliateEnabled = false;
  
  // Real-time market data
  const { 
    marketData, 
    isLoading: marketLoading, 
    isConnected, 
    lastUpdate,
    refresh,
    connectionStatus
  } = useRealTimeMarketData({
    symbols: ['EURUSD', 'GBPUSD', 'USDJPY', 'SPX', 'NDX'],
    updateInterval: 10000, // 10 seconds (lighter)
    enableWebSocket: false
  });

  const [platformStats, setPlatformStats] = useState({
    totalUsers: 12847,
    activeTrades: 1429,
    totalVolume: 2847329,
    successRate: 78.3
  });

  // Update platform stats simulation
  const updatePlatformStats = useCallback(() => {
    setPlatformStats(prev => ({
      totalUsers: prev.totalUsers + Math.floor(Math.random() * 10),
      activeTrades: prev.activeTrades + Math.floor(Math.random() * 20) - 10,
      totalVolume: prev.totalVolume + Math.floor(Math.random() * 10000),
      successRate: Math.max(70, Math.min(85, prev.successRate + (Math.random() - 0.5) * 2))
    }));
  }, []);

  useEffect(() => {
    // Handle affiliate referrals on page load only if affiliate program is enabled
    if (isAffiliateEnabled) {
      handleAffiliateReferral();
    }
  }, [isAffiliateEnabled]);

  // Auto-update platform stats every 30 seconds
  useEffect(() => {
    const interval = setInterval(() => {
      updatePlatformStats();
    }, 30000);
    return () => clearInterval(interval);
  }, [updatePlatformStats]);

  const refreshAllData = () => {
    refresh();
    updatePlatformStats();
    toast({
      title: "Data Refreshed",
      description: "All real-time data has been updated",
      duration: 2000,
    });
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-muted/5 to-primary/5">
      <SEOHead 
        title="Free Forex Trading Journal & Analytics Platform | PipTrackr.com"
        description="Professional forex trading journal for MT4, MT5 & prop firm traders. Track performance, analyze trades, and boost your success rate. 100% FREE forever."
        keywords="forex trading journal, mt4 journal, mt5 journal, prop firm tracker, trading analytics, forex dashboard, trading performance, free trading journal"
        canonical="https://piptrakr.com"
      />
      
      <NotificationBanner location="website" />
      {isAffiliateEnabled && <AffiliateTopStrip />}
      <Navigation />
      
      <main>
        {/* Hero Section */}
        <section aria-label="Main Hero" className="relative">
          <Suspense fallback={<SectionSkeleton />}>
            <HeroSection />
          </Suspense>
        </section>

        {/* Stats Overview Section */}
        <section className="py-16 sm:py-20 relative">
          <div className="container mx-auto px-4 sm:px-6 lg:px-8 max-w-7xl">
            <div className="text-center mb-12 sm:mb-16">
              <h2 className="text-2xl sm:text-3xl md:text-4xl font-poppins font-bold mb-4 sm:mb-6">
                Real-time Trading
                <span className="bg-gradient-primary bg-clip-text text-transparent ml-2">
                  Intelligence
                </span>
              </h2>
              <p className="text-base sm:text-lg text-muted-foreground max-w-2xl mx-auto mb-6">
                Monitor live market data and platform statistics updated in real-time
              </p>
              <div className="flex items-center justify-center gap-2 mb-8">
                <Button 
                  variant="outline" 
                  size="sm" 
                  onClick={refreshAllData}
                  className="gap-2"
                >
                  <RefreshCw className="h-4 w-4" />
                  Refresh Data
                </Button>
                <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg border text-sm">
                  {isConnected ? (
                    <>
                      <Wifi className="h-4 w-4 text-success animate-pulse" />
                      <span className="text-success font-medium">LIVE</span>
                    </>
                  ) : (
                    <>
                      <WifiOff className="h-4 w-4 text-danger" />
                      <span className="text-danger font-medium">OFFLINE</span>
                    </>
                  )}
                </div>
              </div>
            </div>

            {/* Platform Statistics */}
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6 mb-12">
              <Card className="transition-all duration-200 hover:shadow-lg hover:scale-105 bg-card/80 backdrop-blur-sm">
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Active Users</CardTitle>
                  <Users className="h-4 w-4 text-primary" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-primary">
                    {platformStats.totalUsers.toLocaleString()}
                  </div>
                  <p className="text-xs text-muted-foreground">
                    Traders worldwide
                  </p>
                </CardContent>
              </Card>

              <Card className="transition-all duration-200 hover:shadow-lg hover:scale-105 bg-card/80 backdrop-blur-sm">
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Live Trades</CardTitle>
                  <Activity className="h-4 w-4 text-secondary" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-secondary">
                    {platformStats.activeTrades.toLocaleString()}
                  </div>
                  <p className="text-xs text-muted-foreground">
                    Currently active
                  </p>
                </CardContent>
              </Card>

              <Card className="transition-all duration-200 hover:shadow-lg hover:scale-105 bg-card/80 backdrop-blur-sm">
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Trading Volume</CardTitle>
                  <BarChart3 className="h-4 w-4 text-accent" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-accent">
                    ${(platformStats.totalVolume / 1000000).toFixed(1)}M
                  </div>
                  <p className="text-xs text-muted-foreground">
                    Monthly volume tracked
                  </p>
                </CardContent>
              </Card>

              <Card className="transition-all duration-200 hover:shadow-lg hover:scale-105 bg-card/80 backdrop-blur-sm">
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Success Rate</CardTitle>
                  <Target className="h-4 w-4 text-success" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-success">
                    {platformStats.successRate.toFixed(1)}%
                  </div>
                  <p className="text-xs text-muted-foreground">
                    Average win rate
                  </p>
                </CardContent>
              </Card>
            </div>

            {/* Live Market Data */}
            <Card className="glass-card border-card-border">
              <CardHeader className="flex flex-row items-center justify-between pb-2">
                <CardTitle className="text-lg font-semibold">Live Market Data</CardTitle>
                <div className="flex items-center gap-2">
                  {/* Connection Status */}
                  <div className="flex items-center gap-1.5 px-2 py-1 rounded-lg border text-xs">
                    {isConnected ? (
                      <>
                        <Wifi className="h-3 w-3 text-success animate-pulse" />
                        <span className="text-success font-medium">LIVE</span>
                      </>
                    ) : (
                      <>
                        <WifiOff className="h-3 w-3 text-danger" />
                        <span className="text-danger font-medium">OFFLINE</span>
                      </>
                    )}
                  </div>
                  <Button 
                    variant="ghost" 
                    size="sm" 
                    onClick={refresh}
                    disabled={marketLoading}
                    className="h-8 w-8 p-0"
                  >
                    <RefreshCw className={`h-4 w-4 ${marketLoading ? 'animate-spin' : ''}`} />
                  </Button>
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                {marketLoading && Object.keys(marketData).length === 0 ? (
                  <div className="text-center py-4 text-muted-foreground">
                    <Activity className="h-8 w-8 mx-auto mb-2 animate-pulse" />
                    Loading market data...
                  </div>
                ) : (
                  <>
                    {/* Forex Pairs */}
                    <div className="space-y-2">
                      <h4 className="text-sm font-medium text-muted-foreground">FOREX</h4>
                      {['EURUSD', 'GBPUSD', 'USDJPY'].map(pair => {
                        const data = marketData[pair];
                        if (!data) return null;
                        
                        const formatted = {
                          value: data.price.toFixed(pair === 'USDJPY' ? 3 : 5),
                          change: data.changePercent >= 0 ? `+${data.changePercent.toFixed(2)}%` : `${data.changePercent.toFixed(2)}%`,
                          isPositive: data.changePercent >= 0
                        };

                        return (
                          <div key={pair} className="flex items-center justify-between py-1">
                            <span className="font-medium">{pair}</span>
                            <div className="text-right">
                              <div className="font-mono text-sm">{formatted.value}</div>
                              <div className={`text-xs ${formatted.isPositive ? 'text-success' : 'text-destructive'}`}>
                                {formatted.change}
                              </div>
                            </div>
                          </div>
                        );
                      })}
                    </div>

                    {/* Indices */}
                    <div className="space-y-2 pt-2 border-t border-border/50">
                      <h4 className="text-sm font-medium text-muted-foreground">INDICES</h4>
                      {['SPX', 'NDX'].map(index => {
                        const data = marketData[index];
                        if (!data) return null;
                        
                        const formatted = {
                          value: data.price.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 }),
                          change: data.changePercent >= 0 ? `+${data.changePercent.toFixed(2)}%` : `${data.changePercent.toFixed(2)}%`,
                          isPositive: data.changePercent >= 0
                        };

                        return (
                          <div key={index} className="flex items-center justify-between py-1">
                            <span className="font-medium">{index === 'SPX' ? 'S&P 500' : 'NASDAQ'}</span>
                            <div className="text-right">
                              <div className="font-mono text-sm">{formatted.value}</div>
                              <div className={`text-xs ${formatted.isPositive ? 'text-success' : 'text-destructive'}`}>
                                {formatted.change}
                              </div>
                            </div>
                          </div>
                        );
                      })}
                    </div>

                    {/* Last Update */}
                    <div className="pt-2 border-t border-border/50">
                      <div className="flex items-center justify-between text-xs text-muted-foreground">
                        <span>Last updated</span>
                        <span>{lastUpdate ? lastUpdate.toLocaleTimeString() : 'Never'}</span>
                      </div>
                      <div className="text-xs text-muted-foreground mt-1">
                        Status: {connectionStatus.message}
                      </div>
                    </div>
                  </>
                )}
              </CardContent>
            </Card>

            {/* Free Features Highlight */}
            <div className="mt-16 text-center">
              <div className="bg-gradient-to-r from-success/10 to-primary/10 border border-success/20 rounded-2xl p-6 sm:p-8 max-w-4xl mx-auto">
                <h3 className="text-xl sm:text-2xl font-bold text-success mb-4">
                  🎉 Everything is 100% FREE Forever!
                </h3>
                <p className="text-muted-foreground mb-6">
                  No credit card required • No hidden fees • No premium plans • Full access to all features
                </p>
                <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
                  <Button 
                    variant="primary" 
                    size="lg" 
                    className="glow-hover"
                    asChild
                  >
                    <Link to="/auth">Get Started FREE Now</Link>
                  </Button>
                  <Button 
                    variant="outline" 
                    size="lg"
                    onClick={() => navigate('/app/')}
                  >
                    View Demo Dashboard
                  </Button>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Features Section */}
        <section aria-label="Features">
          <Suspense fallback={<SectionSkeleton />}>
            <FeaturesSection />
          </Suspense>
        </section>
        
        {/* Integrations Section */}
        <section aria-label="Platform Integrations">
          <Suspense fallback={<SectionSkeleton />}>
            <IntegrationsSection />
          </Suspense>
        </section>
        
        {/* Affiliate Section */}
        {isAffiliateEnabled && (
          <section aria-label="Affiliate Program">
            <Suspense fallback={<SectionSkeleton />}>
              <AffiliateEarnSection />
            </Suspense>
          </section>
        )}
        
        {/* Pricing Section */}
        <section aria-label="Pricing Plans">
          <Suspense fallback={<SectionSkeleton />}>
            <PricingSection />
          </Suspense>
        </section>
      </main>
      
      <Suspense fallback={<div className="h-32 bg-background" />}>
        <Footer />
      </Suspense>

    </div>
  );
};