import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { ArrowLeft, Send, CheckCircle, Users, Globe, DollarSign, AlertCircle } from "lucide-react";
import { SEOHead } from "@/components/SEOHead";
import { Link } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/useAuth";

export default function AffiliateApply() {
  const navigate = useNavigate();
  const { toast } = useToast();
  const { user, loading } = useAuth();
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [formData, setFormData] = useState({
    full_name: "",
    email: "",
    phone: "",
    country: "",
    website_url: "",
    platform_type: "",
    platform_url: "",
    audience_size: "",
    content_type: "",
    experience_level: "",
    previous_programs: "",
    promotion_strategy: ""
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!user) {
      toast({
        title: "Authentication Required",
        description: "Please sign in to submit an affiliate application.",
        variant: "destructive",
      });
      navigate("/auth");
      return;
    }

    setIsSubmitting(true);

    try {
      const { data, error } = await supabase
        .from('affiliate_applications')
        .insert({
          user_id: user.id,
          full_name: formData.full_name,
          email: formData.email,
          phone: formData.phone || null,
          country: formData.country,
          platform_type: formData.platform_type,
          platform_url: formData.platform_url || null,
          audience_size: formData.audience_size || null,
          content_type: formData.content_type || null,
          experience_level: formData.experience_level,
          previous_programs: formData.previous_programs || null,
          promotion_strategy: formData.promotion_strategy,
          status: 'pending'
        });

      if (error) throw error;

      toast({
        title: "Application Submitted!",
        description: "We'll review your application and get back to you within 24 hours.",
      });

      navigate("/affiliates?applied=true");
    } catch (error: any) {
      toast({
        title: "Application Failed",
        description: error.message || "There was an error submitting your application. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleChange = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  // Show loading state while checking authentication
  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-background via-background to-muted/20 flex items-center justify-center">
        <Card className="w-full max-w-md">
          <CardContent className="p-6 text-center">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto mb-4"></div>
            <p>Loading...</p>
          </CardContent>
        </Card>
      </div>
    );
  }

  // Show authentication required message if not logged in
  if (!user) {
    return (
      <>
        <SEOHead 
          title="Apply for PipTrackr.com Affiliate Program"
          description="Join our affiliate program and start earning recurring commissions. Quick application process with 24-hour approval time."
          keywords="affiliate application, trading affiliate, forex partner program"
        />
        
        <div className="min-h-screen bg-gradient-to-br from-background via-background to-muted/20 flex items-center justify-center p-6">
          <Card className="w-full max-w-md">
            <CardHeader className="text-center">
              <div className="w-12 h-12 bg-warning/10 rounded-lg flex items-center justify-center mx-auto mb-4">
                <AlertCircle className="h-6 w-6 text-warning" />
              </div>
              <CardTitle>Authentication Required</CardTitle>
              <CardDescription>
                You need to be signed in to apply for our affiliate program.
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <Button asChild className="w-full">
                <Link to="/auth">
                  Sign In to Apply
                </Link>
              </Button>
              <Button variant="outline" asChild className="w-full">
                <Link to="/affiliates">
                  <ArrowLeft className="h-4 w-4 mr-2" />
                  Back to Program Info
                </Link>
              </Button>
            </CardContent>
          </Card>
        </div>
      </>
    );
  }

  return (
    <>
      <SEOHead 
        title="Apply for PipTrackr.com Affiliate Program"
        description="Join our affiliate program and start earning recurring commissions. Quick application process with 24-hour approval time."
        keywords="affiliate application, trading affiliate, forex partner program"
      />
      
      <div className="min-h-screen bg-gradient-to-br from-background via-background to-muted/20">
        <div className="container mx-auto px-6 py-12">
          <div className="max-w-4xl mx-auto">
            {/* Header */}
            <div className="flex items-center gap-4 mb-8">
              <Button variant="outline" size="sm" asChild>
                <Link to="/affiliates">
                  <ArrowLeft className="h-4 w-4 mr-2" />
                  Back to Program
                </Link>
              </Button>
            </div>

            <div className="text-center mb-12">
              <Badge className="mb-4 bg-primary/10 text-primary hover:bg-primary/20">
                <Users className="h-4 w-4 mr-1" />
                Affiliate Application
              </Badge>
              
              <h1 className="text-4xl md:text-5xl font-bold mb-4">
                Join Our Elite
                <span className="block text-primary">Affiliate Program</span>
              </h1>
              
              <p className="text-xl text-muted-foreground max-w-2xl mx-auto leading-relaxed">
                Ready to earn substantial recurring income? Fill out the form below 
                and we'll have you approved within 24 hours.
              </p>
            </div>

            {/* Benefits Cards */}
            <div className="grid md:grid-cols-3 gap-6 mb-12">
              {[
                { icon: DollarSign, title: "Tiered Commissions", desc: "10% → 15% → 20% based on referrals" },
                { icon: Globe, title: "Global Reach", desc: "Promote to traders worldwide" },
                { icon: CheckCircle, title: "Fast Approval", desc: "Get approved within 24 hours" }
              ].map((benefit, i) => (
                <Card key={i} className="text-center p-6">
                  <CardContent className="space-y-3">
                    <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center mx-auto">
                      <benefit.icon className="h-6 w-6 text-primary" />
                    </div>
                    <h3 className="font-semibold">{benefit.title}</h3>
                    <p className="text-sm text-muted-foreground">{benefit.desc}</p>
                  </CardContent>
                </Card>
              ))}
            </div>

            {/* Application Form */}
            <Card>
              <CardHeader>
                <CardTitle>Affiliate Application Form</CardTitle>
                <CardDescription>
                  Tell us about yourself and how you plan to promote PipTrackr.com to traders.
                </CardDescription>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleSubmit} className="space-y-6">
                  {/* Personal Information */}
                  <div className="grid md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="full_name">Full Name *</Label>
                      <Input
                        id="full_name"
                        required
                        value={formData.full_name}
                        onChange={(e) => handleChange("full_name", e.target.value)}
                        placeholder="John Smith"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="email">Email Address *</Label>
                      <Input
                        id="email"
                        type="email"
                        required
                        value={formData.email}
                        onChange={(e) => handleChange("email", e.target.value)}
                        placeholder="john@example.com"
                      />
                    </div>
                  </div>

                  <div className="grid md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="phone">Phone Number</Label>
                      <Input
                        id="phone"
                        value={formData.phone}
                        onChange={(e) => handleChange("phone", e.target.value)}
                        placeholder="+1 (555) 123-4567"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="country">Country *</Label>
                      <Input
                        id="country"
                        required
                        value={formData.country}
                        onChange={(e) => handleChange("country", e.target.value)}
                        placeholder="United States"
                      />
                    </div>
                  </div>

                  {/* Platform Information */}
                  <div className="space-y-4">
                    <h3 className="text-lg font-semibold">Platform Information</h3>
                    
                    <div className="grid md:grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="platform_type">Primary Platform *</Label>
                        <Select onValueChange={(value) => handleChange("platform_type", value)}>
                          <SelectTrigger>
                            <SelectValue placeholder="Select your platform" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="website">Website/Blog</SelectItem>
                            <SelectItem value="youtube">YouTube Channel</SelectItem>
                            <SelectItem value="instagram">Instagram</SelectItem>
                            <SelectItem value="twitter">Twitter/X</SelectItem>
                            <SelectItem value="tiktok">TikTok</SelectItem>
                            <SelectItem value="linkedin">LinkedIn</SelectItem>
                            <SelectItem value="telegram">Telegram</SelectItem>
                            <SelectItem value="discord">Discord</SelectItem>
                            <SelectItem value="email">Email List</SelectItem>
                            <SelectItem value="other">Other</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                      
                      <div className="space-y-2">
                        <Label htmlFor="platform_url">Platform URL</Label>
                        <Input
                          id="platform_url"
                          value={formData.platform_url}
                          onChange={(e) => handleChange("platform_url", e.target.value)}
                          placeholder="https://yoursite.com"
                        />
                      </div>
                    </div>

                    <div className="grid md:grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="audience_size">Audience Size</Label>
                        <Select onValueChange={(value) => handleChange("audience_size", value)}>
                          <SelectTrigger>
                            <SelectValue placeholder="Select audience size" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="under_1k">Under 1,000</SelectItem>
                            <SelectItem value="1k_5k">1,000 - 5,000</SelectItem>
                            <SelectItem value="5k_10k">5,000 - 10,000</SelectItem>
                            <SelectItem value="10k_25k">10,000 - 25,000</SelectItem>
                            <SelectItem value="25k_50k">25,000 - 50,000</SelectItem>
                            <SelectItem value="50k_100k">50,000 - 100,000</SelectItem>
                            <SelectItem value="over_100k">Over 100,000</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                      
                      <div className="space-y-2">
                        <Label htmlFor="content_type">Content Type</Label>
                        <Select onValueChange={(value) => handleChange("content_type", value)}>
                          <SelectTrigger>
                            <SelectValue placeholder="Select content type" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="educational">Educational/Tutorials</SelectItem>
                            <SelectItem value="reviews">Product Reviews</SelectItem>
                            <SelectItem value="news">Trading News</SelectItem>
                            <SelectItem value="signals">Trading Signals</SelectItem>
                            <SelectItem value="community">Community/Social</SelectItem>
                            <SelectItem value="courses">Courses/Training</SelectItem>
                            <SelectItem value="other">Other</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </div>
                  </div>

                  {/* Experience */}
                  <div className="space-y-4">
                    <h3 className="text-lg font-semibold">Experience</h3>
                    
                    <div className="space-y-2">
                      <Label htmlFor="experience_level">Affiliate Marketing Experience *</Label>
                      <Select onValueChange={(value) => handleChange("experience_level", value)}>
                        <SelectTrigger>
                          <SelectValue placeholder="Select experience level" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="beginner">Beginner (0-1 years)</SelectItem>
                          <SelectItem value="intermediate">Intermediate (2-5 years)</SelectItem>
                          <SelectItem value="advanced">Advanced (5+ years)</SelectItem>
                          <SelectItem value="expert">Expert (10+ years)</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="previous_programs">Previous Affiliate Programs</Label>
                      <Textarea
                        id="previous_programs"
                        value={formData.previous_programs}
                        onChange={(e) => handleChange("previous_programs", e.target.value)}
                        placeholder="List any trading-related affiliate programs you've participated in..."
                        rows={3}
                      />
                    </div>
                  </div>

                  {/* Promotion Strategy */}
                  <div className="space-y-2">
                    <Label htmlFor="promotion_strategy">How will you promote PipTrackr.com? *</Label>
                    <Textarea
                      id="promotion_strategy"
                      required
                      value={formData.promotion_strategy}
                      onChange={(e) => handleChange("promotion_strategy", e.target.value)}
                      placeholder="Describe your marketing strategy, content plans, and target audience..."
                      rows={4}
                    />
                  </div>

                  {/* Submit */}
                  <div className="flex flex-col gap-4">
                    <Button 
                      type="submit" 
                      size="lg" 
                      disabled={isSubmitting}
                      className="w-full"
                    >
                      {isSubmitting ? (
                        "Submitting Application..."
                      ) : (
                        <>
                          Submit Application <Send className="ml-2 h-5 w-5" />
                        </>
                      )}
                    </Button>
                    
                    <p className="text-sm text-muted-foreground text-center">
                      By submitting, you agree to our{" "}
                      <Link to="/affiliates/terms" className="text-primary hover:underline">
                        Affiliate Terms
                      </Link>
                      {" "}and{" "}
                      <Link to="/privacy" className="text-primary hover:underline">
                        Privacy Policy
                      </Link>
                    </p>
                  </div>
                </form>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </>
  );
}