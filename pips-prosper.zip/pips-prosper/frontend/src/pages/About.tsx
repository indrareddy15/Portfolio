import { Navigation } from "@/components/Navigation";
import { Footer } from "@/components/Footer";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { TrendingUp, Users, Shield, Zap, Target, Award } from "lucide-react";
import { SEOHead } from "@/components/SEOHead";

const About = () => {
  const stats = [
    { label: "Active Traders", value: "10,000+", icon: Users },
    { label: "Trades Logged", value: "1M+", icon: TrendingUp },
    { label: "Countries", value: "50+", icon: Target },
    { label: "Uptime", value: "99.9%", icon: Shield }
  ];

  const team = [
    {
      name: "Sarah Johnson",
      role: "CEO & Founder",
      bio: "Former prop trader with 10+ years of experience at top-tier trading firms."
    },
    {
      name: "Michael Chen", 
      role: "CTO",
      bio: "Ex-Google engineer specializing in high-frequency trading systems and analytics."
    },
    {
      name: "David Rodriguez",
      role: "Head of Product",
      bio: "Trading psychology expert and former hedge fund risk manager."
    }
  ];

  return (
    <div className="min-h-screen bg-background">
      <SEOHead 
        title="About PipTrackr.com - 100% FREE Professional Trading Journal Platform"
        description="Learn about PipTrackr.com, the FREE trading journal platform trusted by 12,000+ traders worldwide. Our mission: provide professional trading tools completely free forever. No premium plans, no hidden costs."
        keywords="about piptrakr, free trading journal company, forex trading platform, trading journal team, free professional trading tools, free trading analytics"
        canonical="https://piptrakr.com/about"
        structuredData={{
          "@context": "https://schema.org",
          "@type": "AboutPage",
          "name": "About PipTrackr.com",
          "description": "Learn about our mission to provide 100% free professional trading journal tools",
          "url": "https://piptrakr.com/about",
          "mainEntity": {
            "@type": "Organization",
            "name": "PipTrackr.com",
            "foundingDate": "2024",
            "numberOfEmployees": "10-50"
          }
        }}
      />
      <Navigation />
      <main className="container mx-auto px-4 py-8 pt-24">
        <div className="max-w-4xl mx-auto">
          {/* Hero Section */}
          <div className="text-center mb-16">
            <Badge variant="secondary" className="mb-4">About PipTrackr.com</Badge>
            <h1 className="text-4xl font-bold tracking-tight mb-6">
              Empowering Traders Worldwide
            </h1>
            <p className="text-muted-foreground text-lg leading-relaxed">
              We're on a mission to democratize professional trading tools and help every trader 
              achieve consistent profitability through data-driven insights and psychological mastery.
            </p>
          </div>

          {/* Stats */}
          <div className="grid gap-6 md:grid-cols-4 mb-16">
            {stats.map((stat, index) => {
              const Icon = stat.icon;
              return (
                <Card key={index} className="text-center">
                  <CardContent className="pt-6">
                    <Icon className="h-8 w-8 mx-auto mb-2 text-primary" />
                    <div className="text-2xl font-bold">{stat.value}</div>
                    <div className="text-sm text-muted-foreground">{stat.label}</div>
                  </CardContent>
                </Card>
              );
            })}
          </div>

          {/* Mission */}
          <Card className="mb-16">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Target className="h-5 w-5" />
                Our Mission
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground leading-relaxed">
                At PipTrackr.com, we believe that successful trading isn't just about having the right strategy—it's about 
                understanding your psychology, managing risk effectively, and learning from every trade. Our platform 
                combines cutting-edge technology with proven trading principles to help you become a more disciplined, 
                profitable trader.
              </p>
            </CardContent>
          </Card>

          {/* Values */}
          <div className="grid gap-6 md:grid-cols-3 mb-16">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Shield className="h-5 w-5" />
                  Security First
                </CardTitle>
                <CardDescription>
                  Your data is protected with bank-grade encryption and security measures.
                </CardDescription>
              </CardHeader>
            </Card>
            
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Zap className="h-5 w-5" />
                  Innovation
                </CardTitle>
                <CardDescription>
                  We continuously innovate to bring you the latest in trading technology and analytics.
                </CardDescription>
              </CardHeader>
            </Card>
            
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Award className="h-5 w-5" />
                  Excellence
                </CardTitle>
                <CardDescription>
                  We're committed to providing the highest quality tools and support for traders.
                </CardDescription>
              </CardHeader>
            </Card>
          </div>

          {/* Team */}
          <div className="mb-16">
            <h2 className="text-3xl font-bold text-center mb-8">Meet Our Team</h2>
            <div className="grid gap-6 md:grid-cols-3">
              {team.map((member, index) => (
                <Card key={index}>
                  <CardHeader>
                    <div className="w-16 h-16 bg-gradient-primary rounded-full mx-auto mb-4"></div>
                    <CardTitle className="text-center">{member.name}</CardTitle>
                    <CardDescription className="text-center">{member.role}</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <p className="text-sm text-muted-foreground text-center">{member.bio}</p>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>

          {/* Story */}
          <Card>
            <CardHeader>
              <CardTitle>Our Story</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground leading-relaxed mb-4">
                PipTrackr.com was born from our founder's frustration with existing trading journals that lacked 
                the depth needed for serious traders. After years of trading at prop firms and seeing countless 
                talented traders fail due to poor risk management and emotional decisions, we knew there had to 
                be a better way.
              </p>
              <p className="text-muted-foreground leading-relaxed">
                Today, we're proud to be the trading journal of choice for both retail and professional traders 
                worldwide, helping them turn their trading passion into consistent profits through better 
                self-awareness and data-driven decision making.
              </p>
            </CardContent>
          </Card>
        </div>
      </main>
      <Footer />
    </div>
  );
};

export default About;