import { Navigation } from "@/components/Navigation";
import { Footer } from "@/components/Footer";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { SEOHead } from "@/components/SEOHead";

const Privacy = () => {
  return (
    <div className="min-h-screen bg-background">
      <SEOHead 
        title="Privacy Policy - FREE Trading Journal | PipTrackr.com"
        description="Read PipTrackr.com's privacy policy for our FREE trading journal. Learn how we protect your trading data with bank-grade security. Your privacy is our priority - 100% free platform."
        keywords="privacy policy, free trading journal privacy, data protection, trading data privacy, piptrakr privacy, user data security, free platform privacy"
        canonical="https://piptrakr.com/privacy"
        robots="index, follow"
        structuredData={{
          "@context": "https://schema.org",
          "@type": "WebPage", 
          "name": "Privacy Policy - PipTrackr.com",
          "description": "Privacy policy for our free trading journal platform",
          "url": "https://piptrakr.com/privacy"
        }}
      />
      <Navigation />
      <main className="container mx-auto px-4 py-6 sm:py-8 pt-20 sm:pt-24">
        <div className="max-w-4xl mx-auto">
          <header className="text-center mb-8 sm:mb-12">
            <h1 className="text-2xl sm:text-3xl lg:text-4xl font-bold tracking-tight mb-3 sm:mb-4">Privacy Policy</h1>
            <p className="text-muted-foreground text-sm sm:text-base">
              Last updated: {new Date().toLocaleDateString()}
            </p>
          </header>

          <div className="space-y-8">
            <Card>
              <CardHeader>
                <CardTitle>1. Information We Collect</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4 text-muted-foreground">
                  <div>
                    <h4 className="font-semibold text-foreground mb-2">Account Information</h4>
                    <p>When you create an account, we collect your email address, name, and password.</p>
                  </div>
                  <div>
                    <h4 className="font-semibold text-foreground mb-2">Trading Data</h4>
                    <p>We collect the trading information you choose to input, including trade details, strategies, and performance metrics.</p>
                  </div>
                  <div>
                    <h4 className="font-semibold text-foreground mb-2">Usage Information</h4>
                    <p>We automatically collect information about how you use our service, including page views, feature usage, and session duration.</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>2. How We Use Your Information</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4 text-muted-foreground">
                  <p>We use your information to:</p>
                  <ul className="space-y-2">
                    <li>• Provide and maintain our trading journal service</li>
                    <li>• Generate analytics and insights from your trading data</li>
                    <li>• Communicate with you about your account and our service</li>
                    <li>• Improve our service and develop new features</li>
                    <li>• Ensure the security and integrity of our platform</li>
                    <li>• Comply with legal obligations</li>
                  </ul>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>3. Information Sharing</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4 text-muted-foreground">
                  <p className="font-semibold text-foreground">We do not sell, trade, or rent your personal information to third parties.</p>
                  <p>We may share your information only in these limited circumstances:</p>
                  <ul className="space-y-2">
                    <li>• With your explicit consent</li>
                    <li>• To comply with legal obligations or court orders</li>
                    <li>• To protect our rights, property, or safety, or that of our users</li>
                    <li>• With service providers who help us operate our platform (under strict confidentiality agreements)</li>
                    <li>• In connection with a merger, acquisition, or sale of assets (with prior notice)</li>
                  </ul>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>4. Data Security</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4 text-muted-foreground">
                  <p>We implement appropriate security measures to protect your personal information:</p>
                  <ul className="space-y-2">
                    <li>• All data is encrypted in transit using TLS 1.3</li>
                    <li>• Data at rest is encrypted using AES-256 encryption</li>
                    <li>• Regular security audits and penetration testing</li>
                    <li>• Access controls and authentication requirements</li>
                    <li>• Secure cloud infrastructure with redundant backups</li>
                  </ul>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>5. Your Rights and Choices</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4 text-muted-foreground">
                  <p>You have the following rights regarding your personal information:</p>
                  <ul className="space-y-2">
                    <li>• <strong>Access:</strong> Request a copy of your personal data</li>
                    <li>• <strong>Correction:</strong> Update or correct inaccurate information</li>
                    <li>• <strong>Deletion:</strong> Request deletion of your personal data</li>
                    <li>• <strong>Portability:</strong> Export your data in a portable format</li>
                    <li>• <strong>Restriction:</strong> Limit how we process your data</li>
                    <li>• <strong>Objection:</strong> Object to certain processing activities</li>
                  </ul>
                  <p className="mt-4">
                    To exercise these rights, please contact us at privacy@piptrakr.com
                  </p>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>6. Data Retention</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4 text-muted-foreground">
                  <p>
                    We retain your personal information for as long as necessary to provide our services and fulfill the purposes outlined in this policy.
                  </p>
                  <p>
                    When you delete your account, we will delete your personal information within 30 days, except where we are required to retain it for legal or regulatory purposes.
                  </p>
                  <p>
                    Aggregated and anonymized data may be retained for analytical purposes.
                  </p>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>7. Cookies and Tracking</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4 text-muted-foreground">
                  <p>We use cookies and similar technologies to:</p>
                  <ul className="space-y-2">
                    <li>• Remember your preferences and settings</li>
                    <li>• Authenticate your sessions</li>
                    <li>• Analyze usage patterns and improve our service</li>
                    <li>• Provide security features</li>
                  </ul>
                  <p>
                    You can control cookie settings through your browser preferences. Note that disabling cookies may affect the functionality of our service.
                  </p>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>8. International Data Transfers</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground">
                  Your information may be transferred to and processed in countries other than your own. We ensure that such transfers comply with applicable data protection laws and implement appropriate safeguards to protect your information.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>9. Children's Privacy</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground">
                  Our service is not intended for children under 18 years of age. We do not knowingly collect personal information from children under 18. If you become aware that a child has provided us with personal information, please contact us immediately.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>10. Changes to This Policy</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground">
                  We may update this Privacy Policy from time to time. We will notify you of any material changes by posting the new policy on this page and updating the "Last updated" date. We encourage you to review this policy periodically.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>11. Contact Us</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-muted-foreground">
                  <p>If you have any questions about this Privacy Policy, please contact us:</p>
                  <div className="mt-4 space-y-1">
                    <p>Email: privacy@piptrakr.com</p>
                    <p>Address: 123 Trading Street, Financial District, New York, NY 10004</p>
                    <p>Phone: +1 (555) 123-4567</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
};

export default Privacy;