import { useState, useEffect } from "react";
import { useSearchParams, Link } from "react-router-dom";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { SEOHead } from "@/components/SEOHead";
import { Navigation } from "@/components/Navigation";
import { Footer } from "@/components/Footer";
import { supabase } from "@/integrations/supabase/client";
import { Calendar, Clock, User, Search, ChevronLeft, ChevronRight } from "lucide-react";

interface BlogPost {
  id: string;
  title: string;
  slug: string;
  excerpt: string;
  cover_url?: string;
  reading_time: number;
  publish_at: string;
  category: {
    name: string;
    slug: string;
  } | null;
  author: {
    name: string;
    slug: string;
    avatar_url?: string;
  } | null;
  tags: Array<{
    name: string;
    slug: string;
  }>;
}

interface BlogCategory {
  id: string;
  name: string;
  slug: string;
  description?: string;
}

interface BlogTag {
  id: string;
  name: string;
  slug: string;
}

export default function Blog() {
  const [searchParams, setSearchParams] = useSearchParams();
  const [posts, setPosts] = useState<BlogPost[]>([]);
  const [categories, setCategories] = useState<BlogCategory[]>([]);
  const [tags, setTags] = useState<BlogTag[]>([]);
  const [loading, setLoading] = useState(true);
  const [totalPosts, setTotalPosts] = useState(0);
  
  const searchQuery = searchParams.get("search") || "";
  const categoryFilter = searchParams.get("category") || "";
  const tagFilter = searchParams.get("tag") || "";
  const currentPage = parseInt(searchParams.get("page") || "1");
  const postsPerPage = 12;

  useEffect(() => {
    fetchBlogData();
  }, [searchParams]);

  // Realtime updates for public blog list
  useEffect(() => {
    const channel = supabase
      .channel('blog-posts-public')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'blog_posts' }, () => {
        fetchBlogData();
      })
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, []);

  const fetchBlogData = async () => {
    setLoading(true);
    
    try {
      // Build query for posts
      const nowIso = new Date().toISOString();
      let query = supabase
        .from('blog_posts')
        .select(`
          id,
          title,
          slug,
          excerpt,
          cover_url,
          reading_time,
          publish_at,
          category:blog_categories(name, slug),
          author:blog_authors(name, slug, avatar_url),
          blog_post_tags(
            tag:blog_tags(name, slug)
          )
        `)
        .eq('status', 'published')
        .or(`publish_at.is.null,publish_at.lte.${nowIso}`)
        .order('publish_at', { ascending: false });

      // Apply filters
      if (searchQuery) {
        query = query.or(`title.ilike.%${searchQuery}%,excerpt.ilike.%${searchQuery}%`);
      }

      if (categoryFilter) {
        const { data: categoryData } = await supabase
          .from('blog_categories')
          .select('id')
          .eq('slug', categoryFilter)
          .single();
        
        if (categoryData) {
          query = query.eq('category_id', categoryData.id);
        }
      }

      if (tagFilter) {
        const { data: tagData } = await supabase
          .from('blog_tags')
          .select('id')
          .eq('slug', tagFilter)
          .single();
        
        if (tagData) {
          const { data: postTags } = await supabase
            .from('blog_post_tags')
            .select('post_id')
            .eq('tag_id', tagData.id);
          
          if (postTags && postTags.length > 0) {
            const postIds = postTags.map(pt => pt.post_id);
            query = query.in('id', postIds);
          }
        }
      }

      // Get total count for pagination
      const { count } = await supabase
        .from('blog_posts')
        .select('*', { count: 'exact', head: true })
        .eq('status', 'published')
        .or(`publish_at.is.null,publish_at.lte.${nowIso}`);
      setTotalPosts(count || 0);

      // Get paginated results
      const { data: postsData } = await query
        .range((currentPage - 1) * postsPerPage, currentPage * postsPerPage - 1);

      // Transform data
      const transformedPosts = postsData?.map(post => ({
        ...post,
        tags: post.blog_post_tags?.map((pt: any) => pt.tag) || []
      })) || [];

      setPosts(transformedPosts);

      // Fetch categories and tags for filters
      const [{ data: categoriesData }, { data: tagsData }] = await Promise.all([
        supabase.from('blog_categories').select('*').order('name'),
        supabase.from('blog_tags').select('*').order('name')
      ]);

      setCategories(categoriesData || []);
      setTags(tagsData || []);
      
    } catch (error) {
      console.error('Error fetching blog data:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleSearch = (query: string) => {
    const newParams = new URLSearchParams(searchParams);
    if (query) {
      newParams.set("search", query);
    } else {
      newParams.delete("search");
    }
    newParams.delete("page");
    setSearchParams(newParams);
  };

  const handleFilter = (type: string, value: string) => {
    const newParams = new URLSearchParams(searchParams);
    if (value) {
      newParams.set(type, value);
    } else {
      newParams.delete(type);
    }
    newParams.delete("page");
    setSearchParams(newParams);
  };

  const handlePageChange = (page: number) => {
    const newParams = new URLSearchParams(searchParams);
    newParams.set("page", page.toString());
    setSearchParams(newParams);
  };

  const totalPages = Math.ceil(totalPosts / postsPerPage);

  return (
    <div className="min-h-screen bg-background">
      <SEOHead
        title="FREE Trading Blog - Insights & Education | PipTrackr.com"
        description="Discover FREE trading insights, strategies, and educational content from PipTrackr. Learn from expert traders and improve your trading performance with our comprehensive blog articles."
        keywords="free trading blog, forex education, trading strategies, market analysis, trading tips, free trading education, forex blog, trading insights"
        canonical="https://piptrakr.com/blog"
        structuredData={{
          "@context": "https://schema.org",
          "@type": "Blog",
          "name": "PipTrackr Trading Blog",
          "description": "Free trading insights and educational content for forex traders",
          "url": "https://piptrakr.com/blog",
          "publisher": {
            "@type": "Organization",
            "name": "PipTrackr.com"
          }
        }}
      />
      
      <Navigation />
      
      <main className="container mx-auto px-4 py-8 pt-24 max-w-6xl">
        {/* Header */}
        <header className="text-center mb-12 lg:mb-16">
          <h1 className="text-3xl sm:text-4xl lg:text-5xl font-bold tracking-tight mb-4 lg:mb-6">
            FREE Trading Insights & Education
          </h1>
          <p className="text-muted-foreground text-base sm:text-lg lg:text-xl leading-relaxed max-w-2xl mx-auto px-4 sm:px-0">
            Discover expert trading strategies, market analysis, and educational content to enhance your trading journey - completely FREE.
          </p>
        </header>

        {/* Search and Filters */}
        <section className="mb-6 lg:mb-8 space-y-4" aria-label="Blog filters">
          <div className="flex flex-col md:flex-row gap-3 lg:gap-4">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground w-4 h-4" />
              <Input
                placeholder="Search free trading articles..."
                value={searchQuery}
                onChange={(e) => handleSearch(e.target.value)}
                className="pl-10 text-sm sm:text-base"
                aria-label="Search blog articles"
              />
            </div>
            
            <select
              value={categoryFilter}
              onChange={(e) => handleFilter("category", e.target.value)}
              className="px-3 py-2 border border-input rounded-md bg-background text-sm sm:text-base min-w-[140px]"
              aria-label="Filter by category"
            >
              <option value="">All Categories</option>
              {categories.map(category => (
                <option key={category.slug} value={category.slug}>
                  {category.name}
                </option>
              ))}
            </select>
            
            <select
              value={tagFilter}
              onChange={(e) => handleFilter("tag", e.target.value)}
              className="px-3 py-2 border border-input rounded-md bg-background text-sm sm:text-base min-w-[120px]"
              aria-label="Filter by tag"
            >
              <option value="">All Tags</option>
              {tags.map(tag => (
                <option key={tag.slug} value={tag.slug}>
                  {tag.name}
                </option>
              ))}
            </select>
          </div>

          {/* Active Filters */}
          <div className="flex flex-wrap gap-2">
            {searchQuery && (
              <Badge variant="secondary" className="flex items-center gap-1">
                Search: "{searchQuery}"
                <button onClick={() => handleSearch("")} className="ml-1 hover:text-destructive">×</button>
              </Badge>
            )}
            {categoryFilter && (
              <Badge variant="secondary" className="flex items-center gap-1">
                Category: {categories.find(c => c.slug === categoryFilter)?.name}
                <button onClick={() => handleFilter("category", "")} className="ml-1 hover:text-destructive">×</button>
              </Badge>
            )}
            {tagFilter && (
              <Badge variant="secondary" className="flex items-center gap-1">
                Tag: {tags.find(t => t.slug === tagFilter)?.name}
                <button onClick={() => handleFilter("tag", "")} className="ml-1 hover:text-destructive">×</button>
              </Badge>
            )}
          </div>
        </section>

        {/* Posts Grid */}
        {loading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-6">
            {[...Array(6)].map((_, i) => (
              <Card key={i} className="animate-pulse">
                <div className="aspect-video bg-muted"></div>
                <CardContent className="p-3 sm:p-4">
                  <div className="h-4 bg-muted rounded mb-2"></div>
                  <div className="h-4 bg-muted rounded mb-4 w-3/4"></div>
                  <div className="flex justify-between">
                    <div className="h-3 bg-muted rounded w-20"></div>
                    <div className="h-3 bg-muted rounded w-16"></div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        ) : posts.length === 0 ? (
          <div className="text-center py-8 sm:py-12">
            <h3 className="text-xl sm:text-2xl font-semibold text-muted-foreground mb-4">
              No articles found
            </h3>
            <p className="text-muted-foreground mb-6 text-sm sm:text-base">
              Try adjusting your search or filter criteria.
            </p>
            <Button 
              variant="outline" 
              onClick={() => {
                setSearchParams(new URLSearchParams());
              }}
            >
              Clear all filters
            </Button>
          </div>
        ) : (
          <>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-6 mb-8">
              {posts.map((post) => (
                <Card key={post.id} className="overflow-hidden hover:shadow-lg transition-shadow">
                  <Link to={`/blog/${post.slug}`}>
                    {post.cover_url && (
                      <div className="aspect-video overflow-hidden">
                        <img 
                          src={post.cover_url}
                          alt={`${post.title} - FREE Trading Education`}
                          className="w-full h-full object-cover hover:scale-105 transition-transform duration-300"
                          loading="lazy"
                          width="400"
                          height="225"
                        />
                      </div>
                    )}
                    
                    <CardContent className="p-3 sm:p-4">
                      <div className="flex items-center gap-2 mb-2">
                        <Badge variant="secondary" className="text-xs">
                          {post.category?.name || 'Uncategorized'}
                        </Badge>
                        <span className="text-xs text-muted-foreground flex items-center gap-1">
                          <Clock className="w-3 h-3" />
                          {post.reading_time} min read
                        </span>
                      </div>
                      
                      <h3 className="font-semibold text-base sm:text-lg mb-2 line-clamp-2 hover:text-primary transition-colors">
                        {post.title}
                      </h3>
                      
                      {post.excerpt && (
                        <p className="text-muted-foreground text-xs sm:text-sm mb-4 line-clamp-3">
                          {post.excerpt}
                        </p>
                      )}
                      
                      <div className="flex items-center justify-between text-xs text-muted-foreground">
                        <div className="flex items-center gap-2">
                          {post.author?.avatar_url && (
                            <img 
                              src={post.author.avatar_url}
                              alt={`${post.author.name} - Author`}
                              className="w-5 h-5 sm:w-6 sm:h-6 rounded-full"
                              width="24"
                              height="24"
                            />
                          )}
                          <span className="truncate">{post.author?.name || 'Unknown Author'}</span>
                        </div>
                        <div className="flex items-center gap-1 flex-shrink-0">
                          <Calendar className="w-3 h-3" />
                          <span className="hidden sm:inline">
                            {new Date(post.publish_at).toLocaleDateString('en-US', { 
                              year: 'numeric', 
                              month: 'short', 
                              day: 'numeric' 
                            })}
                          </span>
                          <span className="sm:hidden">
                            {new Date(post.publish_at).toLocaleDateString('en-US', { 
                              month: 'short', 
                              day: 'numeric' 
                            })}
                          </span>
                        </div>
                      </div>
                      
                      {post.tags.length > 0 && (
                        <div className="flex flex-wrap gap-1 mt-3">
                          {post.tags.slice(0, 3).map(tag => (
                            <Badge 
                              key={tag.slug} 
                              variant="outline" 
                              className="text-xs"
                            >
                              {tag.name}
                            </Badge>
                          ))}
                          {post.tags.length > 3 && (
                            <Badge variant="outline" className="text-xs">
                              +{post.tags.length - 3} more
                            </Badge>
                          )}
                        </div>
                      )}
                    </CardContent>
                  </Link>
                </Card>
              ))}
            </div>

            {/* Pagination */}
            {totalPages > 1 && (
              <nav className="flex items-center justify-center space-x-2" aria-label="Blog pagination">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => handlePageChange(currentPage - 1)}
                  disabled={currentPage <= 1}
                  aria-label="Previous page"
                >
                  <ChevronLeft className="w-4 h-4 mr-1" />
                  <span className="hidden sm:inline">Previous</span>
                </Button>
                
                <div className="flex items-center space-x-1">
                  {Array.from({ length: Math.min(5, totalPages) }, (_, i) => {
                    let pageNum;
                    if (totalPages <= 5) {
                      pageNum = i + 1;
                    } else if (currentPage <= 3) {
                      pageNum = i + 1;
                    } else if (currentPage >= totalPages - 2) {
                      pageNum = totalPages - 4 + i;
                    } else {
                      pageNum = currentPage - 2 + i;
                    }

                    return (
                      <Button
                        key={pageNum}
                        variant={currentPage === pageNum ? "default" : "outline"}
                        size="sm"
                        onClick={() => handlePageChange(pageNum)}
                        className="w-8 h-8 p-0"
                        aria-label={`Page ${pageNum}`}
                      >
                        {pageNum}
                      </Button>
                    );
                  })}
                </div>
                
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => handlePageChange(currentPage + 1)}
                  disabled={currentPage >= totalPages}
                  aria-label="Next page"
                >
                  <span className="hidden sm:inline">Next</span>
                  <ChevronRight className="w-4 h-4 ml-1" />
                </Button>
              </nav>
            )}
          </>
        )}

        {/* Newsletter Section */}
        <section className="bg-card border rounded-lg p-6 sm:p-8 mt-12 text-center">
          <h2 className="text-xl sm:text-2xl font-semibold mb-3">
            Get FREE Trading Insights Delivered
          </h2>
          <p className="text-muted-foreground mb-6">
            Subscribe to receive our latest FREE trading articles, strategies, and market analysis directly in your inbox.
          </p>
          <div className="flex flex-col sm:flex-row gap-3 justify-center max-w-md mx-auto">
            <Input 
              type="email" 
              placeholder="Enter your email" 
              className="flex-1"
              aria-label="Email address for newsletter"
            />
            <Button>
              Subscribe FREE
            </Button>
          </div>
          <p className="text-xs text-muted-foreground mt-3">
            100% Free. No spam. Unsubscribe anytime.
          </p>
        </section>
      </main>
      
      <Footer />
    </div>
  );
}