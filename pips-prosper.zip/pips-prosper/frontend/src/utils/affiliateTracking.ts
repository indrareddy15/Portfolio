import { supabase } from "@/integrations/supabase/client";

// Affiliate cookie management
const AFFILIATE_COOKIE_NAME = 'pj_aff';
const COOKIE_DURATION_DAYS = 90;

export interface AffiliateData {
  affiliate_id: string;
  affiliate_code: string;
  utm?: {
    utm_source?: string;
    utm_medium?: string;
    utm_campaign?: string;
    utm_content?: string;
    utm_term?: string;
  };
  timestamp: number;
}

// Set affiliate cookie with 90-day expiry
export function setAffiliateCookie(data: AffiliateData) {
  const cookieData = {
    ...data,
    timestamp: Date.now()
  };
  
  const expires = new Date();
  expires.setTime(expires.getTime() + (COOKIE_DURATION_DAYS * 24 * 60 * 60 * 1000));
  
  document.cookie = `${AFFILIATE_COOKIE_NAME}=${encodeURIComponent(JSON.stringify(cookieData))}; expires=${expires.toUTCString()}; path=/; SameSite=Lax`;
  
  console.log('Affiliate cookie set:', cookieData);
}

// Get affiliate cookie data
export function getAffiliateCookie(): AffiliateData | null {
  const cookies = document.cookie.split(';');
  const affiliateCookie = cookies.find(cookie => 
    cookie.trim().startsWith(`${AFFILIATE_COOKIE_NAME}=`)
  );
  
  if (!affiliateCookie) return null;
  
  try {
    const cookieValue = affiliateCookie.split('=')[1];
    const data = JSON.parse(decodeURIComponent(cookieValue));
    
    // Check if cookie is still valid (90 days)
    const cookieAge = Date.now() - data.timestamp;
    const maxAge = COOKIE_DURATION_DAYS * 24 * 60 * 60 * 1000;
    
    if (cookieAge > maxAge) {
      clearAffiliateCookie();
      return null;
    }
    
    return data;
  } catch (error) {
    console.error('Error parsing affiliate cookie:', error);
    clearAffiliateCookie();
    return null;
  }
}

// Clear affiliate cookie
export function clearAffiliateCookie() {
  document.cookie = `${AFFILIATE_COOKIE_NAME}=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/;`;
}

// Track affiliate click
export async function trackAffiliateClick(affiliateCode: string, utmParams?: Record<string, string>) {
  try {
    const urlParams = new URLSearchParams();
    urlParams.append('code', affiliateCode);
    
    if (utmParams) {
      Object.entries(utmParams).forEach(([key, value]) => {
        if (value) urlParams.append(key, value);
      });
    }
    
    const { data, error } = await supabase.functions.invoke('affiliate-track', {
      body: Object.fromEntries(urlParams)
    });
    
    if (error) {
      console.error('Error tracking affiliate click:', error);
      return null;
    }
    
    return data;
  } catch (error) {
    console.error('Error tracking affiliate click:', error);
    return null;
  }
}

// Process affiliate attribution after user signup
export async function processAffiliateAttribution(userId: string, promoCode?: string) {
  try {
    const affiliateData = getAffiliateCookie();
    
    if (!affiliateData && !promoCode) {
      console.log('No affiliate attribution data found');
      return null;
    }
    
    const { data, error } = await supabase.functions.invoke('affiliate-attribution', {
      body: {
        user_id: userId,
        affiliate_code: affiliateData?.affiliate_code,
        promo_code: promoCode
      }
    });
    
    if (error) {
      console.error('Error processing affiliate attribution:', error);
      return null;
    }
    
    // Clear cookie after successful attribution
    if (affiliateData) {
      clearAffiliateCookie();
    }
    
    return data;
  } catch (error) {
    console.error('Error processing affiliate attribution:', error);
    return null;
  }
}

// Handle affiliate referral links on page load
export function handleAffiliateReferral() {
  const urlParams = new URLSearchParams(window.location.search);
  const refCode = urlParams.get('ref');
  
  if (refCode) {
    // Extract UTM parameters
    const utmParams = {
      utm_source: urlParams.get('utm_source'),
      utm_medium: urlParams.get('utm_medium'),
      utm_campaign: urlParams.get('utm_campaign'),
      utm_content: urlParams.get('utm_content'),
      utm_term: urlParams.get('utm_term')
    };
    
    // Filter out null values
    const filteredUtmParams = Object.fromEntries(
      Object.entries(utmParams).filter(([_, value]) => value !== null)
    );
    
    // Track the click and set cookie
    trackAffiliateClick(refCode, filteredUtmParams).then(data => {
      if (data) {
        setAffiliateCookie({
          affiliate_id: data.affiliate_id,
          affiliate_code: data.affiliate_code,
          utm: data.utm,
          timestamp: Date.now()
        });
        
        // Clean URL by removing affiliate params
        const cleanUrl = new URL(window.location.href);
        cleanUrl.searchParams.delete('ref');
        Object.keys(filteredUtmParams).forEach(key => {
          cleanUrl.searchParams.delete(key);
        });
        
        window.history.replaceState({}, document.title, cleanUrl.toString());
      }
    });
  }
}

// Generate referral link
export function generateReferralLink(affiliateCode: string, baseUrl?: string, utmParams?: Record<string, string>): string {
  const url = new URL(baseUrl || window.location.origin);
  url.searchParams.set('ref', affiliateCode);
  
  if (utmParams) {
    Object.entries(utmParams).forEach(([key, value]) => {
      if (value) url.searchParams.set(key, value);
    });
  }
  
  return url.toString();
}

// Generate short referral link
export function generateShortReferralLink(affiliateCode: string, baseUrl?: string, utmParams?: Record<string, string>): string {
  const url = new URL(`${baseUrl || window.location.origin}/r/${affiliateCode}`);
  
  if (utmParams) {
    Object.entries(utmParams).forEach(([key, value]) => {
      if (value) url.searchParams.set(key, value);
    });
  }
  
  return url.toString();
}