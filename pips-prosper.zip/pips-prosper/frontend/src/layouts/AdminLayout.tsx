import { SidebarProvider, SidebarTrigger } from "@/components/ui/sidebar";
import { AdminSidebar } from "@/components/admin/AdminSidebar";
import { Outlet } from "react-router-dom";
import { ProtectedAdminRoute } from "@/components/admin/ProtectedAdminRoute";
import { useAuth } from "@/hooks/useAuth";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { 
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { User, Settings, LogOut, Crown, Shield, RefreshCw } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { ThemeToggle } from "@/components/ThemeToggle";
import { NotificationBanner } from "@/components/NotificationBanner";
import { useToast } from "@/hooks/use-toast";
import { useState } from "react";

export function AdminLayout() {
  const { user, signOut, subscriptionData } = useAuth();
  const navigate = useNavigate();
  const { toast } = useToast();
  const [isRefreshing, setIsRefreshing] = useState(false);

  const handleRefresh = async () => {
    setIsRefreshing(true);
    try {
      // Refresh the current page
      window.location.reload();
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to refresh dashboard",
        variant: "destructive",
      });
    } finally {
      setIsRefreshing(false);
    }
  };

  return (
    <ProtectedAdminRoute>
      <div className="min-h-screen bg-gradient-to-br from-background via-muted/5 to-primary/5">
        <SidebarProvider>
          <div className="flex min-h-screen w-full">
            <AdminSidebar />
            
            <div className="flex-1 flex flex-col overflow-hidden">
              {/* Enhanced admin header */}
              <header className="sticky top-0 z-50 w-full border-b border-border bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
                <div className="flex h-14 items-center justify-between px-4">
                  <div className="flex items-center space-x-4">
                    <SidebarTrigger className="md:hidden" />
                    <div className="flex items-center space-x-2">
                      <Shield className="h-5 w-5 text-primary" />
                      <h1 className="text-lg font-semibold text-foreground hidden sm:block">
                        Admin Dashboard
                      </h1>
                      <h1 className="text-base font-semibold text-foreground sm:hidden">
                        Admin
                      </h1>
                    </div>
                  </div>

                  <div className="flex items-center gap-2 sm:gap-4">
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={handleRefresh}
                      disabled={isRefreshing}
                      className="flex items-center gap-2 text-muted-foreground hover:text-foreground"
                      title="Refresh Dashboard"
                    >
                      <RefreshCw className={`h-4 w-4 ${isRefreshing ? 'animate-spin' : ''}`} />
                      <span className="hidden sm:inline">Refresh</span>
                    </Button>
                    <ThemeToggle />
                    
                    {user && (
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" className="flex items-center space-x-2 bg-background border border-border shadow-sm hover:bg-accent hover:text-accent-foreground px-2 sm:px-3">
                            <User className="w-4 h-4" />
                            <span className="hidden lg:inline-block text-sm">{user.email?.split('@')[0]}</span>
                            <Badge variant="outline" className="hidden sm:flex ml-1 sm:ml-2 text-xs text-primary border-primary">
                              Admin
                            </Badge>
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent 
                          align="end" 
                          className="w-56 bg-background border border-border shadow-lg"
                          sideOffset={5}
                        >
                          <DropdownMenuLabel className="font-normal">
                            <div className="flex flex-col space-y-1">
                              <p className="text-sm font-medium leading-none">Admin Account</p>
                              <p className="text-xs leading-none text-muted-foreground">
                                {user.email}
                              </p>
                            </div>
                          </DropdownMenuLabel>
                          <DropdownMenuSeparator />
                          <DropdownMenuItem onClick={() => navigate('/app')} className="cursor-pointer">
                            <Settings className="w-4 h-4 mr-2" />
                            User Dashboard
                          </DropdownMenuItem>
                          <DropdownMenuItem onClick={() => navigate('/subscription')} className="cursor-pointer">
                            <Crown className="w-4 h-4 mr-2" />
                            Subscription
                          </DropdownMenuItem>
                          <DropdownMenuSeparator />
                          <DropdownMenuItem onClick={signOut} className="cursor-pointer text-destructive">
                            <LogOut className="w-4 h-4 mr-2" />
                            Sign Out
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    )}
                  </div>
                </div>
              </header>

              <NotificationBanner location="dashboard" />
              <main className="flex-1 overflow-auto">
                <div className="container mx-auto p-4 sm:p-6 max-w-7xl">
                  <Outlet />
                </div>
              </main>
            </div>
          </div>
        </SidebarProvider>
      </div>
    </ProtectedAdminRoute>
  );
}