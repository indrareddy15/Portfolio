import { Outlet, useLocation } from "react-router-dom"
import { TradingSidebar } from "@/components/TradingSidebar"  
import { OnboardingCoachmarks } from "@/components/OnboardingCoachmarks"
import { SidebarProvider, SidebarTrigger } from "@/components/ui/sidebar"
import { DashboardHeader } from "@/components/DashboardHeader"
import { ScrollToTop } from "@/components/ScrollToTop"
import { NotificationBanner } from "@/components/NotificationBanner"
import { useEffect } from "react"

export function AppLayout() {
  const location = useLocation();

  // Scroll to top whenever the route changes
  useEffect(() => {
    window.scrollTo(0, 0);
  }, [location.pathname]);

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-muted/5 to-primary/5">
      {/* Notification Banner */}
      <NotificationBanner location="dashboard" />
      
      <SidebarProvider>
        <div className="flex min-h-screen w-full">
          <TradingSidebar />
          
          <div className="flex-1 flex flex-col overflow-hidden">
            <DashboardHeader title="PipTrackr.com" />
            
            <main className="flex-1 overflow-auto">
              <div className="container mx-auto p-3 sm:p-4 md:p-6 max-w-7xl">
                <Outlet />
              </div>
            </main>
          </div>
        </div>
      </SidebarProvider>

      <OnboardingCoachmarks />
      <ScrollToTop />
    </div>
  )
}