import React, { lazy } from "react";
import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import { GTMScript, GoogleTracking } from "@/components/GoogleTracking";
import { ConsentBanner } from "@/components/ConsentBanner";
import { AuthProvider } from "@/hooks/useAuth";
import { ProtectedRoute } from "@/components/ProtectedRoute";
import { ThemeProvider } from "next-themes";
import { ScrollToTop } from "@/components/ScrollToTop";
import { AccountProvider } from "@/hooks/useAccountContext";
import { EmailIntegrationsWiring } from "@/components/EmailIntegrationsWiring";
import Index from "./pages/Index";
import Auth from "./pages/Auth";
import { AppLayout } from "./layouts/AppLayout";
import { AdminLayout } from "./layouts/AdminLayout";
import AppDashboard from "./pages/app/AppDashboard";
import AdminOverview from "./pages/admin/AdminOverview";
import AdminPricing from "./pages/admin/pricing/AdminPricing";
import AdminForex from "./pages/admin/forex/AdminForex";
import CrmUsers from "./pages/admin/crm/CrmUsers";
import CrmAffiliates from "./pages/admin/crm/CrmAffiliates";
import CrmNotes from "./pages/admin/crm/CrmNotes";
import AffiliateApplications from "./pages/admin/affiliates/AffiliateApplications";
import AffiliateDirectory from "./pages/admin/affiliates/AffiliateDirectory";
import AdminSubscriptions from "./pages/admin/AdminSubscriptions";
import AppJournal from "./pages/app/AppJournal";
import AppAnalytics from "./pages/app/AppAnalytics";
import AppImports from "./pages/app/AppImports";
import AppStrategy from "./pages/app/AppStrategy";
import AppPsychology from "./pages/app/AppPsychology";
import AppAI from "./pages/app/AppAI";
import AppProp from "./pages/app/AppProp";
import AppTemplates from "./pages/app/AppTemplates";
import AppGoalsRules from "./pages/app/AppGoalsRules";
import AppAffiliate from "./pages/app/AppAffiliate";
import AppExport from "./pages/app/AppExport";
import AppAccounts from "./pages/app/settings/AppAccounts";
import AppProfile from "./pages/app/settings/AppProfile";
import AppSettings from "./pages/app/AppSettings";
import AppIntegrations from "./pages/app/settings/AppIntegrations";
import AppGoals from "./pages/app/settings/AppGoals";
import AppBilling from "./pages/app/settings/AppBilling";
import AppData from "./pages/app/settings/AppData";
import Subscription from "./pages/Subscription";
import Contact from "./pages/Contact";
import About from "./pages/About";
import Security from "./pages/Security";
import Terms from "./pages/Terms";
import Privacy from "./pages/Privacy";
import Cookies from "./pages/Cookies";
import Support from "./pages/Support";
import Blog from "./pages/Blog";
import BlogPost from "./pages/BlogPost";
import Learn from "./pages/Learn";
import Disclaimer from "./pages/Disclaimer";
import Affiliates from "./pages/Affiliates";
import AffiliateApply from "./pages/AffiliateApply";
import AffiliateTerms from "./pages/AffiliateTerms";
import ReferralRedirect from "./pages/ReferralRedirect";
import NotFound from "./pages/NotFound";
import SharedMetrics from "./pages/SharedMetrics";
import SharedTrade from "./pages/SharedTrade";

const AdminWebhooks = lazy(() => import("./pages/admin/system/AdminWebhooks"));
const AdminCoupons = lazy(() => import("./pages/admin/marketing/AdminCoupons"));
const AdminCampaigns = lazy(() => import("./pages/admin/marketing/AdminCampaigns"));
const AdminSettings = lazy(() => import("./pages/admin/system/AdminSettings"));
const AdminNotices = lazy(() => import("./pages/admin/system/AdminNotices"));
const AdminEmail = lazy(() => import("./pages/admin/system/AdminEmail"));
const AdminTeam = lazy(() => import("./pages/admin/system/AdminTeam"));
const AdminLogoManager = lazy(() => import("./pages/admin/branding/AdminLogoManager"));

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <ThemeProvider attribute="class" defaultTheme="system" enableSystem>
      <AuthProvider>
        <TooltipProvider>
          <GTMScript />
          <ConsentBanner />
          <Toaster />
          <Sonner />
          <BrowserRouter future={{ v7_startTransition: true, v7_relativeSplatPath: true }}>
            <ScrollToTop />
            <GoogleTracking />
            <EmailIntegrationsWiring />
            <Routes>
            <Route path="/" element={<Index />} />
            <Route path="/auth" element={<Auth />} />
            
            {/* Admin Routes */}
            <Route path="/admin/*" element={<AdminLayout />}>
              <Route index element={<AdminOverview />} />
              <Route path="crm/users" element={<CrmUsers />} />
              <Route path="crm/affiliates" element={<CrmAffiliates />} />
              <Route path="crm/notes" element={<CrmNotes />} />
              <Route path="affiliates/applications" element={<AffiliateApplications />} />
              <Route path="affiliates/directory" element={<AffiliateDirectory />} />
              <Route path="affiliates/commissions" element={
                <React.Suspense fallback={<div className="flex items-center justify-center min-h-screen"><div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div></div>}>
                  {React.createElement(React.lazy(() => import("./pages/admin/affiliates/AffiliateCommissions")))}
                </React.Suspense>
              } />
              <Route path="affiliates/payouts" element={
                <React.Suspense fallback={<div className="flex items-center justify-center min-h-screen"><div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div></div>}>
                  {React.createElement(React.lazy(() => import("./pages/admin/affiliates/AffiliatePayouts")))}
                </React.Suspense>
              } />
              <Route path="affiliates/creatives" element={
                <React.Suspense fallback={<div className="flex items-center justify-center min-h-screen"><div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div></div>}>
                  {React.createElement(React.lazy(() => import("./pages/admin/affiliates/AffiliateCreatives")))}
                </React.Suspense>
              } />
              <Route path="affiliates/settings" element={
                <React.Suspense fallback={<div className="flex items-center justify-center min-h-screen"><div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div></div>}>
                  {React.createElement(React.lazy(() => import("./pages/admin/affiliates/AffiliateSettings")))}
                </React.Suspense>
              } />
              <Route path="subscriptions" element={<AdminSubscriptions />} />
              <Route path="pricing" element={<AdminPricing />} />
              <Route path="forex" element={<AdminForex />} />
              <Route path="system/notices" element={<AdminNotices />} />
              <Route path="system/webhooks" element={<AdminWebhooks />} />
              <Route path="marketing/coupons" element={<AdminCoupons />} />
              <Route path="marketing/campaigns" element={<AdminCampaigns />} />
              <Route path="system/settings" element={<AdminSettings />} />
              <Route path="system/email" element={<AdminEmail />} />
              <Route path="system/team" element={<AdminTeam />} />
              <Route path="branding/logos" element={<AdminLogoManager />} />
              <Route path="content/blog/posts" element={
                <React.Suspense fallback={<div className="flex items-center justify-center min-h-screen"><div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div></div>}>
                  {React.createElement(React.lazy(() => import("./pages/admin/content/blog/BlogPosts")))}
                </React.Suspense>
              } />
              <Route path="content/blog/posts/new" element={
                <React.Suspense fallback={<div className="flex items-center justify-center min-h-screen"><div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div></div>}>
                  {React.createElement(React.lazy(() => import("./pages/admin/content/blog/BlogPostEditor")))}
                </React.Suspense>
              } />
              <Route path="content/blog/posts/:id/edit" element={
                <React.Suspense fallback={<div className="flex items-center justify-center min-h-screen"><div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div></div>}>
                  {React.createElement(React.lazy(() => import("./pages/admin/content/blog/BlogPostEditor")))}
                </React.Suspense>
              } />
              <Route path="content/blog/categories" element={
                <React.Suspense fallback={<div className="flex items-center justify-center min-h-screen"><div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div></div>}>
                  {React.createElement(React.lazy(() => import("./pages/admin/content/blog/BlogCategories")))}
                </React.Suspense>
              } />
              <Route path="content/blog/tags" element={
                <React.Suspense fallback={<div className="flex items-center justify-center min-h-screen"><div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div></div>}>
                  {React.createElement(React.lazy(() => import("./pages/admin/content/blog/BlogTags")))}
                </React.Suspense>
              } />
              <Route path="marketing/*" element={
                <React.Suspense fallback={<div className="flex items-center justify-center min-h-screen"><div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div></div>}>
                  {React.createElement(React.lazy(() => import("./pages/admin/marketing/AdminMarketing")))}
                </React.Suspense>
              } />
            </Route>

            {/* Protected App Routes */}
            <Route 
              path="/app/*" 
              element={
                <ProtectedRoute>
                  <AccountProvider>
                    <AppLayout />
                  </AccountProvider>
                </ProtectedRoute>
              }
            >
              <Route index element={<AppDashboard />} />
              <Route path="journal" element={<AppJournal />} />
              <Route path="imports" element={<AppImports />} />
              <Route path="analytics/*" element={<AppAnalytics />} />
              <Route path="analytics/overview" element={<AppAnalytics />} />
              <Route path="analytics/instruments" element={<AppAnalytics />} />
              <Route path="analytics/sessions" element={<AppAnalytics />} />
              <Route path="analytics/calendar" element={<AppAnalytics />} />
              <Route path="analytics/risk" element={<AppAnalytics />} />
              <Route path="analytics/mistakes" element={<AppAnalytics />} />
              <Route path="strategy" element={<AppStrategy />} />
              <Route path="psychology" element={<AppPsychology />} />
              <Route path="ai" element={<AppAI />} />
              <Route path="prop" element={<AppProp />} />
              <Route path="templates" element={<AppTemplates />} />
              <Route path="goals-rules" element={<AppGoalsRules />} />
              <Route path="affiliate/*" element={<AppAffiliate />} />
              <Route path="export" element={<AppExport />} />
              <Route path="settings/*" element={<AppSettings />} />
              <Route path="settings/profile" element={<AppProfile />} />
              <Route path="settings/accounts" element={<AppAccounts />} />
              <Route path="settings/integrations" element={<AppIntegrations />} />
              <Route path="settings/goals" element={<AppGoals />} />
              <Route path="settings/billing" element={<AppBilling />} />
              <Route path="settings/data" element={<AppData />} />
            </Route>
            
            {/* Legacy dashboard route - redirect to /app */}
            <Route 
              path="/dashboard" 
              element={
                <ProtectedRoute>
                  <AccountProvider>
                    <AppLayout />
                  </AccountProvider>
                </ProtectedRoute>
              } 
            >
              <Route index element={<AppDashboard />} />
            </Route>
            
            <Route 
              path="/subscription" 
              element={
                <ProtectedRoute>
                  <Subscription />
                </ProtectedRoute>
              } 
            />
            <Route path="/contact" element={<Contact />} />
            <Route path="/about" element={<About />} />
            <Route path="/security" element={<Security />} />
            <Route path="/terms" element={<Terms />} />
            <Route path="/privacy" element={<Privacy />} />
            <Route path="/cookies" element={<Cookies />} />
            <Route path="/support" element={<Support />} />
            <Route path="/blog" element={<Blog />} />
            <Route path="/blog/:slug" element={<BlogPost />} />
            <Route path="/learn" element={<Learn />} />
            <Route path="/disclaimer" element={<Disclaimer />} />
        <Route path="/affiliates" element={<Affiliates />} />
        <Route path="/affiliates/apply" element={<AffiliateApply />} />
        <Route path="/affiliates/terms" element={<AffiliateTerms />} />
            <Route path="/r/:code" element={<ReferralRedirect />} />
            <Route path="/s/:token" element={<SharedMetrics />} />
            <Route path="/shared/trade/:shareToken" element={<SharedTrade />} />
            {/* ADD ALL CUSTOM ROUTES ABOVE THE CATCH-ALL "*" ROUTE */}
            <Route path="*" element={<NotFound />} />
            </Routes>
            <ScrollToTop />
          </BrowserRouter>
        </TooltipProvider>
      </AuthProvider>
    </ThemeProvider>
  </QueryClientProvider>
);

export default App;
