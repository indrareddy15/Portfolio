export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "13.0.4"
  }
  public: {
    Tables: {
      account_goals: {
        Row: {
          account_id: string
          created_at: string
          current_value: number | null
          goal_type: string
          id: string
          is_achieved: boolean | null
          target_date: string | null
          target_value: number
          updated_at: string
          user_id: string
        }
        Insert: {
          account_id: string
          created_at?: string
          current_value?: number | null
          goal_type: string
          id?: string
          is_achieved?: boolean | null
          target_date?: string | null
          target_value: number
          updated_at?: string
          user_id: string
        }
        Update: {
          account_id?: string
          created_at?: string
          current_value?: number | null
          goal_type?: string
          id?: string
          is_achieved?: boolean | null
          target_date?: string | null
          target_value?: number
          updated_at?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "account_goals_account_id_fkey"
            columns: ["account_id"]
            isOneToOne: false
            referencedRelation: "accounts"
            referencedColumns: ["id"]
          },
        ]
      }
      accounts: {
        Row: {
          account_size: number | null
          account_type: string
          allowed_instruments: Json | null
          archived: boolean | null
          balance: number | null
          broker: string | null
          broker_name: string
          created_at: string
          currency: string | null
          equity: number | null
          free_margin: number | null
          id: string
          is_active: boolean | null
          leverage: number | null
          margin: number | null
          name: string
          nickname: string
          platform: string | null
          risk_preference: number | null
          start_balance: number | null
          type: string | null
          updated_at: string
          user_id: string
        }
        Insert: {
          account_size?: number | null
          account_type: string
          allowed_instruments?: Json | null
          archived?: boolean | null
          balance?: number | null
          broker?: string | null
          broker_name: string
          created_at?: string
          currency?: string | null
          equity?: number | null
          free_margin?: number | null
          id?: string
          is_active?: boolean | null
          leverage?: number | null
          margin?: number | null
          name: string
          nickname: string
          platform?: string | null
          risk_preference?: number | null
          start_balance?: number | null
          type?: string | null
          updated_at?: string
          user_id: string
        }
        Update: {
          account_size?: number | null
          account_type?: string
          allowed_instruments?: Json | null
          archived?: boolean | null
          balance?: number | null
          broker?: string | null
          broker_name?: string
          created_at?: string
          currency?: string | null
          equity?: number | null
          free_margin?: number | null
          id?: string
          is_active?: boolean | null
          leverage?: number | null
          margin?: number | null
          name?: string
          nickname?: string
          platform?: string | null
          risk_preference?: number | null
          start_balance?: number | null
          type?: string | null
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      affiliate_applications: {
        Row: {
          audience_size: string | null
          content_type: string | null
          country: string
          created_at: string
          email: string
          experience_level: string
          full_name: string
          id: string
          phone: string | null
          platform_type: string
          platform_url: string | null
          previous_programs: string | null
          promotion_strategy: string
          status: string | null
          updated_at: string
          user_id: string
        }
        Insert: {
          audience_size?: string | null
          content_type?: string | null
          country: string
          created_at?: string
          email: string
          experience_level: string
          full_name: string
          id?: string
          phone?: string | null
          platform_type: string
          platform_url?: string | null
          previous_programs?: string | null
          promotion_strategy: string
          status?: string | null
          updated_at?: string
          user_id: string
        }
        Update: {
          audience_size?: string | null
          content_type?: string | null
          country?: string
          created_at?: string
          email?: string
          experience_level?: string
          full_name?: string
          id?: string
          phone?: string | null
          platform_type?: string
          platform_url?: string | null
          previous_programs?: string | null
          promotion_strategy?: string
          status?: string | null
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      affiliate_attributions: {
        Row: {
          affiliate_id: string
          created_at: string
          id: string
          precedence: number
          source: string
          user_id: string
        }
        Insert: {
          affiliate_id: string
          created_at?: string
          id?: string
          precedence?: number
          source: string
          user_id: string
        }
        Update: {
          affiliate_id?: string
          created_at?: string
          id?: string
          precedence?: number
          source?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "affiliate_attributions_affiliate_id_fkey"
            columns: ["affiliate_id"]
            isOneToOne: false
            referencedRelation: "affiliates"
            referencedColumns: ["id"]
          },
        ]
      }
      affiliate_clicks: {
        Row: {
          affiliate_id: string
          created_at: string
          id: string
          ip_address: unknown | null
          url: string
          user_agent: string | null
          utm_json: Json | null
        }
        Insert: {
          affiliate_id: string
          created_at?: string
          id?: string
          ip_address?: unknown | null
          url: string
          user_agent?: string | null
          utm_json?: Json | null
        }
        Update: {
          affiliate_id?: string
          created_at?: string
          id?: string
          ip_address?: unknown | null
          url?: string
          user_agent?: string | null
          utm_json?: Json | null
        }
        Relationships: [
          {
            foreignKeyName: "affiliate_clicks_affiliate_id_fkey"
            columns: ["affiliate_id"]
            isOneToOne: false
            referencedRelation: "affiliates"
            referencedColumns: ["id"]
          },
        ]
      }
      affiliate_contracts: {
        Row: {
          affiliate_id: string
          contract_data: Json | null
          contract_type: string
          contract_version: string
          created_at: string
          id: string
          signed_at: string | null
          signed_ip: unknown | null
          signed_user_agent: string | null
          status: string
          updated_at: string
        }
        Insert: {
          affiliate_id: string
          contract_data?: Json | null
          contract_type?: string
          contract_version?: string
          created_at?: string
          id?: string
          signed_at?: string | null
          signed_ip?: unknown | null
          signed_user_agent?: string | null
          status?: string
          updated_at?: string
        }
        Update: {
          affiliate_id?: string
          contract_data?: Json | null
          contract_type?: string
          contract_version?: string
          created_at?: string
          id?: string
          signed_at?: string | null
          signed_ip?: unknown | null
          signed_user_agent?: string | null
          status?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "affiliate_contracts_affiliate_id_fkey"
            columns: ["affiliate_id"]
            isOneToOne: false
            referencedRelation: "affiliates"
            referencedColumns: ["id"]
          },
        ]
      }
      affiliate_kyc: {
        Row: {
          affiliate_id: string
          created_at: string
          files_json: Json | null
          id: string
          status: string
          updated_at: string
        }
        Insert: {
          affiliate_id: string
          created_at?: string
          files_json?: Json | null
          id?: string
          status?: string
          updated_at?: string
        }
        Update: {
          affiliate_id?: string
          created_at?: string
          files_json?: Json | null
          id?: string
          status?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "affiliate_kyc_affiliate_id_fkey"
            columns: ["affiliate_id"]
            isOneToOne: false
            referencedRelation: "affiliates"
            referencedColumns: ["id"]
          },
        ]
      }
      affiliate_settings: {
        Row: {
          auto_approval: boolean | null
          cookie_duration: number | null
          created_at: string | null
          default_commission_rate: number | null
          email_notifications: boolean | null
          id: string
          minimum_payout: number | null
          payout_frequency: string | null
          terms_and_conditions: string | null
          tracking_domain: string | null
          updated_at: string | null
          updated_by: string | null
          welcome_message: string | null
        }
        Insert: {
          auto_approval?: boolean | null
          cookie_duration?: number | null
          created_at?: string | null
          default_commission_rate?: number | null
          email_notifications?: boolean | null
          id?: string
          minimum_payout?: number | null
          payout_frequency?: string | null
          terms_and_conditions?: string | null
          tracking_domain?: string | null
          updated_at?: string | null
          updated_by?: string | null
          welcome_message?: string | null
        }
        Update: {
          auto_approval?: boolean | null
          cookie_duration?: number | null
          created_at?: string | null
          default_commission_rate?: number | null
          email_notifications?: boolean | null
          id?: string
          minimum_payout?: number | null
          payout_frequency?: string | null
          terms_and_conditions?: string | null
          tracking_domain?: string | null
          updated_at?: string | null
          updated_by?: string | null
          welcome_message?: string | null
        }
        Relationships: []
      }
      affiliate_tier_snapshots: {
        Row: {
          affiliate_id: string
          approved_count: number
          at_date: string
          created_at: string | null
          effective_rate_pct: number
          id: string
          tier_level: number
        }
        Insert: {
          affiliate_id: string
          approved_count: number
          at_date?: string
          created_at?: string | null
          effective_rate_pct: number
          id?: string
          tier_level: number
        }
        Update: {
          affiliate_id?: string
          approved_count?: number
          at_date?: string
          created_at?: string | null
          effective_rate_pct?: number
          id?: string
          tier_level?: number
        }
        Relationships: [
          {
            foreignKeyName: "affiliate_tier_snapshots_affiliate_id_fkey"
            columns: ["affiliate_id"]
            isOneToOne: false
            referencedRelation: "affiliates"
            referencedColumns: ["id"]
          },
        ]
      }
      affiliates: {
        Row: {
          code: string
          cookie_window_days: number
          created_at: string
          custom_tiers_json: Json | null
          default_rate_pct: number
          flat_pct: number | null
          id: string
          lifetime_approved_count: number | null
          minimum_payout: number | null
          override_mode: string | null
          plan_overrides_json: Json | null
          promo_end: string | null
          promo_start: string | null
          promotion_code_id: string | null
          status: string
          updated_at: string
          user_id: string | null
        }
        Insert: {
          code: string
          cookie_window_days?: number
          created_at?: string
          custom_tiers_json?: Json | null
          default_rate_pct?: number
          flat_pct?: number | null
          id?: string
          lifetime_approved_count?: number | null
          minimum_payout?: number | null
          override_mode?: string | null
          plan_overrides_json?: Json | null
          promo_end?: string | null
          promo_start?: string | null
          promotion_code_id?: string | null
          status?: string
          updated_at?: string
          user_id?: string | null
        }
        Update: {
          code?: string
          cookie_window_days?: number
          created_at?: string
          custom_tiers_json?: Json | null
          default_rate_pct?: number
          flat_pct?: number | null
          id?: string
          lifetime_approved_count?: number | null
          minimum_payout?: number | null
          override_mode?: string | null
          plan_overrides_json?: Json | null
          promo_end?: string | null
          promo_start?: string | null
          promotion_code_id?: string | null
          status?: string
          updated_at?: string
          user_id?: string | null
        }
        Relationships: []
      }
      ai_insights: {
        Row: {
          content: string
          created_at: string
          id: string
          insight_type: string
          is_read: boolean | null
          metadata: Json | null
          title: string
          user_id: string
        }
        Insert: {
          content: string
          created_at?: string
          id?: string
          insight_type: string
          is_read?: boolean | null
          metadata?: Json | null
          title: string
          user_id: string
        }
        Update: {
          content?: string
          created_at?: string
          id?: string
          insight_type?: string
          is_read?: boolean | null
          metadata?: Json | null
          title?: string
          user_id?: string
        }
        Relationships: []
      }
      audit_logs: {
        Row: {
          created_at: string
          id: string
          ip_address: unknown | null
          new_values: Json | null
          old_values: Json | null
          operation: string
          record_id: string | null
          table_name: string
          user_agent: string | null
          user_id: string | null
          user_role: string | null
        }
        Insert: {
          created_at?: string
          id?: string
          ip_address?: unknown | null
          new_values?: Json | null
          old_values?: Json | null
          operation: string
          record_id?: string | null
          table_name: string
          user_agent?: string | null
          user_id?: string | null
          user_role?: string | null
        }
        Update: {
          created_at?: string
          id?: string
          ip_address?: unknown | null
          new_values?: Json | null
          old_values?: Json | null
          operation?: string
          record_id?: string | null
          table_name?: string
          user_agent?: string | null
          user_id?: string | null
          user_role?: string | null
        }
        Relationships: []
      }
      blog_authors: {
        Row: {
          avatar_url: string | null
          bio: string | null
          created_at: string
          id: string
          name: string
          slug: string
          social_json: Json | null
          updated_at: string
        }
        Insert: {
          avatar_url?: string | null
          bio?: string | null
          created_at?: string
          id?: string
          name: string
          slug: string
          social_json?: Json | null
          updated_at?: string
        }
        Update: {
          avatar_url?: string | null
          bio?: string | null
          created_at?: string
          id?: string
          name?: string
          slug?: string
          social_json?: Json | null
          updated_at?: string
        }
        Relationships: []
      }
      blog_categories: {
        Row: {
          created_at: string
          description: string | null
          id: string
          name: string
          slug: string
          updated_at: string
        }
        Insert: {
          created_at?: string
          description?: string | null
          id?: string
          name: string
          slug: string
          updated_at?: string
        }
        Update: {
          created_at?: string
          description?: string | null
          id?: string
          name?: string
          slug?: string
          updated_at?: string
        }
        Relationships: []
      }
      blog_media: {
        Row: {
          alt: string | null
          created_at: string
          file_size: number | null
          height: number | null
          id: string
          mime_type: string | null
          url: string
          width: number | null
        }
        Insert: {
          alt?: string | null
          created_at?: string
          file_size?: number | null
          height?: number | null
          id?: string
          mime_type?: string | null
          url: string
          width?: number | null
        }
        Update: {
          alt?: string | null
          created_at?: string
          file_size?: number | null
          height?: number | null
          id?: string
          mime_type?: string | null
          url?: string
          width?: number | null
        }
        Relationships: []
      }
      blog_poll_votes: {
        Row: {
          created_at: string
          custom_answer: string | null
          id: string
          ip_address: unknown | null
          poll_id: string
          selected_options: Json
          user_agent: string | null
          user_id: string | null
        }
        Insert: {
          created_at?: string
          custom_answer?: string | null
          id?: string
          ip_address?: unknown | null
          poll_id: string
          selected_options?: Json
          user_agent?: string | null
          user_id?: string | null
        }
        Update: {
          created_at?: string
          custom_answer?: string | null
          id?: string
          ip_address?: unknown | null
          poll_id?: string
          selected_options?: Json
          user_agent?: string | null
          user_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "blog_poll_votes_poll_id_fkey"
            columns: ["poll_id"]
            isOneToOne: false
            referencedRelation: "blog_polls"
            referencedColumns: ["id"]
          },
        ]
      }
      blog_polls: {
        Row: {
          allow_custom_answers: boolean | null
          created_at: string
          description: string | null
          expires_at: string | null
          id: string
          is_active: boolean | null
          options_json: Json
          poll_type: string
          position: number | null
          post_id: string | null
          title: string
          total_votes: number | null
          updated_at: string
        }
        Insert: {
          allow_custom_answers?: boolean | null
          created_at?: string
          description?: string | null
          expires_at?: string | null
          id?: string
          is_active?: boolean | null
          options_json?: Json
          poll_type?: string
          position?: number | null
          post_id?: string | null
          title: string
          total_votes?: number | null
          updated_at?: string
        }
        Update: {
          allow_custom_answers?: boolean | null
          created_at?: string
          description?: string | null
          expires_at?: string | null
          id?: string
          is_active?: boolean | null
          options_json?: Json
          poll_type?: string
          position?: number | null
          post_id?: string | null
          title?: string
          total_votes?: number | null
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "blog_polls_post_id_fkey"
            columns: ["post_id"]
            isOneToOne: false
            referencedRelation: "blog_posts"
            referencedColumns: ["id"]
          },
        ]
      }
      blog_post_tags: {
        Row: {
          post_id: string
          tag_id: string
        }
        Insert: {
          post_id: string
          tag_id: string
        }
        Update: {
          post_id?: string
          tag_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "blog_post_tags_post_id_fkey"
            columns: ["post_id"]
            isOneToOne: false
            referencedRelation: "blog_posts"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "blog_post_tags_tag_id_fkey"
            columns: ["tag_id"]
            isOneToOne: false
            referencedRelation: "blog_tags"
            referencedColumns: ["id"]
          },
        ]
      }
      blog_post_versions: {
        Row: {
          body_md: string | null
          created_at: string
          id: string
          meta_json: Json | null
          post_id: string
        }
        Insert: {
          body_md?: string | null
          created_at?: string
          id?: string
          meta_json?: Json | null
          post_id: string
        }
        Update: {
          body_md?: string | null
          created_at?: string
          id?: string
          meta_json?: Json | null
          post_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "blog_post_versions_post_id_fkey"
            columns: ["post_id"]
            isOneToOne: false
            referencedRelation: "blog_posts"
            referencedColumns: ["id"]
          },
        ]
      }
      blog_posts: {
        Row: {
          author_id: string | null
          body_md: string | null
          canonical_url: string | null
          category_id: string | null
          cover_url: string | null
          created_at: string
          excerpt: string | null
          featured: boolean | null
          id: string
          meta_description: string | null
          meta_title: string | null
          og_description: string | null
          og_image_url: string | null
          og_title: string | null
          publish_at: string | null
          reading_time: number | null
          slug: string
          status: string
          title: string
          updated_at: string
        }
        Insert: {
          author_id?: string | null
          body_md?: string | null
          canonical_url?: string | null
          category_id?: string | null
          cover_url?: string | null
          created_at?: string
          excerpt?: string | null
          featured?: boolean | null
          id?: string
          meta_description?: string | null
          meta_title?: string | null
          og_description?: string | null
          og_image_url?: string | null
          og_title?: string | null
          publish_at?: string | null
          reading_time?: number | null
          slug: string
          status?: string
          title: string
          updated_at?: string
        }
        Update: {
          author_id?: string | null
          body_md?: string | null
          canonical_url?: string | null
          category_id?: string | null
          cover_url?: string | null
          created_at?: string
          excerpt?: string | null
          featured?: boolean | null
          id?: string
          meta_description?: string | null
          meta_title?: string | null
          og_description?: string | null
          og_image_url?: string | null
          og_title?: string | null
          publish_at?: string | null
          reading_time?: number | null
          slug?: string
          status?: string
          title?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "blog_posts_author_id_fkey"
            columns: ["author_id"]
            isOneToOne: false
            referencedRelation: "blog_authors"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "blog_posts_category_id_fkey"
            columns: ["category_id"]
            isOneToOne: false
            referencedRelation: "blog_categories"
            referencedColumns: ["id"]
          },
        ]
      }
      blog_qna: {
        Row: {
          allow_anonymous: boolean | null
          created_at: string
          description: string | null
          id: string
          is_active: boolean | null
          moderated: boolean | null
          position: number | null
          post_id: string | null
          title: string
          updated_at: string
        }
        Insert: {
          allow_anonymous?: boolean | null
          created_at?: string
          description?: string | null
          id?: string
          is_active?: boolean | null
          moderated?: boolean | null
          position?: number | null
          post_id?: string | null
          title: string
          updated_at?: string
        }
        Update: {
          allow_anonymous?: boolean | null
          created_at?: string
          description?: string | null
          id?: string
          is_active?: boolean | null
          moderated?: boolean | null
          position?: number | null
          post_id?: string | null
          title?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "blog_qna_post_id_fkey"
            columns: ["post_id"]
            isOneToOne: false
            referencedRelation: "blog_posts"
            referencedColumns: ["id"]
          },
        ]
      }
      blog_qna_answers: {
        Row: {
          answer: string
          author_id: string | null
          created_at: string
          id: string
          is_official: boolean | null
          question_id: string
          updated_at: string
        }
        Insert: {
          answer: string
          author_id?: string | null
          created_at?: string
          id?: string
          is_official?: boolean | null
          question_id: string
          updated_at?: string
        }
        Update: {
          answer?: string
          author_id?: string | null
          created_at?: string
          id?: string
          is_official?: boolean | null
          question_id?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "blog_qna_answers_author_id_fkey"
            columns: ["author_id"]
            isOneToOne: false
            referencedRelation: "blog_authors"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "blog_qna_answers_question_id_fkey"
            columns: ["question_id"]
            isOneToOne: false
            referencedRelation: "blog_qna_questions"
            referencedColumns: ["id"]
          },
        ]
      }
      blog_qna_questions: {
        Row: {
          author_email: string | null
          author_name: string | null
          created_at: string
          id: string
          ip_address: unknown | null
          is_approved: boolean | null
          is_featured: boolean | null
          qna_id: string
          question: string
          updated_at: string
          upvotes: number | null
          user_agent: string | null
          user_id: string | null
        }
        Insert: {
          author_email?: string | null
          author_name?: string | null
          created_at?: string
          id?: string
          ip_address?: unknown | null
          is_approved?: boolean | null
          is_featured?: boolean | null
          qna_id: string
          question: string
          updated_at?: string
          upvotes?: number | null
          user_agent?: string | null
          user_id?: string | null
        }
        Update: {
          author_email?: string | null
          author_name?: string | null
          created_at?: string
          id?: string
          ip_address?: unknown | null
          is_approved?: boolean | null
          is_featured?: boolean | null
          qna_id?: string
          question?: string
          updated_at?: string
          upvotes?: number | null
          user_agent?: string | null
          user_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "blog_qna_questions_qna_id_fkey"
            columns: ["qna_id"]
            isOneToOne: false
            referencedRelation: "blog_qna"
            referencedColumns: ["id"]
          },
        ]
      }
      blog_redirects: {
        Row: {
          created_at: string
          from_path: string
          id: string
          note: string | null
          status_code: number | null
          to_url: string
        }
        Insert: {
          created_at?: string
          from_path: string
          id?: string
          note?: string | null
          status_code?: number | null
          to_url: string
        }
        Update: {
          created_at?: string
          from_path?: string
          id?: string
          note?: string | null
          status_code?: number | null
          to_url?: string
        }
        Relationships: []
      }
      blog_settings: {
        Row: {
          id: string
          key: string
          updated_at: string
          value: Json | null
        }
        Insert: {
          id?: string
          key: string
          updated_at?: string
          value?: Json | null
        }
        Update: {
          id?: string
          key?: string
          updated_at?: string
          value?: Json | null
        }
        Relationships: []
      }
      blog_tags: {
        Row: {
          created_at: string
          id: string
          name: string
          slug: string
        }
        Insert: {
          created_at?: string
          id?: string
          name: string
          slug: string
        }
        Update: {
          created_at?: string
          id?: string
          name?: string
          slug?: string
        }
        Relationships: []
      }
      campaigns: {
        Row: {
          active: boolean | null
          created_at: string | null
          created_by: string | null
          creative_ids: string[] | null
          id: string
          name: string
          updated_at: string | null
          utm_preset_json: Json | null
        }
        Insert: {
          active?: boolean | null
          created_at?: string | null
          created_by?: string | null
          creative_ids?: string[] | null
          id?: string
          name: string
          updated_at?: string | null
          utm_preset_json?: Json | null
        }
        Update: {
          active?: boolean | null
          created_at?: string | null
          created_by?: string | null
          creative_ids?: string[] | null
          id?: string
          name?: string
          updated_at?: string | null
          utm_preset_json?: Json | null
        }
        Relationships: []
      }
      challenge_daily_results: {
        Row: {
          challenge_id: string
          created_at: string
          daily_pnl: number | null
          date: string
          fail_reasons: string[] | null
          id: string
          largest_lot: number | null
          passed: boolean | null
          trades_count: number | null
          user_id: string
        }
        Insert: {
          challenge_id: string
          created_at?: string
          daily_pnl?: number | null
          date: string
          fail_reasons?: string[] | null
          id?: string
          largest_lot?: number | null
          passed?: boolean | null
          trades_count?: number | null
          user_id: string
        }
        Update: {
          challenge_id?: string
          created_at?: string
          daily_pnl?: number | null
          date?: string
          fail_reasons?: string[] | null
          id?: string
          largest_lot?: number | null
          passed?: boolean | null
          trades_count?: number | null
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "challenge_daily_results_challenge_id_fkey"
            columns: ["challenge_id"]
            isOneToOne: false
            referencedRelation: "prop_challenges"
            referencedColumns: ["id"]
          },
        ]
      }
      cms_blocks: {
        Row: {
          content_json: Json
          created_at: string | null
          id: string
          key: string
          updated_at: string | null
          updated_by: string | null
        }
        Insert: {
          content_json?: Json
          created_at?: string | null
          id?: string
          key: string
          updated_at?: string | null
          updated_by?: string | null
        }
        Update: {
          content_json?: Json
          created_at?: string | null
          id?: string
          key?: string
          updated_at?: string | null
          updated_by?: string | null
        }
        Relationships: []
      }
      commissions: {
        Row: {
          affiliate_id: string
          amount: number
          created_at: string
          currency: string
          customer_user_id: string
          effective_rate_pct: number | null
          hold_until: string | null
          id: string
          notes: string | null
          plan_name: string | null
          rate_pct: number
          status: string
          stripe_invoice_id: string | null
          tier_level: number | null
          type: string
          updated_at: string
        }
        Insert: {
          affiliate_id: string
          amount: number
          created_at?: string
          currency?: string
          customer_user_id: string
          effective_rate_pct?: number | null
          hold_until?: string | null
          id?: string
          notes?: string | null
          plan_name?: string | null
          rate_pct: number
          status?: string
          stripe_invoice_id?: string | null
          tier_level?: number | null
          type?: string
          updated_at?: string
        }
        Update: {
          affiliate_id?: string
          amount?: number
          created_at?: string
          currency?: string
          customer_user_id?: string
          effective_rate_pct?: number | null
          hold_until?: string | null
          id?: string
          notes?: string | null
          plan_name?: string | null
          rate_pct?: number
          status?: string
          stripe_invoice_id?: string | null
          tier_level?: number | null
          type?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "commissions_affiliate_id_fkey"
            columns: ["affiliate_id"]
            isOneToOne: false
            referencedRelation: "affiliates"
            referencedColumns: ["id"]
          },
        ]
      }
      consistency_scores: {
        Row: {
          consecutive_days: number
          created_at: string
          id: string
          last_trade_date: string | null
          score: number
          trading_days: number
          updated_at: string
          user_id: string
        }
        Insert: {
          consecutive_days?: number
          created_at?: string
          id?: string
          last_trade_date?: string | null
          score?: number
          trading_days?: number
          updated_at?: string
          user_id: string
        }
        Update: {
          consecutive_days?: number
          created_at?: string
          id?: string
          last_trade_date?: string | null
          score?: number
          trading_days?: number
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      coupons: {
        Row: {
          active: boolean | null
          code: string
          created_at: string
          created_by: string | null
          expires_at: string | null
          id: string
          max_uses: number | null
          type: string
          updated_at: string
          used_count: number | null
          value: number
        }
        Insert: {
          active?: boolean | null
          code: string
          created_at?: string
          created_by?: string | null
          expires_at?: string | null
          id?: string
          max_uses?: number | null
          type?: string
          updated_at?: string
          used_count?: number | null
          value: number
        }
        Update: {
          active?: boolean | null
          code?: string
          created_at?: string
          created_by?: string | null
          expires_at?: string | null
          id?: string
          max_uses?: number | null
          type?: string
          updated_at?: string
          used_count?: number | null
          value?: number
        }
        Relationships: []
      }
      creative_assets: {
        Row: {
          created_at: string
          id: string
          name: string
          size_bytes: number | null
          tags: string[] | null
          type: string
          url: string
        }
        Insert: {
          created_at?: string
          id?: string
          name: string
          size_bytes?: number | null
          tags?: string[] | null
          type: string
          url: string
        }
        Update: {
          created_at?: string
          id?: string
          name?: string
          size_bytes?: number | null
          tags?: string[] | null
          type?: string
          url?: string
        }
        Relationships: []
      }
      crm_notes: {
        Row: {
          affiliate_id: string | null
          body: string | null
          by_admin_id: string
          created_at: string | null
          id: string
          subject: string
          user_id: string | null
        }
        Insert: {
          affiliate_id?: string | null
          body?: string | null
          by_admin_id: string
          created_at?: string | null
          id?: string
          subject: string
          user_id?: string | null
        }
        Update: {
          affiliate_id?: string | null
          body?: string | null
          by_admin_id?: string
          created_at?: string | null
          id?: string
          subject?: string
          user_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "crm_notes_affiliate_id_fkey"
            columns: ["affiliate_id"]
            isOneToOne: false
            referencedRelation: "affiliates"
            referencedColumns: ["id"]
          },
        ]
      }
      dashboard_layouts: {
        Row: {
          created_at: string
          id: string
          is_default: boolean | null
          layout_data: Json
          layout_name: string
          updated_at: string
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          is_default?: boolean | null
          layout_data: Json
          layout_name: string
          updated_at?: string
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          is_default?: boolean | null
          layout_data?: Json
          layout_name?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      email_events: {
        Row: {
          created_at: string | null
          email: string
          email_log_id: string | null
          event: string
          id: string
          meta: Json | null
          sg_message_id: string | null
        }
        Insert: {
          created_at?: string | null
          email: string
          email_log_id?: string | null
          event: string
          id?: string
          meta?: Json | null
          sg_message_id?: string | null
        }
        Update: {
          created_at?: string | null
          email?: string
          email_log_id?: string | null
          event?: string
          id?: string
          meta?: Json | null
          sg_message_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "email_events_email_log_id_fkey"
            columns: ["email_log_id"]
            isOneToOne: false
            referencedRelation: "email_logs"
            referencedColumns: ["id"]
          },
        ]
      }
      email_logs: {
        Row: {
          attempts: number
          created_at: string | null
          id: string
          last_error: string | null
          payload: Json
          sg_message_id: string | null
          status: string
          subject: string
          template_key: string
          to_email: string
          updated_at: string | null
        }
        Insert: {
          attempts?: number
          created_at?: string | null
          id?: string
          last_error?: string | null
          payload: Json
          sg_message_id?: string | null
          status?: string
          subject: string
          template_key: string
          to_email: string
          updated_at?: string | null
        }
        Update: {
          attempts?: number
          created_at?: string | null
          id?: string
          last_error?: string | null
          payload?: Json
          sg_message_id?: string | null
          status?: string
          subject?: string
          template_key?: string
          to_email?: string
          updated_at?: string | null
        }
        Relationships: []
      }
      email_templates: {
        Row: {
          active: boolean | null
          content: string
          created_at: string
          created_by: string | null
          id: string
          name: string
          subject: string
          template_type: string
          updated_at: string
        }
        Insert: {
          active?: boolean | null
          content: string
          created_at?: string
          created_by?: string | null
          id?: string
          name: string
          subject: string
          template_type: string
          updated_at?: string
        }
        Update: {
          active?: boolean | null
          content?: string
          created_at?: string
          created_by?: string | null
          id?: string
          name?: string
          subject?: string
          template_type?: string
          updated_at?: string
        }
        Relationships: []
      }
      email_unsubscribes: {
        Row: {
          created_at: string | null
          email: string
          id: string
          reason: string | null
          template_key: string | null
          unsubscribed_at: string | null
        }
        Insert: {
          created_at?: string | null
          email: string
          id?: string
          reason?: string | null
          template_key?: string | null
          unsubscribed_at?: string | null
        }
        Update: {
          created_at?: string | null
          email?: string
          id?: string
          reason?: string | null
          template_key?: string | null
          unsubscribed_at?: string | null
        }
        Relationships: []
      }
      equity_snapshots: {
        Row: {
          account_id: string | null
          created_at: string
          equity_account: number
          id: string
          time_utc: string
          user_id: string
        }
        Insert: {
          account_id?: string | null
          created_at?: string
          equity_account: number
          id?: string
          time_utc?: string
          user_id: string
        }
        Update: {
          account_id?: string | null
          created_at?: string
          equity_account?: number
          id?: string
          time_utc?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "equity_snapshots_account_id_fkey"
            columns: ["account_id"]
            isOneToOne: false
            referencedRelation: "accounts"
            referencedColumns: ["id"]
          },
        ]
      }
      fx_rates: {
        Row: {
          created_by: string | null
          from_currency: string
          id: string
          is_active: boolean
          rate: number
          to_currency: string
          updated_at: string
        }
        Insert: {
          created_by?: string | null
          from_currency: string
          id?: string
          is_active?: boolean
          rate: number
          to_currency: string
          updated_at?: string
        }
        Update: {
          created_by?: string | null
          from_currency?: string
          id?: string
          is_active?: boolean
          rate?: number
          to_currency?: string
          updated_at?: string
        }
        Relationships: []
      }
      gold_rules: {
        Row: {
          color_code: string | null
          created_at: string
          id: string
          is_active: boolean
          last_reminded_at: string | null
          priority: number
          reminder_frequency: string | null
          rule_text: string
          rule_type: string
          title: string
          updated_at: string
          user_id: string
          violation_count: number
        }
        Insert: {
          color_code?: string | null
          created_at?: string
          id?: string
          is_active?: boolean
          last_reminded_at?: string | null
          priority?: number
          reminder_frequency?: string | null
          rule_text: string
          rule_type?: string
          title: string
          updated_at?: string
          user_id: string
          violation_count?: number
        }
        Update: {
          color_code?: string | null
          created_at?: string
          id?: string
          is_active?: boolean
          last_reminded_at?: string | null
          priority?: number
          reminder_frequency?: string | null
          rule_text?: string
          rule_type?: string
          title?: string
          updated_at?: string
          user_id?: string
          violation_count?: number
        }
        Relationships: []
      }
      import_jobs: {
        Row: {
          created_at: string
          errors_json: Json | null
          finished_at: string | null
          id: string
          processed_rows: number | null
          source: string
          status: string | null
          total_rows: number | null
          user_id: string
        }
        Insert: {
          created_at?: string
          errors_json?: Json | null
          finished_at?: string | null
          id?: string
          processed_rows?: number | null
          source: string
          status?: string | null
          total_rows?: number | null
          user_id: string
        }
        Update: {
          created_at?: string
          errors_json?: Json | null
          finished_at?: string | null
          id?: string
          processed_rows?: number | null
          source?: string
          status?: string | null
          total_rows?: number | null
          user_id?: string
        }
        Relationships: []
      }
      instrument_classes: {
        Row: {
          created_at: string | null
          display_name: string
          id: string
          name: string
        }
        Insert: {
          created_at?: string | null
          display_name: string
          id?: string
          name: string
        }
        Update: {
          created_at?: string | null
          display_name?: string
          id?: string
          name?: string
        }
        Relationships: []
      }
      instrument_stats: {
        Row: {
          avg_rr: number | null
          created_at: string
          id: string
          pnl: number | null
          symbol: string
          trade_count: number | null
          updated_at: string
          user_id: string
          win_rate: number | null
        }
        Insert: {
          avg_rr?: number | null
          created_at?: string
          id?: string
          pnl?: number | null
          symbol: string
          trade_count?: number | null
          updated_at?: string
          user_id: string
          win_rate?: number | null
        }
        Update: {
          avg_rr?: number | null
          created_at?: string
          id?: string
          pnl?: number | null
          symbol?: string
          trade_count?: number | null
          updated_at?: string
          user_id?: string
          win_rate?: number | null
        }
        Relationships: []
      }
      instruments: {
        Row: {
          base_ccy: string
          class: string
          class_name: string | null
          contract_size: number | null
          created_at: string
          description: string | null
          id: string
          is_active: boolean
          lot_units: number
          pip_precision: number
          pip_size: number
          point_value: number | null
          price_precision: number
          pricing_mode: string
          quote_ccy: string
          symbol: string
          tick_size: number | null
          updated_at: string
        }
        Insert: {
          base_ccy: string
          class?: string
          class_name?: string | null
          contract_size?: number | null
          created_at?: string
          description?: string | null
          id?: string
          is_active?: boolean
          lot_units?: number
          pip_precision?: number
          pip_size?: number
          point_value?: number | null
          price_precision?: number
          pricing_mode?: string
          quote_ccy: string
          symbol: string
          tick_size?: number | null
          updated_at?: string
        }
        Update: {
          base_ccy?: string
          class?: string
          class_name?: string | null
          contract_size?: number | null
          created_at?: string
          description?: string | null
          id?: string
          is_active?: boolean
          lot_units?: number
          pip_precision?: number
          pip_size?: number
          point_value?: number | null
          price_precision?: number
          pricing_mode?: string
          quote_ccy?: string
          symbol?: string
          tick_size?: number | null
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "fk_instruments_class"
            columns: ["class_name"]
            isOneToOne: false
            referencedRelation: "instrument_classes"
            referencedColumns: ["name"]
          },
        ]
      }
      logo_settings: {
        Row: {
          created_at: string
          created_by: string | null
          height: number | null
          id: string
          is_active: boolean
          logo_alt: string
          logo_type: string
          logo_url: string
          updated_at: string
          usage_locations: string[] | null
          width: number | null
        }
        Insert: {
          created_at?: string
          created_by?: string | null
          height?: number | null
          id?: string
          is_active?: boolean
          logo_alt?: string
          logo_type?: string
          logo_url: string
          updated_at?: string
          usage_locations?: string[] | null
          width?: number | null
        }
        Update: {
          created_at?: string
          created_by?: string | null
          height?: number | null
          id?: string
          is_active?: boolean
          logo_alt?: string
          logo_type?: string
          logo_url?: string
          updated_at?: string
          usage_locations?: string[] | null
          width?: number | null
        }
        Relationships: []
      }
      metrics_summary: {
        Row: {
          avg_rr: number | null
          created_at: string
          end_ts: string | null
          expectancy: number | null
          id: string
          longest_loss: number | null
          longest_win: number | null
          max_dd: number | null
          net_pnl: number | null
          profit_factor: number | null
          scope: string
          sharpe: number | null
          start_ts: string | null
          total_pnl: number | null
          trade_count: number | null
          updated_at: string
          user_id: string
          win_rate: number | null
        }
        Insert: {
          avg_rr?: number | null
          created_at?: string
          end_ts?: string | null
          expectancy?: number | null
          id?: string
          longest_loss?: number | null
          longest_win?: number | null
          max_dd?: number | null
          net_pnl?: number | null
          profit_factor?: number | null
          scope: string
          sharpe?: number | null
          start_ts?: string | null
          total_pnl?: number | null
          trade_count?: number | null
          updated_at?: string
          user_id: string
          win_rate?: number | null
        }
        Update: {
          avg_rr?: number | null
          created_at?: string
          end_ts?: string | null
          expectancy?: number | null
          id?: string
          longest_loss?: number | null
          longest_win?: number | null
          max_dd?: number | null
          net_pnl?: number | null
          profit_factor?: number | null
          scope?: string
          sharpe?: number | null
          start_ts?: string | null
          total_pnl?: number | null
          trade_count?: number | null
          updated_at?: string
          user_id?: string
          win_rate?: number | null
        }
        Relationships: []
      }
      news_events: {
        Row: {
          category: string | null
          created_at: string
          currency: string | null
          date: string
          description: string | null
          id: string
          impact_level: string | null
          time: string | null
          title: string
        }
        Insert: {
          category?: string | null
          created_at?: string
          currency?: string | null
          date: string
          description?: string | null
          id?: string
          impact_level?: string | null
          time?: string | null
          title: string
        }
        Update: {
          category?: string | null
          created_at?: string
          currency?: string | null
          date?: string
          description?: string | null
          id?: string
          impact_level?: string | null
          time?: string | null
          title?: string
        }
        Relationships: []
      }
      notices: {
        Row: {
          created_at: string
          created_by: string | null
          expires_at: string | null
          id: string
          is_active: boolean
          link_text: string | null
          link_url: string | null
          message: string
          priority: number
          show_on_dashboard: boolean
          show_on_website: boolean
          title: string
          type: string
          updated_at: string
        }
        Insert: {
          created_at?: string
          created_by?: string | null
          expires_at?: string | null
          id?: string
          is_active?: boolean
          link_text?: string | null
          link_url?: string | null
          message: string
          priority?: number
          show_on_dashboard?: boolean
          show_on_website?: boolean
          title: string
          type?: string
          updated_at?: string
        }
        Update: {
          created_at?: string
          created_by?: string | null
          expires_at?: string | null
          id?: string
          is_active?: boolean
          link_text?: string | null
          link_url?: string | null
          message?: string
          priority?: number
          show_on_dashboard?: boolean
          show_on_website?: boolean
          title?: string
          type?: string
          updated_at?: string
        }
        Relationships: []
      }
      payout_audit: {
        Row: {
          changed_by: string | null
          created_at: string
          id: string
          metadata: Json | null
          new_status: string
          old_status: string | null
          payout_id: string
          reason: string | null
        }
        Insert: {
          changed_by?: string | null
          created_at?: string
          id?: string
          metadata?: Json | null
          new_status: string
          old_status?: string | null
          payout_id: string
          reason?: string | null
        }
        Update: {
          changed_by?: string | null
          created_at?: string
          id?: string
          metadata?: Json | null
          new_status?: string
          old_status?: string | null
          payout_id?: string
          reason?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "payout_audit_payout_id_fkey"
            columns: ["payout_id"]
            isOneToOne: false
            referencedRelation: "payouts"
            referencedColumns: ["id"]
          },
        ]
      }
      payouts: {
        Row: {
          affiliate_id: string
          amount: number
          contract_required: boolean | null
          created_at: string
          currency: string
          details_json: Json | null
          id: string
          kyc_required: boolean | null
          method: string
          notes: string | null
          processed_at: string | null
          processed_by: string | null
          reference: string | null
          rejection_reason: string | null
          status: string
          updated_at: string
        }
        Insert: {
          affiliate_id: string
          amount: number
          contract_required?: boolean | null
          created_at?: string
          currency?: string
          details_json?: Json | null
          id?: string
          kyc_required?: boolean | null
          method: string
          notes?: string | null
          processed_at?: string | null
          processed_by?: string | null
          reference?: string | null
          rejection_reason?: string | null
          status?: string
          updated_at?: string
        }
        Update: {
          affiliate_id?: string
          amount?: number
          contract_required?: boolean | null
          created_at?: string
          currency?: string
          details_json?: Json | null
          id?: string
          kyc_required?: boolean | null
          method?: string
          notes?: string | null
          processed_at?: string | null
          processed_by?: string | null
          reference?: string | null
          rejection_reason?: string | null
          status?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "payouts_affiliate_id_fkey"
            columns: ["affiliate_id"]
            isOneToOne: false
            referencedRelation: "affiliates"
            referencedColumns: ["id"]
          },
        ]
      }
      plan_features: {
        Row: {
          created_at: string
          id: string
          is_included: boolean
          label: string
          plan_id: string
          sort_order: number
        }
        Insert: {
          created_at?: string
          id?: string
          is_included?: boolean
          label: string
          plan_id: string
          sort_order?: number
        }
        Update: {
          created_at?: string
          id?: string
          is_included?: boolean
          label?: string
          plan_id?: string
          sort_order?: number
        }
        Relationships: [
          {
            foreignKeyName: "plan_features_plan_id_fkey"
            columns: ["plan_id"]
            isOneToOne: false
            referencedRelation: "plans"
            referencedColumns: ["id"]
          },
        ]
      }
      plans: {
        Row: {
          billing_cycle: Database["public"]["Enums"]["billing_cycle"]
          created_at: string
          description: string | null
          id: string
          is_active: boolean
          name: string
          price_amount: number
          price_currency: string
          sort_order: number
          stripe_price_id: string | null
          stripe_product_id: string | null
          updated_at: string
        }
        Insert: {
          billing_cycle?: Database["public"]["Enums"]["billing_cycle"]
          created_at?: string
          description?: string | null
          id?: string
          is_active?: boolean
          name: string
          price_amount?: number
          price_currency?: string
          sort_order?: number
          stripe_price_id?: string | null
          stripe_product_id?: string | null
          updated_at?: string
        }
        Update: {
          billing_cycle?: Database["public"]["Enums"]["billing_cycle"]
          created_at?: string
          description?: string | null
          id?: string
          is_active?: boolean
          name?: string
          price_amount?: number
          price_currency?: string
          sort_order?: number
          stripe_price_id?: string | null
          stripe_product_id?: string | null
          updated_at?: string
        }
        Relationships: []
      }
      profiles: {
        Row: {
          country: string | null
          created_at: string
          display_name: string | null
          id: string
          preferred_currency: string | null
          timezone: string | null
          trading_experience: string | null
          updated_at: string
          user_id: string
        }
        Insert: {
          country?: string | null
          created_at?: string
          display_name?: string | null
          id?: string
          preferred_currency?: string | null
          timezone?: string | null
          trading_experience?: string | null
          updated_at?: string
          user_id: string
        }
        Update: {
          country?: string | null
          created_at?: string
          display_name?: string | null
          id?: string
          preferred_currency?: string | null
          timezone?: string | null
          trading_experience?: string | null
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      prop_challenges: {
        Row: {
          challenge_name: string
          created_at: string
          current_daily_loss: number | null
          current_overall_loss: number | null
          current_profit: number | null
          end_date: string
          id: string
          max_daily_loss: number
          max_lot_size: number | null
          max_overall_loss: number
          min_trading_days: number
          rules_json: Json | null
          start_date: string
          status: string | null
          target_profit: number | null
          trading_days_count: number | null
          updated_at: string
          user_id: string
        }
        Insert: {
          challenge_name: string
          created_at?: string
          current_daily_loss?: number | null
          current_overall_loss?: number | null
          current_profit?: number | null
          end_date: string
          id?: string
          max_daily_loss: number
          max_lot_size?: number | null
          max_overall_loss: number
          min_trading_days?: number
          rules_json?: Json | null
          start_date: string
          status?: string | null
          target_profit?: number | null
          trading_days_count?: number | null
          updated_at?: string
          user_id: string
        }
        Update: {
          challenge_name?: string
          created_at?: string
          current_daily_loss?: number | null
          current_overall_loss?: number | null
          current_profit?: number | null
          end_date?: string
          id?: string
          max_daily_loss?: number
          max_lot_size?: number | null
          max_overall_loss?: number
          min_trading_days?: number
          rules_json?: Json | null
          start_date?: string
          status?: string | null
          target_profit?: number | null
          trading_days_count?: number | null
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      psychology_entries: {
        Row: {
          adherence_score: number | null
          comments: string | null
          created_at: string
          id: string
          mistake_tags: string[] | null
          mood_post: number | null
          mood_pre: number | null
          trade_id: string
          updated_at: string
          user_id: string
        }
        Insert: {
          adherence_score?: number | null
          comments?: string | null
          created_at?: string
          id?: string
          mistake_tags?: string[] | null
          mood_post?: number | null
          mood_pre?: number | null
          trade_id: string
          updated_at?: string
          user_id: string
        }
        Update: {
          adherence_score?: number | null
          comments?: string | null
          created_at?: string
          id?: string
          mistake_tags?: string[] | null
          mood_post?: number | null
          mood_pre?: number | null
          trade_id?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "psychology_entries_trade_id_fkey"
            columns: ["trade_id"]
            isOneToOne: false
            referencedRelation: "trades"
            referencedColumns: ["id"]
          },
        ]
      }
      public_journals: {
        Row: {
          bio: string | null
          created_at: string
          display_name: string | null
          id: string
          is_public: boolean | null
          public_link: string | null
          updated_at: string
          user_id: string
          view_count: number | null
        }
        Insert: {
          bio?: string | null
          created_at?: string
          display_name?: string | null
          id?: string
          is_public?: boolean | null
          public_link?: string | null
          updated_at?: string
          user_id: string
          view_count?: number | null
        }
        Update: {
          bio?: string | null
          created_at?: string
          display_name?: string | null
          id?: string
          is_public?: boolean | null
          public_link?: string | null
          updated_at?: string
          user_id?: string
          view_count?: number | null
        }
        Relationships: []
      }
      role_permissions: {
        Row: {
          created_at: string
          id: string
          permission: string
          role: Database["public"]["Enums"]["app_role"]
        }
        Insert: {
          created_at?: string
          id?: string
          permission: string
          role: Database["public"]["Enums"]["app_role"]
        }
        Update: {
          created_at?: string
          id?: string
          permission?: string
          role?: Database["public"]["Enums"]["app_role"]
        }
        Relationships: []
      }
      session_stats: {
        Row: {
          created_at: string
          id: string
          pnl: number | null
          session: string
          trade_count: number | null
          updated_at: string
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          pnl?: number | null
          session: string
          trade_count?: number | null
          updated_at?: string
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          pnl?: number | null
          session?: string
          trade_count?: number | null
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      share_analytics: {
        Row: {
          created_at: string
          event_type: string
          id: string
          ip_address: unknown | null
          metadata: Json | null
          referrer: string | null
          source: string | null
          trade_share_id: string
          user_agent: string | null
        }
        Insert: {
          created_at?: string
          event_type: string
          id?: string
          ip_address?: unknown | null
          metadata?: Json | null
          referrer?: string | null
          source?: string | null
          trade_share_id: string
          user_agent?: string | null
        }
        Update: {
          created_at?: string
          event_type?: string
          id?: string
          ip_address?: unknown | null
          metadata?: Json | null
          referrer?: string | null
          source?: string | null
          trade_share_id?: string
          user_agent?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "share_analytics_trade_share_id_fkey"
            columns: ["trade_share_id"]
            isOneToOne: false
            referencedRelation: "trade_shares"
            referencedColumns: ["id"]
          },
        ]
      }
      share_links: {
        Row: {
          created_at: string
          expires_at: string | null
          id: string
          last_viewed_at: string | null
          link_type: string
          password_hash: string | null
          permissions: Json | null
          share_token: string
          user_id: string
          view_count: number | null
        }
        Insert: {
          created_at?: string
          expires_at?: string | null
          id?: string
          last_viewed_at?: string | null
          link_type: string
          password_hash?: string | null
          permissions?: Json | null
          share_token: string
          user_id: string
          view_count?: number | null
        }
        Update: {
          created_at?: string
          expires_at?: string | null
          id?: string
          last_viewed_at?: string | null
          link_type?: string
          password_hash?: string | null
          permissions?: Json | null
          share_token?: string
          user_id?: string
          view_count?: number | null
        }
        Relationships: []
      }
      strategies: {
        Row: {
          active: boolean | null
          created_at: string
          description: string | null
          examples: string[] | null
          id: string
          name: string
          rules_json: Json | null
          updated_at: string
          user_id: string
        }
        Insert: {
          active?: boolean | null
          created_at?: string
          description?: string | null
          examples?: string[] | null
          id?: string
          name: string
          rules_json?: Json | null
          updated_at?: string
          user_id: string
        }
        Update: {
          active?: boolean | null
          created_at?: string
          description?: string | null
          examples?: string[] | null
          id?: string
          name?: string
          rules_json?: Json | null
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      streaks: {
        Row: {
          best_count: number
          created_at: string
          current_count: number
          id: string
          last_date: string | null
          streak_type: string
          updated_at: string
          user_id: string
        }
        Insert: {
          best_count?: number
          created_at?: string
          current_count?: number
          id?: string
          last_date?: string | null
          streak_type: string
          updated_at?: string
          user_id: string
        }
        Update: {
          best_count?: number
          created_at?: string
          current_count?: number
          id?: string
          last_date?: string | null
          streak_type?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      subscribers: {
        Row: {
          created_at: string
          email: string
          id: string
          stripe_customer_id: string | null
          subscribed: boolean
          subscription_end: string | null
          subscription_tier: string | null
          updated_at: string
          user_id: string | null
        }
        Insert: {
          created_at?: string
          email: string
          id?: string
          stripe_customer_id?: string | null
          subscribed?: boolean
          subscription_end?: string | null
          subscription_tier?: string | null
          updated_at?: string
          user_id?: string | null
        }
        Update: {
          created_at?: string
          email?: string
          id?: string
          stripe_customer_id?: string | null
          subscribed?: boolean
          subscription_end?: string | null
          subscription_tier?: string | null
          updated_at?: string
          user_id?: string | null
        }
        Relationships: []
      }
      team_invitations: {
        Row: {
          accepted_at: string | null
          created_at: string
          email: string
          expires_at: string
          id: string
          invited_by: string
          role: Database["public"]["Enums"]["app_role"]
          status: string
          updated_at: string
        }
        Insert: {
          accepted_at?: string | null
          created_at?: string
          email: string
          expires_at?: string
          id?: string
          invited_by: string
          role: Database["public"]["Enums"]["app_role"]
          status?: string
          updated_at?: string
        }
        Update: {
          accepted_at?: string | null
          created_at?: string
          email?: string
          expires_at?: string
          id?: string
          invited_by?: string
          role?: Database["public"]["Enums"]["app_role"]
          status?: string
          updated_at?: string
        }
        Relationships: []
      }
      trade_certificates: {
        Row: {
          certificate_type: string
          certificate_url: string | null
          created_at: string
          generated_at: string
          id: string
          performance_data: Json
          social_image_url: string | null
          template_data: Json
          trade_id: string
          trade_share_id: string
          user_id: string
        }
        Insert: {
          certificate_type?: string
          certificate_url?: string | null
          created_at?: string
          generated_at?: string
          id?: string
          performance_data?: Json
          social_image_url?: string | null
          template_data?: Json
          trade_id: string
          trade_share_id: string
          user_id: string
        }
        Update: {
          certificate_type?: string
          certificate_url?: string | null
          created_at?: string
          generated_at?: string
          id?: string
          performance_data?: Json
          social_image_url?: string | null
          template_data?: Json
          trade_id?: string
          trade_share_id?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "trade_certificates_trade_share_id_fkey"
            columns: ["trade_share_id"]
            isOneToOne: false
            referencedRelation: "trade_shares"
            referencedColumns: ["id"]
          },
        ]
      }
      trade_history: {
        Row: {
          action: string
          changed_fields: string[] | null
          created_at: string
          id: string
          ip_address: unknown | null
          new_values: Json
          old_values: Json | null
          trade_id: string
          user_agent: string | null
          user_id: string
        }
        Insert: {
          action: string
          changed_fields?: string[] | null
          created_at?: string
          id?: string
          ip_address?: unknown | null
          new_values: Json
          old_values?: Json | null
          trade_id: string
          user_agent?: string | null
          user_id: string
        }
        Update: {
          action?: string
          changed_fields?: string[] | null
          created_at?: string
          id?: string
          ip_address?: unknown | null
          new_values?: Json
          old_values?: Json | null
          trade_id?: string
          user_agent?: string | null
          user_id?: string
        }
        Relationships: []
      }
      trade_legs: {
        Row: {
          created_at: string
          id: string
          leg_type: Database["public"]["Enums"]["leg_type"]
          price: number
          qty_or_lots: number
          time: string
          trade_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          leg_type: Database["public"]["Enums"]["leg_type"]
          price: number
          qty_or_lots: number
          time?: string
          trade_id: string
        }
        Update: {
          created_at?: string
          id?: string
          leg_type?: Database["public"]["Enums"]["leg_type"]
          price?: number
          qty_or_lots?: number
          time?: string
          trade_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "trade_legs_trade_id_fkey"
            columns: ["trade_id"]
            isOneToOne: false
            referencedRelation: "trades"
            referencedColumns: ["id"]
          },
        ]
      }
      trade_shares: {
        Row: {
          certificate_generated: boolean
          certificate_url: string | null
          created_at: string
          description: string | null
          expires_at: string | null
          id: string
          is_active: boolean
          is_public: boolean
          share_token: string
          social_image_url: string | null
          title: string | null
          trade_id: string
          updated_at: string
          user_id: string
          view_count: number
        }
        Insert: {
          certificate_generated?: boolean
          certificate_url?: string | null
          created_at?: string
          description?: string | null
          expires_at?: string | null
          id?: string
          is_active?: boolean
          is_public?: boolean
          share_token: string
          social_image_url?: string | null
          title?: string | null
          trade_id: string
          updated_at?: string
          user_id: string
          view_count?: number
        }
        Update: {
          certificate_generated?: boolean
          certificate_url?: string | null
          created_at?: string
          description?: string | null
          expires_at?: string | null
          id?: string
          is_active?: boolean
          is_public?: boolean
          share_token?: string
          social_image_url?: string | null
          title?: string | null
          trade_id?: string
          updated_at?: string
          user_id?: string
          view_count?: number
        }
        Relationships: []
      }
      trades: {
        Row: {
          account_ccy: string | null
          account_currency: string | null
          account_id: string | null
          auto_configured: boolean | null
          closed_at: string | null
          commission: number | null
          converted_pnl: number | null
          created_at: string
          entry_price: number
          exit_price: number | null
          fees: number | null
          fx_rate_used: number | null
          id: string
          instrument: string
          lots: number | null
          notes_post: string | null
          notes_pre: string | null
          opened_at: string
          pip_value: number | null
          pips: number | null
          pips_or_ticks: number | null
          pnl: number | null
          pnl_account: number | null
          prop_challenge_id: string | null
          provider_trade_id: string | null
          quantity: number | null
          quote_currency: string | null
          raw_pnl: number | null
          raw_pnl_quote: number | null
          result: string | null
          risk_percent: number | null
          risk_reward_ratio: number | null
          rr: number | null
          screenshots: string[] | null
          session: string | null
          side: string
          size: number
          source: Database["public"]["Enums"]["trade_source"] | null
          status: Database["public"]["Enums"]["trade_status"] | null
          stop_loss: number | null
          strategy_id: string | null
          swap: number | null
          tags: string[] | null
          take_profit: number | null
          trade_type: string | null
          updated_at: string
          user_id: string
        }
        Insert: {
          account_ccy?: string | null
          account_currency?: string | null
          account_id?: string | null
          auto_configured?: boolean | null
          closed_at?: string | null
          commission?: number | null
          converted_pnl?: number | null
          created_at?: string
          entry_price: number
          exit_price?: number | null
          fees?: number | null
          fx_rate_used?: number | null
          id?: string
          instrument: string
          lots?: number | null
          notes_post?: string | null
          notes_pre?: string | null
          opened_at: string
          pip_value?: number | null
          pips?: number | null
          pips_or_ticks?: number | null
          pnl?: number | null
          pnl_account?: number | null
          prop_challenge_id?: string | null
          provider_trade_id?: string | null
          quantity?: number | null
          quote_currency?: string | null
          raw_pnl?: number | null
          raw_pnl_quote?: number | null
          result?: string | null
          risk_percent?: number | null
          risk_reward_ratio?: number | null
          rr?: number | null
          screenshots?: string[] | null
          session?: string | null
          side: string
          size: number
          source?: Database["public"]["Enums"]["trade_source"] | null
          status?: Database["public"]["Enums"]["trade_status"] | null
          stop_loss?: number | null
          strategy_id?: string | null
          swap?: number | null
          tags?: string[] | null
          take_profit?: number | null
          trade_type?: string | null
          updated_at?: string
          user_id: string
        }
        Update: {
          account_ccy?: string | null
          account_currency?: string | null
          account_id?: string | null
          auto_configured?: boolean | null
          closed_at?: string | null
          commission?: number | null
          converted_pnl?: number | null
          created_at?: string
          entry_price?: number
          exit_price?: number | null
          fees?: number | null
          fx_rate_used?: number | null
          id?: string
          instrument?: string
          lots?: number | null
          notes_post?: string | null
          notes_pre?: string | null
          opened_at?: string
          pip_value?: number | null
          pips?: number | null
          pips_or_ticks?: number | null
          pnl?: number | null
          pnl_account?: number | null
          prop_challenge_id?: string | null
          provider_trade_id?: string | null
          quantity?: number | null
          quote_currency?: string | null
          raw_pnl?: number | null
          raw_pnl_quote?: number | null
          result?: string | null
          risk_percent?: number | null
          risk_reward_ratio?: number | null
          rr?: number | null
          screenshots?: string[] | null
          session?: string | null
          side?: string
          size?: number
          source?: Database["public"]["Enums"]["trade_source"] | null
          status?: Database["public"]["Enums"]["trade_status"] | null
          stop_loss?: number | null
          strategy_id?: string | null
          swap?: number | null
          tags?: string[] | null
          take_profit?: number | null
          trade_type?: string | null
          updated_at?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "trades_account_id_fkey"
            columns: ["account_id"]
            isOneToOne: false
            referencedRelation: "accounts"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "trades_prop_challenge_id_fkey"
            columns: ["prop_challenge_id"]
            isOneToOne: false
            referencedRelation: "prop_challenges"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "trades_strategy_id_fkey"
            columns: ["strategy_id"]
            isOneToOne: false
            referencedRelation: "strategies"
            referencedColumns: ["id"]
          },
        ]
      }
      trading_templates: {
        Row: {
          active: boolean
          category: string
          content: Json
          created_at: string
          description: string | null
          downloads: number
          id: string
          is_public: boolean
          name: string
          preview: string | null
          rating: number
          tags: string[] | null
          updated_at: string
          user_id: string
        }
        Insert: {
          active?: boolean
          category?: string
          content?: Json
          created_at?: string
          description?: string | null
          downloads?: number
          id?: string
          is_public?: boolean
          name: string
          preview?: string | null
          rating?: number
          tags?: string[] | null
          updated_at?: string
          user_id: string
        }
        Update: {
          active?: boolean
          category?: string
          content?: Json
          created_at?: string
          description?: string | null
          downloads?: number
          id?: string
          is_public?: boolean
          name?: string
          preview?: string | null
          rating?: number
          tags?: string[] | null
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      user_badges: {
        Row: {
          badge_description: string | null
          badge_name: string
          badge_type: string
          earned_at: string
          id: string
          metadata: Json | null
          user_id: string
        }
        Insert: {
          badge_description?: string | null
          badge_name: string
          badge_type: string
          earned_at?: string
          id?: string
          metadata?: Json | null
          user_id: string
        }
        Update: {
          badge_description?: string | null
          badge_name?: string
          badge_type?: string
          earned_at?: string
          id?: string
          metadata?: Json | null
          user_id?: string
        }
        Relationships: []
      }
      user_invoices: {
        Row: {
          amount_due: number
          created_at: string
          currency: string
          hosted_invoice_url: string | null
          id: string
          invoice_pdf_url: string | null
          status: Database["public"]["Enums"]["invoice_status"]
          stripe_invoice_id: string
          updated_at: string
          user_id: string
        }
        Insert: {
          amount_due: number
          created_at?: string
          currency?: string
          hosted_invoice_url?: string | null
          id?: string
          invoice_pdf_url?: string | null
          status: Database["public"]["Enums"]["invoice_status"]
          stripe_invoice_id: string
          updated_at?: string
          user_id: string
        }
        Update: {
          amount_due?: number
          created_at?: string
          currency?: string
          hosted_invoice_url?: string | null
          id?: string
          invoice_pdf_url?: string | null
          status?: Database["public"]["Enums"]["invoice_status"]
          stripe_invoice_id?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      user_roles: {
        Row: {
          created_at: string
          created_by: string | null
          id: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Insert: {
          created_at?: string
          created_by?: string | null
          id?: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Update: {
          created_at?: string
          created_by?: string | null
          id?: string
          role?: Database["public"]["Enums"]["app_role"]
          user_id?: string
        }
        Relationships: []
      }
      user_subscriptions: {
        Row: {
          cancel_at_period_end: boolean
          created_at: string
          current_period_end: string | null
          current_period_start: string | null
          id: string
          plan_id: string | null
          status: Database["public"]["Enums"]["subscription_status"]
          stripe_customer_id: string | null
          stripe_subscription_id: string | null
          updated_at: string
          user_id: string
        }
        Insert: {
          cancel_at_period_end?: boolean
          created_at?: string
          current_period_end?: string | null
          current_period_start?: string | null
          id?: string
          plan_id?: string | null
          status?: Database["public"]["Enums"]["subscription_status"]
          stripe_customer_id?: string | null
          stripe_subscription_id?: string | null
          updated_at?: string
          user_id: string
        }
        Update: {
          cancel_at_period_end?: boolean
          created_at?: string
          current_period_end?: string | null
          current_period_start?: string | null
          id?: string
          plan_id?: string | null
          status?: Database["public"]["Enums"]["subscription_status"]
          stripe_customer_id?: string | null
          stripe_subscription_id?: string | null
          updated_at?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "user_subscriptions_plan_id_fkey"
            columns: ["plan_id"]
            isOneToOne: false
            referencedRelation: "plans"
            referencedColumns: ["id"]
          },
        ]
      }
      webhook_keys: {
        Row: {
          active: boolean | null
          created_at: string
          id: string
          name: string
          secret: string
          user_id: string
        }
        Insert: {
          active?: boolean | null
          created_at?: string
          id?: string
          name: string
          secret: string
          user_id: string
        }
        Update: {
          active?: boolean | null
          created_at?: string
          id?: string
          name?: string
          secret?: string
          user_id?: string
        }
        Relationships: []
      }
      webhook_logs: {
        Row: {
          created_at: string
          error_message: string | null
          id: string
          method: string
          payload: Json | null
          response_body: string | null
          response_status: number | null
          webhook_url: string
        }
        Insert: {
          created_at?: string
          error_message?: string | null
          id?: string
          method?: string
          payload?: Json | null
          response_body?: string | null
          response_status?: number | null
          webhook_url: string
        }
        Update: {
          created_at?: string
          error_message?: string | null
          id?: string
          method?: string
          payload?: Json | null
          response_body?: string | null
          response_status?: number | null
          webhook_url?: string
        }
        Relationships: []
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      calculate_metrics_for_account: {
        Args: { account_id_param: string; from_date?: string; to_date?: string }
        Returns: {
          avg_rr: number
          gross_loss_cents: number
          gross_profit_cents: number
          loss_count: number
          max_dd_pct: number
          net_pnl_cents: number
          profit_factor: number
          trades_count: number
          win_count: number
          win_pct: number
        }[]
      }
      create_test_user: {
        Args: Record<PropertyKey, never>
        Returns: undefined
      }
      generate_share_token: {
        Args: Record<PropertyKey, never>
        Returns: string
      }
      get_current_user_role: {
        Args: Record<PropertyKey, never>
        Returns: Database["public"]["Enums"]["app_role"]
      }
      get_user_permissions: {
        Args: { user_id: string }
        Returns: string[]
      }
      get_webhook_keys_safe: {
        Args: Record<PropertyKey, never>
        Returns: {
          active: boolean
          created_at: string
          id: string
          name: string
          secret: string
          secret_masked: string
          user_id: string
        }[]
      }
      has_permission: {
        Args: { permission_name: string; user_id: string }
        Returns: boolean
      }
      has_role: {
        Args: {
          _role: Database["public"]["Enums"]["app_role"]
          _user_id: string
        }
        Returns: boolean
      }
      increment_share_view: {
        Args: { share_token_param: string }
        Returns: undefined
      }
      mask_sensitive_data: {
        Args: { data: string; mask_type?: string }
        Returns: string
      }
    }
    Enums: {
      app_role:
        | "admin"
        | "moderator"
        | "user"
        | "affiliate"
        | "owner"
        | "developer"
        | "sales"
        | "support"
        | "marketing"
        | "finance"
      billing_cycle: "monthly" | "yearly"
      invoice_status: "paid" | "open" | "void" | "uncollectible" | "draft"
      leg_type: "open" | "close"
      subscription_status:
        | "active"
        | "past_due"
        | "canceled"
        | "trialing"
        | "incomplete"
        | "unpaid"
      trade_source: "manual" | "mt4" | "mt5" | "ctrader" | "tradelocker" | "tv"
      trade_status: "open" | "closed" | "partial"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {
      app_role: [
        "admin",
        "moderator",
        "user",
        "affiliate",
        "owner",
        "developer",
        "sales",
        "support",
        "marketing",
        "finance",
      ],
      billing_cycle: ["monthly", "yearly"],
      invoice_status: ["paid", "open", "void", "uncollectible", "draft"],
      leg_type: ["open", "close"],
      subscription_status: [
        "active",
        "past_due",
        "canceled",
        "trialing",
        "incomplete",
        "unpaid",
      ],
      trade_source: ["manual", "mt4", "mt5", "ctrader", "tradelocker", "tv"],
      trade_status: ["open", "closed", "partial"],
    },
  },
} as const
