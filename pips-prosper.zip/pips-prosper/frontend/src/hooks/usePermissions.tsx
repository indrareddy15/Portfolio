import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";

export interface UserPermissions {
  permissions: string[];
  role: string;
  loading: boolean;
}

export function usePermissions(): UserPermissions {
  const { user } = useAuth();
  const [permissions, setPermissions] = useState<string[]>([]);
  const [role, setRole] = useState<string>("user");
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchPermissions = async () => {
      if (!user) {
        setPermissions([]);
        setRole("user");
        setLoading(false);
        return;
      }

      try {
        // Get user role
        const { data: userRole, error: roleError } = await supabase
          .from("user_roles")
          .select("role")
          .eq("user_id", user.id)
          .single();

        if (roleError || !userRole) {
          setPermissions([]);
          setRole("user");
          setLoading(false);
          return;
        }

        setRole(userRole.role);

        // Get permissions for this role
        const { data: rolePermissions, error: permError } = await supabase
          .from("role_permissions")
          .select("permission")
          .eq("role", userRole.role);

        if (permError) {
          console.error("Error fetching permissions:", permError);
          setPermissions([]);
        } else {
          setPermissions(rolePermissions?.map(p => p.permission) || []);
        }
      } catch (error) {
        console.error("Error in usePermissions:", error);
        setPermissions([]);
        setRole("user");
      } finally {
        setLoading(false);
      }
    };

    fetchPermissions();
  }, [user]);

  return { permissions, role, loading };
}

export function hasPermission(permissions: string[], requiredPermission: string): boolean {
  return permissions.includes(requiredPermission) || permissions.includes("view_all");
}

export function hasAnyPermission(permissions: string[], requiredPermissions: string[]): boolean {
  return requiredPermissions.some(perm => hasPermission(permissions, perm));
}