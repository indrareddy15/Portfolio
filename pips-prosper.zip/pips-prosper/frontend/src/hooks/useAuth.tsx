import { createContext, useContext, useEffect, useState } from "react";
import { User, Session } from "@supabase/supabase-js";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/components/ui/use-toast";
import { processAffiliateAttribution } from "@/utils/affiliateTracking";

interface SubscriptionData {
  subscribed: boolean;
  subscription_tier?: string;
  subscription_end?: string;
}

interface AuthContextType {
  user: User | null;
  session: Session | null;
  loading: boolean;
  subscriptionData: SubscriptionData | null;
  refreshSubscription: () => Promise<void>;
  signUp: (email: string, password: string, displayName?: string) => Promise<{ error: any }>;
  signIn: (email: string, password: string) => Promise<{ error: any }>;
  signInWithGoogle: () => Promise<{ error: any }>;
  signInWithDiscord: () => Promise<{ error: any }>;
  signOut: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [session, setSession] = useState<Session | null>(null);
  const [loading, setLoading] = useState(true);
  const [subscriptionData, setSubscriptionData] = useState<SubscriptionData | null>(null);
  const { toast } = useToast();

  const checkSubscription = async (currentUser: User) => {
    try {
      console.log('Checking subscription for user:', currentUser.id);
      // Add timeout to prevent hanging
      const timeoutPromise = new Promise((_, reject) => 
        setTimeout(() => reject(new Error('Subscription check timeout')), 5000)
      );
      
      const subscriptionPromise = supabase.functions.invoke('check-subscription');
      
      const { data, error } = await Promise.race([subscriptionPromise, timeoutPromise]) as any;
      
      if (error) {
        console.error('Error checking subscription:', error);
        
        // Check if it's an authentication error
        if (error.message?.includes('Authentication error') || error.message?.includes('session_not_found') || error.message?.includes('Session from session_id claim in JWT does not exist')) {
          console.log('Authentication error detected, refreshing session...');
          // Try to refresh the session
          const { data: { session }, error: refreshError } = await supabase.auth.refreshSession();
          if (refreshError || !session) {
            console.log('Session refresh failed, signing out user');
            await supabase.auth.signOut();
            return;
          } else {
            console.log('Session refreshed successfully');
            // Retry subscription check with new session
            setTimeout(() => checkSubscription(currentUser), 1000);
            return;
          }
        }
        
        setSubscriptionData({ subscribed: false });
        return;
      }
      console.log('Subscription data:', data);
      setSubscriptionData(data);
    } catch (error) {
      console.error('Error checking subscription:', error);
      
      // Handle authentication errors at catch level too
      const errorMessage = error instanceof Error ? error.message : String(error);
      if (errorMessage?.includes('Authentication error') || errorMessage?.includes('session_not_found') || errorMessage?.includes('Session from session_id claim in JWT does not exist')) {
        console.log('Authentication error in catch block, signing out user');
        await supabase.auth.signOut();
        return;
      }
      
      setSubscriptionData({ subscribed: false });
    }
  };

  const refreshSubscription = async () => {
    if (user) {
      await checkSubscription(user);
    }
  };

  useEffect(() => {
    let isMounted = true;

    // Set up auth state listener
    const { data: { subscription } } = supabase.auth.onAuthStateChange(
      async (event, session) => {
        if (!isMounted) return;
        
        setSession(session);
        setUser(session?.user ?? null);
        
        if (session?.user) {
          // Run subscription check in background
          checkSubscription(session.user).catch(console.error);
          
          // Process affiliate attribution for new/returning users
          if (event === 'SIGNED_IN') {
            setTimeout(() => {
              processAffiliateAttribution(session.user.id).catch(console.error);
            }, 100);
          }
        } else {
          setSubscriptionData(null);
        }

        // Handle auth events
        if (event === 'SIGNED_IN') {
          toast({
            title: "Welcome back!",
            description: "You've been signed in successfully.",
          });
        } else if (event === 'SIGNED_OUT') {
          toast({
            title: "Signed out",
            description: "You've been signed out successfully.",
          });
        }
      }
    );

    // Check for existing session and initialize
    const initializeAuth = async () => {
      try {
        console.log('Initializing auth...');
        const { data: { session } } = await supabase.auth.getSession();
        
        if (!isMounted) return;
        
        console.log('Session found:', !!session);
        setSession(session);
        setUser(session?.user ?? null);
        
        // Check subscription in background without blocking auth
        if (session?.user) {
          checkSubscription(session.user).catch(console.error);
        }
        
        console.log('Auth initialization complete');
      } catch (error) {
        console.error('Error initializing auth:', error);
        // Ensure we still set the session state even on error
        setSession(null);
        setUser(null);
      } finally {
        if (isMounted) {
          console.log('Setting loading to false');
          setLoading(false);
        }
      }
    };

    initializeAuth();

    return () => {
      isMounted = false;
      subscription.unsubscribe();
    };
  }, [toast]);

  const signUp = async (email: string, password: string, displayName?: string) => {
    const redirectUrl = `${window.location.origin}/`;
    
    const { error } = await supabase.auth.signUp({
      email,
      password,
      options: {
        emailRedirectTo: redirectUrl,
        data: {
          display_name: displayName
        }
      }
    });

    if (error) {
      toast({
        variant: "destructive",
        title: "Sign up failed",
        description: error.message,
      });
    } else {
      toast({
        title: "Check your email",
        description: "We've sent you a verification link.",
      });
    }

    return { error };
  };

  const signIn = async (email: string, password: string) => {
    const { error } = await supabase.auth.signInWithPassword({
      email,
      password,
    });

    if (error) {
      toast({
        variant: "destructive",
        title: "Sign in failed", 
        description: error.message,
      });
    }

    return { error };
  };

  const signOut = async () => {
    await supabase.auth.signOut();
  };

  const signInWithGoogle = async () => {
    const { error } = await supabase.auth.signInWithOAuth({
      provider: 'google',
      options: {
        redirectTo: `${window.location.origin}/dashboard`
      }
    });

    if (error) {
      toast({
        variant: "destructive",
        title: "Google sign in failed",
        description: error.message,
      });
    }

    return { error };
  };

  const signInWithDiscord = async () => {
    const { error } = await supabase.auth.signInWithOAuth({
      provider: 'discord',
      options: {
        redirectTo: `${window.location.origin}/dashboard`
      }
    });

    if (error) {
      toast({
        variant: "destructive",
        title: "Discord sign in failed",
        description: error.message,
      });
    }

    return { error };
  };

  return (
    <AuthContext.Provider 
      value={{
        user,
        session,
        loading,
        subscriptionData,
        refreshSubscription,
        signUp,
        signIn,
        signInWithGoogle,
        signInWithDiscord,
        signOut,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error("useAuth must be used within an AuthProvider");
  }
  return context;
}