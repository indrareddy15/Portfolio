import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";

interface SystemSettings {
  maintenance_mode: boolean;
  new_registrations: boolean;
  affiliate_program: boolean;
  default_commission_rate: number;
  min_payout_amount: number;
  payout_processing_days: number;
  support_email: string;
  company_name: string;
  site_url: string;
}

const defaultSettings: SystemSettings = {
  maintenance_mode: false,
  new_registrations: true,
  affiliate_program: false, // Default to disabled for free version
  default_commission_rate: 30,
  min_payout_amount: 50,
  payout_processing_days: 14,
  support_email: "support@piptrackr.com",
  company_name: "PipTrackr.com",
  site_url: "https://piptrackr.com"
};

export function useSystemSettings() {
  const [settings, setSettings] = useState<SystemSettings>(defaultSettings);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchSettings = async () => {
      try {
        const { data, error } = await supabase
          .from('cms_blocks')
          .select('*')
          .eq('key', 'system_settings')
          .single();

        if (error && error.code !== 'PGRST116') {
          throw error;
        }

        if (data?.content_json) {
          setSettings({ ...defaultSettings, ...(data.content_json as Partial<SystemSettings>) });
        }
      } catch (error) {
        console.error('Error fetching system settings:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchSettings();

    // Subscribe to real-time changes
    const channel = supabase
      .channel('system-settings-changes')
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'cms_blocks',
          filter: 'key=eq.system_settings'
        },
        (payload) => {
          if (payload.new && 'content_json' in payload.new && payload.new.content_json) {
            setSettings({ ...defaultSettings, ...(payload.new.content_json as Partial<SystemSettings>) });
          }
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, []);

  return {
    settings,
    loading,
    isAffiliateEnabled: settings.affiliate_program,
    isMaintenanceMode: settings.maintenance_mode,
    isRegistrationEnabled: settings.new_registrations
  };
}