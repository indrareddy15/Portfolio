import { useState, useEffect, useCallback, useRef, useMemo } from 'react';
import { marketDataService, type MarketDataItem, type MarketDataResponse } from '@/services/marketDataService';
import { useToast } from '@/hooks/use-toast';

interface UseRealTimeMarketDataOptions {
  symbols?: string[];
  updateInterval?: number; // milliseconds
  enableWebSocket?: boolean;
  onUpdate?: (data: MarketDataResponse) => void;
  onError?: (error: Error) => void;
}

interface MarketDataState {
  data: MarketDataResponse;
  isLoading: boolean;
  isConnected: boolean;
  lastUpdate: Date | null;
  error: string | null;
}

export function useRealTimeMarketData(options: UseRealTimeMarketDataOptions = {}) {
  const {
    symbols = ['EURUSD', 'GBPUSD', 'USDJPY', 'SPX', 'NDX'],
    updateInterval = 5000, // 5 seconds
    enableWebSocket = true,
    onUpdate,
    onError
  } = options;

  // Memoize symbols array to prevent unnecessary re-renders
  const memoizedSymbols = useMemo(() => symbols, [JSON.stringify(symbols)]);

  const [state, setState] = useState<MarketDataState>({
    data: {},
    isLoading: true,
    isConnected: false,
    lastUpdate: null,
    error: null
  });

  const intervalRef = useRef<NodeJS.Timeout | null>(null);
  const unsubscribeRef = useRef<Function | null>(null);
  const isInitializedRef = useRef(false);
  const { toast } = useToast();

  // Update state helper - stable reference
  const updateState = useCallback((updates: Partial<MarketDataState>) => {
    setState(prev => ({ ...prev, ...updates }));
  }, []);

  // Fetch data function - use memoized symbols
  const fetchData = useCallback(async (showToast = false) => {
    try {
      updateState({ isLoading: true, error: null });
      
      const data = await marketDataService.fetchMarketData(memoizedSymbols);
      
      updateState({
        data,
        isLoading: false,
        isConnected: true,
        lastUpdate: new Date(),
        error: null
      });

      onUpdate?.(data);

      if (showToast) {
        toast({
          title: "Market Data Updated",
          description: "Real-time prices refreshed successfully",
          duration: 2000,
        });
      }

      // Show connection status on first load
      if (!isInitializedRef.current) {
        isInitializedRef.current = true;
        toast({
          title: "Live Market Data Connected",
          description: "Real-time price feeds are now active",
          duration: 3000,
        });
      }

    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Failed to fetch market data';
      
      updateState({
        isLoading: false,
        isConnected: false,
        error: errorMessage
      });

      onError?.(error instanceof Error ? error : new Error(errorMessage));
      
      console.error('Market data fetch error:', error);
    }
  }, [memoizedSymbols, updateState, onUpdate, onError, toast]);

  // Manual refresh function
  const refresh = useCallback(() => {
    fetchData(true);
  }, [fetchData]);

  // WebSocket subscription handler
  const handleWebSocketUpdate = useCallback((symbol: string, marketData: MarketDataItem) => {
    setState(prev => ({
      ...prev,
      data: {
        ...prev.data,
        [symbol]: marketData
      },
      lastUpdate: new Date(),
      isConnected: true,
      error: null
    }));

    onUpdate?.({ [symbol]: marketData });
  }, [onUpdate]);

  // Setup real-time updates - use memoized symbols and stable references
  useEffect(() => {
    let mounted = true;

    const setupRealTimeData = async () => {
      // Initial data fetch
      await fetchData();

      if (!mounted) return;

      // Setup WebSocket if enabled
      if (enableWebSocket) {
        try {
          const unsubscribe = marketDataService.subscribeToRealTimeData(
            memoizedSymbols,
            handleWebSocketUpdate
          );
          unsubscribeRef.current = unsubscribe;
          
          console.log('WebSocket subscription established for symbols:', memoizedSymbols);
        } catch (error) {
          console.warn('WebSocket setup failed, falling back to polling:', error);
          // Fallback to polling
        }
      }

      // Setup polling as backup or primary method
      if (intervalRef.current) {
        clearInterval(intervalRef.current);
      }
      
      intervalRef.current = setInterval(() => {
        if (mounted) {
          fetchData();
        }
      }, updateInterval);
    };

    setupRealTimeData();

    return () => {
      mounted = false;
      
      // Cleanup interval
      if (intervalRef.current) {
        clearInterval(intervalRef.current);
        intervalRef.current = null;
      }
      
      // Cleanup WebSocket subscription
      if (unsubscribeRef.current) {
        unsubscribeRef.current();
        unsubscribeRef.current = null;
      }
    };
  }, [memoizedSymbols, updateInterval, enableWebSocket, fetchData, handleWebSocketUpdate]);

  // Connection status monitoring
  useEffect(() => {
    const checkConnection = setInterval(() => {
      const now = new Date();
      const lastUpdate = state.lastUpdate;
      
      if (lastUpdate) {
        const timeSinceUpdate = now.getTime() - lastUpdate.getTime();
        const isStale = timeSinceUpdate > updateInterval * 3; // Consider stale if 3x update interval
        
        if (isStale && state.isConnected) {
          updateState({ isConnected: false });
        }
      }
    }, updateInterval);

    return () => clearInterval(checkConnection);
  }, [state.lastUpdate, state.isConnected, updateInterval, updateState]);

  // Format helpers
  const formatPrice = useCallback((symbol: string, price: number) => {
    return marketDataService.formatPrice(symbol, price);
  }, []);

  const formatChange = useCallback((change: number, changePercent: number) => {
    return marketDataService.formatChange(change, changePercent);
  }, []);

  // Get specific symbol data
  const getSymbolData = useCallback((symbol: string): MarketDataItem | null => {
    return state.data[symbol] || null;
  }, [state.data]);

  // Connection status indicator
  const getConnectionStatus = useCallback(() => {
    if (state.isLoading && Object.keys(state.data).length === 0) {
      return { status: 'connecting', message: 'Connecting to market data...' };
    }
    if (state.error) {
      return { status: 'error', message: state.error };
    }
    if (!state.isConnected) {
      return { status: 'disconnected', message: 'Market data connection lost' };
    }
    return { status: 'connected', message: 'Live market data active' };
  }, [state.isLoading, state.data, state.error, state.isConnected]);

  return {
    // Data
    data: state.data,
    marketData: state.data, // Alias for backward compatibility
    
    // Status
    isLoading: state.isLoading,
    isConnected: state.isConnected,
    lastUpdate: state.lastUpdate,
    error: state.error,
    connectionStatus: getConnectionStatus(),
    
    // Actions
    refresh,
    
    // Helpers
    formatPrice,
    formatChange,
    getSymbolData,
    
    // Statistics
    symbols: memoizedSymbols,
    dataCount: Object.keys(state.data).length
  };
}

// Hook for single symbol
export function useSymbolData(symbol: string, options: Omit<UseRealTimeMarketDataOptions, 'symbols'> = {}) {
  const { data, ...rest } = useRealTimeMarketData({
    ...options,
    symbols: [symbol]
  });

  return {
    ...rest,
    symbolData: data[symbol] || null,
    data
  };
}

// Hook for forex pairs only
export function useForexData(pairs: string[] = ['EURUSD', 'GBPUSD', 'USDJPY'], options: UseRealTimeMarketDataOptions = {}) {
  return useRealTimeMarketData({
    ...options,
    symbols: pairs
  });
}

// Hook for indices only  
export function useIndicesData(indices: string[] = ['SPX', 'NDX', 'DJI'], options: UseRealTimeMarketDataOptions = {}) {
  return useRealTimeMarketData({
    ...options,
    symbols: indices
  });
}