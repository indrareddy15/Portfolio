import { useMutation } from '@tanstack/react-query';
import { toast } from 'sonner';
import { useSupabaseAuth } from './useSupabaseAuth';

interface SendEmailRequest {
  email: string;
  type: 'signup_confirm' | 'password_reset' | 'magic_link' | 'invite';
  redirectTo?: string;
}

export function useEmailService() {
  const { 
    signupConfirmMutation, 
    passwordResetMutation, 
    magicLinkMutation, 
    inviteUserMutation,
    isLoading 
  } = useSupabaseAuth();

  const sendWelcomeEmail = async (to: string, name: string, dashboardUrl: string): Promise<boolean> => {
    // For welcome emails, we'll use the signup confirmation flow
    signupConfirmMutation.mutate({ 
      email: to, 
      redirectTo: dashboardUrl 
    });
    return true;
  };

  const sendTeamInvite = async (
    to: string, 
    inviterName: string, 
    teamName: string, 
    inviteUrl: string
  ): Promise<boolean> => {
    inviteUserMutation.mutate({ 
      email: to, 
      redirectTo: inviteUrl 
    });
    return true;
  };

  const sendAffiliateApproval = async (
    to: string,
    affiliateCode: string,
    commissionRate: number,
    referralLink: string
  ): Promise<boolean> => {
    // For affiliate approvals, we'll send a magic link with custom redirect
    magicLinkMutation.mutate({ 
      email: to, 
      redirectTo: `${window.location.origin}/app/affiliate?code=${affiliateCode}&rate=${commissionRate}&link=${encodeURIComponent(referralLink)}` 
    });
    return true;
  };

  const sendTestEmail = async (
    to: string,
    subject?: string,
    html?: string
  ): Promise<boolean> => {
    // For test emails, use magic link
    magicLinkMutation.mutate({ 
      email: to, 
      redirectTo: `${window.location.origin}/app` 
    });
    return true;
  };

  const sendPasswordReset = async (to: string, resetUrl: string, userName?: string): Promise<boolean> => {
    passwordResetMutation.mutate({ 
      email: to, 
      redirectTo: resetUrl 
    });
    return true;
  };

  const sendEmailVerification = async (to: string, verificationUrl: string, userName?: string): Promise<boolean> => {
    signupConfirmMutation.mutate({ 
      email: to, 
      redirectTo: verificationUrl 
    });
    return true;
  };

  return {
    sendWelcomeEmail,
    sendTeamInvite,
    sendAffiliateApproval,
    sendTestEmail,
    sendPasswordReset,
    sendEmailVerification,
    isLoading
  };
}