import { useState, useEffect, useCallback } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/hooks/useAuth';
import { useToast } from '@/hooks/use-toast';

export interface PropChallenge {
  id: string;
  user_id: string;
  challenge_name: string;
  start_date: string;
  end_date: string;
  target_profit: number | null;
  max_daily_loss: number;
  max_overall_loss: number;
  min_trading_days: number;
  max_lot_size: number | null;
  current_profit: number;
  current_daily_loss: number;
  current_overall_loss: number;
  trading_days_count: number;
  status: string;
  rules_json: any;
  created_at: string;
  updated_at: string;
}

export interface DailyResult {
  id: string;
  challenge_id: string;
  user_id: string;
  date: string;
  daily_pnl: number;
  passed: boolean;
  fail_reasons: string[];
  trades_count: number;
  largest_lot: number;
  created_at: string;
}

export const usePropChallenges = () => {
  const { user } = useAuth();
  const { toast } = useToast();
  const [challenges, setChallenges] = useState<PropChallenge[]>([]);
  const [dailyResults, setDailyResults] = useState<DailyResult[]>([]);
  const [selectedChallenge, setSelectedChallenge] = useState<string>("");
  const [loading, setLoading] = useState(true);

  // Fetch challenges
  const fetchChallenges = useCallback(async () => {
    if (!user) return;

    try {
      const { data, error } = await supabase
        .from('prop_challenges')
        .select('*')
        .eq('user_id', user.id)
        .order('created_at', { ascending: false });

      if (error) throw error;

      setChallenges(data || []);
      
      // Auto-select first challenge if none selected
      if (data && data.length > 0 && !selectedChallenge) {
        setSelectedChallenge(data[0].id);
      }
    } catch (error: any) {
      console.error('Error fetching challenges:', error);
      toast({
        variant: "destructive",
        title: "Error loading challenges",
        description: error.message,
      });
    } finally {
      setLoading(false);
    }
  }, [user, toast, selectedChallenge]);

  // Fetch daily results for selected challenge
  const fetchDailyResults = useCallback(async () => {
    if (!user || !selectedChallenge) return;

    try {
      const { data, error } = await supabase
        .from('challenge_daily_results')
        .select('*')
        .eq('challenge_id', selectedChallenge)
        .order('date', { ascending: false });

      if (error) throw error;
      setDailyResults(data || []);
    } catch (error: any) {
      console.error('Error fetching daily results:', error);
      toast({
        variant: "destructive",
        title: "Error loading daily results",
        description: error.message,
      });
    }
  }, [user, selectedChallenge, toast]);

  // Auto-update challenge when trades are added/updated
  const updateChallengeFromTrades = useCallback(async (challengeId?: string) => {
    const targetChallengeId = challengeId || selectedChallenge;
    if (!user || !targetChallengeId) return;

    try {
      console.log('🎯 Auto-updating prop challenge from trades...');
      
      // Get challenge data
      const challenge = challenges.find(c => c.id === targetChallengeId);
      if (!challenge) return;

      // Get trades for this challenge period
      const { data: trades } = await supabase
        .from('trades')
        .select('*')
        .eq('user_id', user.id)
        .gte('opened_at', challenge.start_date)
        .lte('opened_at', challenge.end_date)
        .not('pnl', 'is', null);

      if (!trades) return;

      // Calculate daily stats
      const dailyPnL: { [key: string]: number } = {};
      const dailyTrades: { [key: string]: any[] } = {};

      trades.forEach(trade => {
        const date = trade.opened_at.split('T')[0];
        if (!dailyPnL[date]) {
          dailyPnL[date] = 0;
          dailyTrades[date] = [];
        }
        dailyPnL[date] += trade.pnl || 0;
        dailyTrades[date].push(trade);
      });

      // Calculate overall stats
      const totalPnL = trades.reduce((sum, t) => sum + (t.pnl || 0), 0);
      const maxDailyLoss = Math.min(...Object.values(dailyPnL), 0);
      const tradingDays = Object.keys(dailyPnL).length;

      // Check challenge status
      let status = challenge.status;
      const failReasons: string[] = [];

      if (Math.abs(maxDailyLoss) > challenge.max_daily_loss) {
        status = 'failed';
        failReasons.push(`Exceeded daily loss limit: $${Math.abs(maxDailyLoss).toFixed(2)}`);
      }

      if (Math.abs(totalPnL) > challenge.max_overall_loss && totalPnL < 0) {
        status = 'failed';
        failReasons.push(`Exceeded overall loss limit: $${Math.abs(totalPnL).toFixed(2)}`);
      }

      const endDate = new Date(challenge.end_date);
      const today = new Date();
      
      if (today > endDate) {
        if (totalPnL >= (challenge.target_profit || 0) && tradingDays >= challenge.min_trading_days) {
          status = 'passed';
        } else {
          status = 'failed';
          if (totalPnL < (challenge.target_profit || 0)) {
            failReasons.push('Did not reach profit target');
          }
          if (tradingDays < challenge.min_trading_days) {
            failReasons.push(`Insufficient trading days: ${tradingDays}/${challenge.min_trading_days}`);
          }
        }
      }

      // Update challenge
      const { error: updateError } = await supabase
        .from('prop_challenges')
        .update({
          current_profit: totalPnL,
          current_daily_loss: maxDailyLoss,
          current_overall_loss: totalPnL < 0 ? Math.abs(totalPnL) : 0,
          trading_days_count: tradingDays,
          status,
          updated_at: new Date().toISOString()
        })
        .eq('id', targetChallengeId);

      if (updateError) throw updateError;

      // Update daily results
      for (const [date, pnl] of Object.entries(dailyPnL)) {
        const tradesForDay = dailyTrades[date];
        const largestLot = Math.max(...tradesForDay.map(t => t.size || 0));
        const dayPassed = Math.abs(pnl) <= challenge.max_daily_loss && 
                         (!challenge.max_lot_size || largestLot <= challenge.max_lot_size);

        const dayFailReasons: string[] = [];
        if (Math.abs(pnl) > challenge.max_daily_loss) {
          dayFailReasons.push('Exceeded daily loss limit');
        }
        if (challenge.max_lot_size && largestLot > challenge.max_lot_size) {
          dayFailReasons.push('Exceeded lot size limit');
        }

        await supabase
          .from('challenge_daily_results')
          .upsert({
            challenge_id: targetChallengeId,
            user_id: user.id,
            date,
            daily_pnl: pnl,
            passed: dayPassed,
            fail_reasons: dayFailReasons,
            trades_count: tradesForDay.length,
            largest_lot: largestLot,
          });
      }

      console.log('✅ Prop challenge updated successfully');
      
    } catch (error: any) {
      console.error('Error updating challenge from trades:', error);
    }
  }, [user, selectedChallenge, challenges]);

  // Initial data fetch
  useEffect(() => {
    if (user) {
      fetchChallenges();
    }
  }, [fetchChallenges]);

  // Fetch daily results when challenge changes
  useEffect(() => {
    if (selectedChallenge) {
      fetchDailyResults();
    }
  }, [fetchDailyResults]);

  // Set up real-time subscriptions
  useEffect(() => {
    if (!user) return;

    const channel = supabase.channel(`prop-challenges-${user.id}`)
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'prop_challenges',
          filter: `user_id=eq.${user.id}`
        },
        (payload) => {
          console.log('🎯 Prop challenge updated:', payload);
          if (payload.eventType === 'INSERT') {
            const newChallenge = payload.new as PropChallenge;
            setChallenges(prev => [newChallenge, ...prev]);
          } else if (payload.eventType === 'UPDATE') {
            const updatedChallenge = payload.new as PropChallenge;
            setChallenges(prev => prev.map(c => 
              c.id === updatedChallenge.id ? updatedChallenge : c
            ));
          } else if (payload.eventType === 'DELETE') {
            const deletedId = payload.old.id;
            setChallenges(prev => prev.filter(c => c.id !== deletedId));
          }
        }
      )
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'challenge_daily_results',
          filter: `user_id=eq.${user.id}`
        },
        (payload) => {
          console.log('📅 Daily result updated:', payload);
          if (payload.eventType === 'INSERT' || payload.eventType === 'UPDATE') {
            const result = payload.new as DailyResult;
            if (result.challenge_id === selectedChallenge) {
              setDailyResults(prev => {
                const existing = prev.find(r => r.id === result.id);
                if (existing) {
                  return prev.map(r => r.id === result.id ? result : r);
                } else {
                  return [result, ...prev].sort((a, b) => 
                    new Date(b.date).getTime() - new Date(a.date).getTime()
                  );
                }
              });
            }
          }
        }
      )
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'trades',
          filter: `user_id=eq.${user.id}`
        },
        (payload) => {
          console.log('💰 Trade updated - checking prop challenges:', payload);
          // Auto-update challenges when trades change
          setTimeout(() => updateChallengeFromTrades(), 2000);
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [user, selectedChallenge, updateChallengeFromTrades]);

  return {
    challenges,
    dailyResults,
    selectedChallenge,
    setSelectedChallenge,
    loading,
  refetchChallenges: fetchChallenges,
    refetchDailyResults: fetchDailyResults,
    updateChallengeFromTrades,
    deleteChallenge: async (challengeId: string) => {
      if (!user) return;
      
      try {
        // Delete daily results first
        await supabase
          .from('challenge_daily_results')
          .delete()
          .eq('challenge_id', challengeId);
        
        // Delete the challenge
        const { error } = await supabase
          .from('prop_challenges')
          .delete()
          .eq('id', challengeId)
          .eq('user_id', user.id);
          
        if (error) throw error;
        
        toast({
          title: "Challenge Deleted",
          description: "Challenge and all related data have been removed.",
        });
        
        // Update local state
        setChallenges(prev => prev.filter(c => c.id !== challengeId));
        if (selectedChallenge === challengeId) {
          setSelectedChallenge("");
        }
        
      } catch (error: any) {
        toast({
          variant: "destructive",
          title: "Error deleting challenge",
          description: error.message,
        });
      }
    },
  };
};