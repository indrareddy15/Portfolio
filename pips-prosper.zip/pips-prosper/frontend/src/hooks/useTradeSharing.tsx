import { useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";

export interface TradeShare {
  id: string;
  trade_id: string;
  user_id: string;
  share_token: string;
  title?: string;
  description?: string;
  is_public: boolean;
  is_active: boolean;
  view_count: number;
  certificate_generated: boolean;
  certificate_url?: string;
  social_image_url?: string;
  expires_at?: string;
  created_at: string;
  updated_at: string;
}

export interface TradeShareCreateData {
  trade_id: string;
  title?: string;
  description?: string;
  is_public?: boolean;
  expires_at?: string;
}

export const useTradeSharing = () => {
  const [loading, setLoading] = useState(false);
  const { toast } = useToast();

  const generateShareToken = async (): Promise<string | null> => {
    try {
      const { data, error } = await supabase.rpc('generate_share_token');
      if (error) throw error;
      return data;
    } catch (error) {
      console.error('Error generating share token:', error);
      return null;
    }
  };

  const createTradeShare = async (shareData: TradeShareCreateData): Promise<TradeShare | null> => {
    setLoading(true);
    try {
      const token = await generateShareToken();
      if (!token) throw new Error('Failed to generate share token');

      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error('User not authenticated');

      const { data, error } = await supabase
        .from('trade_shares')
        .insert({
          ...shareData,
          user_id: user.id,
          share_token: token,
          is_public: shareData.is_public ?? true,
        })
        .select()
        .single();

      if (error) throw error;

      toast({
        title: "Trade Shared Successfully! 🚀",
        description: "Your trade is now shareable on social media",
      });

      return data;
    } catch (error: any) {
      toast({
        title: "Failed to Share Trade",
        description: error.message || "Please try again",
        variant: "destructive",
      });
      return null;
    } finally {
      setLoading(false);
    }
  };

  const getTradeShares = async (tradeId?: string): Promise<TradeShare[]> => {
    try {
      let query = supabase
        .from('trade_shares')
        .select('*')
        .eq('user_id', (await supabase.auth.getUser()).data.user?.id)
        .order('created_at', { ascending: false });

      if (tradeId) {
        query = query.eq('trade_id', tradeId);
      }

      const { data, error } = await query;
      if (error) throw error;
      return data || [];
    } catch (error) {
      console.error('Error fetching trade shares:', error);
      return [];
    }
  };

  const getPublicTradeShare = async (shareToken: string): Promise<TradeShare | null> => {
    try {
      // Increment view count
      await supabase.rpc('increment_share_view', { share_token_param: shareToken });

      const { data, error } = await supabase
        .from('trade_shares')
        .select('*')
        .eq('share_token', shareToken)
        .eq('is_active', true)
        .single();

      if (error) throw error;
      return data;
    } catch (error) {
      console.error('Error fetching public trade share:', error);
      return null;
    }
  };

  const updateTradeShare = async (id: string, updates: Partial<TradeShare>): Promise<boolean> => {
    setLoading(true);
    try {
      const { error } = await supabase
        .from('trade_shares')
        .update(updates)
        .eq('id', id);

      if (error) throw error;

      toast({
        title: "Share Updated",
        description: "Your share settings have been updated",
      });

      return true;
    } catch (error: any) {
      toast({
        title: "Update Failed",
        description: error.message || "Please try again",
        variant: "destructive",
      });
      return false;
    } finally {
      setLoading(false);
    }
  };

  const deleteTradeShare = async (id: string): Promise<boolean> => {
    setLoading(true);
    try {
      const { error } = await supabase
        .from('trade_shares')
        .delete()
        .eq('id', id);

      if (error) throw error;

      toast({
        title: "Share Deleted",
        description: "Trade share has been removed",
      });

      return true;
    } catch (error: any) {
      toast({
        title: "Delete Failed",
        description: error.message || "Please try again",
        variant: "destructive",
      });
      return false;
    } finally {
      setLoading(false);
    }
  };

  const generateCertificate = async (shareId: string): Promise<string | null> => {
    setLoading(true);
    try {
      const { data, error } = await supabase.functions.invoke('generate-trade-certificate', {
        body: { shareId }
      });

      if (error) throw error;

      toast({
        title: "Certificate Generated! 🏆",
        description: "Your trading certificate is ready to share",
      });

      return data?.certificateUrl || null;
    } catch (error: any) {
      toast({
        title: "Certificate Generation Failed",
        description: error.message || "Please try again",
        variant: "destructive",
      });
      return null;
    } finally {
      setLoading(false);
    }
  };

  const getShareAnalytics = async (shareId: string) => {
    try {
      const { data, error } = await supabase
        .from('share_analytics')
        .select('*')
        .eq('trade_share_id', shareId)
        .order('created_at', { ascending: false });

      if (error) throw error;
      return data || [];
    } catch (error) {
      console.error('Error fetching share analytics:', error);
      return [];
    }
  };

  return {
    loading,
    createTradeShare,
    getTradeShares,
    getPublicTradeShare,
    updateTradeShare,
    deleteTradeShare,
    generateCertificate,
    getShareAnalytics,
  };
};