import { useCallback } from 'react';
import { trackEvent, trackBusinessEvent, trackConversion, trackEnhancedConversion } from '@/components/GoogleTracking';

export interface UserTraits {
  userId?: string;
  email?: string;
  phone?: string;
  role?: 'user' | 'affiliate' | 'admin' | 'owner';
  plan?: 'free' | 'pro' | 'elite';
}

export const useAnalytics = () => {
  // Generic event tracking
  const track = useCallback((eventName: string, properties: Record<string, any> = {}) => {
    trackEvent(eventName, properties);
  }, []);

  // Business-specific event tracking
  const trackBusinessAction = useCallback((action: string, data: any = {}) => {
    trackBusinessEvent(action, data);
  }, []);

  // User lifecycle events
  const trackSignupStarted = useCallback((source?: string) => {
    trackBusinessEvent('signup_started', {
      source,
      timestamp: new Date().toISOString()
    });
  }, []);

  const trackSignupCompleted = useCallback((userTraits: UserTraits) => {
    trackBusinessEvent('signup_completed', {
      user_role: userTraits.role,
      user_plan: userTraits.plan,
      timestamp: new Date().toISOString()
    });
    
    // Track conversion for Google Ads
    trackConversion();
  }, []);

  // Trading events
  const trackImportStarted = useCallback((source: string) => {
    trackBusinessEvent('import_started', {
      source,
      timestamp: new Date().toISOString()
    });
  }, []);

  const trackImportCompleted = useCallback((tradesCount: number, source: string) => {
    trackBusinessEvent('import_done', {
      trades_count: tradesCount,
      source,
      timestamp: new Date().toISOString()
    });
  }, []);

  // Subscription events
  const trackSubscriptionCreated = useCallback((planName: string, amount: number, userTraits: UserTraits) => {
    trackBusinessEvent('subscription_created', {
      plan_name: planName,
      value: amount,
      currency: 'USD',
      user_role: userTraits.role,
      timestamp: new Date().toISOString()
    });
    
    // Track enhanced conversion with user data
    trackEnhancedConversion(userTraits.email, userTraits.phone, amount);
  }, []);

  const trackSubscriptionUpgraded = useCallback((fromPlan: string, toPlan: string, amount: number) => {
    trackBusinessEvent('subscription_upgraded', {
      from_plan: fromPlan,
      to_plan: toPlan,
      value: amount,
      currency: 'USD',
      timestamp: new Date().toISOString()
    });
  }, []);

  const trackSubscriptionCanceled = useCallback((planName: string, reason?: string) => {
    trackBusinessEvent('subscription_canceled', {
      plan_name: planName,
      cancellation_reason: reason,
      timestamp: new Date().toISOString()
    });
  }, []);

  // Affiliate events
  const trackAffiliateClick = useCallback((affiliateCode: string, source?: string) => {
    trackBusinessEvent('affiliate_click', {
      affiliate_code: affiliateCode,
      source,
      timestamp: new Date().toISOString()
    });
  }, []);

  const trackCommissionCreated = useCallback((affiliateId: string, amount: number, planName: string) => {
    trackBusinessEvent('commission_created', {
      affiliate_id: affiliateId,
      commission_amount: amount,
      plan_name: planName,
      currency: 'USD',
      timestamp: new Date().toISOString()
    });
  }, []);

  const trackPayoutRequested = useCallback((affiliateId: string, amount: number, method: string) => {
    trackBusinessEvent('payout_requested', {
      affiliate_id: affiliateId,
      payout_amount: amount,
      payout_method: method,
      currency: 'USD',
      timestamp: new Date().toISOString()
    });
  }, []);

  const trackPayoutPaid = useCallback((affiliateId: string, amount: number, reference: string) => {
    trackBusinessEvent('payout_paid', {
      affiliate_id: affiliateId,
      payout_amount: amount,
      payment_reference: reference,
      currency: 'USD',
      timestamp: new Date().toISOString()
    });
  }, []);

  // Marketing events
  const trackUTMLinkCreated = useCallback((campaign: string, source: string, medium: string) => {
    trackBusinessEvent('utm_link_created', {
      utm_campaign: campaign,
      utm_source: source,
      utm_medium: medium,
      timestamp: new Date().toISOString()
    });
  }, []);

  const trackExperimentStarted = useCallback((experimentName: string, variant: string) => {
    trackBusinessEvent('experiment_started', {
      experiment_name: experimentName,
      variant,
      timestamp: new Date().toISOString()
    });
  }, []);

  const trackExperimentEnded = useCallback((experimentName: string, outcome: string) => {
    trackBusinessEvent('experiment_ended', {
      experiment_name: experimentName,
      outcome,
      timestamp: new Date().toISOString()
    });
  }, []);

  // Page tracking
  const trackPageView = useCallback((pageName: string, userTraits?: UserTraits) => {
    trackBusinessEvent('page_view', {
      page_name: pageName,
      user_role: userTraits?.role,
      user_plan: userTraits?.plan,
      timestamp: new Date().toISOString()
    });
  }, []);

  return {
    track,
    trackBusinessAction,
    trackSignupStarted,
    trackSignupCompleted,
    trackImportStarted,
    trackImportCompleted,
    trackSubscriptionCreated,
    trackSubscriptionUpgraded,
    trackSubscriptionCanceled,
    trackAffiliateClick,
    trackCommissionCreated,
    trackPayoutRequested,
    trackPayoutPaid,
    trackUTMLinkCreated,
    trackExperimentStarted,
    trackExperimentEnded,
    trackPageView
  };
};