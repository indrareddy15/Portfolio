import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/hooks/useAuth';

export function useAccountDisplay(accountId?: string | null) {
  const [accountName, setAccountName] = useState<string>('');
  const [loading, setLoading] = useState(false);
  const { user } = useAuth();

  useEffect(() => {
    if (!accountId || accountId === 'all') {
      setAccountName('All Accounts');
      return;
    }

    if (!user) return;

    const fetchAccountName = async () => {
      setLoading(true);
      try {
        const { data, error } = await supabase
          .from('accounts')
          .select('nickname, name')
          .eq('id', accountId)
          .eq('user_id', user.id)
          .single();

        if (error) {
          console.error('Error fetching account:', error);
          setAccountName('Unknown Account');
        } else {
          setAccountName(data?.nickname || data?.name || 'Account');
        }
      } catch (error) {
        console.error('Error fetching account name:', error);
        setAccountName('Unknown Account');
      } finally {
        setLoading(false);
      }
    };

    fetchAccountName();
  }, [accountId, user]);

  return { accountName, loading };
}