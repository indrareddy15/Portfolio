import { supabase } from '@/integrations/supabase/client';

interface AuthEmailOptions {
  type: 'signup_confirm' | 'password_reset' | 'invite' | 'magic_link';
  email: string;
  redirectTo?: string;
  data?: Record<string, any>;
}

interface AuthEmailResponse {
  success: boolean;
  error?: string;
}

// Rate limiting: max 3 emails per hour per recipient
const RATE_LIMIT_MAX = 3;
const RATE_LIMIT_WINDOW = 60 * 60 * 1000; // 1 hour in milliseconds

async function checkRateLimit(email: string, type: string): Promise<boolean> {
  const oneHourAgo = new Date(Date.now() - RATE_LIMIT_WINDOW);
  
  const { data, error } = await supabase
    .from('email_logs')
    .select('id')
    .eq('to_email', email)
    .eq('template_key', type)
    .gte('created_at', oneHourAgo.toISOString());

  if (error) {
    console.error('Rate limit check error:', error);
    return true; // Allow if we can't check
  }

  return (data?.length || 0) < RATE_LIMIT_MAX;
}

async function logEmailAction(options: AuthEmailOptions, success: boolean, error?: string) {
  try {
    await supabase.from('email_logs').insert({
      template_key: options.type,
      to_email: options.email,
      subject: getSubjectForType(options.type),
      status: success ? 'sent' : 'failed',
      last_error: error || null,
      payload: {
        type: options.type,
        redirectTo: options.redirectTo,
        data: options.data,
        timestamp: new Date().toISOString()
      }
    });
  } catch (logError) {
    console.error('Failed to log email action:', logError);
  }
}

function getSubjectForType(type: string): string {
  switch (type) {
    case 'signup_confirm':
      return 'Confirm your PipTrackr account';
    case 'password_reset':
      return 'Reset your PipTrackr password';
    case 'invite':
      return "You've been invited to PipTrackr";
    case 'magic_link':
      return 'Sign in to PipTrackr';
    default:
      return 'PipTrackr Notification';
  }
}

export async function sendSignupConfirmation(email: string, redirectTo?: string): Promise<AuthEmailResponse> {
  const type = 'signup_confirm';
  
  // Check rate limit
  if (!(await checkRateLimit(email, type))) {
    const error = 'Rate limit exceeded. Please wait before requesting another email.';
    await logEmailAction({ type, email, redirectTo }, false, error);
    return { success: false, error };
  }

  try {
    const { error } = await supabase.auth.resend({
      type: 'signup',
      email,
      options: {
        emailRedirectTo: redirectTo || `${window.location.origin}/`
      }
    });

    if (error) {
      await logEmailAction({ type, email, redirectTo }, false, error.message);
      return { success: false, error: error.message };
    }

    await logEmailAction({ type, email, redirectTo }, true);
    return { success: true };
  } catch (err: any) {
    const errorMessage = err.message || 'Failed to send signup confirmation';
    await logEmailAction({ type, email, redirectTo }, false, errorMessage);
    return { success: false, error: errorMessage };
  }
}

export async function sendPasswordReset(email: string, redirectTo?: string): Promise<AuthEmailResponse> {
  const type = 'password_reset';
  
  // Check rate limit
  if (!(await checkRateLimit(email, type))) {
    const error = 'Rate limit exceeded. Please wait before requesting another email.';
    await logEmailAction({ type, email, redirectTo }, false, error);
    return { success: false, error };
  }

  try {
    const { error } = await supabase.auth.resetPasswordForEmail(email, {
      redirectTo: redirectTo || `${window.location.origin}/auth/reset-password`
    });

    if (error) {
      await logEmailAction({ type, email, redirectTo }, false, error.message);
      return { success: false, error: error.message };
    }

    await logEmailAction({ type, email, redirectTo }, true);
    return { success: true };
  } catch (err: any) {
    const errorMessage = err.message || 'Failed to send password reset';
    await logEmailAction({ type, email, redirectTo }, false, errorMessage);
    return { success: false, error: errorMessage };
  }
}

export async function sendMagicLink(email: string, redirectTo?: string): Promise<AuthEmailResponse> {
  const type = 'magic_link';
  
  // Check rate limit
  if (!(await checkRateLimit(email, type))) {
    const error = 'Rate limit exceeded. Please wait before requesting another email.';
    await logEmailAction({ type, email, redirectTo }, false, error);
    return { success: false, error };
  }

  try {
  const { error } = await supabase.auth.signInWithOtp({
    email,
    options: {
      emailRedirectTo: redirectTo || `${window.location.origin}/`
    }
  });

    if (error) {
      await logEmailAction({ type, email, redirectTo }, false, error.message);
      return { success: false, error: error.message };
    }

    await logEmailAction({ type, email, redirectTo }, true);
    return { success: true };
  } catch (err: any) {
    const errorMessage = err.message || 'Failed to send magic link';
    await logEmailAction({ type, email, redirectTo }, false, errorMessage);
    return { success: false, error: errorMessage };
  }
}

export async function inviteUser(email: string, redirectTo?: string): Promise<AuthEmailResponse> {
  const type = 'invite';
  
  // Check rate limit
  if (!(await checkRateLimit(email, type))) {
    const error = 'Rate limit exceeded. Please wait before requesting another email.';
    await logEmailAction({ type, email, redirectTo }, false, error);
    return { success: false, error };
  }

  try {
    const { error } = await supabase.auth.admin.inviteUserByEmail(email, {
      redirectTo: redirectTo || `${window.location.origin}/`
    });

    if (error) {
      await logEmailAction({ type, email, redirectTo }, false, error.message);
      return { success: false, error: error.message };
    }

    await logEmailAction({ type, email, redirectTo }, true);
    return { success: true };
  } catch (err: any) {
    const errorMessage = err.message || 'Failed to send invite';
    await logEmailAction({ type, email, redirectTo }, false, errorMessage);
    return { success: false, error: errorMessage };
  }
}

// Get email logs with real-time updates
export function subscribeToEmailLogs(callback: (logs: any[]) => void) {
  const channel = supabase
    .channel('email-logs-changes')
    .on(
      'postgres_changes',
      {
        event: '*',
        schema: 'public',
        table: 'email_logs'
      },
      () => {
        // Refetch logs when changes occur
        fetchEmailLogs().then(callback);
      }
    )
    .subscribe();

  // Initial fetch
  fetchEmailLogs().then(callback);

  return () => {
    supabase.removeChannel(channel);
  };
}

async function fetchEmailLogs() {
  const { data, error } = await supabase
    .from('email_logs')
    .select('*')
    .order('created_at', { ascending: false })
    .limit(100);

  if (error) {
    console.error('Failed to fetch email logs:', error);
    return [];
  }

  return data || [];
}