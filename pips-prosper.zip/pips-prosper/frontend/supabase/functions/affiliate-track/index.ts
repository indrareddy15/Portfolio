import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.45.0";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

const logStep = (step: string, details?: any) => {
  const detailsStr = details ? ` - ${JSON.stringify(details)}` : '';
  console.log(`[AFFILIATE-TRACK] ${step}${detailsStr}`);
};

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    logStep("Tracking affiliate click");
    
    const url = new URL(req.url);
    const affiliateCode = url.searchParams.get("code");
    const utmSource = url.searchParams.get("utm_source");
    const utmMedium = url.searchParams.get("utm_medium");
    const utmCampaign = url.searchParams.get("utm_campaign");
    const utmContent = url.searchParams.get("utm_content");
    const utmTerm = url.searchParams.get("utm_term");
    
    if (!affiliateCode) {
      return new Response(JSON.stringify({ error: "No affiliate code provided" }), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
        status: 400,
      });
    }
    
    // Use service role key to bypass RLS
    const supabase = createClient(
      Deno.env.get("SUPABASE_URL") ?? "",
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? "",
      { auth: { persistSession: false } }
    );
    
    // Find affiliate by code
    const { data: affiliate, error: affiliateError } = await supabase
      .from("affiliates")
      .select("id")
      .eq("code", affiliateCode)
      .eq("status", "active")
      .single();
      
    if (affiliateError || !affiliate) {
      logStep("Affiliate not found or inactive", { code: affiliateCode });
      return new Response(JSON.stringify({ error: "Invalid affiliate code" }), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
        status: 404,
      });
    }
    
    // Get request info
    const clientIP = req.headers.get("cf-connecting-ip") || 
                    req.headers.get("x-forwarded-for") || 
                    req.headers.get("x-real-ip") || "unknown";
    const userAgent = req.headers.get("user-agent") || "";
    const refererUrl = req.headers.get("referer") || url.toString();
    
    // Build UTM JSON
    const utmJson = {
      utm_source: utmSource,
      utm_medium: utmMedium,
      utm_campaign: utmCampaign,
      utm_content: utmContent,
      utm_term: utmTerm
    };
    
    // Remove null/undefined values
    Object.keys(utmJson).forEach(key => {
      if (!utmJson[key as keyof typeof utmJson]) {
        delete utmJson[key as keyof typeof utmJson];
      }
    });
    
    // Record the click
    const { error: clickError } = await supabase
      .from("affiliate_clicks")
      .insert({
        affiliate_id: affiliate.id,
        url: refererUrl,
        utm_json: utmJson,
        ip_address: clientIP,
        user_agent: userAgent
      });
      
    if (clickError) {
      logStep("Error recording click", { error: clickError });
    } else {
      logStep("Click recorded", { 
        affiliateId: affiliate.id,
        code: affiliateCode,
        ip: clientIP
      });
    }
    
    // Return affiliate data for cookie setting
    return new Response(JSON.stringify({ 
      affiliate_id: affiliate.id,
      affiliate_code: affiliateCode,
      utm: utmJson
    }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
      status: 200,
    });
    
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : String(error);
    logStep("Tracking error", { error: errorMessage });
    return new Response(JSON.stringify({ error: errorMessage }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
      status: 500,
    });
  }
});