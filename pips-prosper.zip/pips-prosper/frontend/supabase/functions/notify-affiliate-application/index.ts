import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.56.1";
import { Resend } from "npm:resend@2.0.0";

const resend = new Resend(Deno.env.get("RESEND_API_KEY"));

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type",
};

const supabase = createClient(
  Deno.env.get('SUPABASE_URL') ?? '',
  Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
);

interface AffiliateApplication {
  id: string;
  full_name: string;
  email: string;
  phone?: string;
  country: string;
  platform_type: string;
  platform_url?: string;
  audience_size?: string;
  content_type?: string;
  experience_level: string;
  previous_programs?: string;
  promotion_strategy?: string;
  created_at: string;
}

const handler = async (req: Request): Promise<Response> => {
  console.log('Affiliate application notification function called');

  // Handle CORS preflight requests
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { applicationId }: { applicationId: string } = await req.json();
    console.log('Processing application:', applicationId);

    // Fetch the application details
    const { data: application, error } = await supabase
      .from('affiliate_applications')
      .select('*')
      .eq('id', applicationId)
      .single();

    if (error) {
      console.error('Error fetching application:', error);
      throw error;
    }

    if (!application) {
      throw new Error('Application not found');
    }

    console.log('Application found:', application.full_name);

    // Format the email content
    const emailHtml = `
      <h2>New PipsJournal Affiliate Application</h2>
      
      <div style="background: #f8f9fa; padding: 20px; border-radius: 8px; margin: 20px 0;">
        <h3>Applicant Information</h3>
        <p><strong>Name:</strong> ${application.full_name}</p>
        <p><strong>Email:</strong> ${application.email}</p>
        ${application.phone ? `<p><strong>Phone:</strong> ${application.phone}</p>` : ''}
        <p><strong>Country:</strong> ${application.country}</p>
        <p><strong>Applied:</strong> ${new Date(application.created_at).toLocaleDateString()}</p>
      </div>

      <div style="background: #f8f9fa; padding: 20px; border-radius: 8px; margin: 20px 0;">
        <h3>Platform Details</h3>
        <p><strong>Platform Type:</strong> ${application.platform_type}</p>
        ${application.platform_url ? `<p><strong>Platform URL:</strong> <a href="${application.platform_url}">${application.platform_url}</a></p>` : ''}
        ${application.audience_size ? `<p><strong>Audience Size:</strong> ${application.audience_size}</p>` : ''}
        ${application.content_type ? `<p><strong>Content Type:</strong> ${application.content_type}</p>` : ''}
      </div>

      <div style="background: #f8f9fa; padding: 20px; border-radius: 8px; margin: 20px 0;">
        <h3>Experience & Strategy</h3>
        <p><strong>Experience Level:</strong> ${application.experience_level}</p>
        ${application.previous_programs ? `<p><strong>Previous Programs:</strong> ${application.previous_programs}</p>` : ''}
        ${application.promotion_strategy ? `<p><strong>Promotion Strategy:</strong> ${application.promotion_strategy}</p>` : ''}
      </div>

      <div style="margin: 30px 0;">
        <p><strong>Application ID:</strong> ${application.id}</p>
        <p>Review and approve this application in your affiliate dashboard.</p>
      </div>
    `;

    const emailResponse = await resend.emails.send({
      from: "PipsJournal Affiliate <noreply@pipsjournal.com>",
      to: ["pipswarofficial@gmail.com"],
      subject: `New Affiliate Application: ${application.full_name}`,
      html: emailHtml,
    });

    console.log("Email sent successfully:", emailResponse);

    return new Response(
      JSON.stringify({ 
        success: true, 
        emailId: emailResponse.data?.id,
        message: "Notification sent successfully" 
      }),
      {
        status: 200,
        headers: {
          "Content-Type": "application/json",
          ...corsHeaders,
        },
      }
    );
  } catch (error: any) {
    console.error("Error in notify-affiliate-application function:", error);
    return new Response(
      JSON.stringify({ error: error.message }),
      {
        status: 500,
        headers: { "Content-Type": "application/json", ...corsHeaders },
      }
    );
  }
};

serve(handler);