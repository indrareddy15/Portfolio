import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.45.0";
import { crypto } from "https://deno.land/std@0.190.0/crypto/mod.ts";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

interface SendGridEvent {
  email: string;
  timestamp: number;
  'smtp-id': string;
  event: string;
  category?: string[];
  sg_event_id: string;
  sg_message_id: string;
  useragent?: string;
  ip?: string;
  url?: string;
  asm_group_id?: number;
  reason?: string;
  status?: string;
  response?: string;
  attempt?: string;
  type?: string;
}

async function verifySignature(payload: string, signature: string, timestamp: string, publicKey: string): Promise<boolean> {
  try {
    const timestampPayload = timestamp + payload;
    const expectedSignature = await crypto.subtle.importKey(
      'raw',
      new TextEncoder().encode(publicKey),
      { name: 'HMAC', hash: 'SHA-256' },
      false,
      ['verify']
    );

    const signatureBytes = new Uint8Array(
      signature.match(/.{1,2}/g)?.map(byte => parseInt(byte, 16)) || []
    );

    return await crypto.subtle.verify(
      'HMAC',
      expectedSignature,
      signatureBytes,
      new TextEncoder().encode(timestampPayload)
    );
  } catch (error) {
    console.error('Signature verification error:', error);
    return false;
  }
}

const handler = async (req: Request): Promise<Response> => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  if (req.method !== 'POST') {
    return new Response('Method not allowed', { status: 405, headers: corsHeaders });
  }

  try {
    const payload = await req.text();
    const events: SendGridEvent[] = JSON.parse(payload);

    // Verify webhook signature if signing key is configured
    const signingKey = Deno.env.get('SENDGRID_WEBHOOK_SIGNING_KEY');
    if (signingKey) {
      const signature = req.headers.get('X-Twilio-Email-Event-Webhook-Signature');
      const timestamp = req.headers.get('X-Twilio-Email-Event-Webhook-Timestamp');

      if (!signature || !timestamp) {
        console.error('Missing signature or timestamp headers');
        return new Response('Missing signature headers', { status: 401, headers: corsHeaders });
      }

      const isValid = await verifySignature(payload, signature, timestamp, signingKey);
      if (!isValid) {
        console.error('Invalid webhook signature');
        return new Response('Invalid signature', { status: 401, headers: corsHeaders });
      }
    }

    const supabase = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
    );

    console.log(`Processing ${events.length} SendGrid events`);

    // Process each event
    for (const event of events) {
      try {
        console.log(`Processing event: ${event.event} for ${event.email}`);

        // Find the corresponding email log
        let emailLogId = null;
        if (event.sg_message_id) {
          const { data: emailLog } = await supabase
            .from('email_logs')
            .select('id')
            .eq('sg_message_id', event.sg_message_id)
            .single();
          
          emailLogId = emailLog?.id || null;
        }

        // Insert event
        await supabase
          .from('email_events')
          .insert({
            email_log_id: emailLogId,
            event: event.event,
            email: event.email,
            sg_message_id: event.sg_message_id,
            meta: {
              timestamp: event.timestamp,
              sg_event_id: event.sg_event_id,
              smtp_id: event['smtp-id'],
              useragent: event.useragent,
              ip: event.ip,
              url: event.url,
              reason: event.reason,
              status: event.status,
              response: event.response,
              type: event.type,
              attempt: event.attempt,
              category: event.category
            }
          });

        // Update email log status based on event type
        if (emailLogId) {
          if (event.event === 'delivered') {
            await supabase
              .from('email_logs')
              .update({ status: 'sent' })
              .eq('id', emailLogId);
          } else if (['bounce', 'dropped', 'deferred'].includes(event.event)) {
            await supabase
              .from('email_logs')
              .update({ 
                status: 'failed',
                last_error: event.reason || event.response || `Event: ${event.event}`
              })
              .eq('id', emailLogId);
          }
        }

        console.log(`Successfully processed ${event.event} event for ${event.email}`);
      } catch (eventError) {
        console.error(`Error processing event for ${event.email}:`, eventError);
        // Continue processing other events even if one fails
      }
    }

    return new Response(
      JSON.stringify({ success: true, processed: events.length }),
      { status: 200, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );

  } catch (error) {
    console.error('SendGrid webhook error:', error);
    return new Response(
      JSON.stringify({ error: 'Internal server error' }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
};

serve(handler);