import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import Stripe from "https://esm.sh/stripe@14.21.0";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.45.0";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type, stripe-signature",
};

const logStep = (step: string, details?: any) => {
  const detailsStr = details ? ` - ${JSON.stringify(details)}` : '';
  console.log(`[AFFILIATE-WEBHOOK] ${step}${detailsStr}`);
};

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    logStep("Webhook received");
    
    const stripeKey = Deno.env.get("STRIPE_SECRET_KEY");
    if (!stripeKey) throw new Error("STRIPE_SECRET_KEY is not set");
    
    const stripe = new Stripe(stripeKey, { apiVersion: "2023-10-16" });
    
    // Use service role key to bypass RLS
    const supabase = createClient(
      Deno.env.get("SUPABASE_URL") ?? "",
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? "",
      { auth: { persistSession: false } }
    );

    const body = await req.text();
    const signature = req.headers.get("stripe-signature");
    
    if (!signature) {
      throw new Error("No Stripe signature found");
    }

    // Verify webhook signature (in production, use webhook endpoint secret)
    let event;
    try {
      event = stripe.webhooks.constructEvent(body, signature, Deno.env.get("STRIPE_WEBHOOK_SECRET") || "");
    } catch (err) {
      logStep("Webhook signature verification failed", { error: err.message });
      return new Response(`Webhook Error: ${err.message}`, { status: 400 });
    }

    logStep("Processing event", { type: event.type, id: event.id });

    switch (event.type) {
      case "checkout.session.completed":
        await handleCheckoutCompleted(supabase, stripe, event.data.object);
        break;
        
      case "invoice.paid":
        await handleInvoicePaid(supabase, stripe, event.data.object);
        break;
        
      case "invoice.payment_failed":
        await handleInvoiceFailed(supabase, event.data.object);
        break;
        
      case "charge.refunded":
        await handleChargeRefunded(supabase, stripe, event.data.object);
        break;
        
      case "customer.subscription.updated":
        await handleSubscriptionUpdated(supabase, stripe, event.data.object);
        break;
        
      default:
        logStep("Unhandled event type", { type: event.type });
    }

    return new Response(JSON.stringify({ received: true }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
      status: 200,
    });
    
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : String(error);
    logStep("Webhook error", { error: errorMessage });
    return new Response(JSON.stringify({ error: errorMessage }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
      status: 500,
    });
  }
});

async function handleCheckoutCompleted(supabase: any, stripe: any, session: any) {
  logStep("Handling checkout completed", { sessionId: session.id });
  
  // Get customer and check for affiliate attribution
  const customer = await stripe.customers.retrieve(session.customer);
  const customerEmail = customer.email;
  
  // Find user by email
  const { data: authUsers } = await supabase.auth.admin.listUsers();
  const user = authUsers.users?.find((u: any) => u.email === customerEmail);
  
  if (!user) {
    logStep("No user found for email", { email: customerEmail });
    return;
  }
  
  // Check for affiliate attribution
  const { data: attribution } = await supabase
    .from("affiliate_attributions")
    .select("affiliate_id")
    .eq("user_id", user.id)
    .single();
    
  if (attribution) {
    logStep("Found affiliate attribution", { affiliateId: attribution.affiliate_id, userId: user.id });
  }
}

async function handleInvoicePaid(supabase: any, stripe: any, invoice: any) {
  logStep("Handling invoice paid", { invoiceId: invoice.id, amount: invoice.amount_paid });
  
  // Skip $0 invoices (trials)
  if (invoice.amount_paid === 0) {
    logStep("Skipping $0 invoice");
    return;
  }
  
  // Get customer
  const customer = await stripe.customers.retrieve(invoice.customer);
  const customerEmail = customer.email;
  
  // Find user by email
  const { data: authUsers } = await supabase.auth.admin.listUsers();
  const user = authUsers.users?.find((u: any) => u.email === customerEmail);
  
  if (!user) {
    logStep("No user found for email", { email: customerEmail });
    return;
  }
  
  // Check for affiliate attribution
  const { data: attribution } = await supabase
    .from("affiliate_attributions")
    .select("affiliate_id, affiliates(default_rate_pct, plan_overrides_json)")
    .eq("user_id", user.id)
    .single();
    
  if (!attribution) {
    logStep("No affiliate attribution found", { userId: user.id });
    return;
  }
  
  // Calculate commission
  const affiliateData = attribution.affiliates;
  const rate = affiliateData.default_rate_pct || 30;
  const commissionAmount = (invoice.amount_paid * rate) / 10000; // Convert from cents and percentage
  
  // Create commission record
  const holdUntil = new Date();
  holdUntil.setDate(holdUntil.getDate() + 14); // 14-day hold period
  
  const { error } = await supabase
    .from("commissions")
    .insert({
      affiliate_id: attribution.affiliate_id,
      customer_user_id: user.id,
      stripe_invoice_id: invoice.id,
      type: "rev_share",
      amount: commissionAmount,
      currency: invoice.currency.toUpperCase(),
      rate_pct: rate,
      status: "pending",
      hold_until: holdUntil.toISOString(),
      notes: `Invoice ${invoice.id} - ${invoice.lines.data[0]?.description || 'Subscription'}`
    });
    
  if (error) {
    logStep("Error creating commission", { error });
  } else {
    logStep("Commission created", { 
      affiliateId: attribution.affiliate_id,
      amount: commissionAmount,
      currency: invoice.currency.toUpperCase()
    });
  }
}

async function handleInvoiceFailed(supabase: any, invoice: any) {
  logStep("Handling invoice failed", { invoiceId: invoice.id });
  // Could implement commission clawback logic here if needed
}

async function handleChargeRefunded(supabase: any, stripe: any, charge: any) {
  logStep("Handling charge refunded", { chargeId: charge.id, refunded: charge.amount_refunded });
  
  // Create negative adjustment commission for refunds
  const invoice = await stripe.invoices.retrieve(charge.invoice);
  
  // Find existing commission
  const { data: existingCommission } = await supabase
    .from("commissions")
    .select("*")
    .eq("stripe_invoice_id", invoice.id)
    .eq("type", "rev_share")
    .single();
    
  if (existingCommission) {
    const refundRatio = charge.amount_refunded / charge.amount;
    const adjustmentAmount = -(existingCommission.amount * refundRatio);
    
    const { error } = await supabase
      .from("commissions")
      .insert({
        affiliate_id: existingCommission.affiliate_id,
        customer_user_id: existingCommission.customer_user_id,
        stripe_invoice_id: invoice.id,
        type: "adjustment",
        amount: adjustmentAmount,
        currency: existingCommission.currency,
        rate_pct: existingCommission.rate_pct,
        status: "approved",
        notes: `Refund adjustment for charge ${charge.id}`
      });
      
    if (!error) {
      logStep("Refund adjustment created", { 
        amount: adjustmentAmount,
        originalCommission: existingCommission.amount 
      });
    }
  }
}

async function handleSubscriptionUpdated(supabase: any, stripe: any, subscription: any) {
  logStep("Handling subscription updated", { subscriptionId: subscription.id });
  // Could implement upgrade/downgrade commission adjustments here
}