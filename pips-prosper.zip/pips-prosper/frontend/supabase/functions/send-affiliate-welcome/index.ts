import { serve } from "https://deno.land/std@0.168.0/http/server.ts"
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

interface WebhookPayload {
  type: 'INSERT'
  table: string
  record: {
    id: string
    user_id: string
    code: string
    status: string
    default_rate_pct: number
    created_at: string
  }
  old_record: null
}

serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders })
  }

  try {
    const supabaseClient = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
    )

    const payload: WebhookPayload = await req.json()
    console.log('Received webhook payload:', payload)

    // Only process INSERT events for affiliates table
    if (payload.type !== 'INSERT' || payload.table !== 'affiliates') {
      return new Response('Event not processed', { status: 200, headers: corsHeaders })
    }

    const { record } = payload

    // Get the user's profile and application data
    const { data: profile, error: profileError } = await supabaseClient
      .from('profiles')
      .select('display_name')
      .eq('user_id', record.user_id)
      .single()

    if (profileError) {
      console.log('Profile not found, skipping email')
      return new Response('Profile not found', { status: 200, headers: corsHeaders })
    }

    // Get the affiliate application data
    const { data: application, error: appError } = await supabaseClient
      .from('affiliate_applications')
      .select('full_name, email')
      .eq('user_id', record.user_id)
      .single()

    if (appError) {
      console.log('Application not found, skipping email')
      return new Response('Application not found', { status: 200, headers: corsHeaders })
    }

    // Prepare welcome email data
    const emailData = {
      to: [application.email],
      subject: 'Welcome to PipTrackr.com Affiliate Program! 🎉',
      html: `
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
          <div style="background: linear-gradient(135deg, #008ffd, #0b1e3a); padding: 30px; text-align: center; color: white;">
            <h1 style="margin: 0; font-size: 28px;">Welcome to PipTrackr.com!</h1>
            <p style="margin: 10px 0 0 0; font-size: 16px; opacity: 0.9;">You're now an official affiliate partner</p>
          </div>
          
          <div style="padding: 30px; background: #f8f9fa;">
            <h2 style="color: #0b1e3a; margin-top: 0;">Hi ${application.full_name}! 👋</h2>
            
            <p>Congratulations! Your affiliate application has been approved and you're now part of our elite affiliate program.</p>
            
            <div style="background: white; padding: 20px; border-radius: 8px; margin: 20px 0; border-left: 4px solid #008ffd;">
              <h3 style="margin-top: 0; color: #0b1e3a;">Your Affiliate Details:</h3>
              <p><strong>Affiliate Code:</strong> <code style="background: #e5efff; padding: 4px 8px; border-radius: 4px; color: #008ffd;">${record.code}</code></p>
              <p><strong>Commission Rate:</strong> ${record.default_rate_pct}% recurring</p>
              <p><strong>Status:</strong> Active ✅</p>
            </div>
            
            <h3 style="color: #0b1e3a;">What's Next?</h3>
            <ul style="line-height: 1.6;">
              <li>📊 Access your affiliate dashboard to track performance</li>
              <li>🎯 Start promoting PipTrackr.com with your unique code</li>
              <li>💰 Earn ${record.default_rate_pct}% commission on every successful referral</li>
              <li>📈 Unlock higher tiers as you bring more customers</li>
            </ul>
            
            <div style="text-align: center; margin: 30px 0;">
              <a href="https://piptrackr.com/app/affiliate" 
                 style="background: #008ffd; color: white; padding: 12px 24px; text-decoration: none; border-radius: 6px; display: inline-block; font-weight: bold;">
                Access Your Dashboard →
              </a>
            </div>
            
            <div style="background: #e5efff; padding: 15px; border-radius: 6px; margin: 20px 0;">
              <p style="margin: 0; color: #0b1e3a;"><strong>💡 Pro Tip:</strong> Promote your link on social media, blogs, or trading communities to maximize your earnings!</p>
            </div>
            
            <p>If you have any questions, feel free to reach out to our affiliate support team.</p>
            
            <p>Welcome aboard! 🚀</p>
            <p><strong>The PipTrackr.com Team</strong></p>
          </div>
          
          <div style="background: #0b1e3a; padding: 20px; text-align: center; color: white; font-size: 12px;">
            <p style="margin: 0;">© 2024 PipTrackr.com. All rights reserved.</p>
          </div>
        </div>
      `
    }

    // Send email using Resend
    const resendApiKey = Deno.env.get('RESEND_API_KEY')
    if (!resendApiKey) {
      throw new Error('RESEND_API_KEY not found')
    }

    const emailResponse = await fetch('https://api.resend.com/emails', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${resendApiKey}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        from: 'PipTrackr.com <noreply@piptrackr.com>',
        ...emailData
      }),
    })

    if (!emailResponse.ok) {
      const error = await emailResponse.text()
      console.error('Failed to send email:', error)
      throw new Error(`Failed to send email: ${error}`)
    }

    const emailResult = await emailResponse.json()
    console.log('Welcome email sent successfully:', emailResult)

    return new Response(
      JSON.stringify({ success: true, message: 'Welcome email sent successfully' }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    )

  } catch (error) {
    console.error('Error processing webhook:', error)
    return new Response(
      JSON.stringify({ error: error.message }),
      { 
        status: 500, 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
      }
    )
  }
})