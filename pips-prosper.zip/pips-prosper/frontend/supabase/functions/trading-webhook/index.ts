import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.56.1';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    // Extract webhook key from URL path
    const url = new URL(req.url);
    const pathParts = url.pathname.split('/');
    const webhookKey = pathParts[pathParts.length - 1];

    if (!webhookKey || webhookKey === 'trading-webhook') {
      return new Response(
        JSON.stringify({ error: 'Missing webhook key' }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' }, status: 400 }
      );
    }

    console.log('Processing webhook with key:', webhookKey);

    // Initialize Supabase client
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseServiceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const supabase = createClient(supabaseUrl, supabaseServiceKey);

    // Verify webhook key exists and is active
    const { data: webhookData, error: webhookError } = await supabase
      .from('webhook_keys')
      .select('user_id, name, active')
      .eq('secret', webhookKey)
      .eq('active', true)
      .single();

    if (webhookError || !webhookData) {
      console.log('Invalid webhook key:', webhookKey);
      return new Response(
        JSON.stringify({ error: 'Invalid or inactive webhook key' }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' }, status: 401 }
      );
    }

    // Parse the webhook payload
    const payload = await req.json();
    console.log('Received payload:', payload);

    // Validate required fields
    if (!payload.symbol || !payload.side || !payload.price) {
      return new Response(
        JSON.stringify({ error: 'Missing required fields: symbol, side, price' }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' }, status: 400 }
      );
    }

    // Convert TradingView signal to trade record
    const tradeData = {
      user_id: webhookData.user_id,
      instrument: payload.symbol.toString(),
      side: payload.side.toLowerCase() === 'buy' || payload.side.toLowerCase() === 'long' ? 'long' : 'short',
      entry_price: parseFloat(payload.price),
      size: payload.size ? parseFloat(payload.size) : 1.0,
      opened_at: payload.timestamp ? new Date(payload.timestamp).toISOString() : new Date().toISOString(),
      notes_pre: payload.strategy ? `TradingView Strategy: ${payload.strategy}` : 'TradingView Webhook',
      session: getSessionFromTime(new Date()),
    };

    console.log('Creating trade:', tradeData);

    // Insert trade into database
    const { data: trade, error: tradeError } = await supabase
      .from('trades')
      .insert(tradeData)
      .select()
      .single();

    if (tradeError) {
      console.error('Error creating trade:', tradeError);
      return new Response(
        JSON.stringify({ error: 'Failed to create trade', details: tradeError.message }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' }, status: 500 }
      );
    }

    console.log('Trade created successfully:', trade.id);

    // Handle exit signals (if this is a close signal)
    if (payload.signal === 'close' || payload.signal === 'exit') {
      // Find the most recent open trade for this symbol
      const { data: openTrade, error: findError } = await supabase
        .from('trades')
        .select('*')
        .eq('user_id', webhookData.user_id)
        .eq('instrument', payload.symbol)
        .is('closed_at', null)
        .order('opened_at', { ascending: false })
        .limit(1)
        .single();

      if (!findError && openTrade) {
        const exitPrice = parseFloat(payload.price);
        const entryPrice = openTrade.entry_price;
        
        // Calculate P&L (simplified - assumes 1:1 pip value)
        let pnl = 0;
        if (openTrade.side === 'long') {
          pnl = (exitPrice - entryPrice) * openTrade.size;
        } else {
          pnl = (entryPrice - exitPrice) * openTrade.size;
        }

        // Update the trade with exit information
        const { error: updateError } = await supabase
          .from('trades')
          .update({
            exit_price: exitPrice,
            closed_at: new Date().toISOString(),
            pnl: pnl,
            result: pnl > 0 ? 'win' : pnl < 0 ? 'loss' : 'breakeven',
            notes_post: `Auto-closed via TradingView webhook`
          })
          .eq('id', openTrade.id);

        if (updateError) {
          console.error('Error updating trade:', updateError);
        } else {
          console.log('Trade closed successfully:', openTrade.id);
        }
      }
    }

    // Generate AI insight if this is a significant event
    if (payload.signal === 'entry' || !payload.signal) {
      try {
        await generateWebhookInsight(supabase, webhookData.user_id, payload);
      } catch (error) {
        console.log('Failed to generate AI insight:', error);
        // Don't fail the whole request for this
      }
    }

    return new Response(
      JSON.stringify({ 
        success: true, 
        trade_id: trade.id,
        message: 'Trade recorded successfully'
      }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );

  } catch (error) {
    console.error('Webhook processing error:', error);
    return new Response(
      JSON.stringify({ error: 'Internal server error', details: error.message }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' }, status: 500 }
    );
  }
});

function getSessionFromTime(date: Date): string {
  const hour = date.getUTCHours();
  
  if (hour >= 22 || hour < 8) {
    return 'Asian';
  } else if (hour >= 8 && hour < 16) {
    return 'London';
  } else if (hour >= 16 && hour < 22) {
    return 'New York';
  }
  
  return 'Other';
}

async function generateWebhookInsight(supabase: any, userId: string, payload: any) {
  const insights = [
    `New ${payload.side} signal received for ${payload.symbol} at ${payload.price}`,
    `TradingView automation is active - trade automatically recorded`,
    `Strategy "${payload.strategy || 'Unknown'}" triggered a new position`,
  ];

  const randomInsight = insights[Math.floor(Math.random() * insights.length)];

  await supabase
    .from('ai_insights')
    .insert({
      user_id: userId,
      insight_type: 'daily',
      title: '🤖 TradingView Automation',
      content: randomInsight,
      metadata: {
        source: 'webhook',
        symbol: payload.symbol,
        strategy: payload.strategy,
        automation: true
      }
    });
}