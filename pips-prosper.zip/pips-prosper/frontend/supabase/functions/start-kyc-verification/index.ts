import { serve } from "https://deno.land/std@0.168.0/http/server.ts"
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

interface VerificationRequest {
  affiliate_id: string;
  callback_url: string;
}

serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseClient = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_ANON_KEY') ?? '',
      {
        global: {
          headers: { Authorization: req.headers.get('Authorization')! },
        },
      }
    )

    // Get the current user
    const { data: { user }, error: userError } = await supabaseClient.auth.getUser()
    if (userError || !user) {
      throw new Error('Unauthorized')
    }

    const { affiliate_id, callback_url }: VerificationRequest = await req.json()

    // Verify the affiliate belongs to the user
    const { data: affiliate, error: affiliateError } = await supabaseClient
      .from('affiliates')
      .select('id, user_id, code')
      .eq('id', affiliate_id)
      .eq('user_id', user.id)
      .single()

    if (affiliateError || !affiliate) {
      throw new Error('Affiliate not found or unauthorized')
    }

    // Get Veriff API key
    const veriffApiKey = Deno.env.get('VERIFF_API_KEY')
    if (!veriffApiKey) {
      throw new Error('Veriff API key not configured')
    }

    // Create verification session with Veriff
    const veriffResponse = await fetch('https://stationapi.veriff.com/v1/sessions', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${veriffApiKey}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        verification: {
          callback: callback_url,
          person: {
            firstName: user.user_metadata?.display_name?.split(' ')[0] || '',
            lastName: user.user_metadata?.display_name?.split(' ').slice(1).join(' ') || '',
          },
          document: {
            country: 'US', // Default to US, can be made dynamic
            type: 'PASSPORT'
          },
          additionalData: {
            affiliate_id: affiliate_id,
            affiliate_code: affiliate.code
          }
        }
      })
    })

    if (!veriffResponse.ok) {
      const errorData = await veriffResponse.text()
      console.error('Veriff API error:', errorData)
      throw new Error('Failed to create verification session')
    }

    const veriffData = await veriffResponse.json()
    
    // Create or update KYC record
    const kycData = {
      affiliate_id: affiliate_id,
      status: 'pending',
      files_json: []
    }

    const { error: kycError } = await supabaseClient
      .from('affiliate_kyc')
      .upsert(kycData, { 
        onConflict: 'affiliate_id',
        ignoreDuplicates: false 
      })

    if (kycError) {
      console.error('KYC record error:', kycError)
      throw new Error('Failed to create KYC record')
    }

    console.log('KYC verification session created:', {
      affiliate_id,
      session_id: veriffData.verification?.id,
      url: veriffData.verification?.url
    })

    return new Response(
      JSON.stringify({
        success: true,
        session_id: veriffData.verification?.id,
        verification_url: veriffData.verification?.url
      }),
      { 
        headers: { 
          ...corsHeaders,
          'Content-Type': 'application/json' 
        } 
      }
    )

  } catch (error) {
    console.error('Error in start-kyc-verification:', error)
    
    return new Response(
      JSON.stringify({ 
        error: error.message || 'Internal server error' 
      }),
      { 
        status: 400,
        headers: { 
          ...corsHeaders,
          'Content-Type': 'application/json' 
        } 
      }
    )
  }
})