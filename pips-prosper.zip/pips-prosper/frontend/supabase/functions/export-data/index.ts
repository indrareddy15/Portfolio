import { serve } from "https://deno.land/std@0.168.0/http/server.ts"
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.7.1'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

interface ExportRequest {
  type: string;
  format: string;
  dateRange?: {
    from: string;
    to: string;
  };
  accountIds?: string[];
  includeAnalytics?: boolean;
  includeNotes?: boolean;
}

serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders })
  }

  try {
    const supabase = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
    )

    // Get user from auth header
    const authHeader = req.headers.get('Authorization')
    if (!authHeader) {
      throw new Error('No authorization header')
    }

    const { data: { user }, error: authError } = await supabase.auth.getUser(
      authHeader.replace('Bearer ', '')
    )

    if (authError || !user) {
      throw new Error('Invalid authorization')
    }

    const exportRequest: ExportRequest = await req.json()
    console.log('Export request:', exportRequest)

    // Get user's accounts
    const { data: accounts, error: accountsError } = await supabase
      .from('accounts')
      .select('*')
      .eq('user_id', user.id)
      .eq('is_active', true)

    if (accountsError) {
      throw new Error('Failed to fetch accounts')
    }

    const accountIds = exportRequest.accountIds || accounts.map(acc => acc.id)

    // Calculate date range
    let fromDate = exportRequest.dateRange?.from
    let toDate = exportRequest.dateRange?.to

    if (!fromDate || !toDate) {
      const thirtyDaysAgo = new Date()
      thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30)
      fromDate = thirtyDaysAgo.toISOString()
      toDate = new Date().toISOString()
    }

    let exportData: any = {}

    // Export logic based on type
    switch (exportRequest.type.toLowerCase()) {
      case 'trading journal export':
      case 'last 30 days trades':
        exportData = await exportTrades(supabase, accountIds, fromDate, toDate)
        break
      
      case 'performance reports':
      case 'monthly p&l summary':
        exportData = await exportPerformance(supabase, accountIds, fromDate, toDate)
        break
      
      case 'tax reports':
        exportData = await exportTaxData(supabase, accountIds, fromDate, toDate)
        break
      
      case 'strategy backtest':
        exportData = await exportStrategy(supabase, accountIds, fromDate, toDate)
        break
      
      case 'risk metrics report':
        exportData = await exportRiskMetrics(supabase, accountIds, fromDate, toDate)
        break
      
      default:
        exportData = await exportTrades(supabase, accountIds, fromDate, toDate)
    }

    // Generate file based on format
    let fileContent: string | Uint8Array
    let contentType: string
    let filename: string

    switch (exportRequest.format.toLowerCase()) {
      case 'csv':
        const csvResult = generateCSV(exportData)
        fileContent = csvResult.content
        contentType = 'text/csv'
        filename = csvResult.filename
        break
      
      case 'json':
        fileContent = JSON.stringify(exportData, null, 2)
        contentType = 'application/json'
        filename = `export_${Date.now()}.json`
        break
      
      case 'pdf':
        const pdfResult = await generatePDF(exportData, exportRequest.type)
        fileContent = pdfResult.content
        contentType = 'application/pdf'
        filename = pdfResult.filename
        break
      
      case 'excel':
        const excelResult = generateExcel(exportData)
        fileContent = excelResult.content
        contentType = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
        filename = excelResult.filename
        break
      
      default:
        throw new Error('Unsupported export format')
    }

    return new Response(fileContent, {
      headers: {
        ...corsHeaders,
        'Content-Type': contentType,
        'Content-Disposition': `attachment; filename="${filename}"`,
      }
    })

  } catch (error) {
    console.error('Export error:', error)
    return new Response(
      JSON.stringify({ 
        error: error.message || 'Export failed',
        details: error.toString()
      }),
      { 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }, 
        status: 500 
      }
    )
  }
})

async function exportTrades(supabase: any, accountIds: string[], fromDate: string, toDate: string) {
  const { data: trades, error } = await supabase
    .from('trades')
    .select(`
      *,
      account:accounts(name, broker_name, currency)
    `)
    .in('account_id', accountIds)
    .gte('opened_at', fromDate)
    .lte('opened_at', toDate)
    .order('opened_at', { ascending: false })

  if (error) {
    throw new Error('Failed to fetch trades')
  }

  return {
    type: 'trades',
    metadata: {
      totalTrades: trades.length,
      dateRange: { from: fromDate, to: toDate },
      accountIds
    },
    data: trades
  }
}

async function exportPerformance(supabase: any, accountIds: string[], fromDate: string, toDate: string) {
  // Get trades for performance calculation
  const { data: trades } = await supabase
    .from('trades')
    .select('*')
    .in('account_id', accountIds)
    .gte('opened_at', fromDate)
    .lte('opened_at', toDate)
    .not('closed_at', 'is', null)

  const totalTrades = trades.length
  const winningTrades = trades.filter((t: any) => t.pnl > 0).length
  const losingTrades = trades.filter((t: any) => t.pnl < 0).length
  const totalPnL = trades.reduce((sum: number, t: any) => sum + t.pnl, 0)
  const winRate = totalTrades > 0 ? (winningTrades / totalTrades) * 100 : 0

  return {
    type: 'performance',
    metadata: {
      dateRange: { from: fromDate, to: toDate },
      accountIds
    },
    summary: {
      totalTrades,
      winningTrades,
      losingTrades,
      winRate: Math.round(winRate * 100) / 100,
      totalPnL,
      averageTrade: totalTrades > 0 ? totalPnL / totalTrades : 0
    },
    trades
  }
}

async function exportTaxData(supabase: any, accountIds: string[], fromDate: string, toDate: string) {
  const { data: trades } = await supabase
    .from('trades')
    .select(`
      *,
      account:accounts(name, broker_name, currency, account_type)
    `)
    .in('account_id', accountIds)
    .gte('closed_at', fromDate)
    .lte('closed_at', toDate)
    .not('closed_at', 'is', null)
    .order('closed_at', { ascending: true })

  const taxData = trades.map((trade: any) => ({
    date: trade.closed_at,
    instrument: trade.instrument,
    type: trade.type,
    quantity: trade.quantity,
    entryPrice: trade.entry,
    exitPrice: trade.exit,
    pnl: trade.pnl,
    currency: trade.account?.currency || 'USD',
    account: trade.account?.name,
    broker: trade.account?.broker_name,
    accountType: trade.account?.account_type
  }))

  return {
    type: 'tax_report',
    metadata: {
      dateRange: { from: fromDate, to: toDate },
      totalPnL: trades.reduce((sum: number, t: any) => sum + t.pnl, 0),
      totalTrades: trades.length
    },
    data: taxData
  }
}

async function exportStrategy(supabase: any, accountIds: string[], fromDate: string, toDate: string) {
  const { data: trades } = await supabase
    .from('trades')
    .select('*')
    .in('account_id', accountIds)
    .gte('opened_at', fromDate)
    .lte('opened_at', toDate)
    .not('closed_at', 'is', null)

  // Group by strategy if available, or by instrument
  const strategyGroups: any = {}
  trades.forEach((trade: any) => {
    const strategy = trade.strategy || trade.instrument || 'Unknown'
    if (!strategyGroups[strategy]) {
      strategyGroups[strategy] = []
    }
    strategyGroups[strategy].push(trade)
  })

  const strategyPerformance = Object.keys(strategyGroups).map(strategy => {
    const strategyTrades = strategyGroups[strategy]
    const totalPnL = strategyTrades.reduce((sum: number, t: any) => sum + t.pnl, 0)
    const winCount = strategyTrades.filter((t: any) => t.pnl > 0).length
    
    return {
      strategy,
      totalTrades: strategyTrades.length,
      winCount,
      lossCount: strategyTrades.length - winCount,
      winRate: strategyTrades.length > 0 ? (winCount / strategyTrades.length) * 100 : 0,
      totalPnL,
      averageTrade: strategyTrades.length > 0 ? totalPnL / strategyTrades.length : 0
    }
  })

  return {
    type: 'strategy_backtest',
    metadata: {
      dateRange: { from: fromDate, to: toDate },
      strategiesCount: Object.keys(strategyGroups).length
    },
    strategyPerformance,
    detailedTrades: trades
  }
}

async function exportRiskMetrics(supabase: any, accountIds: string[], fromDate: string, toDate: string) {
  const { data: trades } = await supabase
    .from('trades')
    .select('*')
    .in('account_id', accountIds)
    .gte('opened_at', fromDate)
    .lte('opened_at', toDate)
    .not('closed_at', 'is', null)

  const pnls = trades.map((t: any) => t.pnl).sort((a: number, b: number) => a - b)
  const wins = trades.filter((t: any) => t.pnl > 0).map((t: any) => t.pnl)
  const losses = trades.filter((t: any) => t.pnl < 0).map((t: any) => t.pnl)

  // Calculate risk metrics
  const totalPnL = pnls.reduce((sum, pnl) => sum + pnl, 0)
  const avgWin = wins.length > 0 ? wins.reduce((sum, win) => sum + win, 0) / wins.length : 0
  const avgLoss = losses.length > 0 ? Math.abs(losses.reduce((sum, loss) => sum + loss, 0) / losses.length) : 0
  const profitFactor = avgLoss > 0 ? avgWin / avgLoss : 0
  
  // Calculate maximum drawdown
  let maxDrawdown = 0
  let runningPnL = 0
  let peak = 0
  
  for (const pnl of pnls) {
    runningPnL += pnl
    if (runningPnL > peak) {
      peak = runningPnL
    }
    const drawdown = peak - runningPnL
    if (drawdown > maxDrawdown) {
      maxDrawdown = drawdown
    }
  }

  return {
    type: 'risk_metrics',
    metadata: {
      dateRange: { from: fromDate, to: toDate },
      totalTrades: trades.length
    },
    metrics: {
      totalPnL,
      totalTrades: trades.length,
      winRate: trades.length > 0 ? (wins.length / trades.length) * 100 : 0,
      avgWin,
      avgLoss,
      profitFactor,
      maxDrawdown,
      sharpeRatio: 0, // Simplified - would need more data for proper calculation
      largestWin: wins.length > 0 ? Math.max(...wins) : 0,
      largestLoss: losses.length > 0 ? Math.min(...losses) : 0
    }
  }
}

function generateCSV(data: any): { content: string; filename: string } {
  let csvContent = ''
  let filename = `export_${Date.now()}.csv`

  if (data.type === 'trades') {
    filename = `trades_export_${Date.now()}.csv`
    const headers = [
      'Date', 'Account', 'Instrument', 'Type', 'Quantity', 
      'Entry Price', 'Exit Price', 'PnL', 'Duration', 'Status'
    ]
    csvContent = headers.join(',') + '\n'
    
    data.data.forEach((trade: any) => {
      const row = [
        trade.opened_at,
        trade.account?.name || '',
        trade.instrument,
        trade.type,
        trade.quantity,
        trade.entry,
        trade.exit || '',
        trade.pnl || 0,
        trade.closed_at ? 
          Math.round((new Date(trade.closed_at).getTime() - new Date(trade.opened_at).getTime()) / (1000 * 60)) + ' min' :
          'Open',
        trade.status
      ]
      csvContent += row.map(field => `"${field}"`).join(',') + '\n'
    })
  } else if (data.type === 'performance') {
    filename = `performance_export_${Date.now()}.csv`
    csvContent = 'Metric,Value\n'
    csvContent += `Total Trades,${data.summary.totalTrades}\n`
    csvContent += `Winning Trades,${data.summary.winningTrades}\n`
    csvContent += `Losing Trades,${data.summary.losingTrades}\n`
    csvContent += `Win Rate,${data.summary.winRate}%\n`
    csvContent += `Total PnL,${data.summary.totalPnL}\n`
    csvContent += `Average Trade,${data.summary.averageTrade}\n`
  }

  return { content: csvContent, filename }
}

function generateExcel(data: any): { content: Uint8Array; filename: string } {
  // For now, return CSV content as Excel would require additional libraries
  const csvResult = generateCSV(data)
  return {
    content: new TextEncoder().encode(csvResult.content),
    filename: csvResult.filename.replace('.csv', '.xlsx')
  }
}

async function generatePDF(data: any, exportType: string): Promise<{ content: Uint8Array; filename: string }> {
  // Create a simple HTML report that can be converted to PDF
  let htmlContent = `
    <html>
    <head>
      <title>${exportType} Report</title>
      <style>
        body { font-family: Arial, sans-serif; margin: 20px; }
        .header { text-align: center; margin-bottom: 30px; }
        .summary { background: #f5f5f5; padding: 15px; margin: 20px 0; }
        table { width: 100%; border-collapse: collapse; margin: 20px 0; }
        th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
        th { background-color: #f2f2f2; }
        .positive { color: green; }
        .negative { color: red; }
      </style>
    </head>
    <body>
      <div class="header">
        <h1>${exportType}</h1>
        <p>Generated on: ${new Date().toLocaleDateString()}</p>
      </div>
  `

  if (data.type === 'performance') {
    htmlContent += `
      <div class="summary">
        <h2>Performance Summary</h2>
        <p><strong>Total Trades:</strong> ${data.summary.totalTrades}</p>
        <p><strong>Win Rate:</strong> ${data.summary.winRate}%</p>
        <p><strong>Total PnL:</strong> <span class="${data.summary.totalPnL >= 0 ? 'positive' : 'negative'}">${data.summary.totalPnL}</span></p>
        <p><strong>Average Trade:</strong> ${data.summary.averageTrade}</p>
      </div>
    `
  } else if (data.type === 'trades') {
    htmlContent += `
      <div class="summary">
        <h2>Trading Journal</h2>
        <p><strong>Total Trades:</strong> ${data.data.length}</p>
        <p><strong>Date Range:</strong> ${new Date(data.metadata.dateRange.from).toLocaleDateString()} - ${new Date(data.metadata.dateRange.to).toLocaleDateString()}</p>
      </div>
      
      <table>
        <thead>
          <tr>
            <th>Date</th>
            <th>Instrument</th>
            <th>Type</th>
            <th>Entry</th>
            <th>Exit</th>
            <th>PnL</th>
          </tr>
        </thead>
        <tbody>
    `
    
    data.data.slice(0, 50).forEach((trade: any) => {
      htmlContent += `
        <tr>
          <td>${new Date(trade.opened_at).toLocaleDateString()}</td>
          <td>${trade.instrument}</td>
          <td>${trade.type}</td>
          <td>${trade.entry}</td>
          <td>${trade.exit || 'Open'}</td>
          <td class="${trade.pnl >= 0 ? 'positive' : 'negative'}">${trade.pnl || 0}</td>
        </tr>
      `
    })
    
    htmlContent += `
        </tbody>
      </table>
    `
  }

  htmlContent += `
    </body>
    </html>
  `

  // For now, return HTML content as PDF conversion would require additional libraries
  const filename = `${exportType.toLowerCase().replace(/ /g, '_')}_${Date.now()}.pdf`
  return {
    content: new TextEncoder().encode(htmlContent),
    filename
  }
}