import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.45.0";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

const logStep = (step: string, details?: any) => {
  const detailsStr = details ? ` - ${JSON.stringify(details)}` : '';
  console.log(`[AFFILIATE-ATTRIBUTION] ${step}${detailsStr}`);
};

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    logStep("Processing affiliate attribution");
    
    const { affiliate_code, promo_code, user_id } = await req.json();
    
    if (!user_id) {
      return new Response(JSON.stringify({ error: "User ID required" }), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
        status: 400,
      });
    }
    
    // Use service role key to bypass RLS
    const supabase = createClient(
      Deno.env.get("SUPABASE_URL") ?? "",
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? "",
      { auth: { persistSession: false } }
    );
    
    let affiliateId = null;
    let source = "cookie";
    let precedence = 1;
    
    // Check for promo code first (higher precedence)
    if (promo_code) {
      const { data: promoAffiliate } = await supabase
        .from("affiliates")
        .select("id")
        .eq("promotion_code_id", promo_code)
        .eq("status", "active")
        .single();
        
      if (promoAffiliate) {
        affiliateId = promoAffiliate.id;
        source = "promo";
        precedence = 2;
        logStep("Attribution from promo code", { promoCode: promo_code, affiliateId });
      }
    }
    
    // If no promo code attribution, check affiliate code from cookie
    if (!affiliateId && affiliate_code) {
      const { data: codeAffiliate } = await supabase
        .from("affiliates")
        .select("id")
        .eq("code", affiliate_code)
        .eq("status", "active")
        .single();
        
      if (codeAffiliate) {
        affiliateId = codeAffiliate.id;
        source = "cookie";
        precedence = 1;
        logStep("Attribution from affiliate code", { affiliateCode: affiliate_code, affiliateId });
      }
    }
    
    if (!affiliateId) {
      logStep("No valid affiliate found");
      return new Response(JSON.stringify({ attributed: false }), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
        status: 200,
      });
    }
    
    // Check if attribution already exists
    const { data: existingAttribution } = await supabase
      .from("affiliate_attributions")
      .select("id, source, precedence")
      .eq("user_id", user_id)
      .single();
      
    if (existingAttribution) {
      // Update if new attribution has higher precedence
      if (precedence > existingAttribution.precedence) {
        const { error: updateError } = await supabase
          .from("affiliate_attributions")
          .update({
            affiliate_id: affiliateId,
            source,
            precedence
          })
          .eq("user_id", user_id);
          
        if (updateError) {
          logStep("Error updating attribution", { error: updateError });
        } else {
          logStep("Attribution updated", { userId: user_id, affiliateId, source });
        }
      } else {
        logStep("Existing attribution has higher precedence", { 
          existing: existingAttribution.precedence, 
          new: precedence 
        });
      }
    } else {
      // Create new attribution
      const { error: insertError } = await supabase
        .from("affiliate_attributions")
        .insert({
          affiliate_id: affiliateId,
          user_id,
          source,
          precedence
        });
        
      if (insertError) {
        logStep("Error creating attribution", { error: insertError });
      } else {
        logStep("Attribution created", { userId: user_id, affiliateId, source });
      }
    }
    
    return new Response(JSON.stringify({ 
      attributed: true,
      affiliate_id: affiliateId,
      source 
    }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
      status: 200,
    });
    
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : String(error);
    logStep("Attribution error", { error: errorMessage });
    return new Response(JSON.stringify({ error: errorMessage }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
      status: 500,
    });
  }
});