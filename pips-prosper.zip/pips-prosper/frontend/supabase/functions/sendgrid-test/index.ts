import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import sgMail from "npm:@sendgrid/mail@8.1.4";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

interface TestEmailRequest {
  to: string;
  subject?: string;
  html?: string;
  categories?: string[];
  customArgs?: Record<string, string>;
}

const handler = async (req: Request): Promise<Response> => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    // Initialize SendGrid
    const apiKey = Deno.env.get("SENDGRID_API_KEY");
    if (!apiKey) {
      throw new Error("SENDGRID_API_KEY is not configured");
    }
    
    sgMail.setApiKey(apiKey);
    
    const { to, subject, html, categories, customArgs }: TestEmailRequest = await req.json();
    
    const msg = {
      to,
      from: {
        name: Deno.env.get("EMAIL_FROM_NAME") || "PipTrackr",
        email: Deno.env.get("EMAIL_FROM_ADDRESS") || "noreply@piptrackr.com",
      },
      replyTo: Deno.env.get("EMAIL_REPLY_TO") || "support@piptrackr.com",
      subject: subject || "SendGrid Test Email",
      html: html || "<h1>SendGrid Integration Test ✅</h1><p>This is a test email from your SendGrid Web API integration.</p>",
      ...(categories && { categories }),
      ...(customArgs && { customArgs })
    };

    console.log("Sending test email to:", to);
    const [response] = await sgMail.send(msg);
    
    console.log("Email sent successfully:", response.statusCode);
    
    return new Response(JSON.stringify({ 
      ok: true, 
      status: response.statusCode,
      messageId: response.headers?.['x-message-id']
    }), {
      status: 200,
      headers: {
        "Content-Type": "application/json",
        ...corsHeaders,
      },
    });
  } catch (error: any) {
    console.error("SendGrid test error:", error);
    const reason = error?.response?.body || error?.message || 'Unknown error';
    
    return new Response(JSON.stringify({ 
      ok: false, 
      error: reason 
    }), {
      status: 500,
      headers: { 
        "Content-Type": "application/json", 
        ...corsHeaders 
      },
    });
  }
};

serve(handler);