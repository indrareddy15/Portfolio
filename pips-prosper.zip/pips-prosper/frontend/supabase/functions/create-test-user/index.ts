// Supabase Edge Function: create-test-user
// Creates a user (if not exists) and assigns user + admin roles
// Usage: POST { email?: string, password?: string, admin?: boolean, display_name?: string }

import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.56.1'

const SUPABASE_URL = Deno.env.get('SUPABASE_URL')!
const SERVICE_ROLE_KEY = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!

const supabase = createClient(SUPABASE_URL, SERVICE_ROLE_KEY)

async function findUserByEmail(email: string) {
  // Supabase Admin API doesn't provide direct get-by-email; list and filter
  const { data, error } = await supabase.auth.admin.listUsers({ page: 1, perPage: 1000 })
  if (error) throw error
  return data.users.find((u) => u.email?.toLowerCase() === email.toLowerCase()) || null
}

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, {
      status: 204,
      headers: {
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Methods': 'POST, OPTIONS',
        'Access-Control-Allow-Headers': 'Content-Type, Authorization',
      },
    })
  }

  if (req.method !== 'POST') {
    return new Response(JSON.stringify({ error: 'Use POST' }), {
      status: 405,
      headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' },
    })
  }

  try {
    const body = await req.json().catch(() => ({}))
    const email = (body.email as string) || 'piptrackr@gmail.com'
    const password = (body.password as string) || 'Admin123'
    const makeAdmin = body.admin !== false // default true
    const displayName = (body.display_name as string) || 'Test User'

    // 1) Find or create user
    let user = await findUserByEmail(email)

    if (!user) {
      const { data, error } = await supabase.auth.admin.createUser({
        email,
        password,
        email_confirm: true,
        user_metadata: { display_name: displayName },
      })
      if (error) throw error
      user = data.user
    }

    if (!user) throw new Error('Unable to create or find user')

    // 2) Ensure profile exists
    const { error: profileErr } = await supabase
      .from('profiles')
      .upsert({ user_id: user.id, display_name: displayName }, { onConflict: 'user_id' })
    if (profileErr) throw profileErr

    // 3) Ensure roles exist (user + optional admin)
    const roles = makeAdmin ? ['user', 'admin'] : ['user']
    for (const role of roles) {
      const { error: roleErr } = await supabase
        .from('user_roles')
        .upsert({ user_id: user.id, role }, { onConflict: 'user_id,role' })
      if (roleErr) throw roleErr
    }

    return new Response(
      JSON.stringify({
        ok: true,
        message: 'User ensured with roles',
        email,
        password,
        roles,
      }),
      { status: 200, headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' } }
    )
  } catch (e) {
    console.error(e)
    return new Response(JSON.stringify({ ok: false, error: String(e?.message || e) }), {
      status: 500,
      headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' },
    })
  }
})
