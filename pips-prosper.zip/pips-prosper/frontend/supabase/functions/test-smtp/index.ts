import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.45.0";
import { SMTPClient } from "https://deno.land/x/denomailer@1.6.0/mod.ts";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

interface TestEmailRequest {
  to: string;
  subject?: string;
  testType?: 'connection' | 'template';
}

class SMTPProvider {
  private host: string;
  private port: number;
  private username: string;
  private password: string;
  private fromName: string;
  private fromAddress: string;
  private replyTo: string;

  constructor(config: {
    host: string;
    port: number;
    username: string;
    password: string;
    fromName: string;
    fromAddress: string;
    replyTo: string;
  }) {
    this.host = config.host;
    this.port = config.port;
    this.username = config.username;
    this.password = config.password;
    this.fromName = config.fromName;
    this.fromAddress = config.fromAddress;
    this.replyTo = config.replyTo;
  }

  async testConnection(): Promise<{ success: boolean; error?: string }> {
    try {
      const client = new SMTPClient({
        connection: {
          hostname: this.host,
          port: this.port,
          tls: this.port === 465,
          auth: {
            username: this.username,
            password: this.password,
          },
        },
      });

      // Just connect and close to test
      await client.close();

      return { success: true };
    } catch (error) {
      console.error('SMTP connection test error:', error);
      return {
        success: false,
        error: `SMTP connection failed: ${error instanceof Error ? error.message : 'Unknown error'}`
      };
    }
  }

  async sendTestEmail(to: string, subject: string): Promise<{ messageId?: string; success: boolean; error?: string }> {
    try {
      const client = new SMTPClient({
        connection: {
          hostname: this.host,
          port: this.port,
          tls: this.port === 465,
          auth: {
            username: this.username,
            password: this.password,
          },
        },
      });

      const html = `
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
          <div style="background: linear-gradient(135deg, #008ffd 0%, #0066cc 100%); color: white; padding: 30px; text-align: center;">
            <h1 style="margin: 0;">SMTP Test Email</h1>
          </div>
          <div style="padding: 30px; border: 1px solid #e1e5e9;">
            <h2>🎉 SMTP Configuration Test Successful!</h2>
            <p>This test email was sent successfully via SMTP relay through:</p>
            <ul>
              <li><strong>Host:</strong> ${this.host}</li>
              <li><strong>Port:</strong> ${this.port}</li>
              <li><strong>From:</strong> ${this.fromName} &lt;${this.fromAddress}&gt;</li>
              <li><strong>Reply-To:</strong> ${this.replyTo}</li>
            </ul>
            <p>Your SMTP integration is working correctly!</p>
            <div style="background-color: #f8f9fa; padding: 15px; border-radius: 5px; margin-top: 20px;">
              <small style="color: #666;">
                Test performed at: ${new Date().toISOString()}<br>
                Configuration: ${this.username ? 'Authenticated' : 'Anonymous'}
              </small>
            </div>
          </div>
        </div>
      `;

      await client.send({
        from: `${this.fromName} <${this.fromAddress}>`,
        to: to,
        subject: subject,
        content: html,
        html: html,
        headers: {
          'Reply-To': this.replyTo,
          'X-Mailer': 'PipTrackr-SMTP-Test'
        }
      });

      await client.close();

      const messageId = `smtp-test-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;

      return {
        success: true,
        messageId: messageId
      };
    } catch (error) {
      console.error('SMTP test send error:', error);
      return {
        success: false,
        error: `SMTP test failed: ${error instanceof Error ? error.message : 'Unknown error'}`
      };
    }
  }
}

const handler = async (req: Request): Promise<Response> => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  if (req.method !== 'POST') {
    return new Response(
      JSON.stringify({ error: 'Method not allowed' }),
      { status: 405, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }

  try {
    // Verify admin access
    const authHeader = req.headers.get('authorization');
    if (!authHeader) {
      return new Response(
        JSON.stringify({ error: 'Authorization header required' }),
        { status: 401, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    const supabase = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
    );

    const { to, subject, testType = 'template' } = await req.json() as TestEmailRequest;

    if (!to) {
      return new Response(
        JSON.stringify({ error: 'Email address is required' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Initialize SMTP provider
    const smtpProvider = new SMTPProvider({
      host: Deno.env.get('SMTP_HOST') ?? 'smtp.sendgrid.net',
      port: parseInt(Deno.env.get('SMTP_PORT') ?? '587'),
      username: Deno.env.get('SMTP_USER') ?? 'apikey',
      password: Deno.env.get('SMTP_PASS') ?? '',
      fromName: Deno.env.get('SMTP_FROM_NAME') ?? 'PipTrackr',
      fromAddress: Deno.env.get('SMTP_FROM_EMAIL') ?? 'noreply@piptrackr.com',
      replyTo: Deno.env.get('SMTP_REPLY_TO') ?? 'support@piptrackr.com'
    });

    let result: { success: boolean; error?: string; messageId?: string };

    if (testType === 'connection') {
      result = await smtpProvider.testConnection();
    } else {
      const testSubject = subject || `SMTP Test Email - ${new Date().toLocaleString()}`;
      result = await smtpProvider.sendTestEmail(to, testSubject);
    }

    console.log(`SMTP ${testType} test result:`, result);

    return new Response(
      JSON.stringify({
        success: result.success,
        messageId: result.messageId,
        error: result.error,
        testType: testType,
        timestamp: new Date().toISOString()
      }),
      { status: 200, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );

  } catch (error) {
    console.error('SMTP test error:', error);
    return new Response(
      JSON.stringify({ 
        error: 'Internal server error',
        details: error instanceof Error ? error.message : 'Unknown error'
      }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
};

serve(handler);