import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';
import { Resend } from "npm:resend@2.0.0";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

interface PayoutOperationRequest {
  operation: 'approve' | 'process' | 'mark_paid' | 'reject' | 'cancel' | 'bulk_action';
  payout_id?: string;
  payout_ids?: string[];
  reference?: string;
  notes?: string;
  rejection_reason?: string;
}

const supabase = createClient(
  Deno.env.get('SUPABASE_URL') ?? '',
  Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
);

const resend = new Resend(Deno.env.get('RESEND_API_KEY') ?? '');

const handler = async (req: Request): Promise<Response> => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { operation, payout_id, payout_ids, reference, notes, rejection_reason }: PayoutOperationRequest = await req.json();

    // Verify admin permissions
    const authHeader = req.headers.get('Authorization');
    if (!authHeader) {
      throw new Error('No authorization header');
    }

    const token = authHeader.replace('Bearer ', '');
    const { data: { user }, error: authError } = await supabase.auth.getUser(token);
    
    if (authError || !user) {
      throw new Error('Invalid or expired token');
    }

    // Check if user has admin role
    const { data: userRoles, error: roleError } = await supabase
      .from('user_roles')
      .select('role')
      .eq('user_id', user.id);

    if (roleError || !userRoles?.some(ur => ur.role === 'admin')) {
      throw new Error('Insufficient permissions');
    }

    let result;

    switch (operation) {
      case 'approve':
        result = await approvePayout(payout_id!);
        break;
      case 'process':
        result = await processPayout(payout_id!);
        break;
      case 'mark_paid':
        result = await markPayoutPaid(payout_id!, reference, notes);
        break;
      case 'reject':
        result = await rejectPayout(payout_id!, rejection_reason);
        break;
      case 'cancel':
        result = await cancelPayout(payout_id!, notes);
        break;
      case 'bulk_action':
        result = await handleBulkAction(payout_ids!, operation);
        break;
      default:
        throw new Error('Invalid operation');
    }

    return new Response(JSON.stringify(result), {
      status: 200,
      headers: { 'Content-Type': 'application/json', ...corsHeaders },
    });

  } catch (error: any) {
    console.error('Payout operation error:', error);
    return new Response(
      JSON.stringify({ error: error.message }),
      {
        status: 400,
        headers: { 'Content-Type': 'application/json', ...corsHeaders },
      }
    );
  }
};

async function approvePayout(payoutId: string) {
  const { data, error } = await supabase
    .from('payouts')
    .update({ status: 'processing' })
    .eq('id', payoutId)
    .eq('status', 'requested')
    .select('*, affiliates:affiliate_id(code, user_id)')
    .single();

  if (error) throw error;
  if (!data) throw new Error('Payout not found or already processed');

  await sendPayoutEmail(data, 'approved');
  return { success: true, payout: data };
}

async function processPayout(payoutId: string) {
  const { data, error } = await supabase
    .from('payouts')
    .update({ status: 'processing' })
    .eq('id', payoutId)
    .eq('status', 'requested')
    .select('*, affiliates:affiliate_id(code, user_id)')
    .single();

  if (error) throw error;
  if (!data) throw new Error('Payout not found or not in requested status');

  await sendPayoutEmail(data, 'processing');
  return { success: true, payout: data };
}

async function markPayoutPaid(payoutId: string, reference?: string, notes?: string) {
  const updateData: any = { status: 'paid' };
  if (reference) updateData.reference = reference;
  if (notes) updateData.notes = notes;

  const { data, error } = await supabase
    .from('payouts')
    .update(updateData)
    .eq('id', payoutId)
    .in('status', ['processing', 'requested'])
    .select('*, affiliates:affiliate_id(code, user_id)')
    .single();

  if (error) throw error;
  if (!data) throw new Error('Payout not found or cannot be marked as paid');

  await sendPayoutEmail(data, 'paid');
  return { success: true, payout: data };
}

async function rejectPayout(payoutId: string, reason?: string) {
  const { data, error } = await supabase
    .from('payouts')
    .update({ 
      status: 'rejected',
      rejection_reason: reason 
    })
    .eq('id', payoutId)
    .eq('status', 'requested')
    .select('*, affiliates:affiliate_id(code, user_id)')
    .single();

  if (error) throw error;
  if (!data) throw new Error('Payout not found or already processed');

  await sendPayoutEmail(data, 'rejected');
  return { success: true, payout: data };
}

async function cancelPayout(payoutId: string, notes?: string) {
  const updateData: any = { status: 'canceled' };
  if (notes) updateData.notes = notes;

  const { data, error } = await supabase
    .from('payouts')
    .update(updateData)
    .eq('id', payoutId)
    .in('status', ['requested', 'processing'])
    .select('*, affiliates:affiliate_id(code, user_id)')
    .single();

  if (error) throw error;
  if (!data) throw new Error('Payout not found or cannot be canceled');

  await sendPayoutEmail(data, 'canceled');
  return { success: true, payout: data };
}

async function handleBulkAction(payoutIds: string[], action: string) {
  const results = [];
  
  for (const id of payoutIds) {
    try {
      let result;
      switch (action) {
        case 'approve':
          result = await approvePayout(id);
          break;
        case 'process':
          result = await processPayout(id);
          break;
        default:
          throw new Error('Bulk action not supported');
      }
      results.push({ id, success: true, result });
    } catch (error: any) {
      results.push({ id, success: false, error: error.message });
    }
  }
  
  return { success: true, results };
}

async function sendPayoutEmail(payout: any, status: string) {
  try {
    // Get affiliate user profile for email
    const { data: profile } = await supabase
      .from('profiles')
      .select('display_name')
      .eq('user_id', payout.affiliates.user_id)
      .single();

    // Get user email from auth.users (need service role for this)
    const { data: { user } } = await supabase.auth.admin.getUserById(payout.affiliates.user_id);
    
    if (!user?.email) {
      console.log('No email found for affiliate user');
      return;
    }

    const emailSubject = getEmailSubject(status, payout.amount);
    const emailContent = getEmailContent(status, payout, profile?.display_name);

    const emailResponse = await resend.emails.send({
      from: 'PipsJournal <payouts@pipsjournal.com>',
      to: [user.email],
      subject: emailSubject,
      html: emailContent,
    });

    console.log('Payout email sent:', emailResponse);
  } catch (error) {
    console.error('Failed to send payout email:', error);
    // Don't throw - email failure shouldn't break the payout operation
  }
}

function getEmailSubject(status: string, amount: number): string {
  const amountStr = `$${amount.toFixed(2)}`;
  switch (status) {
    case 'approved':
    case 'processing':
      return `Payout ${amountStr} is Being Processed`;
    case 'paid':
      return `Payout ${amountStr} Completed Successfully`;
    case 'rejected':
      return `Payout ${amountStr} Request Declined`;
    case 'canceled':
      return `Payout ${amountStr} Request Canceled`;
    default:
      return `Payout ${amountStr} Status Update`;
  }
}

function getEmailContent(status: string, payout: any, displayName?: string): string {
  const name = displayName || 'Affiliate';
  const amount = `$${payout.amount.toFixed(2)}`;
  const method = payout.method;
  const reference = payout.reference;

  switch (status) {
    case 'approved':
    case 'processing':
      return `
        <h2>Payout Being Processed</h2>
        <p>Hi ${name},</p>
        <p>Great news! Your payout request of <strong>${amount}</strong> is now being processed.</p>
        <p><strong>Payment Method:</strong> ${method}</p>
        <p>We'll notify you once the payment has been completed. This typically takes 1-3 business days.</p>
        <p>Best regards,<br>The PipsJournal Team</p>
      `;
    case 'paid':
      return `
        <h2>Payout Completed!</h2>
        <p>Hi ${name},</p>
        <p>Your payout of <strong>${amount}</strong> has been successfully processed and sent to your ${method} account.</p>
        ${reference ? `<p><strong>Transaction Reference:</strong> ${reference}</p>` : ''}
        <p>Thank you for being a valued affiliate partner!</p>
        <p>Best regards,<br>The PipsJournal Team</p>
      `;
    case 'rejected':
      return `
        <h2>Payout Request Declined</h2>
        <p>Hi ${name},</p>
        <p>Unfortunately, we cannot process your payout request of <strong>${amount}</strong> at this time.</p>
        ${payout.rejection_reason ? `<p><strong>Reason:</strong> ${payout.rejection_reason}</p>` : ''}
        <p>Please contact our support team if you have any questions or would like to discuss this further.</p>
        <p>Best regards,<br>The PipsJournal Team</p>
      `;
    case 'canceled':
      return `
        <h2>Payout Request Canceled</h2>
        <p>Hi ${name},</p>
        <p>Your payout request of <strong>${amount}</strong> has been canceled.</p>
        ${payout.notes ? `<p><strong>Note:</strong> ${payout.notes}</p>` : ''}
        <p>You can submit a new payout request anytime from your affiliate dashboard.</p>
        <p>Best regards,<br>The PipsJournal Team</p>
      `;
    default:
      return `
        <h2>Payout Status Update</h2>
        <p>Hi ${name},</p>
        <p>Your payout request of <strong>${amount}</strong> status has been updated.</p>
        <p>Please check your affiliate dashboard for more details.</p>
        <p>Best regards,<br>The PipsJournal Team</p>
      `;
  }
}

serve(handler);