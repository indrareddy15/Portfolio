-- Create templates table for real-time functionality
CREATE TABLE public.trading_templates (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id uuid NOT NULL,
  name text NOT NULL,
  description text,
  category text NOT NULL DEFAULT 'Strategy'::text,
  preview text,
  content jsonb NOT NULL DEFAULT '{}'::jsonb,
  is_public boolean NOT NULL DEFAULT false,
  rating numeric NOT NULL DEFAULT 0.0,
  downloads integer NOT NULL DEFAULT 0,
  tags text[],
  active boolean NOT NULL DEFAULT true,
  created_at timestamp with time zone NOT NULL DEFAULT now(),
  updated_at timestamp with time zone NOT NULL DEFAULT now()
);

-- Create gold_rules table for trading rules
CREATE TABLE public.gold_rules (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id uuid NOT NULL,
  title text NOT NULL,
  rule_text text NOT NULL,
  rule_type text NOT NULL DEFAULT 'general'::text,
  priority integer NOT NULL DEFAULT 1,
  is_active boolean NOT NULL DEFAULT true,
  color_code text DEFAULT '#008ffd'::text,
  reminder_frequency text DEFAULT 'daily'::text,
  violation_count integer NOT NULL DEFAULT 0,
  last_reminded_at timestamp with time zone,
  created_at timestamp with time zone NOT NULL DEFAULT now(),
  updated_at timestamp with time zone NOT NULL DEFAULT now()
);

-- Enable Row Level Security
ALTER TABLE public.trading_templates ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.gold_rules ENABLE ROW LEVEL SECURITY;

-- Create RLS policies for trading_templates
CREATE POLICY "Users can view public templates or own templates" 
ON public.trading_templates 
FOR SELECT 
TO authenticated
USING (is_public = true OR auth.uid() = user_id);

CREATE POLICY "Users can create their own templates" 
ON public.trading_templates 
FOR INSERT 
TO authenticated
WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own templates" 
ON public.trading_templates 
FOR UPDATE 
TO authenticated
USING (auth.uid() = user_id)
WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can delete their own templates" 
ON public.trading_templates 
FOR DELETE 
TO authenticated
USING (auth.uid() = user_id);

-- Create RLS policies for gold_rules
CREATE POLICY "Users can manage their own gold rules" 
ON public.gold_rules 
FOR ALL 
TO authenticated
USING (auth.uid() = user_id)
WITH CHECK (auth.uid() = user_id);

-- Create indexes for performance
CREATE INDEX idx_trading_templates_user_id ON public.trading_templates(user_id);
CREATE INDEX idx_trading_templates_category ON public.trading_templates(category);
CREATE INDEX idx_trading_templates_public ON public.trading_templates(is_public) WHERE is_public = true;
CREATE INDEX idx_gold_rules_user_id ON public.gold_rules(user_id);
CREATE INDEX idx_gold_rules_priority ON public.gold_rules(priority);

-- Create updated_at triggers
CREATE TRIGGER update_trading_templates_updated_at
BEFORE UPDATE ON public.trading_templates
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_gold_rules_updated_at
BEFORE UPDATE ON public.gold_rules
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();

-- Enable realtime
ALTER TABLE public.trading_templates REPLICA IDENTITY FULL;
ALTER TABLE public.gold_rules REPLICA IDENTITY FULL;