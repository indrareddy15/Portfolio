-- Fix critical security vulnerabilities in subscribers table RLS policies

-- Drop the existing overly permissive policies
DROP POLICY IF EXISTS "insert_subscription" ON public.subscribers;
DROP POLICY IF EXISTS "update_own_subscription" ON public.subscribers;

-- Create secure INSERT policy - only authenticated users can insert their own subscription records
CREATE POLICY "users_can_insert_own_subscription" ON public.subscribers
FOR INSERT 
TO authenticated
WITH CHECK (
  auth.uid() = user_id 
  AND auth.email() = email
);

-- Create secure UPDATE policy - users can only update their own subscription records
CREATE POLICY "users_can_update_own_subscription" ON public.subscribers
FOR UPDATE 
TO authenticated
USING (
  auth.uid() = user_id 
  OR auth.email() = email
);

-- Keep the existing SELECT policy as it's already properly secured
-- Policy "select_own_subscription" allows users to view only their own records

-- Add a service role policy for edge functions to bypass RLS when needed
-- This allows edge functions using service role key to perform administrative operations
CREATE POLICY "service_role_full_access" ON public.subscribers
FOR ALL 
TO service_role
USING (true)
WITH CHECK (true);