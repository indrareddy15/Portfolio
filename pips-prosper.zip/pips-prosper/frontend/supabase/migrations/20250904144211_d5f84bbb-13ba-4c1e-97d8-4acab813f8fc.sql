-- Enable RLS on new tables and create policies

-- Enable RLS on new tables
ALTER TABLE public.trade_legs ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.equity_snapshots ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.metrics_summary ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.instrument_stats ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.session_stats ENABLE ROW LEVEL SECURITY;

-- Create RLS policies for trade_legs
CREATE POLICY "Users can manage their own trade legs" ON public.trade_legs
  FOR ALL USING (
    trade_id IN (SELECT id FROM public.trades WHERE user_id = auth.uid())
  )
  WITH CHECK (
    trade_id IN (SELECT id FROM public.trades WHERE user_id = auth.uid())
  );

-- Create RLS policies for equity_snapshots
CREATE POLICY "Users can manage their own equity snapshots" ON public.equity_snapshots
  FOR ALL USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

-- Create RLS policies for metrics_summary
CREATE POLICY "Users can manage their own metrics summary" ON public.metrics_summary
  FOR ALL USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

-- Create RLS policies for instrument_stats
CREATE POLICY "Users can manage their own instrument stats" ON public.instrument_stats
  FOR ALL USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

-- Create RLS policies for session_stats
CREATE POLICY "Users can manage their own session stats" ON public.session_stats
  FOR ALL USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);