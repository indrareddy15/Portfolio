-- Add 'scheduled' status to email_logs table
ALTER TABLE email_logs 
DROP CONSTRAINT IF EXISTS email_logs_status_check;

ALTER TABLE email_logs 
ADD CONSTRAINT email_logs_status_check 
CHECK (status IN ('queued', 'processing', 'sent', 'failed', 'scheduled'));

-- Add more email templates to the TemplateRenderer
-- Create unsubscribe management table
CREATE TABLE IF NOT EXISTS email_unsubscribes (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  email TEXT NOT NULL,
  template_key TEXT,
  reason TEXT,
  unsubscribed_at TIMESTAMPTZ DEFAULT now(),
  created_at TIMESTAMPTZ DEFAULT now()
);

-- Enable RLS
ALTER TABLE email_unsubscribes ENABLE ROW LEVEL SECURITY;

-- Policies for unsubscribes
CREATE POLICY "Anyone can unsubscribe" ON email_unsubscribes
FOR INSERT WITH CHECK (true);

-- Admins can view unsubscribe data
CREATE POLICY "Admins can view unsubscribes" ON email_unsubscribes
FOR SELECT USING (has_role(auth.uid(), 'admin'::app_role));

-- Create indexes
CREATE INDEX email_unsubscribes_email_idx ON email_unsubscribes(email);
CREATE INDEX email_unsubscribes_template_key_idx ON email_unsubscribes(template_key);