-- Fix inconsistent instrument class_name data
UPDATE instruments 
SET class_name = 'crypto' 
WHERE symbol IN ('BTCUSD', 'ETHUSD', 'SOLUSD', 'ADAUSD', 'DOTUSD', 'LINKUSD');

UPDATE instruments 
SET class_name = 'forex' 
WHERE symbol IN ('AUDCAD', 'AUDCHF', 'AUDUSD', 'CADCHF', 'CADJPY', 'CHFJPY', 'EURAUD', 'EURCAD', 'EURCHF', 'EURGBP', 'EURJPY', 'EURNZD', 'EURUSD', 'GBPAUD', 'GBPCAD', 'GBPCHF', 'GBPJPY', 'GBPNZD', 'GBPUSD', 'NZDCAD', 'NZDCHF', 'NZDJPY', 'NZDUSD', 'USDCAD', 'USDCHF', 'USDJPY');

UPDATE instruments 
SET class_name = 'metals' 
WHERE symbol IN ('XAUUSD', 'XAGUSD');

UPDATE instruments 
SET class_name = 'indices' 
WHERE symbol IN ('US30', 'NAS100', 'SPX500', 'DAX40', 'FTSE100');

UPDATE instruments 
SET class_name = 'oil' 
WHERE symbol IN ('WTI', 'Brent');

-- Also update the legacy 'class' field to match class_name for consistency
UPDATE instruments SET class = class_name;