-- Create account goals table
CREATE TABLE IF NOT EXISTS public.account_goals (
    id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
    account_id uuid NOT NULL REFERENCES public.accounts(id) ON DELETE CASCADE,
    user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
    goal_type text NOT NULL CHECK (goal_type IN ('profit_target', 'win_rate', 'max_drawdown', 'risk_per_trade')),
    target_value numeric NOT NULL,
    current_value numeric DEFAULT 0,
    target_date date,
    is_achieved boolean DEFAULT false,
    created_at timestamp with time zone NOT NULL DEFAULT now(),
    updated_at timestamp with time zone NOT NULL DEFAULT now()
);

-- Enable RLS on account_goals table
ALTER TABLE public.account_goals ENABLE ROW LEVEL SECURITY;

-- Create policies for account_goals
CREATE POLICY "Users can manage their own account goals" 
ON public.account_goals 
FOR ALL 
USING (auth.uid() = user_id)
WITH CHECK (auth.uid() = user_id);

-- Add unique constraint for account nickname per user
ALTER TABLE public.accounts DROP CONSTRAINT IF EXISTS accounts_user_id_nickname_key;
ALTER TABLE public.accounts ADD CONSTRAINT accounts_user_id_nickname_unique UNIQUE (user_id, nickname);

-- Add trigger for account_goals updated_at
CREATE TRIGGER update_account_goals_updated_at
    BEFORE UPDATE ON public.account_goals
    FOR EACH ROW
    EXECUTE FUNCTION public.update_updated_at_column();