-- Add missing user_invoices table if it doesn't exist
DO $$ 
BEGIN
    IF NOT EXISTS (SELECT 1 FROM information_schema.tables WHERE table_name = 'user_invoices' AND table_schema = 'public') THEN
        -- Create invoice_status enum if it doesn't exist
        IF NOT EXISTS (SELECT 1 FROM pg_type WHERE typname = 'invoice_status') THEN
            CREATE TYPE invoice_status AS ENUM ('paid', 'open', 'void', 'uncollectible', 'draft');
        END IF;

        -- Create invoices table
        CREATE TABLE public.user_invoices (
            id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
            user_id UUID NOT NULL,
            stripe_invoice_id TEXT UNIQUE NOT NULL,
            amount_due DECIMAL(10,2) NOT NULL,
            currency TEXT NOT NULL DEFAULT 'USD',
            status invoice_status NOT NULL,
            hosted_invoice_url TEXT,
            invoice_pdf_url TEXT,
            created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
            updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
        );

        -- Enable RLS
        ALTER TABLE public.user_invoices ENABLE ROW LEVEL SECURITY;

        -- Create RLS policies
        CREATE POLICY "Users can view own invoices" ON public.user_invoices
            FOR SELECT USING (user_id = auth.uid() OR has_role(auth.uid(), 'admin'::app_role));

        CREATE POLICY "Service role can manage invoices" ON public.user_invoices
            FOR ALL USING ((auth.jwt() ->> 'role'::text) = 'service_role'::text);

        -- Create indexes
        CREATE INDEX idx_user_invoices_user_id ON public.user_invoices(user_id);
        CREATE INDEX idx_user_invoices_stripe_id ON public.user_invoices(stripe_invoice_id);

        -- Create trigger for updated_at
        CREATE TRIGGER update_user_invoices_updated_at
            BEFORE UPDATE ON public.user_invoices
            FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
    END IF;
END $$;