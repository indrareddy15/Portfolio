-- Enable realtime for blog tables
ALTER publication supabase_realtime ADD TABLE blog_posts;
ALTER publication supabase_realtime ADD TABLE blog_categories;  
ALTER publication supabase_realtime ADD TABLE blog_tags;
ALTER publication supabase_realtime ADD TABLE blog_post_tags;
ALTER publication supabase_realtime ADD TABLE blog_media;

-- Set replica identity for better realtime updates
ALTER TABLE blog_posts REPLICA IDENTITY FULL;
ALTER TABLE blog_categories REPLICA IDENTITY FULL;
ALTER TABLE blog_tags REPLICA IDENTITY FULL;
ALTER TABLE blog_post_tags REPLICA IDENTITY FULL;
ALTER TABLE blog_media REPLICA IDENTITY FULL;