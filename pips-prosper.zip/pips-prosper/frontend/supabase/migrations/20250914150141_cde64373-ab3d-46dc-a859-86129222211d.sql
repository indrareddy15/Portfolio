-- Enable required extensions for scheduled blog publishing
CREATE EXTENSION IF NOT EXISTS pg_cron;
CREATE EXTENSION IF NOT EXISTS pg_net;

-- Create cron job to automatically publish scheduled blog posts every 2 minutes
SELECT cron.schedule(
  'auto-publish-scheduled-blog-posts',
  '*/2 * * * *', -- Run every 2 minutes
  $$
  SELECT
    net.http_post(
        url:='https://pwpxzlcpdbqjckvmkwlw.supabase.co/functions/v1/blog-scheduler',
        headers:='{"Content-Type": "application/json", "Authorization": "Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InB3cHh6bGNwZGJxamNrdm1rd2x3Iiwicm9sZSI6InNlcnZpY2Vfcm9sZSIsImlhdCI6MTc1NjYwNDYwNCwiZXhwIjoyMDcyMTgwNjA0fQ.2mQacttj0TTkM5zdlkyGYyRvZP-YGHhZabj7Rj1Whuo"}'::jsonb,
        body:=concat('{"scheduled_at": "', now(), '"}')::jsonb
    ) as request_id;
  $$
);