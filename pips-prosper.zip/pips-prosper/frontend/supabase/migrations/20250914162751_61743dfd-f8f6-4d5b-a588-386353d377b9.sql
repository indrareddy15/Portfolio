-- Insert demo blog data
INSERT INTO blog_categories (id, name, slug, description) 
VALUES 
  (gen_random_uuid(), 'Trading Tips', 'trading-tips', 'Expert trading tips and strategies'),
  (gen_random_uuid(), 'Market Analysis', 'market-analysis', 'In-depth market analysis and insights')
ON CONFLICT (slug) DO NOTHING;

INSERT INTO blog_authors (id, name, slug, bio, avatar_url) 
VALUES 
  (gen_random_uuid(), 'Trading Expert', 'trading-expert', 'Professional trader with 10+ years of experience in forex and cryptocurrency markets.', 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&h=150&fit=crop&crop=face')
ON CONFLICT (slug) DO NOTHING;

-- Insert demo blog post
INSERT INTO blog_posts (
  id,
  title, 
  slug, 
  excerpt, 
  body_md, 
  status, 
  publish_at,
  meta_title,
  meta_description,
  category_id,
  author_id,
  featured,
  reading_time,
  cover_url
)
SELECT 
  gen_random_uuid(),
  'Top 5 Trading Strategies for Beginners',
  'top-5-trading-strategies-for-beginners',
  'Learn the most effective trading strategies that every beginner should know to start their trading journey successfully.',
  '# Top 5 Trading Strategies for Beginners

Trading can be overwhelming for beginners, but with the right strategies, you can start your journey on the right foot. Here are the top 5 trading strategies every beginner should know:

## 1. Dollar-Cost Averaging (DCA)

Dollar-cost averaging is one of the safest strategies for beginners. Instead of investing a large sum at once, you invest a fixed amount regularly regardless of market conditions.

**Benefits:**
- Reduces impact of market volatility
- Eliminates need to time the market
- Creates disciplined investing habits

## 2. Trend Following

This strategy involves identifying the market trend and trading in the same direction. The famous saying "the trend is your friend" applies here.

**Key Points:**
- Use moving averages to identify trends
- Wait for clear trend confirmation
- Set stop-losses to protect capital

## 3. Support and Resistance Trading

Support and resistance levels are psychological price points where the market tends to reverse or pause.

**How to Use:**
- Buy near support levels
- Sell near resistance levels
- Use multiple timeframes for confirmation

## 4. Risk Management Strategy

This isn''t a trading strategy per se, but it''s crucial for long-term success.

**Rules to Follow:**
- Never risk more than 2% per trade
- Always set stop-losses
- Keep a trading journal
- Don''t let emotions drive decisions

## 5. Paper Trading

Before risking real money, practice with paper trading (virtual trading with fake money).

**Benefits:**
- Learn without financial risk
- Test strategies in real market conditions
- Build confidence and skills

## Conclusion

Remember, successful trading takes time, patience, and continuous learning. Start with these basic strategies and gradually develop your own trading style as you gain experience.

**Disclaimer:** Trading involves substantial risk and is not suitable for every investor. Past performance does not guarantee future results.',
  'published',
  now(),
  'Top 5 Trading Strategies for Beginners - Complete Guide',
  'Discover the most effective trading strategies for beginners. Learn dollar-cost averaging, trend following, support & resistance trading and more.',
  (SELECT id FROM blog_categories WHERE slug = 'trading-tips' LIMIT 1),
  (SELECT id FROM blog_authors WHERE slug = 'trading-expert' LIMIT 1),
  true,
  5,
  'https://images.unsplash.com/photo-1611974789855-9c2a0a7236a3?w=1200&h=630&fit=crop'
WHERE NOT EXISTS (SELECT 1 FROM blog_posts WHERE slug = 'top-5-trading-strategies-for-beginners');