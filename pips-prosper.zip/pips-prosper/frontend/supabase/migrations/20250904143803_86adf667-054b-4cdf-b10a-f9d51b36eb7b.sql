-- Create enums for trade status and sources
CREATE TYPE IF NOT EXISTS trade_status AS ENUM ('open', 'closed', 'partial');
CREATE TYPE IF NOT EXISTS trade_source AS ENUM ('manual', 'mt4', 'mt5', 'ctrader', 'tradelocker', 'tv');
CREATE TYPE IF NOT EXISTS leg_type AS ENUM ('open', 'close');

-- Update trades table with new fields
ALTER TABLE public.trades 
ADD COLUMN IF NOT EXISTS status trade_status DEFAULT 'open',
ADD COLUMN IF NOT EXISTS commission numeric DEFAULT 0,
ADD COLUMN IF NOT EXISTS swap numeric DEFAULT 0,
ADD COLUMN IF NOT EXISTS fees numeric DEFAULT 0,
ADD COLUMN IF NOT EXISTS raw_pnl_quote numeric,
ADD COLUMN IF NOT EXISTS fx_rate_used numeric DEFAULT 1,
ADD COLUMN IF NOT EXISTS pnl_account numeric,
ADD COLUMN IF NOT EXISTS rr numeric,
ADD COLUMN IF NOT EXISTS pips_or_ticks numeric,
ADD COLUMN IF NOT EXISTS account_ccy text DEFAULT 'USD',
ADD COLUMN IF NOT EXISTS source trade_source DEFAULT 'manual',
ADD COLUMN IF NOT EXISTS provider_trade_id text,
ADD COLUMN IF NOT EXISTS lots numeric,
ADD COLUMN IF NOT EXISTS quantity numeric;

-- Update instruments table with new fields
ALTER TABLE public.instruments
ADD COLUMN IF NOT EXISTS contract_size numeric DEFAULT 100000,
ADD COLUMN IF NOT EXISTS point_value numeric DEFAULT 1,
ADD COLUMN IF NOT EXISTS tick_size numeric DEFAULT 0.0001;

-- Create trade_legs table for partial closes
CREATE TABLE IF NOT EXISTS public.trade_legs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  trade_id uuid NOT NULL REFERENCES public.trades(id) ON DELETE CASCADE,
  leg_type leg_type NOT NULL,
  price numeric NOT NULL,
  qty_or_lots numeric NOT NULL,
  time timestamptz NOT NULL DEFAULT now(),
  created_at timestamptz NOT NULL DEFAULT now()
);

-- Create equity_snapshots table
CREATE TABLE IF NOT EXISTS public.equity_snapshots (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL,
  time_utc timestamptz NOT NULL DEFAULT now(),
  equity_account numeric NOT NULL,
  account_id uuid REFERENCES public.accounts(id),
  created_at timestamptz NOT NULL DEFAULT now()
);

-- Create metrics_summary table (denormalized)
CREATE TABLE IF NOT EXISTS public.metrics_summary (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL,
  scope text NOT NULL, -- 'all_time', 'monthly', 'weekly', 'custom_hash'
  start_ts timestamptz,
  end_ts timestamptz,
  total_pnl numeric DEFAULT 0,
  net_pnl numeric DEFAULT 0,
  win_rate numeric DEFAULT 0,
  avg_rr numeric DEFAULT 0,
  profit_factor numeric DEFAULT 0,
  expectancy numeric DEFAULT 0,
  max_dd numeric DEFAULT 0,
  sharpe numeric DEFAULT 0,
  longest_win integer DEFAULT 0,
  longest_loss integer DEFAULT 0,
  trade_count integer DEFAULT 0,
  updated_at timestamptz NOT NULL DEFAULT now(),
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE(user_id, scope, start_ts, end_ts)
);

-- Create instrument_stats table
CREATE TABLE IF NOT EXISTS public.instrument_stats (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL,
  symbol text NOT NULL,
  trade_count integer DEFAULT 0,
  pnl numeric DEFAULT 0,
  win_rate numeric DEFAULT 0,
  avg_rr numeric DEFAULT 0,
  updated_at timestamptz NOT NULL DEFAULT now(),
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE(user_id, symbol)
);

-- Create session_stats table
CREATE TABLE IF NOT EXISTS public.session_stats (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL,
  session text NOT NULL, -- 'London', 'NY', 'Asia', 'Other'
  pnl numeric DEFAULT 0,
  trade_count integer DEFAULT 0,
  updated_at timestamptz NOT NULL DEFAULT now(),
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE(user_id, session)
);

-- Add unique constraint for provider trade IDs to prevent dupes
CREATE UNIQUE INDEX IF NOT EXISTS trades_provider_unique 
ON public.trades(user_id, provider_trade_id) 
WHERE provider_trade_id IS NOT NULL;

-- Enable RLS on new tables
ALTER TABLE public.trade_legs ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.equity_snapshots ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.metrics_summary ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.instrument_stats ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.session_stats ENABLE ROW LEVEL SECURITY;

-- Create RLS policies
CREATE POLICY "Users can manage their own trade legs" ON public.trade_legs
  FOR ALL USING (
    trade_id IN (SELECT id FROM public.trades WHERE user_id = auth.uid())
  )
  WITH CHECK (
    trade_id IN (SELECT id FROM public.trades WHERE user_id = auth.uid())
  );

CREATE POLICY "Users can manage their own equity snapshots" ON public.equity_snapshots
  FOR ALL USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can manage their own metrics summary" ON public.metrics_summary
  FOR ALL USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can manage their own instrument stats" ON public.instrument_stats
  FOR ALL USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can manage their own session stats" ON public.session_stats
  FOR ALL USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

-- Create triggers for updated_at columns
CREATE TRIGGER update_trade_legs_updated_at
  BEFORE UPDATE ON public.trade_legs
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_equity_snapshots_updated_at
  BEFORE UPDATE ON public.equity_snapshots
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_metrics_summary_updated_at
  BEFORE UPDATE ON public.metrics_summary
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_instrument_stats_updated_at
  BEFORE UPDATE ON public.instrument_stats
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_session_stats_updated_at
  BEFORE UPDATE ON public.session_stats
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at_column();

-- Add indexes for performance
CREATE INDEX IF NOT EXISTS idx_trades_user_id_status ON public.trades(user_id, status);
CREATE INDEX IF NOT EXISTS idx_trades_user_id_opened_at ON public.trades(user_id, opened_at DESC);
CREATE INDEX IF NOT EXISTS idx_equity_snapshots_user_id_time ON public.equity_snapshots(user_id, time_utc DESC);
CREATE INDEX IF NOT EXISTS idx_metrics_summary_user_id_scope ON public.metrics_summary(user_id, scope);
CREATE INDEX IF NOT EXISTS idx_instrument_stats_user_id ON public.instrument_stats(user_id);
CREATE INDEX IF NOT EXISTS idx_session_stats_user_id ON public.session_stats(user_id);