-- Insert default system settings with affiliate program disabled
INSERT INTO public.cms_blocks (key, content_json, updated_by, created_at, updated_at)
VALUES (
  'system_settings',
  '{
    "maintenance_mode": false,
    "new_registrations": true,
    "affiliate_program": false,
    "default_commission_rate": 30,
    "min_payout_amount": 50,
    "payout_processing_days": 14,
    "support_email": "support@piptrackr.com",
    "company_name": "PipTrackr.com",
    "site_url": "https://piptrackr.com"
  }'::jsonb,
  null,
  now(),
  now()
)
ON CONFLICT (key) DO UPDATE SET
  content_json = EXCLUDED.content_json,
  updated_at = now();