-- Insert seed data for common instruments with all required columns
INSERT INTO public.instruments (symbol, class, base_ccy, quote_ccy, lot_units, pip_size, price_precision, pip_precision, contract_size, tick_size, pricing_mode, is_active) VALUES
  -- Major Forex Pairs
  ('EURUSD', 'forex', 'EUR', 'USD', 100000, 0.0001, 5, 1, 100000, 0.0001, 'forex', true),
  ('GBPUSD', 'forex', 'GBP', 'USD', 100000, 0.0001, 5, 1, 100000, 0.0001, 'forex', true),
  ('USDJPY', 'forex', 'USD', 'JPY', 100000, 0.01, 3, 1, 100000, 0.01, 'forex', true),
  ('USDCHF', 'forex', 'USD', 'CHF', 100000, 0.0001, 5, 1, 100000, 0.0001, 'forex', true),
  ('AUDUSD', 'forex', 'AUD', 'USD', 100000, 0.0001, 5, 1, 100000, 0.0001, 'forex', true),
  ('USDCAD', 'forex', 'USD', 'CAD', 100000, 0.0001, 5, 1, 100000, 0.0001, 'forex', true),
  ('NZDUSD', 'forex', 'NZD', 'USD', 100000, 0.0001, 5, 1, 100000, 0.0001, 'forex', true),
  ('EURJPY', 'forex', 'EUR', 'JPY', 100000, 0.01, 3, 1, 100000, 0.01, 'forex', true),
  ('GBPJPY', 'forex', 'GBP', 'JPY', 100000, 0.01, 3, 1, 100000, 0.01, 'forex', true),
  ('EURGBP', 'forex', 'EUR', 'GBP', 100000, 0.0001, 5, 1, 100000, 0.0001, 'forex', true),
  
  -- Metals
  ('XAUUSD', 'metals', 'XAU', 'USD', 100, 0.01, 2, 1, 100, 0.01, 'forex', true),
  ('XAGUSD', 'metals', 'XAG', 'USD', 5000, 0.001, 3, 1, 5000, 0.001, 'forex', true),
  
  -- Indices  
  ('US30', 'indices', 'US30', 'USD', 1, 1, 0, 1, 1, 1, 'forex', true),
  ('NAS100', 'indices', 'NAS100', 'USD', 1, 0.1, 1, 1, 1, 0.1, 'forex', true),
  ('SPX500', 'indices', 'SPX500', 'USD', 1, 0.1, 1, 1, 1, 0.1, 'forex', true),
  ('GER30', 'indices', 'GER30', 'EUR', 1, 1, 0, 1, 1, 1, 'forex', true),
  ('UK100', 'indices', 'UK100', 'GBP', 1, 1, 0, 1, 1, 1, 'forex', true),
  
  -- Crypto
  ('BTCUSD', 'crypto', 'BTC', 'USD', 1, 0.1, 1, 1, 1, 0.1, 'forex', true),
  ('ETHUSD', 'crypto', 'ETH', 'USD', 1, 0.01, 2, 1, 1, 0.01, 'forex', true),
  ('ADAUSD', 'crypto', 'ADA', 'USD', 1, 0.0001, 4, 1, 1, 0.0001, 'forex', true)
ON CONFLICT (symbol) DO NOTHING;

-- Create metrics calculation service function
CREATE OR REPLACE FUNCTION public.calculate_metrics_for_account(
  account_id_param UUID,
  from_date TIMESTAMPTZ DEFAULT NULL,
  to_date TIMESTAMPTZ DEFAULT NULL
) RETURNS TABLE(
  trades_count INTEGER,
  win_count INTEGER,
  loss_count INTEGER,
  win_pct DECIMAL,
  net_pnl_cents INTEGER,
  gross_profit_cents INTEGER,
  gross_loss_cents INTEGER,
  profit_factor DECIMAL,
  avg_rr DECIMAL,
  max_dd_pct DECIMAL
) AS $$
DECLARE
  total_trades INTEGER;
  winning_trades INTEGER;
  losing_trades INTEGER;
  total_pnl INTEGER;
  profit_sum INTEGER;
  loss_sum INTEGER;
  running_pnl INTEGER := 0;
  max_drawdown INTEGER := 0;
  current_drawdown INTEGER := 0;
  peak_balance INTEGER := 0;
  avg_risk_reward DECIMAL := 0;
BEGIN
  -- Set default date range if not provided
  IF from_date IS NULL THEN
    from_date := CURRENT_DATE - INTERVAL '30 days';
  END IF;
  
  IF to_date IS NULL THEN
    to_date := CURRENT_DATE + INTERVAL '1 day';
  END IF;
  
  -- Calculate basic metrics
  SELECT 
    COUNT(*),
    COUNT(*) FILTER (WHERE pnl > 0),
    COUNT(*) FILTER (WHERE pnl < 0),
    COALESCE(SUM(pnl), 0),
    COALESCE(SUM(pnl) FILTER (WHERE pnl > 0), 0),
    COALESCE(ABS(SUM(pnl)) FILTER (WHERE pnl < 0), 0)
  INTO total_trades, winning_trades, losing_trades, total_pnl, profit_sum, loss_sum
  FROM public.trades
  WHERE account_id = account_id_param
    AND opened_at >= from_date 
    AND opened_at <= to_date
    AND closed_at IS NOT NULL;
  
  -- Calculate average risk-reward ratio
  SELECT COALESCE(AVG(
    CASE 
      WHEN sl IS NOT NULL AND tp IS NOT NULL AND sl != entry AND tp != entry THEN
        ABS(tp - entry) / ABS(entry - sl)
      ELSE NULL 
    END
  ), 0) INTO avg_risk_reward
  FROM public.trades
  WHERE account_id = account_id_param
    AND opened_at >= from_date 
    AND opened_at <= to_date
    AND closed_at IS NOT NULL;
  
  -- Return calculated metrics
  RETURN QUERY SELECT
    total_trades,
    winning_trades,
    losing_trades,
    CASE WHEN total_trades > 0 THEN (winning_trades::DECIMAL / total_trades * 100) ELSE 0 END,
    total_pnl,
    profit_sum,
    loss_sum,
    CASE WHEN loss_sum > 0 THEN (profit_sum::DECIMAL / loss_sum) ELSE 0 END,
    avg_risk_reward,
    CASE WHEN peak_balance > 0 THEN (max_drawdown::DECIMAL / peak_balance * 100) ELSE 0 END;
    
END;
$$ LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path = public;