-- Fix search path security issue
CREATE OR REPLACE FUNCTION public.get_webhook_keys_safe()
RETURNS TABLE (
    id uuid,
    user_id uuid,
    name text,
    secret_masked text,
    secret text,
    active boolean,
    created_at timestamptz
)
LANGUAGE sql
STABLE SECURITY DEFINER
SET search_path TO 'public' -- Fix the search path security issue
AS $function$
SELECT 
    wk.id,
    wk.user_id,
    wk.name,
    public.mask_sensitive_data(wk.secret, 'secret') as secret_masked,
    CASE 
        -- Only show full secret if created within last 5 minutes
        WHEN wk.created_at > now() - interval '5 minutes' THEN wk.secret
        ELSE public.mask_sensitive_data(wk.secret, 'secret')
    END as secret,
    wk.active,
    wk.created_at
FROM public.webhook_keys wk
WHERE wk.user_id = auth.uid();
$function$;