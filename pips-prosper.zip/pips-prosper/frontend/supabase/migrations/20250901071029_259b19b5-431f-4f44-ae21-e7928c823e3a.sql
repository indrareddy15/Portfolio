-- Ensure we have admin users set up
-- First, let's check if we need to add admin role to existing user
INSERT INTO public.user_roles (user_id, role, created_by)
VALUES ('e34465d3-7463-4951-94b7-383883833b3356', 'admin', 'e34465d3-7463-4951-94b7-383883833b3356')
ON CONFLICT (user_id, role) DO NOTHING;

-- Add admin policies for all affiliate management tables
CREATE POLICY "Admins can manage all affiliates" ON public.affiliates
FOR ALL USING (has_role(auth.uid(), 'admin'::app_role));

CREATE POLICY "Admins can manage all affiliate applications" ON public.affiliate_applications
FOR ALL USING (has_role(auth.uid(), 'admin'::app_role));

CREATE POLICY "Admins can manage all commissions" ON public.commissions
FOR ALL USING (has_role(auth.uid(), 'admin'::app_role));

CREATE POLICY "Admins can manage all payouts" ON public.payouts
FOR ALL USING (has_role(auth.uid(), 'admin'::app_role));

CREATE POLICY "Admins can view all affiliate clicks" ON public.affiliate_clicks
FOR SELECT USING (has_role(auth.uid(), 'admin'::app_role));

CREATE POLICY "Admins can view all affiliate attributions" ON public.affiliate_attributions
FOR SELECT USING (has_role(auth.uid(), 'admin'::app_role));

CREATE POLICY "Admins can manage all profiles" ON public.profiles
FOR ALL USING (has_role(auth.uid(), 'admin'::app_role));

CREATE POLICY "Admins can view all subscribers" ON public.subscribers
FOR SELECT USING (has_role(auth.uid(), 'admin'::app_role));

-- Create system webhook logs table for admin monitoring
CREATE TABLE IF NOT EXISTS public.webhook_logs (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  webhook_url TEXT NOT NULL,
  method TEXT NOT NULL DEFAULT 'POST',
  payload JSONB,
  response_status INTEGER,
  response_body TEXT,
  error_message TEXT,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

ALTER TABLE public.webhook_logs ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Admins can view webhook logs" ON public.webhook_logs
FOR SELECT USING (has_role(auth.uid(), 'admin'::app_role));

-- Create marketing coupons table
CREATE TABLE IF NOT EXISTS public.coupons (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  code TEXT NOT NULL UNIQUE,
  type TEXT NOT NULL DEFAULT 'percentage', -- 'percentage' or 'fixed'
  value NUMERIC NOT NULL,
  max_uses INTEGER,
  used_count INTEGER DEFAULT 0,
  expires_at TIMESTAMP WITH TIME ZONE,
  active BOOLEAN DEFAULT true,
  created_by UUID,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

ALTER TABLE public.coupons ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Admins can manage coupons" ON public.coupons
FOR ALL USING (has_role(auth.uid(), 'admin'::app_role));

-- Create email templates table
CREATE TABLE IF NOT EXISTS public.email_templates (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  name TEXT NOT NULL,
  subject TEXT NOT NULL,
  content TEXT NOT NULL,
  template_type TEXT NOT NULL, -- 'affiliate_approval', 'welcome', etc.
  active BOOLEAN DEFAULT true,
  created_by UUID,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

ALTER TABLE public.email_templates ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Admins can manage email templates" ON public.email_templates
FOR ALL USING (has_role(auth.uid(), 'admin'::app_role));

-- Update triggers for timestamps
CREATE TRIGGER update_coupons_updated_at
BEFORE UPDATE ON public.coupons
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_email_templates_updated_at
BEFORE UPDATE ON public.email_templates
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();

-- Insert some default email templates
INSERT INTO public.email_templates (name, subject, content, template_type, created_by) VALUES
('Affiliate Application Approved', 'Your Affiliate Application has been Approved!', 
'<h1>Congratulations!</h1><p>Your affiliate application has been approved. You can now start promoting PipsJournal and earning commissions.</p><p>Your affiliate code: {{affiliate_code}}</p>', 
'affiliate_approval', 'e34465d3-7463-4951-94b7-383883833b3356'),
('Welcome Email', 'Welcome to PipsJournal!', 
'<h1>Welcome!</h1><p>Thank you for joining PipsJournal. We''re excited to help you on your trading journey.</p>', 
'welcome', 'e34465d3-7463-4951-94b7-383883833b3356')
ON CONFLICT DO NOTHING;