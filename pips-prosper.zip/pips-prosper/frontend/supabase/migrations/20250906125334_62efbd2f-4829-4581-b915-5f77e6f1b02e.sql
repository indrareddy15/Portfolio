-- Update accounts table to support manual account management
ALTER TABLE public.accounts 
ADD COLUMN IF NOT EXISTS allowed_instruments jsonb DEFAULT '{"forex": true, "crypto": true, "indices": true, "oil": true, "metals": true}'::jsonb;

-- Add unique constraint on nickname per user
ALTER TABLE public.accounts 
ADD CONSTRAINT unique_user_nickname UNIQUE (user_id, nickname);

-- Add check constraint for account_type
ALTER TABLE public.accounts 
ADD CONSTRAINT check_account_type CHECK (account_type IN ('broker', 'prop_firm', 'demo', 'live'));

-- Create instruments table with class-based organization
CREATE TABLE IF NOT EXISTS public.instrument_classes (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL UNIQUE,
  display_name text NOT NULL,
  created_at timestamp with time zone DEFAULT now()
);

-- Insert default instrument classes
INSERT INTO public.instrument_classes (name, display_name) VALUES
  ('forex', 'Forex'),
  ('crypto', 'Crypto'),
  ('indices', 'Indices'),
  ('oil', 'Oil'),
  ('metals', 'Metals')
ON CONFLICT (name) DO NOTHING;

-- Add class column to instruments table
ALTER TABLE public.instruments 
ADD COLUMN IF NOT EXISTS class_name text DEFAULT 'forex';

-- Add foreign key constraint
ALTER TABLE public.instruments 
ADD CONSTRAINT fk_instruments_class 
FOREIGN KEY (class_name) REFERENCES public.instrument_classes(name);

-- Update existing instruments with proper classes
UPDATE public.instruments 
SET class_name = CASE 
  WHEN symbol IN ('XAUUSD', 'XAGUSD') THEN 'metals'
  WHEN symbol IN ('WTI', 'BRENT') THEN 'oil'
  WHEN symbol IN ('US30', 'NAS100', 'SPX500', 'DAX40', 'FTSE100') THEN 'indices'
  WHEN symbol IN ('BTCUSD', 'ETHUSD', 'SOLUSD') THEN 'crypto'
  ELSE 'forex'
END;

-- Enable RLS on instrument_classes
ALTER TABLE public.instrument_classes ENABLE ROW LEVEL SECURITY;

-- Create policy for instrument classes
CREATE POLICY "Anyone can view instrument classes" 
ON public.instrument_classes 
FOR SELECT 
USING (true);

-- Add some default instruments if they don't exist
INSERT INTO public.instruments (symbol, description, class_name, base_ccy, quote_ccy) VALUES
  ('EURUSD', 'Euro vs US Dollar', 'forex', 'EUR', 'USD'),
  ('GBPUSD', 'British Pound vs US Dollar', 'forex', 'GBP', 'USD'),
  ('USDJPY', 'US Dollar vs Japanese Yen', 'forex', 'USD', 'JPY'),
  ('USDCHF', 'US Dollar vs Swiss Franc', 'forex', 'USD', 'CHF'),
  ('USDCAD', 'US Dollar vs Canadian Dollar', 'forex', 'USD', 'CAD'),
  ('AUDUSD', 'Australian Dollar vs US Dollar', 'forex', 'AUD', 'USD'),
  ('NZDUSD', 'New Zealand Dollar vs US Dollar', 'forex', 'NZD', 'USD'),
  ('EURJPY', 'Euro vs Japanese Yen', 'forex', 'EUR', 'JPY'),
  ('BTCUSD', 'Bitcoin vs US Dollar', 'crypto', 'BTC', 'USD'),
  ('ETHUSD', 'Ethereum vs US Dollar', 'crypto', 'ETH', 'USD'),
  ('SOLUSD', 'Solana vs US Dollar', 'crypto', 'SOL', 'USD'),
  ('US30', 'Dow Jones Industrial Average', 'indices', 'US30', 'USD'),
  ('NAS100', 'NASDAQ 100', 'indices', 'NAS100', 'USD'),
  ('SPX500', 'S&P 500', 'indices', 'SPX500', 'USD'),
  ('DAX40', 'DAX 40', 'indices', 'DAX40', 'EUR'),
  ('FTSE100', 'FTSE 100', 'indices', 'FTSE100', 'GBP'),
  ('WTI', 'West Texas Intermediate Oil', 'oil', 'WTI', 'USD'),
  ('BRENT', 'Brent Crude Oil', 'oil', 'BRENT', 'USD'),
  ('XAUUSD', 'Gold vs US Dollar', 'metals', 'XAU', 'USD'),
  ('XAGUSD', 'Silver vs US Dollar', 'metals', 'XAG', 'USD')
ON CONFLICT (symbol) DO NOTHING;