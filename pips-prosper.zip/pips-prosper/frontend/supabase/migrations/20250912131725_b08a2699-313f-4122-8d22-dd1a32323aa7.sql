-- Enable real-time functionality for strategies and trades tables

-- Set replica identity to FULL for complete row data during updates
ALTER TABLE public.strategies REPLICA IDENTITY FULL;
ALTER TABLE public.trades REPLICA IDENTITY FULL;

-- Add tables to realtime publication to enable real-time subscriptions
ALTER PUBLICATION supabase_realtime ADD TABLE public.strategies;
ALTER PUBLICATION supabase_realtime ADD TABLE public.trades;