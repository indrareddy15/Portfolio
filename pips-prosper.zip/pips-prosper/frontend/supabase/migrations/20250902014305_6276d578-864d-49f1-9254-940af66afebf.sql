-- Enable the net extension for HTTP requests
CREATE EXTENSION IF NOT EXISTS http WITH SCHEMA extensions;

-- Update the function to use the correct extension path
CREATE OR REPLACE FUNCTION public.notify_new_affiliate()
RETURNS TRIGGER AS $$
DECLARE
    webhook_url TEXT;
    payload JSON;
    response RECORD;
BEGIN
    -- Set the webhook URL to our edge function
    webhook_url := 'https://pwpxzlcpdbqjckvmkwlw.supabase.co/functions/v1/send-affiliate-welcome';
    
    -- Prepare the payload
    payload := json_build_object(
        'type', 'INSERT',
        'table', 'affiliates',
        'record', row_to_json(NEW),
        'old_record', null
    );
    
    -- Make async HTTP request to the webhook (this is a fire-and-forget call)
    -- Using extensions.http_post instead of net.http_post
    BEGIN
        SELECT * FROM extensions.http_post(
            url := webhook_url,
            body := payload::text,
            headers := jsonb_build_object(
                'Content-Type', 'application/json',
                'Authorization', 'Bearer ' || current_setting('app.settings.service_role_key', true)
            )
        ) INTO response;
    EXCEPTION
        WHEN OTHERS THEN
            -- If HTTP request fails, log the error but don't prevent the affiliate creation
            RAISE WARNING 'Failed to send webhook: %', SQLERRM;
    END;
    
    RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = public;