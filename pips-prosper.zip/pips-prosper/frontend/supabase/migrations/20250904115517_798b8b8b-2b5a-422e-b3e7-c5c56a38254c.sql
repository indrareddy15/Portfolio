-- Create pricing management tables for PipTrackr.com (Fixed)

-- Create enum for billing cycles
CREATE TYPE billing_cycle AS ENUM ('monthly', 'yearly');

-- Create enum for subscription status
CREATE TYPE subscription_status AS ENUM ('active', 'past_due', 'canceled', 'trialing', 'incomplete', 'unpaid');

-- Create enum for invoice status
CREATE TYPE invoice_status AS ENUM ('paid', 'open', 'void', 'uncollectible', 'draft');

-- Create plans table
CREATE TABLE public.plans (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name TEXT NOT NULL,
    description TEXT,
    price_amount DECIMAL(10,2) NOT NULL DEFAULT 0,
    price_currency TEXT NOT NULL DEFAULT 'USD',
    billing_cycle billing_cycle NOT NULL DEFAULT 'monthly',
    stripe_product_id TEXT,
    stripe_price_id TEXT,
    is_active BOOLEAN NOT NULL DEFAULT true,
    sort_order INTEGER NOT NULL DEFAULT 0,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
    updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create plan_features table
CREATE TABLE public.plan_features (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    plan_id UUID NOT NULL REFERENCES public.plans(id) ON DELETE CASCADE,
    label TEXT NOT NULL,
    is_included BOOLEAN NOT NULL DEFAULT true,
    sort_order INTEGER NOT NULL DEFAULT 0,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create subscriptions table (extend existing subscribers or create new)
CREATE TABLE public.user_subscriptions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL,
    plan_id UUID REFERENCES public.plans(id),
    status subscription_status NOT NULL DEFAULT 'incomplete',
    stripe_customer_id TEXT,
    stripe_subscription_id TEXT UNIQUE,
    current_period_start TIMESTAMP WITH TIME ZONE,
    current_period_end TIMESTAMP WITH TIME ZONE,
    cancel_at_period_end BOOLEAN NOT NULL DEFAULT false,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
    updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create invoices table
CREATE TABLE public.user_invoices (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL,
    stripe_invoice_id TEXT UNIQUE NOT NULL,
    amount_due DECIMAL(10,2) NOT NULL,
    currency TEXT NOT NULL DEFAULT 'USD',
    status invoice_status NOT NULL,
    hosted_invoice_url TEXT,
    invoice_pdf_url TEXT,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
    updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS on all tables
ALTER TABLE public.plans ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.plan_features ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.user_subscriptions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.user_invoices ENABLE ROW LEVEL SECURITY;

-- RLS Policies for plans (public can read active plans, admins can manage all)
CREATE POLICY "Anyone can view active plans" ON public.plans
    FOR SELECT USING (is_active = true OR has_role(auth.uid(), 'admin'::app_role));

CREATE POLICY "Admins can manage plans" ON public.plans
    FOR ALL USING (has_role(auth.uid(), 'admin'::app_role));

-- RLS Policies for plan_features (public can read features of active plans)
CREATE POLICY "Anyone can view plan features" ON public.plan_features
    FOR SELECT USING (
        plan_id IN (SELECT id FROM public.plans WHERE is_active = true) 
        OR has_role(auth.uid(), 'admin'::app_role)
    );

CREATE POLICY "Admins can manage plan features" ON public.plan_features
    FOR ALL USING (has_role(auth.uid(), 'admin'::app_role));

-- RLS Policies for user_subscriptions (users can view their own, admins can view all)
CREATE POLICY "Users can view own subscriptions" ON public.user_subscriptions
    FOR SELECT USING (user_id = auth.uid() OR has_role(auth.uid(), 'admin'::app_role));

CREATE POLICY "Service role can manage subscriptions" ON public.user_subscriptions
    FOR ALL USING ((auth.jwt() ->> 'role'::text) = 'service_role'::text);

-- RLS Policies for user_invoices (users can view their own, admins can view all)
CREATE POLICY "Users can view own invoices" ON public.user_invoices
    FOR SELECT USING (user_id = auth.uid() OR has_role(auth.uid(), 'admin'::app_role));

CREATE POLICY "Service role can manage invoices" ON public.user_invoices
    FOR ALL USING ((auth.jwt() ->> 'role'::text) = 'service_role'::text);

-- Create indexes for performance
CREATE INDEX idx_plans_active_sort ON public.plans(is_active, sort_order);
CREATE INDEX idx_plan_features_plan_id ON public.plan_features(plan_id, sort_order);
CREATE INDEX idx_user_subscriptions_user_id ON public.user_subscriptions(user_id);
CREATE INDEX idx_user_subscriptions_stripe_id ON public.user_subscriptions(stripe_subscription_id);
CREATE INDEX idx_user_invoices_user_id ON public.user_invoices(user_id);
CREATE INDEX idx_user_invoices_stripe_id ON public.user_invoices(stripe_invoice_id);

-- Create triggers for updated_at timestamps
CREATE TRIGGER update_plans_updated_at
    BEFORE UPDATE ON public.plans
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_user_subscriptions_updated_at
    BEFORE UPDATE ON public.user_subscriptions
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_user_invoices_updated_at
    BEFORE UPDATE ON public.user_invoices
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();