-- Enable RLS and create policies for new tables

-- Enable RLS on new tables
ALTER TABLE public.trade_legs ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.equity_snapshots ENABLE ROW LEVEL SECURITY; 
ALTER TABLE public.metrics_summary ENABLE ROW LEVEL SECURITY;

-- Create RLS policies for trade_legs
CREATE POLICY "Users can manage their own trade legs" ON public.trade_legs
  FOR ALL USING (
    trade_id IN (SELECT id FROM public.trades WHERE user_id = auth.uid())
  )
  WITH CHECK (
    trade_id IN (SELECT id FROM public.trades WHERE user_id = auth.uid())
  );

-- Create RLS policies for equity_snapshots
CREATE POLICY "Users can manage their own equity snapshots" ON public.equity_snapshots
  FOR ALL USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

-- Create RLS policies for metrics_summary
CREATE POLICY "Users can manage their own metrics summary" ON public.metrics_summary
  FOR ALL USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);