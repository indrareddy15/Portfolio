-- Create instruments table for Forex configuration
CREATE TABLE public.instruments (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  symbol TEXT NOT NULL UNIQUE,
  class TEXT NOT NULL DEFAULT 'forex',
  pricing_mode TEXT NOT NULL DEFAULT 'forex',
  base_ccy TEXT NOT NULL,
  quote_ccy TEXT NOT NULL,
  lot_units NUMERIC NOT NULL DEFAULT 100000,
  pip_size NUMERIC NOT NULL DEFAULT 0.0001,
  price_precision INTEGER NOT NULL DEFAULT 5,
  pip_precision INTEGER NOT NULL DEFAULT 1,
  description TEXT,
  is_active BOOLEAN NOT NULL DEFAULT true,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Create FX rates table for currency conversion
CREATE TABLE public.fx_rates (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  from_currency TEXT NOT NULL,
  to_currency TEXT NOT NULL,
  rate NUMERIC NOT NULL,
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  created_by UUID REFERENCES auth.users(id),
  is_active BOOLEAN NOT NULL DEFAULT true,
  UNIQUE(from_currency, to_currency)
);

-- Add new columns to trades table for enhanced Forex support
ALTER TABLE public.trades ADD COLUMN IF NOT EXISTS raw_pnl NUMERIC;
ALTER TABLE public.trades ADD COLUMN IF NOT EXISTS converted_pnl NUMERIC;
ALTER TABLE public.trades ADD COLUMN IF NOT EXISTS fx_rate_used NUMERIC;
ALTER TABLE public.trades ADD COLUMN IF NOT EXISTS account_currency TEXT DEFAULT 'USD';
ALTER TABLE public.trades ADD COLUMN IF NOT EXISTS quote_currency TEXT;
ALTER TABLE public.trades ADD COLUMN IF NOT EXISTS pips NUMERIC;
ALTER TABLE public.trades ADD COLUMN IF NOT EXISTS pip_value NUMERIC;
ALTER TABLE public.trades ADD COLUMN IF NOT EXISTS commission NUMERIC DEFAULT 0;
ALTER TABLE public.trades ADD COLUMN IF NOT EXISTS auto_configured BOOLEAN DEFAULT false;

-- Enable RLS on new tables
ALTER TABLE public.instruments ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.fx_rates ENABLE ROW LEVEL SECURITY;

-- RLS policies for instruments
CREATE POLICY "Anyone can view active instruments" ON public.instruments
  FOR SELECT USING (is_active = true);

CREATE POLICY "Admins can manage instruments" ON public.instruments
  FOR ALL USING (has_role(auth.uid(), 'admin'::app_role));

-- RLS policies for fx_rates
CREATE POLICY "Anyone can view active fx rates" ON public.fx_rates
  FOR SELECT USING (is_active = true);

CREATE POLICY "Admins can manage fx rates" ON public.fx_rates
  FOR ALL USING (has_role(auth.uid(), 'admin'::app_role));

-- Create indexes for performance
CREATE INDEX idx_instruments_symbol ON public.instruments(symbol);
CREATE INDEX idx_instruments_class ON public.instruments(class);
CREATE INDEX idx_fx_rates_currencies ON public.fx_rates(from_currency, to_currency);
CREATE INDEX idx_trades_instrument ON public.trades(instrument);

-- Create trigger for updating timestamps
CREATE TRIGGER update_instruments_updated_at
  BEFORE UPDATE ON public.instruments
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_fx_rates_updated_at
  BEFORE UPDATE ON public.fx_rates
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at_column();

-- Insert default FX rates (admin can update these)
INSERT INTO public.fx_rates (from_currency, to_currency, rate, created_by) VALUES
('USD', 'EUR', 0.85, NULL),
('EUR', 'USD', 1.18, NULL),
('USD', 'GBP', 0.73, NULL),
('GBP', 'USD', 1.37, NULL),
('USD', 'JPY', 150.00, NULL),
('JPY', 'USD', 0.0067, NULL),
('USD', 'AUD', 1.52, NULL),
('AUD', 'USD', 0.66, NULL),
('USD', 'CAD', 1.35, NULL),
('CAD', 'USD', 0.74, NULL),
('USD', 'CHF', 0.88, NULL),
('CHF', 'USD', 1.14, NULL),
('USD', 'NZD', 1.62, NULL),
('NZD', 'USD', 0.62, NULL),
-- Cross rates
('EUR', 'GBP', 0.86, NULL),
('GBP', 'EUR', 1.16, NULL),
('EUR', 'JPY', 176.47, NULL),
('JPY', 'EUR', 0.0057, NULL),
('GBP', 'JPY', 205.48, NULL),
('JPY', 'GBP', 0.0049, NULL),
('AUD', 'CAD', 0.89, NULL),
('CAD', 'AUD', 1.12, NULL);

-- Insert sample Forex instruments (major pairs)
INSERT INTO public.instruments (symbol, base_ccy, quote_ccy, lot_units, pip_size, price_precision, pip_precision, description) VALUES
('EURUSD', 'EUR', 'USD', 100000, 0.0001, 5, 1, 'Euro vs US Dollar'),
('GBPUSD', 'GBP', 'USD', 100000, 0.0001, 5, 1, 'British Pound vs US Dollar'),
('USDJPY', 'USD', 'JPY', 100000, 0.01, 3, 2, 'US Dollar vs Japanese Yen'),
('USDCHF', 'USD', 'CHF', 100000, 0.0001, 5, 1, 'US Dollar vs Swiss Franc'),
('AUDUSD', 'AUD', 'USD', 100000, 0.0001, 5, 1, 'Australian Dollar vs US Dollar'),
('USDCAD', 'USD', 'CAD', 100000, 0.0001, 5, 1, 'US Dollar vs Canadian Dollar'),
('NZDUSD', 'NZD', 'USD', 100000, 0.0001, 5, 1, 'New Zealand Dollar vs US Dollar'),
('EURGBP', 'EUR', 'GBP', 100000, 0.0001, 5, 1, 'Euro vs British Pound'),
('EURJPY', 'EUR', 'JPY', 100000, 0.01, 3, 2, 'Euro vs Japanese Yen'),
('GBPJPY', 'GBP', 'JPY', 100000, 0.01, 3, 2, 'British Pound vs Japanese Yen'),
('AUDCAD', 'AUD', 'CAD', 100000, 0.0001, 5, 1, 'Australian Dollar vs Canadian Dollar'),
('EURCHF', 'EUR', 'CHF', 100000, 0.0001, 5, 1, 'Euro vs Swiss Franc'),
('GBPCHF', 'GBP', 'CHF', 100000, 0.0001, 5, 1, 'British Pound vs Swiss Franc'),
('CADCHF', 'CAD', 'CHF', 100000, 0.0001, 5, 1, 'Canadian Dollar vs Swiss Franc'),
('AUDCHF', 'AUD', 'CHF', 100000, 0.0001, 5, 1, 'Australian Dollar vs Swiss Franc');