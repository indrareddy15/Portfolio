-- Fix webhook_keys security by masking secrets

-- Update mask_sensitive_data function to handle secret keys
CREATE OR REPLACE FUNCTION public.mask_sensitive_data(data text, mask_type text DEFAULT 'email'::text)
RETURNS text
LANGUAGE plpgsql
STABLE SECURITY DEFINER
SET search_path TO 'public'
AS $function$
BEGIN
    CASE mask_type
        WHEN 'email' THEN
            RETURN CONCAT(LEFT(data, 2), '***@', SPLIT_PART(data, '@', 2));
        WHEN 'phone' THEN
            RETURN CONCAT('***-***-', RIGHT(data, 4));
        WHEN 'name' THEN
            RETURN CONCAT(LEFT(data, 1), REPEAT('*', LENGTH(data) - 1));
        WHEN 'secret' THEN
            -- Show first 4 and last 4 characters, mask the middle
            RETURN CONCAT(LEFT(data, 4), REPEAT('*', GREATEST(0, LENGTH(data) - 8)), RIGHT(data, 4));
        ELSE
            RETURN '***';
    END CASE;
END;
$function$;

-- Create a function to get webhook keys with masked secrets
CREATE OR REPLACE FUNCTION public.get_webhook_keys_safe()
RETURNS TABLE (
    id uuid,
    user_id uuid,
    name text,
    secret_masked text,
    secret text,
    active boolean,
    created_at timestamptz
)
LANGUAGE sql
STABLE SECURITY DEFINER
SET search_path TO 'public'
AS $function$
SELECT 
    wk.id,
    wk.user_id,
    wk.name,
    public.mask_sensitive_data(wk.secret, 'secret') as secret_masked,
    CASE 
        -- Only show full secret if created within last 5 minutes
        WHEN wk.created_at > now() - interval '5 minutes' THEN wk.secret
        ELSE public.mask_sensitive_data(wk.secret, 'secret')
    END as secret,
    wk.active,
    wk.created_at
FROM public.webhook_keys wk
WHERE wk.user_id = auth.uid();
$function$;