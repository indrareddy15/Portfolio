-- Create accounts table for multi-account management
CREATE TABLE IF NOT EXISTS public.accounts (
    id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
    user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
    account_type text NOT NULL CHECK (account_type IN ('broker', 'prop_firm')),
    broker_name text NOT NULL,
    nickname text NOT NULL,
    account_size numeric NOT NULL DEFAULT 0,
    currency text NOT NULL DEFAULT 'USD' CHECK (currency IN ('USD', 'EUR', 'GBP', 'JPY', 'AUD', 'CAD', 'CHF', 'NZD', 'INR')),
    risk_preference numeric NOT NULL DEFAULT 1.0 CHECK (risk_preference >= 0.1 AND risk_preference <= 10.0),
    balance numeric DEFAULT 0,
    equity numeric DEFAULT 0,
    free_margin numeric DEFAULT 0,
    margin numeric DEFAULT 0,
    is_active boolean DEFAULT true,
    created_at timestamp with time zone NOT NULL DEFAULT now(),
    updated_at timestamp with time zone NOT NULL DEFAULT now(),
    UNIQUE(user_id, nickname)
);

-- Enable RLS on accounts table
ALTER TABLE public.accounts ENABLE ROW LEVEL SECURITY;

-- Create policies for accounts
CREATE POLICY "Users can manage their own accounts" 
ON public.accounts 
FOR ALL 
USING (auth.uid() = user_id)
WITH CHECK (auth.uid() = user_id);

-- Add account_id to existing trades table
ALTER TABLE public.trades ADD COLUMN IF NOT EXISTS account_id uuid REFERENCES public.accounts(id) ON DELETE SET NULL;

-- Create account goals table
CREATE TABLE IF NOT EXISTS public.account_goals (
    id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
    account_id uuid NOT NULL REFERENCES public.accounts(id) ON DELETE CASCADE,
    user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
    goal_type text NOT NULL CHECK (goal_type IN ('profit_target', 'win_rate', 'max_drawdown', 'risk_per_trade')),
    target_value numeric NOT NULL,
    current_value numeric DEFAULT 0,
    target_date date,
    is_achieved boolean DEFAULT false,
    created_at timestamp with time zone NOT NULL DEFAULT now(),
    updated_at timestamp with time zone NOT NULL DEFAULT now()
);

-- Enable RLS on account_goals table
ALTER TABLE public.account_goals ENABLE ROW LEVEL SECURITY;

-- Create policies for account_goals
CREATE POLICY "Users can manage their own account goals" 
ON public.account_goals 
FOR ALL 
USING (auth.uid() = user_id)
WITH CHECK (auth.uid() = user_id);

-- Add triggers for updated_at
CREATE TRIGGER update_accounts_updated_at
    BEFORE UPDATE ON public.accounts
    FOR EACH ROW
    EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_account_goals_updated_at
    BEFORE UPDATE ON public.account_goals
    FOR EACH ROW
    EXECUTE FUNCTION public.update_updated_at_column();