-- Create blog database schema

-- Blog authors table
CREATE TABLE public.blog_authors (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  name TEXT NOT NULL,
  slug TEXT NOT NULL UNIQUE,
  avatar_url TEXT,
  bio TEXT,
  social_json JSONB DEFAULT '{}'::jsonb,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Blog categories table
CREATE TABLE public.blog_categories (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  name TEXT NOT NULL,
  slug TEXT NOT NULL UNIQUE,
  description TEXT,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Blog tags table
CREATE TABLE public.blog_tags (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  name TEXT NOT NULL,
  slug TEXT NOT NULL UNIQUE,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Blog posts table
CREATE TABLE public.blog_posts (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  title TEXT NOT NULL,
  slug TEXT NOT NULL UNIQUE,
  status TEXT NOT NULL DEFAULT 'draft' CHECK (status IN ('draft', 'published', 'scheduled')),
  publish_at TIMESTAMP WITH TIME ZONE,
  excerpt TEXT,
  cover_url TEXT,
  body_md TEXT,
  canonical_url TEXT,
  meta_title TEXT,
  meta_description TEXT,
  og_title TEXT,
  og_description TEXT,
  og_image_url TEXT,
  category_id UUID REFERENCES blog_categories(id),
  author_id UUID REFERENCES blog_authors(id),
  featured BOOLEAN DEFAULT false,
  reading_time INTEGER DEFAULT 0,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Blog post tags junction table
CREATE TABLE public.blog_post_tags (
  post_id UUID NOT NULL REFERENCES blog_posts(id) ON DELETE CASCADE,
  tag_id UUID NOT NULL REFERENCES blog_tags(id) ON DELETE CASCADE,
  PRIMARY KEY (post_id, tag_id)
);

-- Blog media table
CREATE TABLE public.blog_media (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  url TEXT NOT NULL,
  alt TEXT,
  width INTEGER,
  height INTEGER,
  file_size INTEGER,
  mime_type TEXT,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Blog redirects table
CREATE TABLE public.blog_redirects (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  from_path TEXT NOT NULL UNIQUE,
  to_url TEXT NOT NULL,
  status_code INTEGER DEFAULT 301 CHECK (status_code IN (301, 302)),
  note TEXT,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Blog post versions table
CREATE TABLE public.blog_post_versions (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  post_id UUID NOT NULL REFERENCES blog_posts(id) ON DELETE CASCADE,
  body_md TEXT,
  meta_json JSONB DEFAULT '{}'::jsonb,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Blog settings table
CREATE TABLE public.blog_settings (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  key TEXT NOT NULL UNIQUE,
  value JSONB DEFAULT '{}'::jsonb,
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create indexes for performance
CREATE INDEX idx_blog_posts_status ON blog_posts(status);
CREATE INDEX idx_blog_posts_publish_at ON blog_posts(publish_at);
CREATE INDEX idx_blog_posts_category ON blog_posts(category_id);
CREATE INDEX idx_blog_posts_author ON blog_posts(author_id);
CREATE INDEX idx_blog_posts_featured ON blog_posts(featured);
CREATE INDEX idx_blog_posts_slug ON blog_posts(slug);
CREATE INDEX idx_blog_categories_slug ON blog_categories(slug);
CREATE INDEX idx_blog_tags_slug ON blog_tags(slug);
CREATE INDEX idx_blog_authors_slug ON blog_authors(slug);

-- Enable Row Level Security
ALTER TABLE blog_posts ENABLE ROW LEVEL SECURITY;
ALTER TABLE blog_categories ENABLE ROW LEVEL SECURITY;
ALTER TABLE blog_tags ENABLE ROW LEVEL SECURITY;
ALTER TABLE blog_authors ENABLE ROW LEVEL SECURITY;
ALTER TABLE blog_post_tags ENABLE ROW LEVEL SECURITY;
ALTER TABLE blog_media ENABLE ROW LEVEL SECURITY;
ALTER TABLE blog_redirects ENABLE ROW LEVEL SECURITY;
ALTER TABLE blog_post_versions ENABLE ROW LEVEL SECURITY;
ALTER TABLE blog_settings ENABLE ROW LEVEL SECURITY;

-- Create RLS policies for public read access to published content
CREATE POLICY "Anyone can view published blog posts" 
ON blog_posts FOR SELECT 
USING (status = 'published' AND (publish_at IS NULL OR publish_at <= now()));

CREATE POLICY "Anyone can view blog categories" 
ON blog_categories FOR SELECT 
USING (true);

CREATE POLICY "Anyone can view blog tags" 
ON blog_tags FOR SELECT 
USING (true);

CREATE POLICY "Anyone can view blog authors" 
ON blog_authors FOR SELECT 
USING (true);

CREATE POLICY "Anyone can view blog post tags" 
ON blog_post_tags FOR SELECT 
USING (EXISTS (
  SELECT 1 FROM blog_posts 
  WHERE id = post_id 
  AND status = 'published' 
  AND (publish_at IS NULL OR publish_at <= now())
));

CREATE POLICY "Anyone can view blog media" 
ON blog_media FOR SELECT 
USING (true);

-- Admin policies
CREATE POLICY "Admins can manage blog posts" 
ON blog_posts FOR ALL 
USING (has_role(auth.uid(), 'admin'::app_role))
WITH CHECK (has_role(auth.uid(), 'admin'::app_role));

CREATE POLICY "Admins can manage blog categories" 
ON blog_categories FOR ALL 
USING (has_role(auth.uid(), 'admin'::app_role))
WITH CHECK (has_role(auth.uid(), 'admin'::app_role));

CREATE POLICY "Admins can manage blog tags" 
ON blog_tags FOR ALL 
USING (has_role(auth.uid(), 'admin'::app_role))
WITH CHECK (has_role(auth.uid(), 'admin'::app_role));

CREATE POLICY "Admins can manage blog authors" 
ON blog_authors FOR ALL 
USING (has_role(auth.uid(), 'admin'::app_role))
WITH CHECK (has_role(auth.uid(), 'admin'::app_role));

CREATE POLICY "Admins can manage blog post tags" 
ON blog_post_tags FOR ALL 
USING (has_role(auth.uid(), 'admin'::app_role))
WITH CHECK (has_role(auth.uid(), 'admin'::app_role));

CREATE POLICY "Admins can manage blog media" 
ON blog_media FOR ALL 
USING (has_role(auth.uid(), 'admin'::app_role))
WITH CHECK (has_role(auth.uid(), 'admin'::app_role));

CREATE POLICY "Admins can manage blog redirects" 
ON blog_redirects FOR ALL 
USING (has_role(auth.uid(), 'admin'::app_role))
WITH CHECK (has_role(auth.uid(), 'admin'::app_role));

CREATE POLICY "Admins can manage blog post versions" 
ON blog_post_versions FOR ALL 
USING (has_role(auth.uid(), 'admin'::app_role))
WITH CHECK (has_role(auth.uid(), 'admin'::app_role));

CREATE POLICY "Admins can manage blog settings" 
ON blog_settings FOR ALL 
USING (has_role(auth.uid(), 'admin'::app_role))
WITH CHECK (has_role(auth.uid(), 'admin'::app_role));

-- Create storage bucket for blog media
INSERT INTO storage.buckets (id, name, public) 
VALUES ('blog-media', 'blog-media', true);

-- Create storage policies for blog media
CREATE POLICY "Anyone can view blog media files" 
ON storage.objects FOR SELECT 
USING (bucket_id = 'blog-media');

CREATE POLICY "Admins can upload blog media files" 
ON storage.objects FOR INSERT 
WITH CHECK (
  bucket_id = 'blog-media' 
  AND has_role(auth.uid(), 'admin'::app_role)
);

CREATE POLICY "Admins can update blog media files" 
ON storage.objects FOR UPDATE 
USING (
  bucket_id = 'blog-media' 
  AND has_role(auth.uid(), 'admin'::app_role)
);

CREATE POLICY "Admins can delete blog media files" 
ON storage.objects FOR DELETE 
USING (
  bucket_id = 'blog-media' 
  AND has_role(auth.uid(), 'admin'::app_role)
);

-- Create triggers for updated_at
CREATE TRIGGER update_blog_authors_updated_at
  BEFORE UPDATE ON blog_authors
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_blog_categories_updated_at
  BEFORE UPDATE ON blog_categories
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_blog_posts_updated_at
  BEFORE UPDATE ON blog_posts
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_blog_settings_updated_at
  BEFORE UPDATE ON blog_settings
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

-- Insert default blog settings
INSERT INTO blog_settings (key, value) VALUES 
('general', '{
  "basePath": "/blog",
  "postsPerPage": 12,
  "defaultOgImage": "",
  "siteTitle": "PipTrackr Blog",
  "siteDescription": "Trading insights, tips and strategies from PipTrackr"
}'),
('social', '{
  "twitter": "",
  "facebook": "",
  "linkedin": "",
  "instagram": ""
}'),
('seo', '{
  "enableSitemap": true,
  "enableFeeds": true,
  "enableStructuredData": true
}');

-- Create default author (admin)
INSERT INTO blog_authors (name, slug, bio) VALUES 
('PipTrackr Team', 'piptrackr-team', 'The editorial team at PipTrackr, dedicated to providing valuable trading insights and education.');

-- Create default categories
INSERT INTO blog_categories (name, slug, description) VALUES 
('Trading Tips', 'trading-tips', 'Practical advice and strategies for better trading'),
('Market Analysis', 'market-analysis', 'In-depth analysis of market trends and movements'),
('Education', 'education', 'Learning resources for traders of all levels'),
('Platform Updates', 'platform-updates', 'News and updates about PipTrackr features');