-- Fix affiliate_applications RLS policies to prevent unauthorized access
-- The issue is that the service role policy applies to 'public' role which includes anonymous users

-- Drop existing policies
DROP POLICY IF EXISTS "Admins can manage all affiliate applications" ON public.affiliate_applications;
DROP POLICY IF EXISTS "Service role full access to applications" ON public.affiliate_applications;
DROP POLICY IF EXISTS "Users can create their own applications" ON public.affiliate_applications;
DROP POLICY IF EXISTS "Users can view their own applications" ON public.affiliate_applications;

-- Create restrictive policies that are more secure
-- 1. Users can only view their own applications
CREATE POLICY "Users can view own applications only" 
ON public.affiliate_applications 
FOR SELECT 
TO authenticated
USING (auth.uid() = user_id);

-- 2. Users can only create applications for themselves
CREATE POLICY "Users can create own applications only" 
ON public.affiliate_applications 
FOR INSERT 
TO authenticated
WITH CHECK (auth.uid() = user_id);

-- 3. Users can update their own applications (but only certain fields)
CREATE POLICY "Users can update own applications" 
ON public.affiliate_applications 
FOR UPDATE 
TO authenticated
USING (auth.uid() = user_id)
WITH CHECK (auth.uid() = user_id);

-- 4. Only admins can view all applications
CREATE POLICY "Admins can view all applications" 
ON public.affiliate_applications 
FOR SELECT 
TO authenticated
USING (has_role(auth.uid(), 'admin'::app_role));

-- 5. Only admins can manage all applications (update/delete)
CREATE POLICY "Admins can manage all applications" 
ON public.affiliate_applications 
FOR ALL 
TO authenticated
USING (has_role(auth.uid(), 'admin'::app_role))
WITH CHECK (has_role(auth.uid(), 'admin'::app_role));

-- 6. Service role access (but restricted to service_role only, not public)
CREATE POLICY "Service role full access" 
ON public.affiliate_applications 
FOR ALL 
TO service_role
USING (true)
WITH CHECK (true);

-- 7. Prevent all access to anonymous users (default deny)
CREATE POLICY "Deny anonymous access" 
ON public.affiliate_applications 
FOR ALL 
TO anon
USING (false)
WITH CHECK (false);