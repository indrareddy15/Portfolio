-- Enable real-time for affiliate_applications table
ALTER TABLE public.affiliate_applications REPLICA IDENTITY FULL;

-- Add the table to the realtime publication
ALTER PUBLICATION supabase_realtime ADD TABLE public.affiliate_applications;