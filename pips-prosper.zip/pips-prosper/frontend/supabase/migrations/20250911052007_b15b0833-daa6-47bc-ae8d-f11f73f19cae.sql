-- Create notices table for admin-managed announcements
CREATE TABLE public.notices (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  title text NOT NULL,
  message text NOT NULL,
  link_url text,
  link_text text DEFAULT 'Learn More',
  type text NOT NULL DEFAULT 'info',
  priority integer NOT NULL DEFAULT 1,
  is_active boolean NOT NULL DEFAULT true,
  show_on_website boolean NOT NULL DEFAULT true,
  show_on_dashboard boolean NOT NULL DEFAULT true,
  expires_at timestamp with time zone,
  created_by uuid,
  created_at timestamp with time zone NOT NULL DEFAULT now(),
  updated_at timestamp with time zone NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.notices ENABLE ROW LEVEL SECURITY;

-- Create policies
CREATE POLICY "Admins can manage all notices" 
ON public.notices 
FOR ALL 
USING (has_role(auth.uid(), 'admin'::app_role))
WITH CHECK (has_role(auth.uid(), 'admin'::app_role));

CREATE POLICY "Everyone can view active notices" 
ON public.notices 
FOR SELECT 
USING (is_active = true AND (expires_at IS NULL OR expires_at > now()));

-- Create trigger for updated_at
CREATE TRIGGER update_notices_updated_at
  BEFORE UPDATE ON public.notices
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at_column();

-- Add to realtime
ALTER TABLE public.notices REPLICA IDENTITY FULL;

-- Insert sample notice
INSERT INTO public.notices (title, message, type, link_url, link_text, priority, show_on_website, show_on_dashboard)
VALUES (
  'Welcome to PipTrackr.com!',
  'Start your trading journey with our comprehensive trading journal platform.',
  'success',
  '/pricing',
  'Get Started',
  1,
  true,
  true
);