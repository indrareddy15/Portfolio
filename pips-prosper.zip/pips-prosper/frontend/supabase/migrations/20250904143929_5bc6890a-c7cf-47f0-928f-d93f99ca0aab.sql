-- Create new tables for real-time metrics system

-- Create trade_legs table for partial closes
CREATE TABLE IF NOT EXISTS public.trade_legs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  trade_id uuid NOT NULL REFERENCES public.trades(id) ON DELETE CASCADE,
  leg_type leg_type NOT NULL,
  price numeric NOT NULL,
  qty_or_lots numeric NOT NULL,
  time timestamptz NOT NULL DEFAULT now(),
  created_at timestamptz NOT NULL DEFAULT now()
);

-- Create equity_snapshots table
CREATE TABLE IF NOT EXISTS public.equity_snapshots (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL,
  time_utc timestamptz NOT NULL DEFAULT now(),
  equity_account numeric NOT NULL,
  account_id uuid REFERENCES public.accounts(id),
  created_at timestamptz NOT NULL DEFAULT now()
);

-- Create metrics_summary table (denormalized)
CREATE TABLE IF NOT EXISTS public.metrics_summary (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL,
  scope text NOT NULL, -- 'all_time', 'monthly', 'weekly', 'custom_hash'
  start_ts timestamptz,
  end_ts timestamptz,
  total_pnl numeric DEFAULT 0,
  net_pnl numeric DEFAULT 0,
  win_rate numeric DEFAULT 0,
  avg_rr numeric DEFAULT 0,
  profit_factor numeric DEFAULT 0,
  expectancy numeric DEFAULT 0,
  max_dd numeric DEFAULT 0,
  sharpe numeric DEFAULT 0,
  longest_win integer DEFAULT 0,
  longest_loss integer DEFAULT 0,
  trade_count integer DEFAULT 0,
  updated_at timestamptz NOT NULL DEFAULT now(),
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE(user_id, scope, start_ts, end_ts)
);

-- Add indexes for performance
CREATE INDEX IF NOT EXISTS idx_trade_legs_trade_id ON public.trade_legs(trade_id);
CREATE INDEX IF NOT EXISTS idx_equity_snapshots_user_id_time ON public.equity_snapshots(user_id, time_utc DESC);
CREATE INDEX IF NOT EXISTS idx_metrics_summary_user_id_scope ON public.metrics_summary(user_id, scope);