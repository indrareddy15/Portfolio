-- Fix affiliate_applications RLS security issue
-- Remove the problematic deny policy and create proper restrictive policies

-- Drop the existing problematic policy
DROP POLICY IF EXISTS "deny_anonymous_access_to_affiliate_applications" ON public.affiliate_applications;

-- Create a comprehensive restrictive policy for SELECT operations
DROP POLICY IF EXISTS "admins_can_select_all_applications" ON public.affiliate_applications;
DROP POLICY IF EXISTS "users_can_select_own_applications" ON public.affiliate_applications;

-- Create new secure SELECT policy that only allows:
-- 1. Admins to see all applications
-- 2. Users to see only their own applications
-- 3. Completely blocks anonymous access
CREATE POLICY "secure_select_affiliate_applications" ON public.affiliate_applications
FOR SELECT 
TO authenticated
USING (
  -- Allow admins to see all applications
  has_role(auth.uid(), 'admin'::app_role) 
  OR 
  -- Allow users to see only their own applications
  (auth.uid() = user_id)
);

-- Update other policies to be more explicit about authentication requirement
DROP POLICY IF EXISTS "authenticated_users_can_insert_own_applications" ON public.affiliate_applications;
CREATE POLICY "authenticated_users_can_insert_own_applications" ON public.affiliate_applications
FOR INSERT 
TO authenticated
WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "users_can_update_own_applications" ON public.affiliate_applications;
CREATE POLICY "users_can_update_own_applications" ON public.affiliate_applications
FOR UPDATE 
TO authenticated
USING (
  has_role(auth.uid(), 'admin'::app_role) 
  OR 
  (auth.uid() = user_id)
)
WITH CHECK (
  has_role(auth.uid(), 'admin'::app_role) 
  OR 
  (auth.uid() = user_id)
);

DROP POLICY IF EXISTS "admins_can_update_all_applications" ON public.affiliate_applications;
DROP POLICY IF EXISTS "admins_can_delete_applications" ON public.affiliate_applications;

-- Create secure admin policies
CREATE POLICY "admins_can_delete_applications" ON public.affiliate_applications
FOR DELETE 
TO authenticated
USING (has_role(auth.uid(), 'admin'::app_role));

-- Ensure no anonymous access is possible by not creating any policies for the 'anon' role
-- RLS will automatically deny access to any role without explicit policies