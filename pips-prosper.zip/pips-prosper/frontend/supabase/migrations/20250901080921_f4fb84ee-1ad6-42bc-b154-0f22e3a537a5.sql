-- Fix function search path security vulnerabilities
-- Update existing functions to have secure search paths

-- Fix the has_role function
CREATE OR REPLACE FUNCTION public.has_role(_user_id uuid, _role app_role)
RETURNS boolean
LANGUAGE sql
STABLE SECURITY DEFINER
SET search_path TO 'public'
AS $$
  SELECT EXISTS (
    SELECT 1
    FROM public.user_roles
    WHERE user_id = _user_id
      AND role = _role
  )
$$;

-- Fix the get_current_user_role function
CREATE OR REPLACE FUNCTION public.get_current_user_role()
RETURNS app_role
LANGUAGE sql
STABLE SECURITY DEFINER
SET search_path TO 'public'
AS $$
  SELECT role 
  FROM public.user_roles 
  WHERE user_id = auth.uid() 
  ORDER BY 
    CASE role 
      WHEN 'admin' THEN 1 
      WHEN 'moderator' THEN 2 
      WHEN 'user' THEN 3 
    END 
  LIMIT 1
$$;

-- Fix the mask_sensitive_data function
CREATE OR REPLACE FUNCTION public.mask_sensitive_data(data text, mask_type text DEFAULT 'email'::text)
RETURNS text
LANGUAGE plpgsql
STABLE SECURITY DEFINER
SET search_path TO 'public'
AS $$
BEGIN
    CASE mask_type
        WHEN 'email' THEN
            RETURN CONCAT(LEFT(data, 2), '***@', SPLIT_PART(data, '@', 2));
        WHEN 'phone' THEN
            RETURN CONCAT('***-***-', RIGHT(data, 4));
        WHEN 'name' THEN
            RETURN CONCAT(LEFT(data, 1), REPEAT('*', LENGTH(data) - 1));
        WHEN 'secret' THEN
            -- Show first 4 and last 4 characters, mask the middle
            RETURN CONCAT(LEFT(data, 4), REPEAT('*', GREATEST(0, LENGTH(data) - 8)), RIGHT(data, 4));
        ELSE
            RETURN '***';
    END CASE;
END;
$$;

-- Fix the get_webhook_keys_safe function
CREATE OR REPLACE FUNCTION public.get_webhook_keys_safe()
RETURNS TABLE(id uuid, user_id uuid, name text, secret_masked text, secret text, active boolean, created_at timestamp with time zone)
LANGUAGE sql
STABLE SECURITY DEFINER
SET search_path TO 'public'
AS $$
SELECT 
    wk.id,
    wk.user_id,
    wk.name,
    public.mask_sensitive_data(wk.secret, 'secret') as secret_masked,
    CASE 
        -- Only show full secret if created within last 5 minutes
        WHEN wk.created_at > now() - interval '5 minutes' THEN wk.secret
        ELSE public.mask_sensitive_data(wk.secret, 'secret')
    END as secret,
    wk.active,
    wk.created_at
FROM public.webhook_keys wk
WHERE wk.user_id = auth.uid();
$$;

-- Fix the handle_new_user function
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $$
BEGIN
  -- Create profile
  INSERT INTO public.profiles (user_id, display_name)
  VALUES (NEW.id, NEW.raw_user_meta_data ->> 'display_name');
  
  -- Assign default user role
  INSERT INTO public.user_roles (user_id, role)
  VALUES (NEW.id, 'user'::app_role);
  
  RETURN NEW;
END;
$$;

-- Fix the log_sensitive_operation function
CREATE OR REPLACE FUNCTION public.log_sensitive_operation()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $$
BEGIN
    -- Only log operations on sensitive tables
    IF TG_TABLE_NAME IN ('affiliate_applications', 'profiles', 'subscribers') THEN
        INSERT INTO public.audit_logs (
            table_name,
            operation,
            record_id,
            user_id,
            user_role,
            old_values,
            new_values
        ) VALUES (
            TG_TABLE_NAME,
            TG_OP,
            COALESCE(NEW.id, OLD.id),
            auth.uid(),
            public.get_current_user_role()::TEXT,
            CASE WHEN TG_OP != 'INSERT' THEN to_jsonb(OLD) ELSE NULL END,
            CASE WHEN TG_OP != 'DELETE' THEN to_jsonb(NEW) ELSE NULL END
        );
    END IF;
    
    RETURN COALESCE(NEW, OLD);
END;
$$;

-- Fix the update_updated_at_column function
CREATE OR REPLACE FUNCTION public.update_updated_at_column()
RETURNS trigger
LANGUAGE plpgsql
SET search_path TO 'public'
AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$;