-- Create strategies table
CREATE TABLE public.strategies (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  description TEXT,
  rules_json JSONB,
  examples TEXT[],
  active BOOLEAN DEFAULT true,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create psychology tracking table
CREATE TABLE public.psychology_entries (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  trade_id UUID NOT NULL REFERENCES public.trades(id) ON DELETE CASCADE,
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  mood_pre INTEGER CHECK (mood_pre >= 1 AND mood_pre <= 10),
  mood_post INTEGER CHECK (mood_post >= 1 AND mood_post <= 10),
  mistake_tags TEXT[],
  adherence_score INTEGER CHECK (adherence_score >= 1 AND adherence_score <= 10),
  comments TEXT,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create import jobs table
CREATE TABLE public.import_jobs (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  source TEXT NOT NULL,
  status TEXT CHECK (status IN ('queued', 'processing', 'completed', 'failed')) DEFAULT 'queued',
  errors_json JSONB,
  total_rows INTEGER,
  processed_rows INTEGER DEFAULT 0,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  finished_at TIMESTAMP WITH TIME ZONE
);

-- Create webhook keys table
CREATE TABLE public.webhook_keys (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  secret TEXT NOT NULL,
  active BOOLEAN DEFAULT true,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS on all tables
ALTER TABLE public.strategies ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.psychology_entries ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.import_jobs ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.webhook_keys ENABLE ROW LEVEL SECURITY;

-- Strategies policies
CREATE POLICY "Users can view their own strategies" ON public.strategies FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "Users can create their own strategies" ON public.strategies FOR INSERT WITH CHECK (auth.uid() = user_id);
CREATE POLICY "Users can update their own strategies" ON public.strategies FOR UPDATE USING (auth.uid() = user_id);
CREATE POLICY "Users can delete their own strategies" ON public.strategies FOR DELETE USING (auth.uid() = user_id);

-- Psychology entries policies
CREATE POLICY "Users can view their own psychology entries" ON public.psychology_entries FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "Users can create their own psychology entries" ON public.psychology_entries FOR INSERT WITH CHECK (auth.uid() = user_id);
CREATE POLICY "Users can update their own psychology entries" ON public.psychology_entries FOR UPDATE USING (auth.uid() = user_id);
CREATE POLICY "Users can delete their own psychology entries" ON public.psychology_entries FOR DELETE USING (auth.uid() = user_id);

-- Import jobs policies
CREATE POLICY "Users can view their own import jobs" ON public.import_jobs FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "Users can create their own import jobs" ON public.import_jobs FOR INSERT WITH CHECK (auth.uid() = user_id);
CREATE POLICY "Users can update their own import jobs" ON public.import_jobs FOR UPDATE USING (auth.uid() = user_id);

-- Webhook keys policies
CREATE POLICY "Users can view their own webhook keys" ON public.webhook_keys FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "Users can create their own webhook keys" ON public.webhook_keys FOR INSERT WITH CHECK (auth.uid() = user_id);
CREATE POLICY "Users can update their own webhook keys" ON public.webhook_keys FOR UPDATE USING (auth.uid() = user_id);
CREATE POLICY "Users can delete their own webhook keys" ON public.webhook_keys FOR DELETE USING (auth.uid() = user_id);

-- Add triggers for timestamp updates
CREATE TRIGGER update_strategies_updated_at
  BEFORE UPDATE ON public.strategies
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_psychology_entries_updated_at
  BEFORE UPDATE ON public.psychology_entries
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at_column();

-- Add strategy_id to trades table
ALTER TABLE public.trades ADD COLUMN strategy_id UUID REFERENCES public.strategies(id) ON DELETE SET NULL;

-- Add indexes for better performance
CREATE INDEX idx_trades_user_id_opened_at ON public.trades(user_id, opened_at DESC);
CREATE INDEX idx_trades_instrument ON public.trades(instrument);
CREATE INDEX idx_trades_result ON public.trades(result);
CREATE INDEX idx_strategies_user_id ON public.strategies(user_id);
CREATE INDEX idx_psychology_entries_trade_id ON public.psychology_entries(trade_id);