-- Fix security issues by updating RLS policies to use authenticated role instead of public

-- Drop and recreate affiliate_applications policies with authenticated role
DROP POLICY IF EXISTS "Admins can manage all affiliate applications" ON public.affiliate_applications;
DROP POLICY IF EXISTS "Admins can update applications" ON public.affiliate_applications;
DROP POLICY IF EXISTS "Users can create their own applications" ON public.affiliate_applications;
DROP POLICY IF EXISTS "Users can view their own applications" ON public.affiliate_applications;

-- Recreate with proper authenticated role
CREATE POLICY "Admins can manage all affiliate applications" 
ON public.affiliate_applications 
FOR ALL 
TO authenticated
USING (has_role(auth.uid(), 'admin'::app_role))
WITH CHECK (has_role(auth.uid(), 'admin'::app_role));

CREATE POLICY "Users can create their own applications" 
ON public.affiliate_applications 
FOR INSERT 
TO authenticated
WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can view their own applications" 
ON public.affiliate_applications 
FOR SELECT 
TO authenticated
USING ((auth.uid() = user_id) OR has_role(auth.uid(), 'admin'::app_role));

-- Fix profiles policies
DROP POLICY IF EXISTS "Admins can manage all profiles" ON public.profiles;
DROP POLICY IF EXISTS "Users can insert their own profile" ON public.profiles;
DROP POLICY IF EXISTS "Users can update their own profile" ON public.profiles;
DROP POLICY IF EXISTS "Users can view their own profile" ON public.profiles;

CREATE POLICY "Admins can manage all profiles" 
ON public.profiles 
FOR ALL 
TO authenticated
USING (has_role(auth.uid(), 'admin'::app_role))
WITH CHECK (has_role(auth.uid(), 'admin'::app_role));

CREATE POLICY "Users can insert their own profile" 
ON public.profiles 
FOR INSERT 
TO authenticated
WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own profile" 
ON public.profiles 
FOR UPDATE 
TO authenticated
USING (auth.uid() = user_id)
WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can view their own profile" 
ON public.profiles 
FOR SELECT 
TO authenticated
USING (auth.uid() = user_id);

-- Fix subscribers policies 
DROP POLICY IF EXISTS "Admins can view all subscribers" ON public.subscribers;
DROP POLICY IF EXISTS "select_own_subscription" ON public.subscribers;
DROP POLICY IF EXISTS "users_can_update_own_subscription" ON public.subscribers;

CREATE POLICY "Admins can view all subscribers" 
ON public.subscribers 
FOR SELECT 
TO authenticated
USING (has_role(auth.uid(), 'admin'::app_role));

CREATE POLICY "Users can view own subscription" 
ON public.subscribers 
FOR SELECT 
TO authenticated
USING ((user_id = auth.uid()) OR (email = auth.email()));

CREATE POLICY "Users can update own subscription" 
ON public.subscribers 
FOR UPDATE 
TO authenticated
USING ((auth.uid() = user_id) OR (auth.email() = email))
WITH CHECK ((auth.uid() = user_id) OR (auth.email() = email));

-- Fix webhook_keys policies - remove the problematic policy that requires service_role
DROP POLICY IF EXISTS "Users can create their own webhook keys" ON public.webhook_keys;
DROP POLICY IF EXISTS "Users can delete their own webhook keys" ON public.webhook_keys;
DROP POLICY IF EXISTS "Users can update their own webhook keys" ON public.webhook_keys;
DROP POLICY IF EXISTS "Users can view their own webhook keys" ON public.webhook_keys;
DROP POLICY IF EXISTS "Users can view webhook metadata only" ON public.webhook_keys;

CREATE POLICY "Users can create their own webhook keys" 
ON public.webhook_keys 
FOR INSERT 
TO authenticated
WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can delete their own webhook keys" 
ON public.webhook_keys 
FOR DELETE 
TO authenticated
USING (auth.uid() = user_id);

CREATE POLICY "Users can update their own webhook keys" 
ON public.webhook_keys 
FOR UPDATE 
TO authenticated
USING (auth.uid() = user_id)
WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can view their own webhook keys" 
ON public.webhook_keys 
FOR SELECT 
TO authenticated
USING (auth.uid() = user_id);