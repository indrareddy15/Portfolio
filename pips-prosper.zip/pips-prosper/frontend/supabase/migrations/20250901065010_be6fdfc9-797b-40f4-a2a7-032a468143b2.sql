-- Fix webhook_keys security issue by masking secret keys

-- Update mask_sensitive_data function to handle secret keys
CREATE OR REPLACE FUNCTION public.mask_sensitive_data(data text, mask_type text DEFAULT 'email'::text)
RETURNS text
LANGUAGE plpgsql
STABLE SECURITY DEFINER
SET search_path TO 'public'
AS $function$
BEGIN
    CASE mask_type
        WHEN 'email' THEN
            RETURN CONCAT(LEFT(data, 2), '***@', SPLIT_PART(data, '@', 2));
        WHEN 'phone' THEN
            RETURN CONCAT('***-***-', RIGHT(data, 4));
        WHEN 'name' THEN
            RETURN CONCAT(LEFT(data, 1), REPEAT('*', LENGTH(data) - 1));
        WHEN 'secret' THEN
            -- Show first 4 and last 4 characters, mask the middle
            RETURN CONCAT(LEFT(data, 4), REPEAT('*', GREATEST(0, LENGTH(data) - 8)), RIGHT(data, 4));
        ELSE
            RETURN '***';
    END CASE;
END;
$function$;

-- Create a secure view for webhook_keys that masks secrets
CREATE OR REPLACE VIEW public.webhook_keys_secure AS
SELECT 
  id,
  user_id,
  name,
  public.mask_sensitive_data(secret, 'secret') AS secret_masked,
  secret, -- Keep original for system operations
  active,
  created_at
FROM public.webhook_keys;

-- Enable RLS on the view
ALTER VIEW public.webhook_keys_secure SET (security_barrier = true);

-- Grant usage on the view
GRANT SELECT ON public.webhook_keys_secure TO authenticated;

-- Update RLS policies to be more restrictive on the base table
-- Drop existing policies first
DROP POLICY IF EXISTS "Users can view their own webhook keys" ON public.webhook_keys;

-- Create new restrictive policy for direct table access (system use only)
CREATE POLICY "Users can view their own webhook keys" 
ON public.webhook_keys FOR SELECT 
USING (
  auth.uid() = user_id AND 
  -- Only allow full secret access for the user who just created it (within 5 minutes)
  (created_at > now() - interval '5 minutes' OR auth.jwt() ->> 'role' = 'service_role')
);

-- Create policy for the secure view (normal user operations)
CREATE POLICY "Users can view their own masked webhook keys" 
ON public.webhook_keys_secure FOR SELECT 
USING (auth.uid() = user_id);