-- Enable realtime for strategies table
ALTER TABLE public.strategies REPLICA IDENTITY FULL;

-- Add strategies to realtime publication
INSERT INTO supabase_realtime.subscription (subscription_id, entity) 
VALUES (gen_random_uuid()::text, 'public.strategies')
ON CONFLICT (entity) DO NOTHING;