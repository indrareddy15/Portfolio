-- Assign admin role to the current user
INSERT INTO public.user_roles (user_id, role) 
VALUES ('e34465d3-7463-4951-94b7-3838833b3356', 'admin'::app_role)
ON CONFLICT (user_id, role) DO NOTHING;

-- Also make sure there's a profile for this user
INSERT INTO public.profiles (user_id, display_name) 
VALUES ('e34465d3-7463-4951-94b7-3838833b3356', 'Admin User')
ON CONFLICT (user_id) DO NOTHING;