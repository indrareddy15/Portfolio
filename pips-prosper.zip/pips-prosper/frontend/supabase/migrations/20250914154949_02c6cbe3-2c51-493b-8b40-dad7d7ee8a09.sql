-- Enable full row data for realtime on blog_posts (idempotent)
ALTER TABLE public.blog_posts REPLICA IDENTITY FULL;

-- Add blog_posts to supabase_realtime publication if not already present
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_publication_tables 
    WHERE pubname = 'supabase_realtime' 
      AND schemaname = 'public' 
      AND tablename = 'blog_posts'
  ) THEN
    EXECUTE 'ALTER PUBLICATION supabase_realtime ADD TABLE public.blog_posts';
  END IF;
END $$;