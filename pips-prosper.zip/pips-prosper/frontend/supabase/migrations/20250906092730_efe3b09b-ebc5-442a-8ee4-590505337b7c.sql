-- Create logo settings table
CREATE TABLE public.logo_settings (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  logo_type TEXT NOT NULL DEFAULT 'main', -- main, footer, auth, etc.
  logo_url TEXT NOT NULL,
  logo_alt TEXT NOT NULL DEFAULT 'Logo',
  width INTEGER,
  height INTEGER,
  usage_locations TEXT[] DEFAULT '{}',
  is_active BOOLEAN NOT NULL DEFAULT true,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  created_by UUID REFERENCES auth.users(id)
);

-- Enable RLS
ALTER TABLE public.logo_settings ENABLE ROW LEVEL SECURITY;

-- Create policies
CREATE POLICY "Anyone can view active logo settings" 
ON public.logo_settings 
FOR SELECT 
USING (is_active = true);

CREATE POLICY "Admins can manage logo settings" 
ON public.logo_settings 
FOR ALL 
USING (has_role(auth.uid(), 'admin'::app_role))
WITH CHECK (has_role(auth.uid(), 'admin'::app_role));

-- Create trigger for automatic timestamp updates
CREATE TRIGGER update_logo_settings_updated_at
BEFORE UPDATE ON public.logo_settings
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();

-- Insert default logo
INSERT INTO public.logo_settings (
  logo_type,
  logo_url,
  logo_alt,
  width,
  height,
  usage_locations
) VALUES (
  'main',
  '/lovable-uploads/209ab0bf-bdd5-4655-8850-a8715907b65a.png',
  'PipTrackr.com Logo',
  200,
  50,
  ARRAY['navigation', 'footer', 'auth', 'dashboard']
);