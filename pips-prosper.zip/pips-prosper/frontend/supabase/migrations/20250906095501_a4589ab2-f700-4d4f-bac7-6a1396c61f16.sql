-- Update existing accounts table with new fields for multi-account management
ALTER TABLE public.accounts ADD COLUMN IF NOT EXISTS account_type text CHECK (account_type IN ('broker', 'prop_firm', 'demo', 'live'));
ALTER TABLE public.accounts ADD COLUMN IF NOT EXISTS broker_name text;
ALTER TABLE public.accounts ADD COLUMN IF NOT EXISTS nickname text;
ALTER TABLE public.accounts ADD COLUMN IF NOT EXISTS account_size numeric DEFAULT 0;
ALTER TABLE public.accounts ADD COLUMN IF NOT EXISTS risk_preference numeric DEFAULT 1.0 CHECK (risk_preference >= 0.1 AND risk_preference <= 10.0);
ALTER TABLE public.accounts ADD COLUMN IF NOT EXISTS balance numeric DEFAULT 0;
ALTER TABLE public.accounts ADD COLUMN IF NOT EXISTS equity numeric DEFAULT 0;
ALTER TABLE public.accounts ADD COLUMN IF NOT EXISTS free_margin numeric DEFAULT 0;
ALTER TABLE public.accounts ADD COLUMN IF NOT EXISTS margin numeric DEFAULT 0;
ALTER TABLE public.accounts ADD COLUMN IF NOT EXISTS is_active boolean DEFAULT true;

-- Update existing accounts to have proper values
UPDATE public.accounts 
SET 
    account_type = COALESCE(type, 'demo'),
    broker_name = COALESCE(broker, 'Unknown'),
    nickname = COALESCE(name, 'Account-' || substring(id::text, 1, 8)),
    account_size = COALESCE(start_balance, 10000),
    balance = COALESCE(start_balance, 10000),
    equity = COALESCE(start_balance, 10000),
    risk_preference = 1.0,
    is_active = NOT COALESCE(archived, false)
WHERE account_type IS NULL OR broker_name IS NULL OR nickname IS NULL;

-- Make required fields NOT NULL after populating them
ALTER TABLE public.accounts ALTER COLUMN account_type SET NOT NULL;
ALTER TABLE public.accounts ALTER COLUMN broker_name SET NOT NULL;
ALTER TABLE public.accounts ALTER COLUMN nickname SET NOT NULL;