-- Add new payout status options and audit trail
ALTER TABLE public.payouts 
ADD COLUMN IF NOT EXISTS processed_at TIMESTAMP WITH TIME ZONE,
ADD COLUMN IF NOT EXISTS processed_by UUID REFERENCES auth.users(id),
ADD COLUMN IF NOT EXISTS rejection_reason TEXT,
ADD COLUMN IF NOT EXISTS notes TEXT;

-- Update status constraint to include new statuses
DO $$ 
BEGIN
  -- Drop existing constraint if it exists
  IF EXISTS (SELECT 1 FROM information_schema.table_constraints 
             WHERE constraint_name = 'payouts_status_check' 
             AND table_name = 'payouts') THEN
    ALTER TABLE public.payouts DROP CONSTRAINT payouts_status_check;
  END IF;
  
  -- Add new constraint with all statuses
  ALTER TABLE public.payouts 
  ADD CONSTRAINT payouts_status_check 
  CHECK (status IN ('requested', 'processing', 'paid', 'failed', 'rejected', 'canceled'));
END $$;

-- Create payout status audit table
CREATE TABLE IF NOT EXISTS public.payout_audit (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  payout_id UUID NOT NULL REFERENCES public.payouts(id) ON DELETE CASCADE,
  old_status TEXT,
  new_status TEXT NOT NULL,
  changed_by UUID REFERENCES auth.users(id),
  reason TEXT,
  metadata JSONB DEFAULT '{}',
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS on payout audit
ALTER TABLE public.payout_audit ENABLE ROW LEVEL SECURITY;

-- Create policies for payout audit
CREATE POLICY "Admins can manage payout audit" 
ON public.payout_audit 
FOR ALL 
USING (has_role(auth.uid(), 'admin'::app_role))
WITH CHECK (has_role(auth.uid(), 'admin'::app_role));

-- Create function to handle payout status transitions
CREATE OR REPLACE FUNCTION public.handle_payout_status_change()
RETURNS TRIGGER AS $$
DECLARE
  admin_id UUID;
BEGIN
  -- Get current admin user
  admin_id := auth.uid();
  
  -- Set processed timestamp and admin when moving to final states
  IF NEW.status IN ('paid', 'failed', 'rejected', 'canceled') AND OLD.status != NEW.status THEN
    NEW.processed_at := now();
    NEW.processed_by := admin_id;
  END IF;
  
  -- Log the status change
  INSERT INTO public.payout_audit (
    payout_id, 
    old_status, 
    new_status, 
    changed_by,
    reason,
    metadata
  ) 
  VALUES (
    NEW.id, 
    OLD.status, 
    NEW.status, 
    admin_id,
    NEW.rejection_reason,
    jsonb_build_object(
      'reference', NEW.reference,
      'notes', NEW.notes,
      'amount', NEW.amount,
      'method', NEW.method
    )
  );
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = public;

-- Create trigger for payout status changes
DROP TRIGGER IF EXISTS payout_status_audit_trigger ON public.payouts;
CREATE TRIGGER payout_status_audit_trigger
  BEFORE UPDATE ON public.payouts
  FOR EACH ROW 
  WHEN (OLD.status IS DISTINCT FROM NEW.status)
  EXECUTE FUNCTION public.handle_payout_status_change();

-- Create indexes for better performance
CREATE INDEX IF NOT EXISTS idx_payout_audit_payout_id ON public.payout_audit(payout_id);
CREATE INDEX IF NOT EXISTS idx_payout_audit_created_at ON public.payout_audit(created_at);
CREATE INDEX IF NOT EXISTS idx_payouts_status ON public.payouts(status);
CREATE INDEX IF NOT EXISTS idx_payouts_processed_at ON public.payouts(processed_at);

-- Add realtime for payout audit
ALTER PUBLICATION supabase_realtime ADD TABLE public.payout_audit;