-- Set default affiliate commission to 10% instead of 30%
ALTER TABLE public.affiliates 
ALTER COLUMN default_rate_pct SET DEFAULT 10.00;

-- Update existing affiliates to 10% if they still have 30%
UPDATE public.affiliates 
SET default_rate_pct = 10.00 
WHERE default_rate_pct = 30.00;