-- Fix affiliate_applications RLS policies - use different policy names to avoid conflicts

-- Drop all existing policies first
DROP POLICY IF EXISTS "Admins can manage all affiliate applications" ON public.affiliate_applications;
DROP POLICY IF EXISTS "Service role full access to applications" ON public.affiliate_applications;
DROP POLICY IF EXISTS "Users can create their own applications" ON public.affiliate_applications;
DROP POLICY IF EXISTS "Users can view their own applications" ON public.affiliate_applications;
DROP POLICY IF EXISTS "Users can view own applications only" ON public.affiliate_applications;

-- Create secure policies with new names
-- 1. Users can only view their own applications
CREATE POLICY "secure_user_select_own" 
ON public.affiliate_applications 
FOR SELECT 
TO authenticated
USING (auth.uid() = user_id);

-- 2. Users can only create applications for themselves  
CREATE POLICY "secure_user_insert_own" 
ON public.affiliate_applications 
FOR INSERT 
TO authenticated
WITH CHECK (auth.uid() = user_id);

-- 3. Users can update their own applications
CREATE POLICY "secure_user_update_own" 
ON public.affiliate_applications 
FOR UPDATE 
TO authenticated
USING (auth.uid() = user_id)
WITH CHECK (auth.uid() = user_id);

-- 4. Admins can view all applications
CREATE POLICY "secure_admin_select_all" 
ON public.affiliate_applications 
FOR SELECT 
TO authenticated
USING (has_role(auth.uid(), 'admin'::app_role));

-- 5. Admins can manage all applications
CREATE POLICY "secure_admin_manage_all" 
ON public.affiliate_applications 
FOR ALL 
TO authenticated
USING (has_role(auth.uid(), 'admin'::app_role))
WITH CHECK (has_role(auth.uid(), 'admin'::app_role));

-- 6. Service role access (properly restricted)
CREATE POLICY "secure_service_role_access" 
ON public.affiliate_applications 
FOR ALL 
TO service_role
USING (true)
WITH CHECK (true);

-- 7. Explicitly deny anonymous access
CREATE POLICY "deny_anonymous_access" 
ON public.affiliate_applications 
FOR ALL 
TO anon
USING (false)
WITH CHECK (false);