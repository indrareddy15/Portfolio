-- Create enums for trade status and sources
DO $$
BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_type WHERE typname = 'trade_status') THEN
        CREATE TYPE trade_status AS ENUM ('open', 'closed', 'partial');
    END IF;
END$$;

DO $$
BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_type WHERE typname = 'trade_source') THEN
        CREATE TYPE trade_source AS ENUM ('manual', 'mt4', 'mt5', 'ctrader', 'tradelocker', 'tv');
    END IF;
END$$;

DO $$
BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_type WHERE typname = 'leg_type') THEN
        CREATE TYPE leg_type AS ENUM ('open', 'close');
    END IF;
END$$;