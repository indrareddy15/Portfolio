-- Create public 'blog-media' storage bucket (idempotent)
insert into storage.buckets (id, name, public)
values ('blog-media', 'blog-media', true)
on conflict (id) do nothing;

-- Ensure public can read from the 'blog-media' bucket
DROP POLICY IF EXISTS "Public read blog-media" ON storage.objects;
CREATE POLICY "Public read blog-media"
ON storage.objects
FOR SELECT
USING (bucket_id = 'blog-media');

-- Ensure admins can manage files in 'blog-media'
DROP POLICY IF EXISTS "Admins manage blog-media" ON storage.objects;
CREATE POLICY "Admins manage blog-media"
ON storage.objects
FOR ALL
USING (
  bucket_id = 'blog-media' AND public.has_role(auth.uid(), 'admin'::app_role)
)
WITH CHECK (
  bucket_id = 'blog-media' AND public.has_role(auth.uid(), 'admin'::app_role)
);

-- Enable full row data for realtime on blog_media (idempotent)
ALTER TABLE public.blog_media REPLICA IDENTITY FULL;

-- Add blog_media to supabase_realtime publication if not already present
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_publication_tables 
    WHERE pubname = 'supabase_realtime' 
      AND schemaname = 'public' 
      AND tablename = 'blog_media'
  ) THEN
    EXECUTE 'ALTER PUBLICATION supabase_realtime ADD TABLE public.blog_media';
  END IF;
END $$;