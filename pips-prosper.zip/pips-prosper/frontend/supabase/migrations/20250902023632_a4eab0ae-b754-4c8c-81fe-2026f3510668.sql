-- Create affiliate_settings table for global affiliate configuration
CREATE TABLE public.affiliate_settings (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  default_commission_rate NUMERIC DEFAULT 10.00,
  minimum_payout NUMERIC DEFAULT 100.00,
  payout_frequency TEXT DEFAULT 'monthly',
  cookie_duration INTEGER DEFAULT 90,
  auto_approval BOOLEAN DEFAULT false,
  email_notifications BOOLEAN DEFAULT true,
  tracking_domain TEXT DEFAULT 'track.pipsjournal.com',
  terms_and_conditions TEXT DEFAULT 'Please review our affiliate terms and conditions before participating in the program...',
  welcome_message TEXT DEFAULT 'Welcome to the PipsJournal affiliate program! We''re excited to work with you.',
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
  updated_by UUID REFERENCES auth.users(id)
);

-- Enable RLS
ALTER TABLE public.affiliate_settings ENABLE ROW LEVEL SECURITY;

-- Create policies for affiliate settings
CREATE POLICY "Admins can manage affiliate settings"
ON public.affiliate_settings
FOR ALL 
USING (has_role(auth.uid(), 'admin'::app_role))
WITH CHECK (has_role(auth.uid(), 'admin'::app_role));

-- Anyone can view affiliate settings (for public display)
CREATE POLICY "Anyone can view affiliate settings"
ON public.affiliate_settings
FOR SELECT
USING (true);

-- Insert default settings
INSERT INTO public.affiliate_settings (
  default_commission_rate,
  minimum_payout,
  payout_frequency,
  cookie_duration,
  auto_approval,
  email_notifications,
  tracking_domain,
  terms_and_conditions,
  welcome_message
) VALUES (
  30.00,
  100.00,
  'monthly',
  90,
  false,
  true,
  'track.pipsjournal.com',
  'Please review our affiliate terms and conditions before participating in the program. By joining, you agree to promote PipsJournal honestly and ethically.',
  'Welcome to the PipsJournal affiliate program! We''re excited to work with you and help you earn commissions.'
);

-- Add update trigger
CREATE TRIGGER update_affiliate_settings_updated_at
BEFORE UPDATE ON public.affiliate_settings
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();