-- Insert seed data for common instruments
INSERT INTO public.instruments (symbol, class, contract_size, pip_decimal, tick_size, quote_ccy) VALUES
  -- Major Forex Pairs
  ('EURUSD', 'forex', 100000, 4, 0.0001, 'USD'),
  ('GBPUSD', 'forex', 100000, 4, 0.0001, 'USD'),
  ('USDJPY', 'forex', 100000, 2, 0.01, 'JPY'),
  ('USDCHF', 'forex', 100000, 4, 0.0001, 'CHF'),
  ('AUDUSD', 'forex', 100000, 4, 0.0001, 'USD'),
  ('USDCAD', 'forex', 100000, 4, 0.0001, 'CAD'),
  ('NZDUSD', 'forex', 100000, 4, 0.0001, 'USD'),
  ('EURJPY', 'forex', 100000, 2, 0.01, 'JPY'),
  ('GBPJPY', 'forex', 100000, 2, 0.01, 'JPY'),
  ('EURGBP', 'forex', 100000, 4, 0.0001, 'GBP'),
  
  -- Metals
  ('XAUUSD', 'metals', 100, 2, 0.01, 'USD'),
  ('XAGUSD', 'metals', 5000, 3, 0.001, 'USD'),
  
  -- Indices
  ('US30', 'indices', 1, 0, 1, 'USD'),
  ('NAS100', 'indices', 1, 1, 0.1, 'USD'),
  ('SPX500', 'indices', 1, 1, 0.1, 'USD'),
  ('GER30', 'indices', 1, 0, 1, 'EUR'),
  ('UK100', 'indices', 1, 0, 1, 'GBP'),
  
  -- Crypto
  ('BTCUSD', 'crypto', 1, 1, 0.1, 'USD'),
  ('ETHUSD', 'crypto', 1, 2, 0.01, 'USD'),
  ('ADAUSD', 'crypto', 1, 4, 0.0001, 'USD')
ON CONFLICT (symbol) DO NOTHING;

-- Insert sample FX rates for common currencies
INSERT INTO public.fx_rates_new (base_currency, quote_currency, rate_date, rate) VALUES
  ('EUR', 'USD', CURRENT_DATE, 1.0850),
  ('GBP', 'USD', CURRENT_DATE, 1.2650),
  ('USD', 'JPY', CURRENT_DATE, 150.25),
  ('USD', 'CHF', CURRENT_DATE, 0.8750),
  ('AUD', 'USD', CURRENT_DATE, 0.6550),
  ('USD', 'CAD', CURRENT_DATE, 1.3650),
  ('NZD', 'USD', CURRENT_DATE, 0.6150)
ON CONFLICT (base_currency, quote_currency, rate_date) DO NOTHING;

-- Create calculation helper functions for PnL and metrics
CREATE OR REPLACE FUNCTION public.calculate_pip_value(
  symbol TEXT,
  lots DECIMAL,
  account_currency TEXT DEFAULT 'USD'
) RETURNS DECIMAL AS $$
DECLARE
  instrument_rec RECORD;
  pip_value DECIMAL;
  fx_rate DECIMAL := 1.0;
BEGIN
  -- Get instrument details
  SELECT * INTO instrument_rec FROM public.instruments WHERE instruments.symbol = calculate_pip_value.symbol LIMIT 1;
  
  IF NOT FOUND THEN
    RETURN 0;
  END IF;
  
  -- Calculate base pip value
  pip_value := (POWER(10, -instrument_rec.pip_decimal) * lots * instrument_rec.contract_size);
  
  -- Convert to account currency if needed
  IF instrument_rec.quote_ccy != account_currency THEN
    SELECT rate INTO fx_rate 
    FROM public.fx_rates_new 
    WHERE base_currency = instrument_rec.quote_ccy 
      AND quote_currency = account_currency 
      AND rate_date <= CURRENT_DATE
    ORDER BY rate_date DESC 
    LIMIT 1;
    
    IF fx_rate IS NULL THEN
      fx_rate := 1.0;
    END IF;
    
    pip_value := pip_value * fx_rate;
  END IF;
  
  RETURN pip_value;
END;
$$ LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path = public;

-- Create function to calculate trade PnL
CREATE OR REPLACE FUNCTION public.calculate_trade_pnl(
  symbol TEXT,
  side TEXT,
  lots DECIMAL,
  entry_price DECIMAL,
  exit_price DECIMAL,
  commission_cents INTEGER DEFAULT 0,
  swap_cents INTEGER DEFAULT 0,
  account_currency TEXT DEFAULT 'USD'
) RETURNS INTEGER AS $$
DECLARE
  instrument_rec RECORD;
  direction INTEGER := 1;
  pnl_raw DECIMAL;
  fx_rate DECIMAL := 1.0;
  pnl_cents INTEGER;
BEGIN
  -- Get instrument details
  SELECT * INTO instrument_rec FROM public.instruments WHERE instruments.symbol = calculate_trade_pnl.symbol LIMIT 1;
  
  IF NOT FOUND THEN
    RETURN 0;
  END IF;
  
  -- Set direction multiplier
  IF side = 'short' THEN
    direction := -1;
  END IF;
  
  -- Calculate raw PnL
  pnl_raw := (exit_price - entry_price) * direction * lots * instrument_rec.contract_size;
  
  -- Convert to account currency if needed
  IF instrument_rec.quote_ccy != account_currency THEN
    SELECT rate INTO fx_rate 
    FROM public.fx_rates_new 
    WHERE base_currency = instrument_rec.quote_ccy 
      AND quote_currency = account_currency 
      AND rate_date <= CURRENT_DATE
    ORDER BY rate_date DESC 
    LIMIT 1;
    
    IF fx_rate IS NULL THEN
      fx_rate := 1.0;
    END IF;
    
    pnl_raw := pnl_raw * fx_rate;
  END IF;
  
  -- Convert to cents and subtract fees
  pnl_cents := (pnl_raw * 100)::INTEGER - COALESCE(commission_cents, 0) - COALESCE(swap_cents, 0);
  
  RETURN pnl_cents;
END;
$$ LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path = public;