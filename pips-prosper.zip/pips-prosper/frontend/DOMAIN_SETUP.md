# Custom Domain Setup for PipTrackr

## Overview
Your application is now configured to use custom subdomains:

- **piptrackr.com** - Main website (landing page, marketing)
- **app.piptrackr.com** - User dashboard and trading journal
- **admin.piptrackr.com** - Admin panel

## Setting Up Custom Domains in Lovable

1. **Go to Project Settings**
   - Click on your project name in the top left
   - Select "Settings"
   - Navigate to "Domains"

2. **Add Your Main Domain**
   - Click "Connect Domain"
   - Enter: `piptrackr.com`
   - Follow the DNS setup instructions provided by Lovable

3. **Add Subdomains**
   - After adding the main domain, you can add subdomains
   - Add: `app.piptrackr.com`
   - Add: `admin.piptrackr.com`

## DNS Configuration
You'll need to add these DNS records at your domain registrar:

### A Records
```
@ (root)    A    185.158.133.1
www         A    185.158.133.1
app         A    185.158.133.1
admin       A    185.158.133.1
```

### Alternative: CNAME Records (if A records aren't supported)
```
app         CNAME    your-project.lovable.app
admin       CNAME    your-project.lovable.app
```

## How It Works

1. **Automatic Routing**: The app automatically detects which subdomain the user is on and routes them appropriately
2. **Cross-Subdomain Navigation**: Navigation between sections (main → app → admin) works seamlessly
3. **Development**: Works locally with `.localhost` subdomains for testing

## Testing Locally

For local development, you can test with these URLs:
- `http://piptrackr.localhost:5173` - Main site
- `http://app.piptrackr.localhost:5173` - User dashboard
- `http://admin.piptrackr.localhost:5173` - Admin panel

## DNS Propagation
- DNS changes can take 24-48 hours to propagate globally
- Use [DNSChecker.org](https://dnschecker.org) to verify your DNS settings
- SSL certificates are automatically provisioned by Lovable

## Troubleshooting

- If subdomains aren't working, ensure all A records point to `185.158.133.1`
- Remove any conflicting DNS records
- Wait for full DNS propagation (up to 48 hours)
- Contact Lovable support if issues persist

## Notes
- The application will work with your current Lovable preview URL until domains are configured
- All navigation has been updated to use proper subdomain routing
- Host-based routing automatically redirects users to the correct subdomain