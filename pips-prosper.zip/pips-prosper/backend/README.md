# PipTrackr Backend API

A comprehensive Node.js/Express backend for the PipTrackr trading journal application with MongoDB and complete authentication system.

## 🚀 Features

- **Complete Authentication System**: 8 robust API endpoints
- **MongoDB Integration**: Full user management with Mongoose ODM
- **Email Services**: Welcome, verification, and password reset emails
- **Security**: JWT tokens, rate limiting, input validation, CORS
- **Comprehensive Logging**: Winston logger with different levels
- **Error Handling**: Global error handling with detailed responses
- **API Documentation**: Detailed endpoint documentation

## 📋 Prerequisites

- Node.js (v18.0.0 or higher)
- MongoDB (v4.4 or higher)
- Email service (SendGrid, SMTP, or similar)

## ⚡ Quick Start

### 1. Installation

```bash
# Install dependencies
npm install

# Copy environment variables
cp .env.example .env
```

### 2. Environment Configuration

Edit `.env` file with your configurations:

```bash
# Required Variables
NODE_ENV=development
PORT=5000
MONGODB_URI=mongodb://localhost:27017/piptrakr
JWT_SECRET=your_super_secret_jwt_key_here_minimum_32_characters
JWT_REFRESH_SECRET=your_super_secret_refresh_key_here_minimum_32_characters
FRONTEND_URL=http://localhost:5173

# Email Configuration (choose one)
SENDGRID_API_KEY=your_sendgrid_api_key
# OR
SMTP_HOST=smtp.gmail.com
SMTP_PORT=587
SMTP_USER=your_email@gmail.com
SMTP_PASS=your_app_password
```

### 3. Start the Server

```bash
# Development mode
npm run dev

# Production mode
npm start
```

## 🔐 Authentication API Endpoints

### Base URL: `/api/auth`

### 1. **POST** `/signup` - User Registration

Register a new user account.

**Request Body:**

```json
{
  "firstName": "John",
  "lastName": "Doe",
  "email": "john.doe@example.com",
  "password": "SecurePass123",
  "username": "johndoe",
  "phone": "+1234567890",
  "timezone": "UTC",
  "currency": "USD"
}
```

**Response (201):**

```json
{
  "success": true,
  "message": "Registration successful! Please check your email to verify your account.",
  "data": {
    "user": {
      /* user object */
    },
    "token": "jwt_access_token",
    "refreshToken": "jwt_refresh_token"
  }
}
```

### 2. **POST** `/login` - User Login

Authenticate user and get tokens.

**Request Body:**

```json
{
  "email": "john.doe@example.com",
  "password": "SecurePass123"
}
```

**Response (200):**

```json
{
  "success": true,
  "message": "Login successful",
  "data": {
    "user": {
      /* user object */
    },
    "token": "jwt_access_token",
    "refreshToken": "jwt_refresh_token"
  }
}
```

### 3. **POST** `/logout` - User Logout

Logout user and invalidate tokens.

**Headers:** `Authorization: Bearer <token>`

**Request Body:**

```json
{
  "refreshToken": "jwt_refresh_token"
}
```

**Response (200):**

```json
{
  "success": true,
  "message": "Logged out successfully"
}
```

### 4. **GET** `/profile` - Get User Profile

Get current user's profile information.

**Headers:** `Authorization: Bearer <token>`

**Response (200):**

```json
{
  "success": true,
  "data": {
    "user": {
      "_id": "user_id",
      "firstName": "John",
      "lastName": "Doe",
      "email": "john.doe@example.com",
      "username": "johndoe",
      "isEmailVerified": true,
      "role": "user",
      "subscriptionTier": "free",
      "createdAt": "2023-01-01T00:00:00.000Z",
      "updatedAt": "2023-01-01T00:00:00.000Z"
    }
  }
}
```

### 5. **PUT** `/profile` - Update User Profile

Update user profile information.

**Headers:** `Authorization: Bearer <token>`

**Request Body:**

```json
{
  "firstName": "John",
  "lastName": "Smith",
  "username": "johnsmith",
  "phone": "+1234567890",
  "timezone": "America/New_York",
  "currency": "USD"
}
```

**Response (200):**

```json
{
  "success": true,
  "message": "Profile updated successfully",
  "data": {
    "user": {
      /* updated user object */
    }
  }
}
```

### 6. **POST** `/reset-password` - Password Reset Flow

#### Step 1: Request Password Reset

**POST** `/forgot-password`

**Request Body:**

```json
{
  "email": "john.doe@example.com"
}
```

**Response (200):**

```json
{
  "success": true,
  "message": "Password reset instructions sent to email"
}
```

#### Step 2: Reset Password with Token

**POST** `/reset-password`

**Request Body:**

```json
{
  "token": "reset_token_from_email",
  "password": "NewSecurePass123"
}
```

**Response (200):**

```json
{
  "success": true,
  "message": "Password has been reset successfully",
  "data": {
    "user": {
      /* user object */
    },
    "token": "jwt_access_token",
    "refreshToken": "jwt_refresh_token"
  }
}
```

### 7. **POST** `/verify-email` - Email Verification

Verify user's email address with token.

**Request Body:**

```json
{
  "token": "verification_token_from_email"
}
```

**Response (200):**

```json
{
  "success": true,
  "message": "Email verified successfully",
  "data": {
    "user": {
      /* user object */
    }
  }
}
```

### 8. **POST** `/refresh-token` - Token Refresh

Refresh access token using refresh token.

**Request Body:**

```json
{
  "refreshToken": "jwt_refresh_token"
}
```

**Response (200):**

```json
{
  "success": true,
  "message": "Token refreshed successfully",
  "data": {
    "user": {
      /* user object */
    },
    "token": "new_jwt_access_token",
    "refreshToken": "new_jwt_refresh_token"
  }
}
```

## 🛡️ Additional Endpoints

### **POST** `/change-password` - Change Password

Change password when logged in.

**Headers:** `Authorization: Bearer <token>`

**Request Body:**

```json
{
  "currentPassword": "OldPassword123",
  "newPassword": "NewSecurePass123"
}
```

### **POST** `/resend-verification` - Resend Email Verification

Resend email verification link.

**Headers:** `Authorization: Bearer <token>`

### **GET** `/me` - Get Current User

Alias for `/profile` endpoint.

### **GET** `/check` - Authentication Check

Check if user is authenticated.

### **GET** `/status` - Authentication Status

Get authentication status without failing if not authenticated.

## 🔒 Security Features

- **Rate Limiting**: Different limits for different endpoint types
- **Input Validation**: Comprehensive validation using express-validator
- **Password Hashing**: bcrypt with strength 12
- **JWT Security**: Access and refresh token system
- **CORS Protection**: Configurable origins
- **Helmet**: Security headers
- **Request Logging**: Morgan with Winston integration

## 📊 Rate Limits

- **Strict endpoints** (forgot-password, verify-email): 5 requests/15min
- **Auth endpoints** (login, signup, refresh): 10 requests/15min
- **General endpoints**: 50 requests/15min

## 🗄️ Database Schema

### User Model

```javascript
{
  firstName: String (required),
  lastName: String (required),
  email: String (required, unique),
  password: String (required, hashed),
  username: String (unique),
  avatar: String,
  phone: String,
  isEmailVerified: Boolean,
  isActive: Boolean,
  role: String (enum: user, admin, moderator),
  subscriptionTier: String (enum: free, basic, premium, pro),
  subscriptionStatus: String,
  stripeCustomerId: String,
  timezone: String,
  currency: String,
  lastLogin: Date,
  loginCount: Number,
  refreshTokens: Array,
  // ... more fields
}
```

## 📧 Email Templates

The system includes professional email templates for:

- Welcome emails with verification
- Password reset instructions
- Email verification requests

## 🚨 Error Handling

All endpoints return consistent error responses:

```json
{
  "success": false,
  "message": "Error description",
  "errors": [
    /* validation errors if applicable */
  ],
  "error": "Development error details (dev mode only)"
}
```

## 📝 HTTP Status Codes

- **200**: Success
- **201**: Created (signup)
- **400**: Bad Request (validation errors)
- **401**: Unauthorized (authentication failed)
- **403**: Forbidden (insufficient permissions)
- **404**: Not Found
- **409**: Conflict (duplicate data)
- **429**: Too Many Requests (rate limit)
- **500**: Internal Server Error

## 🧪 Testing

Run the test suite:

```bash
npm test
```

## 📚 API Testing

Use tools like Postman, Insomnia, or curl:

```bash
# Health check
curl http://localhost:5000/health

# Register user
curl -X POST http://localhost:5000/api/auth/signup \
  -H "Content-Type: application/json" \
  -d '{"firstName":"John","lastName":"Doe","email":"john@example.com","password":"SecurePass123"}'

# Login
curl -X POST http://localhost:5000/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{"email":"john@example.com","password":"SecurePass123"}'
```

## 🚀 Deployment

### Environment Variables for Production

```bash
NODE_ENV=production
PORT=80
MONGODB_URI=mongodb+srv://user:pass@cluster.mongodb.net/piptrakr
JWT_SECRET=very_secure_random_string_64_characters_minimum
JWT_REFRESH_SECRET=another_very_secure_random_string_64_characters
FRONTEND_URL=https://your-frontend-domain.com
SENDGRID_API_KEY=your_production_sendgrid_key
```

### PM2 Deployment

```bash
npm install -g pm2
pm2 start server.js --name "piptrakr-backend"
```

## 🔧 Development

### File Structure

```
src/
├── config/
│   └── DbConfig.js          # MongoDB connection
├── controllers/
│   └── authController.js    # Auth route handlers
├── middleware/
│   ├── authMiddleware.js    # Auth middleware
│   └── authValidation.js    # Input validation
├── models/
│   └── authModel.js         # User model
├── routes/
│   └── authRoutes.js        # Auth routes
├── services/
│   ├── authService.js       # Auth business logic
│   └── emailService.js      # Email service
└── utils/
    └── logger.js            # Winston logger
```

## 📞 Support

For issues and questions:

- Create an issue in the repository
- Check the logs in `logs/` directory
- Review the health endpoint: `GET /health`

## 📄 License

MIT License - see LICENSE file for details.

---

**Happy Coding! 🚀**
