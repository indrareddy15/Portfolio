#!/bin/bash

# PipTrackr Backend Setup Script
echo "🚀 Setting up PipTrackr Backend..."

# Check if Node.js is installed
if ! command -v node &> /dev/null; then
    echo "❌ Node.js is not installed. Please install Node.js v18+ first."
    exit 1
fi

# Check Node.js version
NODE_VERSION=$(node -v | cut -d'v' -f2 | cut -d'.' -f1)
if [ "$NODE_VERSION" -lt "18" ]; then
    echo "❌ Node.js version 18+ required. Current version: $(node -v)"
    exit 1
fi

echo "✅ Node.js $(node -v) detected"

# Check if MongoDB is running
if ! command -v mongosh &> /dev/null && ! command -v mongo &> /dev/null; then
    echo "⚠️  MongoDB CLI not found. Make sure MongoDB is installed and running."
    echo "   You can also use MongoDB Atlas (cloud) by updating the connection string."
fi

# Install dependencies
echo "📦 Installing dependencies..."
npm install

# Check if .env exists
if [ ! -f ".env" ]; then
    echo "📝 Creating .env file from template..."
    cp .env.example .env
    echo "⚠️  Please update .env file with your actual configuration!"
    echo "   Required: MONGODB_URI, JWT_SECRET, JWT_REFRESH_SECRET"
else
    echo "✅ .env file already exists"
fi

# Create logs directory if it doesn't exist
if [ ! -d "logs" ]; then
    mkdir logs
    echo "✅ Created logs directory"
fi

# Generate JWT secrets if they don't exist in .env
if ! grep -q "JWT_SECRET=your_super_secret" .env; then
    echo "✅ JWT secrets already configured"
else
    echo "🔐 Generating secure JWT secrets..."
    JWT_SECRET=$(openssl rand -base64 64 | tr -d "=+/" | cut -c1-64)
    JWT_REFRESH_SECRET=$(openssl rand -base64 64 | tr -d "=+/" | cut -c1-64)
    
    # Update .env file
    sed -i.bak "s/JWT_SECRET=your_super_secret_jwt_key_here_minimum_32_characters/JWT_SECRET=$JWT_SECRET/" .env
    sed -i.bak "s/JWT_REFRESH_SECRET=your_super_secret_refresh_key_here_minimum_32_characters/JWT_REFRESH_SECRET=$JWT_REFRESH_SECRET/" .env
    
    echo "✅ Generated secure JWT secrets"
fi

echo ""
echo "🎉 Setup complete!"
echo ""
echo "📋 Next steps:"
echo "   1. Update .env file with your MongoDB connection string"
echo "   2. Configure email service (SendGrid or SMTP)"
echo "   3. Start the server: npm run dev"
echo ""
echo "📚 Endpoints will be available at:"
echo "   Health check: http://localhost:5000/health"
echo "   Authentication: http://localhost:5000/api/auth/*"
echo ""
echo "📖 See README.md for complete API documentation"