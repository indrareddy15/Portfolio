// const nodemailer = require('nodemailer');
// const logger = require('../utils/logger');

// class EmailService {
//     constructor () {
//         this.transporter = null;
//         this.initializeTransporter();
//     }

//     initializeTransporter() {
//         // Configure based on environment
//         if (process.env.NODE_ENV === 'production') {
//             // Production email service (SendGrid, AWS SES, etc.)
//             if (process.env.SENDGRID_API_KEY) {
//                 this.transporter = nodemailer.createTransporter({
//                     service: 'SendGrid',
//                     auth: {
//                         user: 'apikey',
//                         pass: process.env.SENDGRID_API_KEY
//                     }
//                 });
//             } else if (process.env.SMTP_HOST) {
//                 // Generic SMTP configuration
//                 this.transporter = nodemailer.createTransporter({
//                     host: process.env.SMTP_HOST,
//                     port: process.env.SMTP_PORT || 587,
//                     secure: process.env.SMTP_SECURE === 'true',
//                     auth: {
//                         user: process.env.SMTP_USER,
//                         pass: process.env.SMTP_PASS
//                     }
//                 });
//             }
//         } else {
//             // Development - use Ethereal or console logging
//             this.transporter = nodemailer.createTransporter({
//                 host: 'smtp.ethereal.email',
//                 port: 587,
//                 auth: {
//                     user: 'ethereal.user@ethereal.email',
//                     pass: 'ethereal.pass'
//                 }
//             });
//         }

//         if (!this.transporter) {
//             logger.warn('No email configuration found. Emails will be logged to console.');
//         }
//     }

//     async sendEmail(options) {
//         try {
//             const mailOptions = {
//                 from: process.env.EMAIL_FROM || 'PipTrackr <noreply@piptrakr.com>',
//                 to: options.email,
//                 subject: options.subject,
//                 text: options.message,
//                 html: options.html
//             };

//             if (this.transporter) {
//                 const info = await this.transporter.sendMail(mailOptions);
//                 logger.info(`Email sent successfully to ${options.email}`, { messageId: info.messageId });
//                 return { success: true, messageId: info.messageId };
//             } else {
//                 // Log email to console in development
//                 logger.info('EMAIL WOULD BE SENT:', {
//                     to: options.email,
//                     subject: options.subject,
//                     message: options.message
//                 });
//                 return { success: true, messageId: 'dev-mode' };
//             }
//         } catch (error) {
//             logger.error('Email sending failed:', error);
//             throw new Error('Could not send email');
//         }
//     }

//     async sendWelcomeEmail(user, verificationToken) {
//         const verificationURL = `${process.env.FRONTEND_URL}/verify-email?token=${verificationToken}`;

//         const message = `
// Welcome to PipTrackr, ${user.firstName}!

// Thank you for joining our trading journal platform. To get started, please verify your email address by clicking the link below:

// ${verificationURL}

// This verification link will expire in 24 hours.

// If you didn't create this account, please ignore this email.

// Best regards,
// The PipTrackr Team
//         `;

//         const html = `
// <!DOCTYPE html>
// <html>
// <head>
//     <meta charset="utf-8">
//     <title>Welcome to PipTrackr</title>
// </head>
// <body style="font-family: Arial, sans-serif; line-height: 1.6; color: #333;">
//     <div style="max-width: 600px; margin: 0 auto; padding: 20px;">
//         <h1 style="color: #2563eb;">Welcome to PipTrackr!</h1>
        
//         <p>Hi ${user.firstName},</p>
        
//         <p>Thank you for joining our trading journal platform. To get started, please verify your email address by clicking the button below:</p>
        
//         <div style="text-align: center; margin: 30px 0;">
//             <a href="${verificationURL}" 
//                style="background-color: #2563eb; color: white; padding: 12px 24px; text-decoration: none; border-radius: 6px; display: inline-block;">
//                 Verify Email Address
//             </a>
//         </div>
        
//         <p>Or copy and paste this link in your browser:</p>
//         <p style="word-break: break-all; color: #2563eb;">${verificationURL}</p>
        
//         <p><strong>This verification link will expire in 24 hours.</strong></p>
        
//         <p>If you didn't create this account, please ignore this email.</p>
        
//         <hr style="margin: 30px 0; border: none; border-top: 1px solid #eee;">
        
//         <p style="color: #666; font-size: 14px;">
//             Best regards,<br>
//             The PipTrackr Team
//         </p>
//     </div>
// </body>
// </html>
//         `;

//         await this.sendEmail({
//             email: user.email,
//             subject: 'Welcome to PipTrackr - Verify Your Email',
//             message,
//             html
//         });
//     }

//     async sendPasswordResetEmail(user, resetToken) {
//         const resetURL = `${process.env.FRONTEND_URL}/reset-password?token=${resetToken}`;

//         const message = `
// Hi ${user.firstName},

// You requested a password reset for your PipTrackr account. Click the link below to reset your password:

// ${resetURL}

// This password reset link will expire in 10 minutes.

// If you didn't request this password reset, please ignore this email and your password will remain unchanged.

// Best regards,
// The PipTrackr Team
//         `;

//         const html = `
// <!DOCTYPE html>
// <html>
// <head>
//     <meta charset="utf-8">
//     <title>Reset Your Password - PipTrackr</title>
// </head>
// <body style="font-family: Arial, sans-serif; line-height: 1.6; color: #333;">
//     <div style="max-width: 600px; margin: 0 auto; padding: 20px;">
//         <h1 style="color: #2563eb;">Reset Your Password</h1>
        
//         <p>Hi ${user.firstName},</p>
        
//         <p>You requested a password reset for your PipTrackr account. Click the button below to reset your password:</p>
        
//         <div style="text-align: center; margin: 30px 0;">
//             <a href="${resetURL}" 
//                style="background-color: #dc2626; color: white; padding: 12px 24px; text-decoration: none; border-radius: 6px; display: inline-block;">
//                 Reset Password
//             </a>
//         </div>
        
//         <p>Or copy and paste this link in your browser:</p>
//         <p style="word-break: break-all; color: #dc2626;">${resetURL}</p>
        
//         <p><strong>This password reset link will expire in 10 minutes.</strong></p>
        
//         <p>If you didn't request this password reset, please ignore this email and your password will remain unchanged.</p>
        
//         <hr style="margin: 30px 0; border: none; border-top: 1px solid #eee;">
        
//         <p style="color: #666; font-size: 14px;">
//             Best regards,<br>
//             The PipTrackr Team
//         </p>
//     </div>
// </body>
// </html>
//         `;

//         await this.sendEmail({
//             email: user.email,
//             subject: 'Reset Your Password - PipTrackr',
//             message,
//             html
//         });
//     }

//     async sendEmailVerificationEmail(user, verificationToken) {
//         const verificationURL = `${process.env.FRONTEND_URL}/verify-email?token=${verificationToken}`;

//         const message = `
// Hi ${user.firstName},

// Please verify your email address for your PipTrackr account by clicking the link below:

// ${verificationURL}

// This verification link will expire in 24 hours.

// If you didn't request this verification, please ignore this email.

// Best regards,
// The PipTrackr Team
//         `;

//         const html = `
// <!DOCTYPE html>
// <html>
// <head>
//     <meta charset="utf-8">
//     <title>Verify Your Email - PipTrackr</title>
// </head>
// <body style="font-family: Arial, sans-serif; line-height: 1.6; color: #333;">
//     <div style="max-width: 600px; margin: 0 auto; padding: 20px;">
//         <h1 style="color: #2563eb;">Verify Your Email</h1>
        
//         <p>Hi ${user.firstName},</p>
        
//         <p>Please verify your email address for your PipTrackr account by clicking the button below:</p>
        
//         <div style="text-align: center; margin: 30px 0;">
//             <a href="${verificationURL}" 
//                style="background-color: #16a34a; color: white; padding: 12px 24px; text-decoration: none; border-radius: 6px; display: inline-block;">
//                 Verify Email
//             </a>
//         </div>
        
//         <p>Or copy and paste this link in your browser:</p>
//         <p style="word-break: break-all; color: #16a34a;">${verificationURL}</p>
        
//         <p><strong>This verification link will expire in 24 hours.</strong></p>
        
//         <p>If you didn't request this verification, please ignore this email.</p>
        
//         <hr style="margin: 30px 0; border: none; border-top: 1px solid #eee;">
        
//         <p style="color: #666; font-size: 14px;">
//             Best regards,<br>
//             The PipTrackr Team
//         </p>
//     </div>
// </body>
// </html>
//         `;

//         await this.sendEmail({
//             email: user.email,
//             subject: 'Verify Your Email - PipTrackr',
//             message,
//             html
//         });
//     }
// }

// module.exports = new EmailService();