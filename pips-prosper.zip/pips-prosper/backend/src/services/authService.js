const jwt = require('jsonwebtoken');
const crypto = require('crypto');
const User = require('../models/authModel');
const emailService = require('./emailService');
const logger = require('../utils/logger');

class AuthService {

    // Generate JWT token
    signToken(id) {
        return jwt.sign({ id }, process.env.JWT_SECRET, {
            expiresIn: process.env.JWT_EXPIRES_IN || '24h'
        });
    }

    // Generate refresh token
    signRefreshToken(id) {
        return jwt.sign({ id }, process.env.JWT_REFRESH_SECRET || process.env.JWT_SECRET, {
            expiresIn: process.env.JWT_REFRESH_EXPIRES_IN || '7d'
        });
    }

    // Create and send tokens
    createSendToken(user, statusCode, res, message = 'Success') {
        const token = this.signToken(user._id);
        const refreshToken = this.signRefreshToken(user._id);

        // Calculate refresh token expiration
        const refreshExpiresIn = process.env.JWT_REFRESH_EXPIRES_IN || '7d';
        const refreshExpires = new Date();
        if (refreshExpiresIn.includes('d')) {
            refreshExpires.setDate(refreshExpires.getDate() + parseInt(refreshExpiresIn));
        } else if (refreshExpiresIn.includes('h')) {
            refreshExpires.setHours(refreshExpires.getHours() + parseInt(refreshExpiresIn));
        }

        // Add refresh token to user
        user.addRefreshToken(refreshToken, refreshExpires, 'web');
        user.save({ validateBeforeSave: false });

        // Cookie options
        const cookieOptions = {
            expires: new Date(
                Date.now() + (process.env.JWT_COOKIE_EXPIRES_IN || 7) * 24 * 60 * 60 * 1000
            ),
            httpOnly: true,
            secure: process.env.NODE_ENV === 'production',
            sameSite: 'strict'
        };

        res.cookie('jwt', token, cookieOptions);
        res.cookie('refreshToken', refreshToken, cookieOptions);

        // Remove password from output
        user.password = undefined;

        res.status(statusCode).json({
            success: true,
            message,
            data: {
                user,
                token,
                refreshToken
            }
        });
    }

    // User registration
    async signup(userData) {
        try {
            // Check if user already exists
            const existingUser = await User.findOne({ email: userData.email });
            if (existingUser) {
                throw new Error('User with this email already exists');
            }

            // Check if username is taken (if provided)
            if (userData.username) {
                const existingUsername = await User.findOne({ username: userData.username });
                if (existingUsername) {
                    throw new Error('Username is already taken');
                }
            }

            // Create new user
            const newUser = await User.create({
                firstName: userData.firstName,
                lastName: userData.lastName,
                email: userData.email,
                password: userData.password,
                username: userData.username,
                phone: userData.phone,
                timezone: userData.timezone || 'UTC',
                currency: userData.currency || 'USD'
            });

            // Generate email verification token
            const verifyToken = newUser.createEmailVerificationToken();
            await newUser.save({ validateBeforeSave: false });

            // Send welcome email with verification
            try {
                await emailService.sendWelcomeEmail(newUser, verifyToken);
                logger.info(`Welcome email sent to ${newUser.email}`);
            } catch (emailError) {
                logger.error('Failed to send welcome email:', emailError);
                // Don't fail registration if email fails
            }

            return {
                success: true,
                user: newUser,
                message: 'Registration successful! Please check your email to verify your account.'
            };
        } catch (error) {
            logger.error('Registration error:', error);
            throw error;
        }
    }

    // User login
    async login(email, password, deviceInfo = {}) {
        try {
            // Check if email and password exist
            if (!email || !password) {
                throw new Error('Please provide email and password');
            }

            // Check if user exists and get password
            const user = await User.findOne({ email }).select('+password');

            if (!user || !(await user.correctPassword(password, user.password))) {
                throw new Error('Incorrect email or password');
            }

            // Check if user is active
            if (!user.isActive) {
                throw new Error('Your account has been deactivated. Please contact support.');
            }

            // Update login tracking
            user.lastLogin = new Date();
            user.loginCount += 1;

            // Clean expired refresh tokens
            user.cleanExpiredRefreshTokens();

            await user.save({ validateBeforeSave: false });

            logger.info(`User logged in: ${user.email}`);

            return {
                success: true,
                user,
                message: 'Login successful'
            };
        } catch (error) {
            logger.error('Login error:', error);
            throw error;
        }
    }

    // User logout
    async logout(userId, refreshToken) {
        try {
            const user = await User.findById(userId);
            if (user && refreshToken) {
                user.removeRefreshToken(refreshToken);
                await user.save({ validateBeforeSave: false });
            }

            logger.info(`User logged out: ${userId}`);

            return {
                success: true,
                message: 'Logged out successfully'
            };
        } catch (error) {
            logger.error('Logout error:', error);
            throw error;
        }
    }

    // Get user profile
    async getProfile(userId) {
        try {
            const user = await User.findById(userId);
            if (!user) {
                throw new Error('User not found');
            }

            return {
                success: true,
                data: { user }
            };
        } catch (error) {
            logger.error('Get profile error:', error);
            throw error;
        }
    }

    // Update user profile
    async updateProfile(userId, updateData) {
        try {
            // Remove sensitive fields that shouldn't be updated here
            const allowedFields = [
                'firstName',
                'lastName',
                'username',
                'phone',
                'avatar',
                'timezone',
                'currency'
            ];

            const filteredData = {};
            Object.keys(updateData).forEach(key => {
                if (allowedFields.includes(key)) {
                    filteredData[key] = updateData[key];
                }
            });

            // Check if username is taken (if being updated)
            if (filteredData.username) {
                const existingUser = await User.findOne({
                    username: filteredData.username,
                    _id: { $ne: userId }
                });
                if (existingUser) {
                    throw new Error('Username is already taken');
                }
            }

            const user = await User.findByIdAndUpdate(
                userId,
                filteredData,
                {
                    new: true,
                    runValidators: true
                }
            );

            if (!user) {
                throw new Error('User not found');
            }

            logger.info(`Profile updated for user: ${user.email}`);

            return {
                success: true,
                data: { user },
                message: 'Profile updated successfully'
            };
        } catch (error) {
            logger.error('Update profile error:', error);
            throw error;
        }
    }

    // Password reset request
    async forgotPassword(email) {
        try {
            const user = await User.findOne({ email });
            if (!user) {
                throw new Error('There is no user with that email address');
            }

            // Generate reset token
            const resetToken = user.createPasswordResetToken();
            await user.save({ validateBeforeSave: false });

            // Send password reset email
            try {
                await emailService.sendPasswordResetEmail(user, resetToken);
                logger.info(`Password reset email sent to ${user.email}`);
            } catch (emailError) {
                user.passwordResetToken = undefined;
                user.passwordResetExpires = undefined;
                await user.save({ validateBeforeSave: false });

                logger.error('Failed to send password reset email:', emailError);
                throw new Error('There was an error sending the email. Please try again later.');
            }

            return {
                success: true,
                message: 'Password reset instructions sent to email'
            };
        } catch (error) {
            logger.error('Forgot password error:', error);
            throw error;
        }
    }

    // Reset password
    async resetPassword(token, newPassword) {
        try {
            // Get user based on the token
            const hashedToken = crypto.createHash('sha256').update(token).digest('hex');

            const user = await User.findOne({
                passwordResetToken: hashedToken,
                passwordResetExpires: { $gt: Date.now() }
            });

            if (!user) {
                throw new Error('Token is invalid or has expired');
            }

            // Set new password
            user.password = newPassword;
            user.passwordResetToken = undefined;
            user.passwordResetExpires = undefined;

            // Clear all refresh tokens
            user.refreshTokens = [];

            await user.save();

            logger.info(`Password reset for user: ${user.email}`);

            return {
                success: true,
                user,
                message: 'Password has been reset successfully'
            };
        } catch (error) {
            logger.error('Reset password error:', error);
            throw error;
        }
    }

    // Verify email
    async verifyEmail(token) {
        try {
            const hashedToken = crypto.createHash('sha256').update(token).digest('hex');

            const user = await User.findOne({
                emailVerificationToken: hashedToken,
                emailVerificationExpires: { $gt: Date.now() }
            });

            if (!user) {
                throw new Error('Token is invalid or has expired');
            }

            // Update user verification status
            user.isEmailVerified = true;
            user.emailVerificationToken = undefined;
            user.emailVerificationExpires = undefined;

            await user.save({ validateBeforeSave: false });

            logger.info(`Email verified for user: ${user.email}`);

            return {
                success: true,
                user,
                message: 'Email verified successfully'
            };
        } catch (error) {
            logger.error('Email verification error:', error);
            throw error;
        }
    }

    // Refresh token
    async refreshToken(userId, oldRefreshToken) {
        try {
            const user = await User.findById(userId);
            if (!user) {
                throw new Error('User not found');
            }

            // Remove old refresh token
            user.removeRefreshToken(oldRefreshToken);

            // Clean expired tokens
            user.cleanExpiredRefreshTokens();

            // Generate new tokens
            const newToken = this.signToken(user._id);
            const newRefreshToken = this.signRefreshToken(user._id);

            // Calculate refresh token expiration
            const refreshExpiresIn = process.env.JWT_REFRESH_EXPIRES_IN || '7d';
            const refreshExpires = new Date();
            if (refreshExpiresIn.includes('d')) {
                refreshExpires.setDate(refreshExpires.getDate() + parseInt(refreshExpiresIn));
            }

            // Add new refresh token
            user.addRefreshToken(newRefreshToken, refreshExpires, 'web');
            await user.save({ validateBeforeSave: false });

            logger.info(`Token refreshed for user: ${user.email}`);

            return {
                success: true,
                data: {
                    user,
                    token: newToken,
                    refreshToken: newRefreshToken
                },
                message: 'Token refreshed successfully'
            };
        } catch (error) {
            logger.error('Refresh token error:', error);
            throw error;
        }
    }

    // Resend email verification
    async resendEmailVerification(userId) {
        try {
            const user = await User.findById(userId);
            if (!user) {
                throw new Error('User not found');
            }

            if (user.isEmailVerified) {
                throw new Error('Email is already verified');
            }

            // Generate new verification token
            const verifyToken = user.createEmailVerificationToken();
            await user.save({ validateBeforeSave: false });

            // Send verification email
            await emailService.sendEmailVerificationEmail(user, verifyToken);

            logger.info(`Email verification resent to ${user.email}`);

            return {
                success: true,
                message: 'Verification email sent'
            };
        } catch (error) {
            logger.error('Resend verification error:', error);
            throw error;
        }
    }

    // Change password (when user is logged in)
    async changePassword(userId, currentPassword, newPassword) {
        try {
            const user = await User.findById(userId).select('+password');
            if (!user) {
                throw new Error('User not found');
            }

            // Check current password
            if (!(await user.correctPassword(currentPassword, user.password))) {
                throw new Error('Current password is incorrect');
            }

            // Update password
            user.password = newPassword;

            // Clear all refresh tokens to force re-login on other devices
            user.refreshTokens = [];

            await user.save();

            logger.info(`Password changed for user: ${user.email}`);

            return {
                success: true,
                message: 'Password changed successfully'
            };
        } catch (error) {
            logger.error('Change password error:', error);
            throw error;
        }
    }
}

module.exports = new AuthService();