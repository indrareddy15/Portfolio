const { validationResult } = require('express-validator');
const authService = require('../services/authService');
const logger = require('../utils/logger');

class AuthController {

    // 1. POST /auth/signup - User registration
    async signup(req, res) {
        try {
            // Check for validation errors
            const errors = validationResult(req);
            if (!errors.isEmpty()) {
                return res.status(400).json({
                    success: false,
                    message: 'Validation failed',
                    errors: errors.array()
                });
            }

            const { firstName, lastName, email, password, username, phone, timezone, currency } = req.body;

            const result = await authService.signup({
                firstName,
                lastName,
                email,
                password,
                username,
                phone,
                timezone,
                currency
            });

            // Send token if registration successful
            authService.createSendToken(result.user, 201, res, result.message);

        } catch (error) {
            logger.error('Signup controller error:', error);

            let message = 'Registration failed';
            let statusCode = 500;

            if (error.message.includes('already exists') ||
                error.message.includes('already taken') ||
                error.message.includes('duplicate')) {
                statusCode = 409; // Conflict
                message = error.message;
            } else if (error.message.includes('validation')) {
                statusCode = 400; // Bad Request
                message = error.message;
            }

            res.status(statusCode).json({
                success: false,
                message,
                error: process.env.NODE_ENV === 'development' ? error.message : undefined
            });
        }
    }

    // 2. POST /auth/login - User login
    async login(req, res) {
        try {
            // Check for validation errors
            const errors = validationResult(req);
            if (!errors.isEmpty()) {
                return res.status(400).json({
                    success: false,
                    message: 'Validation failed',
                    errors: errors.array()
                });
            }

            const { email, password } = req.body;
            const deviceInfo = {
                userAgent: req.get('User-Agent'),
                ip: req.ip
            };

            const result = await authService.login(email, password, deviceInfo);

            // Send token
            authService.createSendToken(result.user, 200, res, result.message);

        } catch (error) {
            logger.error('Login controller error:', error);

            let message = 'Login failed';
            let statusCode = 401;

            if (error.message.includes('Incorrect email or password')) {
                message = 'Invalid credentials';
            } else if (error.message.includes('deactivated')) {
                statusCode = 403;
                message = error.message;
            } else if (error.message.includes('provide email and password')) {
                statusCode = 400;
                message = error.message;
            }

            res.status(statusCode).json({
                success: false,
                message,
                error: process.env.NODE_ENV === 'development' ? error.message : undefined
            });
        }
    }

    // 3. POST /auth/logout - User logout
    async logout(req, res) {
        try {
            const refreshToken = req.body.refreshToken || req.cookies?.refreshToken;

            await authService.logout(req.user._id, refreshToken);

            // Clear cookies
            res.clearCookie('jwt');
            res.clearCookie('refreshToken');

            res.status(200).json({
                success: true,
                message: 'Logged out successfully'
            });

        } catch (error) {
            logger.error('Logout controller error:', error);
            res.status(500).json({
                success: false,
                message: 'Logout failed',
                error: process.env.NODE_ENV === 'development' ? error.message : undefined
            });
        }
    }

    // 4. GET /auth/profile - Get user profile
    async getProfile(req, res) {
        try {
            const result = await authService.getProfile(req.user._id);

            res.status(200).json(result);

        } catch (error) {
            logger.error('Get profile controller error:', error);

            let statusCode = 500;
            let message = 'Failed to fetch profile';

            if (error.message.includes('not found')) {
                statusCode = 404;
                message = 'User not found';
            }

            res.status(statusCode).json({
                success: false,
                message,
                error: process.env.NODE_ENV === 'development' ? error.message : undefined
            });
        }
    }

    // 5. PUT /auth/profile - Update user profile
    async updateProfile(req, res) {
        try {
            // Check for validation errors
            const errors = validationResult(req);
            if (!errors.isEmpty()) {
                return res.status(400).json({
                    success: false,
                    message: 'Validation failed',
                    errors: errors.array()
                });
            }

            const result = await authService.updateProfile(req.user._id, req.body);

            res.status(200).json(result);

        } catch (error) {
            logger.error('Update profile controller error:', error);

            let statusCode = 500;
            let message = 'Failed to update profile';

            if (error.message.includes('not found')) {
                statusCode = 404;
                message = 'User not found';
            } else if (error.message.includes('already taken') ||
                error.message.includes('duplicate')) {
                statusCode = 409;
                message = error.message;
            } else if (error.message.includes('validation')) {
                statusCode = 400;
                message = error.message;
            }

            res.status(statusCode).json({
                success: false,
                message,
                error: process.env.NODE_ENV === 'development' ? error.message : undefined
            });
        }
    }

    // 6. POST /auth/reset-password - Password reset (two endpoints)

    // POST /auth/forgot-password - Request password reset
    async forgotPassword(req, res) {
        try {
            // Check for validation errors
            const errors = validationResult(req);
            if (!errors.isEmpty()) {
                return res.status(400).json({
                    success: false,
                    message: 'Validation failed',
                    errors: errors.array()
                });
            }

            const { email } = req.body;
            const result = await authService.forgotPassword(email);

            res.status(200).json(result);

        } catch (error) {
            logger.error('Forgot password controller error:', error);

            let statusCode = 500;
            let message = 'Failed to process password reset request';

            if (error.message.includes('no user')) {
                // For security, don't reveal if email exists
                statusCode = 200;
                return res.status(200).json({
                    success: true,
                    message: 'If that email address is in our database, we will send you an email to reset your password.'
                });
            } else if (error.message.includes('error sending')) {
                statusCode = 500;
                message = 'Failed to send reset email. Please try again later.';
            }

            res.status(statusCode).json({
                success: false,
                message,
                error: process.env.NODE_ENV === 'development' ? error.message : undefined
            });
        }
    }

    // POST /auth/reset-password - Actual password reset
    async resetPassword(req, res) {
        try {
            // Check for validation errors
            const errors = validationResult(req);
            if (!errors.isEmpty()) {
                return res.status(400).json({
                    success: false,
                    message: 'Validation failed',
                    errors: errors.array()
                });
            }

            const { token, password } = req.body;
            const result = await authService.resetPassword(token, password);

            // Send new token after password reset
            authService.createSendToken(result.user, 200, res, result.message);

        } catch (error) {
            logger.error('Reset password controller error:', error);

            let statusCode = 400;
            let message = 'Password reset failed';

            if (error.message.includes('invalid') || error.message.includes('expired')) {
                message = 'Invalid or expired reset token';
            }

            res.status(statusCode).json({
                success: false,
                message,
                error: process.env.NODE_ENV === 'development' ? error.message : undefined
            });
        }
    }

    // 7. POST /auth/verify-email - Email verification
    async verifyEmail(req, res) {
        try {
            // Check for validation errors
            const errors = validationResult(req);
            if (!errors.isEmpty()) {
                return res.status(400).json({
                    success: false,
                    message: 'Validation failed',
                    errors: errors.array()
                });
            }

            const { token } = req.body;
            const result = await authService.verifyEmail(token);

            res.status(200).json(result);

        } catch (error) {
            logger.error('Verify email controller error:', error);

            let statusCode = 400;
            let message = 'Email verification failed';

            if (error.message.includes('invalid') || error.message.includes('expired')) {
                message = 'Invalid or expired verification token';
            }

            res.status(statusCode).json({
                success: false,
                message,
                error: process.env.NODE_ENV === 'development' ? error.message : undefined
            });
        }
    }

    // POST /auth/resend-verification - Resend email verification
    async resendEmailVerification(req, res) {
        try {
            const result = await authService.resendEmailVerification(req.user._id);

            res.status(200).json(result);

        } catch (error) {
            logger.error('Resend verification controller error:', error);

            let statusCode = 400;
            let message = 'Failed to resend verification email';

            if (error.message.includes('already verified')) {
                message = error.message;
            } else if (error.message.includes('not found')) {
                statusCode = 404;
                message = 'User not found';
            }

            res.status(statusCode).json({
                success: false,
                message,
                error: process.env.NODE_ENV === 'development' ? error.message : undefined
            });
        }
    }

    // 8. POST /auth/refresh-token - Token refresh
    async refreshToken(req, res) {
        try {
            const result = await authService.refreshToken(req.user._id, req.refreshToken);

            // Set new cookies
            const cookieOptions = {
                expires: new Date(
                    Date.now() + (process.env.JWT_COOKIE_EXPIRES_IN || 7) * 24 * 60 * 60 * 1000
                ),
                httpOnly: true,
                secure: process.env.NODE_ENV === 'production',
                sameSite: 'strict'
            };

            res.cookie('jwt', result.data.token, cookieOptions);
            res.cookie('refreshToken', result.data.refreshToken, cookieOptions);

            res.status(200).json(result);

        } catch (error) {
            logger.error('Refresh token controller error:', error);

            res.status(401).json({
                success: false,
                message: 'Token refresh failed',
                error: process.env.NODE_ENV === 'development' ? error.message : undefined
            });
        }
    }

    // Additional utility endpoints

    // POST /auth/change-password - Change password (when logged in)
    async changePassword(req, res) {
        try {
            // Check for validation errors
            const errors = validationResult(req);
            if (!errors.isEmpty()) {
                return res.status(400).json({
                    success: false,
                    message: 'Validation failed',
                    errors: errors.array()
                });
            }

            const { currentPassword, newPassword } = req.body;
            const result = await authService.changePassword(req.user._id, currentPassword, newPassword);

            // Clear all cookies to force re-login
            res.clearCookie('jwt');
            res.clearCookie('refreshToken');

            res.status(200).json(result);

        } catch (error) {
            logger.error('Change password controller error:', error);

            let statusCode = 400;
            let message = 'Failed to change password';

            if (error.message.includes('incorrect')) {
                statusCode = 401;
                message = 'Current password is incorrect';
            } else if (error.message.includes('not found')) {
                statusCode = 404;
                message = 'User not found';
            }

            res.status(statusCode).json({
                success: false,
                message,
                error: process.env.NODE_ENV === 'development' ? error.message : undefined
            });
        }
    }

    // GET /auth/me - Get current user (alias for getProfile)
    async getCurrentUser(req, res) {
        return this.getProfile(req, res);
    }
}

module.exports = new AuthController();