const express = require('express');
const rateLimit = require('express-rate-limit');
const authController = require('../controllers/authController');
const authMiddleware = require('../middleware/authMiddleware');
const authValidation = require('../middleware/authValidation');

const router = express.Router();

// Rate limiting configurations
const strictLimit = rateLimit({
    windowMs: 15 * 60 * 1000, // 15 minutes
    max: 5, // limit each IP to 5 requests per windowMs
    message: {
        success: false,
        message: 'Too many requests from this IP, please try again later.'
    },
    standardHeaders: true,
    legacyHeaders: false,
});

const authLimit = rateLimit({
    windowMs: 15 * 60 * 1000, // 15 minutes
    max: 10, // limit each IP to 10 requests per windowMs
    message: {
        success: false,
        message: 'Too many authentication attempts, please try again later.'
    },
    standardHeaders: true,
    legacyHeaders: false,
});

const generalLimit = rateLimit({
    windowMs: 15 * 60 * 1000, // 15 minutes
    max: 50, // limit each IP to 50 requests per windowMs
    message: {
        success: false,
        message: 'Too many requests, please try again later.'
    },
    standardHeaders: true,
    legacyHeaders: false,
});

// ============================================
// PUBLIC ROUTES (No Authentication Required)
// ============================================

/**
 * @route   POST /auth/signup
 * @desc    Register a new user
 * @access  Public
 * @body    { firstName, lastName, email, password, username?, phone?, timezone?, currency? }
 * @returns { success, message, data: { user, token, refreshToken } }
 */
router.post('/signup',
    authLimit,
    authValidation.signup,
    authController.signup
);

/**
 * @route   POST /auth/login
 * @desc    Authenticate user and get token
 * @access  Public
 * @body    { email, password }
 * @returns { success, message, data: { user, token, refreshToken } }
 */
router.post('/login',
    authLimit,
    authValidation.login,
    authController.login
);

/**
 * @route   POST /auth/forgot-password
 * @desc    Send password reset email
 * @access  Public
 * @body    { email }
 * @returns { success, message }
 */
router.post('/forgot-password',
    strictLimit,
    authValidation.forgotPassword,
    authController.forgotPassword
);

/**
 * @route   POST /auth/reset-password
 * @desc    Reset password with token
 * @access  Public
 * @body    { token, password }
 * @returns { success, message, data: { user, token, refreshToken } }
 */
router.post('/reset-password',
    strictLimit,
    authValidation.resetPassword,
    authController.resetPassword
);

/**
 * @route   POST /auth/verify-email
 * @desc    Verify email address with token
 * @access  Public
 * @body    { token }
 * @returns { success, message, data: { user } }
 */
router.post('/verify-email',
    generalLimit,
    authValidation.verifyEmail,
    authController.verifyEmail
);

/**
 * @route   POST /auth/refresh-token
 * @desc    Refresh access token using refresh token
 * @access  Public (but requires valid refresh token)
 * @body    { refreshToken }
 * @returns { success, message, data: { user, token, refreshToken } }
 */
router.post('/refresh-token',
    authLimit,
    authMiddleware.verifyRefreshToken,
    authController.refreshToken
);

// ============================================
// PROTECTED ROUTES (Authentication Required)
// ============================================

/**
 * @route   POST /auth/logout
 * @desc    Logout user and invalidate tokens
 * @access  Private
 * @body    { refreshToken? }
 * @returns { success, message }
 */
router.post('/logout',
    generalLimit,
    authMiddleware.protect,
    authController.logout
);

/**
 * @route   GET /auth/profile
 * @desc    Get current user profile
 * @access  Private
 * @returns { success, data: { user } }
 */
router.get('/profile',
    generalLimit,
    authMiddleware.protect,
    authController.getProfile
);

/**
 * @route   GET /auth/me
 * @desc    Get current user (alias for /profile)
 * @access  Private
 * @returns { success, data: { user } }
 */
router.get('/me',
    generalLimit,
    authMiddleware.protect,
    authController.getCurrentUser
);

/**
 * @route   PUT /auth/profile
 * @desc    Update user profile
 * @access  Private
 * @body    { firstName?, lastName?, username?, phone?, avatar?, timezone?, currency? }
 * @returns { success, message, data: { user } }
 */
router.put('/profile',
    generalLimit,
    authMiddleware.protect,
    authValidation.updateProfile,
    authController.updateProfile
);

/**
 * @route   PATCH /auth/profile
 * @desc    Update user profile (alternative method)
 * @access  Private
 * @body    { firstName?, lastName?, username?, phone?, avatar?, timezone?, currency? }
 * @returns { success, message, data: { user } }
 */
router.patch('/profile',
    generalLimit,
    authMiddleware.protect,
    authValidation.updateProfile,
    authController.updateProfile
);

/**
 * @route   POST /auth/change-password
 * @desc    Change password (when logged in)
 * @access  Private
 * @body    { currentPassword, newPassword }
 * @returns { success, message }
 */
router.post('/change-password',
    authLimit,
    authMiddleware.protect,
    authValidation.changePassword,
    authController.changePassword
);

/**
 * @route   POST /auth/resend-verification
 * @desc    Resend email verification
 * @access  Private
 * @returns { success, message }
 */
router.post('/resend-verification',
    strictLimit,
    authMiddleware.protect,
    authController.resendEmailVerification
);

// ============================================
// UTILITY ROUTES
// ============================================

/**
 * @route   GET /auth/check
 * @desc    Check if user is authenticated (utility endpoint)
 * @access  Private
 * @returns { success, data: { user } }
 */
router.get('/check',
    generalLimit,
    authMiddleware.protect,
    (req, res) => {
        res.status(200).json({
            success: true,
            data: { user: req.user },
            message: 'User is authenticated'
        });
    }
);

/**
 * @route   GET /auth/status
 * @desc    Get authentication status without failing
 * @access  Public (optional auth)
 * @returns { success, authenticated, data?: { user } }
 */
router.get('/status',
    generalLimit,
    authMiddleware.optionalAuth,
    (req, res) => {
        res.status(200).json({
            success: true,
            authenticated: !!req.user,
            data: req.user ? { user: req.user } : null
        });
    }
);

module.exports = router;