const { body } = require('express-validator');

const authValidation = {
    // Signup validation
    signup: [
        body('firstName')
            .trim()
            .notEmpty()
            .withMessage('First name is required')
            .isLength({ min: 2, max: 50 })
            .withMessage('First name must be between 2 and 50 characters')
            .matches(/^[a-zA-Z\s]+$/)
            .withMessage('First name can only contain letters and spaces'),

        body('lastName')
            .trim()
            .notEmpty()
            .withMessage('Last name is required')
            .isLength({ min: 2, max: 50 })
            .withMessage('Last name must be between 2 and 50 characters')
            .matches(/^[a-zA-Z\s]+$/)
            .withMessage('Last name can only contain letters and spaces'),

        body('email')
            .isEmail()
            .withMessage('Please provide a valid email')
            .normalizeEmail()
            .toLowerCase(),

        body('password')
            .isLength({ min: 6 })
            .withMessage('Password must be at least 6 characters long')
            .matches(/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)/)
            .withMessage('Password must contain at least one uppercase letter, one lowercase letter, and one number'),

        body('username')
            .optional()
            .trim()
            .isLength({ min: 3, max: 30 })
            .withMessage('Username must be between 3 and 30 characters')
            .matches(/^[a-zA-Z0-9_]+$/)
            .withMessage('Username can only contain letters, numbers, and underscores'),

        body('phone')
            .optional()
            .isMobilePhone()
            .withMessage('Please provide a valid phone number'),

        body('timezone')
            .optional()
            .isString()
            .withMessage('Timezone must be a valid string'),

        body('currency')
            .optional()
            .isIn(['USD', 'EUR', 'GBP', 'JPY', 'AUD', 'CAD', 'CHF', 'NZD'])
            .withMessage('Currency must be one of: USD, EUR, GBP, JPY, AUD, CAD, CHF, NZD')
    ],

    // Login validation
    login: [
        body('email')
            .isEmail()
            .withMessage('Please provide a valid email')
            .normalizeEmail()
            .toLowerCase(),

        body('password')
            .notEmpty()
            .withMessage('Password is required')
    ],

    // Update profile validation
    updateProfile: [
        body('firstName')
            .optional()
            .trim()
            .isLength({ min: 2, max: 50 })
            .withMessage('First name must be between 2 and 50 characters')
            .matches(/^[a-zA-Z\s]+$/)
            .withMessage('First name can only contain letters and spaces'),

        body('lastName')
            .optional()
            .trim()
            .isLength({ min: 2, max: 50 })
            .withMessage('Last name must be between 2 and 50 characters')
            .matches(/^[a-zA-Z\s]+$/)
            .withMessage('Last name can only contain letters and spaces'),

        body('username')
            .optional()
            .trim()
            .isLength({ min: 3, max: 30 })
            .withMessage('Username must be between 3 and 30 characters')
            .matches(/^[a-zA-Z0-9_]+$/)
            .withMessage('Username can only contain letters, numbers, and underscores'),

        body('phone')
            .optional()
            .isMobilePhone()
            .withMessage('Please provide a valid phone number'),

        body('avatar')
            .optional()
            .isURL()
            .withMessage('Avatar must be a valid URL'),

        body('timezone')
            .optional()
            .isString()
            .withMessage('Timezone must be a valid string'),

        body('currency')
            .optional()
            .isIn(['USD', 'EUR', 'GBP', 'JPY', 'AUD', 'CAD', 'CHF', 'NZD'])
            .withMessage('Currency must be one of: USD, EUR, GBP, JPY, AUD, CAD, CHF, NZD')
    ],

    // Forgot password validation
    forgotPassword: [
        body('email')
            .isEmail()
            .withMessage('Please provide a valid email')
            .normalizeEmail()
            .toLowerCase()
    ],

    // Reset password validation
    resetPassword: [
        body('token')
            .notEmpty()
            .withMessage('Reset token is required'),

        body('password')
            .isLength({ min: 6 })
            .withMessage('Password must be at least 6 characters long')
            .matches(/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)/)
            .withMessage('Password must contain at least one uppercase letter, one lowercase letter, and one number')
    ],

    // Email verification validation
    verifyEmail: [
        body('token')
            .notEmpty()
            .withMessage('Verification token is required')
    ],

    // Change password validation
    changePassword: [
        body('currentPassword')
            .notEmpty()
            .withMessage('Current password is required'),

        body('newPassword')
            .isLength({ min: 6 })
            .withMessage('New password must be at least 6 characters long')
            .matches(/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)/)
            .withMessage('New password must contain at least one uppercase letter, one lowercase letter, and one number')
            .custom((value, { req }) => {
                if (value === req.body.currentPassword) {
                    throw new Error('New password must be different from current password');
                }
                return true;
            })
    ]
};

module.exports = authValidation;