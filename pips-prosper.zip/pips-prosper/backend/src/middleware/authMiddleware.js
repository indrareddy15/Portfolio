const jwt = require('jsonwebtoken');
const { promisify } = require('util');
const User = require('../models/authModel');
const logger = require('../utils/logger');

// Protect routes - require authentication
const protect = async (req, res, next) => {
    try {
        // 1) Get token from header
        let token;
        if (req.headers.authorization && req.headers.authorization.startsWith('Bearer')) {
            token = req.headers.authorization.split(' ')[1];
        }

        if (!token) {
            return res.status(401).json({
                success: false,
                message: 'You are not logged in! Please log in to get access.'
            });
        }

        // 2) Verify token
        const decoded = await promisify(jwt.verify)(token, process.env.JWT_SECRET);

        // 3) Check if user still exists
        const currentUser = await User.findById(decoded.id).select('+password');
        if (!currentUser) {
            return res.status(401).json({
                success: false,
                message: 'The user belonging to this token does no longer exist.'
            });
        }

        // 4) Check if user is active
        if (!currentUser.isActive) {
            return res.status(401).json({
                success: false,
                message: 'Your account has been deactivated. Please contact support.'
            });
        }

        // 5) Check if user changed password after the token was issued
        if (currentUser.changedPasswordAfter(decoded.iat)) {
            return res.status(401).json({
                success: false,
                message: 'User recently changed password! Please log in again.'
            });
        }

        // Grant access to protected route
        req.user = currentUser;
        next();
    } catch (error) {
        logger.error('Authentication error:', error);

        if (error.name === 'JsonWebTokenError') {
            return res.status(401).json({
                success: false,
                message: 'Invalid token. Please log in again!'
            });
        } else if (error.name === 'TokenExpiredError') {
            return res.status(401).json({
                success: false,
                message: 'Your token has expired! Please log in again.'
            });
        }

        return res.status(500).json({
            success: false,
            message: 'Authentication failed. Please try again.'
        });
    }
};

// Restrict to specific roles
const restrictTo = (...roles) => {
    return (req, res, next) => {
        if (!roles.includes(req.user.role)) {
            return res.status(403).json({
                success: false,
                message: 'You do not have permission to perform this action'
            });
        }
        next();
    };
};

// Optional authentication - doesn't fail if no token
const optionalAuth = async (req, res, next) => {
    try {
        let token;
        if (req.headers.authorization && req.headers.authorization.startsWith('Bearer')) {
            token = req.headers.authorization.split(' ')[1];
        }

        if (token) {
            const decoded = await promisify(jwt.verify)(token, process.env.JWT_SECRET);
            const currentUser = await User.findById(decoded.id);

            if (currentUser && currentUser.isActive && !currentUser.changedPasswordAfter(decoded.iat)) {
                req.user = currentUser;
            }
        }

        next();
    } catch (error) {
        // If optional auth fails, just continue without user
        next();
    }
};

// Verify refresh token
const verifyRefreshToken = async (req, res, next) => {
    try {
        const { refreshToken } = req.body;

        if (!refreshToken) {
            return res.status(401).json({
                success: false,
                message: 'Refresh token is required'
            });
        }

        // Verify refresh token
        const decoded = await promisify(jwt.verify)(refreshToken, process.env.JWT_REFRESH_SECRET || process.env.JWT_SECRET);

        // Find user and check if refresh token exists and is valid
        const user = await User.findById(decoded.id);
        if (!user) {
            return res.status(401).json({
                success: false,
                message: 'Invalid refresh token'
            });
        }

        // Check if refresh token exists in user's token list
        const tokenExists = user.refreshTokens.some(rt =>
            rt.token === refreshToken && rt.expiresAt > new Date()
        );

        if (!tokenExists) {
            return res.status(401).json({
                success: false,
                message: 'Invalid or expired refresh token'
            });
        }

        // Clean expired tokens
        user.cleanExpiredRefreshTokens();
        await user.save();

        req.user = user;
        req.refreshToken = refreshToken;
        next();
    } catch (error) {
        logger.error('Refresh token verification error:', error);
        return res.status(401).json({
            success: false,
            message: 'Invalid refresh token'
        });
    }
};

module.exports = {
    protect,
    restrictTo,
    optionalAuth,
    verifyRefreshToken
};