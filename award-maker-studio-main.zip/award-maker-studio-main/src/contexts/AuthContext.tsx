import { createContext, useContext, useEffect, useState, ReactNode } from 'react';
import { useNavigate } from 'react-router-dom';
import { mockLogin, mockSignup, mockLogout, getCurrentMockUser, MockUser } from '@/data/mockAuth';

interface AuthContextType {
  user: MockUser | null;
  session: any | null;
  isAdmin: boolean;
  loading: boolean;
  signIn: (email: string, password: string) => Promise<{ error: any }>;
  signUp: (email: string, password: string, fullName: string) => Promise<{ error: any }>;
  signOut: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<MockUser | null>(null);
  const [session, setSession] = useState<any | null>(null);
  const [isAdmin, setIsAdmin] = useState(false);
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();

  useEffect(() => {
    // Check for existing mock user on mount
    const currentUser = getCurrentMockUser();
    if (currentUser) {
      setUser(currentUser);
      setSession({ user: currentUser });
      setIsAdmin(currentUser.role === 'admin');
    }
    setLoading(false);
  }, []);

  const signIn = async (email: string, password: string) => {
    const { user, error } = mockLogin(email, password);
    if (user) {
      setUser(user);
      setSession({ user });
      setIsAdmin(user.role === 'admin');
    }
    return { error: error ? { message: error } : null };
  };

  const signUp = async (email: string, password: string, fullName: string) => {
    const { user, error } = mockSignup(email, password, fullName);
    if (user) {
      setUser(user);
      setSession({ user });
      setIsAdmin(user.role === 'admin');
    }
    return { error: error ? { message: error } : null };
  };

  const signOut = async () => {
    mockLogout();
    setUser(null);
    setSession(null);
    setIsAdmin(false);
    navigate('/');
  };

  return (
    <AuthContext.Provider value={{ user, session, isAdmin, loading, signIn, signUp, signOut }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}