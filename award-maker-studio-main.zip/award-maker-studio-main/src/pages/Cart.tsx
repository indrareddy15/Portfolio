import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Navbar } from '@/components/Navbar';
import { Footer } from '@/components/Footer';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Trash2 } from 'lucide-react';

const Cart = () => {
  const [cartItems, setCartItems] = useState<any[]>([]);
  const navigate = useNavigate();

  useEffect(() => {
    loadCart();
  }, []);

  const loadCart = () => {
    const cart = JSON.parse(localStorage.getItem('cart') || '[]');
    setCartItems(cart);
  };

  const removeItem = (index: number) => {
    const cart = JSON.parse(localStorage.getItem('cart') || '[]');
    cart.splice(index, 1);
    localStorage.setItem('cart', JSON.stringify(cart));
    
    // Trigger custom event for real-time cart update
    window.dispatchEvent(new Event('cartUpdated'));
    
    loadCart();
  };

  const total = cartItems.reduce((sum, item) => sum + parseFloat(item.variant.price), 0);

  return (
    <div className="min-h-screen flex flex-col noise-texture">
      <Navbar />
      <main className="flex-1 pt-24 pb-16">
        <div className="container px-4 max-w-4xl">
          <h1 className="text-3xl font-bold mb-8">Shopping Cart</h1>

          {cartItems.length === 0 ? (
            <Card className="glass-card">
              <CardContent className="pt-6 text-center py-12">
                <p className="text-muted-foreground mb-4">Your cart is empty</p>
                <Button onClick={() => navigate('/products')}>Browse Products</Button>
              </CardContent>
            </Card>
          ) : (
            <div className="space-y-6">
              {cartItems.map((item, index) => (
                <Card key={index} className="glass-card">
                  <CardContent className="pt-6">
                    <div className="flex justify-between items-start">
                      <div className="flex-1">
                        <h3 className="font-bold text-lg">{item.product.name}</h3>
                        <p className="text-sm text-muted-foreground">{item.variant.size}</p>
                        <p className="text-sm text-muted-foreground mt-1">
                          Certificate: {item.certificate.name}
                        </p>
                        {item.notes && (
                          <p className="text-sm mt-1">Notes: {item.notes}</p>
                        )}
                      </div>
                      <div className="text-right">
                        <p className="font-bold text-lg">₹{item.variant.price}</p>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => removeItem(index)}
                          className="mt-2"
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}

              <Card className="glass-card">
                <CardContent className="pt-6">
                  <div className="flex justify-between items-center text-lg font-bold">
                    <span>Total:</span>
                    <span>₹{total.toFixed(2)}</span>
                  </div>
                  <Button
                    onClick={() => navigate('/checkout')}
                    size="lg"
                    className="w-full mt-4"
                  >
                    Proceed to Checkout
                  </Button>
                </CardContent>
              </Card>
            </div>
          )}
        </div>
      </main>
      <Footer />
    </div>
  );
};

export default Cart;