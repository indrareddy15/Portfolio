import { useState, useEffect } from 'react';
import { mockProducts } from '@/data/mockProducts';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { useToast } from '@/hooks/use-toast';
import { Loader2, Plus, Edit, Trash, Eye, EyeOff } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { Switch } from '@/components/ui/switch';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from '@/components/ui/tabs';

interface Product {
  id: string;
  name: string;
  slug: string;
  description: string | null;
  material: string | null;
  meta_title: string | null;
  meta_description: string | null;
  is_active: boolean;
  created_at?: string;
  updated_at?: string;
}

interface ProductVariant {
  id: string;
  product_id: string;
  size: string;
  sku: string;
  price: number;
  compare_at_price: number | null;
  is_available: boolean;
}

interface ProductImage {
  id: string;
  product_id: string;
  image_url: string;
  alt_text: string | null;
  display_order: number;
}

const AdminProducts = () => {
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);
  const [selectedProduct, setSelectedProduct] = useState<string | null>(null);
  const [variants, setVariants] = useState<ProductVariant[]>([]);
  const [images, setImages] = useState<ProductImage[]>([]);
  const { toast } = useToast();

  const [formData, setFormData] = useState({
    name: '',
    slug: '',
    description: '',
    material: '25mm Premium Clear Acrylic',
    meta_title: '',
    meta_description: '',
    is_active: true
  });

  const [variantForm, setVariantForm] = useState({
    size: '',
    sku: '',
    price: '',
    compare_at_price: '',
    is_available: true
  });

  useEffect(() => {
    // Load mock products
    setTimeout(() => {
      setProducts(mockProducts as any);
      setLoading(false);
    }, 300);
  }, []);

  useEffect(() => {
    if (selectedProduct) {
      const product = mockProducts.find(p => p.id === selectedProduct);
      if (product) {
        setVariants(product.product_variants as any);
      }
    }
  }, [selectedProduct]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      toast({ title: 'Success', description: 'Product would be saved (mock data)' });
      setDialogOpen(false);
      resetForm();
    } catch (error: any) {
      toast({ title: 'Error', description: error.message, variant: 'destructive' });
    }
  };

  const handleDeleteProduct = async (id: string) => {
    if (!confirm('Are you sure you want to delete this product?')) return;
    try {
      toast({ title: 'Success', description: 'Product would be deleted (mock data)' });
    } catch (error: any) {
      toast({ title: 'Error', description: error.message, variant: 'destructive' });
    }
  };

  const toggleActive = async (id: string, isActive: boolean) => {
    try {
      toast({ title: 'Success', description: 'Status would be toggled (mock data)' });
    } catch (error: any) {
      toast({ title: 'Error', description: error.message, variant: 'destructive' });
    }
  };

  const handleAddVariant = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedProduct) return;
    try {
      toast({ title: 'Success', description: 'Variant would be added (mock data)' });
      resetVariantForm();
    } catch (error: any) {
      toast({ title: 'Error', description: error.message, variant: 'destructive' });
    }
  };

  const handleDeleteVariant = async (id: string) => {
    if (!confirm('Delete this variant?')) return;
    try {
      toast({ title: 'Success', description: 'Variant would be deleted (mock data)' });
    } catch (error: any) {
      toast({ title: 'Error', description: error.message, variant: 'destructive' });
    }
  };

  const resetForm = () => {
    setFormData({
      name: '',
      slug: '',
      description: '',
      material: '25mm Premium Clear Acrylic',
      meta_title: '',
      meta_description: '',
      is_active: true
    });
    setEditingProduct(null);
  };

  const resetVariantForm = () => {
    setVariantForm({
      size: '',
      sku: '',
      price: '',
      compare_at_price: '',
      is_available: true
    });
  };

  const openEditDialog = (product: Product) => {
    setEditingProduct(product);
    setFormData({
      name: product.name,
      slug: product.slug,
      description: product.description || '',
      material: product.material || '25mm Premium Clear Acrylic',
      meta_title: product.meta_title || '',
      meta_description: product.meta_description || '',
      is_active: product.is_active
    });
    setDialogOpen(true);
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div>
      <div className="flex justify-between items-center mb-8">
        <h1 className="text-3xl font-bold">Products Management</h1>
        <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
          <DialogTrigger asChild>
            <Button onClick={resetForm}>
              <Plus className="h-4 w-4 mr-2" />
              Add Product
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>{editingProduct ? 'Edit Product' : 'Create New Product'}</DialogTitle>
            </DialogHeader>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <Label htmlFor="name">Product Name</Label>
                <Input
                  id="name"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  required
                />
              </div>
              <div>
                <Label htmlFor="slug">Slug</Label>
                <Input
                  id="slug"
                  value={formData.slug}
                  onChange={(e) => setFormData({ ...formData, slug: e.target.value })}
                  placeholder="product-slug"
                  required
                />
              </div>
              <div>
                <Label htmlFor="material">Material</Label>
                <Input
                  id="material"
                  value={formData.material}
                  onChange={(e) => setFormData({ ...formData, material: e.target.value })}
                />
              </div>
              <div>
                <Label htmlFor="description">Description</Label>
                <Textarea
                  id="description"
                  value={formData.description}
                  onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                  rows={4}
                />
              </div>
              <div>
                <Label htmlFor="meta_title">Meta Title</Label>
                <Input
                  id="meta_title"
                  value={formData.meta_title}
                  onChange={(e) => setFormData({ ...formData, meta_title: e.target.value })}
                />
              </div>
              <div>
                <Label htmlFor="meta_description">Meta Description</Label>
                <Textarea
                  id="meta_description"
                  value={formData.meta_description}
                  onChange={(e) => setFormData({ ...formData, meta_description: e.target.value })}
                />
              </div>
              <div className="flex items-center space-x-2">
                <Switch
                  id="is_active"
                  checked={formData.is_active}
                  onCheckedChange={(checked) => setFormData({ ...formData, is_active: checked })}
                />
                <Label htmlFor="is_active">Active</Label>
              </div>
              <Button type="submit" className="w-full">
                {editingProduct ? 'Update Product' : 'Create Product'}
              </Button>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      <div className="grid gap-4">
        {products.map((product) => (
          <Card key={product.id} className="p-6">
            <div className="flex justify-between items-start mb-4">
              <div className="flex-1">
                <div className="flex items-center gap-3 mb-2">
                  <h3 className="text-xl font-bold">{product.name}</h3>
                  {product.is_active ? (
                    <Badge variant="default">Active</Badge>
                  ) : (
                    <Badge variant="secondary">Inactive</Badge>
                  )}
                </div>
                <p className="text-sm text-muted-foreground">/{product.slug}</p>
                {product.description && (
                  <p className="text-sm text-muted-foreground mt-2">{product.description.substring(0, 100)}...</p>
                )}
              </div>
              <div className="flex gap-2">
                <Switch
                  checked={product.is_active}
                  onCheckedChange={() => toggleActive(product.id, product.is_active)}
                />
                <Button
                  size="sm"
                  variant="outline"
                  onClick={() => setSelectedProduct(selectedProduct === product.id ? null : product.id)}
                >
                  {selectedProduct === product.id ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                </Button>
                <Button size="sm" variant="outline" onClick={() => openEditDialog(product)}>
                  <Edit className="h-4 w-4" />
                </Button>
                <Button size="sm" variant="destructive" onClick={() => handleDeleteProduct(product.id)}>
                  <Trash className="h-4 w-4" />
                </Button>
              </div>
            </div>

            {selectedProduct === product.id && (
              <Tabs defaultValue="variants" className="mt-4">
                <TabsList>
                  <TabsTrigger value="variants">Variants</TabsTrigger>
                  <TabsTrigger value="images">Images</TabsTrigger>
                </TabsList>
                
                <TabsContent value="variants" className="space-y-4">
                  <Card className="p-4">
                    <h4 className="font-semibold mb-4">Add Variant</h4>
                    <form onSubmit={handleAddVariant} className="grid grid-cols-2 gap-4">
                      <div>
                        <Label>Size</Label>
                        <Input
                          value={variantForm.size}
                          onChange={(e) => setVariantForm({ ...variantForm, size: e.target.value })}
                          placeholder="e.g., A4, 6x8"
                          required
                        />
                      </div>
                      <div>
                        <Label>SKU</Label>
                        <Input
                          value={variantForm.sku}
                          onChange={(e) => setVariantForm({ ...variantForm, sku: e.target.value })}
                          required
                        />
                      </div>
                      <div>
                        <Label>Price (₹)</Label>
                        <Input
                          type="number"
                          step="0.01"
                          value={variantForm.price}
                          onChange={(e) => setVariantForm({ ...variantForm, price: e.target.value })}
                          required
                        />
                      </div>
                      <div>
                        <Label>Compare Price (₹)</Label>
                        <Input
                          type="number"
                          step="0.01"
                          value={variantForm.compare_at_price}
                          onChange={(e) => setVariantForm({ ...variantForm, compare_at_price: e.target.value })}
                        />
                      </div>
                      <div className="col-span-2 flex items-center space-x-2">
                        <Switch
                          checked={variantForm.is_available}
                          onCheckedChange={(checked) => setVariantForm({ ...variantForm, is_available: checked })}
                        />
                        <Label>Available</Label>
                      </div>
                      <div className="col-span-2">
                        <Button type="submit" className="w-full">Add Variant</Button>
                      </div>
                    </form>
                  </Card>

                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Size</TableHead>
                        <TableHead>SKU</TableHead>
                        <TableHead>Price</TableHead>
                        <TableHead>Status</TableHead>
                        <TableHead>Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {variants.map((variant) => (
                        <TableRow key={variant.id}>
                          <TableCell>{variant.size}</TableCell>
                          <TableCell>{variant.sku}</TableCell>
                          <TableCell>
                            ₹{variant.price}
                            {variant.compare_at_price && (
                              <span className="text-muted-foreground line-through ml-2">
                                ₹{variant.compare_at_price}
                              </span>
                            )}
                          </TableCell>
                          <TableCell>
                            <Badge variant={variant.is_available ? 'default' : 'secondary'}>
                              {variant.is_available ? 'Available' : 'Unavailable'}
                            </Badge>
                          </TableCell>
                          <TableCell>
                            <Button
                              size="sm"
                              variant="destructive"
                              onClick={() => handleDeleteVariant(variant.id)}
                            >
                              <Trash className="h-4 w-4" />
                            </Button>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </TabsContent>

                <TabsContent value="images">
                  <p className="text-sm text-muted-foreground">
                    Image management: {images.length} image(s)
                  </p>
                </TabsContent>
              </Tabs>
            )}
          </Card>
        ))}
      </div>
    </div>
  );
};

export default AdminProducts;