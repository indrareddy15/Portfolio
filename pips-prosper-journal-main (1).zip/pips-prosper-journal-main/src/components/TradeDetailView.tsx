import { useState, useEffect, useCallback } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Separator } from "@/components/ui/separator";
import { 
  TrendingUp, 
  TrendingDown, 
  Calendar, 
  DollarSign, 
  Target, 
  Clock,
  BarChart3,
  Globe,
  RefreshCw,
  Copy,
  Wifi,
  WifiOff
} from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/components/ui/use-toast";
import { useAuth } from "@/hooks/useAuth";

interface TradeDetailViewProps {
  trade: any;
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export function TradeDetailView({ trade, open, onOpenChange }: TradeDetailViewProps) {
  const [tradeHistory, setTradeHistory] = useState<any[]>([]);
  const [relatedTrades, setRelatedTrades] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);
  const [lastUpdate, setLastUpdate] = useState(new Date());
  const [isRealTimeConnected, setIsRealTimeConnected] = useState(false);
  const { toast } = useToast();
  const { user } = useAuth();

  const loadTradeData = useCallback(async () => {
    if (!trade?.id || !user?.id) return;

    setLoading(true);
    try {
      // Load trade history from the new trade_history table
      const { data: historyData, error: historyError } = await supabase
        .from('trade_history')
        .select('*')
        .eq('trade_id', trade.id)
        .eq('user_id', user.id)
        .order('created_at', { ascending: false });

      if (!historyError && historyData) {
        setTradeHistory(historyData);
      }

      // Load related trades (same instrument, same day, or same strategy)
      const { data: relatedData, error: relatedError } = await supabase
        .from('trades')
        .select('*')
        .eq('user_id', user.id)
        .neq('id', trade.id)
        .or(`instrument.eq.${trade.instrument},strategy_id.eq.${trade.strategy_id}`)
        .limit(5)
        .order('opened_at', { ascending: false });

      if (!relatedError && relatedData) {
        setRelatedTrades(relatedData);
      }

      setLastUpdate(new Date());
    } catch (error: any) {
      console.error('Error loading trade data:', error);
      toast({
        variant: "destructive",
        title: "Error loading trade details",
        description: error.message,
      });
    } finally {
      setLoading(false);
    }
  }, [trade?.id, user?.id, toast]);

  // Real-time updates for this specific trade and its history
  useEffect(() => {
    if (!trade?.id || !user?.id || !open) return;

    const channel = supabase
      .channel(`trade-detail-${trade.id}`)
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'trades',
          filter: `id=eq.${trade.id}`
        },
        (payload) => {
          console.log('Real-time trade update:', payload);
          // Refresh trade data
          loadTradeData();
          
          if (payload.eventType === 'UPDATE') {
            toast({
              title: "Trade Updated",
              description: "This trade has been modified in real-time",
              duration: 3000,
            });
          }
        }
      )
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'trade_history',
          filter: `trade_id=eq.${trade.id}`
        },
        (payload) => {
          console.log('Real-time trade history update:', payload);
          // Refresh only the history data
          loadTradeData();
          
          if (payload.eventType === 'INSERT') {
            const action = payload.new?.action;
            let message = "Trade history updated";
            
            switch (action) {
              case 'created':
                message = "Trade was created";
                break;
              case 'updated':
                message = "Trade was modified";
                break;
              case 'closed':
                message = "Trade was closed";
                break;
              case 'deleted':
                message = "Trade was deleted";
                break;
            }
            
            toast({
              title: "History Updated",
              description: message,
              duration: 2000,
            });
          }
        }
      )
      .subscribe((status) => {
        if (status === 'SUBSCRIBED') {
          setIsRealTimeConnected(true);
          console.log('Trade detail real-time connection established');
        } else if (status === 'CHANNEL_ERROR') {
          setIsRealTimeConnected(false);
          console.error('Trade detail real-time connection failed');
        }
      });

    return () => {
      supabase.removeChannel(channel);
      setIsRealTimeConnected(false);
    };
  }, [trade?.id, user?.id, open, loadTradeData, toast]);

  useEffect(() => {
    if (open) {
      loadTradeData();
    }
  }, [open, loadTradeData]);

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 2,
    }).format(amount);
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleString();
  };

  const copyTradeId = () => {
    navigator.clipboard.writeText(trade.id);
    toast({
      title: "Copied",
      description: "Trade ID copied to clipboard",
      duration: 1000,
    });
  };

  const refreshData = () => {
    loadTradeData();
    toast({
      title: "Refreshed",
      description: "Trade data has been refreshed",
      duration: 1000,
    });
  };

  if (!trade) return null;

  const isProfitable = (trade.pnl || 0) > 0;
  const isOpen = !trade.closed_at;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <div className="flex items-center justify-between">
            <DialogTitle className="flex items-center gap-3">
              <div className="flex items-center gap-2">
                {isProfitable ? (
                  <TrendingUp className="h-5 w-5 text-success" />
                ) : (
                  <TrendingDown className="h-5 w-5 text-danger" />
                )}
                <span>{trade.instrument} Trade Details</span>
              </div>
              <Badge variant={isOpen ? "default" : "secondary"}>
                {isOpen ? "Open" : "Closed"}
              </Badge>
            </DialogTitle>
            
            <div className="flex items-center gap-2">
              {/* Real-time Status */}
              <div className="flex items-center gap-1.5 px-2 py-1 rounded-lg border text-xs">
                {isRealTimeConnected ? (
                  <>
                    <Wifi className="h-3 w-3 text-success animate-pulse" />
                    <span className="text-success font-medium">LIVE</span>
                  </>
                ) : (
                  <>
                    <WifiOff className="h-3 w-3 text-danger" />
                    <span className="text-danger font-medium">OFFLINE</span>
                  </>
                )}
              </div>
              
              <Button variant="ghost" size="sm" onClick={refreshData}>
                <RefreshCw className="h-4 w-4" />
              </Button>
            </div>
          </div>
          
          <div className="text-sm text-muted-foreground">
            Last updated: {lastUpdate.toLocaleString()}
          </div>
        </DialogHeader>

        <Tabs defaultValue="overview" className="space-y-4">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="analysis">Analysis</TabsTrigger>
            <TabsTrigger value="history">History</TabsTrigger>
            <TabsTrigger value="related">Related</TabsTrigger>
          </TabsList>

          <TabsContent value="overview" className="space-y-4">
            {/* Trade Summary Cards */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium flex items-center gap-2">
                    <DollarSign className="h-4 w-4 text-primary" />
                    P&L
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className={`text-2xl font-bold ${isProfitable ? 'text-success' : 'text-danger'}`}>
                    {formatCurrency(trade.pnl || 0)}
                  </div>
                  <div className="text-xs text-muted-foreground">
                    {isProfitable ? 'Profit' : 'Loss'}
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium flex items-center gap-2">
                    <Target className="h-4 w-4 text-primary" />
                    Position Size
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">
                    {trade.lot_size || 0}
                  </div>
                  <div className="text-xs text-muted-foreground">
                    Lots
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium flex items-center gap-2">
                    <Clock className="h-4 w-4 text-primary" />
                    Duration
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">
                    {trade.closed_at 
                      ? Math.round((new Date(trade.closed_at).getTime() - new Date(trade.opened_at).getTime()) / (1000 * 60 * 60)) 
                      : Math.round((Date.now() - new Date(trade.opened_at).getTime()) / (1000 * 60 * 60))
                    }h
                  </div>
                  <div className="text-xs text-muted-foreground">
                    {isOpen ? 'Running' : 'Total Duration'}
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Trade Details */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Trade Information</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Trade ID:</span>
                    <div className="flex items-center gap-2">
                      <code className="text-xs bg-muted px-2 py-1 rounded">{trade.id.slice(0, 8)}...</code>
                      <Button variant="ghost" size="sm" onClick={copyTradeId}>
                        <Copy className="h-3 w-3" />
                      </Button>
                    </div>
                  </div>
                  <Separator />
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Instrument:</span>
                    <Badge variant="outline">{trade.instrument}</Badge>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Direction:</span>
                    <Badge variant={trade.direction === 'buy' ? 'default' : 'secondary'}>
                      {trade.direction?.toUpperCase()}
                    </Badge>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Entry Price:</span>
                    <span className="font-mono">{trade.entry_price}</span>
                  </div>
                  {trade.exit_price && (
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Exit Price:</span>
                      <span className="font-mono">{trade.exit_price}</span>
                    </div>
                  )}
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Stop Loss:</span>
                    <span className="font-mono">{trade.stop_loss || 'N/A'}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Take Profit:</span>
                    <span className="font-mono">{trade.take_profit || 'N/A'}</span>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Timing & Status</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Opened At:</span>
                    <div className="text-right">
                      <div className="text-sm">{formatDate(trade.opened_at)}</div>
                    </div>
                  </div>
                  {trade.closed_at && (
                    <>
                      <Separator />
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">Closed At:</span>
                        <div className="text-right">
                          <div className="text-sm">{formatDate(trade.closed_at)}</div>
                        </div>
                      </div>
                    </>
                  )}
                  <Separator />
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Strategy:</span>
                    <Badge variant="outline">{trade.strategy || 'No Strategy'}</Badge>
                  </div>
                  {trade.notes && (
                    <>
                      <Separator />
                      <div>
                        <span className="text-muted-foreground">Notes:</span>
                        <div className="mt-1 p-2 bg-muted rounded-md text-sm">
                          {trade.notes}
                        </div>
                      </div>
                    </>
                  )}
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="analysis" className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <BarChart3 className="h-4 w-4" />
                    Risk Analysis
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  {trade.entry_price && trade.stop_loss && (
                    <div className="flex justify-between items-center p-3 bg-muted/20 rounded-lg">
                      <span className="text-muted-foreground">Risk Amount:</span>
                      <div className="text-right">
                        <div className="font-mono font-semibold">
                          {Math.abs(trade.entry_price - trade.stop_loss).toFixed(4)}
                        </div>
                        <div className="text-xs text-muted-foreground">pips/points</div>
                      </div>
                    </div>
                  )}
                  {trade.entry_price && trade.take_profit && (
                    <div className="flex justify-between items-center p-3 bg-muted/20 rounded-lg">
                      <span className="text-muted-foreground">Reward Amount:</span>
                      <div className="text-right">
                        <div className="font-mono font-semibold">
                          {Math.abs(trade.take_profit - trade.entry_price).toFixed(4)}
                        </div>
                        <div className="text-xs text-muted-foreground">pips/points</div>
                      </div>
                    </div>
                  )}
                  {trade.entry_price && trade.stop_loss && trade.take_profit && (
                    <div className="flex justify-between items-center p-3 bg-primary/5 rounded-lg border border-primary/20">
                      <span className="text-muted-foreground">Risk:Reward Ratio:</span>
                      <Badge variant="outline" className="text-base px-3 py-1">
                        1:{(Math.abs(trade.take_profit - trade.entry_price) / Math.abs(trade.entry_price - trade.stop_loss)).toFixed(2)}
                      </Badge>
                    </div>
                  )}
                  
                  {/* Risk Percentage */}
                  {trade.risk_percent && (
                    <div className="flex justify-between items-center p-3 bg-warning/5 rounded-lg border border-warning/20">
                      <span className="text-muted-foreground">Risk Percentage:</span>
                      <div className="text-right">
                        <div className="font-semibold">{trade.risk_percent}%</div>
                        <div className="text-xs text-muted-foreground">of account</div>
                      </div>
                    </div>
                  )}
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Globe className="h-4 w-4" />
                    Trade Performance
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  {/* Performance Metrics */}
                  <div className="space-y-3">
                    {trade.pips && (
                      <div className="flex justify-between items-center p-3 bg-muted/20 rounded-lg">
                        <span className="text-muted-foreground">Pips Gained/Lost:</span>
                        <div className="text-right">
                          <div className={`font-semibold ${trade.pips > 0 ? 'text-success' : 'text-danger'}`}>
                            {trade.pips > 0 ? '+' : ''}{trade.pips} pips
                          </div>
                        </div>
                      </div>
                    )}
                    
                    {trade.commission && trade.commission !== 0 && (
                      <div className="flex justify-between items-center p-3 bg-muted/20 rounded-lg">
                        <span className="text-muted-foreground">Commission:</span>
                        <div className="text-right">
                          <div className="font-mono text-danger">
                            {formatCurrency(trade.commission)}
                          </div>
                        </div>
                      </div>
                    )}
                    
                    {trade.swap && trade.swap !== 0 && (
                      <div className="flex justify-between items-center p-3 bg-muted/20 rounded-lg">
                        <span className="text-muted-foreground">Swap:</span>
                        <div className="text-right">
                          <div className={`font-mono ${trade.swap >= 0 ? 'text-success' : 'text-danger'}`}>
                            {formatCurrency(trade.swap)}
                          </div>
                        </div>
                      </div>
                    )}
                  </div>
                  
                  {/* Trade Quality Assessment */}
                  <div className="p-4 bg-gradient-to-r from-primary/5 to-secondary/5 rounded-lg border">
                    <h4 className="font-medium mb-2">Trade Quality</h4>
                    <div className="text-sm text-muted-foreground">
                      {trade.result === 'win' ? (
                        <div className="space-y-1">
                          <div className="flex items-center gap-2 text-success">
                            <TrendingUp className="h-4 w-4" />
                            <span>Successful Trade</span>
                          </div>
                          <div>This trade achieved its profit target successfully.</div>
                        </div>
                      ) : trade.result === 'loss' ? (
                        <div className="space-y-1">
                          <div className="flex items-center gap-2 text-danger">
                            <TrendingDown className="h-4 w-4" />
                            <span>Unsuccessful Trade</span>
                          </div>
                          <div>This trade hit the stop loss level.</div>
                        </div>
                      ) : (
                        <div>Trade is still open or closed manually.</div>
                      )}
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="history" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Trade Modification History</CardTitle>
              </CardHeader>
              <CardContent>
                {loading ? (
                  <div className="flex items-center justify-center py-8">
                    <RefreshCw className="h-4 w-4 animate-spin mr-2" />
                    Loading history...
                  </div>
                ) : tradeHistory.length > 0 ? (
                  <div className="space-y-3">
                    {tradeHistory.map((historyItem) => (
                      <div key={historyItem.id} className="border rounded-lg p-4 bg-muted/20">
                        <div className="flex justify-between items-start mb-3">
                          <div className="flex items-center gap-2">
                            <Badge variant={
                              historyItem.action === 'created' ? 'default' :
                              historyItem.action === 'closed' ? 'secondary' :
                              historyItem.action === 'updated' ? 'outline' : 'destructive'
                            }>
                              {historyItem.action.toUpperCase()}
                            </Badge>
                            {historyItem.changed_fields && historyItem.changed_fields.length > 0 && (
                              <div className="flex gap-1 flex-wrap">
                                {historyItem.changed_fields.slice(0, 3).map((field) => (
                                  <Badge key={field} variant="outline" className="text-xs">
                                    {field}
                                  </Badge>
                                ))}
                                {historyItem.changed_fields.length > 3 && (
                                  <Badge variant="outline" className="text-xs">
                                    +{historyItem.changed_fields.length - 3} more
                                  </Badge>
                                )}
                              </div>
                            )}
                          </div>
                          <span className="text-xs text-muted-foreground">
                            {formatDate(historyItem.created_at)}
                          </span>
                        </div>
                        
                        {/* Show changes summary */}
                        {historyItem.action === 'updated' && historyItem.changed_fields && (
                          <div className="space-y-2">
                            <h4 className="text-sm font-medium">Changes Made:</h4>
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-2 text-xs">
                              {historyItem.changed_fields.slice(0, 6).map((field) => {
                                const oldValue = historyItem.old_values?.[field];
                                const newValue = historyItem.new_values?.[field];
                                
                                return (
                                  <div key={field} className="bg-background/50 p-2 rounded border">
                                    <div className="font-medium capitalize">{field.replace('_', ' ')}</div>
                                    <div className="flex items-center gap-2 mt-1">
                                      <span className="text-red-600 truncate max-w-20">
                                        {String(oldValue || 'N/A')}
                                      </span>
                                      <span>→</span>
                                      <span className="text-green-600 truncate max-w-20">
                                        {String(newValue || 'N/A')}
                                      </span>
                                    </div>
                                  </div>
                                );
                              })}
                            </div>
                          </div>
                        )}
                        
                        {/* Show action summary for other operations */}
                        {historyItem.action !== 'updated' && (
                          <div className="text-sm text-muted-foreground">
                            {historyItem.action === 'created' && 'Trade was initially created'}
                            {historyItem.action === 'closed' && 'Trade was closed'}
                            {historyItem.action === 'deleted' && 'Trade was deleted from the system'}
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-8 text-muted-foreground">
                    <div className="space-y-2">
                      <div className="text-4xl">📝</div>
                      <h3 className="font-medium">No History Available</h3>
                      <p className="text-sm">
                        This trade hasn't been modified yet, or history tracking was enabled after this trade was created.
                      </p>
                      <div className="text-xs bg-muted/50 p-3 rounded-lg mt-4">
                        <strong>Note:</strong> History tracking captures all future changes to trades including:
                        price updates, notes changes, status modifications, and more.
                      </div>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="related" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Related Trades</CardTitle>
              </CardHeader>
              <CardContent>
                {relatedTrades.length > 0 ? (
                  <div className="space-y-3">
                    {relatedTrades.map((relatedTrade) => (
                      <div key={relatedTrade.id} className="border rounded-lg p-3 hover:bg-muted/50 cursor-pointer">
                        <div className="flex justify-between items-center">
                          <div className="flex items-center gap-3">
                            <Badge variant="outline">{relatedTrade.instrument}</Badge>
                            <span className="text-sm">
                              {relatedTrade.direction?.toUpperCase()} @ {relatedTrade.entry_price}
                            </span>
                          </div>
                          <div className="text-right">
                            <div className={`font-mono text-sm ${(relatedTrade.pnl || 0) >= 0 ? 'text-success' : 'text-danger'}`}>
                              {formatCurrency(relatedTrade.pnl || 0)}
                            </div>
                            <div className="text-xs text-muted-foreground">
                              {new Date(relatedTrade.opened_at).toLocaleDateString()}
                            </div>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-8 text-muted-foreground">
                    No related trades found
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </DialogContent>
    </Dialog>
  );
}