import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { 
  PieChart, 
  Pie, 
  Cell, 
  ResponsiveContainer, 
  LineChart, 
  Line, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  BarChart, 
  Bar,
  Area,
  AreaChart,
  Legend,
  ReferenceLine
} from "recharts";
import { format, parseISO } from "date-fns";
import { TrendingUp, BarChart3, Target, Activity, Award, Shield, Zap } from "lucide-react";

interface PropChallengeChartsProps {
  challenge: any;
  dailyResults: any[];
  accountSize: number;
}

const COLORS = {
  success: 'hsl(var(--success))',
  danger: 'hsl(var(--danger))',
  warning: 'hsl(var(--warning))',
  info: 'hsl(var(--info))',
  primary: 'hsl(var(--primary))',
  secondary: 'hsl(var(--secondary))',
  muted: 'hsl(var(--muted-foreground))',
  background: 'hsl(var(--background))',
  foreground: 'hsl(var(--foreground))'
};

const GRADIENTS = {
  success: 'linear-gradient(135deg, hsl(var(--success)) 0%, hsl(var(--success)) 100%)',
  danger: 'linear-gradient(135deg, hsl(var(--danger)) 0%, hsl(var(--danger)) 100%)',
  primary: 'linear-gradient(135deg, hsl(var(--primary)) 0%, hsl(var(--primary-dark)) 100%)',
  info: 'linear-gradient(135deg, hsl(var(--info)) 0%, hsl(var(--info-dark)) 100%)'
};

export function PropChallengeCharts({ challenge, dailyResults, accountSize }: PropChallengeChartsProps) {
  // Prepare data for charts
  const winLossData = [
    { 
      name: 'Winning Days', 
      value: dailyResults.filter(d => d.daily_pnl > 0).length,
      color: COLORS.success
    },
    { 
      name: 'Losing Days', 
      value: dailyResults.filter(d => d.daily_pnl < 0).length,
      color: COLORS.danger
    },
    { 
      name: 'Breakeven Days', 
      value: dailyResults.filter(d => d.daily_pnl === 0).length,
      color: COLORS.secondary
    }
  ];

  const ruleComplianceData = [
    {
      name: 'Compliant Days',
      value: dailyResults.filter(d => d.passed).length,
      color: COLORS.success
    },
    {
      name: 'Rule Violations',
      value: dailyResults.filter(d => !d.passed).length,
      color: COLORS.danger
    }
  ];

  // Equity curve data
  const equityCurveData = dailyResults.map((result, index) => {
    const cumulativePnL = dailyResults
      .slice(0, index + 1)
      .reduce((sum, r) => sum + r.daily_pnl, 0);
    
    return {
      date: format(parseISO(result.date), 'MMM dd'),
      equity: accountSize + cumulativePnL,
      pnl: cumulativePnL,
      dailyPnL: result.daily_pnl,
      trades: result.trades_count
    };
  });

  // Daily P&L distribution
  const pnlDistribution = dailyResults.map(result => ({
    date: format(parseISO(result.date), 'MMM dd'),
    pnl: result.daily_pnl,
    trades: result.trades_count,
    passed: result.passed
  }));

  // Risk metrics over time
  const riskOverTime = dailyResults.map((result, index) => {
    const cumulativePnL = dailyResults
      .slice(0, index + 1)
      .reduce((sum, r) => sum + r.daily_pnl, 0);
    
    const maxDrawdown = Math.min(0, cumulativePnL);
    const riskPercentage = accountSize > 0 ? Math.abs(maxDrawdown / accountSize * 100) : 0;
    
    return {
      date: format(parseISO(result.date), 'MMM dd'),
      drawdown: maxDrawdown,
      riskPercent: riskPercentage,
      dailyRisk: Math.abs(result.daily_pnl / accountSize * 100)
    };
  });

  const CustomTooltip = ({ active, payload, label }: any) => {
    if (active && payload && payload.length) {
      return (
        <div className="bg-background/95 backdrop-blur-sm border border-border rounded-xl p-4 shadow-2xl animate-fade-in">
          <p className="font-semibold text-foreground mb-2 text-sm">{label}</p>
          {payload.map((entry: any, index: number) => (
            <div key={index} className="flex items-center justify-between gap-3 text-sm">
              <div className="flex items-center gap-2">
                <div 
                  className="w-3 h-3 rounded-full shadow-sm" 
                  style={{ backgroundColor: entry.color }}
                />
                <span className="text-muted-foreground">{entry.name}:</span>
              </div>
              <span className="font-semibold" style={{ color: entry.color }}>
                {entry.name.includes('$') ? '$' : ''}{typeof entry.value === 'number' ? entry.value.toFixed(2) : entry.value}
                {entry.name.includes('%') ? '%' : ''}
              </span>
            </div>
          ))}
        </div>
      );
    }
    return null;
  };

  return (
    <div className="space-y-8 animate-fade-in">
      {/* Performance Overview Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card className="glass-card border-card-border relative overflow-hidden group hover:shadow-xl transition-all duration-300">
          <div className="absolute inset-0 bg-gradient-to-br from-success/10 via-transparent to-success/5 opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
          <CardHeader className="pb-2">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="p-2 bg-success/10 rounded-lg">
                  <Award className="w-4 h-4 text-success" />
                </div>
                <span className="text-sm font-medium">Win Rate</span>
              </div>
              <Badge variant="outline" className="text-xs">
                <Zap className="w-3 h-3 mr-1" />
                Live
              </Badge>
            </div>
          </CardHeader>
          <CardContent className="pt-0">
            <div className="text-2xl font-bold text-success">
              {dailyResults.length > 0 ? 
                ((dailyResults.filter(d => d.daily_pnl > 0).length / dailyResults.length) * 100).toFixed(1) : 0}%
            </div>
            <div className="text-xs text-muted-foreground mt-1">
              {dailyResults.filter(d => d.daily_pnl > 0).length} wins of {dailyResults.length} days
            </div>
          </CardContent>
        </Card>

        <Card className="glass-card border-card-border relative overflow-hidden group hover:shadow-xl transition-all duration-300">
          <div className="absolute inset-0 bg-gradient-to-br from-primary/10 via-transparent to-primary/5 opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
          <CardHeader className="pb-2">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="p-2 bg-primary/10 rounded-lg">
                  <Activity className="w-4 h-4 text-primary" />
                </div>
                <span className="text-sm font-medium">Consistency</span>
              </div>
              <Badge variant="outline" className="text-xs">
                <Zap className="w-3 h-3 mr-1" />
                Live
              </Badge>
            </div>
          </CardHeader>
          <CardContent className="pt-0">
            <div className="text-2xl font-bold text-primary">
              {dailyResults.length > 0 ? 
                ((dailyResults.filter(d => d.passed).length / dailyResults.length) * 100).toFixed(1) : 0}%
            </div>
            <div className="text-xs text-muted-foreground mt-1">
              {dailyResults.filter(d => d.passed).length} compliant days
            </div>
          </CardContent>
        </Card>

        <Card className="glass-card border-card-border relative overflow-hidden group hover:shadow-xl transition-all duration-300">
          <div className="absolute inset-0 bg-gradient-to-br from-info/10 via-transparent to-info/5 opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
          <CardHeader className="pb-2">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="p-2 bg-info/10 rounded-lg">
                  <Shield className="w-4 h-4 text-info" />
                </div>
                <span className="text-sm font-medium">Risk Score</span>
              </div>
              <Badge variant="outline" className="text-xs">
                <Zap className="w-3 h-3 mr-1" />
                Live
              </Badge>
            </div>
          </CardHeader>
          <CardContent className="pt-0">
            <div className="text-2xl font-bold text-info">
              {accountSize > 0 ? 
                Math.min(100, Math.max(0, 100 - (Math.abs(challenge.current_overall_loss) / accountSize * 100))).toFixed(0) : 100}
            </div>
            <div className="text-xs text-muted-foreground mt-1">
              Risk management score
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Modern Chart Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Win/Loss Distribution - Enhanced */}
        <Card className="glass-card border-card-border group hover:shadow-2xl transition-all duration-500">
          <div className="absolute inset-0 bg-gradient-to-br from-primary/5 via-transparent to-secondary/5 opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
          <CardHeader>
            <CardTitle className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="p-2 bg-primary/10 rounded-xl">
                  <Target className="w-5 h-5 text-primary" />
                </div>
                <div>
                  <h3 className="text-lg font-semibold">Trading Performance</h3>
                  <p className="text-xs text-muted-foreground">Daily win/loss breakdown</p>
                </div>
              </div>
              <Badge variant="outline" className="text-xs">
                <Activity className="w-3 h-3 mr-1" />
                Interactive
              </Badge>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-72">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <defs>
                    <linearGradient id="successGradient" x1="0%" y1="0%" x2="100%" y2="100%">
                      <stop offset="0%" stopColor="hsl(var(--success))" stopOpacity={0.8} />
                      <stop offset="100%" stopColor="hsl(var(--success))" stopOpacity={1} />
                    </linearGradient>
                    <linearGradient id="dangerGradient" x1="0%" y1="0%" x2="100%" y2="100%">
                      <stop offset="0%" stopColor="hsl(var(--danger))" stopOpacity={0.8} />
                      <stop offset="100%" stopColor="hsl(var(--danger))" stopOpacity={1} />
                    </linearGradient>
                    <linearGradient id="mutedGradient" x1="0%" y1="0%" x2="100%" y2="100%">
                      <stop offset="0%" stopColor="hsl(var(--muted-foreground))" stopOpacity={0.6} />
                      <stop offset="100%" stopColor="hsl(var(--muted-foreground))" stopOpacity={0.8} />
                    </linearGradient>
                  </defs>
                  <Pie
                    data={winLossData.map((entry, index) => ({
                      ...entry,
                      fill: index === 0 ? 'url(#successGradient)' : 
                            index === 1 ? 'url(#dangerGradient)' : 'url(#mutedGradient)'
                    }))}
                    cx="50%"
                    cy="50%"
                    innerRadius={65}
                    outerRadius={110}
                    paddingAngle={8}
                    dataKey="value"
                    stroke="hsl(var(--background))"
                    strokeWidth={3}
                  >
                    {winLossData.map((entry, index) => (
                      <Cell 
                        key={`cell-${index}`} 
                        className="hover:opacity-80 transition-opacity duration-300 drop-shadow-lg" 
                      />
                    ))}
                  </Pie>
                  <Tooltip content={<CustomTooltip />} />
                  <Legend 
                    wrapperStyle={{ 
                      paddingTop: '20px',
                      fontSize: '14px',
                      fontWeight: '500'
                    }}
                  />
                </PieChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>

        {/* Rule Compliance - Enhanced */}
        <Card className="glass-card border-card-border group hover:shadow-2xl transition-all duration-500">
          <div className="absolute inset-0 bg-gradient-to-br from-info/5 via-transparent to-warning/5 opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
          <CardHeader>
            <CardTitle className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="p-2 bg-info/10 rounded-xl">
                  <Shield className="w-5 h-5 text-info" />
                </div>
                <div>
                  <h3 className="text-lg font-semibold">Rule Compliance</h3>
                  <p className="text-xs text-muted-foreground">Daily compliance tracking</p>
                </div>
              </div>
              <Badge variant="outline" className="text-xs">
                <Activity className="w-3 h-3 mr-1" />
                Live
              </Badge>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-72">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <defs>
                    <linearGradient id="complianceSuccess" x1="0%" y1="0%" x2="100%" y2="100%">
                      <stop offset="0%" stopColor="hsl(var(--success))" stopOpacity={0.9} />
                      <stop offset="100%" stopColor="hsl(var(--success))" stopOpacity={1} />
                    </linearGradient>
                    <linearGradient id="complianceDanger" x1="0%" y1="0%" x2="100%" y2="100%">
                      <stop offset="0%" stopColor="hsl(var(--danger))" stopOpacity={0.9} />
                      <stop offset="100%" stopColor="hsl(var(--danger))" stopOpacity={1} />
                    </linearGradient>
                  </defs>
                  <Pie
                    data={ruleComplianceData.map((entry, index) => ({
                      ...entry,
                      fill: index === 0 ? 'url(#complianceSuccess)' : 'url(#complianceDanger)'
                    }))}
                    cx="50%"
                    cy="50%"
                    innerRadius={65}
                    outerRadius={110}
                    paddingAngle={6}
                    dataKey="value"
                    stroke="hsl(var(--background))"
                    strokeWidth={3}
                  >
                    {ruleComplianceData.map((entry, index) => (
                      <Cell 
                        key={`cell-${index}`} 
                        className="hover:opacity-80 transition-opacity duration-300 drop-shadow-lg"
                      />
                    ))}
                  </Pie>
                  <Tooltip content={<CustomTooltip />} />
                  <Legend 
                    wrapperStyle={{ 
                      paddingTop: '20px',
                      fontSize: '14px',
                      fontWeight: '500'
                    }}
                  />
                </PieChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Enhanced Equity Curve */}
      <Card className="glass-card border-card-border group hover:shadow-2xl transition-all duration-500">
        <div className="absolute inset-0 bg-gradient-to-br from-primary/5 via-transparent to-info/5 opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-primary/10 rounded-xl">
                <TrendingUp className="w-6 h-6 text-primary" />
              </div>
              <div>
                <h3 className="text-xl font-semibold">Equity Curve Progression</h3>
                <p className="text-sm text-muted-foreground">Account growth over time</p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <Badge variant="outline" className="text-xs">
                <Zap className="w-3 h-3 mr-1" />
                Real-time
              </Badge>
              <Badge variant="secondary" className="text-xs">
                ${equityCurveData.length > 0 ? equityCurveData[equityCurveData.length - 1]?.equity.toLocaleString() : accountSize.toLocaleString()}
              </Badge>
            </div>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="h-96">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={equityCurveData} margin={{ top: 20, right: 30, left: 20, bottom: 20 }}>
                <defs>
                  <linearGradient id="equityGradient" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="hsl(var(--primary))" stopOpacity={0.3}/>
                    <stop offset="95%" stopColor="hsl(var(--primary))" stopOpacity={0.05}/>
                  </linearGradient>
                  <linearGradient id="pnlGradient" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="hsl(var(--info))" stopOpacity={0.2}/>
                    <stop offset="95%" stopColor="hsl(var(--info))" stopOpacity={0.05}/>
                  </linearGradient>
                </defs>
                <CartesianGrid 
                  strokeDasharray="3 3" 
                  stroke="hsl(var(--muted-foreground))" 
                  strokeOpacity={0.2}
                />
                <XAxis 
                  dataKey="date" 
                  tick={{ fontSize: 12, fill: 'hsl(var(--muted-foreground))' }}
                  axisLine={{ stroke: 'hsl(var(--border))' }}
                />
                <YAxis 
                  tick={{ fontSize: 12, fill: 'hsl(var(--muted-foreground))' }}
                  axisLine={{ stroke: 'hsl(var(--border))' }}
                />
                <Tooltip content={<CustomTooltip />} />
                <Legend />
                <ReferenceLine 
                  y={accountSize} 
                  stroke="hsl(var(--muted-foreground))" 
                  strokeDasharray="5 5" 
                  strokeOpacity={0.5}
                  label="Starting Balance"
                />
                <Area 
                  type="monotone" 
                  dataKey="equity" 
                  stroke="hsl(var(--primary))" 
                  strokeWidth={3}
                  fill="url(#equityGradient)"
                  name="Account Equity ($)"
                  className="drop-shadow-sm"
                />
                <Line 
                  type="monotone" 
                  dataKey="pnl" 
                  stroke="hsl(var(--info))" 
                  strokeWidth={2}
                  strokeDasharray="5 5"
                  name="Cumulative P&L ($)"
                />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </CardContent>
      </Card>

      {/* Enhanced Daily P&L Performance */}
      <Card className="glass-card border-card-border group hover:shadow-2xl transition-all duration-500">
        <div className="absolute inset-0 bg-gradient-to-br from-success/5 via-transparent to-danger/5 opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-info/10 rounded-xl">
                <BarChart3 className="w-6 h-6 text-info" />
              </div>
              <div>
                <h3 className="text-xl font-semibold">Daily P&L Performance</h3>
                <p className="text-sm text-muted-foreground">Daily profit and loss breakdown</p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <Badge variant="outline" className="text-xs">
                <Activity className="w-3 h-3 mr-1" />
                Interactive
              </Badge>
              {pnlDistribution.length > 0 && (
                <Badge variant={
                  pnlDistribution[pnlDistribution.length - 1]?.pnl >= 0 ? 'default' : 'destructive'
                } className="text-xs">
                  Latest: ${pnlDistribution[pnlDistribution.length - 1]?.pnl.toFixed(2)}
                </Badge>
              )}
            </div>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="h-96">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={pnlDistribution} margin={{ top: 20, right: 30, left: 20, bottom: 20 }}>
                <defs>
                  <linearGradient id="profitGradient" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="hsl(var(--success))" stopOpacity={0.9}/>
                    <stop offset="95%" stopColor="hsl(var(--success))" stopOpacity={0.7}/>
                  </linearGradient>
                  <linearGradient id="lossGradient" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="hsl(var(--danger))" stopOpacity={0.9}/>
                    <stop offset="95%" stopColor="hsl(var(--danger))" stopOpacity={0.7}/>
                  </linearGradient>
                </defs>
                <CartesianGrid 
                  strokeDasharray="3 3" 
                  stroke="hsl(var(--muted-foreground))" 
                  strokeOpacity={0.2}
                />
                <XAxis 
                  dataKey="date" 
                  tick={{ fontSize: 12, fill: 'hsl(var(--muted-foreground))' }}
                  axisLine={{ stroke: 'hsl(var(--border))' }}
                />
                <YAxis 
                  tick={{ fontSize: 12, fill: 'hsl(var(--muted-foreground))' }}
                  axisLine={{ stroke: 'hsl(var(--border))' }}
                />
                <Tooltip content={<CustomTooltip />} />
                <ReferenceLine 
                  y={0} 
                  stroke="hsl(var(--muted-foreground))" 
                  strokeDasharray="2 2" 
                  strokeOpacity={0.7}
                />
                <Bar 
                  dataKey="pnl" 
                  name="Daily P&L ($)"
                  radius={[4, 4, 0, 0]}
                  className="drop-shadow-sm"
                >
                  {pnlDistribution.map((entry, index) => (
                    <Cell 
                      key={`cell-${index}`} 
                      fill={entry.pnl >= 0 ? 'url(#profitGradient)' : 'url(#lossGradient)'}
                      className="hover:opacity-80 transition-opacity duration-300"
                    />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </CardContent>
      </Card>

      {/* Enhanced Risk & Volume Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Risk Analysis Over Time */}
        <Card className="glass-card border-card-border group hover:shadow-2xl transition-all duration-500">
          <div className="absolute inset-0 bg-gradient-to-br from-warning/5 via-transparent to-danger/5 opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
          <CardHeader>
            <CardTitle className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="p-2 bg-warning/10 rounded-xl">
                  <Shield className="w-5 h-5 text-warning" />
                </div>
                <div>
                  <h3 className="text-lg font-semibold">Risk Analysis</h3>
                  <p className="text-xs text-muted-foreground">Drawdown & risk tracking</p>
                </div>
              </div>
              <Badge variant="outline" className="text-xs">
                <Zap className="w-3 h-3 mr-1" />
                Live
              </Badge>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-80">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={riskOverTime} margin={{ top: 20, right: 30, left: 20, bottom: 20 }}>
                  <defs>
                    <linearGradient id="riskGradient" x1="0" y1="0" x2="1" y2="0">
                      <stop offset="0%" stopColor="hsl(var(--warning))" stopOpacity={0.8}/>
                      <stop offset="100%" stopColor="hsl(var(--danger))" stopOpacity={0.8}/>
                    </linearGradient>
                  </defs>
                  <CartesianGrid 
                    strokeDasharray="3 3" 
                    stroke="hsl(var(--muted-foreground))" 
                    strokeOpacity={0.2}
                  />
                  <XAxis 
                    dataKey="date" 
                    tick={{ fontSize: 12, fill: 'hsl(var(--muted-foreground))' }}
                    axisLine={{ stroke: 'hsl(var(--border))' }}
                  />
                  <YAxis 
                    tick={{ fontSize: 12, fill: 'hsl(var(--muted-foreground))' }}
                    axisLine={{ stroke: 'hsl(var(--border))' }}
                  />
                  <Tooltip content={<CustomTooltip />} />
                  <Legend />
                  <Line 
                    type="monotone" 
                    dataKey="riskPercent" 
                    stroke="hsl(var(--warning))" 
                    strokeWidth={3}
                    dot={{ fill: 'hsl(var(--warning))', strokeWidth: 2, r: 4 }}
                    activeDot={{ r: 6, className: "drop-shadow-lg" }}
                    name="Max Drawdown (%)"
                  />
                  <Line 
                    type="monotone" 
                    dataKey="dailyRisk" 
                    stroke="hsl(var(--danger))" 
                    strokeWidth={2}
                    strokeDasharray="5 5"
                    dot={{ fill: 'hsl(var(--danger))', strokeWidth: 2, r: 3 }}
                    name="Daily Risk (%)"
                  />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>

        {/* Trading Volume Analysis */}
        <Card className="glass-card border-card-border group hover:shadow-2xl transition-all duration-500">
          <div className="absolute inset-0 bg-gradient-to-br from-info/5 via-transparent to-primary/5 opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
          <CardHeader>
            <CardTitle className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="p-2 bg-info/10 rounded-xl">
                  <BarChart3 className="w-5 h-5 text-info" />
                </div>
                <div>
                  <h3 className="text-lg font-semibold">Trading Volume</h3>
                  <p className="text-xs text-muted-foreground">Daily trading activity</p>
                </div>
              </div>
              <Badge variant="outline" className="text-xs">
                <Activity className="w-3 h-3 mr-1" />
                Live
              </Badge>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-80">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={pnlDistribution} margin={{ top: 20, right: 30, left: 20, bottom: 20 }}>
                  <defs>
                    <linearGradient id="volumeGradient" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="hsl(var(--info))" stopOpacity={0.9}/>
                      <stop offset="95%" stopColor="hsl(var(--info))" stopOpacity={0.6}/>
                    </linearGradient>
                  </defs>
                  <CartesianGrid 
                    strokeDasharray="3 3" 
                    stroke="hsl(var(--muted-foreground))" 
                    strokeOpacity={0.2}
                  />
                  <XAxis 
                    dataKey="date" 
                    tick={{ fontSize: 12, fill: 'hsl(var(--muted-foreground))' }}
                    axisLine={{ stroke: 'hsl(var(--border))' }}
                  />
                  <YAxis 
                    tick={{ fontSize: 12, fill: 'hsl(var(--muted-foreground))' }}
                    axisLine={{ stroke: 'hsl(var(--border))' }}
                  />
                  <Tooltip content={<CustomTooltip />} />
                  <Bar 
                    dataKey="trades" 
                    fill="url(#volumeGradient)"
                    name="Number of Trades"
                    radius={[4, 4, 0, 0]}
                    className="drop-shadow-sm hover:opacity-80 transition-opacity duration-300"
                  />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}