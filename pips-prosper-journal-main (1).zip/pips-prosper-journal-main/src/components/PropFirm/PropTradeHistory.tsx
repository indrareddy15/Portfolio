import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { 
  TrendingUp, 
  TrendingDown, 
  MoreVertical, 
  Eye, 
  Edit, 
  Trash2, 
  Calendar,
  DollarSign,
  Activity,
  Share2,
  Award
} from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/useAuth";
import { format } from "date-fns";
import { TradeForm } from "@/components/TradeForm";
import { EditTradeDialog } from "@/components/EditTradeDialog";
import { useTradeSharing } from "@/hooks/useTradeSharing";

interface PropTradeHistoryProps {
  challengeId: string;
  onTradeUpdate?: () => void;
}

export function PropTradeHistory({ challengeId, onTradeUpdate }: PropTradeHistoryProps) {
  const [trades, setTrades] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedTrade, setSelectedTrade] = useState<any>(null);
  const [showTradeForm, setShowTradeForm] = useState(false);
  const [showEditDialog, setShowEditDialog] = useState(false);
  const [showViewDialog, setShowViewDialog] = useState(false);
  const { user } = useAuth();
  const { toast } = useToast();
  const { createTradeShare, generateCertificate } = useTradeSharing();

  const fetchTrades = async () => {
    if (!user || !challengeId) return;
    
    setLoading(true);
    try {
      const { data, error } = await supabase
        .from('trades')
        .select(`
          *,
          accounts!inner(name, nickname)
        `)
        .eq('user_id', user.id)
        .eq('prop_challenge_id', challengeId)
        .order('opened_at', { ascending: false });

      if (error) throw error;
      setTrades(data || []);
    } catch (error: any) {
      console.error('Error fetching prop trades:', error);
      toast({
        title: "Error loading trades",
        description: error.message,
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchTrades();
  }, [challengeId, user]);

  // Real-time updates
  useEffect(() => {
    if (!user || !challengeId) return;

    const channel = supabase
      .channel('prop-trades-changes')
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'trades',
          filter: `prop_challenge_id=eq.${challengeId}`
        },
        () => {
          fetchTrades();
          onTradeUpdate?.();
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [challengeId, user]);

  const handleDeleteTrade = async (tradeId: string) => {
    try {
      const { error } = await supabase
        .from('trades')
        .delete()
        .eq('id', tradeId)
        .eq('user_id', user?.id);

      if (error) throw error;

      toast({
        title: "Trade deleted",
        description: "Trade has been removed from your challenge",
      });

      fetchTrades();
      onTradeUpdate?.();
    } catch (error: any) {
      toast({
        title: "Error deleting trade",
        description: error.message,
        variant: "destructive",
      });
    }
  };

  const handleShareTrade = async (trade: any) => {
    try {
      const share = await createTradeShare({
        trade_id: trade.id,
        title: `${trade.pnl && trade.pnl > 0 ? 'Profitable' : 'Learning'} ${trade.instrument} Trade`,
        description: `Prop Challenge Trade — P&L: $${(trade.pnl || 0).toFixed(2)}`,
        is_public: true,
      });

      if (share) {
        const shareUrl = `${window.location.origin}/shared/trade/${share.share_token}`;
        navigator.clipboard.writeText(shareUrl);
        
        toast({
          title: "Share link copied! 🔗",
          description: "Trade share link copied to clipboard",
        });

        // Generate certificate
        generateCertificate(share.id);
      }
    } catch (error: any) {
      toast({
        title: "Error sharing trade",
        description: error.message,
        variant: "destructive",
      });
    }
  };

  const formatPnL = (pnl: number) => {
    const formatted = Math.abs(pnl).toFixed(2);
    return pnl >= 0 ? `+$${formatted}` : `-$${formatted}`;
  };

  const getPnLColor = (pnl: number) => {
    if (pnl > 0) return 'text-success';
    if (pnl < 0) return 'text-danger';
    return 'text-muted-foreground';
  };

  if (loading) {
    return (
      <Card className="glass-card border-card-border">
        <CardContent className="p-6">
          <div className="space-y-4">
            {[1, 2, 3].map(i => (
              <div key={i} className="animate-pulse">
                <div className="h-16 bg-muted rounded-lg"></div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <>
      <Card className="glass-card border-card-border">
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="flex items-center gap-2">
              <Activity className="w-5 h-5 text-primary" />
              Challenge Trades ({trades.length})
            </CardTitle>
            <Button onClick={() => setShowTradeForm(true)} size="sm">
              Add Trade
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          {trades.length === 0 ? (
            <div className="text-center py-8">
              <Activity className="w-12 h-12 mx-auto mb-4 text-muted-foreground" />
              <h3 className="text-lg font-semibold mb-2">No trades yet</h3>
              <p className="text-muted-foreground mb-4">
                Start adding trades to track your prop challenge progress
              </p>
              <Button onClick={() => setShowTradeForm(true)}>
                Add First Trade
              </Button>
            </div>
          ) : (
            <div className="space-y-3">
              {trades.map((trade) => (
                <div key={trade.id} className="flex items-center justify-between p-4 bg-muted/20 rounded-lg hover:bg-muted/30 transition-colors">
                  <div className="flex items-center gap-4">
                    <div className={`w-3 h-3 rounded-full ${
                      trade.pnl > 0 ? 'bg-success' : trade.pnl < 0 ? 'bg-danger' : 'bg-muted-foreground'
                    }`}></div>
                    
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-medium">{trade.instrument}</span>
                        <Badge variant={trade.side === 'long' ? 'default' : 'secondary'} className="text-xs">
                          {trade.side === 'long' ? (
                            <TrendingUp className="w-3 h-3 mr-1" />
                          ) : (
                            <TrendingDown className="w-3 h-3 mr-1" />
                          )}
                          {trade.side.toUpperCase()}
                        </Badge>
                      </div>
                      <div className="text-sm text-muted-foreground">
                        {format(new Date(trade.opened_at), "MMM dd, yyyy • HH:mm")}
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center gap-4">
                    <div className="text-right">
                      <div className={`text-lg font-bold ${getPnLColor(trade.pnl || 0)}`}>
                        {formatPnL(trade.pnl || 0)}
                      </div>
                      <div className="text-sm text-muted-foreground">
                        Size: {trade.size}
                      </div>
                    </div>

                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="ghost" size="sm">
                          <MoreVertical className="w-4 h-4" />
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end" className="w-48">
                        <DropdownMenuItem onClick={() => {
                          setSelectedTrade(trade);
                          setShowViewDialog(true);
                        }}>
                          <Eye className="w-4 h-4 mr-2" />
                          View Details
                        </DropdownMenuItem>
                        <DropdownMenuItem onClick={() => {
                          setSelectedTrade(trade);
                          setShowEditDialog(true);
                        }}>
                          <Edit className="w-4 h-4 mr-2" />
                          Edit Trade
                        </DropdownMenuItem>
                        <DropdownMenuItem onClick={() => handleShareTrade(trade)}>
                          <Share2 className="w-4 h-4 mr-2" />
                          Share Trade
                        </DropdownMenuItem>
                        <DropdownMenuItem 
                          onClick={() => handleDeleteTrade(trade.id)}
                          className="text-danger focus:text-danger"
                        >
                          <Trash2 className="w-4 h-4 mr-2" />
                          Delete Trade
                        </DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Add Trade Dialog */}
      <Dialog open={showTradeForm} onOpenChange={setShowTradeForm}>
        <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Add Trade to Challenge</DialogTitle>
          </DialogHeader>
          <div className="mt-4">
            <TradeForm 
              onTradeAdded={() => {
                setShowTradeForm(false);
                fetchTrades();
                onTradeUpdate?.();
              }}
            />
          </div>
        </DialogContent>
      </Dialog>

      {/* Edit Trade Dialog */}
      {selectedTrade && (
        <EditTradeDialog
          trade={selectedTrade}
          open={showEditDialog}
          onOpenChange={setShowEditDialog}
          onTradeUpdated={() => {
            fetchTrades();
            onTradeUpdate?.();
            setShowEditDialog(false);
          }}
        />
      )}

      {/* View Trade Details Dialog */}
      <Dialog open={showViewDialog} onOpenChange={setShowViewDialog}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Eye className="w-5 h-5" />
              Trade Details
            </DialogTitle>
          </DialogHeader>
          {selectedTrade && (
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <label className="text-sm font-medium text-muted-foreground">Instrument</label>
                  <div className="text-lg font-semibold">{selectedTrade.instrument}</div>
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium text-muted-foreground">Side</label>
                  <Badge variant={selectedTrade.side === 'long' ? 'default' : 'secondary'}>
                    {selectedTrade.side === 'long' ? (
                      <TrendingUp className="w-3 h-3 mr-1" />
                    ) : (
                      <TrendingDown className="w-3 h-3 mr-1" />
                    )}
                    {selectedTrade.side.toUpperCase()}
                  </Badge>
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium text-muted-foreground">Entry Price</label>
                  <div className="text-lg">{selectedTrade.entry_price}</div>
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium text-muted-foreground">Exit Price</label>
                  <div className="text-lg">{selectedTrade.exit_price || 'Open'}</div>
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium text-muted-foreground">Size</label>
                  <div className="text-lg">{selectedTrade.size}</div>
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium text-muted-foreground">P&L</label>
                  <div className={`text-lg font-bold ${getPnLColor(selectedTrade.pnl || 0)}`}>
                    {formatPnL(selectedTrade.pnl || 0)}
                  </div>
                </div>
              </div>
              
              <div className="space-y-2">
                <label className="text-sm font-medium text-muted-foreground">Opened At</label>
                <div className="flex items-center gap-2">
                  <Calendar className="w-4 h-4" />
                  {format(new Date(selectedTrade.opened_at), "PPpp")}
                </div>
              </div>

              {selectedTrade.closed_at && (
                <div className="space-y-2">
                  <label className="text-sm font-medium text-muted-foreground">Closed At</label>
                  <div className="flex items-center gap-2">
                    <Calendar className="w-4 h-4" />
                    {format(new Date(selectedTrade.closed_at), "PPpp")}
                  </div>
                </div>
              )}

              {selectedTrade.notes_pre && (
                <div className="space-y-2">
                  <label className="text-sm font-medium text-muted-foreground">Pre-Trade Notes</label>
                  <div className="p-3 bg-muted/20 rounded-lg">{selectedTrade.notes_pre}</div>
                </div>
              )}

              {selectedTrade.notes_post && (
                <div className="space-y-2">
                  <label className="text-sm font-medium text-muted-foreground">Post-Trade Notes</label>
                  <div className="p-3 bg-muted/20 rounded-lg">{selectedTrade.notes_post}</div>
                </div>
              )}

              <div className="flex gap-2 pt-4">
                <Button 
                  onClick={() => handleShareTrade(selectedTrade)}
                  variant="outline"
                  className="flex-1"
                >
                  <Share2 className="w-4 h-4 mr-2" />
                  Share Trade
                </Button>
                <Button 
                  onClick={() => {
                    setShowViewDialog(false);
                    setShowEditDialog(true);
                  }}
                  className="flex-1"
                >
                  <Edit className="w-4 h-4 mr-2" />
                  Edit Trade
                </Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </>
  );
}