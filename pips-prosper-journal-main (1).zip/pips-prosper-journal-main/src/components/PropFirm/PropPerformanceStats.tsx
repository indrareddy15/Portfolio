import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { 
  TrendingUp, 
  Award, 
  Calendar,
  DollarSign,
  BarChart3,
  Target,
  Clock,
  Activity
} from "lucide-react";
import { format, parseISO, differenceInDays } from "date-fns";

interface PropPerformanceStatsProps {
  challenge: any;
  dailyResults: any[];
  accountSize: number;
}

export function PropPerformanceStats({ challenge, dailyResults, accountSize }: PropPerformanceStatsProps) {
  // Calculate comprehensive performance statistics
  const calculatePerformanceStats = () => {
    if (dailyResults.length === 0) return null;

    const pnlValues = dailyResults.map(r => r.daily_pnl);
    const winningDays = pnlValues.filter(p => p > 0);
    const losingDays = pnlValues.filter(p => p < 0);
    const breakEvenDays = pnlValues.filter(p => p === 0);
    
    // Basic statistics
    const totalPnL = pnlValues.reduce((sum, pnl) => sum + pnl, 0);
    const avgDailyPnL = totalPnL / dailyResults.length;
    const bestDay = Math.max(...pnlValues);
    const worstDay = Math.min(...pnlValues);
    
    // Win/Loss statistics
    const winRate = (winningDays.length / dailyResults.length) * 100;
    const avgWin = winningDays.length > 0 ? winningDays.reduce((sum, win) => sum + win, 0) / winningDays.length : 0;
    const avgLoss = losingDays.length > 0 ? Math.abs(losingDays.reduce((sum, loss) => sum + loss, 0) / losingDays.length) : 0;
    
    // Challenge progress
    const daysElapsed = differenceInDays(new Date(), parseISO(challenge.start_date));
    const totalChallengeDays = differenceInDays(parseISO(challenge.end_date), parseISO(challenge.start_date));
    const progressPercent = Math.min(100, (daysElapsed / totalChallengeDays) * 100);
    
    // Profit target progress
    const profitProgress = challenge.target_profit > 0 ? 
      Math.max(0, Math.min(100, (totalPnL / challenge.target_profit) * 100)) : 0;
    
    // Trading frequency
    const totalTrades = dailyResults.reduce((sum, day) => sum + day.trades_count, 0);
    const avgTradesPerDay = totalTrades / dailyResults.length;
    
    // Consistency metrics
    const standardDeviation = Math.sqrt(
      pnlValues.reduce((sum, pnl) => sum + Math.pow(pnl - avgDailyPnL, 2), 0) / dailyResults.length
    );
    
    // Performance rating (0-100 scale)
    const performanceRating = calculatePerformanceRating({
      winRate,
      profitProgress,
      riskManagement: Math.max(0, 100 - (Math.abs(worstDay) / accountSize * 100 * 10)),
      consistency: Math.max(0, 100 - (standardDeviation / avgDailyPnL * 10))
    });

    return {
      totalPnL,
      avgDailyPnL,
      bestDay,
      worstDay,
      winRate,
      avgWin,
      avgLoss,
      winningDays: winningDays.length,
      losingDays: losingDays.length,
      breakEvenDays: breakEvenDays.length,
      daysElapsed,
      totalChallengeDays,
      progressPercent,
      profitProgress,
      totalTrades,
      avgTradesPerDay,
      standardDeviation,
      performanceRating
    };
  };

  const calculatePerformanceRating = (metrics: any) => {
    const weights = {
      winRate: 0.3,
      profitProgress: 0.3,
      riskManagement: 0.25,
      consistency: 0.15
    };
    
    return Math.round(
      metrics.winRate * weights.winRate +
      metrics.profitProgress * weights.profitProgress +
      metrics.riskManagement * weights.riskManagement +
      metrics.consistency * weights.consistency
    );
  };

  const getPerformanceGrade = (rating: number) => {
    if (rating >= 90) return { grade: 'A+', color: 'success', description: 'Excellent' };
    if (rating >= 80) return { grade: 'A', color: 'success', description: 'Very Good' };
    if (rating >= 70) return { grade: 'B', color: 'info', description: 'Good' };
    if (rating >= 60) return { grade: 'C', color: 'warning', description: 'Average' };
    return { grade: 'D', color: 'danger', description: 'Needs Improvement' };
  };

  const stats = calculatePerformanceStats();

  if (!stats) {
    return (
      <Card className="glass-card border-card-border">
        <CardContent className="p-12 text-center">
          <BarChart3 className="w-16 h-16 mx-auto mb-4 text-muted-foreground" />
          <h3 className="text-xl font-semibold mb-2">No Performance Data Available</h3>
          <p className="text-muted-foreground">
            Start trading to see detailed performance statistics and analysis.
          </p>
        </CardContent>
      </Card>
    );
  }

  const performanceGrade = getPerformanceGrade(stats.performanceRating);

  return (
    <div className="space-y-6">
      {/* Performance Overview */}
      <Card className="glass-card border-card-border">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Award className="w-5 h-5 text-primary" />
            Performance Overview
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {/* Performance Grade */}
            <div className="text-center p-6 bg-gradient-to-br from-primary/10 to-transparent rounded-lg">
              <div className={`text-4xl font-bold text-${performanceGrade.color} mb-2`}>
                {performanceGrade.grade}
              </div>
              <div className="text-lg font-semibold mb-1">{performanceGrade.description}</div>
              <div className="text-sm text-muted-foreground">Performance Rating</div>
              <div className="mt-3">
                <Progress value={stats.performanceRating} className="h-2" />
                <div className="text-xs text-muted-foreground mt-1">
                  {stats.performanceRating}/100
                </div>
              </div>
            </div>

            {/* Challenge Progress */}
            <div className="space-y-4">
              <div>
                <div className="flex justify-between mb-2">
                  <span className="text-sm font-medium">Time Progress</span>
                  <span className="text-sm text-muted-foreground">
                    {stats.daysElapsed}/{stats.totalChallengeDays} days
                  </span>
                </div>
                <Progress value={stats.progressPercent} className="h-2" />
              </div>
              
              <div>
                <div className="flex justify-between mb-2">
                  <span className="text-sm font-medium">Profit Target</span>
                  <span className="text-sm text-muted-foreground">
                    {stats.profitProgress.toFixed(1)}%
                  </span>
                </div>
                <Progress value={stats.profitProgress} className="h-2" />
              </div>
              
              <div>
                <div className="flex justify-between mb-2">
                  <span className="text-sm font-medium">Trading Days</span>
                  <span className="text-sm text-muted-foreground">
                    {challenge.trading_days_count}/{challenge.min_trading_days}
                  </span>
                </div>
                <Progress 
                  value={(challenge.trading_days_count / challenge.min_trading_days) * 100} 
                  className="h-2" 
                />
              </div>
            </div>

            {/* Key Metrics */}
            <div className="space-y-3">
              <div className="flex justify-between">
                <span className="text-sm">Total P&L</span>
                <span className={`text-sm font-bold ${
                  stats.totalPnL >= 0 ? 'text-success' : 'text-danger'
                }`}>
                  ${stats.totalPnL.toLocaleString()}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-sm">Daily Average</span>
                <span className={`text-sm font-medium ${
                  stats.avgDailyPnL >= 0 ? 'text-success' : 'text-danger'
                }`}>
                  ${stats.avgDailyPnL.toFixed(2)}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-sm">Win Rate</span>
                <span className="text-sm font-medium text-info">
                  {stats.winRate.toFixed(1)}%
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-sm">Total Trades</span>
                <span className="text-sm font-medium">
                  {stats.totalTrades}
                </span>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Detailed Statistics */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* P&L Statistics */}
        <Card className="glass-card border-card-border">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <DollarSign className="w-5 h-5 text-primary" />
              P&L Statistics
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="text-center p-3 bg-success/10 rounded-lg">
                <div className="text-lg font-bold text-success">
                  ${stats.bestDay.toFixed(2)}
                </div>
                <div className="text-sm text-muted-foreground">Best Day</div>
              </div>
              <div className="text-center p-3 bg-danger/10 rounded-lg">
                <div className="text-lg font-bold text-danger">
                  ${stats.worstDay.toFixed(2)}
                </div>
                <div className="text-sm text-muted-foreground">Worst Day</div>
              </div>
            </div>

            <div className="space-y-3">
              <div className="flex justify-between">
                <span className="text-sm">Average Win</span>
                <span className="text-sm font-medium text-success">
                  ${stats.avgWin.toFixed(2)}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-sm">Average Loss</span>
                <span className="text-sm font-medium text-danger">
                  ${stats.avgLoss.toFixed(2)}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-sm">Win/Loss Ratio</span>
                <span className="text-sm font-medium">
                  {stats.avgLoss > 0 ? (stats.avgWin / stats.avgLoss).toFixed(2) : '∞'}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-sm">Volatility (Std Dev)</span>
                <span className="text-sm font-medium">
                  ${stats.standardDeviation.toFixed(2)}
                </span>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Trading Activity */}
        <Card className="glass-card border-card-border">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Activity className="w-5 h-5 text-primary" />
              Trading Activity
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-3 gap-4">
              <div className="text-center p-3 bg-success/10 rounded-lg">
                <div className="text-lg font-bold text-success">
                  {stats.winningDays}
                </div>
                <div className="text-sm text-muted-foreground">Win Days</div>
              </div>
              <div className="text-center p-3 bg-danger/10 rounded-lg">
                <div className="text-lg font-bold text-danger">
                  {stats.losingDays}
                </div>
                <div className="text-sm text-muted-foreground">Loss Days</div>
              </div>
              <div className="text-center p-3 bg-secondary/10 rounded-lg">
                <div className="text-lg font-bold text-secondary">
                  {stats.breakEvenDays}
                </div>
                <div className="text-sm text-muted-foreground">B/E Days</div>
              </div>
            </div>

            <div className="space-y-3">
              <div className="flex justify-between">
                <span className="text-sm">Total Trading Days</span>
                <span className="text-sm font-medium">{dailyResults.length}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-sm">Avg Trades/Day</span>
                <span className="text-sm font-medium">
                  {stats.avgTradesPerDay.toFixed(1)}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-sm">Most Active Day</span>
                <span className="text-sm font-medium">
                  {Math.max(...dailyResults.map(d => d.trades_count))} trades
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-sm">Days Without Trading</span>
                <span className="text-sm font-medium">
                  {stats.daysElapsed - dailyResults.length}
                </span>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Challenge Milestones */}
      <Card className="glass-card border-card-border">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Target className="w-5 h-5 text-primary" />
            Challenge Milestones
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="flex items-center justify-between p-3 bg-muted/20 rounded-lg">
              <div className="flex items-center gap-3">
                <div className={`w-3 h-3 rounded-full ${
                  stats.profitProgress >= 25 ? 'bg-success' : 'bg-muted'
                }`}></div>
                <span className="font-medium">25% Profit Target</span>
              </div>
              <Badge variant={stats.profitProgress >= 25 ? 'default' : 'outline'}>
                {stats.profitProgress >= 25 ? 'Achieved' : 'Pending'}
              </Badge>
            </div>

            <div className="flex items-center justify-between p-3 bg-muted/20 rounded-lg">
              <div className="flex items-center gap-3">
                <div className={`w-3 h-3 rounded-full ${
                  stats.profitProgress >= 50 ? 'bg-success' : 'bg-muted'
                }`}></div>
                <span className="font-medium">50% Profit Target</span>
              </div>
              <Badge variant={stats.profitProgress >= 50 ? 'default' : 'outline'}>
                {stats.profitProgress >= 50 ? 'Achieved' : 'Pending'}
              </Badge>
            </div>

            <div className="flex items-center justify-between p-3 bg-muted/20 rounded-lg">
              <div className="flex items-center gap-3">
                <div className={`w-3 h-3 rounded-full ${
                  challenge.trading_days_count >= challenge.min_trading_days ? 'bg-success' : 'bg-muted'
                }`}></div>
                <span className="font-medium">Minimum Trading Days</span>
              </div>
              <Badge variant={challenge.trading_days_count >= challenge.min_trading_days ? 'default' : 'outline'}>
                {challenge.trading_days_count >= challenge.min_trading_days ? 'Achieved' : 'Pending'}
              </Badge>
            </div>

            <div className="flex items-center justify-between p-3 bg-muted/20 rounded-lg">
              <div className="flex items-center gap-3">
                <div className={`w-3 h-3 rounded-full ${
                  stats.profitProgress >= 100 ? 'bg-success' : 'bg-muted'
                }`}></div>
                <span className="font-medium">Full Profit Target</span>
              </div>
              <Badge variant={stats.profitProgress >= 100 ? 'default' : 'outline'}>
                {stats.profitProgress >= 100 ? 'Achieved' : 'Pending'}
              </Badge>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}