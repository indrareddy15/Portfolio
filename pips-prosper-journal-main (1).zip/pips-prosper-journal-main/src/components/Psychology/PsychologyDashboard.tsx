import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { 
  Brain, 
  TrendingUp, 
  AlertTriangle,
  Calendar,
  Target,
  MessageSquare,
  Plus,
  BarChart3
} from "lucide-react";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, BarChart, Bar } from 'recharts';
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";

interface PsychologyEntry {
  id: string;
  trade_id: string;
  mood_pre: number;
  mood_post: number;
  adherence_score: number;
  mistake_tags: string[];
  comments: string;
  created_at: string;
  updated_at: string;
}

interface Trade {
  id: string;
  instrument: string;
  pnl: number;
  opened_at: string;
  closed_at: string;
}

const MISTAKE_TAGS = [
  'Revenge Trading',
  'FOMO Entry',
  'No Stop Loss',
  'Overtrade',
  'Early Exit',
  'Wrong Size',
  'Emotional Decision',
  'Ignored Rules',
  'No Plan',
  'Greed',
  'Fear',
  'Impatience'
];

export function PsychologyDashboard() {
  const [entries, setEntries] = useState<PsychologyEntry[]>([]);
  const [trades, setTrades] = useState<Trade[]>([]);
  const [showAddEntry, setShowAddEntry] = useState(false);
  const [selectedTrade, setSelectedTrade] = useState("");
  const [moodVsPnLData, setMoodVsPnLData] = useState<any[]>([]);
  const [mistakeAnalysis, setMistakeAnalysis] = useState<{ [key: string]: number }>({});
  const [reflectionStreak, setReflectionStreak] = useState(0);
  
  // Form state
  const [newEntry, setNewEntry] = useState({
    mood_pre: 5,
    mood_post: 5,
    adherence_score: 5,
    mistake_tags: [] as string[],
    comments: "",
  });

  const { user } = useAuth();
  const { toast } = useToast();

  useEffect(() => {
    if (user) {
      loadData();
    }
  }, [user]);

  useEffect(() => {
    if (entries.length > 0 && trades.length > 0) {
      generateMoodVsPnLChart();
      analyzeMistakes();
      calculateReflectionStreak();
    }
  }, [entries, trades]);

  const loadData = async () => {
    if (!user) return;

    try {
      // Load psychology entries
      const { data: entriesData, error: entriesError } = await supabase
        .from("psychology_entries")
        .select("*")
        .eq("user_id", user.id)
        .order("created_at", { ascending: false });

      if (entriesError) throw entriesError;
      setEntries(entriesData || []);

      // Load trades (recent ones without psychology entries)
      const { data: tradesData, error: tradesError } = await supabase
        .from("trades")
        .select("id, instrument, pnl, opened_at, closed_at")
        .eq("user_id", user.id)
        .not("pnl", "is", null)
        .order("opened_at", { ascending: false })
        .limit(50);

      if (tradesError) throw tradesError;
      setTrades(tradesData || []);

    } catch (error: any) {
      toast({
        variant: "destructive",
        title: "Error loading data",
        description: error.message,
      });
    }
  };

  const generateMoodVsPnLChart = () => {
    const chartData = entries
      .map(entry => {
        const trade = trades.find(t => t.id === entry.trade_id);
        if (!trade) return null;
        
        return {
          date: new Date(entry.created_at).toLocaleDateString(),
          mood_pre: entry.mood_pre,
          mood_post: entry.mood_post,
          pnl: trade.pnl,
          adherence: entry.adherence_score,
        };
      })
      .filter(Boolean)
      .reverse()
      .slice(-20); // Last 20 entries

    setMoodVsPnLData(chartData);
  };

  const analyzeMistakes = () => {
    const analysis: { [key: string]: number } = {};
    
    entries.forEach(entry => {
      entry.mistake_tags.forEach(tag => {
        analysis[tag] = (analysis[tag] || 0) + 1;
      });
    });

    setMistakeAnalysis(analysis);
  };

  const calculateReflectionStreak = () => {
    const today = new Date();
    let streak = 0;
    let currentDate = new Date(today);

    // Go backwards day by day to find consecutive reflection days
    while (true) {
      const dateStr = currentDate.toDateString();
      const hasReflection = entries.some(entry => 
        new Date(entry.created_at).toDateString() === dateStr
      );

      if (hasReflection) {
        streak++;
        currentDate.setDate(currentDate.getDate() - 1);
      } else {
        break;
      }
    }

    setReflectionStreak(streak);
  };

  const addPsychologyEntry = async () => {
    if (!user || !selectedTrade) {
      toast({
        variant: "destructive",
        title: "Error",
        description: "Please select a trade and fill in the details.",
      });
      return;
    }

    try {
      const { error } = await supabase
        .from("psychology_entries")
        .insert({
          user_id: user.id,
          trade_id: selectedTrade,
          mood_pre: newEntry.mood_pre,
          mood_post: newEntry.mood_post,
          adherence_score: newEntry.adherence_score,
          mistake_tags: newEntry.mistake_tags,
          comments: newEntry.comments,
        });

      if (error) throw error;

      toast({
        title: "Psychology entry added",
        description: "Your trading reflection has been recorded.",
      });

      // Reset form
      setNewEntry({
        mood_pre: 5,
        mood_post: 5,
        adherence_score: 5,
        mistake_tags: [],
        comments: "",
      });
      setSelectedTrade("");
      setShowAddEntry(false);
      
      loadData();
    } catch (error: any) {
      toast({
        variant: "destructive",
        title: "Error adding entry",
        description: error.message,
      });
    }
  };

  const toggleMistakeTag = (tag: string) => {
    setNewEntry(prev => ({
      ...prev,
      mistake_tags: prev.mistake_tags.includes(tag)
        ? prev.mistake_tags.filter(t => t !== tag)
        : [...prev.mistake_tags, tag]
    }));
  };

  const tradesWithoutEntries = trades.filter(trade => 
    !entries.some(entry => entry.trade_id === trade.id)
  );

  const topMistakes = Object.entries(mistakeAnalysis)
    .sort(([, a], [, b]) => b - a)
    .slice(0, 3);

  return (
    <div className="space-y-6">
      {/* Stats Overview */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card className="glass-card border-card-border">
          <CardContent className="p-6">
            <div className="flex items-center gap-2 mb-2">
              <Calendar className="w-4 h-4 text-primary" />
              <span className="text-sm text-muted-foreground">Reflection Streak</span>
            </div>
            <div className="text-3xl font-bold text-primary">{reflectionStreak}</div>
            <div className="text-sm text-muted-foreground">
              {reflectionStreak > 0 ? 'Consecutive days' : 'Start reflecting today!'}
            </div>
          </CardContent>
        </Card>

        <Card className="glass-card border-card-border">
          <CardContent className="p-6">
            <div className="flex items-center gap-2 mb-2">
              <Brain className="w-4 h-4 text-success" />
              <span className="text-sm text-muted-foreground">Total Reflections</span>
            </div>
            <div className="text-3xl font-bold text-success">{entries.length}</div>
            <div className="text-sm text-muted-foreground">
              Psychology entries logged
            </div>
          </CardContent>
        </Card>

        <Card className="glass-card border-card-border">
          <CardContent className="p-6">
            <div className="flex items-center gap-2 mb-2">
              <Target className="w-4 h-4 text-warning" />
              <span className="text-sm text-muted-foreground">Avg Adherence</span>
            </div>
            <div className="text-3xl font-bold text-warning">
              {entries.length > 0 
                ? (entries.reduce((sum, e) => sum + e.adherence_score, 0) / entries.length).toFixed(1)
                : '0'
              }/10
            </div>
            <div className="text-sm text-muted-foreground">
              Rule following score
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Add Entry Button */}
      <Card className="glass-card border-card-border">
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="flex items-center gap-2">
              <MessageSquare className="w-5 h-5 text-primary" />
              Trading Psychology Tracker
            </CardTitle>
            <Button onClick={() => setShowAddEntry(!showAddEntry)}>
              <Plus className="w-4 h-4 mr-2" />
              Add Reflection
            </Button>
          </div>
        </CardHeader>
        
        {showAddEntry && (
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Label htmlFor="trade-select">Select Trade</Label>
                <Select value={selectedTrade} onValueChange={setSelectedTrade}>
                  <SelectTrigger>
                    <SelectValue placeholder="Choose a trade..." />
                  </SelectTrigger>
                  <SelectContent>
                    {tradesWithoutEntries.map(trade => (
                      <SelectItem key={trade.id} value={trade.id}>
                        {trade.instrument} - ${trade.pnl?.toFixed(2)} ({new Date(trade.opened_at).toLocaleDateString()})
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div>
                <Label htmlFor="mood-pre">Pre-Trade Mood (1-10)</Label>
                <Input
                  id="mood-pre"
                  type="number"
                  min="1"
                  max="10"
                  value={newEntry.mood_pre}
                  onChange={(e) => setNewEntry(prev => ({ ...prev, mood_pre: parseInt(e.target.value) || 5 }))}
                />
              </div>

              <div>
                <Label htmlFor="mood-post">Post-Trade Mood (1-10)</Label>
                <Input
                  id="mood-post"
                  type="number"
                  min="1"
                  max="10"
                  value={newEntry.mood_post}
                  onChange={(e) => setNewEntry(prev => ({ ...prev, mood_post: parseInt(e.target.value) || 5 }))}
                />
              </div>

              <div>
                <Label htmlFor="adherence">Rule Adherence (1-10)</Label>
                <Input
                  id="adherence"
                  type="number"
                  min="1"
                  max="10"
                  value={newEntry.adherence_score}
                  onChange={(e) => setNewEntry(prev => ({ ...prev, adherence_score: parseInt(e.target.value) || 5 }))}
                />
              </div>
            </div>

            <div>
              <Label>Mistake Tags (if any)</Label>
              <div className="flex flex-wrap gap-2 mt-2">
                {MISTAKE_TAGS.map(tag => (
                  <Badge
                    key={tag}
                    variant={newEntry.mistake_tags.includes(tag) ? "default" : "outline"}
                    className="cursor-pointer"
                    onClick={() => toggleMistakeTag(tag)}
                  >
                    {tag}
                  </Badge>
                ))}
              </div>
            </div>

            <div>
              <Label htmlFor="comments">Reflection Notes</Label>
              <Textarea
                id="comments"
                placeholder="What did you learn from this trade? What would you do differently?"
                value={newEntry.comments}
                onChange={(e) => setNewEntry(prev => ({ ...prev, comments: e.target.value }))}
                rows={4}
              />
            </div>

            <div className="flex gap-2">
              <Button onClick={addPsychologyEntry}>
                Save Reflection
              </Button>
              <Button variant="outline" onClick={() => setShowAddEntry(false)}>
                Cancel
              </Button>
            </div>
          </CardContent>
        )}
      </Card>

      {/* Mood vs P&L Chart */}
      {moodVsPnLData.length > 0 && (
        <Card className="glass-card border-card-border">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <TrendingUp className="w-5 h-5 text-primary" />
              Mood vs P&L Analysis
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <LineChart data={moodVsPnLData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="date" />
                <YAxis yAxisId="mood" domain={[1, 10]} />
                <YAxis yAxisId="pnl" orientation="right" />
                <Tooltip />
                <Line 
                  yAxisId="mood"
                  type="monotone" 
                  dataKey="mood_pre" 
                  stroke="hsl(var(--primary))" 
                  name="Pre-Trade Mood"
                  strokeWidth={2}
                />
                <Line 
                  yAxisId="mood"
                  type="monotone" 
                  dataKey="mood_post" 
                  stroke="hsl(var(--secondary))" 
                  name="Post-Trade Mood"
                  strokeWidth={2}
                />
                <Line 
                  yAxisId="pnl"
                  type="monotone" 
                  dataKey="pnl" 
                  stroke="hsl(var(--success))" 
                  name="P&L ($)"
                  strokeWidth={2}
                />
              </LineChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      )}

      {/* Mistake Analysis */}
      {topMistakes.length > 0 && (
        <Card className="glass-card border-card-border">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <AlertTriangle className="w-5 h-5 text-warning" />
              Top 3 Trading Mistakes
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {topMistakes.map(([mistake, count], index) => (
                <div key={mistake} className="flex items-center justify-between p-3 bg-muted/20 rounded-lg">
                  <div className="flex items-center gap-3">
                    <div className={`w-8 h-8 rounded-full flex items-center justify-center text-white font-bold ${
                      index === 0 ? 'bg-red-500' : index === 1 ? 'bg-orange-500' : 'bg-yellow-500'
                    }`}>
                      {index + 1}
                    </div>
                    <span className="font-semibold">{mistake}</span>
                  </div>
                  <Badge variant="destructive">{count} times</Badge>
                </div>
              ))}
            </div>
            
            <div className="mt-6 p-4 bg-info/5 border border-info/20 rounded-lg">
              <h4 className="font-semibold text-info mb-2">💡 Improvement Tips:</h4>
              <ul className="text-sm space-y-1">
                <li>• Set up alerts to remind yourself of your trading rules</li>
                <li>• Take a 5-minute break before entering any trade</li>
                <li>• Keep a checklist visible during trading sessions</li>
                <li>• Review these mistakes weekly to stay aware</li>
              </ul>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Recent Reflections */}
      <Card className="glass-card border-card-border">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <BarChart3 className="w-5 h-5 text-primary" />
            Recent Reflections
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {entries.length > 0 ? (
              <>
                {entries.slice(0, 5).map(entry => {
                  const trade = trades.find(t => t.id === entry.trade_id);
                  
                  return (
                    <div key={entry.id} className="p-4 bg-muted/10 border border-muted/20 rounded-lg">
                      <div className="flex items-center justify-between mb-2">
                        <h3 className="font-semibold">
                          {trade ? `${trade.instrument} - $${trade.pnl?.toFixed(2)}` : 'Trade'}
                        </h3>
                        <span className="text-sm text-muted-foreground">
                          {new Date(entry.created_at).toLocaleDateString()}
                        </span>
                      </div>
                      
                      <div className="grid grid-cols-3 gap-4 mb-3 text-sm">
                        <div>
                          <span className="text-muted-foreground">Pre-Mood: </span>
                          <span className="font-semibold">{entry.mood_pre}/10</span>
                        </div>
                        <div>
                          <span className="text-muted-foreground">Post-Mood: </span>
                          <span className="font-semibold">{entry.mood_post}/10</span>
                        </div>
                        <div>
                          <span className="text-muted-foreground">Adherence: </span>
                          <span className="font-semibold">{entry.adherence_score}/10</span>
                        </div>
                      </div>
                      
                      {entry.mistake_tags.length > 0 && (
                        <div className="mb-3">
                          <div className="flex flex-wrap gap-1">
                            {entry.mistake_tags.map(tag => (
                              <Badge key={tag} variant="destructive" className="text-xs">
                                {tag}
                              </Badge>
                            ))}
                          </div>
                        </div>
                      )}
                      
                      {entry.comments && (
                        <p className="text-sm text-muted-foreground italic">
                          "{entry.comments}"
                        </p>
                      )}
                    </div>
                  );
                })}
              </>
            ) : (
              <div className="text-center py-8 text-muted-foreground">
                <Brain className="w-12 h-12 mx-auto mb-4 opacity-50" />
                <p>No psychology reflections yet.</p>
                <p className="text-sm">Start adding reflections to track your trading mindset!</p>
              </div>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}