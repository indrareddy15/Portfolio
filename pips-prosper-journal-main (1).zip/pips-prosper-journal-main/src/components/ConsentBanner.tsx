import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Switch } from '@/components/ui/switch';
import { X, Cookie, Shield, BarChart3 } from 'lucide-react';
import { updateConsent } from './GoogleTracking';

interface ConsentPreferences {
  analytics: boolean;
  advertising: boolean;
  functional: boolean; // Always true, non-optional
}

export const ConsentBanner = () => {
  const [isVisible, setIsVisible] = useState(false);
  const [showDetails, setShowDetails] = useState(false);
  const [preferences, setPreferences] = useState<ConsentPreferences>({
    analytics: false,
    advertising: false,
    functional: true
  });

  useEffect(() => {
    // Check if user has already made a consent choice
    const hasConsented = localStorage.getItem('consent_timestamp');
    if (!hasConsented) {
      // Show banner after 1 second delay
      const timer = setTimeout(() => setIsVisible(true), 1000);
      return () => clearTimeout(timer);
    }
  }, []);

  // Auto-dismiss after 3 seconds once visible (does not imply consent)
  useEffect(() => {
    if (!isVisible) return;
    const autoHide = setTimeout(() => setIsVisible(false), 3000);
    return () => clearTimeout(autoHide);
  }, [isVisible]);

  const acceptAll = () => {
    const newPreferences = {
      analytics: true,
      advertising: true,
      functional: true
    };
    setPreferences(newPreferences);
    saveConsent(newPreferences);
  };

  const acceptSelected = () => {
    saveConsent(preferences);
  };

  const declineAll = () => {
    const newPreferences = {
      analytics: false,
      advertising: false,
      functional: true
    };
    setPreferences(newPreferences);
    saveConsent(newPreferences);
  };

  const saveConsent = (prefs: ConsentPreferences) => {
    // Save to localStorage
    localStorage.setItem('consent_preferences', JSON.stringify(prefs));
    localStorage.setItem('consent_timestamp', new Date().toISOString());
    localStorage.setItem('analytics_consent', prefs.analytics.toString());
    localStorage.setItem('marketing_consent', prefs.advertising.toString());
    
    // Update Google Consent Mode
    updateConsent(prefs.analytics, prefs.advertising);
    
    // Hide banner
    setIsVisible(false);
    
    // Track consent given event
    if (typeof window !== 'undefined' && window.dataLayer) {
      window.dataLayer.push({
        event: 'consent_update',
        analytics_storage: prefs.analytics ? 'granted' : 'denied',
        ad_storage: prefs.advertising ? 'granted' : 'denied'
      });
    }
  };

  if (!isVisible) return null;

  return (
    <div className="fixed inset-0 bg-black/50 z-50 flex items-end justify-center p-4">
      <Card className="max-w-2xl w-full bg-background border shadow-2xl">
        <div className="p-6 space-y-4">
          {/* Header */}
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Cookie className="h-5 w-5 text-primary" />
              <h3 className="font-semibold text-lg">Privacy & Cookies</h3>
            </div>
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setIsVisible(false)}
              className="h-8 w-8 p-0"
            >
              <X className="h-4 w-4" />
            </Button>
          </div>

          {/* Description */}
          <p className="text-muted-foreground">
            We use cookies and similar technologies to enhance your experience, analyze traffic, and improve our services. 
            You can choose which types of cookies to allow.
          </p>

          {/* Simple view */}
          {!showDetails && (
            <div className="flex flex-col sm:flex-row gap-3">
              <Button onClick={acceptAll} className="flex-1">
                Accept All
              </Button>
              <Button onClick={declineAll} variant="outline" className="flex-1">
                Decline All
              </Button>
              <Button 
                onClick={() => setShowDetails(true)} 
                variant="ghost" 
                className="flex-1"
              >
                Customize
              </Button>
            </div>
          )}

          {/* Detailed view */}
          {showDetails && (
            <div className="space-y-4">
              <div className="space-y-3">
                {/* Analytics */}
                <div className="flex items-center justify-between p-3 border rounded-lg">
                  <div className="flex items-center gap-3">
                    <BarChart3 className="h-4 w-4 text-muted-foreground" />
                    <div>
                      <h4 className="font-medium">Analytics</h4>
                      <p className="text-sm text-muted-foreground">
                        Help us understand how you use our site
                      </p>
                    </div>
                  </div>
                  <Switch
                    checked={preferences.analytics}
                    onCheckedChange={(checked) => 
                      setPreferences(prev => ({ ...prev, analytics: checked }))
                    }
                  />
                </div>

                {/* Advertising */}
                <div className="flex items-center justify-between p-3 border rounded-lg">
                  <div className="flex items-center gap-3">
                    <Shield className="h-4 w-4 text-muted-foreground" />
                    <div>
                      <h4 className="font-medium">Marketing & Advertising</h4>
                      <p className="text-sm text-muted-foreground">
                        Show relevant ads and measure campaign performance
                      </p>
                    </div>
                  </div>
                  <Switch
                    checked={preferences.advertising}
                    onCheckedChange={(checked) => 
                      setPreferences(prev => ({ ...prev, advertising: checked }))
                    }
                  />
                </div>

                {/* Essential (always on) */}
                <div className="flex items-center justify-between p-3 border rounded-lg bg-muted/30">
                  <div className="flex items-center gap-3">
                    <Shield className="h-4 w-4 text-muted-foreground" />
                    <div>
                      <h4 className="font-medium">Essential</h4>
                      <p className="text-sm text-muted-foreground">
                        Required for basic functionality and security
                      </p>
                    </div>
                  </div>
                  <Switch checked={true} disabled />
                </div>
              </div>

              {/* Action buttons */}
              <div className="flex gap-3">
                <Button onClick={acceptSelected} className="flex-1">
                  Save Preferences
                </Button>
                <Button 
                  onClick={() => setShowDetails(false)} 
                  variant="outline"
                  className="px-6"
                >
                  Back
                </Button>
              </div>
            </div>
          )}

          {/* Legal links */}
          <div className="text-xs text-muted-foreground border-t pt-3">
            <span>By continuing, you agree to our </span>
            <a href="/privacy" className="underline hover:text-foreground">Privacy Policy</a>
            <span> and </span>
            <a href="/cookies" className="underline hover:text-foreground">Cookie Policy</a>
          </div>
        </div>
      </Card>
    </div>
  );
};