import { useState, useEffect } from "react";
import { 
  Dialog, 
  DialogContent, 
  DialogHeader, 
  DialogTitle,
  DialogFooter
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { toast } from "sonner";

interface QnA {
  id?: string;
  title: string;
  description?: string;
  is_active: boolean;
  allow_anonymous: boolean;
  moderated: boolean;
  position: number;
}

interface QnaDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onSave: (qna: Omit<QnA, 'id'>) => void;
  qna?: QnA | null;
}

export default function QnaDialog({ open, onOpenChange, onSave, qna }: QnaDialogProps) {
  const [formData, setFormData] = useState<Omit<QnA, 'id'>>({
    title: '',
    description: '',
    is_active: true,
    allow_anonymous: true,
    moderated: true,
    position: 0
  });

  useEffect(() => {
    if (qna) {
      setFormData({
        title: qna.title,
        description: qna.description || '',
        is_active: qna.is_active,
        allow_anonymous: qna.allow_anonymous,
        moderated: qna.moderated,
        position: qna.position
      });
    } else {
      setFormData({
        title: '',
        description: '',
        is_active: true,
        allow_anonymous: true,
        moderated: true,
        position: 0
      });
    }
  }, [qna, open]);

  const handleSave = () => {
    if (!formData.title.trim()) {
      toast.error('Q&A title is required');
      return;
    }

    onSave(formData);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle>{qna ? 'Edit Q&A Section' : 'Create Q&A Section'}</DialogTitle>
        </DialogHeader>

        <div className="space-y-4">
          <div>
            <Label htmlFor="qna-title">Title *</Label>
            <Input
              id="qna-title"
              value={formData.title}
              onChange={(e) => setFormData(prev => ({ ...prev, title: e.target.value }))}
              placeholder="Questions & Answers"
            />
          </div>

          <div>
            <Label htmlFor="qna-description">Description (optional)</Label>
            <Textarea
              id="qna-description"
              value={formData.description}
              onChange={(e) => setFormData(prev => ({ ...prev, description: e.target.value }))}
              placeholder="Instructions for users asking questions..."
              rows={3}
            />
          </div>

          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-2">
                <Switch
                  id="is-active"
                  checked={formData.is_active}
                  onCheckedChange={(checked) => 
                    setFormData(prev => ({ ...prev, is_active: checked }))
                  }
                />
                <Label htmlFor="is-active">Active</Label>
              </div>
              
              <div className="flex items-center space-x-2">
                <Switch
                  id="allow-anonymous"
                  checked={formData.allow_anonymous}
                  onCheckedChange={(checked) => 
                    setFormData(prev => ({ ...prev, allow_anonymous: checked }))
                  }
                />
                <Label htmlFor="allow-anonymous">Allow Anonymous Questions</Label>
              </div>
            </div>

            <div className="flex items-center space-x-2">
              <Switch
                id="moderated"
                checked={formData.moderated}
                onCheckedChange={(checked) => 
                  setFormData(prev => ({ ...prev, moderated: checked }))
                }
              />
              <Label htmlFor="moderated">Moderate Questions (require approval)</Label>
            </div>
          </div>

          <div className="text-sm text-muted-foreground">
            <p><strong>Note:</strong> Questions will need to be approved in the admin panel before appearing publicly.</p>
            <p>Readers can upvote questions to help prioritize which ones get answered first.</p>
          </div>
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            Cancel
          </Button>
          <Button onClick={handleSave}>
            {qna ? 'Update Q&A' : 'Create Q&A'}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}