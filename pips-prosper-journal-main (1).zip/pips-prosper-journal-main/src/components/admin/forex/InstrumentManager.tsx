import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Plus, Edit, Upload, Trash2, Search, Download } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { useRealtime } from "@/hooks/useRealtime";

interface Instrument {
  id: string;
  symbol: string;
  class: string;
  pricing_mode: string;
  base_ccy: string;
  quote_ccy: string;
  lot_units: number;
  pip_size: number;
  price_precision: number;
  pip_precision: number;
  description?: string;
  is_active: boolean;
  created_at: string;
  updated_at: string;
}

export function InstrumentManager() {
  const [instruments, setInstruments] = useState<Instrument[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedInstrument, setSelectedInstrument] = useState<Instrument | null>(null);
  const [showDialog, setShowDialog] = useState(false);
  const [showImportDialog, setShowImportDialog] = useState(false);
  const [importFile, setImportFile] = useState<File | null>(null);
  const [importing, setImporting] = useState(false);
  const { toast } = useToast();

  const fetchInstruments = async () => {
    try {
      const { data, error } = await supabase
        .from('instruments')
        .select('*')
        .order('symbol');
      
      if (error) throw error;
      setInstruments(data || []);
    } catch (error: any) {
      toast({
        title: "Error",
        description: "Failed to load instruments",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  // Real-time updates
  useRealtime([
    {
      table: 'instruments',
      events: ['INSERT', 'UPDATE', 'DELETE'],
      onInsert: () => fetchInstruments(),
      onUpdate: () => fetchInstruments(),
      onDelete: () => fetchInstruments(),
      showToasts: false
    }
  ]);

  useEffect(() => {
    fetchInstruments();
  }, []);

  const filteredInstruments = instruments.filter(instrument =>
    instrument.symbol.toLowerCase().includes(searchTerm.toLowerCase()) ||
    instrument.description?.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const formData = new FormData(e.currentTarget);
    
    const instrumentData = {
      symbol: (formData.get("symbol") as string).toUpperCase(),
      class: formData.get("class") as string,
      pricing_mode: formData.get("pricing_mode") as string,
      base_ccy: (formData.get("base_ccy") as string).toUpperCase(),
      quote_ccy: (formData.get("quote_ccy") as string).toUpperCase(),
      lot_units: parseInt(formData.get("lot_units") as string),
      pip_size: parseFloat(formData.get("pip_size") as string),
      price_precision: parseInt(formData.get("price_precision") as string),
      pip_precision: parseInt(formData.get("pip_precision") as string),
      description: formData.get("description") as string,
      is_active: formData.get("is_active") === "on"
    };

    try {
      let result;
      if (selectedInstrument) {
        result = await supabase
          .from('instruments')
          .update(instrumentData)
          .eq('id', selectedInstrument.id);
      } else {
        result = await supabase
          .from('instruments')
          .insert([instrumentData]);
      }

      if (result.error) throw result.error;

      toast({
        title: "Success",
        description: `Instrument ${selectedInstrument ? 'updated' : 'created'} successfully`
      });

      setShowDialog(false);
      setSelectedInstrument(null);
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive"
      });
    }
  };

  const handleDelete = async (instrument: Instrument) => {
    if (!confirm(`Are you sure you want to delete ${instrument.symbol}?`)) return;

    try {
      const { error } = await supabase
        .from('instruments')
        .delete()
        .eq('id', instrument.id);

      if (error) throw error;

      toast({
        title: "Success",
        description: "Instrument deleted successfully"
      });
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive"
      });
    }
  };

  const handleImport = async () => {
    if (!importFile) return;

    setImporting(true);
    try {
      const text = await importFile.text();
      const data = JSON.parse(text);
      
      if (!Array.isArray(data)) {
        throw new Error("Import file must contain an array of instruments");
      }

      const instrumentsToImport = data.map((item: any) => ({
        symbol: item.symbol?.toUpperCase() || '',
        class: item.class || 'forex',
        pricing_mode: item.pricingMode || 'forex',
        base_ccy: item.baseCcy?.toUpperCase() || item.symbol?.substring(0, 3)?.toUpperCase() || '',
        quote_ccy: item.quoteCcy?.toUpperCase() || item.symbol?.substring(3, 6)?.toUpperCase() || '',
        lot_units: item.lotUnits || 100000,
        pip_size: item.pipSize || (item.quoteCcy === 'JPY' ? 0.01 : 0.0001),
        price_precision: item.pricePrecision || (item.quoteCcy === 'JPY' ? 3 : 5),
        pip_precision: item.pipPrecision || (item.quoteCcy === 'JPY' ? 2 : 1),
        description: item.description || `${item.baseCcy || item.symbol?.substring(0, 3)} vs ${item.quoteCcy || item.symbol?.substring(3, 6)}`,
        is_active: true
      }));

      const { error } = await supabase
        .from('instruments')
        .upsert(instrumentsToImport, { onConflict: 'symbol' });

      if (error) throw error;

      toast({
        title: "Success",
        description: `Imported ${instrumentsToImport.length} instruments`
      });

      setShowImportDialog(false);
      setImportFile(null);
    } catch (error: any) {
      toast({
        title: "Import Error",
        description: error.message,
        variant: "destructive"
      });
    } finally {
      setImporting(false);
    }
  };

  const exportInstruments = () => {
    const dataStr = JSON.stringify(instruments, null, 2);
    const dataBlob = new Blob([dataStr], { type: 'application/json' });
    const url = URL.createObjectURL(dataBlob);
    const link = document.createElement('a');
    link.href = url;
    link.download = 'forex_instruments.json';
    link.click();
    URL.revokeObjectURL(url);
  };

  if (loading) {
    return <div className="animate-pulse">Loading instruments...</div>;
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold">Forex Instruments</h2>
          <p className="text-muted-foreground">Manage Forex pairs and their configurations</p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" onClick={exportInstruments}>
            <Download className="w-4 h-4 mr-2" />
            Export
          </Button>
          <Dialog open={showImportDialog} onOpenChange={setShowImportDialog}>
            <DialogTrigger asChild>
              <Button variant="outline">
                <Upload className="w-4 h-4 mr-2" />
                Import
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Import Instruments</DialogTitle>
              </DialogHeader>
              <div className="space-y-4">
                <div>
                  <Label htmlFor="import-file">JSON File</Label>
                  <Input
                    id="import-file"
                    type="file"
                    accept=".json"
                    onChange={(e) => setImportFile(e.target.files?.[0] || null)}
                  />
                </div>
                <Button onClick={handleImport} disabled={!importFile || importing}>
                  {importing ? "Importing..." : "Import"}
                </Button>
              </div>
            </DialogContent>
          </Dialog>
          <Dialog open={showDialog} onOpenChange={setShowDialog}>
            <DialogTrigger asChild>
              <Button onClick={() => setSelectedInstrument(null)}>
                <Plus className="w-4 h-4 mr-2" />
                Add Instrument
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-2xl">
              <DialogHeader>
                <DialogTitle>
                  {selectedInstrument ? 'Edit Instrument' : 'Add New Instrument'}
                </DialogTitle>
              </DialogHeader>
              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="symbol">Symbol *</Label>
                    <Input
                      id="symbol"
                      name="symbol"
                      defaultValue={selectedInstrument?.symbol}
                      placeholder="EURUSD"
                      required
                    />
                  </div>
                  <div>
                    <Label htmlFor="class">Class</Label>  
                    <Input
                      id="class"
                      name="class"
                      defaultValue={selectedInstrument?.class || "forex"}
                      placeholder="forex"
                    />
                  </div>
                  <div>
                    <Label htmlFor="base_ccy">Base Currency *</Label>
                    <Input
                      id="base_ccy"
                      name="base_ccy"
                      defaultValue={selectedInstrument?.base_ccy}
                      placeholder="EUR"
                      required
                    />
                  </div>
                  <div>
                    <Label htmlFor="quote_ccy">Quote Currency *</Label>
                    <Input
                      id="quote_ccy"
                      name="quote_ccy"
                      defaultValue={selectedInstrument?.quote_ccy}
                      placeholder="USD"
                      required
                    />
                  </div>
                  <div>
                    <Label htmlFor="lot_units">Lot Units</Label>
                    <Input
                      id="lot_units"
                      name="lot_units"
                      type="number"
                      defaultValue={selectedInstrument?.lot_units || 100000}
                    />
                  </div>
                  <div>
                    <Label htmlFor="pip_size">Pip Size</Label>
                    <Input
                      id="pip_size"
                      name="pip_size"
                      type="number"
                      step="0.00001"
                      defaultValue={selectedInstrument?.pip_size || 0.0001}
                    />
                  </div>
                  <div>
                    <Label htmlFor="price_precision">Price Precision</Label>
                    <Input
                      id="price_precision"
                      name="price_precision"
                      type="number"
                      defaultValue={selectedInstrument?.price_precision || 5}
                    />
                  </div>
                  <div>
                    <Label htmlFor="pip_precision">Pip Precision</Label>
                    <Input
                      id="pip_precision"
                      name="pip_precision"
                      type="number"
                      defaultValue={selectedInstrument?.pip_precision || 1}
                    />
                  </div>
                </div>
                <div>
                  <Label htmlFor="description">Description</Label>
                  <Textarea
                    id="description"
                    name="description"
                    defaultValue={selectedInstrument?.description}
                    placeholder="Euro vs US Dollar"
                  />
                </div>
                <div className="flex items-center space-x-2">
                  <Switch
                    id="is_active"
                    name="is_active"
                    defaultChecked={selectedInstrument?.is_active ?? true}
                  />
                  <Label htmlFor="is_active">Active</Label>
                </div>
                <div className="flex justify-end space-x-2">
                  <Button type="button" variant="outline" onClick={() => setShowDialog(false)}>
                    Cancel
                  </Button>
                  <Button type="submit">
                    {selectedInstrument ? 'Update' : 'Create'}
                  </Button>
                </div>
              </form>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle>Instruments ({filteredInstruments.length})</CardTitle>
            <div className="flex items-center space-x-2">
              <Search className="w-4 h-4 text-muted-foreground" />
              <Input
                placeholder="Search instruments..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-64"
              />
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Symbol</TableHead>
                <TableHead>Currencies</TableHead>
                <TableHead>Lot Units</TableHead>
                <TableHead>Pip Size</TableHead>
                <TableHead>Precision</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredInstruments.map((instrument) => (
                <TableRow key={instrument.id}>
                  <TableCell className="font-mono font-semibold">
                    {instrument.symbol}
                  </TableCell>
                  <TableCell>
                    <span className="text-sm">
                      {instrument.base_ccy} / {instrument.quote_ccy}
                    </span>
                  </TableCell>
                  <TableCell>{instrument.lot_units.toLocaleString()}</TableCell>
                  <TableCell>{instrument.pip_size}</TableCell>
                  <TableCell>
                    <span className="text-xs">
                      Price: {instrument.price_precision}, Pip: {instrument.pip_precision}
                    </span>
                  </TableCell>
                  <TableCell>
                    <Badge variant={instrument.is_active ? "default" : "secondary"}>
                      {instrument.is_active ? "Active" : "Inactive"}
                    </Badge>
                  </TableCell>
                  <TableCell>
                    <div className="flex space-x-2">
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => {
                          setSelectedInstrument(instrument);
                          setShowDialog(true);
                        }}
                      >
                        <Edit className="w-4 h-4" />
                      </Button>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => handleDelete(instrument)}
                        className="text-red-600 hover:text-red-700"
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
}