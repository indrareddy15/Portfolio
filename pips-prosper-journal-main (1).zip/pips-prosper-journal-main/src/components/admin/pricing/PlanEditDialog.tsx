import { useState, useEffect } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "@/hooks/use-toast";

interface Plan {
  id: string;
  name: string;
  description: string;
  price_amount: number;
  price_currency: string;
  billing_cycle: string;
  is_active: boolean;
  sort_order: number;
  stripe_product_id?: string;
  stripe_price_id?: string;
}

interface PlanEditDialogProps {
  plan: Plan | null;
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onSuccess: () => void;
}

export function PlanEditDialog({ plan, open, onOpenChange, onSuccess }: PlanEditDialogProps) {
  const [formData, setFormData] = useState({
    name: '',
    description: '',
    price_amount: 0,
    price_currency: 'USD',
    billing_cycle: 'monthly',
    is_active: true,
    sort_order: 1
  });
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (plan) {
      setFormData({
        name: plan.name,
        description: plan.description || '',
        price_amount: plan.price_amount,
        price_currency: plan.price_currency,
        billing_cycle: plan.billing_cycle,
        is_active: plan.is_active,
        sort_order: plan.sort_order
      });
    } else {
      // Reset for new plan
      setFormData({
        name: '',
        description: '',
        price_amount: 0,
        price_currency: 'USD',
        billing_cycle: 'monthly',
        is_active: true,
        sort_order: 1
      });
    }
  }, [plan, open]);

  const createStripeProduct = async (planData: any) => {
    try {
      console.log('Creating Stripe product for plan:', planData);
      
      // Call Stripe edge function to create product and price
      const { data: stripeData, error: stripeError } = await supabase.functions.invoke('create-stripe-product', {
        body: {
          name: planData.name,
          description: planData.description,
          price_amount: planData.price_amount,
          currency: planData.price_currency,
          billing_cycle: planData.billing_cycle
        }
      });

      if (stripeError) {
        console.error('Stripe product creation error:', stripeError);
        throw new Error(`Failed to create Stripe product: ${stripeError.message}`);
      }

      return stripeData;
    } catch (error) {
      console.error('Error creating Stripe product:', error);
      // Don't throw here - we'll save the plan without Stripe IDs and show a warning
      toast({
        title: "Warning",
        description: "Plan saved but Stripe integration failed. You may need to set up Stripe manually.",
        variant: "destructive"
      });
      return null;
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    try {
      let stripeData = null;

      // Create Stripe product/price if this is a paid plan
      if (formData.price_amount > 0) {
        stripeData = await createStripeProduct(formData);
      }

      const planPayload = {
        ...formData,
        billing_cycle: formData.billing_cycle as "monthly" | "yearly",
        stripe_product_id: stripeData?.product_id || null,
        stripe_price_id: stripeData?.price_id || null
      };

      let result;
      if (plan) {
        // Update existing plan
        result = await supabase
          .from('plans')
          .update(planPayload)
          .eq('id', plan.id)
          .select();
      } else {
        // Create new plan
        result = await supabase
          .from('plans')
          .insert(planPayload)
          .select();
      }

      if (result.error) throw result.error;

      toast({
        title: "Success",
        description: `Plan ${plan ? 'updated' : 'created'} successfully`
      });

      onSuccess();
    } catch (error: any) {
      console.error('Error saving plan:', error);
      toast({
        title: "Error",
        description: error.message || `Failed to ${plan ? 'update' : 'create'} plan`,
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[600px]">
        <DialogHeader>
          <DialogTitle>{plan ? 'Edit Plan' : 'Create New Plan'}</DialogTitle>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="name">Plan Name *</Label>
              <Input
                id="name"
                value={formData.name}
                onChange={(e) => setFormData(prev => ({ ...prev, name: e.target.value }))}
                placeholder="e.g. Pro, Premium"
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="price">Price *</Label>
              <Input
                id="price"
                type="number"
                step="0.01"
                min="0"
                value={formData.price_amount}
                onChange={(e) => setFormData(prev => ({ ...prev, price_amount: parseFloat(e.target.value) || 0 }))}
                placeholder="0.00"
                required
              />
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="description">Description</Label>
            <Textarea
              id="description"
              value={formData.description}
              onChange={(e) => setFormData(prev => ({ ...prev, description: e.target.value }))}
              placeholder="Brief description of the plan"
              rows={2}
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="currency">Currency</Label>
              <Select value={formData.price_currency} onValueChange={(value) => setFormData(prev => ({ ...prev, price_currency: value }))}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="USD">USD</SelectItem>
                  <SelectItem value="EUR">EUR</SelectItem>
                  <SelectItem value="GBP">GBP</SelectItem>
                  <SelectItem value="INR">INR</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="billing_cycle">Billing Cycle</Label>
              <Select value={formData.billing_cycle} onValueChange={(value) => setFormData(prev => ({ ...prev, billing_cycle: value }))}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="monthly">Monthly</SelectItem>
                  <SelectItem value="yearly">Yearly</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="sort_order">Sort Order</Label>
              <Input
                id="sort_order"
                type="number"
                min="1"
                value={formData.sort_order}
                onChange={(e) => setFormData(prev => ({ ...prev, sort_order: parseInt(e.target.value) || 1 }))}
              />
            </div>

            <div className="flex items-center space-x-2 pt-6">
              <Switch
                id="is_active"
                checked={formData.is_active}
                onCheckedChange={(checked) => setFormData(prev => ({ ...prev, is_active: checked }))}
              />
              <Label htmlFor="is_active">Active</Label>
            </div>
          </div>

          {plan?.stripe_product_id && (
            <div className="p-3 bg-muted rounded-lg">
              <div className="text-sm font-medium mb-1">Stripe Integration</div>
              <div className="text-xs text-muted-foreground space-y-1">
                <div>Product ID: {plan.stripe_product_id}</div>
                <div>Price ID: {plan.stripe_price_id}</div>
              </div>
            </div>
          )}

          <div className="flex justify-end space-x-2 pt-4">
            <Button
              type="button"
              variant="outline"
              onClick={() => onOpenChange(false)}
              disabled={loading}
            >
              Cancel
            </Button>
            <Button type="submit" disabled={loading}>
              {loading ? (plan ? 'Updating...' : 'Creating...') : (plan ? 'Update Plan' : 'Create Plan')}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}