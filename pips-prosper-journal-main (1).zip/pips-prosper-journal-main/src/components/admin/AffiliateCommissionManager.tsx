import { useState, useEffect } from "react";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Pencil, Save, X, Users, Percent, Code } from "lucide-react";
import { Separator } from "@/components/ui/separator";
import { useRealtime } from "@/hooks/useRealtime";

interface Affiliate {
  id: string;
  user_id: string;
  code: string;
  default_rate_pct: number;
  status: string;
  created_at: string;
  lifetime_approved_count: number;
}

export const AffiliateCommissionManager = () => {
  const [affiliates, setAffiliates] = useState<Affiliate[]>([]);
  const [loading, setLoading] = useState(true);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editValue, setEditValue] = useState<number>(0);
  const [editingCodeId, setEditingCodeId] = useState<string | null>(null);
  const [editCodeValue, setEditCodeValue] = useState<string>("");
  const [globalRate, setGlobalRate] = useState<number>(10);
  const { toast } = useToast();

  useEffect(() => {
    fetchAffiliates();
  }, []);

  // Real-time updates for affiliates
  useRealtime([
    {
      table: 'affiliates',
      events: ['INSERT', 'UPDATE', 'DELETE'],
      onInsert: (payload) => {
        console.log('New affiliate:', payload.new);
        fetchAffiliates();
        toast({
          title: "New Affiliate Added! 🎉",
          description: `Affiliate ${payload.new.code} has been created`,
        });
      },
      onUpdate: (payload) => {
        console.log('Affiliate updated:', payload.new);
        setAffiliates(prev => 
          prev.map(affiliate => 
            affiliate.id === payload.new.id 
              ? { ...affiliate, ...payload.new }
              : affiliate
          )
        );
        if (payload.old.default_rate_pct !== payload.new.default_rate_pct) {
          toast({
            title: "Commission Rate Updated",
            description: `${payload.new.code} rate changed to ${payload.new.default_rate_pct}%`,
          });
        }
        if (payload.old.code !== payload.new.code) {
          toast({
            title: "Affiliate Code Updated",
            description: `Code changed to ${payload.new.code}`,
          });
        }
      },
      onDelete: (payload) => {
        console.log('Affiliate deleted:', payload.old);
        setAffiliates(prev => prev.filter(aff => aff.id !== payload.old.id));
        toast({
          title: "Affiliate Removed",
          description: `Affiliate ${payload.old.code} has been deleted`,
        });
      },
      channelName: 'affiliate-commission-realtime'
    }
  ]);

  const fetchAffiliates = async () => {
    try {
      const { data, error } = await supabase
        .from('affiliates')
        .select('*')
        .order('created_at', { ascending: false });

      if (error) throw error;
      setAffiliates(data || []);
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to fetch affiliates",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const updateAffiliateCode = async (affiliateId: string, newCode: string) => {
    if (!newCode || newCode.trim().length === 0) {
      toast({
        title: "Invalid Code",
        description: "Affiliate code cannot be empty",
        variant: "destructive",
      });
      return;
    }

    try {
      const { error } = await supabase
        .from('affiliates')
        .update({ code: newCode.trim() })
        .eq('id', affiliateId);

      if (error) throw error;

      setEditingCodeId(null);
      toast({
        title: "Affiliate Code Updated",
        description: `Affiliate code updated to ${newCode}`,
      });
    } catch (error) {
      console.error('Error updating affiliate code:', error);
      toast({
        title: "Error",
        description: "Failed to update affiliate code. Code might already exist.",
        variant: "destructive",
      });
    }
  };

  const updateCommission = async (affiliateId: string, newRate: number) => {
    if (newRate < 0 || newRate > 100) {
      toast({
        title: "Invalid Rate",
        description: "Commission rate must be between 0% and 100%",
        variant: "destructive",
      });
      return;
    }

    try {
      const { error } = await supabase
        .from('affiliates')
        .update({ default_rate_pct: newRate })
        .eq('id', affiliateId);

      if (error) throw error;

      setEditingId(null);
      toast({
        title: "Commission Updated",
        description: `Commission rate updated to ${newRate}%`,
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to update commission rate",
        variant: "destructive",
      });
    }
  };

  const updateGlobalCommission = async () => {
    if (globalRate < 0 || globalRate > 100) {
      toast({
        title: "Invalid Rate",
        description: "Commission rate must be between 0% and 100%",
        variant: "destructive",
      });
      return;
    }

    try {
      const { error } = await supabase
        .from('affiliates')
        .update({ default_rate_pct: globalRate });

      if (error) throw error;

      setAffiliates(prev => 
        prev.map(affiliate => ({ ...affiliate, default_rate_pct: globalRate }))
      );

      toast({
        title: "Global Commission Updated",
        description: `All affiliate commission rates updated to ${globalRate}%`,
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to update global commission rate",
        variant: "destructive",
      });
    }
  };

  const startEditing = (id: string, currentRate: number) => {
    setEditingId(id);
    setEditValue(currentRate);
  };

  const cancelEditing = () => {
    setEditingId(null);
    setEditValue(0);
  };

  const startEditingCode = (id: string, currentCode: string) => {
    setEditingCodeId(id);
    setEditCodeValue(currentCode);
  };

  const cancelEditingCode = () => {
    setEditingCodeId(null);
    setEditCodeValue("");
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'active': return 'text-success border-success';
      case 'pending': return 'text-warning border-warning';
      case 'rejected': return 'text-destructive border-destructive';
      default: return 'text-muted-foreground border-muted';
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center p-8">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Global Commission Control */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Percent className="h-5 w-5" />
            Global Commission Settings
          </CardTitle>
          <CardDescription>
            Set commission rates for all affiliates at once or manage individual rates (Real-time updates enabled)
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex items-center gap-4">
            <div className="flex-1 max-w-xs">
              <Label htmlFor="globalRate">Global Commission Rate (%)</Label>
              <Input
                id="globalRate"
                type="number"
                min="0"
                max="100"
                step="0.01"
                value={globalRate}
                onChange={(e) => setGlobalRate(parseFloat(e.target.value) || 0)}
                className="mt-1"
              />
            </div>
            <Button onClick={updateGlobalCommission} className="mt-6">
              Update All Affiliates
            </Button>
          </div>
        </CardContent>
      </Card>

      <Separator />

      {/* Individual Affiliate Management */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Users className="h-5 w-5" />
            Individual Affiliate Commission & Codes
          </CardTitle>
          <CardDescription>
            Manage commission rates and custom codes for individual affiliates
          </CardDescription>
        </CardHeader>
        <CardContent>
          {affiliates.length === 0 ? (
            <div className="text-center py-8 text-muted-foreground">
              No affiliates found
            </div>
          ) : (
            <div className="rounded-md border">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Affiliate Code</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Commission Rate</TableHead>
                    <TableHead>Approved Count</TableHead>
                    <TableHead>Joined Date</TableHead>
                    <TableHead>Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {affiliates.map((affiliate) => (
                    <TableRow key={affiliate.id}>
                      <TableCell className="font-medium">
                        {editingCodeId === affiliate.id ? (
                          <div className="flex items-center gap-2">
                            <Input
                              type="text"
                              value={editCodeValue}
                              onChange={(e) => setEditCodeValue(e.target.value)}
                              className="w-32"
                              placeholder="Enter code"
                            />
                            <Button
                              size="sm"
                              onClick={() => updateAffiliateCode(affiliate.id, editCodeValue)}
                            >
                              <Save className="h-3 w-3" />
                            </Button>
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={cancelEditingCode}
                            >
                              <X className="h-3 w-3" />
                            </Button>
                          </div>
                        ) : (
                          <div className="flex items-center gap-2">
                            <span>{affiliate.code}</span>
                            <Button
                              size="sm"
                              variant="ghost"
                              onClick={() => startEditingCode(affiliate.id, affiliate.code)}
                            >
                              <Code className="h-3 w-3" />
                            </Button>
                          </div>
                        )}
                      </TableCell>
                      <TableCell>
                        <Badge variant="outline" className={getStatusColor(affiliate.status)}>
                          {affiliate.status}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        {editingId === affiliate.id ? (
                          <div className="flex items-center gap-2">
                            <Input
                              type="number"
                              min="0"
                              max="100"
                              step="0.01"
                              value={editValue}
                              onChange={(e) => setEditValue(parseFloat(e.target.value) || 0)}
                              className="w-20"
                            />
                            <span>%</span>
                          </div>
                        ) : (
                          <span className="font-medium">{affiliate.default_rate_pct}%</span>
                        )}
                      </TableCell>
                      <TableCell>{affiliate.lifetime_approved_count}</TableCell>
                      <TableCell>
                        {new Date(affiliate.created_at).toLocaleDateString()}
                      </TableCell>
                      <TableCell>
                        {editingId === affiliate.id ? (
                          <div className="flex items-center gap-1">
                            <Button
                              size="sm"
                              onClick={() => updateCommission(affiliate.id, editValue)}
                            >
                              <Save className="h-4 w-4" />
                            </Button>
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={cancelEditing}
                            >
                              <X className="h-4 w-4" />
                            </Button>
                          </div>
                        ) : (
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => startEditing(affiliate.id, affiliate.default_rate_pct)}
                          >
                            <Pencil className="h-4 w-4" />
                          </Button>
                        )}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
};