import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { TrendingUp, TrendingDown, Search, Filter, Edit, Trash2, Eye, RefreshCw, Wifi, WifiOff, Share, Award, Link2, Trophy } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { useTradesRealtime } from "@/hooks/useRealtime";
import { useAccountContext } from "@/hooks/useAccountContext";
import { useTradeSharing } from "@/hooks/useTradeSharing";
import { EditTradeDialog } from "@/components/EditTradeDialog";
import { TradeDetailView } from "@/components/TradeDetailView";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { ShareTradeDialog } from "@/components/TradeSharing/ShareTradeDialog";

interface Trade {
  id: string;
  instrument: string;
  side: string;
  entry_price: number;
  exit_price: number | null;
  size: number;
  stop_loss: number | null;
  take_profit: number | null;
  risk_percent: number | null;
  pnl: number | null;
  result: string | null;
  opened_at: string;
  closed_at: string | null;
  notes_pre: string | null;
  notes_post: string | null;
}

interface TradesTableProps {
  refreshTrigger?: number;
}

export function TradesTable({ refreshTrigger }: TradesTableProps) {
  const [trades, setTrades] = useState<Trade[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState("");
  const [filterResult, setFilterResult] = useState<string>("all");
  const [editingTrade, setEditingTrade] = useState<Trade | null>(null);
  const [editDialogOpen, setEditDialogOpen] = useState(false);
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [tradeToDelete, setTradeToDelete] = useState<Trade | null>(null);
  const [selectedTrade, setSelectedTrade] = useState<Trade | null>(null);
  const [showShareDialog, setShowShareDialog] = useState(false);
  const [detailViewOpen, setDetailViewOpen] = useState(false);
  const [isRealTimeConnected, setIsRealTimeConnected] = useState(false);
  const [lastUpdate, setLastUpdate] = useState(new Date());
  const { user } = useAuth();
  const { toast } = useToast();
  const { selectedAccountId } = useAccountContext();
  const { createTradeShare, generateCertificate } = useTradeSharing();

  const fetchTrades = async () => {
    if (!user) return;

    try {
      let query = supabase
        .from("trades")
        .select("*")
        .eq("user_id", user.id);

      // Filter by selected account if not "all"
      if (selectedAccountId && selectedAccountId !== "all") {
        query = query.eq("account_id", selectedAccountId);
      }

      const { data, error } = await query.order("opened_at", { ascending: false });

      if (error) throw error;
      setTrades(data || []);
      setLastUpdate(new Date());
    } catch (error: any) {
      toast({
        variant: "destructive",
        title: "Error loading trades",
        description: error.message,
      });
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchTrades();
  }, [user, refreshTrigger, selectedAccountId]);

  // Real-time trades updates with connection status
  useEffect(() => {
    if (!user?.id) return;

    const channel = supabase
      .channel(`trades-realtime-${user.id}`)
      .on(
        'postgres_changes',
        {
          event: 'INSERT',
          schema: 'public',
          table: 'trades',
          filter: `user_id=eq.${user.id}`
        },
        (payload) => {
          console.log('New trade added:', payload.new);
          setTrades(prev => [payload.new as Trade, ...prev]);
          setLastUpdate(new Date());
          toast({
            title: "New Trade Added! 📈",
            description: `${payload.new.side?.toUpperCase()} ${payload.new.instrument} at ${payload.new.entry_price}`,
            duration: 3000,
          });
        }
      )
      .on(
        'postgres_changes',
        {
          event: 'UPDATE',
          schema: 'public',
          table: 'trades',
          filter: `user_id=eq.${user.id}`
        },
        (payload) => {
          console.log('Trade updated:', payload.new);
          setTrades(prev => prev.map(trade => 
            trade.id === payload.new.id ? payload.new as Trade : trade
          ));
          setLastUpdate(new Date());
          
          // Show notification if trade was closed
          if (payload.old.closed_at === null && payload.new.closed_at !== null) {
            toast({
              title: `Trade Closed! ${payload.new.result === 'win' ? '🎉' : '📉'}`,
              description: `${payload.new.instrument} ${payload.new.result?.toUpperCase()} - P/L: ${payload.new.pnl}`,
              duration: 3000,
            });
          }
        }
      )
      .on(
        'postgres_changes',
        {
          event: 'DELETE',
          schema: 'public',
          table: 'trades',
          filter: `user_id=eq.${user.id}`
        },
        (payload) => {
          console.log('Trade deleted:', payload.old);
          setTrades(prev => prev.filter(trade => trade.id !== payload.old.id));
          setLastUpdate(new Date());
          toast({
            title: "Trade Deleted",
            description: `${payload.old.instrument} trade has been removed`,
            duration: 2000,
          });
        }
      )
      .subscribe((status) => {
        if (status === 'SUBSCRIBED') {
          setIsRealTimeConnected(true);
          console.log('Trades real-time connection established');
        } else if (status === 'CHANNEL_ERROR') {
          setIsRealTimeConnected(false);
          console.error('Trades real-time connection failed');
        }
      });

    return () => {
      supabase.removeChannel(channel);
      setIsRealTimeConnected(false);
    };
  }, [user?.id, toast]);

  const handleEditTrade = (trade: Trade) => {
    setEditingTrade(trade);
    setEditDialogOpen(true);
  };

  const handleDeleteTrade = (trade: Trade) => {
    setTradeToDelete(trade);
    setDeleteDialogOpen(true);
  };

  const handleViewTradeDetails = (trade: Trade) => {
    setSelectedTrade(trade);
    setDetailViewOpen(true);
  };

  const handleShareTrade = async (trade: Trade) => {
    try {
      const share = await createTradeShare({
        trade_id: trade.id,
        title: `${trade.pnl && trade.pnl > 0 ? 'Profitable' : 'Learning'} ${trade.instrument} Trade`,
        description: `P&L: ${formatPnL(trade.pnl)} — Shared via PipTrackr`,
        is_public: true,
      });

      if (share) {
        const hostname = window.location.hostname;
        let base = window.location.origin;
        if (hostname.startsWith('app.')) {
          base = base.replace('//app.', '//');
        }
        const shareUrl = `${base}/shared/trade/${share.share_token}`;
        
        // Copy to clipboard
        await navigator.clipboard.writeText(shareUrl);
        
        toast({
          title: "🔗 Share link copied!",
          description: "Trade share link copied to clipboard",
        });

        // Auto-generate certificate
        generateCertificate(share.id);
      }
    } catch (error: any) {
      toast({
        title: "Error sharing trade",
        description: error.message,
        variant: "destructive",
      });
    }
  };

  const handleGenerateCertificate = async (trade: Trade) => {
    try {
      // First create a share if it doesn't exist
      const share = await createTradeShare({
        trade_id: trade.id,
        title: `Trading Certificate - ${trade.instrument} Trade`,
        description: `Professional trading certificate for ${trade.instrument} trade`,
        is_public: true,
      });

      if (share) {
        await generateCertificate(share.id);
        toast({
          title: "🏆 Certificate Generated!",
          description: "Your trading certificate is ready",
        });
      }
    } catch (error: any) {
      toast({
        title: "Error generating certificate",
        description: error.message,
        variant: "destructive",
      });
    }
  };

  const refreshData = () => {
    fetchTrades();
    toast({
      title: "Refreshed",
      description: "Trade data has been updated",
      duration: 1000,
    });
  };

  const confirmDeleteTrade = async () => {

    const { error } = await supabase
      .from("trades")
      .delete()
      .eq("id", tradeToDelete.id);

    if (error) {
      toast({
        variant: "destructive",
        title: "Error deleting trade",
        description: error.message,
      });
    } else {
      toast({
        title: "Trade deleted successfully",
        description: `${tradeToDelete.instrument} trade has been removed.`,
      });
    }

    setDeleteDialogOpen(false);
    setTradeToDelete(null);
  };

  const filteredTrades = trades.filter(trade => {
    const matchesSearch = trade.instrument.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesFilter = filterResult === "all" || trade.result === filterResult;
    return matchesSearch && matchesFilter;
  });

  const formatPrice = (price: number | null) => {
    if (price === null) return "-";
    return price.toFixed(5);
  };

  const formatPnL = (pnl: number | null) => {
    if (pnl === null) return "-";
    const formatted = pnl.toFixed(2);
    return pnl >= 0 ? `+$${formatted}` : `-$${Math.abs(pnl).toFixed(2)}`;
  };

  const getPnLColor = (pnl: number | null) => {
    if (pnl === null) return "text-muted-foreground";
    if (pnl > 0) return "text-green-600";
    if (pnl < 0) return "text-red-600";
    return "text-muted-foreground";
  };

  const getResultBadge = (result: string | null) => {
    switch (result) {
      case "win":
        return <Badge className="bg-green-100 text-green-800 border-green-200">Win</Badge>;
      case "loss":
        return <Badge className="bg-red-100 text-red-800 border-red-200">Loss</Badge>;
      case "breakeven":
        return <Badge className="bg-gray-100 text-gray-800 border-gray-200">BE</Badge>;
      default:
        return <Badge variant="outline">Open</Badge>;
    }
  };

  if (loading) {
    return (
      <Card className="glass-card border-card-border">
        <CardContent className="p-8">
          <div className="text-center">Loading trades...</div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="glass-card border-card-border">
      <CardHeader>
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <CardTitle className="flex items-center gap-2 text-xl font-poppins">
            <TrendingUp className="w-5 h-5 text-primary" />
            Trading Journal
          </CardTitle>
          
          <div className="flex items-center gap-2">
            {/* Real-time Status */}
            <div className="flex items-center gap-1.5 px-2 py-1 rounded-lg border text-xs">
              {isRealTimeConnected ? (
                <>
                  <Wifi className="h-3 w-3 text-success animate-pulse" />
                  <span className="text-success font-medium">LIVE</span>
                </>
              ) : (
                <>
                  <WifiOff className="h-3 w-3 text-danger" />
                  <span className="text-danger font-medium">OFFLINE</span>
                </>
              )}
            </div>
            
            <div className="text-xs text-muted-foreground hidden sm:block">
              Updated: {lastUpdate.toLocaleTimeString()}
            </div>
            
            <Button variant="ghost" size="sm" onClick={refreshData}>
              <RefreshCw className="h-4 w-4" />
            </Button>
          </div>
        </div>
        
        {/* Filters */}
        <div className="flex flex-col sm:flex-row gap-2 sm:gap-4 mt-4">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <Input
              placeholder="Search instruments..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10 h-9"
            />
          </div>
          <Select value={filterResult} onValueChange={setFilterResult}>
            <SelectTrigger className="w-full sm:w-36 h-9">
              <Filter className="w-4 h-4 mr-2" />
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Results</SelectItem>
              <SelectItem value="win">Wins</SelectItem>
              <SelectItem value="loss">Losses</SelectItem>
              <SelectItem value="breakeven">Breakeven</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </CardHeader>
      <CardContent>
        {filteredTrades.length === 0 ? (
          <div className="text-center py-8 text-muted-foreground">
            <TrendingUp className="w-12 h-12 mx-auto mb-4 opacity-50" />
            <p className="text-lg font-medium">No trades found</p>
            <p>Start building your trading journal by adding your first trade.</p>
          </div>
        ) : (
          <>
            {/* Mobile Card View */}
            <div className="block sm:hidden space-y-3">
              {filteredTrades.map((trade) => (
                <Card 
                  key={trade.id} 
                  className="p-4 cursor-pointer hover:bg-muted/50 transition-colors"
                  onClick={() => handleViewTradeDetails(trade)}
                >
                  <div className="flex items-start justify-between mb-3">
                    <div className="flex items-center gap-2">
                      <h3 className="font-semibold">{trade.instrument}</h3>
                      {trade.side === 'long' ? (
                        <TrendingUp className="w-4 h-4 text-green-500" />
                      ) : (
                        <TrendingDown className="w-4 h-4 text-red-500" />
                      )}
                      <span className="text-sm text-muted-foreground capitalize">{trade.side}</span>
                    </div>
                    <div className="flex items-center gap-1" onClick={(e) => e.stopPropagation()}>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => handleViewTradeDetails(trade)}
                        className="h-8 w-8 p-0"
                        title="View Details"
                      >
                        <Eye className="h-3 w-3" />
                      </Button>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => handleEditTrade(trade)}
                        className="h-8 w-8 p-0"
                        title="Edit Trade"
                      >
                        <Edit className="h-3 w-3" />
                      </Button>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => handleShareTrade(trade)}
                        className="h-8 w-8 p-0 text-blue-500 hover:text-blue-700"
                        title="Share Trade"
                      >
                        <Share className="h-3 w-3" />
                      </Button>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => handleGenerateCertificate(trade)}
                        className="h-8 w-8 p-0 text-amber-500 hover:text-amber-700"
                        title="Generate Certificate"
                      >
                        <Trophy className="h-3 w-3" />
                      </Button>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => handleDeleteTrade(trade)}
                        className="h-8 w-8 p-0 text-red-500 hover:text-red-700"
                        title="Delete Trade"
                      >
                        <Trash2 className="h-3 w-3" />
                      </Button>
                    </div>
                  </div>
                  
                  <div className="grid grid-cols-2 gap-3 text-sm">
                    <div>
                      <span className="text-muted-foreground">Entry:</span>
                      <span className="ml-1 font-medium">{formatPrice(trade.entry_price)}</span>
                    </div>
                    <div>
                      <span className="text-muted-foreground">Exit:</span>
                      <span className="ml-1 font-medium">{formatPrice(trade.exit_price)}</span>
                    </div>
                    <div>
                      <span className="text-muted-foreground">Size:</span>
                      <span className="ml-1 font-medium">{trade.size}</span>
                    </div>
                    <div>
                      <span className="text-muted-foreground">P&L:</span>
                      <span className={`ml-1 font-medium ${getPnLColor(trade.pnl)}`}>
                        {formatPnL(trade.pnl)}
                      </span>
                    </div>
                  </div>
                  
                  <div className="flex items-center justify-between mt-3 pt-3 border-t">
                    <div className="text-xs text-muted-foreground">
                      {new Date(trade.opened_at).toLocaleDateString()}
                    </div>
                    {getResultBadge(trade.result)}
                  </div>
                </Card>
              ))}
            </div>

            {/* Desktop Table View */}
            <div className="hidden sm:block overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="min-w-24">Instrument</TableHead>
                    <TableHead className="min-w-20">Side</TableHead>
                    <TableHead className="min-w-20">Entry</TableHead>
                    <TableHead className="min-w-20">Exit</TableHead>
                    <TableHead className="min-w-16">Size</TableHead>
                    <TableHead className="min-w-20">P&L</TableHead>
                    <TableHead className="min-w-16">Result</TableHead>
                    <TableHead className="min-w-20">Date</TableHead>
                    <TableHead className="min-w-24">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredTrades.map((trade) => (
                    <TableRow 
                      key={trade.id} 
                      className="hover:bg-accent/5 cursor-pointer"
                      onClick={() => handleViewTradeDetails(trade)}
                    >
                      <TableCell className="font-medium">{trade.instrument}</TableCell>
                      <TableCell>
                        <div className="flex items-center gap-2">
                          {trade.side === 'long' ? (
                            <TrendingUp className="w-4 h-4 text-green-500" />
                          ) : (
                            <TrendingDown className="w-4 h-4 text-red-500" />
                          )}
                          <span className="capitalize">{trade.side}</span>
                        </div>
                      </TableCell>
                      <TableCell>{formatPrice(trade.entry_price)}</TableCell>
                      <TableCell>{formatPrice(trade.exit_price)}</TableCell>
                      <TableCell>{trade.size}</TableCell>
                      <TableCell className={getPnLColor(trade.pnl)}>
                        {formatPnL(trade.pnl)}
                      </TableCell>
                      <TableCell>{getResultBadge(trade.result)}</TableCell>
                      <TableCell>
                        {new Date(trade.opened_at).toLocaleDateString()}
                      </TableCell>
                      <TableCell onClick={(e) => e.stopPropagation()}>
                        <div className="flex items-center gap-1">
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => handleViewTradeDetails(trade)}
                            className="h-8 w-8 p-0"
                            title="View Details"
                          >
                            <Eye className="h-4 w-4" />
                          </Button>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => handleEditTrade(trade)}
                            className="h-8 w-8 p-0"
                            title="Edit Trade"
                          >
                            <Edit className="h-4 w-4" />
                          </Button>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => handleShareTrade(trade)}
                            className="h-8 w-8 p-0 text-blue-500 hover:text-blue-700"
                            title="Share Trade"
                          >
                            <Share className="h-4 w-4" />
                          </Button>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => handleGenerateCertificate(trade)}
                            className="h-8 w-8 p-0 text-amber-500 hover:text-amber-700"
                            title="Generate Certificate"
                          >
                            <Trophy className="h-4 w-4" />
                          </Button>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => handleDeleteTrade(trade)}
                            className="h-8 w-8 p-0 text-red-500 hover:text-red-700"
                            title="Delete Trade"
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          </>
        )}
      </CardContent>

      <EditTradeDialog
        trade={editingTrade}
        open={editDialogOpen}
        onOpenChange={setEditDialogOpen}
      />

      <TradeDetailView
        trade={selectedTrade}
        open={detailViewOpen}
        onOpenChange={setDetailViewOpen}
      />

      <AlertDialog open={deleteDialogOpen} onOpenChange={setDeleteDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete Trade</AlertDialogTitle>
            <AlertDialogDescription>
              Are you sure you want to delete this trade? This action cannot be undone.
              {tradeToDelete && (
                <div className="mt-2 p-2 bg-muted rounded">
                  <strong>{tradeToDelete.instrument}</strong> - {tradeToDelete.side.toUpperCase()} at {formatPrice(tradeToDelete.entry_price)}
                </div>
              )}
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={confirmDeleteTrade} className="bg-red-500 hover:bg-red-600">
              Delete Trade
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </Card>
  );
}