import React, { useState, useEffect, useMemo } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { 
  Calendar as CalendarIcon, 
  Clock, 
  Globe, 
  Wifi, 
  TrendingUp, 
  TrendingDown,
  Activity,
  Eye,
  Edit3,
  Save,
  ChevronLeft,
  ChevronRight,
  MapPin
} from "lucide-react";
import { format, isSameDay, startOfMonth, endOfMonth, eachDayOfInterval, isToday, isSameMonth } from "date-fns";
import { formatInTimeZone, toZonedTime, fromZonedTime } from 'date-fns-tz';
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { useAccountContext } from "@/hooks/useAccountContext";
import { useAccounts } from "@/hooks/useAccounts";
import { useToast } from "@/hooks/use-toast";

interface Trade {
  id: string;
  instrument: string;
  side: 'buy' | 'sell';
  entry_price: number;
  exit_price?: number;
  size: number;
  pnl?: number;
  opened_at: string;
  closed_at?: string;
  notes_pre?: string;
  notes_post?: string;
  account_id: string;
  strategy_id?: string;
}

interface DayStats {
  date: Date;
  trades: Trade[];
  pnl: number;
  winRate: number;
  volume: number;
  profitableTrades: number;
  totalTrades: number;
}

interface SessionStats {
  name: string;
  startTime: string;
  endTime: string;
  timezone: string;
  trades: Trade[];
  pnl: number;
  active: boolean;
  nextOpen?: Date;
}

const TRADING_SESSIONS = [
  {
    name: 'Sydney',
    startTime: '22:00',
    endTime: '07:00',
    timezone: 'Australia/Sydney',
    color: 'bg-blue-500'
  },
  {
    name: 'Tokyo', 
    startTime: '00:00',
    endTime: '09:00',
    timezone: 'Asia/Tokyo',
    color: 'bg-red-500'
  },
  {
    name: 'London',
    startTime: '08:00', 
    endTime: '17:00',
    timezone: 'Europe/London',
    color: 'bg-green-500'
  },
  {
    name: 'New York',
    startTime: '13:00',
    endTime: '22:00', 
    timezone: 'America/New_York',
    color: 'bg-purple-500'
  }
];

const TIMEZONES = [
  { value: 'America/New_York', label: 'New York (EST/EDT)' },
  { value: 'Europe/London', label: 'London (GMT/BST)' },
  { value: 'Asia/Tokyo', label: 'Tokyo (JST)' },
  { value: 'Australia/Sydney', label: 'Sydney (AEST/AEDT)' },
  { value: 'Asia/Dubai', label: 'Dubai (GST)' },
  { value: 'Europe/Frankfurt', label: 'Frankfurt (CET/CEST)' },
  { value: 'America/Los_Angeles', label: 'Los Angeles (PST/PDT)' },
  { value: 'UTC', label: 'UTC' }
];

export function ModernTradingCalendar() {
  const [currentDate, setCurrentDate] = useState(new Date());
  const [selectedDay, setSelectedDay] = useState<DayStats | null>(null);
  const [selectedTrade, setSelectedTrade] = useState<Trade | null>(null);
  const [trades, setTrades] = useState<Trade[]>([]);
  const [calendarData, setCalendarData] = useState<Map<string, DayStats>>(new Map());
  const [loading, setLoading] = useState(false);
  const [lastUpdate, setLastUpdate] = useState(new Date());
  const [userTimezone, setUserTimezone] = useState(
    Intl.DateTimeFormat().resolvedOptions().timeZone
  );
  const [editingNotes, setEditingNotes] = useState(false);
  const [preTradeNotes, setPreTradeNotes] = useState('');
  const [postTradeNotes, setPostTradeNotes] = useState('');
  
  const { user } = useAuth();
  const { selectedAccountId } = useAccountContext();
  const { accounts } = useAccounts();
  const { toast } = useToast();

  const selectedAccount = accounts.find(acc => acc.id === selectedAccountId);

  // Calculate current trading sessions
  const currentSessions = useMemo(() => {
    const now = new Date();
    return TRADING_SESSIONS.map(session => {
      const sessionTime = formatInTimeZone(now, session.timezone, 'HH:mm');
      const [startHour, startMin] = session.startTime.split(':').map(Number);
      const [endHour, endMin] = session.endTime.split(':').map(Number);
      
      let isActive = false;
      if (startHour < endHour) {
        const currentMinutes = now.getHours() * 60 + now.getMinutes();
        const startMinutes = startHour * 60 + startMin;
        const endMinutes = endHour * 60 + endMin;
        isActive = currentMinutes >= startMinutes && currentMinutes <= endMinutes;
      } else {
        // Session crosses midnight
        const currentMinutes = now.getHours() * 60 + now.getMinutes();
        const startMinutes = startHour * 60 + startMin;
        const endMinutes = endHour * 60 + endMin;
        isActive = currentMinutes >= startMinutes || currentMinutes <= endMinutes;
      }

      const sessionTrades = trades.filter(trade => {
        const tradeTime = new Date(trade.opened_at);
        const tradeSessionTime = formatInTimeZone(tradeTime, session.timezone, 'HH:mm');
        return tradeSessionTime >= session.startTime && tradeSessionTime <= session.endTime;
      });

      return {
        ...session,
        trades: sessionTrades,
        pnl: sessionTrades.reduce((sum, trade) => sum + (trade.pnl || 0), 0),
        active: isActive
      };
    });
  }, [trades]);

  // Generate calendar days
  const calendarDays = useMemo(() => {
    const start = startOfMonth(currentDate);
    const end = endOfMonth(currentDate);
    return eachDayOfInterval({ start, end });
  }, [currentDate]);

  // Load trades for current month with real-time subscription
  useEffect(() => {
    if (!user?.id || !selectedAccountId) return;

    const loadTrades = async () => {
      try {
        setLoading(true);
        const startDate = startOfMonth(currentDate);
        const endDate = endOfMonth(currentDate);

        const { data, error } = await supabase
          .from('trades')
          .select('*')
          .eq('user_id', user.id)
          .eq('account_id', selectedAccountId)
          .gte('opened_at', startDate.toISOString())
          .lte('opened_at', endDate.toISOString())
          .order('opened_at', { ascending: true });

        if (error) throw error;
        
        setTrades((data || []).map(trade => ({
          ...trade,
          side: trade.side as 'buy' | 'sell'
        })));
        setLastUpdate(new Date());
      } catch (error) {
        console.error('Error loading trades:', error);
        toast({
          variant: "destructive",
          title: "Error loading trades",
          description: "Failed to load calendar data"
        });
      } finally {
        setLoading(false);
      }
    };

    loadTrades();

    // Set up real-time subscription
    const channel = supabase
      .channel(`calendar-${user.id}-${selectedAccountId}`)
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'trades',
          filter: `user_id=eq.${user.id}`,
        },
        (payload) => {
          console.log('Real-time calendar update:', payload);
          loadTrades();
          
          toast({
            title: "📅 Calendar Updated",
            description: "Trading calendar refreshed with new data",
            duration: 2000,
          });
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [user?.id, selectedAccountId, currentDate]);

  // Process trades into calendar data
  useEffect(() => {
    const dataMap = new Map<string, DayStats>();

    calendarDays.forEach(day => {
      const dayKey = format(day, 'yyyy-MM-dd');
      const dayTrades = trades.filter(trade => 
        isSameDay(new Date(trade.opened_at), day)
      );

      const dayPnl = dayTrades.reduce((sum, trade) => sum + (trade.pnl || 0), 0);
      const profitableTrades = dayTrades.filter(trade => (trade.pnl || 0) > 0).length;
      const winRate = dayTrades.length > 0 ? (profitableTrades / dayTrades.length) * 100 : 0;
      const volume = dayTrades.reduce((sum, trade) => sum + Math.abs(trade.pnl || 0), 0);

      dataMap.set(dayKey, {
        date: day,
        trades: dayTrades,
        pnl: dayPnl,
        winRate,
        volume,
        profitableTrades,
        totalTrades: dayTrades.length
      });
    });

    setCalendarData(dataMap);
  }, [trades, calendarDays]);

  const handleDayClick = (day: Date) => {
    const dayKey = format(day, 'yyyy-MM-dd');
    const dayData = calendarData.get(dayKey);
    if (dayData && dayData.totalTrades > 0) {
      setSelectedDay(dayData);
    }
  };

  const handleTradeClick = (trade: Trade) => {
    setSelectedTrade(trade);
    setPreTradeNotes(trade.notes_pre || '');
    setPostTradeNotes(trade.notes_post || '');
    setEditingNotes(false);
  };

  const saveTradeNotes = async () => {
    if (!selectedTrade || !user) return;

    try {
      const { error } = await supabase
        .from('trades')
        .update({
          notes_pre: preTradeNotes || null,
          notes_post: postTradeNotes || null
        })
        .eq('id', selectedTrade.id)
        .eq('user_id', user.id);

      if (error) throw error;

      // Update local state
      setSelectedTrade({
        ...selectedTrade,
        notes_pre: preTradeNotes,
        notes_post: postTradeNotes
      });

      setTrades(prev => prev.map(trade => 
        trade.id === selectedTrade.id 
          ? { ...trade, notes_pre: preTradeNotes, notes_post: postTradeNotes }
          : trade
      ));

      setEditingNotes(false);
      
      toast({
        title: "📝 Notes Saved",
        description: "Trade notes updated successfully",
      });
    } catch (error: any) {
      console.error('Error saving trade notes:', error);
      toast({
        variant: "destructive",
        title: "Error saving notes",
        description: error.message,
      });
    }
  };

  const navigateMonth = (direction: 'prev' | 'next') => {
    setCurrentDate(prev => {
      const newDate = new Date(prev);
      if (direction === 'prev') {
        newDate.setMonth(prev.getMonth() - 1);
      } else {
        newDate.setMonth(prev.getMonth() + 1);
      }
      return newDate;
    });
  };

  const getDayClassName = (dayStats: DayStats | undefined) => {
    if (!dayStats || dayStats.totalTrades === 0) {
      return 'bg-background/30 border-border/40 hover:bg-background/50';
    }
    
    if (dayStats.pnl > 1000) return 'bg-gradient-to-br from-success/80 to-success/60 border-success text-white';
    if (dayStats.pnl > 0) return 'bg-gradient-to-br from-success/50 to-success/30 border-success/70';
    if (dayStats.pnl > -1000) return 'bg-gradient-to-br from-danger/50 to-danger/30 border-danger/70';
    return 'bg-gradient-to-br from-danger/80 to-danger/60 border-danger text-white';
  };

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0
    }).format(value);
  };

  const formatTimeInTimezone = (date: Date, timezone: string) => {
    return formatInTimeZone(date, timezone, 'HH:mm');
  };

  if (!selectedAccount) {
    return (
      <Card className="modern-card">
        <CardContent className="flex items-center justify-center h-64">
          <div className="text-center text-muted-foreground">
            <CalendarIcon className="h-12 w-12 mx-auto mb-4 opacity-50" />
            <p>Please select an account to view the trading calendar</p>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header with Real-time Indicators */}
      <Card className="modern-card border-primary/20">
        <CardHeader>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-primary/10">
                <CalendarIcon className="h-6 w-6 text-primary" />
              </div>
              <div>
                <CardTitle className="text-xl">Modern Trading Calendar</CardTitle>
                <p className="text-sm text-muted-foreground flex items-center gap-2">
                  <Wifi className="w-4 h-4 text-success animate-pulse" />
                  Real-time updates • {selectedAccount.name}
                </p>
              </div>
            </div>
            
            <div className="flex items-center gap-4">
              <Select value={userTimezone} onValueChange={setUserTimezone}>
                <SelectTrigger className="w-48">
                  <Globe className="w-4 h-4 mr-2" />
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {TIMEZONES.map(tz => (
                    <SelectItem key={tz.value} value={tz.value}>
                      {tz.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              
              <div className="text-xs text-muted-foreground flex items-center gap-1">
                <Clock className="w-4 h-4" />
                {formatInTimeZone(lastUpdate, userTimezone, 'HH:mm:ss')}
              </div>
            </div>
          </div>
        </CardHeader>
      </Card>

      {/* Trading Sessions Status */}
      <Card className="modern-card">
        <CardHeader>
          <CardTitle className="text-lg flex items-center gap-2">
            <Globe className="w-5 h-5" />
            Global Trading Sessions
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            {currentSessions.map(session => (
              <div 
                key={session.name}
                className={`p-4 rounded-xl border-2 transition-all hover:scale-105 cursor-pointer ${
                  session.active 
                    ? 'border-success bg-success/10 shadow-success/20 shadow-lg' 
                    : 'border-border bg-background/50'
                }`}
                onClick={() => session.trades.length > 0 && console.log('Show session trades')}
              >
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center gap-2">
                    <div className={`w-3 h-3 rounded-full ${session.color} ${session.active ? 'animate-pulse' : ''}`}></div>
                    <span className="font-semibold">{session.name}</span>
                  </div>
                  {session.active && (
                    <Badge variant="default" className="text-xs">LIVE</Badge>
                  )}
                </div>
                
                <div className="space-y-1 text-sm">
                  <div className="flex items-center justify-between">
                    <span className="text-muted-foreground">Local Time:</span>
                    <span className="font-mono">
                      {formatInTimeZone(new Date(), session.timezone, 'HH:mm')}
                    </span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-muted-foreground">Trades:</span>
                    <span>{session.trades.length}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-muted-foreground">P&L:</span>
                    <span className={session.pnl >= 0 ? 'text-success' : 'text-danger'}>
                      {formatCurrency(session.pnl)}
                    </span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Calendar */}
      <Card className="modern-card">
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="flex items-center gap-2">
              <CalendarIcon className="h-5 w-5" />
              {formatInTimeZone(currentDate, userTimezone, 'MMMM yyyy')}
            </CardTitle>
            <div className="flex items-center gap-2">
              <Button variant="outline" size="sm" onClick={() => navigateMonth('prev')}>
                <ChevronLeft className="h-4 w-4" />
              </Button>
              <Button variant="outline" size="sm" onClick={() => navigateMonth('next')}>
                <ChevronRight className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          {loading ? (
            <div className="flex items-center justify-center py-12">
              <Activity className="h-8 w-8 animate-spin text-primary" />
            </div>
          ) : (
            <>
              {/* Calendar Header */}
              <div className="grid grid-cols-7 gap-2 mb-4">
                {['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].map(day => (
                  <div key={day} className="text-center text-sm font-semibold text-muted-foreground p-3">
                    {day}
                  </div>
                ))}
              </div>

              {/* Calendar Grid */}
              <div className="grid grid-cols-7 gap-2">
                {calendarDays.map(day => {
                  const dayKey = format(day, 'yyyy-MM-dd');
                  const dayStats = calendarData.get(dayKey);
                  const hasTradesData = dayStats && dayStats.totalTrades > 0;

                  return (
                    <div
                      key={dayKey}
                      className={`
                        relative min-h-[100px] p-3 rounded-xl border-2 transition-all duration-200 cursor-pointer
                        ${!isSameMonth(day, currentDate) ? 'opacity-30' : ''}
                        ${isToday(day) ? 'ring-2 ring-primary ring-offset-2' : ''}
                        ${getDayClassName(dayStats)}
                        hover:scale-105 hover:shadow-lg
                      `}
                      onClick={() => hasTradesData && handleDayClick(day)}
                    >
                      <div className="text-lg font-bold mb-2">
                        {format(day, 'd')}
                      </div>
                      
                      {hasTradesData && dayStats && (
                        <div className="space-y-1">
                          <div className="text-sm font-semibold">
                            {formatCurrency(dayStats.pnl)}
                          </div>
                          <div className="text-xs opacity-90">
                            {dayStats.totalTrades} trades
                          </div>
                          <div className="text-xs opacity-80">
                            {dayStats.winRate.toFixed(0)}% win
                          </div>
                          
                          {/* Visual P&L indicator */}
                          <div className="absolute bottom-2 right-2">
                            {dayStats.pnl >= 0 ? (
                              <TrendingUp className="w-4 h-4 opacity-70" />
                            ) : (
                              <TrendingDown className="w-4 h-4 opacity-70" />
                            )}
                          </div>
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            </>
          )}
        </CardContent>
      </Card>

      {/* Monthly Summary */}
      <Card className="modern-card border-primary/30">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-primary">
            <TrendingUp className="h-5 w-5" />
            Monthly Performance Summary
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
            {[
              {
                label: 'Total Trades',
                value: Array.from(calendarData.values()).reduce((sum, day) => sum + day.totalTrades, 0),
                icon: Activity,
                color: 'text-primary'
              },
              {
                label: 'Monthly P&L',
                value: formatCurrency(Array.from(calendarData.values()).reduce((sum, day) => sum + day.pnl, 0)),
                icon: TrendingUp,
                color: Array.from(calendarData.values()).reduce((sum, day) => sum + day.pnl, 0) >= 0 ? 'text-success' : 'text-danger'
              },
              {
                label: 'Trading Days',
                value: Array.from(calendarData.values()).filter(day => day.totalTrades > 0).length,
                icon: CalendarIcon,
                color: 'text-muted-foreground'
              },
              {
                label: 'Win Rate',
                value: (() => {
                  const allTrades = Array.from(calendarData.values()).reduce((sum, day) => sum + day.totalTrades, 0);
                  const profitableTrades = Array.from(calendarData.values()).reduce((sum, day) => sum + day.profitableTrades, 0);
                  return allTrades > 0 ? `${((profitableTrades / allTrades) * 100).toFixed(1)}%` : '0%';
                })(),
                icon: TrendingUp,
                color: 'text-success'
              }
            ].map((stat, index) => (
              <div key={index} className="text-center p-4 rounded-lg bg-background/50 border border-border/50">
                <div className={`mx-auto mb-2 ${stat.color}`}>
                  <stat.icon className="h-6 w-6" />
                </div>
                <div className={`text-2xl font-bold ${stat.color}`}>
                  {stat.value}
                </div>
                <div className="text-sm text-muted-foreground mt-1">
                  {stat.label}
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Day Details Dialog */}
      <Dialog open={!!selectedDay} onOpenChange={() => setSelectedDay(null)}>
        <DialogContent className="max-w-5xl max-h-[85vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-3 text-xl">
              <CalendarIcon className="h-6 w-6" />
              {selectedDay && formatInTimeZone(selectedDay.date, userTimezone, 'EEEE, MMMM d, yyyy')}
              <Badge variant="outline" className="ml-2">
                {selectedDay?.totalTrades} trades
              </Badge>
              <Badge variant={selectedDay && selectedDay.pnl >= 0 ? 'default' : 'destructive'}>
                {selectedDay && selectedDay.pnl >= 0 ? '+' : ''}{selectedDay && formatCurrency(selectedDay.pnl)}
              </Badge>
            </DialogTitle>
          </DialogHeader>
          
          <div className="space-y-4">
            {selectedDay?.trades.map(trade => (
              <div
                key={trade.id}
                className="p-4 rounded-lg border-2 hover:border-primary/50 transition-all cursor-pointer hover:bg-background/80"
                onClick={() => handleTradeClick(trade)}
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-4">
                    <Badge variant={trade.side === 'buy' ? 'default' : 'secondary'} className="px-3 py-1">
                      {trade.side.toUpperCase()}
                    </Badge>
                    <div>
                      <span className="font-semibold text-lg">{trade.instrument}</span>
                      <div className="text-sm text-muted-foreground">
                        {trade.size} lots @ {trade.entry_price}
                      </div>
                    </div>
                    <div className="text-sm text-muted-foreground flex items-center gap-1">
                      <Clock className="w-4 h-4" />
                      {formatInTimeZone(new Date(trade.opened_at), userTimezone, 'HH:mm:ss')}
                    </div>
                  </div>
                  
                  <div className="flex items-center gap-3">
                    {(trade.notes_pre || trade.notes_post) && (
                      <Edit3 className="h-4 w-4 text-muted-foreground" />
                    )}
                    {trade.pnl !== undefined && (
                      <div className={`flex items-center gap-2 text-lg font-bold ${
                        trade.pnl >= 0 ? 'text-success' : 'text-danger'
                      }`}>
                        {trade.pnl >= 0 ? <TrendingUp className="h-5 w-5" /> : <TrendingDown className="h-5 w-5" />}
                        {trade.pnl >= 0 ? '+' : ''}{formatCurrency(trade.pnl)}
                      </div>
                    )}
                    <Eye className="h-4 w-4 text-muted-foreground" />
                  </div>
                </div>
              </div>
            ))}
          </div>
        </DialogContent>
      </Dialog>

      {/* Trade Detail Dialog */}
      <Dialog open={!!selectedTrade} onOpenChange={() => setSelectedTrade(null)}>
        <DialogContent className="max-w-3xl">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-3 text-xl">
              Trade Details - {selectedTrade?.instrument}
              <Badge variant={selectedTrade?.side === 'buy' ? 'default' : 'secondary'} className="px-3 py-1">
                {selectedTrade?.side.toUpperCase()}
              </Badge>
            </DialogTitle>
          </DialogHeader>
          
          {selectedTrade && (
            <div className="space-y-6">
              {/* Trade Info */}
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4 p-4 bg-background/50 rounded-lg">
                <div>
                  <div className="text-sm text-muted-foreground">Entry Price</div>
                  <div className="font-semibold">{selectedTrade.entry_price}</div>
                </div>
                <div>
                  <div className="text-sm text-muted-foreground">Size</div>
                  <div className="font-semibold">{selectedTrade.size} lots</div>
                </div>
                <div>
                  <div className="text-sm text-muted-foreground">Opened At</div>
                  <div className="font-semibold">
                    {formatInTimeZone(new Date(selectedTrade.opened_at), userTimezone, 'MMM d, HH:mm:ss')}
                  </div>
                </div>
                <div>
                  <div className="text-sm text-muted-foreground">P&L</div>
                  <div className={`font-bold text-lg ${
                    (selectedTrade.pnl || 0) >= 0 ? 'text-success' : 'text-danger'
                  }`}>
                    {(selectedTrade.pnl || 0) >= 0 ? '+' : ''}{formatCurrency(selectedTrade.pnl || 0)}
                  </div>
                </div>
              </div>

              {/* Notes Section */}
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <h3 className="text-lg font-semibold">Trade Notes</h3>
                  <Button
                    variant={editingNotes ? "default" : "outline"}
                    size="sm"
                    onClick={() => editingNotes ? saveTradeNotes() : setEditingNotes(true)}
                    disabled={editingNotes && (!preTradeNotes.trim() && !postTradeNotes.trim())}
                  >
                    {editingNotes ? <Save className="w-4 h-4 mr-2" /> : <Edit3 className="w-4 h-4 mr-2" />}
                    {editingNotes ? 'Save Notes' : 'Edit Notes'}
                  </Button>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label className="text-sm font-medium">Pre-trade Analysis</Label>
                    {editingNotes ? (
                      <Textarea
                        value={preTradeNotes}
                        onChange={(e) => setPreTradeNotes(e.target.value)}
                        placeholder="Your analysis before entering the trade..."
                        className="min-h-[120px]"
                      />
                    ) : (
                      <div className="p-3 bg-background/50 rounded-lg min-h-[120px] text-sm">
                        {selectedTrade.notes_pre || 'No pre-trade notes'}
                      </div>
                    )}
                  </div>
                  
                  <div className="space-y-2">
                    <Label className="text-sm font-medium">Post-trade Review</Label>
                    {editingNotes ? (
                      <Textarea
                        value={postTradeNotes}
                        onChange={(e) => setPostTradeNotes(e.target.value)}
                        placeholder="Your review after closing the trade..."
                        className="min-h-[120px]"
                      />
                    ) : (
                      <div className="p-3 bg-background/50 rounded-lg min-h-[120px] text-sm">
                        {selectedTrade.notes_post || 'No post-trade notes'}
                      </div>
                    )}
                  </div>
                </div>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}