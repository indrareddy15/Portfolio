import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  Target, 
  Plus, 
  Edit, 
  Trash2, 
  BarChart3,
  CheckCircle,
  AlertCircle,
  TrendingUp,
  BookOpen,
  Zap
} from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";

interface Strategy {
  id: string;
  name: string;
  description: string;
  rules_json: any;
  active: boolean;
  created_at: string;
  tradeCount?: number;
  winRate?: number;
  avgPnL?: number;
  totalPnL?: number;
}

export function StrategyManager() {
  const [strategies, setStrategies] = useState<Strategy[]>([]);
  const [loading, setLoading] = useState(true);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingStrategy, setEditingStrategy] = useState<Strategy | null>(null);
  const [isRealTimeActive, setIsRealTimeActive] = useState(false);
  const { user } = useAuth();
  const { toast } = useToast();

  const [formData, setFormData] = useState({
    name: "",
    description: "",
    rules: {
      entry: "",
      exit: "", 
      riskManagement: "",
      timeframes: "",
      instruments: ""
    }
  });

  const fetchStrategies = async () => {
    if (!user) return;

    try {
      // Fetch strategies
      const { data: strategiesData, error: strategiesError } = await supabase
        .from("strategies")
        .select("*")
        .eq("user_id", user.id)
        .order("created_at", { ascending: false });

      if (strategiesError) throw strategiesError;

      // Fetch trade statistics for each strategy
      const strategiesWithStats = await Promise.all(
        (strategiesData || []).map(async (strategy) => {
          const { data: trades, error: tradesError } = await supabase
            .from("trades")
            .select("pnl, result")
            .eq("user_id", user.id)
            .eq("strategy_id", strategy.id)
            .not("pnl", "is", null);

          if (tradesError) {
            console.error("Error fetching trades for strategy:", tradesError);
            return { ...strategy, tradeCount: 0, winRate: 0, avgPnL: 0, totalPnL: 0 };
          }

          const tradeCount = trades?.length || 0;
          const winningTrades = trades?.filter(t => (t.pnl || 0) > 0).length || 0;
          const winRate = tradeCount > 0 ? (winningTrades / tradeCount) * 100 : 0;
          const totalPnL = trades?.reduce((sum, t) => sum + (t.pnl || 0), 0) || 0;
          const avgPnL = tradeCount > 0 ? totalPnL / tradeCount : 0;

          return {
            ...strategy,
            tradeCount,
            winRate,
            avgPnL,
            totalPnL
          };
        })
      );

      setStrategies(strategiesWithStats);
    } catch (error: any) {
      toast({
        variant: "destructive",
        title: "Error loading strategies",
        description: error.message,
      });
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (!user) return;
    
    fetchStrategies();
    setupRealTimeSubscriptions();
    
    return () => {
      // Cleanup subscriptions on unmount
      supabase.removeAllChannels();
    };
  }, [user]);

  const setupRealTimeSubscriptions = () => {
    if (!user) return;

    // Subscribe to strategies changes
    const strategiesChannel = supabase
      .channel('strategies_realtime')
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'strategies',
          filter: `user_id=eq.${user.id}`
        },
        (payload) => {
          handleStrategyRealTimeUpdate(payload);
        }
      )
      .subscribe();

    // Subscribe to trades changes for metric updates
    const tradesChannel = supabase
      .channel('trades_realtime')
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public', 
          table: 'trades',
          filter: `user_id=eq.${user.id}`
        },
        (payload) => {
          handleTradeRealTimeUpdate(payload);
        }
      )
      .subscribe();

    setIsRealTimeActive(true);
    
    toast({
      title: "🚀 Real-time Active",
      description: "Strategy updates are now live!",
    });
  };

  const handleStrategyRealTimeUpdate = (payload: any) => {
    const { eventType, new: newRecord, old: oldRecord } = payload;
    
    setStrategies(currentStrategies => {
      switch (eventType) {
        case 'INSERT':
          if (newRecord && !currentStrategies.find(s => s.id === newRecord.id)) {
            calculateStrategyStats(newRecord).then(strategyWithStats => {
              setStrategies(prev => [strategyWithStats, ...prev]);
            });
          }
          return currentStrategies;
          
        case 'UPDATE':
          return currentStrategies.map(strategy => 
            strategy.id === newRecord.id 
              ? { ...strategy, ...newRecord }
              : strategy
          );
          
        case 'DELETE':
          return currentStrategies.filter(strategy => strategy.id !== oldRecord.id);
          
        default:
          return currentStrategies;
      }
    });
  };

  const handleTradeRealTimeUpdate = (payload: any) => {
    const { eventType, new: newRecord, old: oldRecord } = payload;
    
    // Recalculate metrics for affected strategies
    const affectedStrategyId = newRecord?.strategy_id || oldRecord?.strategy_id;
    
    if (affectedStrategyId) {
      setStrategies(currentStrategies => {
        const strategyIndex = currentStrategies.findIndex(s => s.id === affectedStrategyId);
        if (strategyIndex !== -1) {
          const strategy = currentStrategies[strategyIndex];
          calculateStrategyStats(strategy).then(updatedStrategy => {
            setStrategies(prev => 
              prev.map((s, i) => i === strategyIndex ? updatedStrategy : s)
            );
          });
        }
        return currentStrategies;
      });
      
      toast({
        title: "📊 Metrics Updated",
        description: "Strategy performance updated in real-time",
      });
    }
  };

  const calculateStrategyStats = async (strategy: any): Promise<Strategy> => {
    const { data: trades } = await supabase
      .from("trades")
      .select("pnl, result")
      .eq("user_id", user?.id)
      .eq("strategy_id", strategy.id)
      .not("pnl", "is", null);

    const tradeCount = trades?.length || 0;
    const winningTrades = trades?.filter(t => (t.pnl || 0) > 0).length || 0;
    const winRate = tradeCount > 0 ? (winningTrades / tradeCount) * 100 : 0;
    const totalPnL = trades?.reduce((sum, t) => sum + (t.pnl || 0), 0) || 0;
    const avgPnL = tradeCount > 0 ? totalPnL / tradeCount : 0;

    return {
      ...strategy,
      tradeCount,
      winRate,
      avgPnL,
      totalPnL
    };
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) return;

    try {
      const strategyData = {
        user_id: user.id,
        name: formData.name,
        description: formData.description,
        rules_json: formData.rules,
        active: true
      };

      if (editingStrategy) {
        const { error } = await supabase
          .from("strategies")
          .update(strategyData)
          .eq("id", editingStrategy.id);

        if (error) throw error;

        toast({
          title: "Strategy updated",
          description: "Your trading strategy has been updated successfully.",
        });
      } else {
        const { error } = await supabase
          .from("strategies")
          .insert([strategyData]);

        if (error) throw error;

        toast({
          title: "Strategy created",
          description: "Your new trading strategy has been created successfully.",
        });
      }

      setIsDialogOpen(false);
      setEditingStrategy(null);
      setFormData({
        name: "",
        description: "",
        rules: {
          entry: "",
          exit: "",
          riskManagement: "",
          timeframes: "",
          instruments: ""
        }
      });
      fetchStrategies();

    } catch (error: any) {
      toast({
        variant: "destructive",
        title: "Error saving strategy",
        description: error.message,
      });
    }
  };

  const handleEdit = (strategy: Strategy) => {
    setEditingStrategy(strategy);
    setFormData({
      name: strategy.name,
      description: strategy.description || "",
      rules: strategy.rules_json || {
        entry: "",
        exit: "",
        riskManagement: "",
        timeframes: "",
        instruments: ""
      }
    });
    setIsDialogOpen(true);
  };

  const handleDelete = async (strategy: Strategy) => {
    if (!confirm(`Are you sure you want to delete "${strategy.name}"?`)) return;

    try {
      const { error } = await supabase
        .from("strategies")
        .delete()
        .eq("id", strategy.id);

      if (error) throw error;

      toast({
        title: "Strategy deleted",
        description: "The strategy has been deleted successfully.",
      });
      fetchStrategies();
    } catch (error: any) {
      toast({
        variant: "destructive",
        title: "Error deleting strategy",
        description: error.message,
      });
    }
  };

  const toggleActive = async (strategy: Strategy) => {
    try {
      const { error } = await supabase
        .from("strategies")
        .update({ active: !strategy.active })
        .eq("id", strategy.id);

      if (error) throw error;

      toast({
        title: strategy.active ? "Strategy deactivated" : "Strategy activated",
        description: `${strategy.name} has been ${strategy.active ? 'deactivated' : 'activated'}.`,
      });
      fetchStrategies();
    } catch (error: any) {
      toast({
        variant: "destructive",
        title: "Error updating strategy",
        description: error.message,
      });
    }
  };

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 2,
    }).format(amount);
  };

  const getTemplateRules = (templateName: string) => {
    const templates = {
      "Scalping Strategy": {
        entry: "• Price breaks above/below key level with volume\n• RSI shows momentum (>70 for sell, <30 for buy)\n• Use 1-5 minute charts\n• Enter on pullback after initial break",
        exit: "• Take profit: 5-10 pips\n• Stop loss: 3-5 pips\n• Exit if trade doesn't move in 15 minutes\n• Close all positions before major news",
        riskManagement: "• Risk maximum 0.5% per trade\n• Maximum 3 concurrent positions\n• No more than 10 trades per session\n• Avoid news events",
        timeframes: "• Primary: M1, M5\n• Secondary: M15 for context\n• Avoid during low liquidity hours\n• Best during London/New York overlap",
        instruments: "• EUR/USD, GBP/USD, USD/JPY\n• Major currency pairs only\n• High liquidity instruments\n• Avoid exotics and commodities"
      },
      "Swing Trading": {
        entry: "• Wait for trend reversal at support/resistance\n• Look for bullish/bearish divergence\n• Enter on breakout with confirmation\n• Use daily and 4-hour charts",
        exit: "• Take profit at next major level\n• Trail stop once 1:1 R:R achieved\n• Hold for 3-10 days typically\n• Exit if fundamentals change",
        riskManagement: "• Risk 1-2% per trade\n• Maximum 5 open positions\n• Diversify across different pairs\n• Use position sizing based on volatility",
        timeframes: "• Primary: Daily, H4\n• Entry: H1\n• Avoid weekend gaps\n• Hold through minor fluctuations",
        instruments: "• Major and minor currency pairs\n• Some commodity currencies\n• Indices during trending markets\n• Avoid high-impact news pairs"
      },
      "Breakout Strategy": {
        entry: "• Price breaks key S/R with volume\n• Wait for retest of broken level\n• Enter on momentum confirmation\n• Use multiple timeframe analysis",
        exit: "• Target next major level\n• Use trailing stops\n• Exit if momentum fades\n• Take partial profits at key levels",
        riskManagement: "• Risk 1% per trade\n• Stop below/above broken level\n• Maximum 3 positions\n• Avoid low volatility periods",
        timeframes: "• Setup: H4, Daily\n• Entry: H1, M15\n• Monitor on multiple TFs\n• Best during high volatility sessions",
        instruments: "• Major currency pairs\n• Indices during earnings/news\n• Commodities with clear levels\n• Avoid range-bound instruments"
      }
    };
    return templates[templateName as keyof typeof templates] || {
      entry: "",
      exit: "",
      riskManagement: "",
      timeframes: "",
      instruments: ""
    };
  };

  if (loading) {
    return (
      <div className="space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {[1,2,3].map(i => (
            <Card key={i} className="glass-card border-card-border">
              <CardContent className="p-6">
                <div className="animate-pulse space-y-4">
                  <div className="h-4 bg-muted rounded"></div>
                  <div className="h-8 bg-muted rounded"></div>
                  <div className="h-4 bg-muted rounded"></div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 px-2 sm:px-0">
        <div className="flex-1">
          <div className="flex items-center gap-2 mb-1">
            <h2 className="text-xl sm:text-2xl font-bold">Strategy Management</h2>
            {isRealTimeActive && (
              <div className="flex items-center gap-1">
                <Zap className="w-4 h-4 text-green-500 animate-pulse" />
                <span className="text-xs text-green-600 font-medium">LIVE</span>
              </div>
            )}
          </div>
          <p className="text-muted-foreground text-sm sm:text-base">Create, manage and analyze your trading strategies</p>
        </div>
        
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger asChild>
            <Button 
              variant="primary"
              className="w-full sm:w-auto"
              onClick={() => {
                setEditingStrategy(null);
                setFormData({
                  name: "",
                  description: "",
                  rules: {
                    entry: "",
                    exit: "",
                    riskManagement: "",
                    timeframes: "",
                    instruments: ""
                  }
                });
              }}
            >
              <Plus className="w-4 h-4 mr-2" />
              Create Strategy
            </Button>
          </DialogTrigger>
          
          <DialogContent className="max-w-2xl max-h-[85vh] overflow-y-auto mx-2 sm:mx-auto">
            <DialogHeader>
              <DialogTitle className="text-lg sm:text-xl">
                {editingStrategy ? "Edit Strategy" : "Create New Strategy"}
              </DialogTitle>
            </DialogHeader>
            
            <form onSubmit={handleSubmit} className="space-y-4 sm:space-y-6">
              <div className="space-y-3 sm:space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="name" className="text-sm font-medium">Strategy Name</Label>
                  <Input
                    id="name"
                    value={formData.name}
                    onChange={(e) => setFormData(prev => ({ ...prev, name: e.target.value }))}
                    placeholder="e.g., Breakout Strategy, Scalping Setup"
                    className="text-sm"
                    required
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="description" className="text-sm font-medium">Description</Label>
                  <Textarea
                    id="description"
                    value={formData.description}
                    onChange={(e) => setFormData(prev => ({ ...prev, description: e.target.value }))}
                    placeholder="Brief description of your strategy..."
                    rows={3}
                    className="text-sm resize-none"
                  />
                </div>

                <Tabs defaultValue="entry" className="space-y-3 sm:space-y-4">
                  <TabsList className="grid w-full grid-cols-3 sm:grid-cols-5 h-auto">
                    <TabsTrigger value="entry" className="text-xs sm:text-sm px-1 sm:px-3">Entry</TabsTrigger>
                    <TabsTrigger value="exit" className="text-xs sm:text-sm px-1 sm:px-3">Exit</TabsTrigger>
                    <TabsTrigger value="risk" className="text-xs sm:text-sm px-1 sm:px-3">Risk</TabsTrigger>
                    <TabsTrigger value="timeframes" className="text-xs sm:text-sm px-1 sm:px-3 col-span-1 sm:col-span-1">Time</TabsTrigger>
                    <TabsTrigger value="instruments" className="text-xs sm:text-sm px-1 sm:px-3 col-span-2 sm:col-span-1">Assets</TabsTrigger>
                  </TabsList>

                   <TabsContent value="entry" className="space-y-2">
                     <Label className="text-sm font-medium">Entry Rules</Label>
                     <Textarea
                       value={formData.rules.entry}
                       onChange={(e) => setFormData(prev => ({
                         ...prev,
                         rules: { ...prev.rules, entry: e.target.value }
                       }))}
                       placeholder="Define your entry criteria..."
                       rows={3}
                       className="text-sm resize-none"
                     />
                   </TabsContent>

                   <TabsContent value="exit" className="space-y-2">
                     <Label className="text-sm font-medium">Exit Rules</Label>
                     <Textarea
                       value={formData.rules.exit}
                       onChange={(e) => setFormData(prev => ({
                         ...prev,
                         rules: { ...prev.rules, exit: e.target.value }
                       }))}
                       placeholder="Define your exit criteria..."
                       rows={3}
                       className="text-sm resize-none"
                     />
                   </TabsContent>

                   <TabsContent value="risk" className="space-y-2">
                     <Label className="text-sm font-medium">Risk Management</Label>
                     <Textarea
                       value={formData.rules.riskManagement}
                       onChange={(e) => setFormData(prev => ({
                         ...prev,
                         rules: { ...prev.rules, riskManagement: e.target.value }
                       }))}
                       placeholder="Define your risk management rules..."
                       rows={3}
                       className="text-sm resize-none"
                     />
                   </TabsContent>

                   <TabsContent value="timeframes" className="space-y-2">
                     <Label className="text-sm font-medium">Timeframes</Label>
                     <Textarea
                       value={formData.rules.timeframes}
                       onChange={(e) => setFormData(prev => ({
                         ...prev,
                         rules: { ...prev.rules, timeframes: e.target.value }
                       }))}
                       placeholder="Specify timeframes for this strategy..."
                       rows={3}
                       className="text-sm resize-none"
                     />
                   </TabsContent>

                   <TabsContent value="instruments" className="space-y-2">
                     <Label className="text-sm font-medium">Instruments/Assets</Label>
                     <Textarea
                       value={formData.rules.instruments}
                       onChange={(e) => setFormData(prev => ({
                         ...prev,
                         rules: { ...prev.rules, instruments: e.target.value }
                       }))}
                       placeholder="List the instruments/assets for this strategy..."
                       rows={3}
                       className="text-sm resize-none"
                     />
                   </TabsContent>
                </Tabs>
              </div>

               <div className="flex flex-col sm:flex-row justify-end gap-2 sm:gap-2 sm:space-x-0">
                 <Button 
                   type="button" 
                   variant="outline" 
                   onClick={() => setIsDialogOpen(false)}
                   className="order-2 sm:order-1"
                 >
                   Cancel
                 </Button>
                 <Button type="submit" variant="primary" className="order-1 sm:order-2">
                   {editingStrategy ? "Update Strategy" : "Create Strategy"}
                 </Button>
               </div>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      {/* Strategies Grid */}
      {strategies.length === 0 ? (
        <Card className="glass-card border-card-border">
          <CardContent className="p-12 text-center">
            <Target className="w-16 h-16 mx-auto mb-4 text-muted-foreground opacity-50" />
            <h3 className="text-lg font-semibold mb-2">No Strategies Yet</h3>
            <p className="text-muted-foreground mb-6">
              Create your first trading strategy to start organizing your trades and tracking performance.
            </p>
            <Button variant="primary" onClick={() => setIsDialogOpen(true)}>
              <Plus className="w-4 h-4 mr-2" />
              Create Your First Strategy
            </Button>
          </CardContent>
        </Card>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-6 px-2 sm:px-0">
          {strategies.map((strategy) => (
            <Card key={strategy.id} className="glass-card border-card-border hover:shadow-elegant transition-all duration-300">
              <CardHeader className="pb-3 p-4 sm:p-6">
                <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-2">
                  <div className="flex-1 min-w-0">
                    <CardTitle className="text-base sm:text-lg truncate">{strategy.name}</CardTitle>
                    <p className="text-xs sm:text-sm text-muted-foreground mt-1 line-clamp-2">
                      {strategy.description || "No description provided"}
                    </p>
                  </div>
                  <div className="flex items-center gap-2 flex-shrink-0">
                    <Badge variant={strategy.active ? "default" : "secondary"} className="text-xs">
                      {strategy.active ? "Active" : "Inactive"}
                    </Badge>
                  </div>
                </div>
              </CardHeader>
              
              <CardContent className="space-y-3 sm:space-y-4 p-4 sm:p-6">
                {/* Performance Metrics */}
                <div className="grid grid-cols-2 gap-3 sm:gap-4">
                  <div className="text-center">
                    <div className="text-base sm:text-lg font-semibold">{strategy.tradeCount || 0}</div>
                    <div className="text-xs text-muted-foreground">Trades</div>
                  </div>
                  <div className="text-center">
                    <div className={`text-base sm:text-lg font-semibold ${
                      (strategy.winRate || 0) >= 50 ? 'text-green-600' : 'text-red-600'
                    }`}>
                      {(strategy.winRate || 0).toFixed(1)}%
                    </div>
                    <div className="text-xs text-muted-foreground">Win Rate</div>
                  </div>
                </div>

                <div className="text-center pt-2 border-t border-card-border">
                  <div className={`text-lg sm:text-xl font-bold ${
                    (strategy.totalPnL || 0) >= 0 ? 'text-green-600' : 'text-red-600'
                  }`}>
                    {formatCurrency(strategy.totalPnL || 0)}
                  </div>
                  <div className="text-xs text-muted-foreground">Total P&L</div>
                  {strategy.tradeCount && strategy.tradeCount > 0 && (
                    <div className="text-xs text-muted-foreground mt-1">
                      Avg: {formatCurrency(strategy.avgPnL || 0)}
                    </div>
                  )}
                </div>

                {/* Actions */}
                <div className="flex flex-col sm:flex-row gap-2 pt-2">
                  <Button
                    variant="outline"
                    size="sm"
                    className="flex-1 text-xs sm:text-sm"
                    onClick={() => toggleActive(strategy)}
                  >
                    {strategy.active ? (
                      <AlertCircle className="w-3 h-3 sm:w-4 sm:h-4 mr-1" />
                    ) : (
                      <CheckCircle className="w-3 h-3 sm:w-4 sm:h-4 mr-1" />
                    )}
                    <span className="hidden sm:inline">{strategy.active ? 'Deactivate' : 'Activate'}</span>
                    <span className="sm:hidden">{strategy.active ? 'Disable' : 'Enable'}</span>
                  </Button>
                  <div className="flex gap-2">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => handleEdit(strategy)}
                      className="flex-1 sm:flex-none"
                    >
                      <Edit className="w-3 h-3 sm:w-4 sm:h-4 sm:mr-0" />
                      <span className="ml-1 sm:hidden">Edit</span>
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => handleDelete(strategy)}
                      className="text-red-600 hover:text-red-700 flex-1 sm:flex-none"
                    >
                      <Trash2 className="w-3 h-3 sm:w-4 sm:h-4 sm:mr-0" />
                      <span className="ml-1 sm:hidden">Delete</span>
                    </Button>
                  </div>
                </div>

                {/* Performance Indicator */}
                {strategy.tradeCount && strategy.tradeCount > 5 && (
                  <div className="flex items-center gap-2 pt-2 border-t border-card-border">
                    {strategy.winRate && strategy.winRate > 60 && strategy.totalPnL && strategy.totalPnL > 0 ? (
                      <>
                        <TrendingUp className="w-4 h-4 text-green-600" />
                        <span className="text-sm text-green-600 font-medium">Strong Performance</span>
                      </>
                    ) : strategy.winRate && strategy.winRate < 40 ? (
                      <>
                        <AlertCircle className="w-4 h-4 text-red-600" />
                        <span className="text-sm text-red-600 font-medium">Needs Review</span>
                      </>
                    ) : (
                      <>
                        <BarChart3 className="w-4 h-4 text-yellow-600" />
                        <span className="text-sm text-yellow-600 font-medium">Average Performance</span>
                      </>
                    )}
                  </div>
                )}
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      {/* Strategy Templates */}
      <Card className="glass-card border-card-border">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <BookOpen className="w-5 h-5 text-primary" />
            Strategy Templates
            {isRealTimeActive && (
              <Badge variant="secondary" className="text-xs">
                <Zap className="w-3 h-3 mr-1" />
                Live Ready
              </Badge>
            )}
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3 sm:gap-4 px-2 sm:px-0">
            {[
              {
                name: "Scalping Strategy",
                description: "Quick trades on small timeframes with tight risk management",
                popular: true
              },
              {
                name: "Swing Trading", 
                description: "Medium-term trades holding positions for days to weeks",
                popular: false
              },
              {
                name: "Breakout Strategy",
                description: "Trading breakouts from key support and resistance levels",
                popular: true
              }
            ].map((template, index) => (
              <Card key={index} className="p-3 sm:p-4 hover:shadow-sm transition-all cursor-pointer">
                <div className="flex items-start justify-between mb-2">
                  <h4 className="font-medium text-sm sm:text-base truncate pr-2">{template.name}</h4>
                  {template.popular && (
                    <Badge variant="secondary" className="text-xs flex-shrink-0">Popular</Badge>
                  )}
                </div>
                <p className="text-xs sm:text-sm text-muted-foreground mb-3 line-clamp-2">{template.description}</p>
                <Button 
                  variant="outline" 
                  size="sm" 
                  className="w-full text-xs sm:text-sm"
                  onClick={() => {
                    setFormData({
                      name: template.name,
                      description: template.description,
                      rules: {
                        entry: getTemplateRules(template.name).entry,
                        exit: getTemplateRules(template.name).exit,
                        riskManagement: getTemplateRules(template.name).riskManagement,
                        timeframes: getTemplateRules(template.name).timeframes,
                        instruments: getTemplateRules(template.name).instruments
                      }
                    });
                    setIsDialogOpen(true);
                  }}
                >
                  Use Template
                </Button>
              </Card>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}