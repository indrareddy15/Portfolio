import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { 
  Layout, 
  Settings, 
  Plus, 
  Save, 
  RotateCcw,
  TrendingUp,
  Target,
  Activity,
  Calendar,
  PieChart,
  BarChart3
} from "lucide-react";
import RGL, { WidthProvider } from "react-grid-layout";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/components/ui/use-toast";

import 'react-grid-layout/css/styles.css';
import 'react-resizable/css/styles.css';

const ReactGridLayout = WidthProvider(RGL);

interface Widget {
  id: string;
  type: string;
  title: string;
  component: React.ComponentType<any>;
  minW?: number;
  minH?: number;
}

interface Layout {
  i: string;
  x: number;
  y: number;
  w: number;
  h: number;
  minW?: number;
  minH?: number;
}

// Widget Components
const EquityCurveWidget = () => (
  <div className="h-full p-4 bg-gradient-to-br from-primary/5 to-transparent rounded-lg">
    <div className="flex items-center gap-2 mb-4">
      <TrendingUp className="w-4 h-4 text-primary" />
      <h3 className="font-semibold">Equity Curve</h3>
    </div>
    <div className="h-32 bg-muted/20 rounded flex items-center justify-center">
      <span className="text-sm text-muted-foreground">Chart placeholder</span>
    </div>
  </div>
);

const WinRateWidget = () => (
  <div className="h-full p-4 bg-gradient-to-br from-success/5 to-transparent rounded-lg">
    <div className="flex items-center gap-2 mb-4">
      <Target className="w-4 h-4 text-success" />
      <h3 className="font-semibold">Win Rate</h3>
    </div>
    <div className="text-center">
      <div className="text-3xl font-bold text-success">73.2%</div>
      <div className="text-sm text-muted-foreground">128W / 47L</div>
    </div>
  </div>
);

const SessionHeatmapWidget = () => (
  <div className="h-full p-4 bg-gradient-to-br from-warning/5 to-transparent rounded-lg">
    <div className="flex items-center gap-2 mb-4">
      <Calendar className="w-4 h-4 text-warning" />
      <h3 className="font-semibold">Session Heatmap</h3>
    </div>
    <div className="grid grid-cols-7 gap-1 h-20">
      {Array.from({ length: 28 }).map((_, i) => (
        <div 
          key={i} 
          className={`rounded w-full h-2 ${
            Math.random() > 0.5 ? 'bg-success/40' : 'bg-danger/40'
          }`} 
        />
      ))}
    </div>
  </div>
);

const InstrumentPerformanceWidget = () => (
  <div className="h-full p-4 bg-gradient-to-br from-info/5 to-transparent rounded-lg">
    <div className="flex items-center gap-2 mb-4">
      <PieChart className="w-4 h-4 text-info" />
      <h3 className="font-semibold">Top Instruments</h3>
    </div>
    <div className="space-y-2">
      {['EURUSD', 'GBPUSD', 'USDJPY'].map((pair, i) => (
        <div key={pair} className="flex justify-between text-sm">
          <span>{pair}</span>
          <span className={i === 0 ? 'text-success' : 'text-muted-foreground'}>
            {i === 0 ? '+$2,345' : i === 1 ? '+$1,234' : '-$567'}
          </span>
        </div>
      ))}
    </div>
  </div>
);

const StreaksWidget = () => (
  <div className="h-full p-4 bg-gradient-to-br from-accent/5 to-transparent rounded-lg">
    <div className="flex items-center gap-2 mb-4">
      <Activity className="w-4 h-4 text-accent" />
      <h3 className="font-semibold">Current Streaks</h3>
    </div>
    <div className="space-y-2">
      <div className="flex justify-between items-center">
        <span className="text-sm">Trading Days</span>
        <Badge variant="default">12 days</Badge>
      </div>
      <div className="flex justify-between items-center">
        <span className="text-sm">Green Days</span>
        <Badge variant="secondary">4 days</Badge>
      </div>
    </div>
  </div>
);

const PropMetricsWidget = () => (
  <div className="h-full p-4 bg-gradient-to-br from-secondary/5 to-transparent rounded-lg">
    <div className="flex items-center gap-2 mb-4">
      <BarChart3 className="w-4 h-4 text-secondary" />
      <h3 className="font-semibold">Prop Metrics</h3>
    </div>
    <div className="text-center">
      <div className="text-3xl font-bold text-secondary">87</div>
      <div className="text-sm text-muted-foreground">Ready for Challenge</div>
    </div>
  </div>
);

const AVAILABLE_WIDGETS: Widget[] = [
  { id: 'equity-curve', type: 'equity-curve', title: 'Equity Curve', component: EquityCurveWidget, minW: 4, minH: 3 },
  { id: 'win-rate', type: 'win-rate', title: 'Win Rate', component: WinRateWidget, minW: 2, minH: 2 },
  { id: 'session-heatmap', type: 'session-heatmap', title: 'Session Heatmap', component: SessionHeatmapWidget, minW: 4, minH: 2 },
  { id: 'instruments', type: 'instruments', title: 'Instrument Performance', component: InstrumentPerformanceWidget, minW: 3, minH: 3 },
  { id: 'streaks', type: 'streaks', title: 'Streaks Tracker', component: StreaksWidget, minW: 2, minH: 2 },
  { id: 'prop-metrics', type: 'prop-metrics', title: 'Prop Metrics', component: PropMetricsWidget, minW: 2, minH: 2 },
];

const DEFAULT_LAYOUTS = {
  scalper: [
    { i: 'equity-curve', x: 0, y: 0, w: 6, h: 3 },
    { i: 'win-rate', x: 6, y: 0, w: 2, h: 2 },
    { i: 'session-heatmap', x: 8, y: 0, w: 4, h: 2 },
    { i: 'streaks', x: 6, y: 2, w: 2, h: 2 },
    { i: 'instruments', x: 0, y: 3, w: 3, h: 3 },
    { i: 'prop-score', x: 8, y: 2, w: 2, h: 2 },
  ],
  swing: [
    { i: 'equity-curve', x: 0, y: 0, w: 8, h: 3 },
    { i: 'instruments', x: 8, y: 0, w: 4, h: 3 },
    { i: 'win-rate', x: 0, y: 3, w: 3, h: 2 },
    { i: 'prop-score', x: 3, y: 3, w: 3, h: 2 },
    { i: 'session-heatmap', x: 6, y: 3, w: 4, h: 2 },
    { i: 'streaks', x: 10, y: 3, w: 2, h: 2 },
  ],
  prop: [
    { i: 'prop-score', x: 0, y: 0, w: 3, h: 2 },
    { i: 'equity-curve', x: 3, y: 0, w: 6, h: 3 },
    { i: 'streaks', x: 9, y: 0, w: 3, h: 2 },
    { i: 'win-rate', x: 0, y: 2, w: 3, h: 2 },
    { i: 'session-heatmap', x: 3, y: 3, w: 6, h: 2 },
    { i: 'instruments', x: 9, y: 2, w: 3, h: 3 },
  ],
};

export function CustomizableDashboard() {
  const [currentLayout, setCurrentLayout] = useState<Layout[]>([]);
  const [activeWidgets, setActiveWidgets] = useState<string[]>([]);
  const [savedLayouts, setSavedLayouts] = useState<any[]>([]);
  const [layoutName, setLayoutName] = useState("");
  const [selectedPreset, setSelectedPreset] = useState<string>("");
  const [isEditing, setIsEditing] = useState(false);
  
  const { user } = useAuth();
  const { toast } = useToast();

  useEffect(() => {
    if (user) loadSavedLayouts();
  }, [user]);

  const loadSavedLayouts = async () => {
    if (!user) return;

    try {
      const { data, error } = await supabase
        .from("dashboard_layouts")
        .select("*")
        .eq("user_id", user.id)
        .order("created_at", { ascending: false });

      if (error) throw error;

      setSavedLayouts(data || []);
      
      // Load default layout if exists
      const defaultLayout = data?.find(l => l.is_default);
      if (defaultLayout && defaultLayout.layout_data) {
        const layoutData = defaultLayout.layout_data as any;
        if (layoutData.layout && layoutData.widgets) {
          setCurrentLayout(layoutData.layout);
          setActiveWidgets(layoutData.widgets);
        }
      } else {
        // Set default scalper layout
        loadPresetLayout('scalper');
      }
    } catch (error: any) {
      toast({
        variant: "destructive",
        title: "Error loading layouts",
        description: error.message,
      });
    }
  };

  const loadPresetLayout = (preset: string) => {
    const layout = DEFAULT_LAYOUTS[preset as keyof typeof DEFAULT_LAYOUTS];
    if (layout) {
      setCurrentLayout(layout);
      setActiveWidgets(layout.map(l => l.i));
      setSelectedPreset(preset);
    }
  };

  const saveLayout = async () => {
    if (!user || !layoutName.trim()) {
      toast({
        variant: "destructive",
        title: "Error", 
        description: "Please enter a layout name.",
      });
      return;
    }

    try {
      const layoutData = {
        layout: currentLayout,
        widgets: activeWidgets,
      };

      const { error } = await supabase
        .from("dashboard_layouts")
        .insert({
          user_id: user.id,
          layout_name: layoutName,
          layout_data: layoutData as any,
          is_default: false,
        });

      if (error) throw error;

      toast({
        title: "Layout saved",
        description: `Layout "${layoutName}" has been saved.`,
      });

      setLayoutName("");
      loadSavedLayouts();
    } catch (error: any) {
      toast({
        variant: "destructive",
        title: "Error saving layout",
        description: error.message,
      });
    }
  };

  const addWidget = (widgetId: string) => {
    if (activeWidgets.includes(widgetId)) return;

    const widget = AVAILABLE_WIDGETS.find(w => w.id === widgetId);
    if (!widget) return;

    // Find a good position for the new widget
    const newItem: Layout = {
      i: widgetId,
      x: 0,
      y: Math.max(...currentLayout.map(item => item.y + item.h), 0),
      w: widget.minW || 2,
      h: widget.minH || 2,
      minW: widget.minW,
      minH: widget.minH,
    };

    setCurrentLayout([...currentLayout, newItem]);
    setActiveWidgets([...activeWidgets, widgetId]);
  };

  const removeWidget = (widgetId: string) => {
    setCurrentLayout(currentLayout.filter(item => item.i !== widgetId));
    setActiveWidgets(activeWidgets.filter(id => id !== widgetId));
  };

  const onLayoutChange = (layout: Layout[]) => {
    setCurrentLayout(layout);
  };

  return (
    <div className="space-y-6">
      {/* Controls */}
      <Card className="glass-card border-card-border">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Layout className="w-5 h-5 text-primary" />
            Customizable Dashboard
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex items-center gap-4 mb-4">
            <Button
              variant={isEditing ? "default" : "outline"}
              size="sm"
              onClick={() => setIsEditing(!isEditing)}
            >
              <Settings className="w-4 h-4 mr-2" />
              {isEditing ? "Exit Edit Mode" : "Edit Layout"}
            </Button>

            <Select value={selectedPreset} onValueChange={loadPresetLayout}>
              <SelectTrigger className="w-48">
                <SelectValue placeholder="Load preset" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="scalper">Scalper Layout</SelectItem>
                <SelectItem value="swing">Swing Trader Layout</SelectItem>
                <SelectItem value="prop">Prop Firm Layout</SelectItem>
              </SelectContent>
            </Select>

            <Button
              variant="outline"
              size="sm"
              onClick={() => loadPresetLayout('scalper')}
            >
              <RotateCcw className="w-4 h-4 mr-2" />
              Reset
            </Button>
          </div>

          {isEditing && (
            <div className="flex items-center gap-4">
              <div className="flex items-center gap-2">
                <Input
                  placeholder="Layout name..."
                  value={layoutName}
                  onChange={(e) => setLayoutName(e.target.value)}
                  className="w-48"
                />
                <Button size="sm" onClick={saveLayout}>
                  <Save className="w-4 h-4 mr-2" />
                  Save
                </Button>
              </div>

              <Select onValueChange={addWidget}>
                <SelectTrigger className="w-48">
                  <SelectValue placeholder="Add widget" />
                </SelectTrigger>
                <SelectContent>
                  {AVAILABLE_WIDGETS.filter(w => !activeWidgets.includes(w.id)).map(widget => (
                    <SelectItem key={widget.id} value={widget.id}>
                      <Plus className="w-4 h-4 mr-2 inline" />
                      {widget.title}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Dashboard Grid */}
      <div className="relative">
        <ReactGridLayout
          className="layout"
          layout={currentLayout}
          onLayoutChange={onLayoutChange}
          isDraggable={isEditing}
          isResizable={isEditing}
          cols={12}
          rowHeight={60}
          compactType="vertical"
          preventCollision={false}
        >
          {activeWidgets.map(widgetId => {
            const widget = AVAILABLE_WIDGETS.find(w => w.id === widgetId);
            if (!widget) return null;

            const WidgetComponent = widget.component;
            
            return (
              <div key={widgetId} className="relative">
                <Card className="glass-card border-card-border h-full">
                  <CardContent className="p-0 h-full">
                    <WidgetComponent />
                  </CardContent>
                </Card>
                
                {isEditing && (
                  <Button
                    size="sm"
                    variant="destructive"
                    className="absolute -top-2 -right-2 h-6 w-6 p-0 z-10"
                    onClick={() => removeWidget(widgetId)}
                  >
                    ×
                  </Button>
                )}
              </div>
            );
          })}
        </ReactGridLayout>
      </div>

      {/* Saved Layouts */}
      {savedLayouts.length > 0 && (
        <Card className="glass-card border-card-border">
          <CardHeader>
            <CardTitle>Saved Layouts</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex flex-wrap gap-2">
              {savedLayouts.map(layout => (
                <Badge 
                  key={layout.id}
                  variant="outline"
                  className="cursor-pointer hover:bg-primary/10"
                  onClick={() => {
                    const layoutData = layout.layout_data as any;
                    if (layoutData && layoutData.layout && layoutData.widgets) {
                      setCurrentLayout(layoutData.layout);
                      setActiveWidgets(layoutData.widgets);
                    }
                  }}
                >
                  {layout.layout_name}
                </Badge>
              ))}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}