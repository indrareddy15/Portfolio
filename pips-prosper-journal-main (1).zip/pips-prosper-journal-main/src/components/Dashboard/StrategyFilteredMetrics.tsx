import { useState, useEffect, useCallback } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { 
  TrendingUp, 
  TrendingDown, 
  Target,
  DollarSign,
  Activity,
  Filter,
  BarChart3,
  RefreshCw,
  Wifi,
  WifiOff
} from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/components/ui/use-toast";

interface MetricsData {
  totalPnL: number;
  winRate: number;
  avgRR: number;
  maxDrawdown: number;
  tradeCount: number;
  profitFactor: number;
  grossProfit: number;
  grossLoss: number;
  expectancy: number;
}

interface StrategyFilteredMetricsProps {
  selectedStrategy?: string | null;
  onStrategyChange?: (strategyId: string | null) => void;
}

export function StrategyFilteredMetrics({ 
  selectedStrategy, 
  onStrategyChange 
}: StrategyFilteredMetricsProps) {
  const [strategies, setStrategies] = useState<any[]>([]);
  const [metrics, setMetrics] = useState<MetricsData>({
    totalPnL: 0,
    winRate: 0,
    avgRR: 0,
    maxDrawdown: 0,
    tradeCount: 0,
    profitFactor: 0,
    grossProfit: 0,
    grossLoss: 0,
    expectancy: 0
  });
  const [loading, setLoading] = useState(true);
  const [isRealTimeConnected, setIsRealTimeConnected] = useState(false);
  const [lastUpdate, setLastUpdate] = useState(new Date());
  const { user } = useAuth();
  const { toast } = useToast();

  // Load strategies
  const loadStrategies = useCallback(async () => {
    if (!user) return;

    try {
      const { data, error } = await supabase
        .from('strategies')
        .select('*')
        .eq('user_id', user.id)
        .eq('active', true)
        .order('name');

      if (error) throw error;
      setStrategies(data || []);
    } catch (error: any) {
      console.error('Error loading strategies:', error);
      toast({
        variant: "destructive",
        title: "Error loading strategies",
        description: error.message,
      });
    }
  }, [user, toast]);

  useEffect(() => {
    loadStrategies();
  }, [loadStrategies]);

  // Calculate metrics for selected strategy or all trades
  const calculateMetrics = useCallback(async () => {
    if (!user) return;

    setLoading(true);
    try {
      let query = supabase
        .from('trades')
        .select('*')
        .eq('user_id', user.id)
        .not('pnl', 'is', null);

      // Filter by strategy if selected
      if (selectedStrategy) {
        query = query.eq('strategy_id', selectedStrategy);
      }

      const { data: trades, error } = await query;

      if (error) {
        throw error;
      }

      if (!trades || trades.length === 0) {
        setMetrics({
          totalPnL: 0,
          winRate: 0,
          avgRR: 0,
          maxDrawdown: 0,
          tradeCount: 0,
          profitFactor: 0,
          grossProfit: 0,
          grossLoss: 0,
          expectancy: 0
        });
        setLastUpdate(new Date());
        return;
      }

      // Calculate basic metrics
      const tradeCount = trades.length;
      const winningTrades = trades.filter(t => (t.pnl || 0) > 0);
      const losingTrades = trades.filter(t => (t.pnl || 0) < 0);
      
      const winRate = (winningTrades.length / tradeCount) * 100;
      const totalPnL = trades.reduce((sum, t) => sum + (t.pnl || 0), 0);
      const grossProfit = winningTrades.reduce((sum, t) => sum + (t.pnl || 0), 0);
      const grossLoss = Math.abs(losingTrades.reduce((sum, t) => sum + (t.pnl || 0), 0));
      
      const profitFactor = grossLoss > 0 ? grossProfit / grossLoss : grossProfit > 0 ? 999 : 0;
      const expectancy = totalPnL / tradeCount;

      // Calculate average risk-reward ratio
      const rrTrades = trades.filter(t => 
        t.entry_price && t.take_profit && t.stop_loss && 
        t.entry_price !== t.take_profit && t.entry_price !== t.stop_loss
      );
      
      const avgRR = rrTrades.length > 0 
        ? rrTrades.reduce((sum, t) => {
            const reward = Math.abs((t.take_profit || 0) - (t.entry_price || 0));
            const risk = Math.abs((t.entry_price || 0) - (t.stop_loss || 0));
            return sum + (risk > 0 ? reward / risk : 0);
          }, 0) / rrTrades.length
        : 0;

      // Calculate max drawdown (simplified)
      let runningBalance = 0;
      let peak = 0;
      let maxDrawdown = 0;

      const sortedTrades = [...trades].sort((a, b) => 
        new Date(a.closed_at || a.opened_at).getTime() - new Date(b.closed_at || b.opened_at).getTime()
      );

      sortedTrades.forEach(trade => {
        runningBalance += (trade.pnl || 0);
        if (runningBalance > peak) {
          peak = runningBalance;
        }
        const drawdown = peak - runningBalance;
        if (drawdown > maxDrawdown) {
          maxDrawdown = drawdown;
        }
      });

      setMetrics({
        totalPnL,
        winRate,
        avgRR,
        maxDrawdown,
        tradeCount,
        profitFactor,
        grossProfit,
        grossLoss,
        expectancy
      });

      setLastUpdate(new Date());

    } catch (error: any) {
      toast({
        variant: "destructive",
        title: "Error calculating metrics",
        description: error.message,
      });
    } finally {
      setLoading(false);
    }
  }, [user, selectedStrategy, toast]);

  useEffect(() => {
    calculateMetrics();
  }, [calculateMetrics]);

  // Real-time updates
  useEffect(() => {
    if (!user) return;

    const channel = supabase
      .channel(`strategy-metrics-realtime-${user.id}`)
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'trades',
          filter: `user_id=eq.${user.id}`
        },
        (payload) => {
          console.log('Real-time trade update for metrics:', payload);
          // Re-calculate metrics when trades change
          calculateMetrics();
          
          if (payload.eventType === 'INSERT') {
            toast({
              title: "New Trade Added",
              description: "Metrics updated with latest trade data",
              duration: 2000,
            });
          }
        }
      )
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'strategies',
          filter: `user_id=eq.${user.id}`
        },
        (payload) => {
          console.log('Real-time strategy update:', payload);
          loadStrategies();
        }
      )
      .subscribe((status) => {
        if (status === 'SUBSCRIBED') {
          setIsRealTimeConnected(true);
          console.log('Strategy metrics real-time connection established');
        } else if (status === 'CHANNEL_ERROR') {
          setIsRealTimeConnected(false);
          console.error('Strategy metrics real-time connection failed');
        }
      });

    return () => {
      supabase.removeChannel(channel);
      setIsRealTimeConnected(false);
    };
  }, [user, calculateMetrics, loadStrategies, toast]);

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 2,
    }).format(amount);
  };

  const formatPercentage = (value: number) => {
    return `${value.toFixed(1)}%`;
  };

  const getSelectedStrategyName = () => {
    if (!selectedStrategy) return "All Strategies";
    const strategy = strategies.find(s => s.id === selectedStrategy);
    return strategy?.name || "Unknown Strategy";
  };

  const handleStrategyChange = (value: string) => {
    const newStrategy = value === "all" ? null : value;
    onStrategyChange?.(newStrategy);
  };

  const refreshMetrics = () => {
    calculateMetrics();
    toast({
      title: "Metrics Refreshed",
      description: "Strategy metrics have been updated",
      duration: 2000,
    });
  };

  return (
    <div className="space-y-6">
      {/* Strategy Filter */}
      <Card className="glass-card border-card-border">
        <CardHeader className="pb-3 sm:pb-4">
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 sm:gap-0">
            <CardTitle className="flex items-center gap-2 text-base sm:text-lg">
              <Filter className="w-4 h-4 sm:w-5 sm:h-5 text-primary" />
              <span className="hidden sm:inline">Strategy Performance Filter</span>
              <span className="sm:hidden">Strategy Filter</span>
            </CardTitle>
            <div className="flex items-center gap-2">
              {/* Real-time Status */}
              <div className="flex items-center gap-1.5 px-2 py-1 rounded-lg border text-xs">
                {isRealTimeConnected ? (
                  <>
                    <Wifi className="h-3 w-3 text-success animate-pulse" />
                    <span className="text-success font-medium hidden sm:inline">LIVE</span>
                  </>
                ) : (
                  <>
                    <WifiOff className="h-3 w-3 text-danger" />
                    <span className="text-danger font-medium hidden sm:inline">OFFLINE</span>
                  </>
                )}
              </div>
              <Badge variant="outline" className="text-xs sm:text-sm">
                {getSelectedStrategyName()}
              </Badge>
              <Button
                variant="ghost"
                size="sm"
                onClick={refreshMetrics}
                className="p-2 hover:bg-primary hover:text-primary-foreground"
              >
                <RefreshCw className="h-3 w-3 sm:h-4 sm:w-4" />
              </Button>
            </div>
          </div>
          <div className="text-xs text-muted-foreground mt-2 hidden sm:block">
            Last updated: {lastUpdate.toLocaleTimeString()}
          </div>
        </CardHeader>
        <CardContent className="pt-0">
          <div className="w-full">
            <Select 
              value={selectedStrategy || "all"} 
              onValueChange={handleStrategyChange}
            >
              <SelectTrigger className="w-full bg-background border-border hover:bg-accent transition-colors">
                <SelectValue placeholder="Select strategy to analyze" />
              </SelectTrigger>
              <SelectContent className="bg-background border-border shadow-lg z-50">
                <SelectItem 
                  value="all" 
                  className="hover:bg-accent focus:bg-accent cursor-pointer"
                >
                  <div className="flex items-center gap-2">
                    <BarChart3 className="w-3 h-3 sm:w-4 sm:w-4 text-primary" />
                    <span className="text-sm">All Strategies Combined</span>
                  </div>
                </SelectItem>
                {strategies.map((strategy) => (
                  <SelectItem 
                    key={strategy.id} 
                    value={strategy.id}
                    className="hover:bg-accent focus:bg-accent cursor-pointer"
                  >
                    <div className="flex items-center justify-between w-full gap-2">
                      <span className="text-sm truncate flex-1">{strategy.name}</span>
                      <Badge variant="outline" className="text-xs flex-shrink-0">
                        Active
                      </Badge>
                    </div>
                  </SelectItem>
                ))}
                {strategies.length === 0 && (
                  <div className="p-2 text-sm text-muted-foreground text-center">
                    No strategies found
                  </div>
                )}
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {/* Metrics Cards */}
      {loading ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3 sm:gap-4 md:gap-6 animate-fade-in">
          {[1, 2, 3, 4, 5, 6, 7, 8].map(i => (
            <Card key={i} className="glass-card border-card-border">
              <CardContent className="p-4 sm:p-6">
                <div className="animate-pulse space-y-3 sm:space-y-4">
                  <div className="h-3 sm:h-4 bg-muted rounded"></div>
                  <div className="h-6 sm:h-8 bg-muted rounded"></div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3 sm:gap-4 md:gap-6 animate-fade-in">
          {/* Total P&L */}
          <Card className="glass-card border-card-border hover:shadow-elegant transition-all duration-300 hover-scale">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-xs sm:text-sm font-medium">Total P&L</CardTitle>
              <DollarSign className="h-3 w-3 sm:h-4 sm:w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent className="pb-4">
              <div className={`text-lg sm:text-xl lg:text-2xl font-bold ${
                metrics.totalPnL >= 0 ? 'text-success' : 'text-danger'
              }`}>
                {formatCurrency(metrics.totalPnL)}
              </div>
              <div className="flex items-center gap-1 text-xs text-muted-foreground mt-1">
                {metrics.totalPnL >= 0 ? (
                  <TrendingUp className="h-3 w-3 text-success" />
                ) : (
                  <TrendingDown className="h-3 w-3 text-danger" />
                )}
                <span className="hidden sm:inline">Strategy Performance</span>
                <span className="sm:hidden">Performance</span>
              </div>
            </CardContent>
          </Card>

          {/* Win Rate */}
          <Card className="glass-card border-card-border hover:shadow-elegant transition-all duration-300 hover-scale">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-xs sm:text-sm font-medium">Win Rate</CardTitle>
              <Target className="h-3 w-3 sm:h-4 sm:w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent className="pb-4">
              <div className={`text-lg sm:text-xl lg:text-2xl font-bold ${
                metrics.winRate >= 50 ? 'text-success' : 'text-warning'
              }`}>
                {formatPercentage(metrics.winRate)}
              </div>
              <div className="text-xs text-muted-foreground mt-1">
                <span className="hidden sm:inline">{metrics.tradeCount} trades analyzed</span>
                <span className="sm:hidden">{metrics.tradeCount} trades</span>
              </div>
            </CardContent>
          </Card>

          {/* Average Risk-Reward */}
          <Card className="glass-card border-card-border hover:shadow-elegant transition-all duration-300 hover-scale">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-xs sm:text-sm font-medium">
                <span className="hidden sm:inline">Avg Risk/Reward</span>
                <span className="sm:hidden">Avg R/R</span>
              </CardTitle>
              <BarChart3 className="h-3 w-3 sm:h-4 sm:w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent className="pb-4">
              <div className={`text-lg sm:text-xl lg:text-2xl font-bold ${
                metrics.avgRR >= 1 ? 'text-success' : 'text-warning'
              }`}>
                {metrics.avgRR.toFixed(2)}
              </div>
              <div className="text-xs text-muted-foreground mt-1">
                <span className="hidden sm:inline">Risk vs Reward ratio</span>
                <span className="sm:hidden">R/R ratio</span>
              </div>
            </CardContent>
          </Card>

          {/* Trade Count */}
          <Card className="glass-card border-card-border hover:shadow-elegant transition-all duration-300 hover-scale">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-xs sm:text-sm font-medium">Total Trades</CardTitle>
              <Activity className="h-3 w-3 sm:h-4 sm:w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent className="pb-4">
              <div className="text-lg sm:text-xl lg:text-2xl font-bold text-foreground">
                {metrics.tradeCount}
              </div>
              <div className="text-xs text-muted-foreground mt-1">
                <span className="hidden sm:inline">Closed positions</span>
                <span className="sm:hidden">Positions</span>
              </div>
            </CardContent>
          </Card>

          {/* Profit Factor */}
          <Card className="glass-card border-card-border hover:shadow-elegant transition-all duration-300 hover-scale">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-xs sm:text-sm font-medium">Profit Factor</CardTitle>
              <TrendingUp className="h-3 w-3 sm:h-4 sm:w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent className="pb-4">
              <div className={`text-lg sm:text-xl lg:text-2xl font-bold ${
                metrics.profitFactor >= 1 ? 'text-success' : 'text-danger'
              }`}>
                {metrics.profitFactor === 999 ? '∞' : metrics.profitFactor.toFixed(2)}
              </div>
              <div className="text-xs text-muted-foreground mt-1">
                <span className="hidden sm:inline">Profit / Loss ratio</span>
                <span className="sm:hidden">P/L ratio</span>
              </div>
            </CardContent>
          </Card>

          {/* Max Drawdown */}
          <Card className="glass-card border-card-border hover:shadow-elegant transition-all duration-300 hover-scale">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-xs sm:text-sm font-medium">Max Drawdown</CardTitle>
              <TrendingDown className="h-3 w-3 sm:h-4 sm:w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent className="pb-4">
              <div className={`text-lg sm:text-xl lg:text-2xl font-bold ${
                metrics.maxDrawdown <= 1000 ? 'text-success' : 'text-warning'
              }`}>
                {formatCurrency(metrics.maxDrawdown)}
              </div>
              <div className="text-xs text-muted-foreground mt-1">
                <span className="hidden sm:inline">Largest losing streak</span>
                <span className="sm:hidden">Max loss</span>
              </div>
            </CardContent>
          </Card>

          {/* Gross Profit */}
          <Card className="glass-card border-card-border hover:shadow-elegant transition-all duration-300 hover-scale">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-xs sm:text-sm font-medium">Gross Profit</CardTitle>
              <DollarSign className="h-3 w-3 sm:h-4 sm:w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent className="pb-4">
              <div className="text-lg sm:text-xl lg:text-2xl font-bold text-success">
                {formatCurrency(metrics.grossProfit)}
              </div>
              <div className="text-xs text-muted-foreground mt-1">
                <span className="hidden sm:inline">Total winning trades</span>
                <span className="sm:hidden">Winning trades</span>
              </div>
            </CardContent>
          </Card>

          {/* Expectancy */}
          <Card className="glass-card border-card-border hover:shadow-elegant transition-all duration-300 hover-scale">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-xs sm:text-sm font-medium">Expectancy</CardTitle>
              <Target className="h-3 w-3 sm:h-4 sm:w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent className="pb-4">
              <div className={`text-lg sm:text-xl lg:text-2xl font-bold ${
                metrics.expectancy >= 0 ? 'text-success' : 'text-danger'
              }`}>
                {formatCurrency(metrics.expectancy)}
              </div>
              <div className="text-xs text-muted-foreground mt-1">
                <span className="hidden sm:inline">Average per trade</span>
                <span className="sm:hidden">Avg/trade</span>
              </div>
            </CardContent>
          </Card>
        </div>
      )}
    </div>
  );
}