import { useEffect } from 'react';
import { useLocation } from 'react-router-dom';

// GTM & Analytics Configuration
const GTM_ID = import.meta.env.VITE_GTM_ID || 'GTM-XXXXXXX';
const GA4_ID = import.meta.env.VITE_GA4_ID || 'G-XXXXXXXXXX';
const GOOGLE_ADS_ID = import.meta.env.VITE_GOOGLE_ADS_ID || 'AW-XXXXXXXXX';
const GOOGLE_ADS_CONVERSION_LABEL = import.meta.env.VITE_GOOGLE_ADS_CONVERSION_LABEL || 'XXXXXXXXXX';

// Declare gtag function
declare global {
  interface Window {
    gtag: (...args: any[]) => void;
    dataLayer: any[];
  }
}

// Initialize dataLayer
if (typeof window !== 'undefined' && !window.dataLayer) {
  window.dataLayer = [];
}

// GTM gtag function
function gtag(...args: any[]) {
  if (typeof window !== 'undefined') {
    window.dataLayer.push(args);
  }
}

// Consent Mode v2 Configuration
export const initializeConsentMode = () => {
  if (typeof window === 'undefined') return;
  
  // Set default consent state (denied until user accepts)
  gtag('consent', 'default', {
    'ad_storage': 'denied',
    'analytics_storage': 'denied',
    'ad_user_data': 'denied',
    'ad_personalization': 'denied',
    'functionality_storage': 'granted',
    'security_storage': 'granted'
  });
  
  // Initialize GTM
  gtag('js', new Date());
  gtag('config', GA4_ID, {
    page_title: document.title,
    page_location: window.location.href
  });
};

// Update consent based on user preferences
export const updateConsent = (analytics: boolean, advertising: boolean) => {
  if (typeof window === 'undefined') return;
  
  gtag('consent', 'update', {
    'analytics_storage': analytics ? 'granted' : 'denied',
    'ad_storage': advertising ? 'granted' : 'denied',
    'ad_user_data': advertising ? 'granted' : 'denied',
    'ad_personalization': advertising ? 'granted' : 'denied'
  });
};

// Track events
export const trackEvent = (eventName: string, parameters: Record<string, any> = {}) => {
  if (typeof window === 'undefined') return;
  
  gtag('event', eventName, {
    event_category: parameters.category || 'engagement',
    event_label: parameters.label,
    value: parameters.value,
    ...parameters
  });
};

// Track conversions for Google Ads
export const trackConversion = (conversionLabel: string = GOOGLE_ADS_CONVERSION_LABEL, value?: number) => {
  if (typeof window === 'undefined') return;
  
  gtag('event', 'conversion', {
    'send_to': `${GOOGLE_ADS_ID}/${conversionLabel}`,
    'value': value || 1.0,
    'currency': 'USD'
  });
};

// Enhanced Conversions (with user email hash)
export const trackEnhancedConversion = (email?: string, phone?: string, value?: number) => {
  if (typeof window === 'undefined') return;
  
  const enhancedData: any = {};
  
  // Only include user data if consent is granted
  const consentState = localStorage.getItem('marketing_consent');
  if (consentState === 'true' && email) {
    enhancedData.email = hashEmail(email);
  }
  if (consentState === 'true' && phone) {
    enhancedData.phone_number = phone;
  }
  
  gtag('event', 'conversion', {
    'send_to': `${GOOGLE_ADS_ID}/${GOOGLE_ADS_CONVERSION_LABEL}`,
    'value': value || 1.0,
    'currency': 'USD',
    ...enhancedData
  });
};

// Simple email hashing for Enhanced Conversions
function hashEmail(email: string): string {
  // In a real implementation, use proper SHA-256 hashing
  // This is a simplified version for demo purposes
  return btoa(email.toLowerCase().trim());
}

// Page view tracking
export const trackPageView = (path: string, title?: string, userTraits?: any) => {
  if (typeof window === 'undefined') return;
  
  // Standard page view
  gtag('config', GA4_ID, {
    page_path: path,
    page_title: title || document.title,
    page_location: window.location.href
  });
  
  // Custom dataLayer push with user traits (if consented)
  const consentState = localStorage.getItem('analytics_consent');
  if (consentState === 'true' && userTraits) {
    window.dataLayer.push({
      event: 'page_view',
      page_path: path,
      user_role: userTraits.role,
      user_plan: userTraits.plan,
      user_id_hash: userTraits.userId ? hashEmail(userTraits.userId) : undefined
    });
  }
};

// Business event tracking
export const trackBusinessEvent = (eventName: string, data: any = {}) => {
  if (typeof window === 'undefined') return;
  
  const eventData = {
    event: eventName,
    ...data
  };
  
  window.dataLayer.push(eventData);
  
  // Also send to GA4
  gtag('event', eventName, data);
};

export const GoogleTracking = () => {
  const location = useLocation();
  
  useEffect(() => {
    // Initialize consent mode on first load
    initializeConsentMode();
  }, []);
  
  useEffect(() => {
    // Track page views on route changes
    trackPageView(location.pathname);
  }, [location]);
  
  return null;
};

// GTM Script Component
export const GTMScript = () => {
  useEffect(() => {
    if (typeof window === 'undefined' || !GTM_ID || GTM_ID === 'GTM-XXXXXXX') return;
    
    // GTM Head Script
    const script = document.createElement('script');
    script.innerHTML = `
      (function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
      new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
      j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
      'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
      })(window,document,'script','dataLayer','${GTM_ID}');
    `;
    document.head.appendChild(script);
    
    // GTM NoScript (body)
    const noscript = document.createElement('noscript');
    noscript.innerHTML = `
      <iframe src="https://www.googletagmanager.com/ns.html?id=${GTM_ID}"
      height="0" width="0" style="display:none;visibility:hidden"></iframe>
    `;
    document.body.insertBefore(noscript, document.body.firstChild);
    
    return () => {
      // Cleanup on unmount (though GTM usually stays loaded)
      script.remove();
      noscript.remove();
    };
  }, []);
  
  return null;
};