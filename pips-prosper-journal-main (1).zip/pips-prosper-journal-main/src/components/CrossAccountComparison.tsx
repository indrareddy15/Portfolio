import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { TrendingUp, TrendingDown, DollarSign, Target } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";

interface AccountMetrics {
  id: string;
  nickname: string;
  currency: string;
  account_type: string;
  broker_name: string;
  trade_count: number;
  net_pnl: number;
  win_rate: number;
  max_drawdown: number;
  avg_risk: number;
  balance: number;
}

export function CrossAccountComparison() {
  const [accountMetrics, setAccountMetrics] = useState<AccountMetrics[]>([]);
  const [loading, setLoading] = useState(true);
  const { user } = useAuth();

  useEffect(() => {
    if (!user) return;
    fetchAccountMetrics();
  }, [user]);

  const fetchAccountMetrics = async () => {
    if (!user) return;

    try {
      // Get all active accounts
      const { data: accounts, error: accountsError } = await supabase
        .from('accounts')
        .select('*')
        .eq('user_id', user.id)
        .eq('archived', false);

      if (accountsError) throw accountsError;

      const metricsPromises = accounts.map(async (account) => {
        // Get trades for this account
        const { data: trades } = await supabase
          .from('trades')
          .select('*')
          .eq('user_id', user.id)
          .eq('account_id', account.id)
          .not('closed_at', 'is', null);

        // Calculate metrics
        const metrics = calculateAccountMetrics(trades || [], account);
        return metrics;
      });

      const allMetrics = await Promise.all(metricsPromises);
      setAccountMetrics(allMetrics);
    } catch (error) {
      console.error('Error fetching account metrics:', error);
    } finally {
      setLoading(false);
    }
  };

  const calculateAccountMetrics = (trades: any[], account: any): AccountMetrics => {
    if (!trades || trades.length === 0) {
      return {
        id: account.id,
        nickname: account.nickname || account.name,
        currency: account.currency,
        account_type: account.account_type,
        broker_name: account.broker_name,
        trade_count: 0,
        net_pnl: 0,
        win_rate: 0,
        max_drawdown: 0,
        avg_risk: account.risk_preference || 1,
        balance: account.balance || 0,
      };
    }

    const closedTrades = trades.filter(t => t.closed_at && t.pnl !== null);
    const winningTrades = closedTrades.filter(t => t.pnl > 0);
    
    const totalPnL = closedTrades.reduce((sum, t) => sum + (t.pnl || 0), 0);
    const winRate = closedTrades.length > 0 ? (winningTrades.length / closedTrades.length) * 100 : 0;
    
    // Simple drawdown calculation (would need equity snapshots for accurate calculation)
    let runningPnL = 0;
    let peak = 0;
    let maxDD = 0;
    
    closedTrades.forEach(trade => {
      runningPnL += trade.pnl || 0;
      if (runningPnL > peak) {
        peak = runningPnL;
      }
      const drawdown = peak - runningPnL;
      if (drawdown > maxDD) {
        maxDD = drawdown;
      }
    });
    
    const maxDrawdownPercent = peak > 0 ? (maxDD / peak) * 100 : 0;

    return {
      id: account.id,
      nickname: account.nickname || account.name,
      currency: account.currency,
      account_type: account.account_type,
      broker_name: account.broker_name,
      trade_count: closedTrades.length,
      net_pnl: totalPnL,
      win_rate: winRate,
      max_drawdown: maxDrawdownPercent,
      avg_risk: account.risk_preference || 1,
      balance: account.balance || 0,
    };
  };

  const formatCurrency = (value: number, currency: string = 'USD') => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: currency,
      minimumFractionDigits: 2
    }).format(value);
  };

  const formatPercent = (value: number) => {
    return `${value.toFixed(1)}%`;
  };

  if (loading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Account Comparison</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-2">
            {Array.from({ length: 3 }).map((_, i) => (
              <div key={i} className="h-12 bg-muted rounded animate-pulse" />
            ))}
          </div>
        </CardContent>
      </Card>
    );
  }

  if (accountMetrics.length === 0) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Account Comparison</CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-muted-foreground text-center py-8">
            No accounts found. Add accounts to see comparison.
          </p>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Target className="h-5 w-5 text-primary" />
          Cross-Account Performance Comparison
        </CardTitle>
      </CardHeader>
      <CardContent className="p-3 sm:p-6">
        {/* Mobile Card View */}
        <div className="block md:hidden space-y-3">
          {accountMetrics
            .sort((a, b) => b.net_pnl - a.net_pnl)
            .map((account) => (
            <div key={account.id} className="bg-muted/30 rounded-lg p-4 space-y-3">
              <div className="flex items-start justify-between">
                <div>
                  <div className="font-medium text-sm">{account.nickname}</div>
                  <div className="text-xs text-muted-foreground flex items-center gap-1 mt-1">
                    {account.broker_name}
                    <Badge variant="outline" className="text-xs px-1 py-0">
                      {account.account_type === 'prop_firm' ? 'Prop' : 'Broker'}
                    </Badge>
                  </div>
                </div>
                <div className="text-right">
                  <div className="flex items-center gap-1">
                    {account.net_pnl >= 0 ? (
                      <TrendingUp className="h-3 w-3 text-success" />
                    ) : (
                      <TrendingDown className="h-3 w-3 text-danger" />
                    )}
                    <span className={`text-sm font-medium ${account.net_pnl >= 0 ? 'text-success' : 'text-danger'}`}>
                      {formatCurrency(account.net_pnl, account.currency)}
                    </span>
                  </div>
                </div>
              </div>
              
              <div className="grid grid-cols-2 gap-3 text-xs">
                <div>
                  <div className="text-muted-foreground">Trades</div>
                  <div className="font-medium">{account.trade_count}</div>
                </div>
                <div>
                  <div className="text-muted-foreground">Win Rate</div>
                  <div className={`font-medium ${account.win_rate >= 50 ? 'text-success' : 'text-muted-foreground'}`}>
                    {formatPercent(account.win_rate)}
                  </div>
                </div>
                <div>
                  <div className="text-muted-foreground">Max DD</div>
                  <div className={`font-medium ${
                    account.max_drawdown <= 5 ? 'text-success' : 
                    account.max_drawdown <= 10 ? 'text-warning' : 'text-danger'
                  }`}>
                    -{formatPercent(account.max_drawdown)}
                  </div>
                </div>
                <div>
                  <div className="text-muted-foreground">Balance</div>
                  <div className="font-medium">
                    {formatCurrency(account.balance, account.currency)}
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Desktop Table View */}
        <div className="hidden md:block">
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Account</TableHead>
                  <TableHead className="text-right">Trades</TableHead>
                  <TableHead className="text-right">Win Rate</TableHead>
                  <TableHead className="text-right">Net P&L</TableHead>
                  <TableHead className="text-right">Max DD</TableHead>
                  <TableHead className="text-right">Avg Risk</TableHead>
                  <TableHead className="text-right">Balance</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {accountMetrics
                  .sort((a, b) => b.net_pnl - a.net_pnl)
                  .map((account) => (
                  <TableRow key={account.id}>
                    <TableCell>
                      <div>
                        <div className="font-medium">{account.nickname}</div>
                        <div className="text-sm text-muted-foreground">
                          {account.broker_name}
                          <Badge 
                            variant="outline" 
                            className="ml-2 text-xs"
                          >
                            {account.account_type === 'prop_firm' ? 'Prop' : 'Broker'}
                          </Badge>
                        </div>
                      </div>
                    </TableCell>
                    <TableCell className="text-right">{account.trade_count}</TableCell>
                    <TableCell className="text-right">
                      <div className="flex items-center justify-end gap-1">
                        <Target className={`h-3 w-3 ${account.win_rate >= 50 ? 'text-success' : 'text-muted-foreground'}`} />
                        <span className={account.win_rate >= 50 ? 'text-success' : 'text-muted-foreground'}>
                          {formatPercent(account.win_rate)}
                        </span>
                      </div>
                    </TableCell>
                    <TableCell className="text-right">
                      <div className="flex items-center justify-end gap-1">
                        {account.net_pnl >= 0 ? (
                          <TrendingUp className="h-3 w-3 text-success" />
                        ) : (
                          <TrendingDown className="h-3 w-3 text-danger" />
                        )}
                        <span className={account.net_pnl >= 0 ? 'text-success font-medium' : 'text-danger font-medium'}>
                          {formatCurrency(account.net_pnl, account.currency)}
                        </span>
                      </div>
                    </TableCell>
                    <TableCell className="text-right">
                      <span className={`${
                        account.max_drawdown <= 5 ? 'text-success' : 
                        account.max_drawdown <= 10 ? 'text-warning' : 'text-danger'
                      }`}>
                        -{formatPercent(account.max_drawdown)}
                      </span>
                    </TableCell>
                    <TableCell className="text-right text-muted-foreground">
                      {account.avg_risk}%
                    </TableCell>
                    <TableCell className="text-right">
                      <div className="flex items-center justify-end gap-1">
                        <DollarSign className="h-3 w-3 text-muted-foreground" />
                        <span className="font-medium">
                          {formatCurrency(account.balance, account.currency)}
                        </span>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </div>
        
        {accountMetrics.length > 0 && (
          <div className="mt-4 pt-4 border-t border-border">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
              <div className="text-center">
                <div className="font-medium text-foreground">Total Accounts</div>
                <div className="text-muted-foreground">{accountMetrics.length}</div>
              </div>
              <div className="text-center">
                <div className="font-medium text-foreground">Total Trades</div>
                <div className="text-muted-foreground">
                  {accountMetrics.reduce((sum, acc) => sum + acc.trade_count, 0)}
                </div>
              </div>
              <div className="text-center">
                <div className="font-medium text-foreground">Combined P&L</div>
                <div className={`font-medium ${
                  accountMetrics.reduce((sum, acc) => sum + acc.net_pnl, 0) >= 0 ? 'text-success' : 'text-danger'
                }`}>
                  {formatCurrency(accountMetrics.reduce((sum, acc) => sum + acc.net_pnl, 0))}
                </div>
              </div>
              <div className="text-center">
                <div className="font-medium text-foreground">Avg Win Rate</div>
                <div className="text-muted-foreground">
                  {accountMetrics.length > 0 
                    ? formatPercent(accountMetrics.reduce((sum, acc) => sum + acc.win_rate, 0) / accountMetrics.length)
                    : '0%'
                  }
                </div>
              </div>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}