import { Button } from "@/components/ui/button";
import { 
  TrendingUp, 
  TrendingDown, 
  DollarSign, 
  Target,
  Calendar,
  MoreVertical
} from "lucide-react";

export const DashboardPreview = () => {
  return (
    <section className="py-12 sm:py-16 md:py-20 relative overflow-hidden">
      {/* Background Elements */}
      <div className="absolute inset-0 bg-muted/30"></div>
      <div className="absolute top-1/2 left-0 w-64 h-64 sm:w-96 sm:h-96 bg-primary/5 rounded-full blur-3xl"></div>
      <div className="absolute top-0 right-0 w-48 h-48 sm:w-64 sm:h-64 bg-success/10 rounded-full blur-2xl"></div>
      
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="text-center mb-8 sm:mb-12 md:mb-16 px-2 sm:px-0">
          <h2 className="text-2xl sm:text-3xl md:text-4xl lg:text-5xl font-poppins font-bold mb-4 sm:mb-6 leading-tight">
            Your Trading Command Center
          </h2>
          <p className="text-base sm:text-lg md:text-xl text-muted-foreground max-w-3xl mx-auto leading-relaxed">
            Get instant insights into your performance with real-time analytics, 
            advanced filtering, and beautiful visualizations.
          </p>
        </div>

        {/* Dashboard Mock */}
        <div className="max-w-6xl mx-auto px-2 sm:px-0">
          <div className="glass-card p-4 sm:p-6 md:p-8 rounded-xl sm:rounded-2xl">
            {/* Dashboard Header */}
            <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 mb-6 sm:mb-8">
              <div>
                <h3 className="text-lg sm:text-xl md:text-2xl font-poppins font-bold text-foreground">
                  Trading Dashboard
                </h3>
                <p className="text-sm sm:text-base text-muted-foreground">December 2024 Performance</p>
              </div>
              <Button variant="glass" size="sm" className="text-xs sm:text-sm">
                <Calendar className="w-3 h-3 sm:w-4 sm:h-4 mr-1 sm:mr-2" />
                Last 30 Days
              </Button>
            </div>

            {/* KPI Cards */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4 md:gap-6 mb-6 sm:mb-8">
              <div className="bg-success-light/50 border border-success/20 rounded-lg p-3 sm:p-4 md:p-6">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-xs sm:text-sm font-medium text-success-foreground">Win Rate</span>
                  <TrendingUp className="w-3 h-3 sm:w-4 sm:h-4 text-success" />
                </div>
                <div className="text-lg sm:text-xl md:text-2xl font-bold text-success">68.4%</div>
                <div className="text-xs text-success/70">+2.1% from last month</div>
              </div>

              <div className="bg-primary/5 border border-primary/20 rounded-lg p-3 sm:p-4 md:p-6">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-xs sm:text-sm font-medium text-foreground">Profit Factor</span>
                  <DollarSign className="w-3 h-3 sm:w-4 sm:h-4 text-primary" />
                </div>
                <div className="text-lg sm:text-xl md:text-2xl font-bold text-foreground">2.34</div>
                <div className="text-xs text-muted-foreground">Excellent</div>
              </div>

              <div className="bg-warning/5 border border-warning/20 rounded-lg p-3 sm:p-4 md:p-6">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-xs sm:text-sm font-medium text-foreground">Avg R:R</span>
                  <Target className="w-3 h-3 sm:w-4 sm:h-4 text-warning" />
                </div>
                <div className="text-lg sm:text-xl md:text-2xl font-bold text-foreground">1.8:1</div>
                <div className="text-xs text-muted-foreground">Good ratio</div>
              </div>

              <div className="bg-danger/5 border border-danger/20 rounded-lg p-3 sm:p-4 md:p-6">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-xs sm:text-sm font-medium text-foreground">Max DD</span>
                  <TrendingDown className="w-3 h-3 sm:w-4 sm:h-4 text-danger" />
                </div>
                <div className="text-lg sm:text-xl md:text-2xl font-bold text-foreground">-4.2%</div>
                <div className="text-xs text-muted-foreground">Within limits</div>
              </div>
            </div>

            {/* Chart Area Mock */}
            <div className="bg-muted/30 rounded-lg p-3 sm:p-4 md:p-6 mb-4 sm:mb-6">
              <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2 sm:gap-0 mb-3 sm:mb-4">
                <h4 className="text-base sm:text-lg font-semibold text-foreground">Equity Curve</h4>
                <Button variant="ghost" size="sm" className="self-end sm:self-auto">
                  <MoreVertical className="w-3 h-3 sm:w-4 sm:h-4" />
                </Button>
              </div>
              <div className="h-48 sm:h-56 md:h-64 bg-gradient-to-r from-success/20 via-primary/20 to-success/30 rounded-lg flex items-end justify-center relative overflow-hidden">
                <div className="absolute inset-0 bg-[linear-gradient(90deg,transparent_0%,rgba(0,143,253,0.1)_50%,transparent_100%)] animate-pulse"></div>
                <div className="text-muted-foreground text-xs sm:text-sm font-medium mb-4">
                  Interactive Chart Area
                </div>
              </div>
            </div>

            {/* Recent Trades */}
            <div>
              <h4 className="text-base sm:text-lg font-semibold text-foreground mb-3 sm:mb-4">Recent Trades</h4>
              <div className="space-y-2 sm:space-y-3">
                {[
                  { pair: "EURUSD", result: "win", pnl: "+$245", rr: "1.5:1" },
                  { pair: "GBPJPY", result: "loss", pnl: "-$120", rr: "0.8:1" },
                  { pair: "AUDUSD", result: "win", pnl: "+$380", rr: "2.1:1" },
                ].map((trade, index) => (
                  <div key={index} className="flex items-center justify-between p-2 sm:p-3 bg-muted/20 rounded-lg">
                    <div className="flex items-center space-x-2 sm:space-x-3">
                      <div className={`w-2 h-2 sm:w-3 sm:h-3 rounded-full ${trade.result === 'win' ? 'bg-success' : 'bg-danger'}`}></div>
                      <span className="text-sm sm:text-base font-medium text-foreground">{trade.pair}</span>
                    </div>
                    <div className="flex items-center space-x-2 sm:space-x-4 text-xs sm:text-sm">
                      <span className="text-muted-foreground hidden sm:inline">R:R {trade.rr}</span>
                      <span className="text-muted-foreground sm:hidden">{trade.rr}</span>
                      <span className={`font-semibold ${trade.result === 'win' ? 'text-success' : 'text-danger'}`}>
                        {trade.pnl}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};