import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { TrendingUp, TrendingDown } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/components/ui/use-toast";
import { z } from "zod";

// Trade validation schema
const tradeSchema = z.object({
  instrument: z.string().min(1, "Instrument is required"),
  side: z.enum(["long", "short"], { required_error: "Side is required" }),
  entry_price: z.number().positive("Entry price must be positive"),
  exit_price: z.number().positive("Exit price must be positive").optional(),
  size: z.number().positive("Size must be positive"),
  stop_loss: z.number().positive().optional(),
  take_profit: z.number().positive().optional(),
  risk_percent: z.number().min(0).max(100).optional(),
});

interface Trade {
  id: string;
  instrument: string;
  side: string;
  entry_price: number;
  exit_price: number | null;
  size: number;
  stop_loss: number | null;
  take_profit: number | null;
  risk_percent: number | null;
  opened_at: string;
  closed_at: string | null;
  notes_pre: string | null;
  notes_post: string | null;
  pnl: number | null;
  result: string | null;
}

interface EditTradeDialogProps {
  trade: Trade | null;
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onTradeUpdated?: () => void;
}

export function EditTradeDialog({ trade, open, onOpenChange, onTradeUpdated }: EditTradeDialogProps) {
  const [isLoading, setIsLoading] = useState(false);
  const [formData, setFormData] = useState<Partial<Trade>>({});
  const [validationErrors, setValidationErrors] = useState<Record<string, string>>({});
  const { toast } = useToast();

  // Populate form when trade changes
  useEffect(() => {
    if (trade) {
      setFormData({
        instrument: trade.instrument,
        side: trade.side,
        entry_price: trade.entry_price,
        exit_price: trade.exit_price,
        size: trade.size,
        stop_loss: trade.stop_loss,
        take_profit: trade.take_profit,
        risk_percent: trade.risk_percent,
        opened_at: trade.opened_at ? new Date(trade.opened_at).toISOString().slice(0, 16) : '',
        closed_at: trade.closed_at ? new Date(trade.closed_at).toISOString().slice(0, 16) : '',
        notes_pre: trade.notes_pre || '',
        notes_post: trade.notes_post || '',
      });
    }
  }, [trade]);

  const handleInputChange = (field: string, value: any) => {
    setFormData(prev => ({ ...prev, [field]: value }));
    // Clear validation error when user starts typing
    if (validationErrors[field]) {
      setValidationErrors(prev => ({ ...prev, [field]: '' }));
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!trade) return;

    setIsLoading(true);
    setValidationErrors({});

    // Prepare data for validation
    const rawData = {
      instrument: formData.instrument,
      side: formData.side,
      entry_price: Number(formData.entry_price),
      exit_price: formData.exit_price ? Number(formData.exit_price) : undefined,
      size: Number(formData.size),
      stop_loss: formData.stop_loss ? Number(formData.stop_loss) : undefined,
      take_profit: formData.take_profit ? Number(formData.take_profit) : undefined,
      risk_percent: formData.risk_percent ? Number(formData.risk_percent) : undefined,
    };

    // Validate with Zod
    try {
      tradeSchema.parse(rawData);
    } catch (error) {
      if (error instanceof z.ZodError) {
        const errors: Record<string, string> = {};
        error.errors.forEach((err) => {
          if (err.path[0]) {
            errors[err.path[0] as string] = err.message;
          }
        });
        setValidationErrors(errors);
        setIsLoading(false);
        return;
      }
    }

    // Prepare update data
    const updateData: any = {
      instrument: formData.instrument,
      side: formData.side,
      entry_price: Number(formData.entry_price),
      exit_price: formData.exit_price ? Number(formData.exit_price) : null,
      size: Number(formData.size),
      stop_loss: formData.stop_loss ? Number(formData.stop_loss) : null,
      take_profit: formData.take_profit ? Number(formData.take_profit) : null,
      risk_percent: formData.risk_percent ? Number(formData.risk_percent) : null,
      opened_at: formData.opened_at,
      closed_at: formData.closed_at || null,
      notes_pre: formData.notes_pre || null,
      notes_post: formData.notes_post || null,
    };

    // Calculate PnL if both entry and exit prices are provided
    if (updateData.exit_price) {
      const priceDiff = updateData.side === 'long' 
        ? updateData.exit_price - updateData.entry_price
        : updateData.entry_price - updateData.exit_price;
      updateData.pnl = priceDiff * updateData.size;
      updateData.result = updateData.pnl > 0 ? 'win' : updateData.pnl < 0 ? 'loss' : 'breakeven';
    } else {
      updateData.pnl = null;
      updateData.result = null;
    }

    const { error } = await supabase
      .from("trades")
      .update(updateData)
      .eq("id", trade.id);

    if (error) {
      console.error('Trade update error:', error);
      toast({
        variant: "destructive",
        title: "Error updating trade",
        description: error.message,
      });
    } else {
      console.log('Trade updated successfully:', updateData);
      toast({
        title: "Trade updated successfully",
        description: "Your trade has been updated in your journal.",
      });
      onTradeUpdated?.();
      onOpenChange(false);
    }

    setIsLoading(false);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Edit Trade</DialogTitle>
        </DialogHeader>
        
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="edit-instrument">Instrument</Label>
              <Input 
                id="edit-instrument"
                value={formData.instrument || ''}
                onChange={(e) => handleInputChange('instrument', e.target.value)}
                placeholder="e.g., EURUSD, BTCUSD"
                required 
              />
              {validationErrors.instrument && (
                <p className="text-sm text-red-500">{validationErrors.instrument}</p>
              )}
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="edit-side">Side</Label>
              <Select 
                value={formData.side || undefined} 
                onValueChange={(value) => handleInputChange('side', value)}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select side" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="long">
                    <div className="flex items-center gap-2">
                      <TrendingUp className="w-4 h-4 text-green-500" />
                      Long (Buy)
                    </div>
                  </SelectItem>
                  <SelectItem value="short">
                    <div className="flex items-center gap-2">
                      <TrendingDown className="w-4 h-4 text-red-500" />
                      Short (Sell)
                    </div>
                  </SelectItem>
                </SelectContent>
              </Select>
              {validationErrors.side && (
                <p className="text-sm text-red-500">{validationErrors.side}</p>
              )}
            </div>

            <div className="space-y-2">
              <Label htmlFor="edit-entry-price">Entry Price</Label>
              <Input 
                id="edit-entry-price"
                type="number"
                step="0.00001"
                value={formData.entry_price || ''}
                onChange={(e) => handleInputChange('entry_price', e.target.value)}
                placeholder="1.08450"
                required 
              />
              {validationErrors.entry_price && (
                <p className="text-sm text-red-500">{validationErrors.entry_price}</p>
              )}
            </div>

            <div className="space-y-2">
              <Label htmlFor="edit-size">Lot Size</Label>
              <Input 
                id="edit-size"
                type="number"
                step="0.01"
                value={formData.size || ''}
                onChange={(e) => handleInputChange('size', e.target.value)}
                placeholder="0.10 lots"
                required 
              />
              {validationErrors.size && (
                <p className="text-sm text-red-500">{validationErrors.size}</p>
              )}
            </div>

            <div className="space-y-2">
              <Label htmlFor="edit-stop-loss">Stop Loss</Label>
              <Input 
                id="edit-stop-loss"
                type="number"
                step="0.00001"
                value={formData.stop_loss || ''}
                onChange={(e) => handleInputChange('stop_loss', e.target.value)}
                placeholder="1.08200"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="edit-take-profit">Take Profit</Label>
              <Input 
                id="edit-take-profit"
                type="number"
                step="0.00001"
                value={formData.take_profit || ''}
                onChange={(e) => handleInputChange('take_profit', e.target.value)}
                placeholder="1.08700"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="edit-opened-at">Open Time</Label>
              <Input 
                id="edit-opened-at"
                type="datetime-local"
                value={formData.opened_at || ''}
                onChange={(e) => handleInputChange('opened_at', e.target.value)}
                required 
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="edit-closed-at">Close Time (if closed)</Label>
              <Input 
                id="edit-closed-at"
                type="datetime-local"
                value={formData.closed_at || ''}
                onChange={(e) => handleInputChange('closed_at', e.target.value)}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="edit-exit-price">Exit Price (if closed)</Label>
              <Input 
                id="edit-exit-price"
                type="number"
                step="0.00001"
                value={formData.exit_price || ''}
                onChange={(e) => handleInputChange('exit_price', e.target.value)}
                placeholder="1.08650"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="edit-risk-percent">Risk %</Label>
              <Input 
                id="edit-risk-percent"
                type="number"
                step="0.1"
                value={formData.risk_percent || ''}
                onChange={(e) => handleInputChange('risk_percent', e.target.value)}
                placeholder="2.0"
              />
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="edit-notes-pre">Pre-Trade Notes</Label>
            <Textarea 
              id="edit-notes-pre"
              value={formData.notes_pre || ''}
              onChange={(e) => handleInputChange('notes_pre', e.target.value)}
              placeholder="Why did you take this trade? What was your analysis?"
              rows={3}
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="edit-notes-post">Post-Trade Notes</Label>
            <Textarea 
              id="edit-notes-post"
              value={formData.notes_post || ''}
              onChange={(e) => handleInputChange('notes_post', e.target.value)}
              placeholder="How did the trade go? What did you learn?"
              rows={3}
            />
          </div>

          <DialogFooter>
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
              Cancel
            </Button>
            <Button type="submit" disabled={isLoading}>
              {isLoading ? "Updating..." : "Update Trade"}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}