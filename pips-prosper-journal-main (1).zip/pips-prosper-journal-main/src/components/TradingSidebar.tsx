import { useState, useEffect } from "react"
import { ChevronLeft, ChevronRight, Layout, Book, Upload, BarChart3, Beaker, Brain, Sparkles, ShieldCheck, Grid3X3, Trophy, Download, Settings, Sun, Moon, HelpCircle, Bell, Users, Award, Star, FileText } from "lucide-react"
import { NavLink, useLocation } from "react-router-dom"
import { useTheme } from "next-themes"

import {
  Sidebar,
  SidebarContent,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarMenuSub,
  SidebarMenuSubButton,
  SidebarMenuSubItem,
  SidebarHeader,
  SidebarFooter,
  SidebarTrigger,
  useSidebar,
} from "@/components/ui/sidebar"
import { Button } from "@/components/ui/button"
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible"
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip"

const mainNavItems = [
  { title: "Dashboard", url: "/app", icon: Layout, shortcut: "g d" },
  { title: "Journal", url: "/app/journal", icon: Book, shortcut: "g j" },
  { title: "Imports", url: "/app/imports", icon: Upload, shortcut: "g i" },
  { 
    title: "Analytics", 
    url: "/app/analytics", 
    icon: BarChart3, 
    shortcut: "g a",
    subItems: [
      { title: "Overview", url: "/app/analytics?tab=overview" },
      { title: "Instruments", url: "/app/analytics?tab=instruments" },
      { title: "Sessions", url: "/app/analytics?tab=sessions" },
      { title: "Calendar", url: "/app/analytics?tab=calendar" },
      { title: "Risk", url: "/app/analytics?tab=risk" },
      { title: "Mistakes", url: "/app/analytics?tab=mistakes" }
    ]
  },
  { title: "Strategy", url: "/app/strategy", icon: Beaker },
  { title: "Goals", url: "/app/goals-rules", icon: Trophy },
  { title: "Psychology", url: "/app/psychology", icon: Brain },
  { title: "AI Coach", url: "/app/ai", icon: Sparkles },
  { title: "Prop Metrics", url: "/app/prop", icon: ShieldCheck, shortcut: "g p" },
  { title: "Templates", url: "/app/templates", icon: Grid3X3 },
  { 
    title: "Affiliate", 
    url: "/app/affiliate", 
    icon: Users,
    subItems: [
      { title: "Overview", url: "/app/affiliate/overview" },
      { title: "Links", url: "/app/affiliate/links" },
      { title: "Sales", url: "/app/affiliate/sales" },
      { title: "Payouts", url: "/app/affiliate/payouts" },
      { title: "KYC Verification", url: "/app/affiliate/kyc" },
      { title: "Contract", url: "/app/affiliate/contract" },
      { title: "Creatives", url: "/app/affiliate/creatives" },
      { title: "Settings", url: "/app/affiliate/settings" }
    ]
  },
  { title: "Export", url: "/app/export", icon: Download },
  { title: "Blog", url: "/blog", icon: FileText },
]

const settingsNavItems = [
  { 
    title: "Settings", 
    url: "/app/settings", 
    icon: Settings, 
    shortcut: "g s",
    subItems: [
      { title: "Profile", url: "/app/settings/profile" },
      { title: "Accounts", url: "/app/settings/accounts" },
      { title: "Integrations", url: "/app/settings/integrations" },
      { title: "Goals & Rules", url: "/app/settings/goals" },
      { title: "Billing", url: "/app/settings/billing" },
      { title: "Data", url: "/app/settings/data" }
    ]
  },
]

// Hidden by default - feature flag
const leaderboardItem = { title: "Leaderboards", url: "/app/leaderboards", icon: Trophy }

export function TradingSidebar() {
  const { theme, setTheme } = useTheme()
  const { state, open, setOpen } = useSidebar()
  const location = useLocation()
  const [expandedGroups, setExpandedGroups] = useState<Record<string, boolean>>({})

  // Load persisted state from localStorage
  useEffect(() => {
    const saved = localStorage.getItem('tradingSidebar')
    if (saved) {
      try {
        const parsed = JSON.parse(saved)
        setExpandedGroups(parsed.expandedGroups || {})
      } catch (error) {
        console.error('Failed to parse sidebar state:', error)
      }
    }

    // Auto-expand parent groups based on current route
    const currentPath = location.pathname
    const analyticsExpanded = currentPath.startsWith('/app/analytics')
    const settingsExpanded = currentPath.startsWith('/app/settings')
    const affiliateExpanded = currentPath.startsWith('/app/affiliate')
    
    setExpandedGroups(prev => ({
      ...prev,
      analytics: analyticsExpanded,
      settings: settingsExpanded,
      affiliate: affiliateExpanded
    }))
  }, [location.pathname])

  // Save state to localStorage
  useEffect(() => {
    localStorage.setItem('tradingSidebar', JSON.stringify({
      collapsed: !open,
      expandedGroups
    }))
  }, [open, expandedGroups])

  // Keyboard shortcuts
  useEffect(() => {
    const handleKeyPress = (e: KeyboardEvent) => {
      // Only handle shortcuts when not in input fields
      if (e.target instanceof HTMLInputElement || e.target instanceof HTMLTextAreaElement) {
        return
      }

      const key = e.key.toLowerCase()
      
      // Handle sidebar collapse/expand shortcuts
      if (e.ctrlKey || e.metaKey) {
        if (key === '[') {
          e.preventDefault()
          setOpen(false)
        } else if (key === ']') {
          e.preventDefault()
          setOpen(true)
        }
      }
      
      // Handle navigation shortcuts (g + key)
      if (e.code === 'KeyG' && !e.ctrlKey && !e.metaKey) {
        // Start listening for next key
        const handleNavShortcut = (navEvent: KeyboardEvent) => {
          navEvent.preventDefault()
          const navKey = navEvent.key.toLowerCase()
          
          // Find matching shortcut
          const allItems = [...mainNavItems, ...settingsNavItems]
          const item = allItems.find(item => 
            item.shortcut && item.shortcut.endsWith(navKey)
          )
          
          if (item) {
            window.location.href = item.url
          }
          
          document.removeEventListener('keydown', handleNavShortcut)
        }
        
        document.addEventListener('keydown', handleNavShortcut)
        setTimeout(() => document.removeEventListener('keydown', handleNavShortcut), 2000)
      }
    }

    document.addEventListener('keydown', handleKeyPress)
    return () => document.removeEventListener('keydown', handleKeyPress)
  }, [setOpen])

  const isActive = (path: string) => location.pathname === path
  const isParentActive = (item: any) => {
    return item.subItems?.some((sub: any) => location.pathname === sub.url) || isActive(item.url)
  }

  const toggleGroup = (groupKey: string) => {
    setExpandedGroups(prev => ({
      ...prev,
      [groupKey]: !prev[groupKey]
    }))
  }

  const NavItem = ({ item, isCollapsed }: { item: any; isCollapsed: boolean }) => {
    const active = isActive(item.url)
    const parentActive = isParentActive(item)
    
    if (item.subItems) {
      const groupKey = item.title.toLowerCase().replace(' ', '-')
      const isExpanded = expandedGroups[groupKey] || parentActive

      return (
        <Collapsible open={isExpanded} onOpenChange={() => toggleGroup(groupKey)}>
          <SidebarMenuItem>
            <CollapsibleTrigger asChild>
              <SidebarMenuButton 
                className={`
                  w-full justify-between transition-all duration-200
                  ${parentActive ? 'bg-primary/10 text-primary border-l-4 border-primary' : 'hover:bg-muted/50'}
                  ${isCollapsed ? 'px-3' : 'px-4'}
                `}
                tooltip={isCollapsed ? item.title : undefined}
              >
                <div className="flex items-center gap-3">
                  <item.icon className={`${isCollapsed ? 'h-5 w-5' : 'h-4 w-4'} ${parentActive ? 'text-primary' : 'text-muted-foreground'} transition-colors`} />
                  {!isCollapsed && <span className="font-medium">{item.title}</span>}
                </div>
                {!isCollapsed && (
                  <ChevronRight className={`h-4 w-4 transition-transform ${isExpanded ? 'rotate-90' : ''}`} />
                )}
              </SidebarMenuButton>
            </CollapsibleTrigger>
            {!isCollapsed && (
              <CollapsibleContent>
                <SidebarMenuSub className="ml-6 mt-1">
                  {item.subItems.map((subItem: any) => (
                    <SidebarMenuSubItem key={subItem.url}>
                      <SidebarMenuSubButton 
                        asChild
                        className={`
                          transition-all duration-200
                          ${isActive(subItem.url) ? 'bg-primary/5 text-primary border-l-2 border-primary' : 'hover:bg-muted/30 text-muted-foreground hover:text-foreground'}
                        `}
                      >
                        <NavLink to={subItem.url}>
                          {subItem.title}
                        </NavLink>
                      </SidebarMenuSubButton>
                    </SidebarMenuSubItem>
                  ))}
                </SidebarMenuSub>
              </CollapsibleContent>
            )}
          </SidebarMenuItem>
        </Collapsible>
      )
    }

    const menuButton = (
      <SidebarMenuButton 
        asChild
        className={`
          transition-all duration-200
          ${active ? 'bg-primary/10 text-primary border-l-4 border-primary' : 'hover:bg-muted/50 text-muted-foreground hover:text-foreground'}
          ${isCollapsed ? 'px-3' : 'px-4'}
        `}
        tooltip={isCollapsed ? item.title : undefined}
      >
        <NavLink to={item.url} className="flex items-center gap-3">
          <item.icon className={`${isCollapsed ? 'h-5 w-5' : 'h-4 w-4'} ${active ? 'text-primary' : 'text-muted-foreground'} transition-colors`} />
          {!isCollapsed && <span className="font-medium">{item.title}</span>}
        </NavLink>
      </SidebarMenuButton>
    )

    return (
      <SidebarMenuItem>
        {isCollapsed ? (
          <TooltipProvider>
            <Tooltip>
              <TooltipTrigger asChild>
                {menuButton}
              </TooltipTrigger>
              <TooltipContent side="right">
                <p>{item.title}</p>
                {item.shortcut && <p className="text-xs opacity-60">{item.shortcut}</p>}
              </TooltipContent>
            </Tooltip>
          </TooltipProvider>
        ) : (
          menuButton
        )}
      </SidebarMenuItem>
    )
  }

  const isCollapsed = state === "collapsed"

  return (
    <Sidebar 
      className={`
        transition-all duration-200 border-r border-border
        ${isCollapsed ? 'w-12 sm:w-16' : 'w-48 sm:w-60'}
      `}
      collapsible="icon"
    >
      {/* Header */}
      <SidebarHeader className="border-b border-border p-4">
        <div className="flex items-center justify-center">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 bg-gradient-primary rounded-lg flex items-center justify-center">
              <span className="text-white font-bold text-sm">PJ</span>
            </div>
            {!isCollapsed && (
              <span className="font-poppins font-semibold text-foreground">PipTrackr.com</span>
            )}
          </div>
        </div>
      </SidebarHeader>

      {/* Navigation Content */}
      <SidebarContent>
        <SidebarGroup>
          <SidebarGroupLabel className={isCollapsed ? 'sr-only' : ''}>
            Navigation
          </SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu className="space-y-1">
              {mainNavItems.map((item) => (
                <NavItem key={item.url} item={item} isCollapsed={isCollapsed} />
              ))}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>

        <SidebarGroup>
          <SidebarGroupLabel className={isCollapsed ? 'sr-only' : ''}>
            Configuration
          </SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu className="space-y-1">
              {settingsNavItems.map((item) => (
                <NavItem key={item.url} item={item} isCollapsed={isCollapsed} />
              ))}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>
      </SidebarContent>

      {/* Footer Utilities */}
      <SidebarFooter className="border-t border-border p-2">
        <div className={`flex ${isCollapsed ? 'flex-col' : 'flex-row'} gap-1`}>
          <TooltipProvider>
            <Tooltip>
              <TooltipTrigger asChild>
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => setTheme(theme === "light" ? "dark" : "light")}
                  className="h-8 w-8"
                >
                  <Sun className="h-4 w-4 rotate-0 scale-100 transition-all dark:-rotate-90 dark:scale-0" />
                  <Moon className="absolute h-4 w-4 rotate-90 scale-0 transition-all dark:rotate-0 dark:scale-100" />
                </Button>
              </TooltipTrigger>
              <TooltipContent side="right">
                <p>Toggle theme</p>
              </TooltipContent>
            </Tooltip>
          </TooltipProvider>

          <TooltipProvider>
            <Tooltip>
              <TooltipTrigger asChild>
                <Button variant="ghost" size="icon" className="h-8 w-8">
                  <Bell className="h-4 w-4" />
                </Button>
              </TooltipTrigger>
              <TooltipContent side="right">
                <p>Notifications</p>
              </TooltipContent>
            </Tooltip>
          </TooltipProvider>

          <TooltipProvider>
            <Tooltip>
              <TooltipTrigger asChild>
                <Button variant="ghost" size="icon" className="h-8 w-8">
                  <HelpCircle className="h-4 w-4" />
                </Button>
              </TooltipTrigger>
              <TooltipContent side="right">
                <p>Help & Docs</p>
              </TooltipContent>
            </Tooltip>
          </TooltipProvider>
        </div>
      </SidebarFooter>
    </Sidebar>
  )
}