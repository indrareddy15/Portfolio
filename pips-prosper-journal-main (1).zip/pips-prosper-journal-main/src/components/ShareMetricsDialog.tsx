import { useState, useEffect } from "react";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Copy, Share2, Calendar, Lock, Eye, EyeOff } from "lucide-react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import type { Account } from "@/hooks/useAccounts";

interface ShareMetricsDialogProps {
  trigger?: React.ReactNode;
  accounts: Account[];
  defaultAccountId?: string | null;
}

export function ShareMetricsDialog({ trigger, accounts, defaultAccountId }: ShareMetricsDialogProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [shareUrl, setShareUrl] = useState("");
  const [showPasscode, setShowPasscode] = useState(false);
  
  const [formData, setFormData] = useState({
    scope: defaultAccountId ? 'account' : 'all_accounts',
    account_id: defaultAccountId || '',
    include_trades: true,
    mask_currency: false,
    hide_brokers: false,
    hide_open: false,
    passcode: '',
    expires_at: ''
  });

  // Update form data when defaultAccountId changes
  useEffect(() => {
    setFormData(prev => ({
      ...prev,
      scope: defaultAccountId ? 'account' : 'all_accounts',
      account_id: defaultAccountId || ''
    }));
  }, [defaultAccountId]);

  // Set up real-time subscription for share links
  useEffect(() => {
    const channel = supabase
      .channel('share-links-realtime')
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'share_links'
        },
        (payload) => {
          console.log('Share link updated:', payload);
          // You can add additional real-time handling here if needed
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, []);

  const handleCreate = async () => {
    setIsLoading(true);
    try {
      const { data, error } = await supabase.functions.invoke('share-create', {
        body: {
          ...formData,
          account_id: formData.scope === 'account' ? formData.account_id : null,
          expires_at: formData.expires_at ? new Date(formData.expires_at).toISOString() : null
        }
      });

      if (error) throw error;

      if (data?.success) {
        setShareUrl(data.data.url);
        toast.success("Share link created successfully!");
      } else {
        throw new Error(data?.error || 'Failed to create share link');
      }
    } catch (error: any) {
      console.error('Share creation error:', error);
      toast.error(error.message || "Failed to create share link");
    } finally {
      setIsLoading(false);
    }
  };

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(shareUrl);
      toast.success("Link copied to clipboard!");
    } catch (error) {
      toast.error("Failed to copy link");
    }
  };

  const resetForm = () => {
    setFormData({
      scope: defaultAccountId ? 'account' : 'all_accounts',
      account_id: defaultAccountId || '',
      include_trades: true,
      mask_currency: false,
      hide_brokers: false,
      hide_open: false,
      passcode: '',
      expires_at: ''
    });
    setShareUrl("");
    setShowPasscode(false);
  };

  return (
    <Dialog open={isOpen} onOpenChange={(open) => {
      setIsOpen(open);
      if (!open) {
        setTimeout(resetForm, 200);
      }
    }}>
      <DialogTrigger asChild>
        {trigger || (
          <Button variant="outline" size="sm">
            <Share2 className="h-4 w-4 mr-2" />
            Share
          </Button>
        )}
      </DialogTrigger>
      
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle>Share Account Metrics</DialogTitle>
          <DialogDescription>
            Create a read-only link to share your trading metrics
          </DialogDescription>
        </DialogHeader>

        {!shareUrl ? (
          <div className="space-y-4">
            <div className="space-y-2">
              <Label>Scope</Label>
              <Select value={formData.scope} onValueChange={(value) => setFormData(prev => ({ ...prev, scope: value }))}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all_accounts">All Accounts (Combined)</SelectItem>
                  <SelectItem value="account">This Account Only</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {formData.scope === 'account' && (
              <div className="space-y-2">
                <Label>Account</Label>
                <Select value={formData.account_id} onValueChange={(value) => setFormData(prev => ({ ...prev, account_id: value }))}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select account" />
                  </SelectTrigger>
                  <SelectContent className="bg-background border border-border shadow-lg z-50">
                    {accounts.map((account) => (
                      <SelectItem key={account.id} value={account.id}>
                        {account.nickname || account.name} • {account.broker_name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            )}

            <div className="space-y-3">
              <Label className="text-sm font-medium">Privacy Options</Label>
              
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label className="text-sm">Include trade list</Label>
                  <p className="text-xs text-muted-foreground">Show individual trades (read-only)</p>
                </div>
                <Switch
                  checked={formData.include_trades}
                  onCheckedChange={(checked) => setFormData(prev => ({ ...prev, include_trades: checked }))}
                />
              </div>

              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label className="text-sm">Mask currency amounts</Label>
                  <p className="text-xs text-muted-foreground">Hide $ amounts, show pips/% only</p>
                </div>
                <Switch
                  checked={formData.mask_currency}
                  onCheckedChange={(checked) => setFormData(prev => ({ ...prev, mask_currency: checked }))}
                />
              </div>

              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label className="text-sm">Hide broker names</Label>
                  <p className="text-xs text-muted-foreground">Anonymous broker/prop firm</p>
                </div>
                <Switch
                  checked={formData.hide_brokers}
                  onCheckedChange={(checked) => setFormData(prev => ({ ...prev, hide_brokers: checked }))}
                />
              </div>

              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label className="text-sm">Hide open positions</Label>
                  <p className="text-xs text-muted-foreground">Only show closed trades</p>
                </div>
                <Switch
                  checked={formData.hide_open}
                  onCheckedChange={(checked) => setFormData(prev => ({ ...prev, hide_open: checked }))}
                />
              </div>
            </div>

            <div className="space-y-3">
              <Label className="text-sm font-medium">Security Options</Label>
              
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label className="text-sm">Require passcode</Label>
                  <p className="text-xs text-muted-foreground">Optional password protection</p>
                </div>
                <Switch
                  checked={showPasscode}
                  onCheckedChange={setShowPasscode}
                />
              </div>

              {showPasscode && (
                <div className="space-y-2">
                  <Label htmlFor="passcode" className="sr-only">Passcode</Label>
                  <Input
                    id="passcode"
                    type="password"
                    placeholder="Enter passcode"
                    value={formData.passcode}
                    onChange={(e) => setFormData(prev => ({ ...prev, passcode: e.target.value }))}
                  />
                </div>
              )}

              <div className="space-y-2">
                <Label htmlFor="expires">Expire link (optional)</Label>
                <Input
                  id="expires"
                  type="datetime-local"
                  value={formData.expires_at}
                  onChange={(e) => setFormData(prev => ({ ...prev, expires_at: e.target.value }))}
                />
              </div>
            </div>

            <Button 
              onClick={handleCreate} 
              disabled={isLoading || (formData.scope === 'account' && !formData.account_id)}
              className="w-full"
            >
              {isLoading ? "Creating..." : "Create Share Link"}
            </Button>
          </div>
        ) : (
          <div className="space-y-4">
            <div className="space-y-2">
              <Label>Your share link is ready!</Label>
              <div className="flex gap-2">
                <Input value={shareUrl} readOnly className="font-mono text-xs" />
                <Button size="sm" onClick={handleCopy}>
                  <Copy className="h-4 w-4" />
                </Button>
              </div>
            </div>

            <div className="space-y-2">
              <p className="text-sm text-muted-foreground">
                Anyone with this link can view your trading metrics (read-only).
              </p>
              
              <div className="flex gap-2">
                <Button variant="outline" onClick={resetForm} className="flex-1">
                  Create Another
                </Button>
                <Button onClick={() => setIsOpen(false)} className="flex-1">
                  Done
                </Button>
              </div>
            </div>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}