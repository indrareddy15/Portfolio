import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Check, X, Star, Crown, Zap } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/useAuth";
import { useRealtime } from "@/hooks/useRealtime";

interface Plan {
  id: string;
  name: string;
  description: string;
  price_amount: number;
  price_currency: string;
  billing_cycle: string;
  stripe_price_id?: string;
  sort_order: number;
}

interface PlanFeature {
  id: string;
  plan_id: string;
  label: string;
  is_included: boolean;
  sort_order: number;
}

interface UserSubscription {
  plan_id?: string;
  status: string;
  current_period_end?: string;
}

export function PricingPage() {
  const [plans, setPlans] = useState<Plan[]>([]);
  const [features, setFeatures] = useState<PlanFeature[]>([]);
  const [userSubscription, setUserSubscription] = useState<UserSubscription | null>(null);
  const [loading, setLoading] = useState(true);
  const [checkoutLoading, setCheckoutLoading] = useState<string | null>(null);
  const [isYearly, setIsYearly] = useState(false);
  const { user } = useAuth();

  // Real-time updates for plans and features
  useRealtime([
    {
      table: 'plans',
      events: ['INSERT', 'UPDATE', 'DELETE'],
      onInsert: () => fetchPlans(),
      onUpdate: () => fetchPlans(),
      onDelete: () => fetchPlans(),
      showToasts: false
    },
    {
      table: 'plan_features',
      events: ['INSERT', 'UPDATE', 'DELETE'],
      onInsert: () => fetchFeatures(),
      onUpdate: () => fetchFeatures(),
      onDelete: () => fetchFeatures(),
      showToasts: false
    }
  ]);

  const fetchPlans = async () => {
    try {
      const { data, error } = await supabase
        .from('plans')
        .select('*')
        .eq('is_active', true)
        .order('sort_order');
      
      if (error) throw error;
      setPlans(data || []);
    } catch (error) {
      console.error('Error fetching plans:', error);
      toast({
        title: "Error",
        description: "Failed to load pricing plans",
        variant: "destructive"
      });
    }
  };

  const fetchFeatures = async () => {
    try {
      const { data, error } = await supabase
        .from('plan_features')
        .select('*')
        .order('plan_id, sort_order');
      
      if (error) throw error;
      setFeatures(data || []);
    } catch (error) {
      console.error('Error fetching features:', error);
    }
  };

  const fetchUserSubscription = async () => {
    if (!user) return;

    try {
      const { data, error } = await supabase
        .from('user_subscriptions')
        .select('plan_id, status, current_period_end')
        .eq('user_id', user.id)
        .eq('status', 'active')
        .maybeSingle();

      if (error) throw error;
      setUserSubscription(data);
    } catch (error) {
      console.error('Error fetching user subscription:', error);
    }
  };

  useEffect(() => {
    const loadData = async () => {
      setLoading(true);
      await Promise.all([
        fetchPlans(),
        fetchFeatures(),
        fetchUserSubscription()
      ]);
      setLoading(false);
    };
    loadData();
  }, [user]);

  const handleChoosePlan = async (plan: Plan) => {
    if (!user) {
      toast({
        title: "Authentication Required",
        description: "Please sign in to subscribe to a plan",
        variant: "destructive"
      });
      return;
    }

    if (!plan.stripe_price_id) {
      toast({
        title: "Setup Required",
        description: "This plan is not yet configured for payments",
        variant: "destructive"
      });
      return;
    }

    setCheckoutLoading(plan.id);

    try {
      const { data, error } = await supabase.functions.invoke('create-pricing-checkout', {
        body: {
          price_id: plan.stripe_price_id,
          plan_id: plan.id
        }
      });

      if (error) throw error;

      if (data?.url) {
        // Open Stripe checkout in a new tab
        window.open(data.url, '_blank');
      }
    } catch (error: any) {
      console.error('Error creating checkout:', error);
      toast({
        title: "Error",
        description: error.message || "Failed to create checkout session",
        variant: "destructive"
      });
    } finally {
      setCheckoutLoading(null);
    }
  };

  const handleManageBilling = async () => {
    if (!user) return;

    try {
      const { data, error } = await supabase.functions.invoke('pricing-billing-portal');
      
      if (error) throw error;

      if (data?.url) {
        window.open(data.url, '_blank');
      }
    } catch (error: any) {
      console.error('Error opening billing portal:', error);
      toast({
        title: "Error",
        description: error.message || "Failed to open billing portal",
        variant: "destructive"
      });
    }
  };

  const formatPrice = (amount: number, currency: string, cycle: string) => {
    if (amount === 0) return 'Free';
    
    const formattedAmount = new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: currency,
      minimumFractionDigits: 0,
      maximumFractionDigits: 2
    }).format(amount);
    
    return `${formattedAmount}/${cycle === 'yearly' ? 'year' : 'month'}`;
  };

  const getPlanFeatures = (planId: string) => {
    return features.filter(f => f.plan_id === planId).sort((a, b) => a.sort_order - b.sort_order);
  };

  const getPlanIcon = (plan: Plan) => {
    if (plan.name.toLowerCase().includes('free')) return Zap;
    if (plan.name.toLowerCase().includes('pro')) return Star;
    if (plan.name.toLowerCase().includes('elite') || plan.name.toLowerCase().includes('premium')) return Crown;
    return Star;
  };

  const isUserSubscribed = (planId: string) => {
    return userSubscription?.plan_id === planId && userSubscription.status === 'active';
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
      </div>
    );
  }

  return (
    <section className="py-20">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-16">
          <h1 className="text-4xl md:text-5xl font-poppins font-bold mb-6">
            Choose Your{" "}
            <span className="bg-gradient-primary bg-clip-text text-transparent">
              Trading Plan
            </span>
          </h1>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            Start your trading journey with our comprehensive plans designed for traders at every level.
            Upgrade or downgrade anytime.
          </p>
          
          {/* Billing Toggle */}
          <div className="inline-flex items-center bg-muted rounded-lg p-1 mt-8">
            <button 
              onClick={() => setIsYearly(false)}
              className={`px-4 py-2 text-sm font-medium transition-colors ${
                !isYearly 
                  ? 'bg-primary text-primary-foreground rounded-md' 
                  : 'text-muted-foreground hover:text-foreground'
              }`}
            >
              Monthly
            </button>
            <button 
              onClick={() => setIsYearly(true)}
              className={`px-4 py-2 text-sm font-medium transition-colors ${
                isYearly 
                  ? 'bg-primary text-primary-foreground rounded-md' 
                  : 'text-muted-foreground hover:text-foreground'
              }`}
            >
              Yearly (Save 20%)
            </button>
          </div>
        </div>

        {/* Pricing Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 max-w-7xl mx-auto">
          {plans
            .filter(plan => plan.billing_cycle === (isYearly ? 'yearly' : 'monthly') || plan.price_amount === 0)
            .map((plan) => {
            const Icon = getPlanIcon(plan);
            const planFeatures = getPlanFeatures(plan.id);
            const isSubscribed = isUserSubscribed(plan.id);
            const isPopular = plan.name.toLowerCase().includes('pro');
            const isCheckingOut = checkoutLoading === plan.id;

            return (
              <Card 
                key={plan.id} 
                className={`relative transition-all hover:shadow-xl ${
                  isPopular ? 'border-primary shadow-lg scale-105' : ''
                } ${isSubscribed ? 'ring-2 ring-success' : ''}`}
              >
                {/* Popular Badge */}
                {isPopular && (
                  <div className="absolute -top-4 left-1/2 transform -translate-x-1/2">
                    <Badge className="bg-primary text-primary-foreground px-4 py-1">
                      Most Popular
                    </Badge>
                  </div>
                )}

                {/* Current Plan Badge */}
                {isSubscribed && (
                  <div className="absolute -top-4 right-4">
                    <Badge variant="outline" className="bg-success text-success-foreground border-success">
                      Current Plan
                    </Badge>
                  </div>
                )}

                <CardHeader className="text-center pb-4">
                  <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center mx-auto mb-4">
                    <Icon className="w-6 h-6 text-primary" />
                  </div>
                  <CardTitle className="text-2xl font-bold">{plan.name}</CardTitle>
                  {plan.description && (
                    <p className="text-muted-foreground">{plan.description}</p>
                  )}
                </CardHeader>

                <CardContent className="space-y-6">
                  {/* Price */}
                  <div className="text-center">
                    <div className="text-4xl font-bold">
                      {formatPrice(plan.price_amount, plan.price_currency, plan.billing_cycle)}
                    </div>
                    {plan.price_amount > 0 && (
                      <div className="text-sm text-muted-foreground">
                        Billed {plan.billing_cycle}
                      </div>
                    )}
                  </div>

                  {/* Features */}
                  <div className="space-y-3">
                    {planFeatures.map((feature) => (
                      <div key={feature.id} className="flex items-center space-x-3">
                        <div className={`flex-shrink-0 w-5 h-5 rounded-full flex items-center justify-center ${
                          feature.is_included 
                            ? 'bg-success text-success-foreground' 
                            : 'bg-muted text-muted-foreground'
                        }`}>
                          {feature.is_included ? (
                            <Check className="w-3 h-3" />
                          ) : (
                            <X className="w-3 h-3" />
                          )}
                        </div>
                        <span className={`text-sm ${
                          feature.is_included ? 'text-foreground' : 'text-muted-foreground line-through'
                        }`}>
                          {feature.label}
                        </span>
                      </div>
                    ))}
                  </div>

                  {/* CTA Button */}
                  <div className="pt-4">
                    {isSubscribed ? (
                      <Button 
                        variant="outline" 
                        className="w-full"
                        onClick={handleManageBilling}
                      >
                        Manage Billing
                      </Button>
                    ) : (
                      <Button 
                        variant={isPopular ? "default" : "outline"}
                        className={`w-full ${isPopular ? 'glow-hover' : ''}`}
                        onClick={() => handleChoosePlan(plan)}
                        disabled={isCheckingOut || !plan.stripe_price_id}
                      >
                        {isCheckingOut ? 'Processing...' : `Choose ${plan.name}`}
                      </Button>
                    )}
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>

        {/* Bottom CTA */}
        <div className="text-center mt-16">
          <p className="text-muted-foreground mb-4">
            Need a custom plan for your trading firm?
          </p>
          <Button variant="outline" size="lg">
            Contact Sales
          </Button>
        </div>
      </div>
    </section>
  );
}