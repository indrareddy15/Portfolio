import { useState, useEffect } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { useRealtime } from "@/hooks/useRealtime";
import { CheckCircle, Crown, Zap, Loader2, RefreshCw } from "lucide-react";

interface SubscriptionData {
  subscribed: boolean;
  subscription_tier?: string;
  subscription_end?: string;
}

interface Plan {
  id: string;
  name: string;
  description: string;
  price_amount: number;
  price_currency: string;
  billing_cycle: string;
  is_active: boolean;
  sort_order: number;
  stripe_product_id?: string;
  stripe_price_id?: string;
}

interface PlanFeature {
  id: string;
  plan_id: string;
  label: string;
  is_included: boolean;
  sort_order: number;
}

export function SubscriptionManager() {
  const [subscriptionData, setSubscriptionData] = useState<SubscriptionData | null>(null);
  const [plans, setPlans] = useState<Plan[]>([]);
  const [features, setFeatures] = useState<PlanFeature[]>([]);
  const [loading, setLoading] = useState(true);
  const [actionLoading, setActionLoading] = useState<string | null>(null);
  const [isYearly, setIsYearly] = useState(false);
  const { toast } = useToast();
  const { user } = useAuth();

  // Real-time updates for plans and features
  useRealtime([
    {
      table: 'plans',
      events: ['INSERT', 'UPDATE', 'DELETE'],
      onInsert: () => fetchPlans(),
      onUpdate: () => fetchPlans(),
      onDelete: () => fetchPlans(),
      showToasts: false
    },
    {
      table: 'plan_features',
      events: ['INSERT', 'UPDATE', 'DELETE'],
      onInsert: () => fetchFeatures(),
      onUpdate: () => fetchFeatures(),
      onDelete: () => fetchFeatures(),
      showToasts: false
    }
  ]);

  const fetchPlans = async () => {
    try {
      const { data, error } = await supabase
        .from('plans')
        .select('*')
        .eq('is_active', true)
        .order('sort_order');
      
      if (error) throw error;
      setPlans(data || []);
    } catch (error) {
      console.error('Error fetching plans:', error);
      toast({
        title: "Error",
        description: "Failed to load pricing plans",
        variant: "destructive",
      });
    }
  };

  const fetchFeatures = async () => {
    try {
      const { data, error } = await supabase
        .from('plan_features')
        .select('*')
        .order('plan_id, sort_order');
      
      if (error) throw error;
      setFeatures(data || []);
    } catch (error) {
      console.error('Error fetching features:', error);
    }
  };

  const checkSubscription = async () => {
    if (!user) return;
    
    try {
      const { data, error } = await supabase.functions.invoke('check-subscription');
      
      if (error) throw error;
      
      setSubscriptionData(data);
    } catch (error) {
      console.error('Error checking subscription:', error);
      toast({
        title: "Error",
        description: "Failed to check subscription status",
        variant: "destructive",
      });
    }
  };

  const handleSubscribe = async (plan: Plan) => {
    if (!user) return;
    
    try {
      setActionLoading(plan.id);
      const { data, error } = await supabase.functions.invoke('create-pricing-checkout', {
        body: { 
          planId: plan.id,
          planName: plan.name,
          amount: plan.price_amount,
          currency: plan.price_currency,
          billingCycle: plan.billing_cycle
        }
      });
      
      if (error) throw error;
      
      // Open Stripe checkout in a new tab
      window.open(data.url, '_blank');
    } catch (error) {
      console.error('Error creating checkout:', error);
      toast({
        title: "Error",
        description: "Failed to create checkout session",
        variant: "destructive",
      });
    } finally {
      setActionLoading(null);
    }
  };

  const handleManageSubscription = async () => {
    if (!user) return;
    
    try {
      setActionLoading('manage');
      const { data, error } = await supabase.functions.invoke('pricing-billing-portal');
      
      if (error) throw error;
      
      // Open customer portal in a new tab
      window.open(data.url, '_blank');
    } catch (error) {
      console.error('Error opening customer portal:', error);
      toast({
        title: "Error",
        description: "Failed to open customer portal",
        variant: "destructive",
      });
    } finally {
      setActionLoading(null);
    }
  };

  const formatPrice = (amount: number, currency: string, cycle: string) => {
    const formattedAmount = new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: currency
    }).format(amount);
    
    return amount === 0 ? 'Free' : `${formattedAmount}/${cycle}`;
  };

  const getPlanFeatures = (planId: string) => {
    return features.filter(f => f.plan_id === planId && f.is_included);
  };

  useEffect(() => {
    const loadData = async () => {
      setLoading(true);
      await Promise.all([fetchPlans(), fetchFeatures()]);
      if (user) {
        await checkSubscription();
      }
      setLoading(false);
    };
    loadData();
  }, [user]);

  if (loading) {
    return (
      <div className="grid gap-6 md:grid-cols-auto-fit-300">
        {[1, 2, 3].map((i) => (
          <Card key={i} className="animate-pulse">
            <CardHeader>
              <div className="h-6 bg-muted rounded w-3/4"></div>
              <div className="h-4 bg-muted rounded w-1/2"></div>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                {[1, 2, 3].map((j) => (
                  <div key={j} className="h-4 bg-muted rounded"></div>
                ))}
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    );
  }

  const getCurrentPlan = () => {
    if (!subscriptionData?.subscribed) {
      // If not subscribed, find the free plan (price_amount = 0)
      return plans.find(p => p.price_amount === 0);
    }
    
    // Find plan by subscription tier name
    return plans.find(p => p.name === subscriptionData.subscription_tier);
  };

  const currentPlan = getCurrentPlan();

  return (
    <div className="space-y-6">
      {/* Billing Toggle */}
      <div className="text-center">
        <div className="inline-flex items-center bg-muted rounded-lg p-1">
          <button 
            onClick={() => setIsYearly(false)}
            className={`px-4 py-2 text-sm font-medium transition-colors ${
              !isYearly 
                ? 'bg-primary text-primary-foreground rounded-md' 
                : 'text-muted-foreground hover:text-foreground'
            }`}
          >
            Monthly
          </button>
          <button 
            onClick={() => setIsYearly(true)}
            className={`px-4 py-2 text-sm font-medium transition-colors ${
              isYearly 
                ? 'bg-primary text-primary-foreground rounded-md' 
                : 'text-muted-foreground hover:text-foreground'
            }`}
          >
            Yearly (Save 20%)
          </button>
        </div>
      </div>

      {/* Current Subscription Status */}
      {subscriptionData && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              Current Subscription
              <Button
                variant="ghost"
                size="sm"
                onClick={checkSubscription}
                disabled={loading}
              >
                <RefreshCw className={`h-4 w-4 ${loading ? 'animate-spin' : ''}`} />
              </Button>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <Badge variant={subscriptionData.subscribed ? "default" : "secondary"}>
                  {subscriptionData.subscribed ? subscriptionData.subscription_tier : "Free"}
                </Badge>
                {subscriptionData.subscribed && (
                  <span className="text-sm text-muted-foreground">
                    Active until {new Date(subscriptionData.subscription_end!).toLocaleDateString()}
                  </span>
                )}
              </div>
              {subscriptionData.subscribed && (
                <Button
                  onClick={handleManageSubscription}
                  disabled={actionLoading === 'manage'}
                >
                  {actionLoading === 'manage' && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                  Manage Subscription
                </Button>
              )}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Pricing Plans */}
      <div className="grid gap-6 md:grid-cols-auto-fit-300">
        {plans
          .filter(plan => plan.billing_cycle === (isYearly ? 'yearly' : 'monthly') || plan.price_amount === 0)
          .map((plan) => {
          const isCurrentPlan = currentPlan?.id === plan.id;
          const planFeatures = getPlanFeatures(plan.id);
          const isFree = plan.price_amount === 0;
          const isPremium = plan.price_amount > 0 && plan.price_amount <= 1000; // Up to $10
          
          return (
            <Card 
              key={plan.id}
              className={`relative ${isPremium ? 'ring-2 ring-primary' : ''} ${isCurrentPlan ? 'bg-muted/50' : ''}`}
            >
              {isPremium && (
                <div className="absolute -top-3 left-1/2 -translate-x-1/2">
                  <Badge className="bg-primary text-primary-foreground">
                    Most Popular
                  </Badge>
                </div>
              )}
              
              {isCurrentPlan && (
                <div className="absolute -top-3 right-4">
                  <Badge variant="secondary" className="bg-green-100 text-green-800">
                    <CheckCircle className="w-3 h-3 mr-1" />
                    Current Plan
                  </Badge>
                </div>
              )}

              <CardHeader className="text-center">
                <CardTitle className="flex items-center justify-center gap-2">
                  {plan.name}
                  {isPremium && <Crown className="h-5 w-5 text-yellow-500" />}
                  {plan.price_amount > 1000 && <Zap className="h-5 w-5 text-purple-500" />}
                </CardTitle>
                <CardDescription>
                  <span className="text-3xl font-bold">
                    {formatPrice(plan.price_amount, plan.price_currency, plan.billing_cycle)}
                  </span>
                </CardDescription>
                {plan.description && (
                  <p className="text-sm text-muted-foreground mt-2">{plan.description}</p>
                )}
              </CardHeader>

              <CardContent className="space-y-4">
                <ul className="space-y-2">
                  {planFeatures.map((feature) => (
                    <li key={feature.id} className="flex items-center gap-2 text-sm">
                      <CheckCircle className="h-4 w-4 text-green-500 flex-shrink-0" />
                      {feature.label}
                    </li>
                  ))}
                </ul>

                {!isFree && !isCurrentPlan && (
                  <Button
                    className="w-full"
                    variant={isPremium ? "default" : "outline"}
                    onClick={() => handleSubscribe(plan)}
                    disabled={actionLoading === plan.id}
                  >
                    {actionLoading === plan.id && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                    Subscribe to {plan.name}
                  </Button>
                )}

                {isFree && !isCurrentPlan && (
                  <Button className="w-full" variant="outline" disabled>
                    Upgrade to access
                  </Button>
                )}

                {isCurrentPlan && isFree && (
                  <Button className="w-full" variant="outline" disabled>
                    Current Plan
                  </Button>
                )}
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* Success/Cancel Messages */}
      <div className="text-center text-sm text-muted-foreground">
        <p>All subscriptions can be cancelled at any time from the customer portal.</p>
        <p>Questions? Contact support for assistance.</p>
      </div>
    </div>
  );
}