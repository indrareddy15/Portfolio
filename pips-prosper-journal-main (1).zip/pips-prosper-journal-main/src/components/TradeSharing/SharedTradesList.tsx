import { useState, useEffect } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { 
  Share, 
  Eye, 
  Trophy, 
  MoreVertical, 
  Copy, 
  Edit, 
  Trash2, 
  ExternalLink,
  Calendar,
  Globe,
  Lock,
  TrendingUp,
  Facebook,
  Twitter,
  Linkedin
} from "lucide-react";
import { useTradeSharing, TradeShare } from "@/hooks/useTradeSharing";
import { useToast } from "@/hooks/use-toast";
import { format } from "date-fns";

interface SharedTradesListProps {
  tradeId?: string;
  onEditShare?: (share: TradeShare) => void;
}

export const SharedTradesList = ({ tradeId, onEditShare }: SharedTradesListProps) => {
  const [shares, setShares] = useState<TradeShare[]>([]);
  const [loading, setLoading] = useState(true);
  const { getTradeShares, deleteTradeShare, generateCertificate } = useTradeSharing();
  const { toast } = useToast();

  useEffect(() => {
    loadShares();
  }, [tradeId]);

  const loadShares = async () => {
    setLoading(true);
    const data = await getTradeShares(tradeId);
    setShares(data);
    setLoading(false);
  };

  const handleCopyLink = (shareToken: string) => {
    const url = `${window.location.origin}/shared/trade/${shareToken}`;
    navigator.clipboard.writeText(url);
    toast({
      title: "Link Copied! 📋",
      description: "Share link has been copied to your clipboard",
    });
  };

  const handleDelete = async (shareId: string) => {
    if (confirm('Are you sure you want to delete this share? This action cannot be undone.')) {
      const success = await deleteTradeShare(shareId);
      if (success) {
        loadShares();
      }
    }
  };

  const handleGenerateCertificate = async (shareId: string) => {
    await generateCertificate(shareId);
    loadShares(); // Refresh to show certificate status
  };

  const getShareUrl = (shareToken: string) => {
    return `${window.location.origin}/shared/trade/${shareToken}`;
  };

  const handleSocialShare = (platform: string, shareToken: string, title: string) => {
    const url = getShareUrl(shareToken);
    const text = `Check out my trading results on PipTrackr.com! ${title}`;
    
    let shareUrl = '';
    
    switch (platform) {
      case 'facebook':
        shareUrl = `https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(url)}`;
        break;
      case 'twitter':
        shareUrl = `https://twitter.com/intent/tweet?text=${encodeURIComponent(text)}&url=${encodeURIComponent(url)}&hashtags=trading,forex,piptrakr`;
        break;
      case 'linkedin':
        shareUrl = `https://www.linkedin.com/sharing/share-offsite/?url=${encodeURIComponent(url)}`;
        break;
    }
    
    if (shareUrl) {
      window.open(shareUrl, '_blank', 'width=600,height=400');
    }
  };

  if (loading) {
    return (
      <div className="space-y-4">
        {[...Array(3)].map((_, i) => (
          <Card key={i} className="animate-pulse">
            <CardContent className="p-4">
              <div className="h-4 bg-muted rounded mb-2"></div>
              <div className="h-3 bg-muted rounded w-3/4"></div>
            </CardContent>
          </Card>
        ))}
      </div>
    );
  }

  if (shares.length === 0) {
    return (
      <Card className="text-center py-8">
        <CardContent>
          <Share className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
          <h3 className="text-lg font-semibold mb-2">No Shared Trades Yet</h3>
          <p className="text-muted-foreground mb-4">
            Share your trades to showcase your trading skills and attract followers
          </p>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-4">
      <h3 className="text-lg font-semibold">Shared Trades ({shares.length})</h3>
      
      {shares.map((share) => (
        <Card key={share.id} className="group hover:shadow-md transition-shadow">
          <CardHeader className="pb-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <CardTitle className="text-base">{share.title || 'Untitled Trade'}</CardTitle>
                <Badge variant={share.is_public ? "default" : "secondary"} className="text-xs">
                  {share.is_public ? (
                    <>
                      <Globe className="w-3 h-3 mr-1" />
                      Public
                    </>
                  ) : (
                    <>
                      <Lock className="w-3 h-3 mr-1" />
                      Private
                    </>
                  )}
                </Badge>
                {!share.is_active && (
                  <Badge variant="destructive" className="text-xs">
                    Inactive
                  </Badge>
                )}
              </div>
              
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="ghost" size="sm">
                    <MoreVertical className="w-4 h-4" />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end">
                  <DropdownMenuItem onClick={() => handleCopyLink(share.share_token)}>
                    <Copy className="w-4 h-4 mr-2" />
                    Copy Link
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={() => window.open(getShareUrl(share.share_token), '_blank')}>
                    <ExternalLink className="w-4 h-4 mr-2" />
                    View Share
                  </DropdownMenuItem>
                  {onEditShare && (
                    <DropdownMenuItem onClick={() => onEditShare(share)}>
                      <Edit className="w-4 h-4 mr-2" />
                      Edit
                    </DropdownMenuItem>
                  )}
                  <DropdownMenuItem 
                    onClick={() => handleGenerateCertificate(share.id)}
                    disabled={share.certificate_generated}
                  >
                    <Trophy className="w-4 h-4 mr-2" />
                    {share.certificate_generated ? 'Certificate Ready' : 'Generate Certificate'}
                  </DropdownMenuItem>
                  <DropdownMenuItem 
                    onClick={() => handleDelete(share.id)}
                    className="text-destructive"
                  >
                    <Trash2 className="w-4 h-4 mr-2" />
                    Delete
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </div>
            
            {share.description && (
              <CardDescription className="text-sm">
                {share.description}
              </CardDescription>
            )}
          </CardHeader>
          
          <CardContent className="pt-0">
            <div className="flex items-center justify-between text-sm text-muted-foreground mb-4">
              <div className="flex items-center gap-4">
                <div className="flex items-center gap-1">
                  <Eye className="w-4 h-4" />
                  <span>{share.view_count} views</span>
                </div>
                <div className="flex items-center gap-1">
                  <Calendar className="w-4 h-4" />
                  <span>{format(new Date(share.created_at), 'MMM dd, yyyy')}</span>
                </div>
                {share.certificate_generated && (
                  <div className="flex items-center gap-1 text-warning">
                    <Trophy className="w-4 h-4" />
                    <span>Certificate Ready</span>
                  </div>
                )}
              </div>
            </div>
            
            {/* Quick Actions */}
            <div className="flex gap-2 flex-wrap">
              <Button
                size="sm"
                variant="outline"
                onClick={() => handleCopyLink(share.share_token)}
                className="flex-1 min-w-0"
              >
                <Copy className="w-4 h-4 mr-2" />
                Copy Link
              </Button>
              
              {/* Social Media Buttons */}
              <Button
                size="sm"
                variant="outline"
                onClick={() => handleSocialShare('facebook', share.share_token, share.title || '')}
                className="px-3"
              >
                <Facebook className="w-4 h-4" />
              </Button>
              <Button
                size="sm"
                variant="outline"
                onClick={() => handleSocialShare('twitter', share.share_token, share.title || '')}
                className="px-3"
              >
                <Twitter className="w-4 h-4" />
              </Button>
              <Button
                size="sm"
                variant="outline"
                onClick={() => handleSocialShare('linkedin', share.share_token, share.title || '')}
                className="px-3"
              >
                <Linkedin className="w-4 h-4" />
              </Button>
            </div>
            
            {share.expires_at && (
              <div className="mt-3 text-xs text-muted-foreground">
                Expires: {format(new Date(share.expires_at), 'PPP')}
              </div>
            )}
          </CardContent>
        </Card>
      ))}
    </div>
  );
};