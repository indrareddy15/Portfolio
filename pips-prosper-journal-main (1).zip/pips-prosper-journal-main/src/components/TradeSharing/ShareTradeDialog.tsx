import { useState } from "react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { cn } from "@/lib/utils";
import { CalendarIcon, Share, Trophy, Eye, Users, Lock, Globe } from "lucide-react";
import { format, addDays } from "date-fns";
import { useTradeSharing, TradeShareCreateData } from "@/hooks/useTradeSharing";

interface Trade {
  id: string;
  instrument: string;
  pnl: number;
  opened_at: string;
  closed_at?: string;
  entry_price: number;
  exit_price?: number;
  side: 'buy' | 'sell';
  size: number;
}

interface ShareTradeDialogProps {
  trade: Trade;
  isOpen: boolean;
  onClose: () => void;
  onSuccess: (shareData: any) => void;
}

export const ShareTradeDialog = ({ trade, isOpen, onClose, onSuccess }: ShareTradeDialogProps) => {
  const [title, setTitle] = useState(`${trade.pnl > 0 ? 'Profitable' : 'Learning'} ${trade.instrument} Trade`);
  const [description, setDescription] = useState(
    `Check out my ${trade.side.toUpperCase()} trade on ${trade.instrument}! ${
      trade.pnl > 0 
        ? `Made ${trade.pnl > 0 ? '+' : ''}$${trade.pnl.toFixed(2)} profit 📈` 
        : `Learning from this trade experience 📚`
    }`
  );
  const [isPublic, setIsPublic] = useState(true);
  const [hasExpiry, setHasExpiry] = useState(false);
  const [expiryDate, setExpiryDate] = useState<Date>(addDays(new Date(), 30));

  const { loading, createTradeShare } = useTradeSharing();

  const handleShare = async () => {
    const shareData: TradeShareCreateData = {
      trade_id: trade.id,
      title,
      description,
      is_public: isPublic,
      expires_at: hasExpiry ? expiryDate.toISOString() : undefined,
    };

    const result = await createTradeShare(shareData);
    if (result) {
      onSuccess(result);
      onClose();
    }
  };

  const getPnlColor = (pnl: number) => {
    return pnl > 0 ? 'text-success' : pnl < 0 ? 'text-danger' : 'text-muted-foreground';
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Share className="w-5 h-5" />
            Share Your Trade
          </DialogTitle>
          <DialogDescription>
            Create a shareable link for your trade to showcase on social media
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-6">
          {/* Trade Preview */}
          <div className="bg-card/50 rounded-lg p-4 border">
            <div className="flex items-center justify-between mb-2">
              <h4 className="font-semibold text-lg">{trade.instrument}</h4>
              <div className="flex items-center gap-2">
                <Trophy className="w-4 h-4 text-warning" />
                <span className={cn("font-bold text-lg", getPnlColor(trade.pnl))}>
                  {trade.pnl > 0 ? '+' : ''}${trade.pnl.toFixed(2)}
                </span>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4 text-sm">
              <div>
                <span className="text-muted-foreground">Side:</span> 
                <span className="ml-2 font-medium capitalize">{trade.side}</span>
              </div>
              <div>
                <span className="text-muted-foreground">Size:</span> 
                <span className="ml-2 font-medium">{trade.size}</span>
              </div>
              <div>
                <span className="text-muted-foreground">Entry:</span> 
                <span className="ml-2 font-medium">{trade.entry_price}</span>
              </div>
              <div>
                <span className="text-muted-foreground">Exit:</span> 
                <span className="ml-2 font-medium">{trade.exit_price || 'N/A'}</span>
              </div>
            </div>
          </div>

          {/* Share Settings */}
          <div className="space-y-4">
            <div>
              <Label htmlFor="title" className="text-sm font-medium">
                Share Title
              </Label>
              <Input
                id="title"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder="Give your trade a catchy title..."
                className="mt-1"
              />
            </div>

            <div>
              <Label htmlFor="description" className="text-sm font-medium">
                Description
              </Label>
              <Textarea
                id="description"
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                placeholder="Tell the story behind this trade..."
                className="mt-1 min-h-[100px]"
              />
            </div>

            {/* Privacy Settings */}
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <div className="space-y-1">
                  <Label className="text-sm font-medium flex items-center gap-2">
                    {isPublic ? <Globe className="w-4 h-4" /> : <Lock className="w-4 h-4" />}
                    Public Share
                  </Label>
                  <p className="text-xs text-muted-foreground">
                    {isPublic 
                      ? "Anyone with the link can view this trade" 
                      : "Only people you share the link with can view"
                    }
                  </p>
                </div>
                <Switch
                  checked={isPublic}
                  onCheckedChange={setIsPublic}
                />
              </div>

              <div className="flex items-center justify-between">
                <div className="space-y-1">
                  <Label className="text-sm font-medium">Auto-Expire</Label>
                  <p className="text-xs text-muted-foreground">
                    Automatically disable the share after a certain date
                  </p>
                </div>
                <Switch
                  checked={hasExpiry}
                  onCheckedChange={setHasExpiry}
                />
              </div>

              {hasExpiry && (
                <div>
                  <Label className="text-sm font-medium">Expiry Date</Label>
                  <Popover>
                    <PopoverTrigger asChild>
                      <Button
                        variant="outline"
                        className={cn(
                          "w-full mt-1 justify-start text-left font-normal",
                          !expiryDate && "text-muted-foreground"
                        )}
                      >
                        <CalendarIcon className="mr-2 h-4 w-4" />
                        {expiryDate ? format(expiryDate, "PPP") : <span>Pick a date</span>}
                      </Button>
                    </PopoverTrigger>
                    <PopoverContent className="w-auto p-0" align="start">
                      <Calendar
                        mode="single"
                        selected={expiryDate}
                        onSelect={(date) => date && setExpiryDate(date)}
                        disabled={(date) => date < new Date()}
                        initialFocus
                      />
                    </PopoverContent>
                  </Popover>
                </div>
              )}
            </div>
          </div>

          {/* Actions */}
          <div className="flex gap-3 pt-4">
            <Button
              onClick={onClose}
              variant="outline"
              className="flex-1"
            >
              Cancel
            </Button>
            <Button
              onClick={handleShare}
              disabled={loading || !title.trim()}
              className="flex-1"
            >
              {loading ? (
                <>
                  <div className="w-4 h-4 border-2 border-primary-foreground/20 border-t-primary-foreground rounded-full animate-spin mr-2" />
                  Creating...
                </>
              ) : (
                <>
                  <Share className="w-4 h-4 mr-2" />
                  Create Share Link
                </>
              )}
            </Button>
          </div>

          {/* Features Preview */}
          <div className="bg-muted/20 rounded-lg p-4 border-l-4 border-primary">
            <h4 className="font-medium mb-2 text-sm">What you'll get:</h4>
            <ul className="text-xs space-y-1 text-muted-foreground">
              <li className="flex items-center gap-2">
                <Eye className="w-3 h-3" />
                Real-time view tracking & analytics
              </li>
              <li className="flex items-center gap-2">
                <Trophy className="w-3 h-3" />
                Generate professional trading certificates
              </li>
              <li className="flex items-center gap-2">
                <Users className="w-3 h-3" />
                Optimized for all social media platforms
              </li>
            </ul>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};