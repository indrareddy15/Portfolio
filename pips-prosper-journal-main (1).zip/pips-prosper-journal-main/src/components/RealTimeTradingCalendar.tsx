import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Calendar as CalendarIcon, TrendingUp, Activity, Wifi, Clock, Eye, Edit3, Save, X } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";

interface DailyStats {
  date: string;
  trades: number;
  pnl: number;
  winRate: number;
  volume: number;
}

interface Trade {
  id: string;
  instrument: string;
  side: string;
  entry_price: number;
  exit_price: number;
  size: number;
  pnl: number;
  opened_at: string;
  closed_at: string;
  notes_pre?: string;
  notes_post?: string;
  result: string;
  strategy_id?: string;
}

export function RealTimeTradingCalendar() {
  const [dailyStats, setDailyStats] = useState<DailyStats[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedMonth, setSelectedMonth] = useState(new Date().getMonth());
  const [selectedYear, setSelectedYear] = useState(new Date().getFullYear());
  const [lastUpdate, setLastUpdate] = useState(new Date());
  const [selectedDate, setSelectedDate] = useState<string | null>(null);
  const [dailyTrades, setDailyTrades] = useState<Trade[]>([]);
  const [showTradesDialog, setShowTradesDialog] = useState(false);
  const [selectedTrade, setSelectedTrade] = useState<Trade | null>(null);
  const [showTradeDetail, setShowTradeDetail] = useState(false);
  const [editingNotes, setEditingNotes] = useState(false);
  const [preTradeNotes, setPreTradeNotes] = useState('');
  const [postTradeNotes, setPostTradeNotes] = useState('');
  const [loadingTrades, setLoadingTrades] = useState(false);
  const { user } = useAuth();
  const { toast } = useToast();

  const fetchCalendarData = async () => {
    if (!user) return;

    try {
      setLoading(true);

      // Get start and end dates for the selected month
      const startDate = new Date(selectedYear, selectedMonth, 1);
      const endDate = new Date(selectedYear, selectedMonth + 1, 0);

      const { data: trades, error } = await supabase
        .from('trades')
        .select('*')
        .eq('user_id', user.id)
        .gte('opened_at', startDate.toISOString())
        .lte('opened_at', endDate.toISOString())
        .not('closed_at', 'is', null);

      if (error) throw error;

      // Group trades by day
      const dailyStatsMap = new Map<string, {
        trades: any[];
        pnl: number;
        winningTrades: number;
        volume: number;
      }>();

      trades?.forEach(trade => {
        const date = new Date(trade.opened_at).toISOString().split('T')[0];
        
        if (!dailyStatsMap.has(date)) {
          dailyStatsMap.set(date, { trades: [], pnl: 0, winningTrades: 0, volume: 0 });
        }

        const dayData = dailyStatsMap.get(date)!;
        dayData.trades.push(trade);
        dayData.pnl += trade.pnl || 0;
        dayData.volume += Math.abs(trade.pnl || 0);
        if ((trade.pnl || 0) > 0) dayData.winningTrades++;
      });

      // Convert to DailyStats array
      const stats: DailyStats[] = Array.from(dailyStatsMap.entries()).map(([date, data]) => ({
        date,
        trades: data.trades.length,
        pnl: data.pnl,
        winRate: data.trades.length > 0 ? (data.winningTrades / data.trades.length) * 100 : 0,
        volume: data.volume
      }));

      setDailyStats(stats);
      setLastUpdate(new Date());
    } catch (error: any) {
      console.error('Error fetching calendar data:', error);
      toast({
        variant: "destructive",
        title: "Error loading calendar data",
        description: error.message,
      });
    } finally {
      setLoading(false);
    }
  };

  // Real-time subscription
  useEffect(() => {
    fetchCalendarData();

    if (!user) return;

    const channel = supabase
      .channel(`calendar-analytics-${user.id}`)
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'trades',
          filter: `user_id=eq.${user.id}`,
        },
        (payload) => {
          console.log('Real-time calendar update:', payload);
          fetchCalendarData();
          
          if (payload.eventType === 'INSERT') {
            toast({
              title: "📅 Calendar Updated",
              description: "Trading calendar refreshed with new data",
              duration: 2000,
            });
          }
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [user, selectedMonth, selectedYear]);

  // Fetch trades for a specific date
  const fetchTradesForDate = async (date: string) => {
    if (!user) return;

    try {
      setLoadingTrades(true);
      
      const startOfDay = new Date(date);
      const endOfDay = new Date(date);
      endOfDay.setHours(23, 59, 59, 999);

      const { data: trades, error } = await supabase
        .from('trades')
        .select('*')
        .eq('user_id', user.id)
        .gte('opened_at', startOfDay.toISOString())
        .lte('opened_at', endOfDay.toISOString())
        .order('opened_at', { ascending: true });

      if (error) throw error;

      setDailyTrades(trades || []);
      setSelectedDate(date);
      setShowTradesDialog(true);
    } catch (error: any) {
      console.error('Error fetching trades for date:', error);
      toast({
        variant: "destructive",
        title: "Error loading trades",
        description: error.message,
      });
    } finally {
      setLoadingTrades(false);
    }
  };

  // Handle trade detail view
  const handleTradeClick = (trade: Trade) => {
    setSelectedTrade(trade);
    setPreTradeNotes(trade.notes_pre || '');
    setPostTradeNotes(trade.notes_post || '');
    setEditingNotes(false);
    setShowTradeDetail(true);
  };

  // Save trade notes
  const saveTradeNotes = async () => {
    if (!selectedTrade || !user) return;

    try {
      const { error } = await supabase
        .from('trades')
        .update({
          notes_pre: preTradeNotes || null,
          notes_post: postTradeNotes || null
        })
        .eq('id', selectedTrade.id)
        .eq('user_id', user.id);

      if (error) throw error;

      // Update local state
      setSelectedTrade({
        ...selectedTrade,
        notes_pre: preTradeNotes,
        notes_post: postTradeNotes
      });

      // Update trades list
      setDailyTrades(prev => prev.map(trade => 
        trade.id === selectedTrade.id 
          ? { ...trade, notes_pre: preTradeNotes, notes_post: postTradeNotes }
          : trade
      ));

      setEditingNotes(false);
      
      toast({
        title: "📝 Notes Saved",
        description: "Trade notes updated successfully",
      });
    } catch (error: any) {
      console.error('Error saving trade notes:', error);
      toast({
        variant: "destructive",
        title: "Error saving notes",
        description: error.message,
      });
    }
  };

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 2
    }).format(value);
  };

  const getDayColor = (pnl: number, trades: number) => {
    if (trades === 0) return 'bg-muted/20';
    if (pnl > 500) return 'bg-success/80';
    if (pnl > 0) return 'bg-success/40';
    if (pnl > -500) return 'bg-danger/40';
    return 'bg-danger/80';
  };

  const getDaysInMonth = (month: number, year: number) => {
    return new Date(year, month + 1, 0).getDate();
  };

  const getFirstDayOfMonth = (month: number, year: number) => {
    return new Date(year, month, 1).getDay();
  };

  const renderCalendar = () => {
    const daysInMonth = getDaysInMonth(selectedMonth, selectedYear);
    const firstDay = getFirstDayOfMonth(selectedMonth, selectedYear);
    const days = [];

    // Add empty cells for days before the first day of the month
    for (let i = 0; i < firstDay; i++) {
      days.push(<div key={`empty-${i}`} className="h-20 border border-muted/20"></div>);
    }

    // Add cells for each day of the month
    for (let day = 1; day <= daysInMonth; day++) {
      const date = new Date(selectedYear, selectedMonth, day).toISOString().split('T')[0];
      const dayStats = dailyStats.find(stat => stat.date === date);

      days.push(
        <div
          key={day}
          className={`h-20 border border-muted/20 p-1 hover:bg-muted/30 transition-colors cursor-pointer ${
            dayStats ? getDayColor(dayStats.pnl, dayStats.trades) : 'bg-muted/10 hover:bg-muted/20'
          }`}
          onClick={() => dayStats && dayStats.trades > 0 && fetchTradesForDate(date)}
          title={dayStats && dayStats.trades > 0 ? `Click to view ${dayStats.trades} trades` : undefined}
        >
          <div className="text-xs font-medium mb-1">{day}</div>
          {dayStats && (
            <div className="space-y-0.5">
              <div className="text-xs font-bold text-white">
                {dayStats.trades} trades
              </div>
              <div className="text-xs text-white/90">
                {formatCurrency(dayStats.pnl)}
              </div>
              <div className="text-xs text-white/80">
                {dayStats.winRate.toFixed(0)}% win
              </div>
            </div>
          )}
        </div>
      );
    }

    return days;
  };

  const monthNames = [
    'January', 'February', 'March', 'April', 'May', 'June',
    'July', 'August', 'September', 'October', 'November', 'December'
  ];

  if (loading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <CalendarIcon className="h-5 w-5" />
            Trading Calendar
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="h-96 animate-pulse bg-muted rounded"></div>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="flex items-center gap-2">
              <CalendarIcon className="h-5 w-5 text-primary" />
              Real-Time Trading Calendar
              <Badge variant="outline" className="ml-2 text-xs">
                <Wifi className="w-3 h-3 mr-1" />
                Live
              </Badge>
            </CardTitle>
            <div className="flex items-center gap-4">
              <div className="flex items-center gap-2">
                <select
                  value={selectedMonth}
                  onChange={(e) => setSelectedMonth(parseInt(e.target.value))}
                  className="text-sm border rounded px-2 py-1"
                >
                  {monthNames.map((month, index) => (
                    <option key={index} value={index}>{month}</option>
                  ))}
                </select>
                <select
                  value={selectedYear}
                  onChange={(e) => setSelectedYear(parseInt(e.target.value))}
                  className="text-sm border rounded px-2 py-1"
                >
                  {Array.from({ length: 5 }, (_, i) => new Date().getFullYear() - 2 + i).map(year => (
                    <option key={year} value={year}>{year}</option>
                  ))}
                </select>
              </div>
              <div className="text-xs text-muted-foreground flex items-center gap-1">
                <Clock className="w-3 h-3" />
                {lastUpdate.toLocaleTimeString()}
              </div>
            </div>
          </div>
          <p className="text-sm text-muted-foreground">
            Daily trading performance calendar - updates automatically
          </p>
        </CardHeader>
        <CardContent>
          {/* Calendar Legend */}
          <div className="mb-4 flex flex-wrap gap-4 text-xs">
            <div className="flex items-center gap-2">
              <div className="w-4 h-4 bg-success/80 rounded"></div>
              <span>High Profit (&gt; $500)</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-4 h-4 bg-success/40 rounded"></div>
              <span>Profit</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-4 h-4 bg-danger/40 rounded"></div>
              <span>Loss</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-4 h-4 bg-danger/80 rounded"></div>
              <span>High Loss (&lt; -$500)</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-4 h-4 bg-muted/20 rounded border"></div>
              <span>No Trades</span>
            </div>
          </div>

          {/* Calendar Grid */}
          <div className="grid grid-cols-7 gap-0 border border-muted/20 rounded-lg overflow-hidden">
            {/* Day headers */}
            <div className="bg-muted/20 p-2 text-center text-sm font-medium">Sun</div>
            <div className="bg-muted/20 p-2 text-center text-sm font-medium">Mon</div>
            <div className="bg-muted/20 p-2 text-center text-sm font-medium">Tue</div>
            <div className="bg-muted/20 p-2 text-center text-sm font-medium">Wed</div>
            <div className="bg-muted/20 p-2 text-center text-sm font-medium">Thu</div>
            <div className="bg-muted/20 p-2 text-center text-sm font-medium">Fri</div>
            <div className="bg-muted/20 p-2 text-center text-sm font-medium">Sat</div>
            
            {/* Calendar days */}
            {renderCalendar()}
          </div>

          {/* Monthly Summary */}
          <div className="mt-6 p-4 bg-primary/5 rounded-lg border border-primary/10">
            <h4 className="font-semibold text-primary mb-3 flex items-center gap-2">
              <TrendingUp className="h-4 w-4" />
              {monthNames[selectedMonth]} {selectedYear} Summary
            </h4>
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4 text-sm">
              <div>
                <p className="text-muted-foreground">Total Trades:</p>
                <p className="font-medium text-lg">
                  {dailyStats.reduce((sum, day) => sum + day.trades, 0)}
                </p>
              </div>
              <div>
                <p className="text-muted-foreground">Monthly P&L:</p>
                <p className={`font-medium text-lg ${
                  dailyStats.reduce((sum, day) => sum + day.pnl, 0) >= 0 ? 'text-success' : 'text-danger'
                }`}>
                  {formatCurrency(dailyStats.reduce((sum, day) => sum + day.pnl, 0))}
                </p>
              </div>
              <div>
                <p className="text-muted-foreground">Trading Days:</p>
                <p className="font-medium text-lg">
                  {dailyStats.filter(day => day.trades > 0).length}
                </p>
              </div>
              <div>
                <p className="text-muted-foreground">Avg Daily P&L:</p>
                <p className="font-medium text-lg">
                  {dailyStats.length > 0 
                    ? formatCurrency(dailyStats.reduce((sum, day) => sum + day.pnl, 0) / dailyStats.filter(day => day.trades > 0).length || 0)
                    : '$0.00'
                  }
                </p>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Daily Trades Dialog */}
      <Dialog open={showTradesDialog} onOpenChange={setShowTradesDialog}>
        <DialogContent className="max-w-4xl max-h-[80vh] overflow-auto">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <CalendarIcon className="h-5 w-5" />
              Trades for {selectedDate ? new Date(selectedDate).toLocaleDateString('en-US', { 
                weekday: 'long', 
                year: 'numeric', 
                month: 'long', 
                day: 'numeric' 
              }) : ''}
              <Badge variant="outline">{dailyTrades.length} trades</Badge>
            </DialogTitle>
          </DialogHeader>
          
          {loadingTrades ? (
            <div className="flex items-center justify-center py-8">
              <Activity className="h-6 w-6 animate-spin mr-2" />
              Loading trades...
            </div>
          ) : (
            <div className="space-y-4">
              {dailyTrades.length > 0 ? (
                <div className="grid gap-3">
                  {dailyTrades.map((trade) => (
                    <Card 
                      key={trade.id} 
                      className="cursor-pointer hover:bg-muted/50 transition-colors"
                      onClick={() => handleTradeClick(trade)}
                    >
                      <CardContent className="p-4">
                        <div className="flex items-center justify-between">
                          <div className="space-y-1">
                            <div className="flex items-center gap-2">
                              <span className="font-semibold">{trade.instrument}</span>
                              <Badge variant={trade.side === 'long' ? 'default' : 'secondary'}>
                                {trade.side.toUpperCase()}
                              </Badge>
                              <Badge variant={trade.result === 'win' ? 'default' : 'destructive'}>
                                {trade.result?.toUpperCase() || 'OPEN'}
                              </Badge>
                            </div>
                            <div className="text-sm text-muted-foreground">
                              Entry: {trade.entry_price} → Exit: {trade.exit_price || 'Open'}
                            </div>
                            <div className="text-sm text-muted-foreground">
                              Size: {trade.size} • Time: {new Date(trade.opened_at).toLocaleTimeString()}
                            </div>
                          </div>
                          <div className="text-right space-y-1">
                            <div className={`text-lg font-bold ${
                              trade.pnl >= 0 ? 'text-success' : 'text-danger'
                            }`}>
                              {formatCurrency(trade.pnl)}
                            </div>
                            <Button variant="ghost" size="sm" className="gap-1">
                              <Eye className="h-3 w-3" />
                              View Details
                            </Button>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              ) : (
                <div className="text-center py-8 text-muted-foreground">
                  <CalendarIcon className="h-12 w-12 mx-auto mb-2 opacity-50" />
                  <p>No trades found for this date</p>
                </div>
              )}
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* Trade Detail Dialog */}
      <Dialog open={showTradeDetail} onOpenChange={setShowTradeDetail}>
        <DialogContent className="max-w-2xl max-h-[80vh] overflow-auto">
          <DialogHeader>
            <DialogTitle className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                Trade Details - {selectedTrade?.instrument}
                <Badge variant={selectedTrade?.result === 'win' ? 'default' : 'destructive'}>
                  {selectedTrade?.result?.toUpperCase() || 'OPEN'}
                </Badge>
              </div>
              <div className="flex items-center gap-2">
                {!editingNotes ? (
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setEditingNotes(true)}
                    className="gap-1"
                  >
                    <Edit3 className="h-3 w-3" />
                    Edit Notes
                  </Button>
                ) : (
                  <div className="flex gap-1">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={saveTradeNotes}
                      className="gap-1"
                    >
                      <Save className="h-3 w-3" />
                      Save
                    </Button>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => {
                        setEditingNotes(false);
                        setPreTradeNotes(selectedTrade?.notes_pre || '');
                        setPostTradeNotes(selectedTrade?.notes_post || '');
                      }}
                      className="gap-1"
                    >
                      <X className="h-3 w-3" />
                      Cancel
                    </Button>
                  </div>
                )}
              </div>
            </DialogTitle>
          </DialogHeader>

          {selectedTrade && (
            <div className="space-y-6">
              {/* Trade Summary */}
              <div className="grid grid-cols-2 gap-4">
                <Card className="p-4">
                  <h4 className="font-semibold mb-2">Trade Information</h4>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Instrument:</span>
                      <span className="font-medium">{selectedTrade.instrument}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Direction:</span>
                      <Badge variant={selectedTrade.side === 'long' ? 'default' : 'secondary'}>
                        {selectedTrade.side.toUpperCase()}
                      </Badge>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Size:</span>
                      <span className="font-medium">{selectedTrade.size}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Entry Price:</span>
                      <span className="font-medium">{selectedTrade.entry_price}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Exit Price:</span>
                      <span className="font-medium">{selectedTrade.exit_price || 'Open'}</span>
                    </div>
                  </div>
                </Card>

                <Card className="p-4">
                  <h4 className="font-semibold mb-2">Performance</h4>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">P&L:</span>
                      <span className={`font-bold ${selectedTrade.pnl >= 0 ? 'text-success' : 'text-danger'}`}>
                        {formatCurrency(selectedTrade.pnl)}
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Result:</span>
                      <Badge variant={selectedTrade.result === 'win' ? 'default' : 'destructive'}>
                        {selectedTrade.result?.toUpperCase() || 'OPEN'}
                      </Badge>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Opened:</span>
                      <span className="font-medium">
                        {new Date(selectedTrade.opened_at).toLocaleString()}
                      </span>
                    </div>
                    {selectedTrade.closed_at && (
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">Closed:</span>
                        <span className="font-medium">
                          {new Date(selectedTrade.closed_at).toLocaleString()}
                        </span>
                      </div>
                    )}
                  </div>
                </Card>
              </div>

              {/* Notes Section */}
              <div className="space-y-4">
                <div>
                  <Label className="text-sm font-medium">Pre-Trade Notes</Label>
                  {editingNotes ? (
                    <Textarea
                      value={preTradeNotes}
                      onChange={(e) => setPreTradeNotes(e.target.value)}
                      placeholder="Add your pre-trade analysis, entry reasons, and setup notes..."
                      className="mt-2"
                      rows={3}
                    />
                  ) : (
                    <div className="mt-2 p-3 bg-muted/20 rounded-lg border min-h-[60px]">
                      {selectedTrade.notes_pre || (
                        <span className="text-muted-foreground italic">
                          No pre-trade notes. Click "Edit Notes" to add your analysis.
                        </span>
                      )}
                    </div>
                  )}
                </div>

                <div>
                  <Label className="text-sm font-medium">Post-Trade Notes</Label>
                  {editingNotes ? (
                    <Textarea
                      value={postTradeNotes}
                      onChange={(e) => setPostTradeNotes(e.target.value)}
                      placeholder="Add your post-trade review, lessons learned, and improvement notes..."
                      className="mt-2"
                      rows={3}
                    />
                  ) : (
                    <div className="mt-2 p-3 bg-muted/20 rounded-lg border min-h-[60px]">
                      {selectedTrade.notes_post || (
                        <span className="text-muted-foreground italic">
                          No post-trade notes. Click "Edit Notes" to add your review.
                        </span>
                      )}
                    </div>
                  )}
                </div>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}