import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { useAuth } from "@/hooks/useAuth"
import { resetOnboardingForUser, isOnboardingCompleted } from "@/utils/onboardingUtils"
import { useToast } from "@/hooks/use-toast"
import { RotateCcw, HelpCircle, CheckCircle } from "lucide-react"
import { Badge } from "@/components/ui/badge"

export const OnboardingSettings = () => {
  const { user } = useAuth()
  const { toast } = useToast()

  const isCompleted = user?.id ? isOnboardingCompleted(user.id) : false

  const handleRestartTour = () => {
    if (user?.id) {
      resetOnboardingForUser(user.id)
      toast({
        title: "Tour Reset! 🎯",
        description: "Navigate to your dashboard to see the onboarding tour again.",
        duration: 3000,
      })
      // Redirect to dashboard to trigger tour
      setTimeout(() => {
        window.location.href = '/app'
      }, 1000)
    }
  }

  if (!user) return null

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <HelpCircle className="w-5 h-5 text-primary" />
          Help & Guidance
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Onboarding Status */}
        <div className="flex items-center justify-between">
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <p className="font-medium">Onboarding Tour</p>
              {isCompleted ? (
                <Badge variant="secondary" className="text-xs">
                  <CheckCircle className="w-3 h-3 mr-1" />
                  Completed
                </Badge>
              ) : (
                <Badge variant="outline" className="text-xs">
                  Not Completed
                </Badge>
              )}
            </div>
            <p className="text-sm text-muted-foreground">
              {isCompleted 
                ? "You've completed the onboarding tour. You can retake it anytime."
                : "Take the guided tour to learn about dashboard features."
              }
            </p>
          </div>
          <Button 
            variant="outline" 
            onClick={handleRestartTour}
            className="flex items-center gap-2"
          >
            <RotateCcw className="w-4 h-4" />
            {isCompleted ? "Restart Tour" : "Take Tour"}
          </Button>
        </div>

        {/* Help Information */}
        <div className="border-t pt-4">
          <p className="text-sm font-medium mb-2">Tour Features:</p>
          <ul className="text-sm text-muted-foreground space-y-1">
            <li>• Navigation sidebar overview</li>
            <li>• Quick actions walkthrough</li>
            <li>• Key features introduction</li>
          </ul>
        </div>
      </CardContent>
    </Card>
  )
}