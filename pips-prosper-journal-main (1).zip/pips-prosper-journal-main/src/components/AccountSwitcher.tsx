import { useState, useEffect } from "react";
import { Check, ChevronDown, Plus } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { toast } from "@/hooks/use-toast";

export interface Account {
  id: string;
  nickname: string;
  broker_name: string;
  account_type: string;
  balance: number;
  currency: string;
  is_active: boolean;
}

interface AccountSwitcherProps {
  selectedAccountId: string | null;
  onAccountChange: (accountId: string | null) => void;
  showAddAccount?: boolean;
  onAddAccount?: () => void;
}

export function AccountSwitcher({ 
  selectedAccountId, 
  onAccountChange, 
  showAddAccount = true,
  onAddAccount 
}: AccountSwitcherProps) {
  const { user } = useAuth();
  const [accounts, setAccounts] = useState<Account[]>([]);
  const [loading, setLoading] = useState(true);

  const fetchAccounts = async () => {
    if (!user) return;

    try {
      const { data, error } = await supabase
        .from("accounts")
        .select("*")
        .eq("user_id", user.id)
        .eq("is_active", true)
        .order("created_at", { ascending: true });

      if (error) throw error;
      setAccounts(data || []);

      // Set default to "All Accounts" if no selection
      if (!selectedAccountId && data && data.length > 0) {
        onAccountChange(null); // null represents "All Accounts"
      }
    } catch (error) {
      console.error("Error fetching accounts:", error);
      toast({
        title: "Error",
        description: "Failed to load accounts",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchAccounts();

    // Set up real-time subscription
    const channel = supabase
      .channel("accounts-changes")
      .on(
        "postgres_changes",
        {
          event: "*",
          schema: "public",
          table: "accounts",
          filter: `user_id=eq.${user?.id}`,
        },
        () => {
          fetchAccounts();
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [user]);

  const selectedAccount = selectedAccountId 
    ? accounts.find(acc => acc.id === selectedAccountId)
    : null;

  const displayText = selectedAccount 
    ? selectedAccount.nickname 
    : "All Accounts";

  const displaySubtext = selectedAccount
    ? `${selectedAccount.broker_name} • ${selectedAccount.currency}`
    : `${accounts.length} account${accounts.length !== 1 ? 's' : ''}`;

  if (loading) {
    return (
      <div className="flex items-center space-x-2">
        <div className="h-8 w-32 bg-muted animate-pulse rounded" />
      </div>
    );
  }

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button variant="outline" className="w-auto min-w-[200px] justify-between bg-background">
          <div className="flex flex-col items-start">
            <span className="font-medium text-foreground">{displayText}</span>
            <span className="text-xs text-muted-foreground">{displaySubtext}</span>
          </div>
          <ChevronDown className="ml-2 h-4 w-4 shrink-0 opacity-50" />
        </Button>
      </DropdownMenuTrigger>
      
      <DropdownMenuContent className="w-56 bg-background border border-border shadow-lg">
        <DropdownMenuLabel className="text-foreground">Switch Account</DropdownMenuLabel>
        <DropdownMenuSeparator />
        
        {/* All Accounts Option */}
        <DropdownMenuItem
          className="flex items-center justify-between cursor-pointer hover:bg-muted"
          onClick={() => onAccountChange(null)}
        >
          <div className="flex flex-col">
            <span className="font-medium text-foreground">All Accounts</span>
            <span className="text-xs text-muted-foreground">
              Combined view of {accounts.length} account{accounts.length !== 1 ? 's' : ''}
            </span>
          </div>
          {!selectedAccountId && <Check className="h-4 w-4 text-primary" />}
        </DropdownMenuItem>
        
        <DropdownMenuSeparator />
        
        {/* Individual Accounts */}
        {accounts.map((account) => (
          <DropdownMenuItem
            key={account.id}
            className="flex items-center justify-between cursor-pointer hover:bg-muted"
            onClick={() => onAccountChange(account.id)}
          >
            <div className="flex flex-col">
              <span className="font-medium text-foreground">{account.nickname}</span>
              <span className="text-xs text-muted-foreground">
                {account.broker_name} • {account.currency} {account.balance.toLocaleString()}
              </span>
            </div>
            {selectedAccountId === account.id && <Check className="h-4 w-4 text-primary" />}
          </DropdownMenuItem>
        ))}
        
        {accounts.length === 0 && (
          <DropdownMenuItem disabled className="text-muted-foreground">
            No accounts found
          </DropdownMenuItem>
        )}
        
        {showAddAccount && (
          <>
            <DropdownMenuSeparator />
            <DropdownMenuItem
              className="flex items-center cursor-pointer hover:bg-muted text-primary"
              onClick={onAddAccount}
            >
              <Plus className="mr-2 h-4 w-4" />
              Add Account
            </DropdownMenuItem>
          </>
        )}
      </DropdownMenuContent>
    </DropdownMenu>
  );
}