import { Button } from "@/components/ui/button";
import { 
  BarChart3, 
  Brain, 
  FileBarChart, 
  Zap, 
  Shield, 
  TrendingUp,
  Target,
  Bot,
  Calendar
} from "lucide-react";
import { useNavigate } from "react-router-dom";
import { useToast } from "@/hooks/use-toast";

const features = [
  {
    icon: BarChart3,
    title: "Advanced Forex Analytics",
    description: "Real-time performance metrics, equity curves, drawdown analysis, and interactive forex trading charts with advanced filtering.",
    color: "text-primary"
  },
  {
    icon: Brain,
    title: "AI Trading Coach",
    description: "Get personalized insights and improvement suggestions based on your forex trading patterns and psychology analysis.",
    color: "text-success"
  },
  {
    icon: Target,
    title: "Prop Firm Journal Ready",
    description: "Track prop firm rules, daily progress, and get readiness scores with exportable PDF reports for prop trading challenges.",
    color: "text-warning"
  },
  {
    icon: FileBarChart,
    title: "MT4/MT5 Smart Imports",
    description: "Auto-import from MT4, MT5, cTrader, and broker platforms. TradingView webhooks for real-time trade sync.",
    color: "text-danger"
  },
  {
    icon: Calendar,
    title: "Forex Session Analysis", 
    description: "Identify your best performing forex sessions (London, New York, Tokyo) with detailed heatmap visualizations.",
    color: "text-primary-glow"
  },
  {
    icon: Shield,
    title: "Broker-Grade Security",
    description: "End-to-end encryption, 2FA, SOC 2 compliance, and secure data export capabilities for all broker accounts.",
    color: "text-secondary"
  },
  {
    icon: Zap,
    title: "Auto Trade Sync",
    description: "🚀 Coming Soon! Automatically sync trades from all major platforms including MT4, MT5, and prop firm accounts in real-time.",
    color: "text-success",
    comingSoon: true
  }
];

export const FeaturesSection = () => {
  const navigate = useNavigate();
  const { toast } = useToast();

  const handleStartFree = () => {
    navigate('/auth');
    toast({
      title: "Get Started FREE! 🚀",
      description: "Creating your free account with all features included",
      duration: 3000,
    });
  };

  const handleViewDemo = () => {
    navigate('/dashboard');
    toast({
      title: "Demo Dashboard",
      description: "Exploring live demo with sample data",
      duration: 3000,
    });
  };
  return (
    <section id="features" className="py-20 relative">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center mb-12 sm:mb-16 px-4 sm:px-0">
          <h2 className="text-2xl sm:text-3xl md:text-4xl lg:text-5xl font-poppins font-bold mb-4 sm:mb-6">
            Complete{" "}
            <span className="bg-gradient-primary bg-clip-text text-transparent">
              Trading Journal Features
            </span>
            {" "}100% FREE Forever
          </h2>
          <p className="text-lg sm:text-xl text-muted-foreground max-w-3xl mx-auto leading-relaxed">
            From MT4/MT5 imports to prop firm tracking and AI insights. 
            PipTrackr.com provides everything forex traders need to succeed.
            <span className="block mt-2 text-success font-semibold">
              All features completely FREE - No premium plans, no hidden costs!
            </span>
          </p>
        </div>

        {/* Features Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-8 mb-12 sm:mb-16 px-4 sm:px-0">
          {features.map((feature, index) => {
            const IconComponent = feature.icon;
            return (
              <div 
                key={index}
                className={`glass-card p-6 sm:p-8 hover:shadow-glow transition-all duration-300 group relative ${
                  feature.comingSoon ? 'border-success/30 bg-success/5' : ''
                }`}
              >
                {feature.comingSoon && (
                  <div className="absolute -top-2 -right-2 bg-success text-success-foreground text-xs px-3 py-1 rounded-full animate-pulse">
                    Coming Soon!
                  </div>
                )}
                <div className={`w-10 h-10 sm:w-12 sm:h-12 rounded-lg bg-gradient-glass flex items-center justify-center mb-4 sm:mb-6 group-hover:scale-110 transition-transform ${
                  feature.comingSoon ? 'animate-pulse' : ''
                }`}>
                  <IconComponent className={`w-5 h-5 sm:w-6 sm:h-6 ${feature.color}`} />
                </div>
                <h3 className="text-lg sm:text-xl font-poppins font-semibold mb-3 sm:mb-4 text-foreground">
                  {feature.title}
                </h3>
                <p className="text-sm sm:text-base text-muted-foreground leading-relaxed">
                  {feature.description}
                </p>
              </div>
            );
          })}
        </div>

        {/* CTA Section */}
        <div className="text-center px-4 sm:px-0">
          <div className="glass-card p-6 sm:p-8 max-w-2xl mx-auto">
            <h3 className="text-xl sm:text-2xl font-poppins font-bold mb-3 sm:mb-4">
              Ready to Transform Your Trading? 100% FREE!
            </h3>
            <p className="text-sm sm:text-base text-muted-foreground mb-4 sm:mb-6 leading-relaxed">
              Join thousands of traders who've improved their performance with data-driven insights.
              <span className="block mt-1 text-success font-semibold">
                No credit card required • All features FREE forever
              </span>
            </p>
            <div className="flex flex-col sm:flex-row gap-3 sm:gap-4 justify-center">
              <Button 
                variant="primary" 
                size="lg" 
                className="glow-hover w-full sm:w-auto relative"
                onClick={handleStartFree}
              >
                Start FREE Now
                <div className="absolute -top-2 -right-2 bg-success text-success-foreground text-xs px-2 py-1 rounded-full animate-pulse">
                  FREE
                </div>
              </Button>
              <Button 
                variant="outline" 
                size="lg" 
                className="w-full sm:w-auto"
                onClick={handleViewDemo}
              >
                View Live Demo
              </Button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};