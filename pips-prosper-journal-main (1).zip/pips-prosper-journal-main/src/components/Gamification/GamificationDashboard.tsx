import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Button } from "@/components/ui/button";
import { 
  Trophy, 
  Target, 
  Zap, 
  Calendar, 
  TrendingUp,
  Award,
  Star,
  Shield,
  Crown,
  Sparkles
} from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";

interface Badge {
  id: string;
  name: string;
  description: string;
  icon: React.ElementType;
  earned: boolean;
  earnedAt?: string;
  progress?: number;
  maxProgress?: number;
  color: string;
}

interface ConsistencyMetrics {
  score: number;
  tradingDays: number;
  consecutiveDays: number;
  ruleAdherence: number;
  riskManagement: number;
}

export function GamificationDashboard() {
  const [consistencyScore, setConsistencyScore] = useState(0);
  const [badges, setBadges] = useState<Badge[]>([]);
  const [metrics, setMetrics] = useState<ConsistencyMetrics>({
    score: 0,
    tradingDays: 0,
    consecutiveDays: 0,
    ruleAdherence: 0,
    riskManagement: 0,
  });
  const [loading, setLoading] = useState(true);
  const { user } = useAuth();
  const { toast } = useToast();

  const availableBadges: Badge[] = [
    {
      id: "no_fomo_week",
      name: "No-FOMO Week",
      description: "7 days without overtrading",
      icon: Shield,
      earned: false,
      color: "text-blue-500 bg-blue-500/10",
    },
    {
      id: "risk_master",
      name: "Risk Master", 
      description: "Keep risk under 2% for 20 trades",
      icon: Target,
      earned: false,
      progress: 0,
      maxProgress: 20,
      color: "text-green-500 bg-green-500/10",
    },
    {
      id: "prop_ready",
      name: "Prop-Ready",
      description: "Pass prop firm rules for 30 days",
      icon: Crown,
      earned: false,
      progress: 0,
      maxProgress: 30,
      color: "text-purple-500 bg-purple-500/10",
    },
    {
      id: "journal_streak_7",
      name: "Journal Warrior",
      description: "7-day journal streak",
      icon: Calendar,
      earned: false,
      progress: 0,
      maxProgress: 7,
      color: "text-orange-500 bg-orange-500/10",
    },
    {
      id: "consistent_trader",
      name: "Consistent Trader",
      description: "80+ consistency score",
      icon: TrendingUp,
      earned: false,
      color: "text-primary bg-primary/10",
    },
    {
      id: "profit_machine",
      name: "Profit Machine",
      description: "10 consecutive profitable days",
      icon: Sparkles,
      earned: false,
      progress: 0,
      maxProgress: 10,
      color: "text-yellow-500 bg-yellow-500/10",
    },
  ];

  useEffect(() => {
    if (user) {
      loadGamificationData();
    }
  }, [user]);

  const loadGamificationData = async () => {
    try {
      setLoading(true);
      
      // Get consistency score
      const { data: consistencyData } = await supabase
        .from('consistency_scores')
        .select('*')
        .eq('user_id', user!.id)
        .single();

      if (consistencyData) {
        setConsistencyScore(consistencyData.score);
        setMetrics({
          score: consistencyData.score,
          tradingDays: consistencyData.trading_days,
          consecutiveDays: consistencyData.consecutive_days,
          ruleAdherence: Math.min(100, consistencyData.score + 10), // Mock calculation
          riskManagement: Math.min(100, consistencyData.score - 5), // Mock calculation
        });
      }

      // Get earned badges
      const { data: earnedBadges } = await supabase
        .from('user_badges')
        .select('*')
        .eq('user_id', user!.id);

      // Calculate badge progress and update badges
      const updatedBadges = await Promise.all(
        availableBadges.map(async (badge) => {
          const earned = earnedBadges?.some(b => b.badge_name === badge.name);
          const earnedBadge = earnedBadges?.find(b => b.badge_name === badge.name);
          
          let progress = 0;
          if (!earned && badge.maxProgress) {
            progress = await calculateBadgeProgress(badge.id);
          }

          return {
            ...badge,
            earned,
            earnedAt: earnedBadge?.earned_at,
            progress: earned ? badge.maxProgress : progress,
          };
        })
      );

      setBadges(updatedBadges);

      // Check for new badge unlocks
      await checkBadgeUnlocks();

    } catch (error) {
      console.error('Error loading gamification data:', error);
    } finally {
      setLoading(false);
    }
  };

  const calculateBadgeProgress = async (badgeId: string): Promise<number> => {
    const now = new Date();
    const sevenDaysAgo = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);
    const thirtyDaysAgo = new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000);

    try {
      switch (badgeId) {
        case "risk_master": {
          const { data: trades } = await supabase
            .from('trades')
            .select('risk_percent')
            .eq('user_id', user!.id)
            .not('risk_percent', 'is', null)
            .order('created_at', { ascending: false })
            .limit(20);
          
          return trades?.filter(t => t.risk_percent! <= 2).length || 0;
        }
        
        case "prop_ready": {
          const { data: dailyResults } = await supabase
            .from('challenge_daily_results')
            .select('passed')
            .eq('user_id', user!.id)
            .gte('date', thirtyDaysAgo.toISOString().split('T')[0]);
          
          return dailyResults?.filter(r => r.passed).length || 0;
        }
        
        case "journal_streak_7": {
          const { data: entries } = await supabase
            .from('psychology_entries')
            .select('created_at')
            .eq('user_id', user!.id)
            .gte('created_at', sevenDaysAgo.toISOString())
            .order('created_at', { ascending: false });
          
          // Calculate consecutive days
          let streak = 0;
          const dates = entries?.map(e => new Date(e.created_at).toDateString()) || [];
          const uniqueDates = [...new Set(dates)];
          
          for (let i = 0; i < 7; i++) {
            const checkDate = new Date(now.getTime() - i * 24 * 60 * 60 * 1000);
            if (uniqueDates.includes(checkDate.toDateString())) {
              streak++;
            } else {
              break;
            }
          }
          
          return streak;
        }
        
        case "profit_machine": {
          // Mock calculation for profitable days
          return Math.floor(Math.random() * 8);
        }
        
        default:
          return 0;
      }
    } catch (error) {
      console.error('Error calculating badge progress:', error);
      return 0;
    }
  };

  const checkBadgeUnlocks = async () => {
    for (const badge of badges) {
      if (!badge.earned && badge.progress === badge.maxProgress) {
        await unlockBadge(badge);
      }
      
      // Special checks for badges without progress tracking
      if (badge.id === "no_fomo_week" && !badge.earned) {
        // Check if user had reasonable trade volume in past week
        const sevenDaysAgo = new Date();
        sevenDaysAgo.setDate(sevenDaysAgo.getDate() - 7);
        
        const { data: weekTrades } = await supabase
          .from('trades')
          .select('id')
          .eq('user_id', user!.id)
          .gte('created_at', sevenDaysAgo.toISOString());
        
        if (weekTrades && weekTrades.length <= 5 && weekTrades.length >= 3) {
          await unlockBadge(badge);
        }
      }
      
      if (badge.id === "consistent_trader" && !badge.earned && consistencyScore >= 80) {
        await unlockBadge(badge);
      }
    }
  };

  const unlockBadge = async (badge: Badge) => {
    try {
      const { error } = await supabase.from('user_badges').insert({
        user_id: user!.id,
        badge_name: badge.name,
        badge_description: badge.description,
        badge_type: badge.id,
        metadata: { unlockedAt: new Date().toISOString() },
      });

      if (!error) {
        toast({
          title: "🎉 Badge Unlocked!",
          description: `You earned the "${badge.name}" badge!`,
        });
        
        // Confetti effect (simplified)
        const confetti = document.createElement('div');
        confetti.innerHTML = '🎊';
        confetti.style.position = 'fixed';
        confetti.style.top = '20%';
        confetti.style.left = '50%';
        confetti.style.fontSize = '2rem';
        confetti.style.zIndex = '9999';
        confetti.style.animation = 'bounce 1s ease-out';
        document.body.appendChild(confetti);
        
        setTimeout(() => document.body.removeChild(confetti), 1000);
        
        // Reload data to show new badge
        loadGamificationData();
      }
    } catch (error) {
      console.error('Error unlocking badge:', error);
    }
  };

  if (loading) {
    return (
      <div className="space-y-6">
        <div className="h-32 bg-muted rounded-lg animate-pulse" />
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {[1, 2, 3].map(i => (
            <div key={i} className="h-24 bg-muted rounded-lg animate-pulse" />
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Consistency Score Overview */}
      <Card className="glass-card">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Trophy className="h-5 w-5 text-primary" />
            Consistency Score
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <div className="space-y-4">
              <div className="text-center">
                <div className="text-4xl font-bold text-primary mb-2">
                  {consistencyScore}/100
                </div>
                <Progress value={consistencyScore} className="mb-2" />
                <p className="text-sm text-muted-foreground">
                  Based on rule adherence, risk management, and consistency
                </p>
              </div>
            </div>
            
            <div className="space-y-3">
              <div className="flex justify-between">
                <span className="text-sm">Trading Days</span>
                <span className="font-medium">{metrics.tradingDays}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-sm">Consecutive Days</span>
                <span className="font-medium">{metrics.consecutiveDays}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-sm">Rule Adherence</span>
                <span className="font-medium">{metrics.ruleAdherence}%</span>
              </div>
              <div className="flex justify-between">
                <span className="text-sm">Risk Management</span>
                <span className="font-medium">{metrics.riskManagement}%</span>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Badges Grid */}
      <Card className="glass-card">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Award className="h-5 w-5 text-primary" />
            Trading Achievements
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {badges.map((badge) => {
              const IconComponent = badge.icon;
              return (
                <div
                  key={badge.id}
                  className={`p-4 rounded-lg border transition-all ${
                    badge.earned
                      ? 'border-primary bg-primary/5'
                      : 'border-border bg-card'
                  }`}
                >
                  <div className="flex items-start gap-3">
                    <div className={`p-2 rounded-lg ${badge.color}`}>
                      <IconComponent className="h-4 w-4" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 mb-1">
                        <h3 className="font-medium truncate">{badge.name}</h3>
                        {badge.earned && (
                          <Badge variant="secondary" className="text-xs">
                            Earned
                          </Badge>
                        )}
                      </div>
                      <p className="text-xs text-muted-foreground mb-2">
                        {badge.description}
                      </p>
                      
                      {badge.maxProgress && (
                        <div className="space-y-1">
                          <div className="flex justify-between text-xs">
                            <span>Progress</span>
                            <span>
                              {badge.progress}/{badge.maxProgress}
                            </span>
                          </div>
                          <Progress 
                            value={(badge.progress! / badge.maxProgress) * 100} 
                            className="h-2"
                          />
                        </div>
                      )}
                      
                      {badge.earned && badge.earnedAt && (
                        <p className="text-xs text-muted-foreground mt-2">
                          Earned {new Date(badge.earnedAt).toLocaleDateString()}
                        </p>
                      )}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </CardContent>
      </Card>

      {/* Actions */}
      <Card className="glass-card">
        <CardContent className="pt-6">
          <div className="flex justify-center">
            <Button onClick={loadGamificationData} variant="outline">
              <Zap className="h-4 w-4 mr-2" />
              Refresh Achievements
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}