import { Twitter, Github, Linkedin, Mail } from "lucide-react";
import { Link } from "react-router-dom";
import { useLogoSettings } from "@/hooks/useLogoSettings";

const footerLinks = {
  product: [
    { name: "Features", href: "/#features" },
    { name: "Pricing", href: "/#pricing" },
    { name: "Integrations", href: "/#integrations" },
    { name: "Dashboard", href: "/dashboard" },
    { name: "Subscription", href: "/subscription" }
  ],
  company: [
    { name: "About", href: "/about" },
    { name: "Security", href: "/security" },
    { name: "Contact", href: "/contact" },
    { name: "Support", href: "/support" },
    { name: "Blog", href: "/blog" },
    { name: "Affiliate Program", href: "/affiliates" }
  ],
  legal: [
    { name: "Terms of Service", href: "/terms" },
    { name: "Privacy Policy", href: "/privacy" },
    { name: "Cookie Policy", href: "/cookies" },
    { name: "Disclaimer", href: "/disclaimer" }
  ]
};

export const Footer = () => {
  const { getMainLogo } = useLogoSettings();
  const mainLogo = getMainLogo();
  return (
    <footer className="bg-secondary text-secondary-foreground">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        {/* Main Footer Content */}
        <div className="py-12 sm:py-16">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-6 sm:gap-8 px-4 sm:px-0">
            {/* Brand Section */}
            <div className="lg:col-span-2 text-center sm:text-left">
              <div className="flex items-center justify-center sm:justify-start mb-4 sm:mb-6 gap-3">
                {mainLogo ? (
                  <img 
                    src={mainLogo.logo_url} 
                    alt={mainLogo.logo_alt} 
                    className="h-8 w-auto"
                    style={{
                      maxWidth: mainLogo.width ? `${mainLogo.width}px` : 'auto',
                      maxHeight: mainLogo.height ? `${mainLogo.height}px` : '32px'
                    }}
                  />
                ) : (
                  <img 
                    src="/lovable-uploads/6c66d095-1b1a-4b06-860b-9f973847053f.png" 
                    alt="PipTrackr.com Logo" 
                    className="h-8 w-auto"
                  />
                )}
                <span className="text-lg sm:text-xl font-poppins font-semibold text-secondary-foreground">
                  PipTrackr.com
                </span>
              </div>
              <p className="text-sm sm:text-base text-secondary-foreground/70 mb-4 sm:mb-6 leading-relaxed">
                The complete trading journal platform trusted by thousands of traders 
                worldwide. Transform your trading performance with data-driven insights.
              </p>
              <div className="flex justify-center sm:justify-start space-x-4">
                <a 
                  href="https://twitter.com/piptrakr" 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="text-secondary-foreground/50 hover:text-secondary-foreground transition-colors"
                >
                  <Twitter className="w-4 h-4 sm:w-5 sm:h-5" />
                </a>
                <a 
                  href="https://github.com/piptrakr" 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="text-secondary-foreground/50 hover:text-secondary-foreground transition-colors"
                >
                  <Github className="w-4 h-4 sm:w-5 sm:h-5" />
                </a>
                <a 
                  href="https://linkedin.com/company/piptrakr" 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="text-secondary-foreground/50 hover:text-secondary-foreground transition-colors"
                >
                  <Linkedin className="w-4 h-4 sm:w-5 sm:h-5" />
                </a>
                <Link 
                  to="/contact" 
                  className="text-secondary-foreground/50 hover:text-secondary-foreground transition-colors"
                >
                  <Mail className="w-4 h-4 sm:w-5 sm:h-5" />
                </Link>
              </div>
            </div>

            {/* Product Links */}
            <div className="text-center sm:text-left">
              <h3 className="text-base sm:text-lg font-poppins font-semibold mb-3 sm:mb-4">Product</h3>
              <ul className="space-y-2 sm:space-y-3">
                {footerLinks.product.map((link, index) => (
                  <li key={index}>
                    {link.href.startsWith('/#') ? (
                      <a 
                        href={link.href}
                        className="text-sm sm:text-base text-secondary-foreground/70 hover:text-secondary-foreground transition-colors"
                      >
                        {link.name}
                      </a>
                    ) : (
                      <Link 
                        to={link.href}
                        className="text-sm sm:text-base text-secondary-foreground/70 hover:text-secondary-foreground transition-colors"
                      >
                        {link.name}
                      </Link>
                    )}
                  </li>
                ))}
              </ul>
            </div>

            {/* Company Links */}
            <div className="text-center sm:text-left">
              <h3 className="text-base sm:text-lg font-poppins font-semibold mb-3 sm:mb-4">Company</h3>
              <ul className="space-y-2 sm:space-y-3">
                {footerLinks.company.map((link, index) => (
                  <li key={index}>
                    <Link 
                      to={link.href}
                      className="text-sm sm:text-base text-secondary-foreground/70 hover:text-secondary-foreground transition-colors"
                    >
                      {link.name}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>

            {/* Legal Links */}
            <div className="text-center sm:text-left">
              <h3 className="text-base sm:text-lg font-poppins font-semibold mb-3 sm:mb-4">Legal</h3>
              <ul className="space-y-2 sm:space-y-3">
                {footerLinks.legal.map((link, index) => (
                  <li key={index}>
                    <Link 
                      to={link.href}
                      className="text-sm sm:text-base text-secondary-foreground/70 hover:text-secondary-foreground transition-colors"
                    >
                      {link.name}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="border-t border-secondary-foreground/20 py-6 sm:py-8 px-4 sm:px-0">
          <div className="flex flex-col md:flex-row items-center justify-between gap-4">
            <p className="text-secondary-foreground/50 text-xs sm:text-sm text-center md:text-left">
              © 2024 PipTrackr.com. All rights reserved.
            </p>
            <div className="flex flex-col sm:flex-row items-center gap-3 sm:gap-4 lg:gap-6 text-xs sm:text-sm text-secondary-foreground/50">
              <span>🔒 Bank-Grade Security</span>
              <span>📊 Real-time Analytics</span>
              <span>🤖 AI-Powered Insights</span>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
};