import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import { 
  Key, 
  Copy, 
  Eye, 
  EyeOff, 
  Plus, 
  Trash2,
  Zap,
  Code,
  AlertCircle,
  CheckCircle
} from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";

interface WebhookKey {
  id: string;
  user_id: string;
  name: string;
  secret_masked: string;
  secret: string;
  active: boolean;
  created_at: string;
}

export function TradingViewWebhook() {
  const [webhookKeys, setWebhookKeys] = useState<WebhookKey[]>([]);
  const [webhookName, setWebhookName] = useState("");
  const [generatedKey, setGeneratedKey] = useState("");
  const [webhookUrl, setWebhookUrl] = useState("");
  const [generating, setGenerating] = useState(false);
  const [loading, setLoading] = useState(true);
  const [visibleSecrets, setVisibleSecrets] = useState<Set<string>>(new Set());
  const { user } = useAuth();
  const { toast } = useToast();

  useEffect(() => {
    if (user) {
      loadWebhookKeys();
    }
  }, [user]);

  const loadWebhookKeys = async () => {
    try {
      setLoading(true);
      const { data, error } = await supabase.rpc('get_webhook_keys_safe');
      
      if (error) {
        throw error;
      }
      
      setWebhookKeys(data || []);
    } catch (error) {
      console.error('Error loading webhook keys:', error);
      toast({
        title: "Error loading webhook keys",
        description: "Please try again",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const generateWebhookKey = async () => {
    if (!webhookName.trim()) {
      toast({
        title: "Name required",
        description: "Please enter a name for your webhook",
        variant: "destructive",
      });
      return;
    }

    try {
      setGenerating(true);
      
      // Generate a secure random key
      const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
      let key = '';
      for (let i = 0; i < 64; i++) {
        key += chars.charAt(Math.floor(Math.random() * chars.length));
      }

      const { error } = await supabase.from('webhook_keys').insert({
        user_id: user!.id,
        name: webhookName,
        secret: key,
        active: true,
      });

      if (error) throw error;

      setGeneratedKey(key);
      setWebhookUrl(`https://pwpxzlcpdbqjckvmkwlw.supabase.co/functions/v1/trading-webhook?key=${key}`);
      setWebhookName("");
      
      toast({
        title: "Webhook key generated",
        description: "Your webhook is ready to use with TradingView",
      });

      await loadWebhookKeys();
    } catch (error) {
      console.error('Error generating webhook key:', error);
      toast({
        title: "Error generating webhook",
        description: "Please try again",
        variant: "destructive",
      });
    } finally {
      setGenerating(false);
    }
  };

  const deleteWebhookKey = async (keyId: string) => {
    try {
      const { error } = await supabase
        .from('webhook_keys')
        .delete()
        .eq('id', keyId);

      if (error) throw error;

      toast({
        title: "Webhook deleted",
        description: "The webhook key has been removed",
      });

      await loadWebhookKeys();
    } catch (error) {
      console.error('Error deleting webhook key:', error);
      toast({
        title: "Error deleting webhook",
        description: "Please try again",
        variant: "destructive",
      });
    }
  };

  const toggleSecretVisibility = (keyId: string) => {
    setVisibleSecrets(prev => {
      const newSet = new Set(prev);
      if (newSet.has(keyId)) {
        newSet.delete(keyId);
      } else {
        newSet.add(keyId);
      }
      return newSet;
    });
  };

  const copyToClipboard = (text: string, label: string) => {
    navigator.clipboard.writeText(text);
    toast({
      title: "Copied to clipboard",
      description: `${label} has been copied`,
    });
  };

  const samplePayload = `{
  "instrument": "EURUSD",
  "side": "buy",
  "entry_price": 1.0850,
  "size": 0.1,
  "stop_loss": 1.0800,
  "take_profit": 1.0900,
  "notes": "Breakout setup"
}`;

  const pineScriptCode = `// TradingView Pine Script v5
//@version=5
strategy("PipTrackr.com Webhook", overlay=true)

// Strategy inputs
webhook_url = input.string("YOUR_WEBHOOK_URL", title="Webhook URL")

// Entry conditions (customize as needed)
long_condition = ta.crossover(ta.sma(close, 10), ta.sma(close, 20))
short_condition = ta.crossunder(ta.sma(close, 10), ta.sma(close, 20))

// Calculate position size and levels
position_size = 0.01 // Adjust as needed
stop_loss_pips = 50
take_profit_pips = 100

if long_condition
    strategy.entry("Long", strategy.long)
    alert('{"instrument":"' + syminfo.ticker + 
          '","side":"buy","entry_price":' + str.tostring(close) + 
          ',"size":' + str.tostring(position_size) + 
          ',"stop_loss":' + str.tostring(close - stop_loss_pips * syminfo.mintick * 10) + 
          ',"take_profit":' + str.tostring(close + take_profit_pips * syminfo.mintick * 10) + 
          ',"notes":"TradingView Long Signal"}', 
          freq=alert.freq_once_per_bar)

if short_condition
    strategy.entry("Short", strategy.short)
    alert('{"instrument":"' + syminfo.ticker + 
          '","side":"sell","entry_price":' + str.tostring(close) + 
          ',"size":' + str.tostring(position_size) + 
          ',"stop_loss":' + str.tostring(close + stop_loss_pips * syminfo.mintick * 10) + 
          ',"take_profit":' + str.tostring(close - take_profit_pips * syminfo.mintick * 10) + 
          ',"notes":"TradingView Short Signal"}', 
          freq=alert.freq_once_per_bar)`;

  if (loading) {
    return (
      <div className="space-y-6">
        <div className="h-32 bg-muted rounded-lg animate-pulse" />
        <div className="h-64 bg-muted rounded-lg animate-pulse" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Existing Webhook Keys */}
      {webhookKeys.length > 0 && (
        <Card className="glass-card">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Key className="h-5 w-5 text-primary" />
              Active Webhook Keys
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {webhookKeys.map((key) => (
              <div key={key.id} className="flex items-center justify-between p-4 border rounded-lg">
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 mb-2">
                    <h3 className="font-medium">{key.name}</h3>
                    <Badge variant={key.active ? "default" : "secondary"}>
                      {key.active ? "Active" : "Inactive"}
                    </Badge>
                  </div>
                  <div className="space-y-2">
                    <div className="flex items-center gap-2">
                      <Label className="text-xs">URL:</Label>
                      <code className="text-xs bg-muted px-2 py-1 rounded flex-1 truncate">
                        https://pwpxzlcpdbqjckvmkwlw.supabase.co/functions/v1/trading-webhook?key={key.secret_masked}
                      </code>
                      <Button
                        size="sm"
                        variant="ghost"
                        onClick={() => copyToClipboard(
                          `https://pwpxzlcpdbqjckvmkwlw.supabase.co/functions/v1/trading-webhook?key=${key.secret}`,
                          "Webhook URL"
                        )}
                      >
                        <Copy className="h-4 w-4" />
                      </Button>
                    </div>
                    <div className="flex items-center gap-2">
                      <Label className="text-xs">Secret:</Label>
                      <code className="text-xs bg-muted px-2 py-1 rounded flex-1 truncate">
                        {visibleSecrets.has(key.id) ? key.secret : key.secret_masked}
                      </code>
                      <Button
                        size="sm"
                        variant="ghost"
                        onClick={() => toggleSecretVisibility(key.id)}
                      >
                        {visibleSecrets.has(key.id) ? (
                          <EyeOff className="h-4 w-4" />
                        ) : (
                          <Eye className="h-4 w-4" />
                        )}
                      </Button>
                      <Button
                        size="sm"
                        variant="ghost"
                        onClick={() => copyToClipboard(key.secret, "Secret key")}
                      >
                        <Copy className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                  <p className="text-xs text-muted-foreground mt-2">
                    Created {new Date(key.created_at).toLocaleDateString()}
                  </p>
                </div>
                <Button
                  size="sm"
                  variant="destructive"
                  onClick={() => deleteWebhookKey(key.id)}
                >
                  <Trash2 className="h-4 w-4" />
                </Button>
              </div>
            ))}
          </CardContent>
        </Card>
      )}

      {/* Generate New Webhook */}
      <Card className="glass-card">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Plus className="h-5 w-5 text-primary" />
            Generate New Webhook
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="webhook-name">Webhook Name</Label>
            <Input
              id="webhook-name"
              placeholder="e.g., TradingView Strategy"
              value={webhookName}
              onChange={(e) => setWebhookName(e.target.value)}
            />
          </div>

          <Button
            onClick={generateWebhookKey}
            disabled={generating || !webhookName.trim()}
            className="w-full"
          >
            {generating ? (
              <>
                <Zap className="h-4 w-4 mr-2 animate-spin" />
                Generating...
              </>
            ) : (
              <>
                <Plus className="h-4 w-4 mr-2" />
                Generate Webhook Key
              </>
            )}
          </Button>

          {generatedKey && (
            <div className="mt-4 p-4 bg-success-light border border-success rounded-lg">
              <div className="flex items-center gap-2 mb-2">
                <CheckCircle className="h-5 w-5 text-success" />
                <h3 className="font-medium text-success">Webhook Generated!</h3>
              </div>
              <div className="space-y-2">
                <div>
                  <Label className="text-xs">Webhook URL:</Label>
                  <div className="flex items-center gap-2 mt-1">
                    <code className="text-xs bg-white p-2 rounded flex-1 break-all">
                      {webhookUrl}
                    </code>
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => copyToClipboard(webhookUrl, "Webhook URL")}
                    >
                      <Copy className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
                <div>
                  <Label className="text-xs">Secret Key:</Label>
                  <div className="flex items-center gap-2 mt-1">
                    <code className="text-xs bg-white p-2 rounded flex-1 break-all">
                      {generatedKey}
                    </code>
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => copyToClipboard(generatedKey, "Secret key")}
                    >
                      <Copy className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </div>
              <div className="mt-2 p-2 bg-warning-light border border-warning rounded text-xs">
                <AlertCircle className="h-4 w-4 inline mr-1" />
                Save this secret key! It will be masked after you leave this page.
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Sample Payload */}
      <Card className="glass-card">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Code className="h-5 w-5 text-primary" />
            Sample JSON Payload
          </CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-sm text-muted-foreground mb-4">
            Send this JSON structure to your webhook URL to create pending trades:
          </p>
          <div className="relative">
            <Textarea
              value={samplePayload}
              readOnly
              className="font-mono text-sm min-h-[200px]"
            />
            <Button
              size="sm"
              variant="ghost"
              className="absolute top-2 right-2"
              onClick={() => copyToClipboard(samplePayload, "Sample payload")}
            >
              <Copy className="h-4 w-4" />
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Pine Script Example */}
      <Card className="glass-card">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Code className="h-5 w-5 text-primary" />
            Pine Script Example
          </CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-sm text-muted-foreground mb-4">
            Use this Pine Script template in TradingView to send trades to your webhook:
          </p>
          <div className="relative">
            <Textarea
              value={pineScriptCode}
              readOnly
              className="font-mono text-xs min-h-[400px]"
            />
            <Button
              size="sm"
              variant="ghost"
              className="absolute top-2 right-2"
              onClick={() => copyToClipboard(pineScriptCode, "Pine Script code")}
            >
              <Copy className="h-4 w-4" />
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Setup Instructions */}
      <Card className="glass-card">
        <CardHeader>
          <CardTitle>Setup Instructions</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4 text-sm">
            <div>
              <h4 className="font-medium mb-2">1. Generate Webhook</h4>
              <p className="text-muted-foreground">
                Create a new webhook above and copy the generated URL and secret key.
              </p>
            </div>
            <div>
              <h4 className="font-medium mb-2">2. Configure TradingView Alert</h4>
              <p className="text-muted-foreground">
                In TradingView, create an alert and set the webhook URL as the destination. 
                Use the sample JSON payload format in the message body.
              </p>
            </div>
            <div>
              <h4 className="font-medium mb-2">3. Test Your Webhook</h4>
              <p className="text-muted-foreground">
                Send a test alert from TradingView. The trade will appear as "pending" 
                in your journal, and you can confirm or reject it.
              </p>
            </div>
            <div>
              <h4 className="font-medium mb-2">4. Confirm Trades</h4>
              <p className="text-muted-foreground">
                Review pending trades in your journal and confirm them to add to your trading history.
              </p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
