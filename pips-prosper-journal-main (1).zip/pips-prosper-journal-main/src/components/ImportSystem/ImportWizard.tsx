import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { 
  Upload, 
  FileText, 
  CheckCircle, 
  AlertCircle, 
  Download,
  Zap,
  BarChart3,
  Settings
} from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/components/ui/use-toast";
import { useAccounts } from "@/hooks/useAccounts";

interface ImportMapping {
  instrument: string;
  side: string;
  entry_price: string;
  exit_price: string;
  size: string;
  opened_at: string;
  closed_at?: string;
  pnl?: string;
}

const PLATFORM_TEMPLATES = {
  mt4: {
    name: "MetaTrader 4",
    description: "Standard MT4 history export",
    status: "Coming Soon",
    mapping: {
      instrument: "Symbol",
      side: "Type",
      entry_price: "Price",
      exit_price: "Price",
      size: "Volume",
      opened_at: "Time",
      closed_at: "Time",
      pnl: "Profit"
    }
  },
  mt5: {
    name: "MetaTrader 5", 
    description: "Standard MT5 history export",
    status: "Coming Soon",
    mapping: {
      instrument: "Symbol",
      side: "Type", 
      entry_price: "Price",
      exit_price: "Price",
      size: "Volume",
      opened_at: "Time",
      closed_at: "Time",
      pnl: "Profit"
    }
  },
  ctrader: {
    name: "cTrader",
    description: "cTrader history export",
    status: "Coming Soon",
    mapping: {
      instrument: "Symbol",
      side: "Side",
      entry_price: "Entry Price",
      exit_price: "Exit Price", 
      size: "Volume",
      opened_at: "Open Time",
      closed_at: "Close Time",
      pnl: "Net P&L"
    }
  },
  custom: {
    name: "Manual CSV Import",
    description: "Currently available - Map your own CSV columns",
    status: "Available",
    mapping: {}
  }
};

export function ImportWizard() {
  const [step, setStep] = useState(1);
  const [selectedPlatform, setSelectedPlatform] = useState("");
  const [file, setFile] = useState<File | null>(null);
  const [csvData, setCsvData] = useState<any[]>([]);
  const [csvHeaders, setCsvHeaders] = useState<string[]>([]);
  const [selectedAccount, setSelectedAccount] = useState("");
  const [selectedStrategy, setSelectedStrategy] = useState("");
  const [mapping, setMapping] = useState<ImportMapping>({
    instrument: "",
    side: "",
    entry_price: "",
    exit_price: "",
    size: "",
    opened_at: ""
  });
  const [importing, setImporting] = useState(false);
  const [importProgress, setImportProgress] = useState(0);
  const [importResults, setImportResults] = useState<any>(null);
  const { user } = useAuth();
  const { toast } = useToast();
  const { accounts } = useAccounts();

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const uploadedFile = event.target.files?.[0];
    if (!uploadedFile) return;

    if (!uploadedFile.name.endsWith('.csv')) {
      toast({
        variant: "destructive",
        title: "Invalid file type",
        description: "Please upload a CSV file.",
      });
      return;
    }

    setFile(uploadedFile);
    
    // Parse CSV
    const reader = new FileReader();
    reader.onload = (e) => {
      const text = e.target?.result as string;
      const lines = text.split('\n').filter(line => line.trim());
      
      if (lines.length === 0) {
        toast({
          variant: "destructive", 
          title: "Empty file",
          description: "The CSV file appears to be empty.",
        });
        return;
      }

      const headers = lines[0].split(',').map(h => h.trim().replace(/"/g, ''));
      const data = lines.slice(1).map(line => {
        const values = line.split(',').map(v => v.trim().replace(/"/g, ''));
        const row: any = {};
        headers.forEach((header, index) => {
          row[header] = values[index] || '';
        });
        return row;
      });

      setCsvHeaders(headers);
      setCsvData(data);

      // Auto-apply platform template if selected
      if (selectedPlatform && selectedPlatform !== 'custom') {
        const template = PLATFORM_TEMPLATES[selectedPlatform as keyof typeof PLATFORM_TEMPLATES];
        const autoMapping: any = {};
        
        Object.entries(template.mapping).forEach(([key, templateValue]) => {
          const matchingHeader = headers.find(h => 
            h.toLowerCase().includes(templateValue.toLowerCase()) ||
            templateValue.toLowerCase().includes(h.toLowerCase())
          );
          if (matchingHeader) {
            autoMapping[key] = matchingHeader;
          }
        });

        setMapping(prev => ({ ...prev, ...autoMapping }));
      }

      setStep(3);
    };

    reader.readAsText(uploadedFile);
  };

  const handleImport = async () => {
    if (!user || !csvData.length) return;

    setImporting(true);
    setImportProgress(0);

    try {
      // Create import job
      const { data: importJob, error: jobError } = await supabase
        .from("import_jobs")
        .insert({
          user_id: user.id,
          source: selectedPlatform || "csv",
          status: "processing",
          total_rows: csvData.length
        })
        .select()
        .single();

      if (jobError) throw jobError;

      // Process trades in batches
      const batchSize = 10;
      const trades = [];
      const errors = [];

      for (let i = 0; i < csvData.length; i += batchSize) {
        const batch = csvData.slice(i, i + batchSize);
        
        for (const row of batch) {
          try {
            const tradeData: any = {
              user_id: user.id,
              instrument: row[mapping.instrument] || "",
              side: row[mapping.side]?.toLowerCase().includes('buy') || row[mapping.side]?.toLowerCase().includes('long') ? 'long' : 'short',
              entry_price: parseFloat(row[mapping.entry_price]) || 0,
              size: parseFloat(row[mapping.size]) || 0,
              opened_at: new Date(row[mapping.opened_at]).toISOString(),
              account_id: selectedAccount || null,
              strategy: selectedStrategy || "Imported"
            };

            if (mapping.exit_price && row[mapping.exit_price]) {
              tradeData.exit_price = parseFloat(row[mapping.exit_price]);
              tradeData.closed_at = mapping.closed_at && row[mapping.closed_at] 
                ? new Date(row[mapping.closed_at]).toISOString()
                : new Date(row[mapping.opened_at]).toISOString();
            }

            if (mapping.pnl && row[mapping.pnl]) {
              tradeData.pnl = parseFloat(row[mapping.pnl]);
              tradeData.result = tradeData.pnl > 0 ? 'win' : tradeData.pnl < 0 ? 'loss' : 'breakeven';
            }

            trades.push(tradeData);
          } catch (error: any) {
            errors.push({
              row: i + 1,
              error: error.message,
              data: row
            });
          }
        }

        // Update progress
        setImportProgress((i / csvData.length) * 90);
        
        // Small delay to show progress
        await new Promise(resolve => setTimeout(resolve, 100));
      }

      // Insert trades
      if (trades.length > 0) {
        const { error: insertError } = await supabase
          .from("trades")
          .insert(trades);

        if (insertError) throw insertError;
      }

      // Update import job
      await supabase
        .from("import_jobs")
        .update({
          status: errors.length === csvData.length ? "failed" : "completed",
          processed_rows: trades.length,
          errors_json: errors,
          finished_at: new Date().toISOString()
        })
        .eq("id", importJob.id);

      setImportProgress(100);
      setImportResults({
        success: trades.length,
        errors: errors.length,
        errorDetails: errors
      });
      setStep(4);

      toast({
        title: "Import completed",
        description: `Successfully imported ${trades.length} trades${errors.length > 0 ? ` with ${errors.length} errors` : ''}. Dashboard stats updated!`,
      });

      // Trigger realtime notification for dashboard refresh
      window.dispatchEvent(new CustomEvent('tradesImported', { 
        detail: { count: trades.length, errors: errors.length }
      }));

    } catch (error: any) {
      toast({
        variant: "destructive",
        title: "Import failed",
        description: error.message,
      });
    } finally {
      setImporting(false);
    }
  };

  const resetImport = () => {
    setStep(1);
    setSelectedPlatform("");
    setFile(null);
    setCsvData([]);
    setCsvHeaders([]);
    setSelectedAccount("");
    setSelectedStrategy("");
    setMapping({
      instrument: "",
      side: "",
      entry_price: "",
      exit_price: "",
      size: "",
      opened_at: ""
    });
    setImportResults(null);
    setImportProgress(0);
  };

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      {/* Progress Indicator */}
      <Card className="glass-card border-card-border">
        <CardContent className="p-6">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-xl font-semibold">Import Trading Data</h2>
            <Badge variant="outline">Step {step} of 4</Badge>
          </div>
          <div className="flex items-center space-x-4">
            {[1, 2, 3, 4].map((stepNum) => (
              <div key={stepNum} className="flex items-center">
                <div className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-medium ${
                  step >= stepNum ? 'bg-primary text-white' : 'bg-muted text-muted-foreground'
                }`}>
                  {step > stepNum ? <CheckCircle className="w-4 h-4" /> : stepNum}
                </div>
                {stepNum < 4 && (
                  <div className={`w-12 h-0.5 ${
                    step > stepNum ? 'bg-primary' : 'bg-muted'
                  }`} />
                )}
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Step 1: Choose Platform */}
      {step === 1 && (
        <Card className="glass-card border-card-border">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Settings className="w-5 h-5 text-primary" />
              Choose Your Trading Platform
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {Object.entries(PLATFORM_TEMPLATES).map(([key, template]) => (
                <Card 
                  key={key}
                  className={`transition-all duration-200 ${
                    template.status === 'Coming Soon' 
                      ? 'border-muted bg-muted/20 opacity-60 cursor-not-allowed' 
                      : selectedPlatform === key 
                      ? 'border-primary bg-primary/5 cursor-pointer' 
                      : 'border-card-border hover:border-primary/50 cursor-pointer'
                  }`}
                  onClick={() => template.status === 'Available' && setSelectedPlatform(key)}
                >
                  <CardContent className="p-6">
                    <div className="flex items-start justify-between mb-3">
                      <h3 className="font-semibold">{template.name}</h3>
                      <div className="flex items-center gap-2">
                        {template.status === 'Coming Soon' && (
                          <span className="text-xs px-2 py-1 rounded-full bg-warning/20 text-warning">
                            Coming Soon
                          </span>
                        )}
                        {selectedPlatform === key && template.status === 'Available' && (
                          <CheckCircle className="w-5 h-5 text-primary" />
                        )}
                      </div>
                    </div>
                    <p className="text-sm text-muted-foreground">{template.description}</p>
                  </CardContent>
                </Card>
              ))}
            </div>
            
            <div className="flex justify-end">
              <Button 
                onClick={() => setStep(2)}
                disabled={!selectedPlatform}
                variant="primary"
              >
                Continue
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Step 2: Upload File */}
      {step === 2 && (
        <Card className="glass-card border-card-border">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Upload className="w-5 h-5 text-primary" />
              Upload Your CSV File
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="border-2 border-dashed border-muted-foreground/25 rounded-lg p-8 text-center">
              <Upload className="w-12 h-12 mx-auto mb-4 text-muted-foreground" />
              <div className="space-y-2">
                <h3 className="font-medium">Drop your CSV file here</h3>
                <p className="text-sm text-muted-foreground">
                  Or click to browse your files
                </p>
              </div>
              <Input
                type="file"
                accept=".csv"
                onChange={handleFileUpload}
                className="mt-4 max-w-xs mx-auto"
              />
            </div>

            {file && (
              <div className="flex items-center gap-3 p-3 bg-accent/5 rounded-lg">
                <FileText className="w-5 h-5 text-primary" />
                <div>
                  <p className="font-medium">{file.name}</p>
                  <p className="text-sm text-muted-foreground">
                    {(file.size / 1024).toFixed(1)} KB
                  </p>
                </div>
              </div>
            )}

            <div className="flex justify-between">
              <Button variant="outline" onClick={() => setStep(1)}>
                Back
              </Button>
              {csvData.length > 0 && (
                <Button variant="primary" onClick={() => setStep(3)}>
                  Continue
                </Button>
              )}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Step 3: Map Columns */}
      {step === 3 && (
        <Card className="glass-card border-card-border">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <BarChart3 className="w-5 h-5 text-primary" />
              Map Your Data Columns
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Target Account (Optional)</Label>
                <Select value={selectedAccount} onValueChange={setSelectedAccount}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select account..." />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="">Default Account</SelectItem>
                    {accounts.map(account => (
                      <SelectItem key={account.id} value={account.id}>
                        {account.nickname} ({account.broker_name})
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label>Strategy (Optional)</Label>
                <Input
                  value={selectedStrategy}
                  onChange={(e) => setSelectedStrategy(e.target.value)}
                  placeholder="e.g., Scalping, Breakout, etc."
                />
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {Object.entries({
                instrument: "Instrument/Symbol",
                side: "Side (Long/Short)",
                entry_price: "Entry Price",
                exit_price: "Exit Price", 
                size: "Position Size",
                opened_at: "Open Time",
                closed_at: "Close Time (Optional)",
                pnl: "P&L (Optional)"
              }).map(([key, label]) => (
                <div key={key} className="space-y-2">
                  <Label htmlFor={key}>{label}</Label>
                  <Select
                    value={mapping[key as keyof ImportMapping] || undefined}
                    onValueChange={(value) => setMapping(prev => ({ ...prev, [key]: value }))}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select column" />
                    </SelectTrigger>
                    <SelectContent>
                      {csvHeaders.map(header => (
                        <SelectItem key={header} value={header}>
                          {header}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              ))}
            </div>

            {/* Preview */}
            {csvData.length > 0 && (
              <div className="space-y-3">
                <h4 className="font-semibold">Preview (First 3 rows)</h4>
                <div className="overflow-x-auto">
                  <table className="w-full border rounded-lg">
                    <thead className="bg-muted/50">
                      <tr>
                        <th className="p-2 text-left text-sm font-medium">Instrument</th>
                        <th className="p-2 text-left text-sm font-medium">Side</th>
                        <th className="p-2 text-left text-sm font-medium">Entry</th>
                        <th className="p-2 text-left text-sm font-medium">Size</th>
                        <th className="p-2 text-left text-sm font-medium">Open Time</th>
                      </tr>
                    </thead>
                    <tbody>
                      {csvData.slice(0, 3).map((row, index) => (
                        <tr key={index} className="border-t">
                          <td className="p-2 text-sm">{row[mapping.instrument] || '-'}</td>
                          <td className="p-2 text-sm">{row[mapping.side] || '-'}</td>
                          <td className="p-2 text-sm">{row[mapping.entry_price] || '-'}</td>
                          <td className="p-2 text-sm">{row[mapping.size] || '-'}</td>
                          <td className="p-2 text-sm">{row[mapping.opened_at] || '-'}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            )}

            <div className="flex justify-between">
              <Button variant="outline" onClick={() => setStep(2)}>
                Back
              </Button>
              <Button 
                variant="primary" 
                onClick={handleImport}
                disabled={!mapping.instrument || !mapping.side || !mapping.entry_price || !mapping.size || !mapping.opened_at}
              >
                Start Import
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Step 4: Import Progress & Results */}
      {step === 4 && (
        <Card className="glass-card border-card-border">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Zap className="w-5 h-5 text-primary" />
              {importing ? "Importing..." : "Import Complete"}
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            {importing && (
              <div className="space-y-3">
                <Progress value={importProgress} className="w-full" />
                <p className="text-sm text-muted-foreground text-center">
                  Processing your trades... {Math.round(importProgress)}%
                </p>
              </div>
            )}

            {importResults && (
              <div className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <Card className="p-4 border-green-200 bg-green-50">
                    <div className="flex items-center gap-2">
                      <CheckCircle className="w-5 h-5 text-green-600" />
                      <div>
                        <p className="font-medium text-green-900">Successfully Imported</p>
                        <p className="text-2xl font-bold text-green-600">{importResults.success}</p>
                      </div>
                    </div>
                  </Card>

                  {importResults.errors > 0 && (
                    <Card className="p-4 border-red-200 bg-red-50">
                      <div className="flex items-center gap-2">
                        <AlertCircle className="w-5 h-5 text-red-600" />
                        <div>
                          <p className="font-medium text-red-900">Errors</p>
                          <p className="text-2xl font-bold text-red-600">{importResults.errors}</p>
                        </div>
                      </div>
                    </Card>
                  )}
                </div>

                <div className="flex justify-between">
                  <Button variant="outline" onClick={resetImport}>
                    Import More Data
                  </Button>
                  <Button variant="primary" asChild>
                    <a href="/dashboard">View Dashboard</a>
                  </Button>
                </div>
              </div>
            )}
          </CardContent>
        </Card>
      )}

      {/* Sample Data Download */}
      <Card className="glass-card border-card-border">
        <CardHeader>
          <CardTitle>Need Sample Data?</CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-sm text-muted-foreground mb-4">
            Download sample CSV files to test the import functionality.
          </p>
          <div className="flex gap-2">
            <Button variant="outline" size="sm">
              <Download className="w-4 h-4 mr-2" />
              MT4 Sample
            </Button>
            <Button variant="outline" size="sm">
              <Download className="w-4 h-4 mr-2" />
              MT5 Sample
            </Button>
            <Button variant="outline" size="sm">
              <Download className="w-4 h-4 mr-2" />
              Custom Sample
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}