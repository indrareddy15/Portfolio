import { useState } from "react";
import { Button } from "@/components/ui/button";
import { ExternalLink, Zap, CheckCircle, TrendingUp, BarChart3, Activity, Settings, Globe, Smartphone } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

const integrations = [
  {
    name: "MetaTrader 4",
    icon: TrendingUp,
    description: "Direct CSV import and live data sync from MT4 platform",
    status: "Coming Soon",
    category: "Trading Platforms",
    color: "text-blue-500"
  },
  {
    name: "MetaTrader 5",
    icon: BarChart3,
    description: "Advanced trade tracking and real-time synchronization from MT5",
    status: "Coming Soon", 
    category: "Trading Platforms",
    color: "text-blue-600"
  },
  {
    name: "cTrader",
    icon: Activity,
    description: "Professional ECN platform integration with real-time sync",
    status: "Coming Soon",
    category: "Trading Platforms",
    color: "text-green-500"
  },
  {
    name: "TradeLocker",
    icon: Settings,
    description: "Multi-asset trading platform with advanced portfolio tracking",
    status: "Coming Soon",
    category: "Trading Platforms",
    color: "text-purple-500"
  },
  {
    name: "MatchTrader",
    icon: Globe,
    description: "Institutional-grade trading platform integration",
    status: "Coming Soon",
    category: "Trading Platforms",
    color: "text-orange-500"
  },
  {
    name: "DXTrade",
    icon: Smartphone,
    description: "Multi-device trading platform with seamless sync",
    status: "Coming Soon",
    category: "Trading Platforms",
    color: "text-red-500"
  },
  {
    name: "Manual Entry",
    icon: ExternalLink,
    description: "Quick manual trade logging with smart templates",
    status: "Available",
    category: "Manual",
    color: "text-gray-500"
  },
  {
    name: "Auto Trade Sync",
    icon: Zap,
    description: "🚀 Automatic trade synchronization from all platforms in real-time",
    status: "Coming Soon",
    category: "Automation",
    highlight: true,
    color: "text-success"
  }
];

const categories = ["All", "Trading Platforms", "Manual", "Automation"];

export const IntegrationsSection = () => {
  const [selectedCategory, setSelectedCategory] = useState("All");
  const { toast } = useToast();

  const handleCategoryFilter = (category: string) => {
    setSelectedCategory(category);
    toast({
      title: `${category} Integrations`,
      description: `Filtered to show ${category.toLowerCase()} integrations`,
      duration: 2000,
    });
  };

  const handleRequestIntegration = () => {
    toast({
      title: "Integration Request 📝",
      description: "Opening form to request your platform integration. All integrations stay FREE!",
      duration: 4000,
    });
  };

  const handleOpenIntegration = (name: string) => {
    toast({
      title: `${name} Integration`,
      description: "Opening integration setup for this platform",
      duration: 3000,
    });
  };

  const filteredIntegrations = selectedCategory === "All" 
    ? integrations 
    : integrations.filter(integration => integration.category === selectedCategory);
  return (
    <section id="integrations" className="py-20 relative">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center mb-12 sm:mb-16 px-2 sm:px-0">
          <h2 className="text-2xl sm:text-3xl md:text-4xl lg:text-5xl font-poppins font-bold mb-4 sm:mb-6 leading-tight">
            Seamless{" "}
            <span className="bg-gradient-primary bg-clip-text text-transparent">
              Integrations
            </span>
            {" "}100% FREE
          </h2>
          <p className="text-base sm:text-lg md:text-xl text-muted-foreground max-w-3xl mx-auto mb-6 sm:mb-8 leading-relaxed">
            Connect your favorite trading platforms, exchanges, and tools. 
            Import data automatically or sync in real-time with webhooks.
            <span className="block mt-2 text-success font-semibold">
              All integrations included FREE • Auto Trade Sync coming soon!
            </span>
          </p>
        </div>

        {/* Category Filter */}
        <div className="flex flex-wrap justify-center gap-2 mb-8 sm:mb-12 px-2 sm:px-0">
          {categories.map((category) => (
            <Button 
              key={category}
              variant={selectedCategory === category ? "primary" : "ghost"}
              size="sm"
              className="rounded-full text-xs sm:text-sm"
              onClick={() => handleCategoryFilter(category)}
            >
              {category}
            </Button>
          ))}
        </div>

        {/* Integrations Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4 sm:gap-6 mb-12 sm:mb-16 px-2 sm:px-0">
          {filteredIntegrations.map((integration, index) => {
            const IconComponent = integration.icon;
            return (
              <div 
                key={index}
                className={`glass-card p-4 sm:p-6 hover:shadow-glow transition-all duration-300 group relative ${
                  integration.highlight ? 'border-success/30 bg-success/5 animate-pulse' : ''
                }`}
              >
                {integration.highlight && (
                  <div className="absolute -top-2 -right-2 bg-success text-success-foreground text-xs px-3 py-1 rounded-full animate-pulse">
                    New!
                  </div>
                )}
                <div className="flex items-start justify-between mb-3 sm:mb-4">
                  <div className={`w-10 h-10 sm:w-12 sm:h-12 rounded-lg bg-gradient-glass flex items-center justify-center group-hover:scale-110 transition-transform ${
                    integration.highlight ? 'animate-pulse' : ''
                  }`}>
                    <IconComponent className={`w-5 h-5 sm:w-6 sm:h-6 ${integration.color}`} />
                  </div>
                  <div className="flex items-center space-x-1 sm:space-x-2">
                    {integration.status === "Available" && (
                      <CheckCircle className="w-3 h-3 sm:w-4 sm:h-4 text-success" />
                    )}
                    <span className={`text-xs px-1.5 sm:px-2 py-0.5 sm:py-1 rounded-full font-medium ${
                      integration.status === "Available" 
                        ? "bg-success/20 text-success"
                        : integration.status === "Coming Soon"
                        ? "bg-warning/20 text-warning animate-pulse" 
                        : "bg-muted text-muted-foreground"
                    }`}>
                      {integration.status}
                    </span>
                  </div>
                </div>
                
                <h3 className="text-base sm:text-lg font-poppins font-semibold mb-2 text-foreground">
                  {integration.name}
                </h3>
                
                <p className="text-muted-foreground text-xs sm:text-sm mb-3 sm:mb-4 leading-relaxed">
                  {integration.description}
                </p>
                
                <div className="flex items-center justify-between">
                  <span className="text-xs text-muted-foreground">
                    {integration.category}
                  </span>
                  {integration.status === "Available" && (
                    <Button 
                      variant="ghost" 
                      size="sm" 
                      className="group-hover:text-primary p-1 sm:p-2"
                      onClick={() => handleOpenIntegration(integration.name)}
                    >
                      <ExternalLink className="w-3 h-3 sm:w-4 sm:h-4" />
                    </Button>
                  )}
                </div>
              </div>
            );
          })}
        </div>

        {/* Request Integration */}
        <div className="text-center px-2 sm:px-0">
          <div className="glass-card p-6 sm:p-8 max-w-2xl mx-auto">
            <Zap className="w-8 h-8 sm:w-10 sm:h-10 md:w-12 md:h-12 text-primary mx-auto mb-4 sm:mb-6" />
            <h3 className="text-lg sm:text-xl md:text-2xl font-poppins font-bold mb-3 sm:mb-4">
              Don't See Your Platform?
            </h3>
            <p className="text-sm sm:text-base text-muted-foreground mb-4 sm:mb-6 leading-relaxed">
              Request a new integration and we'll prioritize based on community demand. 
              Most integrations are built within 2-4 weeks.
              <span className="block mt-1 text-success font-semibold">
                All integrations will remain FREE forever!
              </span>
            </p>
            <Button 
              variant="primary" 
              size="lg" 
              className="glow-hover text-sm sm:text-base w-full sm:w-auto"
              onClick={handleRequestIntegration}
            >
              Request FREE Integration
            </Button>
          </div>
        </div>
      </div>
    </section>
  );
};