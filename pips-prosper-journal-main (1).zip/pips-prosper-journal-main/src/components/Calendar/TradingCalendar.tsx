import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Calendar } from "@/components/ui/calendar";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { 
  Calendar as CalendarIcon, 
  TrendingUp, 
  TrendingDown,
  AlertTriangle,
  Info,
  DollarSign,
  BarChart3
} from "lucide-react";
import { format, isSameDay, startOfMonth, endOfMonth, eachDayOfInterval } from "date-fns";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";

interface Trade {
  id: string;
  instrument: string;
  pnl: number;
  opened_at: string;
  closed_at: string | null;
}

interface NewsEvent {
  id: string;
  date: string;
  time: string | null;
  title: string;
  description: string | null;
  impact_level: 'low' | 'medium' | 'high';
  currency: string | null;
  category: string | null;
}

interface DayData {
  date: Date;
  trades: Trade[];
  pnl: number;
  newsEvents: NewsEvent[];
  hasTrading: boolean;
}

const IMPACT_COLORS = {
  low: "bg-green-500",
  medium: "bg-yellow-500", 
  high: "bg-red-500"
};

const IMPACT_ICONS = {
  low: <Info className="w-3 h-3" />,
  medium: <AlertTriangle className="w-3 h-3" />,
  high: <AlertTriangle className="w-3 h-3" />
};

export function TradingCalendar() {
  const [selectedDate, setSelectedDate] = useState<Date>(new Date());
  const [currentMonth, setCurrentMonth] = useState<Date>(new Date());
  const [trades, setTrades] = useState<Trade[]>([]);
  const [newsEvents, setNewsEvents] = useState<NewsEvent[]>([]);
  const [calendarData, setCalendarData] = useState<{ [key: string]: DayData }>({});
  const [selectedTimeframe, setSelectedTimeframe] = useState("month");
  const [selectedCurrency, setSelectedCurrency] = useState("all");
  
  const { user } = useAuth();
  const { toast } = useToast();

  useEffect(() => {
    if (user) {
      loadTrades();
      loadNewsEvents();
    }
  }, [user, currentMonth]);

  useEffect(() => {
    if (trades.length > 0) {
      generateCalendarData();
    }
  }, [trades, newsEvents, currentMonth]);

  const loadTrades = async () => {
    if (!user) return;

    try {
      const startDate = startOfMonth(currentMonth);
      const endDate = endOfMonth(currentMonth);

      const { data, error } = await supabase
        .from("trades")
        .select("*")
        .eq("user_id", user.id)
        .gte("opened_at", startDate.toISOString())
        .lte("opened_at", endDate.toISOString())
        .not("pnl", "is", null)
        .order("opened_at", { ascending: true });

      if (error) throw error;
      setTrades(data || []);
    } catch (error: any) {
      toast({
        variant: "destructive",
        title: "Error loading trades",
        description: error.message,
      });
    }
  };

  const loadNewsEvents = async () => {
    try {
      const startDate = startOfMonth(currentMonth);
      const endDate = endOfMonth(currentMonth);

      const { data, error } = await supabase
        .from("news_events")
        .select("*")
        .gte("date", format(startDate, "yyyy-MM-dd"))
        .lte("date", format(endDate, "yyyy-MM-dd"))
        .order("date", { ascending: true });

      if (error) throw error;
      setNewsEvents((data || []).map(event => ({
        ...event,
        impact_level: event.impact_level as 'low' | 'medium' | 'high'
      })));
    } catch (error: any) {
      // If no news events, continue silently
      setNewsEvents([]);
    }
  };

  const generateCalendarData = () => {
    const startDate = startOfMonth(currentMonth);
    const endDate = endOfMonth(currentMonth);
    const days = eachDayOfInterval({ start: startDate, end: endDate });
    
    const data: { [key: string]: DayData } = {};

    days.forEach(day => {
      const dayStr = format(day, "yyyy-MM-dd");
      const dayTrades = trades.filter(trade => 
        format(new Date(trade.opened_at), "yyyy-MM-dd") === dayStr
      );
      
      const dayEvents = newsEvents.filter(event => event.date === dayStr);
      
      // Filter by currency if selected
      const filteredEvents = selectedCurrency === "all" 
        ? dayEvents 
        : dayEvents.filter(event => event.currency === selectedCurrency.toUpperCase());

      const dayPnL = dayTrades.reduce((sum, trade) => sum + (trade.pnl || 0), 0);

      data[dayStr] = {
        date: day,
        trades: dayTrades,
        pnl: dayPnL,
        newsEvents: filteredEvents,
        hasTrading: dayTrades.length > 0
      };
    });

    setCalendarData(data);
  };

  const getDayClassName = (date: Date) => {
    const dayStr = format(date, "yyyy-MM-dd");
    const dayData = calendarData[dayStr];
    
    if (!dayData || !dayData.hasTrading) return "";
    
    if (dayData.pnl > 0) return "bg-success/20 border-success/40 hover:bg-success/30";
    if (dayData.pnl < 0) return "bg-danger/20 border-danger/40 hover:bg-danger/30";
    return "bg-muted/20 border-muted/40";
  };

  const renderDayContent = (date: Date) => {
    const dayStr = format(date, "yyyy-MM-dd");
    const dayData = calendarData[dayStr];
    
    if (!dayData) return null;

    return (
      <div className="w-full h-full p-1">
        <div className="text-sm font-semibold">{format(date, "d")}</div>
        
        {/* P&L indicator */}
        {dayData.hasTrading && (
          <div className={`text-xs font-bold ${
            dayData.pnl > 0 ? 'text-success' : dayData.pnl < 0 ? 'text-danger' : 'text-muted-foreground'
          }`}>
            {dayData.pnl > 0 ? '+' : ''}${dayData.pnl.toFixed(0)}
          </div>
        )}
        
        {/* News events indicators */}
        <div className="flex flex-wrap gap-0.5 mt-1">
          {dayData.newsEvents.slice(0, 3).map(event => (
            <div 
              key={event.id} 
              className={`w-2 h-2 rounded-full ${IMPACT_COLORS[event.impact_level]}`}
              title={event.title}
            />
          ))}
          {dayData.newsEvents.length > 3 && (
            <div className="text-xs text-muted-foreground">+{dayData.newsEvents.length - 3}</div>
          )}
        </div>
      </div>
    );
  };

  const selectedDayData = selectedDate ? calendarData[format(selectedDate, "yyyy-MM-dd")] : null;

  // Sample news events (in real app, these would come from an API)
  const sampleNewsEvents: NewsEvent[] = [
    {
      id: "1",
      date: format(new Date(), "yyyy-MM-dd"),
      time: "08:30",
      title: "US Non-Farm Payrolls",
      description: "Monthly employment report",
      impact_level: "high",
      currency: "USD",
      category: "Employment"
    },
    {
      id: "2", 
      date: format(new Date(), "yyyy-MM-dd"),
      time: "12:00",
      title: "EUR CPI Flash Estimate",
      description: "Inflation data for Eurozone",
      impact_level: "medium",
      currency: "EUR",
      category: "Inflation"
    }
  ];

  return (
    <div className="space-y-6">
      {/* Controls */}
      <Card className="glass-card border-card-border">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <CalendarIcon className="w-5 h-5 text-primary" />
            Trading Calendar with Economic Events
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex items-center gap-4">
            <Select value={selectedTimeframe} onValueChange={setSelectedTimeframe}>
              <SelectTrigger className="w-32">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="week">Week</SelectItem>
                <SelectItem value="month">Month</SelectItem>
                <SelectItem value="quarter">Quarter</SelectItem>
              </SelectContent>
            </Select>

            <Select value={selectedCurrency} onValueChange={setSelectedCurrency}>
              <SelectTrigger className="w-32">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Currencies</SelectItem>
                <SelectItem value="usd">USD</SelectItem>
                <SelectItem value="eur">EUR</SelectItem>
                <SelectItem value="gbp">GBP</SelectItem>
                <SelectItem value="jpy">JPY</SelectItem>
              </SelectContent>
            </Select>

            <div className="flex items-center gap-2 ml-auto">
              <div className="flex items-center gap-1">
                <div className="w-3 h-3 bg-success/40 rounded"></div>
                <span className="text-xs">Profit</span>
              </div>
              <div className="flex items-center gap-1">
                <div className="w-3 h-3 bg-danger/40 rounded"></div>
                <span className="text-xs">Loss</span>
              </div>
              <div className="flex items-center gap-1">
                <div className="w-2 h-2 bg-red-500 rounded-full"></div>
                <span className="text-xs">High Impact</span>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Calendar */}
        <Card className="glass-card border-card-border lg:col-span-2">
          <CardContent className="p-6">
            <Calendar
              mode="single"
              selected={selectedDate}
              onSelect={setSelectedDate}
              month={currentMonth}
              onMonthChange={setCurrentMonth}
              className="w-full"
              classNames={{
                day: "h-16 w-full p-0 relative",
              }}
              components={{
                DayContent: ({ date }) => renderDayContent(date),
              }}
            />
          </CardContent>
        </Card>

        {/* Selected Day Details */}
        <Card className="glass-card border-card-border">
          <CardHeader>
            <CardTitle className="text-lg">
              {selectedDate ? format(selectedDate, "MMM dd, yyyy") : "Select a Date"}
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {selectedDayData ? (
              <>
                {/* Trading Summary */}
                {selectedDayData.hasTrading ? (
                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-muted-foreground">Daily P&L:</span>
                      <span className={`font-bold ${
                        selectedDayData.pnl > 0 ? 'text-success' : 
                        selectedDayData.pnl < 0 ? 'text-danger' : 'text-muted-foreground'
                      }`}>
                        {selectedDayData.pnl > 0 ? '+' : ''}${selectedDayData.pnl.toFixed(2)}
                      </span>
                    </div>
                    
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-muted-foreground">Trades:</span>
                      <span className="font-semibold">{selectedDayData.trades.length}</span>
                    </div>

                    <div className="space-y-2">
                      <h4 className="font-semibold text-sm">Trade Details:</h4>
                      {selectedDayData.trades.map(trade => (
                        <div key={trade.id} className="flex items-center justify-between text-sm p-2 bg-muted/10 rounded">
                          <span>{trade.instrument}</span>
                          <span className={`font-semibold ${
                            (trade.pnl || 0) > 0 ? 'text-success' : 'text-danger'
                          }`}>
                            {(trade.pnl || 0) > 0 ? '+' : ''}${trade.pnl?.toFixed(2)}
                          </span>
                        </div>
                      ))}
                    </div>
                  </div>
                ) : (
                  <div className="text-center py-4 text-muted-foreground">
                    <BarChart3 className="w-8 h-8 mx-auto mb-2 opacity-50" />
                    <p className="text-sm">No trades on this day</p>
                  </div>
                )}

                {/* News Events */}
                {selectedDayData.newsEvents.length > 0 ? (
                  <div className="space-y-3">
                    <h4 className="font-semibold text-sm">Economic Events:</h4>
                    {selectedDayData.newsEvents.map(event => (
                      <div key={event.id} className="p-3 bg-muted/10 rounded-lg">
                        <div className="flex items-center gap-2 mb-1">
                          <div className={`p-1 rounded-full text-white ${IMPACT_COLORS[event.impact_level]}`}>
                            {IMPACT_ICONS[event.impact_level]}
                          </div>
                          <span className="font-semibold text-sm">{event.title}</span>
                          {event.currency && (
                            <Badge variant="outline" className="text-xs">
                              {event.currency}
                            </Badge>
                          )}
                        </div>
                        {event.time && (
                          <div className="text-xs text-muted-foreground mb-1">
                            {event.time}
                          </div>
                        )}
                        {event.description && (
                          <p className="text-xs text-muted-foreground">
                            {event.description}
                          </p>
                        )}
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-4 text-muted-foreground">
                    <Info className="w-8 h-8 mx-auto mb-2 opacity-50" />
                    <p className="text-sm">No economic events</p>
                  </div>
                )}
              </>
            ) : (
              <div className="text-center py-8 text-muted-foreground">
                <CalendarIcon className="w-12 h-12 mx-auto mb-4 opacity-50" />
                <p>Select a date to view details</p>
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Monthly Summary */}
      <Card className="glass-card border-card-border">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <DollarSign className="w-5 h-5 text-primary" />
            {format(currentMonth, "MMMM yyyy")} Summary
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
            <div className="text-center">
              <div className="text-2xl font-bold text-primary">
                {Object.values(calendarData).filter(d => d.hasTrading).length}
              </div>
              <div className="text-sm text-muted-foreground">Trading Days</div>
            </div>
            
            <div className="text-center">
              <div className="text-2xl font-bold text-success">
                {Object.values(calendarData).filter(d => d.pnl > 0).length}
              </div>
              <div className="text-sm text-muted-foreground">Profitable Days</div>
            </div>
            
            <div className="text-center">
              <div className="text-2xl font-bold text-danger">
                {Object.values(calendarData).filter(d => d.pnl < 0).length}
              </div>
              <div className="text-sm text-muted-foreground">Loss Days</div>
            </div>
            
            <div className="text-center">
              <div className={`text-2xl font-bold ${
                Object.values(calendarData).reduce((sum, d) => sum + d.pnl, 0) > 0 ? 'text-success' : 'text-danger'
              }`}>
                ${Object.values(calendarData).reduce((sum, d) => sum + d.pnl, 0).toFixed(2)}
              </div>
              <div className="text-sm text-muted-foreground">Total P&L</div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}