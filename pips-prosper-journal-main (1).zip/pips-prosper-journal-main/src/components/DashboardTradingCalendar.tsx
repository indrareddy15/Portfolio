import { useState, useEffect, useMemo } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Calendar, ChevronLeft, ChevronRight, TrendingUp, TrendingDown, StickyNote } from "lucide-react";
import { format, startOfMonth, endOfMonth, eachDayOfInterval, isSameMonth, isSameDay, isToday } from "date-fns";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { useAccountContext } from "@/hooks/useAccountContext";
import { useAccounts, Account } from "@/hooks/useAccounts";
import { useToast } from "@/hooks/use-toast";

interface Trade {
  id: string;
  instrument: string;
  side: 'buy' | 'sell';
  entry_price: number;
  exit_price?: number;
  size: number;
  pnl?: number;
  opened_at: string;
  closed_at?: string;
  notes_pre?: string;
  notes_post?: string;
  account_id: string;
}

interface DayData {
  date: Date;
  pnl: number;
  trades: Trade[];
  totalTrades: number;
}

interface TradeDetailProps {
  trade: Trade;
  onNotesUpdate: (tradeId: string, preNotes: string, postNotes: string) => void;
}

const TradeDetail = ({ trade, onNotesUpdate }: TradeDetailProps) => {
  const [preNotes, setPreNotes] = useState(trade.notes_pre || '');
  const [postNotes, setPostNotes] = useState(trade.notes_post || '');
  const [isSaving, setIsSaving] = useState(false);

  const handleSaveNotes = async () => {
    setIsSaving(true);
    try {
      const { error } = await supabase
        .from('trades')
        .update({
          notes_pre: preNotes.trim() || null,
          notes_post: postNotes.trim() || null
        })
        .eq('id', trade.id);

      if (error) throw error;
      onNotesUpdate(trade.id, preNotes, postNotes);
    } catch (error) {
      console.error('Error saving notes:', error);
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <div className="space-y-4 p-4 border rounded-lg bg-card">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Badge variant={trade.side === 'buy' ? 'default' : 'secondary'}>
            {trade.side.toUpperCase()}
          </Badge>
          <span className="font-medium">{trade.instrument}</span>
          <span className="text-sm text-muted-foreground">
            {trade.size} lots @ {trade.entry_price}
          </span>
        </div>
        {trade.pnl !== undefined && (
          <div className={`flex items-center gap-1 ${trade.pnl >= 0 ? 'text-success' : 'text-danger'}`}>
            {trade.pnl >= 0 ? <TrendingUp className="h-4 w-4" /> : <TrendingDown className="h-4 w-4" />}
            <span className="font-semibold">
              {trade.pnl >= 0 ? '+' : ''}${trade.pnl?.toFixed(2)}
            </span>
          </div>
        )}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="space-y-2">
          <Label className="text-sm font-medium">Pre-trade Notes</Label>
          <Textarea
            value={preNotes}
            onChange={(e) => setPreNotes(e.target.value)}
            placeholder="Add your pre-trade analysis, setup, reasoning..."
            className="min-h-[80px] text-sm"
          />
        </div>
        
        <div className="space-y-2">
          <Label className="text-sm font-medium">Post-trade Notes</Label>
          <Textarea
            value={postNotes}
            onChange={(e) => setPostNotes(e.target.value)}
            placeholder="Add your post-trade review, lessons learned..."
            className="min-h-[80px] text-sm"
          />
        </div>
      </div>

        <Button
          onClick={handleSaveNotes}
          disabled={isSaving}
          size="sm"
          className="w-full"
        >
          <StickyNote className="h-4 w-4 mr-2" />
          {isSaving ? 'Saving...' : 'Save Notes'}
        </Button>
    </div>
  );
};

export function DashboardTradingCalendar() {
  const [currentDate, setCurrentDate] = useState(new Date());
  const [selectedDay, setSelectedDay] = useState<DayData | null>(null);
  const [selectedTrade, setSelectedTrade] = useState<Trade | null>(null);
  const [trades, setTrades] = useState<Trade[]>([]);
  const [dayDataMap, setDayDataMap] = useState<Map<string, DayData>>(new Map());

  const { user } = useAuth();
  const { selectedAccountId } = useAccountContext();
  const { accounts } = useAccounts();
  const { toast } = useToast();

  const selectedAccount = accounts.find(acc => acc.id === selectedAccountId);

  // Generate calendar days
  const calendarDays = useMemo(() => {
    const start = startOfMonth(currentDate);
    const end = endOfMonth(currentDate);
    return eachDayOfInterval({ start, end });
  }, [currentDate]);

  // Load trades for current month
  useEffect(() => {
    if (!user?.id || !selectedAccountId) return;

    const loadTrades = async () => {
      try {
        const startDate = startOfMonth(currentDate);
        const endDate = endOfMonth(currentDate);

        const { data, error } = await supabase
          .from('trades')
          .select('*')
          .eq('user_id', user.id)
          .eq('account_id', selectedAccountId)
          .gte('opened_at', startDate.toISOString())
          .lte('opened_at', endDate.toISOString())
          .order('opened_at', { ascending: true });

        if (error) throw error;
        setTrades((data || []).map(trade => ({
          ...trade,
          side: trade.side as 'buy' | 'sell'
        })));
      } catch (error) {
        console.error('Error loading trades:', error);
        toast({
          variant: "destructive",
          title: "Error loading trades",
          description: "Failed to load calendar data"
        });
      }
    };

    loadTrades();
  }, [user?.id, selectedAccountId, currentDate]);

  // Process trades into day data
  useEffect(() => {
    const dayMap = new Map<string, DayData>();

    calendarDays.forEach(day => {
      const dayKey = format(day, 'yyyy-MM-dd');
      const dayTrades = trades.filter(trade => 
        isSameDay(new Date(trade.opened_at), day)
      );

      const dayPnl = dayTrades
        .filter(trade => trade.pnl !== null && trade.pnl !== undefined)
        .reduce((sum, trade) => sum + (trade.pnl || 0), 0);

      dayMap.set(dayKey, {
        date: day,
        pnl: dayPnl,
        trades: dayTrades,
        totalTrades: dayTrades.length
      });
    });

    setDayDataMap(dayMap);
  }, [trades, calendarDays]);

  const handleDayClick = (day: Date) => {
    const dayKey = format(day, 'yyyy-MM-dd');
    const dayData = dayDataMap.get(dayKey);
    if (dayData && dayData.totalTrades > 0) {
      setSelectedDay(dayData);
    }
  };

  const handleTradeClick = (trade: Trade) => {
    setSelectedTrade(trade);
  };

  const handleNotesUpdate = (tradeId: string, preNotes: string, postNotes: string) => {
    setTrades(prev => prev.map(trade => 
      trade.id === tradeId 
        ? { ...trade, notes_pre: preNotes, notes_post: postNotes }
        : trade
    ));
    
    toast({
      title: "Notes saved",
      description: "Trade notes have been updated successfully"
    });
  };

  const navigateMonth = (direction: 'prev' | 'next') => {
    setCurrentDate(prev => {
      const newDate = new Date(prev);
      if (direction === 'prev') {
        newDate.setMonth(prev.getMonth() - 1);
      } else {
        newDate.setMonth(prev.getMonth() + 1);
      }
      return newDate;
    });
  };

  if (!selectedAccount) {
    return (
      <Card className="glass-card border-card-border">
        <CardContent className="flex items-center justify-center h-64">
          <div className="text-center text-muted-foreground">
            <Calendar className="h-12 w-12 mx-auto mb-4 opacity-50" />
            <p>Please select an account to view the trading calendar</p>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <>
      <Card className="glass-card border-card-border">
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="flex items-center gap-2">
              <Calendar className="h-5 w-5 text-primary" />
              Trading Calendar - {selectedAccount.name}
            </CardTitle>
            <div className="flex items-center gap-2">
              <Button variant="outline" size="sm" onClick={() => navigateMonth('prev')}>
                <ChevronLeft className="h-4 w-4" />
              </Button>
              <span className="font-medium min-w-[140px] text-center">
                {format(currentDate, 'MMMM yyyy')}
              </span>
              <Button variant="outline" size="sm" onClick={() => navigateMonth('next')}>
                <ChevronRight className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-7 gap-2 mb-4">
            {['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].map(day => (
              <div key={day} className="text-center text-sm font-medium text-muted-foreground p-2">
                {day}
              </div>
            ))}
          </div>

          <div className="grid grid-cols-7 gap-2">
            {calendarDays.map(day => {
              const dayKey = format(day, 'yyyy-MM-dd');
              const dayData = dayDataMap.get(dayKey);
              const hasTradesData = dayData && dayData.totalTrades > 0;

              return (
                <div
                  key={dayKey}
                  className={`
                    relative aspect-square p-2 rounded-lg border transition-all cursor-pointer
                    ${!isSameMonth(day, currentDate) ? 'opacity-30' : ''}
                    ${isToday(day) ? 'ring-2 ring-primary' : ''}
                    ${hasTradesData ? 'bg-card hover:bg-card/80' : 'bg-muted/20 hover:bg-muted/40'}
                  `}
                  onClick={() => handleDayClick(day)}
                >
                  <div className="text-sm font-medium">
                    {format(day, 'd')}
                  </div>
                  
                  {hasTradesData && (
                    <div className="absolute inset-x-1 bottom-1 space-y-1">
                      <div className={`text-xs font-semibold ${
                        dayData.pnl >= 0 ? 'text-success' : 'text-danger'
                      }`}>
                        {dayData.pnl >= 0 ? '+' : ''}${dayData.pnl.toFixed(0)}
                      </div>
                      <div className="text-xs text-muted-foreground">
                        {dayData.totalTrades} trades
                      </div>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </CardContent>
      </Card>

      {/* Day Details Dialog */}
      <Dialog open={!!selectedDay} onOpenChange={() => setSelectedDay(null)}>
        <DialogContent className="max-w-4xl max-h-[80vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Calendar className="h-5 w-5" />
              Trades for {selectedDay && format(selectedDay.date, 'MMMM d, yyyy')}
              <Badge variant="outline" className="ml-2">
                {selectedDay?.totalTrades} trades
              </Badge>
              <Badge variant={selectedDay && selectedDay.pnl >= 0 ? 'default' : 'destructive'}>
                {selectedDay && selectedDay.pnl >= 0 ? '+' : ''}${selectedDay?.pnl.toFixed(2)}
              </Badge>
            </DialogTitle>
          </DialogHeader>
          
          <div className="space-y-4">
            {selectedDay?.trades.map(trade => (
              <div
                key={trade.id}
                className="p-4 border rounded-lg cursor-pointer hover:bg-card/50 transition-colors"
                onClick={() => handleTradeClick(trade)}
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <Badge variant={trade.side === 'buy' ? 'default' : 'secondary'}>
                      {trade.side.toUpperCase()}
                    </Badge>
                    <span className="font-medium">{trade.instrument}</span>
                    <span className="text-sm text-muted-foreground">
                      {trade.size} lots @ {trade.entry_price}
                    </span>
                    <span className="text-xs text-muted-foreground">
                      {format(new Date(trade.opened_at), 'HH:mm')}
                    </span>
                  </div>
                  
                  <div className="flex items-center gap-2">
                    {(trade.notes_pre || trade.notes_post) && (
                      <StickyNote className="h-4 w-4 text-muted-foreground" />
                    )}
                    {trade.pnl !== undefined && (
                      <div className={`flex items-center gap-1 ${
                        trade.pnl >= 0 ? 'text-success' : 'text-danger'
                      }`}>
                        {trade.pnl >= 0 ? <TrendingUp className="h-4 w-4" /> : <TrendingDown className="h-4 w-4" />}
                        <span className="font-semibold">
                          {trade.pnl >= 0 ? '+' : ''}${trade.pnl.toFixed(2)}
                        </span>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </DialogContent>
      </Dialog>

      {/* Trade Detail Dialog */}
      <Dialog open={!!selectedTrade} onOpenChange={() => setSelectedTrade(null)}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              Trade Details - {selectedTrade?.instrument}
              <Badge variant={selectedTrade?.side === 'buy' ? 'default' : 'secondary'}>
                {selectedTrade?.side.toUpperCase()}
              </Badge>
            </DialogTitle>
          </DialogHeader>
          
          {selectedTrade && (
            <TradeDetail
              trade={selectedTrade}
              onNotesUpdate={handleNotesUpdate}
            />
          )}
        </DialogContent>
      </Dialog>
    </>
  );
}