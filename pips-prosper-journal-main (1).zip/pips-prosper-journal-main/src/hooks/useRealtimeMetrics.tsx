import { useEffect, useState, useCallback } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/hooks/useAuth';

export interface MetricsSummary {
  id: string;
  user_id: string;
  scope: string;
  start_ts?: string;
  end_ts?: string;
  total_pnl: number;
  net_pnl: number;
  win_rate: number;
  avg_rr: number;
  profit_factor: number;
  expectancy: number;
  max_dd: number;
  sharpe: number;
  longest_win: number;
  longest_loss: number;
  trade_count: number;
  updated_at: string;
}

export interface EquitySnapshot {
  id: string;
  user_id: string;
  time_utc: string;
  equity_account: number;
  account_id?: string;
}

export interface InstrumentStats {
  id: string;
  user_id: string;
  symbol: string;
  trade_count: number;
  pnl: number;
  win_rate: number;
  avg_rr: number;
}


export const useRealtimeMetrics = () => {
  const { user } = useAuth();
  const [metricsSummary, setMetricsSummary] = useState<MetricsSummary | null>(null);
  const [equityData, setEquityData] = useState<EquitySnapshot[]>([]);
  const [instrumentStats, setInstrumentStats] = useState<InstrumentStats[]>([]);
  const [loading, setLoading] = useState(true);

  // Fetch initial data
  const fetchMetrics = useCallback(async () => {
    if (!user) return;

    try {
      // Fetch metrics summary for all_time scope
      const { data: metricsData } = await supabase
        .from('metrics_summary')
        .select('*')
        .eq('user_id', user.id)
        .eq('scope', 'all_time')
        .single();

      if (metricsData) {
        setMetricsSummary(metricsData as MetricsSummary);
      }

      // Fetch equity snapshots (last 30 days)
      const thirtyDaysAgo = new Date();
      thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);
      
      const { data: equityDataResult } = await supabase
        .from('equity_snapshots')
        .select('*')
        .eq('user_id', user.id)
        .gte('time_utc', thirtyDaysAgo.toISOString())
        .order('time_utc', { ascending: true });

      if (equityDataResult) {
        setEquityData(equityDataResult as EquitySnapshot[]);
      }

      // Fetch instrument stats
      const { data: instrumentStatsData } = await supabase
        .from('instrument_stats')
        .select('*')
        .eq('user_id', user.id)
        .order('pnl', { ascending: false });

      if (instrumentStatsData) {
        setInstrumentStats(instrumentStatsData as InstrumentStats[]);
      }

    } catch (error) {
      console.error('Error fetching metrics:', error);
    } finally {
      setLoading(false);
    }
  }, [user]);

  // Trigger metrics recalculation when trades change
  const triggerMetricsUpdate = useCallback(async () => {
    if (!user) return;

    try {
      // Call the realtime metrics engine to recalculate
      await supabase.functions.invoke('realtime-metrics-engine', {
        body: { user_id: user.id, action: 'recalculate' }
      });
    } catch (error) {
      console.error('Error triggering metrics update:', error);
    }
  }, [user]);

  useEffect(() => {
    fetchMetrics();
  }, [fetchMetrics]);

  // Set up real-time subscriptions with automatic metrics recalculation
  useEffect(() => {
    if (!user) return;

    const channel = supabase.channel(`enhanced-metrics-${user.id}`)
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'metrics_summary',
          filter: `user_id=eq.${user.id}`
        },
        (payload) => {
          console.log('📊 Metrics summary updated:', payload);
          if (payload.eventType === 'UPDATE' || payload.eventType === 'INSERT') {
            const newData = payload.new as MetricsSummary;
            if (newData.scope === 'all_time') {
              setMetricsSummary(newData);
            }
          }
        }
      )
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'equity_snapshots',
          filter: `user_id=eq.${user.id}`
        },
        (payload) => {
          console.log('📈 Equity snapshot updated:', payload);
          if (payload.eventType === 'INSERT') {
            const newSnapshot = payload.new as EquitySnapshot;
            setEquityData(prev => [...prev, newSnapshot].slice(-200));
          }
        }
      )
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'trades',
          filter: `user_id=eq.${user.id}`
        },
        (payload) => {
          console.log('💰 Trade updated - triggering metrics recalculation:', payload);
          // Automatically trigger metrics update when trades change
          setTimeout(() => triggerMetricsUpdate(), 1000);
        }
      )
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'instrument_stats',
          filter: `user_id=eq.${user.id}`
        },
        (payload) => {
          console.log('🎯 Instrument stats updated:', payload);
          if (payload.eventType === 'UPDATE' || payload.eventType === 'INSERT') {
            const updatedStat = payload.new as InstrumentStats;
            setInstrumentStats(prev => {
              const existing = prev.find(s => s.id === updatedStat.id);
              if (existing) {
                return prev.map(s => s.id === updatedStat.id ? updatedStat : s);
              } else {
                return [...prev, updatedStat].sort((a, b) => b.pnl - a.pnl);
              }
            });
          }
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [user]);

  return {
    metricsSummary,
    equityData,
    instrumentStats,
    loading,
    refetchMetrics: fetchMetrics,
    triggerMetricsUpdate,
  };
};