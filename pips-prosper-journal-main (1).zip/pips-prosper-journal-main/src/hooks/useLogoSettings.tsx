import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";

interface LogoSetting {
  id: string;
  logo_type: string;
  logo_url: string;
  logo_alt: string;
  width?: number;
  height?: number;
  usage_locations?: string[];
  is_active: boolean;
  created_at: string;
  updated_at: string;
}

export const useLogoSettings = () => {
  const [logos, setLogos] = useState<LogoSetting[]>([]);
  const [loading, setLoading] = useState(true);

  const fetchLogos = async () => {
    try {
      const { data, error } = await supabase
        .from('logo_settings')
        .select('*')
        .eq('is_active', true)
        .order('created_at', { ascending: false });

      if (error) throw error;
      setLogos(data || []);
    } catch (error) {
      console.error('Error fetching logo settings:', error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchLogos();

    // Set up real-time subscription
    const channel = supabase
      .channel('logo-settings-changes')
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'logo_settings'
        },
        () => {
          fetchLogos();
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, []);

  const getMainLogo = () => {
    return logos.find(logo => logo.logo_type === 'main' && logo.is_active);
  };

  const getLogoByType = (type: string) => {
    return logos.find(logo => logo.logo_type === type && logo.is_active);
  };

  return {
    logos,
    loading,
    getMainLogo,
    getLogoByType,
    refetch: fetchLogos
  };
};