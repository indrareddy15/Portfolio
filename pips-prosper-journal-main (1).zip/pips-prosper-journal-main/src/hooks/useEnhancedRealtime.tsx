import { useEffect, useCallback, useRef } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { toast } from '@/hooks/use-toast';

export interface EnhancedRealtimeConfig {
  table: string;
  events?: ('INSERT' | 'UPDATE' | 'DELETE')[];
  onInsert?: (payload: any) => void;
  onUpdate?: (payload: any) => void;
  onDelete?: (payload: any) => void;
  showToasts?: boolean;
  channelName?: string;
  filter?: string;
  userId?: string;
}

export const useEnhancedRealtime = (configs: EnhancedRealtimeConfig[]) => {
  const channelsRef = useRef<Set<string>>(new Set());

  const setupChannels = useCallback(() => {
    // Clean up existing channels
    channelsRef.current.forEach(channelName => {
      const channel = supabase.channel(channelName);
      supabase.removeChannel(channel);
    });
    channelsRef.current.clear();

    if (!configs.length) return;

    configs.forEach((config, index) => {
      const channelName = config.channelName || `enhanced-realtime-${config.table}-${index}`;
      channelsRef.current.add(channelName);
      
      const channel = supabase.channel(channelName);
      const events = config.events || ['INSERT', 'UPDATE', 'DELETE'];

      events.forEach((event) => {
        const subscription: any = {
          event,
          schema: 'public',
          table: config.table
        };

        // Add filter if provided
        if (config.filter) {
          subscription.filter = config.filter;
        }

        channel.on(
          'postgres_changes' as any,
          subscription,
          (payload: any) => {
            console.log(`Enhanced Realtime: ${event} on ${config.table}:`, payload);

            // Filter by user if specified
            if (config.userId && payload.new && payload.new.user_id !== config.userId) {
              return;
            }
            if (config.userId && payload.old && payload.old.user_id !== config.userId) {
              return;
            }

            // Handle different events
            switch (event) {
              case 'INSERT':
                config.onInsert?.(payload);
                if (config.showToasts) {
                  toast({
                    title: `New ${config.table.replace('_', ' ')} created`,
                    description: 'Data updated in real-time',
                  });
                }
                break;
              case 'UPDATE':
                config.onUpdate?.(payload);
                if (config.showToasts) {
                  toast({
                    title: `${config.table.replace('_', ' ')} updated`,
                    description: 'Changes applied in real-time',
                  });
                }
                break;
              case 'DELETE':
                config.onDelete?.(payload);
                if (config.showToasts) {
                  toast({
                    title: `${config.table.replace('_', ' ')} deleted`,
                    description: 'Record removed in real-time',
                  });
                }
                break;
            }
          }
        );
      });

      channel.subscribe((status) => {
        console.log(`Enhanced Realtime channel ${channelName} status:`, status);
      });
    });
  }, [configs]);

  useEffect(() => {
    setupChannels();

    return () => {
      // Clean up all channels on unmount
      channelsRef.current.forEach(channelName => {
        const channel = supabase.channel(channelName);
        supabase.removeChannel(channel);
      });
      channelsRef.current.clear();
    };
  }, [setupChannels]);

  return {
    reconnect: setupChannels
  };
};

// Enhanced specialized hooks with better error handling and performance
export const useEnhancedTradesRealtime = (
  userId?: string,
  onTradeInsert?: (trade: any) => void,
  onTradeUpdate?: (trade: any) => void,
  onTradeDelete?: (trade: any) => void
) => {
  return useEnhancedRealtime([{
    table: 'trades',
    userId,
    onInsert: (payload) => {
      onTradeInsert?.(payload);
      // Trigger metrics recalculation in the background
      triggerMetricsUpdate(payload.new.user_id);
    },
    onUpdate: (payload) => {
      onTradeUpdate?.(payload);
      // Trigger metrics recalculation in the background  
      triggerMetricsUpdate(payload.new.user_id);
    },
    onDelete: (payload) => {
      onTradeDelete?.(payload);
      // Trigger metrics recalculation in the background
      triggerMetricsUpdate(payload.old.user_id);
    },
    channelName: 'enhanced-trades-realtime'
  }]);
};

export const useEnhancedMetricsRealtime = (
  userId?: string,
  onMetricsUpdate?: (metrics: any) => void
) => {
  return useEnhancedRealtime([
    {
      table: 'metrics_summary',
      userId,
      onUpdate: onMetricsUpdate,
      channelName: 'enhanced-metrics-realtime'
    },
    {
      table: 'equity_snapshots',
      userId,
      onInsert: (payload) => {
        console.log('New equity snapshot:', payload.new);
      },
      channelName: 'enhanced-equity-realtime'
    }
  ]);
};

export const useEnhancedAccountsRealtime = (
  userId?: string,
  onAccountUpdate?: (account: any) => void
) => {
  return useEnhancedRealtime([{
    table: 'accounts',
    userId,
    onUpdate: onAccountUpdate,
    showToasts: true,
    channelName: 'enhanced-accounts-realtime'
  }]);
};

// Helper function to trigger metrics update
const triggerMetricsUpdate = async (userId: string) => {
  try {
    console.log('Triggering enhanced metrics update for user:', userId);
    
    // Call the real-time metrics engine
    const response = await supabase.functions.invoke('realtime-metrics-engine', {
      body: { 
        user_id: userId,
        trade_id: null
      }
    });

    if (response.error) {
      console.error('Error calling enhanced metrics engine:', response.error);
    } else {
      console.log('Enhanced metrics updated successfully:', response.data);
    }
  } catch (error) {
    console.error('Error triggering enhanced metrics update:', error);
  }
};