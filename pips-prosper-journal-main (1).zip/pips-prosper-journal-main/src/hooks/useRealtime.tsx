import { useEffect, useCallback } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { toast } from '@/hooks/use-toast';

export interface RealtimeConfig {
  table: string;
  events?: ('INSERT' | 'UPDATE' | 'DELETE')[];
  onInsert?: (payload: any) => void;
  onUpdate?: (payload: any) => void;
  onDelete?: (payload: any) => void;
  showToasts?: boolean;
  channelName?: string;
}

export const useRealtime = (configs: RealtimeConfig[]) => {
  const setupChannel = useCallback(() => {
    if (!configs.length) return null;

    const channelName = configs[0]?.channelName || `realtime-${Date.now()}`;
    const channel = supabase.channel(channelName);

    configs.forEach((config) => {
      const events = config.events || ['INSERT', 'UPDATE', 'DELETE'];

      events.forEach((event) => {
        channel.on(
          'postgres_changes' as any,
          {
            event,
            schema: 'public',
            table: config.table
          },
          (payload: any) => {
            console.log(`${event} on ${config.table}:`, payload);

            // Handle different events
            switch (event) {
              case 'INSERT':
                config.onInsert?.(payload);
                if (config.showToasts) {
                  toast({
                    title: `New ${config.table.replace('_', ' ')} created`,
                    description: 'Data updated in real-time',
                  });
                }
                break;
              case 'UPDATE':
                config.onUpdate?.(payload);
                if (config.showToasts) {
                  toast({
                    title: `${config.table.replace('_', ' ')} updated`,
                    description: 'Changes applied in real-time',
                  });
                }
                break;
              case 'DELETE':
                config.onDelete?.(payload);
                if (config.showToasts) {
                  toast({
                    title: `${config.table.replace('_', ' ')} deleted`,
                    description: 'Record removed in real-time',
                  });
                }
                break;
            }
          }
        );
      });
    });

    channel.subscribe();
    return channel;
  }, [configs]);

  useEffect(() => {
    const channel = setupChannel();

    return () => {
      if (channel) {
        supabase.removeChannel(channel);
      }
    };
  }, [setupChannel]);
};

// Specialized hooks for common use cases
export const useTradesRealtime = (
  onTradeInsert?: (trade: any) => void,
  onTradeUpdate?: (trade: any) => void,
  onTradeDelete?: (trade: any) => void
) => {
  useRealtime([{
    table: 'trades',
    onInsert: (payload) => {
      onTradeInsert?.(payload);
      // Trigger metrics recalculation in the background
      triggerMetricsUpdate(payload.new.user_id);
    },
    onUpdate: (payload) => {
      onTradeUpdate?.(payload);
      // Trigger metrics recalculation in the background  
      triggerMetricsUpdate(payload.new.user_id);
    },
    onDelete: (payload) => {
      onTradeDelete?.(payload);
      // Trigger metrics recalculation in the background
      triggerMetricsUpdate(payload.old.user_id);
    },
    channelName: 'trades-realtime'
  }]);
};

// Helper function to trigger metrics update
const triggerMetricsUpdate = async (userId: string) => {
  try {
    console.log('Triggering metrics update for user:', userId);
    
    // Call the real-time metrics engine
    const response = await supabase.functions.invoke('realtime-metrics-engine', {
      body: { 
        user_id: userId,
        trade_id: null // Can be specific trade ID if needed
      }
    });

    if (response.error) {
      console.error('Error calling metrics engine:', response.error);
    } else {
      console.log('Metrics updated successfully:', response.data);
    }
  } catch (error) {
    console.error('Error triggering metrics update:', error);
  }
};

export const useAccountsRealtime = (
  onAccountInsert?: (account: any) => void,
  onAccountUpdate?: (account: any) => void,
  onAccountDelete?: (account: any) => void
) => {
  useRealtime([{
    table: 'accounts',
    onInsert: onAccountInsert,
    onUpdate: onAccountUpdate,
    onDelete: onAccountDelete,
    channelName: 'accounts-realtime'
  }]);
};

export const useAffiliateRealtime = (
  onAffiliateInsert?: (affiliate: any) => void,
  onAffiliateUpdate?: (affiliate: any) => void,
  onCommissionInsert?: (commission: any) => void,
  onPayoutUpdate?: (payout: any) => void
) => {
  useRealtime([
    {
      table: 'affiliates',
      onInsert: onAffiliateInsert,
      onUpdate: onAffiliateUpdate,
      channelName: 'affiliate-realtime'
    },
    {
      table: 'commissions',
      onInsert: onCommissionInsert,
      channelName: 'affiliate-realtime'
    },
    {
      table: 'payouts',
      onUpdate: onPayoutUpdate,
      channelName: 'affiliate-realtime'
    }
  ]);
};

export const useSubscriberRealtime = (
  onSubscriberInsert?: (subscriber: any) => void,
  onSubscriberUpdate?: (subscriber: any) => void
) => {
  useRealtime([{
    table: 'subscribers',
    onInsert: onSubscriberInsert,
    onUpdate: onSubscriberUpdate,
    channelName: 'subscribers-realtime'
  }]);
};

export const useCrmRealtime = (
  onNoteInsert?: (note: any) => void,
  onProfileUpdate?: (profile: any) => void
) => {
  useRealtime([
    {
      table: 'crm_notes',
      onInsert: onNoteInsert,
      channelName: 'crm-realtime'
    },
    {
      table: 'profiles',
      onUpdate: onProfileUpdate,
      channelName: 'crm-realtime'
    }
  ]);
};