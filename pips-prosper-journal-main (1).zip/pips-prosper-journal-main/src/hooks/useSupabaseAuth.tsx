import { useState } from 'react';
import { useMutation, useQuery } from '@tanstack/react-query';
import { toast } from 'sonner';
import { 
  sendSignupConfirmation, 
  sendPasswordReset, 
  sendMagicLink, 
  inviteUser,
  subscribeToEmailLogs 
} from '@/lib/supabaseAuth';
import { supabase } from '@/integrations/supabase/client';

export function useSupabaseAuth() {
  const [isRateLimited, setIsRateLimited] = useState(false);

  const signupConfirmMutation = useMutation({
    mutationFn: ({ email, redirectTo }: { email: string; redirectTo?: string }) =>
      sendSignupConfirmation(email, redirectTo),
    onSuccess: (result, variables) => {
      if (result.success) {
        toast.success('Confirmation email sent! Check your inbox (and spam folder).');
      } else {
        toast.error(result.error || 'Failed to send confirmation email');
        if (result.error?.includes('Rate limit')) {
          setIsRateLimited(true);
          setTimeout(() => setIsRateLimited(false), 30000); // Re-enable after 30s
        }
      }
    },
    onError: (error: any) => {
      toast.error('Failed to send confirmation email: ' + error.message);
    }
  });

  const passwordResetMutation = useMutation({
    mutationFn: ({ email, redirectTo }: { email: string; redirectTo?: string }) =>
      sendPasswordReset(email, redirectTo),
    onSuccess: (result, variables) => {
      if (result.success) {
        toast.success('Password reset email sent! Check your inbox.');
      } else {
        toast.error(result.error || 'Failed to send password reset email');
        if (result.error?.includes('Rate limit')) {
          setIsRateLimited(true);
          setTimeout(() => setIsRateLimited(false), 30000);
        }
      }
    },
    onError: (error: any) => {
      toast.error('Failed to send password reset email: ' + error.message);
    }
  });

  const magicLinkMutation = useMutation({
    mutationFn: ({ email, redirectTo }: { email: string; redirectTo?: string }) =>
      sendMagicLink(email, redirectTo),
    onSuccess: (result, variables) => {
      if (result.success) {
        toast.success('Magic link sent! Check your inbox.');
      } else {
        toast.error(result.error || 'Failed to send magic link');
        if (result.error?.includes('Rate limit')) {
          setIsRateLimited(true);
          setTimeout(() => setIsRateLimited(false), 30000);
        }
      }
    },
    onError: (error: any) => {
      toast.error('Failed to send magic link: ' + error.message);
    }
  });

  const inviteUserMutation = useMutation({
    mutationFn: ({ email, redirectTo }: { email: string; redirectTo?: string }) =>
      inviteUser(email, redirectTo),
    onSuccess: (result, variables) => {
      if (result.success) {
        toast.success('Invitation sent successfully!');
      } else {
        toast.error(result.error || 'Failed to send invitation');
        if (result.error?.includes('Rate limit')) {
          setIsRateLimited(true);
          setTimeout(() => setIsRateLimited(false), 30000);
        }
      }
    },
    onError: (error: any) => {
      toast.error('Failed to send invitation: ' + error.message);
    }
  });

  // Resend functionality with debouncing
  const resendEmail = (type: 'signup' | 'password_reset' | 'magic_link' | 'invite', email: string, redirectTo?: string) => {
    if (isRateLimited) {
      toast.warning('Please wait before sending another email.');
      return;
    }

    switch (type) {
      case 'signup':
        signupConfirmMutation.mutate({ email, redirectTo });
        break;
      case 'password_reset':
        passwordResetMutation.mutate({ email, redirectTo });
        break;
      case 'magic_link':
        magicLinkMutation.mutate({ email, redirectTo });
        break;
      case 'invite':
        inviteUserMutation.mutate({ email, redirectTo });
        break;
    }
  };

  return {
    // Mutations
    signupConfirmMutation,
    passwordResetMutation,
    magicLinkMutation,
    inviteUserMutation,
    
    // Helper functions
    resendEmail,
    
    // State
    isRateLimited,
    
    // Loading states
    isLoading: signupConfirmMutation.isPending || 
               passwordResetMutation.isPending || 
               magicLinkMutation.isPending || 
               inviteUserMutation.isPending
  };
}

export function useEmailLogs() {
  const [logs, setLogs] = useState<any[]>([]);

  const { data, isLoading, error, refetch } = useQuery({
    queryKey: ['emailLogs'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('email_logs')
        .select('*')
        .order('created_at', { ascending: false })
        .limit(100);

      if (error) throw error;
      return data || [];
    }
  });

  // Set up real-time subscription
  const setupRealtimeSubscription = () => {
    return subscribeToEmailLogs((newLogs) => {
      setLogs(newLogs);
    });
  };

  return {
    logs: data || logs,
    isLoading,
    error,
    refetch,
    setupRealtimeSubscription
  };
}