import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/hooks/useAuth';

export function useAccountMetrics(accountId?: string | null) {
  const [metrics, setMetrics] = useState<any>(null);
  const [loading, setLoading] = useState(false);
  const { user } = useAuth();

  const fetchMetrics = async () => {
    if (!user) return;
    
    setLoading(true);
    
    try {
      let query = supabase
        .from('metrics_summary')
        .select('*')
        .eq('user_id', user.id);
      
      // If specific account selected, filter by account
      if (accountId && accountId !== 'all') {
        // For account-specific metrics, we'll need to calculate from trades
        const { data: trades } = await supabase
          .from('trades')
          .select('*')
          .eq('user_id', user.id)
          .eq('account_id', accountId)
          .not('closed_at', 'is', null);
        
        // Calculate metrics for this specific account
        const accountMetrics = calculateAccountMetrics(trades || []);
        setMetrics(accountMetrics);
      } else {
        // All accounts combined
        const { data } = await query.eq('scope', 'all_time').single();
        setMetrics(data);
      }
    } catch (error) {
      console.error('Error fetching account metrics:', error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchMetrics();
  }, [user, accountId]);

  return { metrics, loading, refetch: fetchMetrics };
}

function calculateAccountMetrics(trades: any[]) {
  if (!trades || trades.length === 0) {
    return {
      trade_count: 0,
      net_pnl: 0,
      win_rate: 0,
      avg_rr: 0,
      profit_factor: 0,
      expectancy: 0,
      max_dd: 0
    };
  }

  const closedTrades = trades.filter(t => t.closed_at && t.pnl !== null);
  const winningTrades = closedTrades.filter(t => t.pnl > 0);
  const losingTrades = closedTrades.filter(t => t.pnl < 0);
  
  const totalPnL = closedTrades.reduce((sum, t) => sum + (t.pnl || 0), 0);
  const grossProfit = winningTrades.reduce((sum, t) => sum + (t.pnl || 0), 0);
  const grossLoss = Math.abs(losingTrades.reduce((sum, t) => sum + (t.pnl || 0), 0));
  
  const winRate = closedTrades.length > 0 ? (winningTrades.length / closedTrades.length) * 100 : 0;
  const profitFactor = grossLoss > 0 ? grossProfit / grossLoss : 0;
  
  // Calculate average R:R ratio
  const avgRR = calculateAverageRR(closedTrades);
  
  // Calculate expectancy
  const avgWin = winningTrades.length > 0 ? grossProfit / winningTrades.length : 0;
  const avgLoss = losingTrades.length > 0 ? grossLoss / losingTrades.length : 0;
  const expectancy = (winRate / 100) * avgWin - ((100 - winRate) / 100) * avgLoss;
  
  return {
    trade_count: closedTrades.length,
    net_pnl: totalPnL,
    win_rate: winRate,
    avg_rr: avgRR,
    profit_factor: profitFactor,
    expectancy,
    max_dd: 0 // Would need equity snapshots to calculate properly
  };
}

function calculateAverageRR(trades: any[]) {
  const tradesWithRR = trades.filter(t => 
    t.entry_price && t.exit_price && t.stop_loss && t.take_profit
  );
  
  if (tradesWithRR.length === 0) return 0;
  
  const rrRatios = tradesWithRR.map(t => {
    const riskDistance = Math.abs(t.entry_price - t.stop_loss);
    const rewardDistance = Math.abs(t.take_profit - t.entry_price);
    return riskDistance > 0 ? rewardDistance / riskDistance : 0;
  });
  
  return rrRatios.reduce((sum, rr) => sum + rr, 0) / rrRatios.length;
}