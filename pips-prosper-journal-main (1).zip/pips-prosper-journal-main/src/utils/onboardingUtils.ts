// Utility functions for managing user onboarding

export const resetOnboardingForUser = (userId: string) => {
  localStorage.removeItem(`onboarding-completed-${userId}`)
  localStorage.removeItem(`last-login-${userId}`)
}

export const isOnboardingCompleted = (userId: string): boolean => {
  return Boolean(localStorage.getItem(`onboarding-completed-${userId}`))
}

export const markOnboardingCompleted = (userId: string) => {
  localStorage.setItem(`onboarding-completed-${userId}`, 'true')
}

export const isFirstTimeUser = (userId: string): boolean => {
  const completed = localStorage.getItem(`onboarding-completed-${userId}`)
  const lastLogin = localStorage.getItem(`last-login-${userId}`)
  return !completed && !lastLogin
}