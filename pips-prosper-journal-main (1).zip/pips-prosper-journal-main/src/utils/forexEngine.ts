import { supabase } from "@/integrations/supabase/client";

export interface ForexInstrument {
  id: string;
  symbol: string;
  class: string;
  pricingMode: string;
  baseCcy: string;
  quoteCcy: string;
  lotUnits: number;
  pipSize: number;
  pricePrecision: number;
  pipPrecision: number;
  description?: string;
  isActive: boolean;
}

export interface FxRate {
  fromCurrency: string;
  toCurrency: string;
  rate: number;
  updatedAt: string;
}

export interface ForexCalculationResult {
  pips: number;
  pipValue: number;
  rawPnL: number;
  convertedPnL: number;
  fxRateUsed: number;
  riskAmount: number;
  rewardAmount: number;
  riskRewardRatio: number;
  instrumentConfig: ForexInstrument;
  autoConfigured: boolean;
}

export interface TradeCalculationInput {
  symbol: string;
  side: 'long' | 'short';
  entryPrice: number;
  exitPrice?: number;
  stopLoss?: number;
  takeProfit?: number;
  lots: number;
  accountCurrency: string;
}

class ForexEngine {
  private instrumentsCache: Map<string, ForexInstrument> = new Map();
  private fxRatesCache: Map<string, number> = new Map();
  private lastFxUpdate = 0;
  private readonly CACHE_DURATION = 5 * 60 * 1000; // 5 minutes

  /**
   * Validate Forex symbol format
   */
  validateSymbol(symbol: string): { valid: boolean; error?: string } {
    const cleanSymbol = symbol.toUpperCase().replace(/[^A-Z]/g, '');
    
    if (cleanSymbol.length !== 6) {
      return { valid: false, error: 'Symbol must be exactly 6 letters (e.g., EURUSD)' };
    }

    const baseCcy = cleanSymbol.substring(0, 3);
    const quoteCcy = cleanSymbol.substring(3, 6);

    // Validate currency codes (basic check)
    const validCurrencies = ['USD', 'EUR', 'GBP', 'JPY', 'AUD', 'CAD', 'CHF', 'NZD', 'CNH', 'HKD', 'SGD', 'SEK', 'NOK', 'DKK', 'ZAR', 'MXN', 'TRY', 'PLN', 'HUF', 'CZK', 'INR', 'THB', 'MYR', 'IDR', 'PHP', 'KRW', 'TWD'];
    
    if (!validCurrencies.includes(baseCcy) || !validCurrencies.includes(quoteCcy)) {
      return { valid: false, error: `Unknown currency code. Base: ${baseCcy}, Quote: ${quoteCcy}` };
    }

    return { valid: true };
  }

  /**
   * Get or auto-configure instrument
   */
  async getInstrument(symbol: string): Promise<{ instrument: ForexInstrument; autoConfigured: boolean }> {
    const cleanSymbol = symbol.toUpperCase();
    
    // Check cache first
    if (this.instrumentsCache.has(cleanSymbol)) {
      return { 
        instrument: this.instrumentsCache.get(cleanSymbol)!, 
        autoConfigured: false 
      };
    }

    // Try to load from database
    const { data: dbInstrument } = await supabase
      .from('instruments')
      .select('*')
      .eq('symbol', cleanSymbol)
      .eq('is_active', true)
      .single();

    if (dbInstrument) {
      const instrument: ForexInstrument = {
        id: dbInstrument.id,
        symbol: dbInstrument.symbol,
        class: dbInstrument.class,
        pricingMode: dbInstrument.pricing_mode,
        baseCcy: dbInstrument.base_ccy,
        quoteCcy: dbInstrument.quote_ccy,
        lotUnits: Number(dbInstrument.lot_units),
        pipSize: Number(dbInstrument.pip_size),
        pricePrecision: dbInstrument.price_precision,
        pipPrecision: dbInstrument.pip_precision,
        description: dbInstrument.description,
        isActive: dbInstrument.is_active
      };
      
      this.instrumentsCache.set(cleanSymbol, instrument);
      return { instrument, autoConfigured: false };
    }

    // Auto-configure using fallback rules
    const validation = this.validateSymbol(cleanSymbol);
    if (!validation.valid) {
      throw new Error(validation.error);
    }

    const baseCcy = cleanSymbol.substring(0, 3);
    const quoteCcy = cleanSymbol.substring(3, 6);
    
    const autoInstrument: ForexInstrument = {
      id: `auto-${cleanSymbol}`,
      symbol: cleanSymbol,
      class: 'forex',
      pricingMode: 'forex',
      baseCcy,
      quoteCcy,
      lotUnits: 100000,
      pipSize: quoteCcy === 'JPY' ? 0.01 : 0.0001,
      pricePrecision: quoteCcy === 'JPY' ? 3 : 5,
      pipPrecision: quoteCcy === 'JPY' ? 2 : 1,
      description: `${baseCcy} vs ${quoteCcy} (Auto-configured)`,
      isActive: true
    };

    console.log(`Auto-configured instrument: ${cleanSymbol}`, autoInstrument);
    return { instrument: autoInstrument, autoConfigured: true };
  }

  /**
   * Get FX rate for currency conversion
   */
  async getFxRate(fromCcy: string, toCcy: string): Promise<number> {
    if (fromCcy === toCcy) return 1;

    const now = Date.now();
    const cacheKey = `${fromCcy}${toCcy}`;
    
    // Check cache first
    if (this.fxRatesCache.has(cacheKey) && (now - this.lastFxUpdate) < this.CACHE_DURATION) {
      return this.fxRatesCache.get(cacheKey)!;
    }

    // Try direct rate first
    let { data: directRate } = await supabase
      .from('fx_rates')
      .select('rate')
      .eq('from_currency', fromCcy)
      .eq('to_currency', toCcy)
      .eq('is_active', true)
      .single();

    if (directRate) {
      const rate = Number(directRate.rate);
      this.fxRatesCache.set(cacheKey, rate);
      this.lastFxUpdate = now;
      return rate;
    }

    // Try inverse rate
    let { data: inverseRate } = await supabase
      .from('fx_rates')
      .select('rate')
      .eq('from_currency', toCcy)
      .eq('to_currency', fromCcy)
      .eq('is_active', true)
      .single();

    if (inverseRate) {
      const rate = 1 / Number(inverseRate.rate);
      this.fxRatesCache.set(cacheKey, rate);
      this.lastFxUpdate = now;
      return rate;
    }

    // Try USD triangle if neither currency is USD
    if (fromCcy !== 'USD' && toCcy !== 'USD') {
      try {
        const fromToUsd = await this.getFxRate(fromCcy, 'USD');
        const usdToTarget = await this.getFxRate('USD', toCcy);
        const rate = fromToUsd * usdToTarget;
        this.fxRatesCache.set(cacheKey, rate);
        return rate;
      } catch (error) {
        console.warn(`Could not calculate ${fromCcy}/${toCcy} via USD`, error);
      }
    }

    throw new Error(`FX rate not found for ${fromCcy}/${toCcy}. Please add to FX rates table.`);
  }

  /**
   * Calculate comprehensive trade metrics
   */
  async calculateTrade(input: TradeCalculationInput): Promise<ForexCalculationResult> {
    const { instrument, autoConfigured } = await this.getInstrument(input.symbol);
    
    // Calculate pips
    let pips = 0;
    if (input.exitPrice) {
      pips = input.side === 'long' 
        ? (input.exitPrice - input.entryPrice) / instrument.pipSize
        : (input.entryPrice - input.exitPrice) / instrument.pipSize;
    }

    // Calculate pip value in quote currency
    const pipValue = instrument.lotUnits * instrument.pipSize;

    // Calculate raw PnL in quote currency
    const rawPnL = pips * pipValue * input.lots;

    // Get FX rate for conversion to account currency
    const fxRate = await this.getFxRate(instrument.quoteCcy, input.accountCurrency);
    const convertedPnL = rawPnL * fxRate;

    // Calculate risk/reward amounts
    let riskAmount = 0;
    let rewardAmount = 0;
    let riskRewardRatio = 0;

    if (input.stopLoss) {
      const riskPips = input.side === 'long'
        ? (input.entryPrice - input.stopLoss) / instrument.pipSize
        : (input.stopLoss - input.entryPrice) / instrument.pipSize;
      riskAmount = Math.abs(riskPips * pipValue * input.lots * fxRate);
    }

    if (input.takeProfit) {
      const rewardPips = input.side === 'long'
        ? (input.takeProfit - input.entryPrice) / instrument.pipSize
        : (input.entryPrice - input.takeProfit) / instrument.pipSize;
      rewardAmount = rewardPips * pipValue * input.lots * fxRate;
    }

    if (riskAmount > 0 && rewardAmount > 0) {
      riskRewardRatio = rewardAmount / riskAmount;
    }

    return {
      pips: Math.round(pips * Math.pow(10, instrument.pipPrecision)) / Math.pow(10, instrument.pipPrecision),
      pipValue: Math.round(pipValue * Math.pow(10, instrument.pricePrecision)) / Math.pow(10, instrument.pricePrecision),
      rawPnL: Math.round(rawPnL * 100) / 100,
      convertedPnL: Math.round(convertedPnL * 100) / 100,
      fxRateUsed: Math.round(fxRate * 100000) / 100000,
      riskAmount: Math.round(riskAmount * 100) / 100,
      rewardAmount: Math.round(rewardAmount * 100) / 100,
      riskRewardRatio: Math.round(riskRewardRatio * 100) / 100,
      instrumentConfig: instrument,
      autoConfigured
    };
  }

  /**
   * Persist auto-configured instrument to database
   */
  async persistAutoConfig(instrument: ForexInstrument): Promise<void> {
    const { error } = await supabase
      .from('instruments')
      .insert({
        symbol: instrument.symbol,
        class: instrument.class,
        pricing_mode: instrument.pricingMode,
        base_ccy: instrument.baseCcy,
        quote_ccy: instrument.quoteCcy,
        lot_units: instrument.lotUnits,
        pip_size: instrument.pipSize,
        price_precision: instrument.pricePrecision,
        pip_precision: instrument.pipPrecision,
        description: instrument.description?.replace(' (Auto-configured)', ''),
        is_active: true
      });

    if (error) {
      throw new Error(`Failed to persist instrument: ${error.message}`);
    }

    // Update cache with real ID
    this.instrumentsCache.delete(instrument.symbol);
  }

  /**
   * Clear caches
   */
  clearCache(): void {
    this.instrumentsCache.clear();
    this.fxRatesCache.clear();
    this.lastFxUpdate = 0;
  }
}

// Export singleton instance
export const forexEngine = new ForexEngine();

// Utility functions for unit tests
export const testCases = [
  {
    name: 'EURUSD Long 1.1000→1.1050',
    input: {
      symbol: 'EURUSD',
      side: 'long' as const,
      entryPrice: 1.1000,
      exitPrice: 1.1050,
      lots: 1,
      accountCurrency: 'USD'
    },
    expected: {
      pips: 50,
      rawPnL: 500, // 50 pips × $10 pip value
      convertedPnL: 500
    }
  },
  {
    name: 'USDJPY Long 150.00→149.00',
    input: {
      symbol: 'USDJPY',
      side: 'long' as const,
      entryPrice: 150.00,
      exitPrice: 149.00,
      lots: 1,
      accountCurrency: 'USD'
    },
    expected: {
      pips: -100,
      rawPnL: -100000, // -100 pips × ¥1,000 pip value
      convertedPnL: -666.67 // -¥100,000 ÷ 150 USDJPY rate
    }
  },
  {
    name: 'GBPJPY Long 180.00→181.50',
    input: {
      symbol: 'GBPJPY',
      side: 'long' as const,
      entryPrice: 180.00,
      exitPrice: 181.50,
      lots: 1,
      accountCurrency: 'USD'
    },
    expected: {
      pips: 150,
      rawPnL: 150000, // 150 pips × ¥1,000 pip value
      convertedPnL: 1000 // ¥150,000 ÷ 150 USDJPY rate
    }
  },
  {
    name: 'AUDCAD Long 0.8900→0.8800',
    input: {
      symbol: 'AUDCAD',
      side: 'long' as const,
      entryPrice: 0.8900,
      exitPrice: 0.8800,
      lots: 1,
      accountCurrency: 'USD'
    },
    expected: {
      pips: -100,
      rawPnL: -1000, // -100 pips × CAD$10 pip value
      convertedPnL: -740.74 // -CAD$1,000 ÷ 1.35 USDCAD rate
    }
  }
];