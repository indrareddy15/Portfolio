import { supabase } from '@/integrations/supabase/client';

export interface TradeCalculationInput {
  symbol: string;
  side: 'long' | 'short';
  entry_price: number;
  exit_price?: number;
  lots: number;
  commission?: number;
  swap?: number;
  fees?: number;
  account_ccy?: string;
  stop_loss?: number;
  take_profit?: number;
}

export interface PnLCalculationResult {
  raw_pnl_quote: number;
  fx_rate_used: number;
  pnl_account: number;
  pips_or_ticks: number;
  rr?: number;
  success: boolean;
  error?: string;
}

export interface TradingSession {
  session: string;
  start_hour: number;
  end_hour: number;
}

const TRADING_SESSIONS: TradingSession[] = [
  { session: 'Asian', start_hour: 22, end_hour: 8 }, // 22:00-08:00 UTC
  { session: 'London', start_hour: 8, end_hour: 16 }, // 08:00-16:00 UTC  
  { session: 'NY', start_hour: 13, end_hour: 21 }, // 13:00-21:00 UTC
];

export class PnLCalculationEngine {
  private fxRatesCache: Map<string, { rate: number; timestamp: number }> = new Map();
  private instrumentsCache: Map<string, any> = new Map();
  private cacheExpiry = 5 * 60 * 1000; // 5 minutes

  async calculatePnL(input: TradeCalculationInput): Promise<PnLCalculationResult> {
    try {
      const instrument = await this.getInstrument(input.symbol);
      if (!instrument.success) {
        return { 
          success: false, 
          error: instrument.error,
          raw_pnl_quote: 0,
          fx_rate_used: 1,
          pnl_account: 0,
          pips_or_ticks: 0
        };
      }

      const config = instrument.config;
      const { entry_price, exit_price, lots, side, account_ccy = 'USD' } = input;

      if (!exit_price) {
        return { 
          success: false, 
          error: 'Exit price required for PnL calculation',
          raw_pnl_quote: 0,
          fx_rate_used: 1,
          pnl_account: 0,
          pips_or_ticks: 0
        };
      }

      let pnl_quote = 0;
      let pips_or_ticks = 0;

      // Calculate based on pricing mode
      if (config.pricing_mode === 'forex') {
        // Forex calculation
        const pip_direction = side === 'long' ? 1 : -1;
        pips_or_ticks = ((exit_price - entry_price) / config.pip_size) * pip_direction;
        const pip_value_quote = config.lot_units * config.pip_size;
        pnl_quote = pips_or_ticks * pip_value_quote * lots;
      } else if (config.pricing_mode === 'contract') {
        // Contract-based (metals, oil, crypto CFD)
        const direction = side === 'long' ? 1 : -1;
        pnl_quote = (exit_price - entry_price) * direction * config.contract_size * lots;
        pips_or_ticks = (exit_price - entry_price) / config.tick_size * direction;
      } else if (config.pricing_mode === 'point') {
        // Point-based (indices)
        const direction = side === 'long' ? 1 : -1;
        pnl_quote = (exit_price - entry_price) * direction * config.point_value * lots;
        pips_or_ticks = (exit_price - entry_price) * direction;
      }

      // Get FX rate if needed
      let fx_rate_used = 1;
      let pnl_account = pnl_quote;

      if (account_ccy !== config.quote_ccy) {
        const fxResult = await this.getFxRate(config.quote_ccy, account_ccy);
        if (!fxResult.success) {
          return {
            success: false,
            error: `Cannot convert ${config.quote_ccy} to ${account_ccy}: ${fxResult.error}`,
            raw_pnl_quote: pnl_quote,
            fx_rate_used: 1,
            pnl_account: pnl_quote,
            pips_or_ticks
          };
        }
        fx_rate_used = fxResult.rate;
        pnl_account = pnl_quote * fx_rate_used;
      }

      // Apply commission, swap, and fees
      const total_costs = (input.commission || 0) + (input.swap || 0) + (input.fees || 0);
      const net_pnl_account = pnl_account - total_costs;

      // Calculate R:R if stop loss and take profit are provided
      let rr;
      if (input.stop_loss && input.take_profit) {
        const risk = Math.abs(entry_price - input.stop_loss) * lots * config.lot_units;
        const reward = Math.abs(input.take_profit - entry_price) * lots * config.lot_units;
        rr = risk > 0 ? reward / risk : 0;
      }

      return {
        success: true,
        raw_pnl_quote: pnl_quote,
        fx_rate_used,
        pnl_account: net_pnl_account,
        pips_or_ticks,
        rr
      };

    } catch (error) {
      return {
        success: false,
        error: `Calculation error: ${error}`,
        raw_pnl_quote: 0,
        fx_rate_used: 1,
        pnl_account: 0,
        pips_or_ticks: 0
      };
    }
  }

  private async getInstrument(symbol: string): Promise<{ success: boolean; config?: any; error?: string }> {
    const cacheKey = symbol;
    const cached = this.instrumentsCache.get(cacheKey);
    
    if (cached && (Date.now() - cached.timestamp < this.cacheExpiry)) {
      return { success: true, config: cached.config };
    }

    try {
      const { data, error } = await supabase
        .from('instruments')
        .select('*')
        .eq('symbol', symbol)
        .eq('is_active', true)
        .single();

      if (error) {
        // Create fallback configuration for forex pairs
        if (this.isForexPair(symbol)) {
          const fallbackConfig = this.createFallbackForexConfig(symbol);
          this.instrumentsCache.set(cacheKey, { 
            config: fallbackConfig, 
            timestamp: Date.now() 
          });
          return { success: true, config: fallbackConfig };
        }
        return { success: false, error: `Instrument ${symbol} not found` };
      }

      this.instrumentsCache.set(cacheKey, { 
        config: data, 
        timestamp: Date.now() 
      });
      return { success: true, config: data };

    } catch (error) {
      return { success: false, error: `Error fetching instrument: ${error}` };
    }
  }

  private async getFxRate(fromCcy: string, toCcy: string): Promise<{ success: boolean; rate?: number; error?: string }> {
    if (fromCcy === toCcy) {
      return { success: true, rate: 1 };
    }

    const cacheKey = `${fromCcy}_${toCcy}`;
    const cached = this.fxRatesCache.get(cacheKey);
    
    if (cached && (Date.now() - cached.timestamp < this.cacheExpiry)) {
      return { success: true, rate: cached.rate };
    }

    try {
      // Try direct rate
      const { data: directRate } = await supabase
        .from('fx_rates')
        .select('rate')
        .eq('from_currency', fromCcy)
        .eq('to_currency', toCcy)
        .eq('is_active', true)
        .single();

      if (directRate) {
        this.fxRatesCache.set(cacheKey, { 
          rate: directRate.rate, 
          timestamp: Date.now() 
        });
        return { success: true, rate: directRate.rate };
      }

      // Try inverse rate
      const { data: inverseRate } = await supabase
        .from('fx_rates')
        .select('rate')
        .eq('from_currency', toCcy)
        .eq('to_currency', fromCcy)
        .eq('is_active', true)
        .single();

      if (inverseRate) {
        const rate = 1 / inverseRate.rate;
        this.fxRatesCache.set(cacheKey, { 
          rate, 
          timestamp: Date.now() 
        });
        return { success: true, rate };
      }

      // Try triangular conversion via USD
      if (fromCcy !== 'USD' && toCcy !== 'USD') {
        const fromUsdResult = await this.getFxRate(fromCcy, 'USD');
        const usdToResult = await this.getFxRate('USD', toCcy);
        
        if (fromUsdResult.success && usdToResult.success) {
          const rate = fromUsdResult.rate! * usdToResult.rate!;
          this.fxRatesCache.set(cacheKey, { 
            rate, 
            timestamp: Date.now() 
          });
          return { success: true, rate };
        }
      }

      return { success: false, error: `No FX rate found for ${fromCcy}/${toCcy}` };

    } catch (error) {
      return { success: false, error: `Error fetching FX rate: ${error}` };
    }
  }

  private isForexPair(symbol: string): boolean {
    return symbol.length === 6 && /^[A-Z]{6}$/.test(symbol);
  }

  private createFallbackForexConfig(symbol: string) {
    const baseCcy = symbol.substring(0, 3);
    const quoteCcy = symbol.substring(3, 6);
    
    return {
      symbol,
      class: 'forex',
      pricing_mode: 'forex',
      base_ccy: baseCcy,
      quote_ccy: quoteCcy,
      lot_units: 100000,
      pip_size: quoteCcy === 'JPY' ? 0.01 : 0.0001,
      contract_size: 100000,
      point_value: 1,
      tick_size: quoteCcy === 'JPY' ? 0.01 : 0.0001,
      price_precision: quoteCcy === 'JPY' ? 3 : 5,
      pip_precision: 1,
      is_active: true
    };
  }

  getTradingSession(timestamp: Date): string {
    const utcHour = timestamp.getUTCHours();
    
    for (const session of TRADING_SESSIONS) {
      if (session.start_hour <= session.end_hour) {
        // Normal session (doesn't cross midnight)
        if (utcHour >= session.start_hour && utcHour < session.end_hour) {
          return session.session;
        }
      } else {
        // Session crosses midnight (like Asian session)
        if (utcHour >= session.start_hour || utcHour < session.end_hour) {
          return session.session;
        }
      }
    }
    
    return 'Other';
  }

  clearCache(): void {
    this.fxRatesCache.clear();
    this.instrumentsCache.clear();
  }
}

export const pnlEngine = new PnLCalculationEngine();