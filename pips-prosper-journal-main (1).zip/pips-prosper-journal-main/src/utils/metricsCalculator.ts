// Comprehensive trading metrics calculator with accurate formulas

import { supabase } from "@/integrations/supabase/client";

export interface InstrumentConfig {
  symbol: string;
  type: 'forex' | 'metal' | 'index' | 'crypto' | 'commodity';
  contractSize: number;
  pipSize: number;
  pipPrecision: number;
  baseCurrency: string;
  quoteCurrency: string;
}

// New interfaces for database-powered calculations
export interface TradeMetrics {
  totalTrades: number;
  winRate: number;
  profitFactor: number;
  averageRR: number;
  totalPnL: number;
  largestWin: number;
  largestLoss: number;
  averageWin: number;
  averageLoss: number;
  maxDrawdown: number;
  grossProfit: number;
  grossLoss: number;
  winCount: number;
  lossCount: number;
}

export interface AccountHealth {
  balanceScore: number;
  equityScore: number;
  marginScore: number;
  overallScore: number;
  status: 'healthy' | 'warning' | 'critical';
  marginUsage?: number;
  balanceGrowth?: number;
}

export interface PipCalculationParams {
  symbol: string;
  lots: number;
  accountCurrency?: string;
}

export interface PnLCalculationParams {
  symbol: string;
  side: 'long' | 'short';
  lots: number;
  entryPrice: number;
  exitPrice: number;
  commissionCents?: number;
  swapCents?: number;
  accountCurrency?: string;
}

export interface TradeData {
  id: string;
  account_id: string;
  symbol: string;
  direction: 'buy' | 'sell';
  entry_price: number;
  exit_price?: number;
  stop_loss?: number;
  take_profit?: number;
  lot_size: number;
  opened_at: string;
  closed_at?: string;
  pnl?: number;
  pips?: number;
  commission?: number;
  swap?: number;
}

export interface AccountBalance {
  account_id: string;
  balance: number;
  equity: number;
  currency: string;
}

// Instrument configurations
export const INSTRUMENT_CONFIGS: Record<string, InstrumentConfig> = {
  'EURUSD': { symbol: 'EURUSD', type: 'forex', contractSize: 100000, pipSize: 0.0001, pipPrecision: 4, baseCurrency: 'EUR', quoteCurrency: 'USD' },
  'GBPUSD': { symbol: 'GBPUSD', type: 'forex', contractSize: 100000, pipSize: 0.0001, pipPrecision: 4, baseCurrency: 'GBP', quoteCurrency: 'USD' },
  'USDJPY': { symbol: 'USDJPY', type: 'forex', contractSize: 100000, pipSize: 0.01, pipPrecision: 2, baseCurrency: 'USD', quoteCurrency: 'JPY' },
  'USDCHF': { symbol: 'USDCHF', type: 'forex', contractSize: 100000, pipSize: 0.0001, pipPrecision: 4, baseCurrency: 'USD', quoteCurrency: 'CHF' },
  'AUDUSD': { symbol: 'AUDUSD', type: 'forex', contractSize: 100000, pipSize: 0.0001, pipPrecision: 4, baseCurrency: 'AUD', quoteCurrency: 'USD' },
  'USDCAD': { symbol: 'USDCAD', type: 'forex', contractSize: 100000, pipSize: 0.0001, pipPrecision: 4, baseCurrency: 'USD', quoteCurrency: 'CAD' },
  'NZDUSD': { symbol: 'NZDUSD', type: 'forex', contractSize: 100000, pipSize: 0.0001, pipPrecision: 4, baseCurrency: 'NZD', quoteCurrency: 'USD' },
  'XAUUSD': { symbol: 'XAUUSD', type: 'metal', contractSize: 100, pipSize: 0.01, pipPrecision: 2, baseCurrency: 'XAU', quoteCurrency: 'USD' },
  'XAGUSD': { symbol: 'XAGUSD', type: 'metal', contractSize: 5000, pipSize: 0.001, pipPrecision: 3, baseCurrency: 'XAG', quoteCurrency: 'USD' },
  'US30': { symbol: 'US30', type: 'index', contractSize: 1, pipSize: 1, pipPrecision: 0, baseCurrency: 'USD', quoteCurrency: 'USD' },
  'SPX500': { symbol: 'SPX500', type: 'index', contractSize: 1, pipSize: 0.1, pipPrecision: 1, baseCurrency: 'USD', quoteCurrency: 'USD' },
  'NAS100': { symbol: 'NAS100', type: 'index', contractSize: 1, pipSize: 0.1, pipPrecision: 1, baseCurrency: 'USD', quoteCurrency: 'USD' },
  'BTCUSD': { symbol: 'BTCUSD', type: 'crypto', contractSize: 1, pipSize: 1, pipPrecision: 0, baseCurrency: 'BTC', quoteCurrency: 'USD' },
  'ETHUSD': { symbol: 'ETHUSD', type: 'crypto', contractSize: 1, pipSize: 0.01, pipPrecision: 2, baseCurrency: 'ETH', quoteCurrency: 'USD' },
};

// Get instrument config with fallback
export function getInstrumentConfig(symbol: string): InstrumentConfig {
  return INSTRUMENT_CONFIGS[symbol] || {
    symbol,
    type: 'forex',
    contractSize: 100000,
    pipSize: 0.0001,
    pipPrecision: 4,
    baseCurrency: symbol.substring(0, 3),
    quoteCurrency: symbol.substring(3, 6)
  };
}

// Calculate pip value for a trade
export function calculatePipValue(
  symbol: string,
  lotSize: number,
  accountCurrency: string = 'USD',
  exchangeRate: number = 1
): number {
  const config = getInstrumentConfig(symbol);
  
  // Base pip value in quote currency
  let pipValue = config.pipSize * lotSize * config.contractSize;
  
  // Convert to account currency if needed
  if (config.quoteCurrency !== accountCurrency) {
    pipValue = pipValue / exchangeRate;
  }
  
  return pipValue;
}

// Calculate pips for a trade
export function calculatePips(
  symbol: string,
  entryPrice: number,
  exitPrice: number,
  direction: 'buy' | 'sell'
): number {
  const config = getInstrumentConfig(symbol);
  const priceDiff = direction === 'buy' ? exitPrice - entryPrice : entryPrice - exitPrice;
  return priceDiff / config.pipSize;
}

// Calculate P&L for a trade
export function calculatePnL(
  symbol: string,
  entryPrice: number,
  exitPrice: number,
  direction: 'buy' | 'sell',
  lotSize: number,
  accountCurrency: string = 'USD',
  exchangeRate: number = 1
): { pnl: number; pips: number } {
  const config = getInstrumentConfig(symbol);
  const pips = calculatePips(symbol, entryPrice, exitPrice, direction);
  const pipValue = calculatePipValue(symbol, lotSize, accountCurrency, exchangeRate);
  const pnl = pips * pipValue;
  
  return { pnl, pips };
}

// Calculate risk percentage for a trade
export function calculateRiskPercent(
  symbol: string,
  entryPrice: number,
  stopLoss: number,
  lotSize: number,
  accountBalance: number,
  accountCurrency: string = 'USD',
  exchangeRate: number = 1
): number {
  if (!stopLoss || stopLoss === 0) return 0;
  
  const config = getInstrumentConfig(symbol);
  const pipsAtRisk = Math.abs(entryPrice - stopLoss) / config.pipSize;
  const pipValue = calculatePipValue(symbol, lotSize, accountCurrency, exchangeRate);
  const riskAmount = pipsAtRisk * pipValue;
  
  return (riskAmount / accountBalance) * 100;
}

// Calculate risk-reward ratio
export function calculateRiskRewardRatio(
  entryPrice: number,
  stopLoss?: number,
  takeProfit?: number
): number {
  if (!stopLoss || !takeProfit || stopLoss === 0 || takeProfit === 0) return 0;
  
  const risk = Math.abs(entryPrice - stopLoss);
  const reward = Math.abs(takeProfit - entryPrice);
  
  return risk > 0 ? reward / risk : 0;
}

// Calculate trading metrics for a set of trades
export interface TradingMetrics {
  totalTrades: number;
  winningTrades: number;
  losingTrades: number;
  winRate: number;
  totalPnL: number;
  totalPips: number;
  averageWin: number;
  averageLoss: number;
  largestWin: number;
  largestLoss: number;
  profitFactor: number;
  averageRR: number;
  maxDrawdown: number;
  maxRunup: number;
  expectancy: number;
  sharpeRatio: number;
  longestWinStreak: number;
  longestLossStreak: number;
}

export function calculateTradingMetrics(
  trades: TradeData[],
  accountBalance: number = 10000
): TradingMetrics {
  const closedTrades = trades.filter(t => t.exit_price && t.closed_at);
  
  if (closedTrades.length === 0) {
    return {
      totalTrades: 0,
      winningTrades: 0,
      losingTrades: 0,
      winRate: 0,
      totalPnL: 0,
      totalPips: 0,
      averageWin: 0,
      averageLoss: 0,
      largestWin: 0,
      largestLoss: 0,
      profitFactor: 0,
      averageRR: 0,
      maxDrawdown: 0,
      maxRunup: 0,
      expectancy: 0,
      sharpeRatio: 0,
      longestWinStreak: 0,
      longestLossStreak: 0,
    };
  }

  // Calculate P&L and pips for each trade
  const tradesWithMetrics = closedTrades.map(trade => {
    const { pnl, pips } = calculatePnL(
      trade.symbol,
      trade.entry_price,
      trade.exit_price!,
      trade.direction,
      trade.lot_size
    );
    
    const riskReward = calculateRiskRewardRatio(
      trade.entry_price,
      trade.stop_loss,
      trade.take_profit
    );

    return {
      ...trade,
      calculatedPnL: pnl - (trade.commission || 0) - (trade.swap || 0),
      calculatedPips: pips,
      riskReward
    };
  });

  const totalTrades = tradesWithMetrics.length;
  const wins = tradesWithMetrics.filter(t => t.calculatedPnL > 0);
  const losses = tradesWithMetrics.filter(t => t.calculatedPnL < 0);
  
  const totalPnL = tradesWithMetrics.reduce((sum, t) => sum + t.calculatedPnL, 0);
  const totalPips = tradesWithMetrics.reduce((sum, t) => sum + t.calculatedPips, 0);
  
  const grossWins = wins.reduce((sum, t) => sum + t.calculatedPnL, 0);
  const grossLosses = Math.abs(losses.reduce((sum, t) => sum + t.calculatedPnL, 0));
  
  const averageWin = wins.length > 0 ? grossWins / wins.length : 0;
  const averageLoss = losses.length > 0 ? grossLosses / losses.length : 0;
  
  const largestWin = wins.length > 0 ? Math.max(...wins.map(t => t.calculatedPnL)) : 0;
  const largestLoss = losses.length > 0 ? Math.min(...losses.map(t => t.calculatedPnL)) : 0;
  
  const profitFactor = grossLosses > 0 ? grossWins / grossLosses : grossWins > 0 ? 999 : 0;
  
  const averageRR = tradesWithMetrics
    .filter(t => t.riskReward > 0)
    .reduce((sum, t) => sum + t.riskReward, 0) / 
    Math.max(1, tradesWithMetrics.filter(t => t.riskReward > 0).length);
  
  // Calculate drawdown
  let runningBalance = accountBalance;
  let peak = accountBalance;
  let maxDrawdown = 0;
  let maxRunup = 0;

  for (const trade of tradesWithMetrics) {
    runningBalance += trade.calculatedPnL;
    if (runningBalance > peak) {
      peak = runningBalance;
    }
    const drawdown = ((peak - runningBalance) / peak) * 100;
    maxDrawdown = Math.max(maxDrawdown, drawdown);
    
    const runup = ((runningBalance - accountBalance) / accountBalance) * 100;
    maxRunup = Math.max(maxRunup, runup);
  }

  // Calculate expectancy
  const winRate = totalTrades > 0 ? (wins.length / totalTrades) * 100 : 0;
  const expectancy = (winRate / 100) * averageWin - ((100 - winRate) / 100) * averageLoss;

  // Calculate streaks
  let currentStreak = 0;
  let longestWinStreak = 0;
  let longestLossStreak = 0;
  let currentWinStreak = 0;
  let currentLossStreak = 0;

  tradesWithMetrics.forEach(trade => {
    if (trade.calculatedPnL > 0) {
      currentWinStreak++;
      currentLossStreak = 0;
      longestWinStreak = Math.max(longestWinStreak, currentWinStreak);
    } else {
      currentLossStreak++;
      currentWinStreak = 0;
      longestLossStreak = Math.max(longestLossStreak, currentLossStreak);
    }
  });

  // Simple Sharpe ratio calculation (would need risk-free rate for accuracy)
  const returns = tradesWithMetrics.map(t => (t.calculatedPnL / accountBalance) * 100);
  const avgReturn = returns.reduce((sum, r) => sum + r, 0) / returns.length;
  const returnStdDev = Math.sqrt(
    returns.reduce((sum, r) => sum + Math.pow(r - avgReturn, 2), 0) / returns.length
  );
  const sharpeRatio = returnStdDev > 0 ? avgReturn / returnStdDev : 0;

  return {
    totalTrades,
    winningTrades: wins.length,
    losingTrades: losses.length,
    winRate: Math.round(winRate * 100) / 100,
    totalPnL: Math.round(totalPnL * 100) / 100,
    totalPips: Math.round(totalPips * 100) / 100,
    averageWin: Math.round(averageWin * 100) / 100,
    averageLoss: Math.round(averageLoss * 100) / 100,
    largestWin: Math.round(largestWin * 100) / 100,
    largestLoss: Math.round(largestLoss * 100) / 100,
    profitFactor: Math.round(profitFactor * 100) / 100,
    averageRR: Math.round(averageRR * 100) / 100,
    maxDrawdown: Math.round(maxDrawdown * 100) / 100,
    maxRunup: Math.round(maxRunup * 100) / 100,
    expectancy: Math.round(expectancy * 100) / 100,
    sharpeRatio: Math.round(sharpeRatio * 100) / 100,
    longestWinStreak,
    longestLossStreak,
  };
}

// ============= New Database-Powered Functions =============

/**
 * Calculate pip value using database function and instrument data
 */
export async function calculatePipValueDB(params: PipCalculationParams): Promise<number> {
  try {
    const { data, error } = await supabase
      .from('instruments')
      .select('pip_size, contract_size, quote_ccy')
      .eq('symbol', params.symbol)
      .single();

    if (error || !data) {
      // Fallback to local calculation
      return calculatePipValue(params.symbol, params.lots, params.accountCurrency);
    }

    // Calculate pip value manually using database data
    const pipValue = parseFloat(data.pip_size.toString()) * params.lots * parseFloat(data.contract_size.toString());
    
    // For now, assume no currency conversion needed (can be enhanced later)
    return pipValue;
  } catch (error) {
    console.error('Error calculating pip value:', error);
    return calculatePipValue(params.symbol, params.lots, params.accountCurrency);
  }
}

/**
 * Calculate trade PnL using database function and FX rates
 */
export async function calculateTradePnLDB(params: PnLCalculationParams): Promise<number> {
  try {
    const { data, error } = await supabase
      .from('instruments')
      .select('pip_size, contract_size, quote_ccy')
      .eq('symbol', params.symbol)
      .single();

    if (error || !data) {
      // Fallback to local calculation
      const direction = params.side === 'long' ? 'buy' : 'sell';
      const result = calculatePnL(
        params.symbol,
        params.entryPrice,
        params.exitPrice,
        direction,
        params.lots,
        params.accountCurrency
      );
      return Math.round(result.pnl * 100); // Convert to cents
    }

    // Calculate PnL manually
    const direction = params.side === 'long' ? 1 : -1;
    const priceDiff = (params.exitPrice - params.entryPrice) * direction;
    const contractSize = parseFloat(data.contract_size.toString());
    const pnl = priceDiff * params.lots * contractSize;
    const pnlCents = Math.round(pnl * 100) - (params.commissionCents || 0) - (params.swapCents || 0);
    
    return pnlCents;
  } catch (error) {
    console.error('Error calculating PnL:', error);
    const direction = params.side === 'long' ? 'buy' : 'sell';
    const result = calculatePnL(
      params.symbol,
      params.entryPrice,
      params.exitPrice,
      direction,
      params.lots,
      params.accountCurrency
    );
    return Math.round(result.pnl * 100);
  }
}

/**
 * Get comprehensive metrics for an account using trades data
 */
export async function getAccountMetricsDB(
  accountId: string,
  fromDate?: string,
  toDate?: string
): Promise<TradeMetrics | null> {
  try {
    let query = supabase
      .from('trades')
      .select('*')
      .eq('account_id', accountId)
      .not('closed_at', 'is', null);

    if (fromDate) {
      query = query.gte('opened_at', fromDate);
    }
    if (toDate) {
      query = query.lte('opened_at', toDate);
    }

    const { data: trades, error } = await query;

    if (error) {
      console.error('Error fetching trades for metrics:', error);
      return null;
    }

    if (!trades || trades.length === 0) {
      return {
        totalTrades: 0,
        winRate: 0,
        profitFactor: 0,
        averageRR: 0,
        totalPnL: 0,
        largestWin: 0,
        largestLoss: 0,
        averageWin: 0,
        averageLoss: 0,
        maxDrawdown: 0,
        grossProfit: 0,
        grossLoss: 0,
        winCount: 0,
        lossCount: 0,
      };
    }

    // Calculate metrics from trades
    const winningTrades = trades.filter(t => (t.pnl || 0) > 0);
    const losingTrades = trades.filter(t => (t.pnl || 0) < 0);
    
    const totalPnL = trades.reduce((sum, t) => sum + (t.pnl || 0), 0);
    const grossProfit = winningTrades.reduce((sum, t) => sum + (t.pnl || 0), 0);
    const grossLoss = Math.abs(losingTrades.reduce((sum, t) => sum + (t.pnl || 0), 0));
    
    const profitFactor = grossLoss > 0 ? grossProfit / grossLoss : grossProfit > 0 ? 999 : 0;
    const winRate = trades.length > 0 ? (winningTrades.length / trades.length) * 100 : 0;
    
    return {
      totalTrades: trades.length,
      winCount: winningTrades.length,
      lossCount: losingTrades.length,
      winRate,
      totalPnL,
      grossProfit,
      grossLoss,
      profitFactor,
      averageRR: 0, // Calculate from stop loss and take profit data if available
      maxDrawdown: 0, // Would need equity curve calculation
      largestWin: winningTrades.length > 0 ? Math.max(...winningTrades.map(t => t.pnl || 0)) : 0,
      largestLoss: losingTrades.length > 0 ? Math.min(...losingTrades.map(t => t.pnl || 0)) : 0,
      averageWin: winningTrades.length > 0 ? grossProfit / winningTrades.length : 0,
      averageLoss: losingTrades.length > 0 ? grossLoss / losingTrades.length : 0,
    };
  } catch (error) {
    console.error('Error calculating account metrics:', error);
    return null;
  }
}

/**
 * Calculate account health score
 */
export function getAccountHealth(accountData: {
  balance?: number;
  equity?: number;
  freeMargin?: number;
  margin?: number;
  balanceCents?: number;
  equityCents?: number;
  freeMarginCents?: number;
  marginPct?: number;
}): AccountHealth {
  const balance = accountData.balance || (accountData.balanceCents ? accountData.balanceCents / 100 : 10000);
  const equity = accountData.equity || (accountData.equityCents ? accountData.equityCents / 100 : balance);
  const marginUsage = accountData.marginPct || 0;
  
  // Balance vs Equity score (0-100)
  const equityRatio = balance > 0 ? equity / balance : 1;
  const balanceScore = Math.max(0, Math.min(100, equityRatio * 100));
  
  // Equity score based on drawdown (0-100)
  const equityScore = Math.max(0, Math.min(100, equityRatio * 100));
  
  // Margin usage score (0-100, lower usage = higher score)
  const marginScore = Math.max(0, 100 - (marginUsage * 2));
  
  // Overall health score
  const overallScore = (balanceScore + equityScore + marginScore) / 3;
  
  // Determine status
  let status: 'healthy' | 'warning' | 'critical' = 'healthy';
  if (overallScore < 30) status = 'critical';
  else if (overallScore < 70) status = 'warning';
  
  return {
    balanceScore: Math.round(balanceScore),
    equityScore: Math.round(equityScore),
    marginScore: Math.round(marginScore),
    overallScore: Math.round(overallScore),
    status,
    marginUsage,
    balanceGrowth: equityRatio > 1 ? ((equityRatio - 1) * 100) : -((1 - equityRatio) * 100)
  };
}

/**
 * Get instruments from database
 */
export async function getInstrumentsDB(): Promise<InstrumentConfig[]> {
  const { data, error } = await supabase
    .from('instruments')
    .select('*')
    .eq('is_active', true);

  if (error) {
    console.error('Error fetching instruments:', error);
    return [];
  }

  return data.map(item => ({
    symbol: item.symbol,
    type: item.class as 'forex' | 'metal' | 'index' | 'crypto' | 'commodity',
    contractSize: parseFloat(item.contract_size.toString()),
    pipSize: parseFloat(item.pip_size.toString()),
    pipPrecision: item.pip_precision,
    baseCurrency: item.base_ccy,
    quoteCurrency: item.quote_ccy,
  }));
}