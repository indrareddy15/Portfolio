// Utility functions for handling subdomain navigation

export const getSubdomainUrl = (subdomain: 'app' | 'admin', path: string = '') => {
  const hostname = window.location.hostname;
  const protocol = window.location.protocol;
  const port = window.location.port;
  
  // For development (localhost)
  if (hostname.includes('localhost') || hostname.includes('127.0.0.1')) {
    const baseUrl = `${protocol}//${subdomain}.piptrackr.localhost`;
    return port ? `${baseUrl}:${port}${path}` : `${baseUrl}${path}`;
  }
  
  // For Lovable preview
  if (hostname.includes('lovable.app')) {
    // For Lovable preview, we'll use relative paths
    return path.startsWith('/') ? path : `/${path}`;
  }
  
  // For production
  return `https://${subdomain}.piptrackr.com${path}`;
};

export const navigateToSubdomain = (subdomain: 'app' | 'admin', path: string = '') => {
  const url = getSubdomainUrl(subdomain, path);
  window.location.href = url;
};

export const isCurrentSubdomain = (subdomain: 'app' | 'admin') => {
  const hostname = window.location.hostname;
  return hostname.includes(`${subdomain}.piptrackr`) || 
         hostname.includes(`${subdomain}.localhost`) ||
         (hostname.includes('lovable.app') && window.location.pathname.startsWith(`/${subdomain}`));
};