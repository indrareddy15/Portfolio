import { useState, useEffect } from "react";
import { useParams, Link } from "react-router-dom";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { SEOHead } from "@/components/SEOHead";
import { Navigation } from "@/components/Navigation";
import { Footer } from "@/components/Footer";
import { supabase } from "@/integrations/supabase/client";
import { 
  Calendar, 
  Clock, 
  User, 
  Share2, 
  ArrowLeft, 
  Facebook, 
  Twitter, 
  Linkedin,
  Copy,
  Check
} from "lucide-react";
import { format } from "date-fns";
import { toast } from "sonner";

interface BlogPost {
  id: string;
  title: string;
  slug: string;
  excerpt?: string;
  cover_url?: string;
  body_md: string;
  reading_time: number;
  publish_at: string;
  meta_title?: string;
  meta_description?: string;
  og_title?: string;
  og_description?: string;
  og_image_url?: string;
  canonical_url?: string;
  category: {
    name: string;
    slug: string;
  };
  author: {
    name: string;
    slug: string;
    avatar_url?: string;
    bio?: string;
  };
  tags: Array<{
    name: string;
    slug: string;
  }>;
}

interface RelatedPost {
  id: string;
  title: string;
  slug: string;
  excerpt?: string;
  cover_url?: string;
  reading_time: number;
  category: {
    name: string;
    slug: string;
  };
}

export default function BlogPost() {
  const { slug } = useParams<{ slug: string }>();
  const [post, setPost] = useState<BlogPost | null>(null);
  const [relatedPosts, setRelatedPosts] = useState<RelatedPost[]>([]);
  const [loading, setLoading] = useState(true);
  const [copiedLink, setCopiedLink] = useState(false);

  useEffect(() => {
    if (slug) {
      fetchPost();
    }
  }, [slug]);

  // Realtime updates for single post
  useEffect(() => {
    if (!slug) return;

    const channel = supabase
      .channel('blog-post-single')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'blog_posts', filter: `slug=eq.${slug}` }, () => {
        fetchPost();
      })
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [slug]);

  const fetchPost = async () => {
    if (!slug) return;
    
    setLoading(true);
    
    try {
      const nowIso = new Date().toISOString();
      // Fetch the main post
      const { data: postData, error } = await supabase
        .from('blog_posts')
        .select(`
          id,
          title,
          slug,
          excerpt,
          cover_url,
          body_md,
          reading_time,
          publish_at,
          meta_title,
          meta_description,
          og_title,
          og_description,
          og_image_url,
          canonical_url,
          category_id,
          category:blog_categories(name, slug),
          author:blog_authors(name, slug, avatar_url, bio),
          blog_post_tags(
            tag:blog_tags(name, slug)
          )
        `)
        .eq('slug', slug)
        .eq('status', 'published')
        .or(`publish_at.is.null,publish_at.lte.${nowIso}`)
        .maybeSingle();

      if (error || !postData) {
        console.error('Post not found:', error);
        return;
      }

      // Transform the post data
      const transformedPost = {
        ...postData,
        tags: postData.blog_post_tags?.map((pt: any) => pt.tag) || []
      };

      setPost(transformedPost);

      // Fetch related posts from the same category
      if (postData.category_id) {
        const { data: relatedData } = await supabase
          .from('blog_posts')
          .select(`
            id,
            title,
            slug,
            excerpt,
            cover_url,
            reading_time,
            category:blog_categories(name, slug)
          `)
          .eq('category_id', postData.category_id)
          .neq('id', postData.id)
          .eq('status', 'published')
          .or(`publish_at.is.null,publish_at.lte.${nowIso}`)
          .order('publish_at', { ascending: false })
          .limit(3);

        setRelatedPosts(relatedData || []);
      }
      
    } catch (error) {
      console.error('Error fetching post:', error);
    } finally {
      setLoading(false);
    }
  };

  const shareUrl = window.location.href;
  const shareTitle = post?.title || "";
  
  const copyLink = async () => {
    try {
      await navigator.clipboard.writeText(shareUrl);
      setCopiedLink(true);
      toast.success("Link copied to clipboard!");
      setTimeout(() => setCopiedLink(false), 2000);
    } catch (error) {
      toast.error("Failed to copy link");
    }
  };

  const shareOnSocial = (platform: string) => {
    let url = "";
    
    switch (platform) {
      case "twitter":
        url = `https://twitter.com/intent/tweet?text=${encodeURIComponent(shareTitle)}&url=${encodeURIComponent(shareUrl)}`;
        break;
      case "facebook":
        url = `https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(shareUrl)}`;
        break;
      case "linkedin":
        url = `https://www.linkedin.com/sharing/share-offsite/?url=${encodeURIComponent(shareUrl)}`;
        break;
    }
    
    if (url) {
      window.open(url, "_blank", "width=600,height=400");
    }
  };

  const renderMarkdown = (markdown: string) => {
    // Simple markdown rendering - in production, use a proper markdown parser
    return markdown
      .replace(/^# (.*$)/gim, '<h1 class="text-3xl font-bold mb-4 mt-8 first:mt-0">$1</h1>')
      .replace(/^## (.*$)/gim, '<h2 class="text-2xl font-semibold mb-3 mt-6">$1</h2>')
      .replace(/^### (.*$)/gim, '<h3 class="text-xl font-medium mb-2 mt-4">$1</h3>')
      .replace(/\*\*(.*)\*\*/gim, '<strong class="font-semibold">$1</strong>')
      .replace(/\*(.*)\*/gim, '<em class="italic">$1</em>')
      .replace(/^\* (.*$)/gim, '<li class="ml-4">$1</li>')
      .replace(/^(\d+)\. (.*$)/gim, '<li class="ml-4">$2</li>')
      .replace(/\n\n/g, '</p><p class="mb-4">')
      .replace(/^/, '<p class="mb-4">')
      .replace(/$/, '</p>');
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-background">
        <Navigation />
        <main className="container mx-auto px-4 py-8 pt-24 max-w-4xl">
          <div className="animate-pulse">
            <div className="h-8 bg-muted rounded mb-4"></div>
            <div className="h-64 bg-muted rounded mb-8"></div>
            <div className="space-y-4">
              {[...Array(10)].map((_, i) => (
                <div key={i} className="h-4 bg-muted rounded w-full"></div>
              ))}
            </div>
          </div>
        </main>
        <Footer />
      </div>
    );
  }

  if (!post) {
    return (
      <div className="min-h-screen bg-background">
        <Navigation />
        <main className="container mx-auto px-4 py-8 pt-24 max-w-4xl">
          <div className="text-center py-12">
            <h1 className="text-2xl font-bold text-muted-foreground mb-4">
              Post not found
            </h1>
            <p className="text-muted-foreground mb-6">
              The blog post you're looking for doesn't exist or has been removed.
            </p>
            <Link to="/blog">
              <Button variant="outline">
                <ArrowLeft className="w-4 h-4 mr-2" />
                Back to Blog
              </Button>
            </Link>
          </div>
        </main>
        <Footer />
      </div>
    );
  }

  const seoTitle = post.meta_title || post.og_title || post.title;
  const seoDescription = post.meta_description || post.og_description || post.excerpt || "";
  const seoImage = post.og_image_url || post.cover_url || "";

  return (
    <div className="min-h-screen bg-background">
      <SEOHead
        title={`${seoTitle} | PipTrackr Blog`}
        description={seoDescription}
        keywords={post.tags.map(tag => tag.name).join(', ')}
        canonical={post.canonical_url || `${window.location.origin}/blog/${post.slug}`}
      />
      
      <Navigation />
      
      <main className="container mx-auto px-4 py-8 pt-24 max-w-4xl">
        {/* Back Navigation */}
        <div className="mb-8">
          <Link to="/blog" className="inline-flex items-center text-muted-foreground hover:text-foreground transition-colors">
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back to Blog
          </Link>
        </div>

        <article>
          {/* Header */}
          <header className="mb-8">
            <div className="flex items-center gap-2 mb-4">
              <Badge variant="secondary">
                {post.category.name}
              </Badge>
              <span className="text-sm text-muted-foreground flex items-center gap-1">
                <Clock className="w-3 h-3" />
                {post.reading_time} min read
              </span>
            </div>
            
            <h1 className="text-4xl font-bold tracking-tight mb-6">
              {post.title}
            </h1>
            
            {post.excerpt && (
              <p className="text-xl text-muted-foreground mb-6 leading-relaxed">
                {post.excerpt}
              </p>
            )}
            
            {/* Author and Date */}
            <div className="flex items-center justify-between flex-wrap gap-4">
              <div className="flex items-center gap-3">
                {post.author.avatar_url && (
                  <img 
                    src={post.author.avatar_url}
                    alt={post.author.name}
                    className="w-12 h-12 rounded-full"
                  />
                )}
                <div>
                  <p className="font-medium">{post.author.name}</p>
                  <div className="flex items-center gap-1 text-sm text-muted-foreground">
                    <Calendar className="w-3 h-3" />
                    {new Date(post.publish_at).toLocaleDateString('en-US', { 
                      year: 'numeric', 
                      month: 'long', 
                      day: 'numeric' 
                    })}
                  </div>
                </div>
              </div>
              
              {/* Share Buttons */}
              <div className="flex items-center gap-2">
                <span className="text-sm text-muted-foreground mr-2">Share:</span>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => shareOnSocial("twitter")}
                >
                  <Twitter className="w-4 h-4" />
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => shareOnSocial("facebook")}
                >
                  <Facebook className="w-4 h-4" />
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => shareOnSocial("linkedin")}
                >
                  <Linkedin className="w-4 h-4" />
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={copyLink}
                >
                  {copiedLink ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
                </Button>
              </div>
            </div>
          </header>

          {/* Cover Image */}
          {post.cover_url && (
            <div className="mb-8">
              <img 
                src={post.cover_url}
                alt={post.title}
                className="w-full aspect-video object-cover rounded-lg"
              />
            </div>
          )}

          {/* Content */}
          <div 
            className="prose prose-lg max-w-none mb-8"
            dangerouslySetInnerHTML={{ __html: renderMarkdown(post.body_md) }}
          />

          {/* Tags */}
          {post.tags.length > 0 && (
            <div className="mb-8">
              <h3 className="text-sm font-medium text-muted-foreground mb-3">Tags:</h3>
              <div className="flex flex-wrap gap-2">
                {post.tags.map(tag => (
                  <Link key={tag.slug} to={`/blog?tag=${tag.slug}`}>
                    <Badge variant="outline" className="hover:bg-primary hover:text-primary-foreground">
                      {tag.name}
                    </Badge>
                  </Link>
                ))}
              </div>
            </div>
          )}
        </article>

        {/* Author Bio */}
        {post.author.bio && (
          <Card className="mb-8">
            <CardContent className="p-6">
              <div className="flex items-start gap-4">
                {post.author.avatar_url && (
                  <img 
                    src={post.author.avatar_url}
                    alt={post.author.name}
                    className="w-16 h-16 rounded-full"
                  />
                )}
                <div>
                  <h3 className="text-lg font-semibold mb-2">About {post.author.name}</h3>
                  <p className="text-muted-foreground">{post.author.bio}</p>
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Related Posts */}
        {relatedPosts.length > 0 && (
          <section className="mb-8">
            <h2 className="text-2xl font-bold mb-6">Related Articles</h2>
            <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
              {relatedPosts.map(relatedPost => (
                <Card key={relatedPost.id} className="overflow-hidden hover:shadow-lg transition-shadow">
                  <Link to={`/blog/${relatedPost.slug}`}>
                    {relatedPost.cover_url && (
                      <div className="aspect-video overflow-hidden">
                        <img 
                          src={relatedPost.cover_url}
                          alt={relatedPost.title}
                          className="w-full h-full object-cover hover:scale-105 transition-transform duration-300"
                        />
                      </div>
                    )}
                    
                    <CardContent className="p-4">
                      <Badge variant="secondary" className="text-xs mb-2">
                        {relatedPost.category.name}
                      </Badge>
                      
                      <h3 className="font-semibold mb-2 line-clamp-2 hover:text-primary transition-colors">
                        {relatedPost.title}
                      </h3>
                      
                      {relatedPost.excerpt && (
                        <p className="text-muted-foreground text-sm mb-2 line-clamp-2">
                          {relatedPost.excerpt}
                        </p>
                      )}
                      
                      <span className="text-xs text-muted-foreground flex items-center gap-1">
                        <Clock className="w-3 h-3" />
                        {relatedPost.reading_time} min read
                      </span>
                    </CardContent>
                  </Link>
                </Card>
              ))}
            </div>
          </section>
        )}
      </main>
      
      <Footer />
    </div>
  );
}