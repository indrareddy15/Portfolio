import { Navigation } from "@/components/Navigation";
import { Footer } from "@/components/Footer";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { SEOHead } from "@/components/SEOHead";

const Terms = () => {
  return (
    <div className="min-h-screen bg-background">
      <SEOHead 
        title="Terms of Service - FREE Trading Journal | PipTrackr.com" 
        description="Read PipTrackr.com's terms of service for our 100% FREE trading journal platform. Understand your rights when using our free MT4, MT5, and prop firm trading tools."
        keywords="terms of service, free trading journal terms, user agreement, trading journal terms, piptrakr terms, free service agreement, free platform terms"
        canonical="https://piptrakr.com/terms"
        robots="index, follow"
        structuredData={{
          "@context": "https://schema.org",
          "@type": "WebPage",
          "name": "Terms of Service - PipTrackr.com", 
          "description": "Terms of service for our free trading journal platform",
          "url": "https://piptrakr.com/terms"
        }}
      />
      <Navigation />
      <main className="container mx-auto px-4 py-6 sm:py-8 pt-20 sm:pt-24">
        <div className="max-w-4xl mx-auto">
          <header className="text-center mb-8 sm:mb-12">
            <h1 className="text-2xl sm:text-3xl lg:text-4xl font-bold tracking-tight mb-3 sm:mb-4">Terms of Service</h1>
            <p className="text-muted-foreground text-sm sm:text-base">
              Last updated: {new Date().toLocaleDateString()}
            </p>
          </header>

          <section className="space-y-6 lg:space-y-8" aria-labelledby="terms-content">
            <h2 id="terms-content" className="sr-only">Terms of Service Content</h2>
            <Card>
              <CardHeader>
                <CardTitle>1. Acceptance of Terms</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground">
                  By accessing and using PipTrackr.com ("the Service"), you accept and agree to be bound by the terms and provision of this agreement. If you do not agree to abide by the above, please do not use this service.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>2. Description of Service</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground mb-4">
                  PipTrackr.com provides a comprehensive trading journal platform that includes:
                </p>
                <ul className="text-muted-foreground space-y-2">
                  <li>• Trade logging and analytics</li>
                  <li>• Performance tracking and reporting</li>
                  <li>• Risk management tools</li>
                  <li>• Psychology and learning resources</li>
                  <li>• Strategy management</li>
                </ul>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>3. User Accounts</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4 text-muted-foreground">
                  <p>
                    You are responsible for maintaining the confidentiality of your account and password and for restricting access to your computer.
                  </p>
                  <p>
                    You agree to accept responsibility for all activities that occur under your account or password.
                  </p>
                  <p>
                    You must provide accurate and complete information when creating your account.
                  </p>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>4. Acceptable Use</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4 text-muted-foreground">
                  <p>You agree not to use the service:</p>
                  <ul className="space-y-2">
                    <li>• For any unlawful purpose or to solicit others to perform unlawful acts</li>
                    <li>• To violate any international, federal, provincial or state regulations, rules or laws</li>
                    <li>• To transmit material that is copyrighted, unless you are the copyright owner</li>
                    <li>• To transmit any material that infringes on any intellectual property rights</li>
                    <li>• To transmit any material that is obscene, offensive, blasphemous or pornographic</li>
                  </ul>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>5. Data and Privacy</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4 text-muted-foreground">
                  <p>
                    Your trading data remains your property. We process your data only as necessary to provide our services.
                  </p>
                  <p>
                    We implement appropriate security measures to protect your personal information against unauthorized access, alteration, disclosure, or destruction.
                  </p>
                  <p>
                    For detailed information about how we collect, use, and protect your data, please review our Privacy Policy.
                  </p>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>6. Payment Terms</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4 text-muted-foreground">
                  <p>
                    Subscription fees are billed in advance on a monthly or annual basis and are non-refundable.
                  </p>
                  <p>
                    We reserve the right to change our pricing at any time. Price changes will be communicated at least 30 days in advance.
                  </p>
                  <p>
                    If payment fails, your account may be suspended until payment is resolved.
                  </p>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>7. Limitation of Liability</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground">
                  In no event shall PipTrackr.com, nor its directors, employees, partners, agents, suppliers, or affiliates, be liable for any indirect, incidental, punitive, consequential, or special damages, including without limitation, loss of profits, data, use, goodwill, or other intangible losses, resulting from your use of the service.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>8. Disclaimer</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4 text-muted-foreground">
                  <p className="font-semibold text-foreground">
                    Trading Risk Warning:
                  </p>
                  <p>
                    Trading financial instruments involves substantial risk of loss and is not suitable for all investors. Past performance is not indicative of future results. PipTrackr.com is a tool for tracking and analyzing trades and does not provide investment advice.
                  </p>
                  <p>
                    The information on this service is provided on an "as is" basis. To the fullest extent permitted by law, this service excludes all representations, warranties, conditions and terms.
                  </p>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>9. Termination</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4 text-muted-foreground">
                  <p>
                    You may terminate your account at any time by contacting customer support.
                  </p>
                  <p>
                    We reserve the right to terminate or suspend your account immediately, without prior notice, for conduct that we believe violates these Terms of Service.
                  </p>
                  <p>
                    Upon termination, your right to use the service will cease immediately, but these terms will remain in effect.
                  </p>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>10. Changes to Terms</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground">
                  We reserve the right to modify these terms at any time. We will notify users of any material changes via email or through the service. Your continued use of the service after such modifications will constitute acknowledgment and agreement of the modified terms.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>11. Contact Information</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground">
                  If you have any questions about these Terms of Service, please contact us at:
                  <br />
                  Email: legal@piptrakr.com
                  <br />
                  Address: 123 Trading Street, Financial District, New York, NY 10004
                </p>
              </CardContent>
            </Card>
          </section>
        </div>
      </main>
      <Footer />
    </div>
  );
};

export default Terms;