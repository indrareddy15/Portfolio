import { useState, useEffect } from "react";
import { useParams, Link } from "react-router-dom";
import { Navigation } from "@/components/Navigation";
import { Footer } from "@/components/Footer";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { SEOHead } from "@/components/SEOHead";
import { 
  Trophy, 
  TrendingUp, 
  TrendingDown, 
  Calendar, 
  Clock, 
  Eye, 
  Share, 
  ArrowRight,
  Target,
  DollarSign,
  Activity,
  BarChart3
} from "lucide-react";
import { useTradeSharing, TradeShare } from "@/hooks/useTradeSharing";
import { supabase } from "@/integrations/supabase/client";
import { format } from "date-fns";

interface TradeData {
  id: string;
  instrument: string;
  pnl: number;
  opened_at: string;
  closed_at?: string;
  entry_price: number;
  exit_price?: number;
  side: 'buy' | 'sell';
  size: number;
  stop_loss?: number;
  take_profit?: number;
  commission?: number;
  swap?: number;
}

interface UserProfile {
  display_name?: string;
}

export default function SharedTrade() {
  const { shareToken } = useParams<{ shareToken: string }>();
  const [share, setShare] = useState<TradeShare | null>(null);
  const [trade, setTrade] = useState<TradeData | null>(null);
  const [userProfile, setUserProfile] = useState<UserProfile | null>(null);
  const [loading, setLoading] = useState(true);
  const [notFound, setNotFound] = useState(false);
  
  const { getPublicTradeShare } = useTradeSharing();

  useEffect(() => {
    if (shareToken) {
      loadSharedTrade();
    }
  }, [shareToken]);

  const loadSharedTrade = async () => {
    try {
      setLoading(true);
      
      // Get the trade share
      const shareData = await getPublicTradeShare(shareToken!);
      if (!shareData) {
        setNotFound(true);
        return;
      }
      
      setShare(shareData);

      // Get the actual trade data
      const { data: tradeData, error: tradeError } = await supabase
        .from('trades')
        .select('*')
        .eq('id', shareData.trade_id)
        .single();

      if (tradeError) {
        console.error('Error fetching trade:', tradeError);
        setNotFound(true);
        return;
      }

      setTrade(tradeData as TradeData);

      // Get user profile
      const { data: profileData } = await supabase
        .from('profiles')
        .select('display_name')
        .eq('user_id', shareData.user_id)
        .single();

      if (profileData) {
        setUserProfile(profileData);
      }

    } catch (error) {
      console.error('Error loading shared trade:', error);
      setNotFound(true);
    } finally {
      setLoading(false);
    }
  };

  const getPnlColor = (pnl: number) => {
    return pnl > 0 ? 'text-success' : pnl < 0 ? 'text-danger' : 'text-muted-foreground';
  };

  const getPnlIcon = (pnl: number) => {
    return pnl > 0 ? TrendingUp : TrendingDown;
  };

  const calculateRisk = () => {
    if (!trade || !trade.stop_loss || !trade.entry_price) return null;
    const risk = Math.abs(trade.entry_price - trade.stop_loss);
    const reward = trade.exit_price ? Math.abs(trade.exit_price - trade.entry_price) : 0;
    const rr = reward > 0 ? reward / risk : 0;
    return { risk, reward, rr };
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-background">
        <Navigation />
        <main className="container mx-auto px-4 py-8 pt-24">
          <div className="max-w-4xl mx-auto">
            <div className="animate-pulse space-y-6">
              <div className="h-8 bg-muted rounded w-3/4"></div>
              <div className="h-4 bg-muted rounded w-1/2"></div>
              <Card>
                <CardContent className="p-6">
                  <div className="h-32 bg-muted rounded"></div>
                </CardContent>
              </Card>
            </div>
          </div>
        </main>
        <Footer />
      </div>
    );
  }

  if (notFound || !share || !trade) {
    return (
      <div className="min-h-screen bg-background">
        <SEOHead 
          title="Trade Not Found | PipTrackr.com"
          description="The shared trade you're looking for was not found or is no longer available."
          robots="noindex, nofollow"
        />
        <Navigation />
        <main className="container mx-auto px-4 py-8 pt-24">
          <div className="max-w-2xl mx-auto text-center py-16">
            <div className="text-6xl mb-4">🔍</div>
            <h1 className="text-2xl font-bold mb-4">Trade Not Found</h1>
            <p className="text-muted-foreground mb-8">
              This shared trade doesn't exist or is no longer available.
            </p>
            <Button asChild>
              <Link to="/">
                <ArrowRight className="w-4 h-4 mr-2" />
                Back to Home
              </Link>
            </Button>
          </div>
        </main>
        <Footer />
      </div>
    );
  }

  const riskData = calculateRisk();
  const PnlIcon = getPnlIcon(trade.pnl);

  return (
    <div className="min-h-screen bg-background">
      <SEOHead 
        title={`${share.title || `${trade.instrument} Trade`} | Shared on PipTrackr.com`}
        description={share.description || `Check out this ${trade.pnl > 0 ? 'profitable' : 'learning'} ${trade.instrument} trade shared on PipTrackr.com - The FREE trading journal platform.`}
        keywords={`shared trade, ${trade.instrument}, forex trading, trading results, piptrakr, trading journal`}
        canonical={`https://piptrakr.com/shared/trade/${shareToken}`}
        ogTitle={share.title || `${trade.instrument} Trading Result`}
        ogDescription={share.description || `${trade.pnl > 0 ? 'Profitable' : 'Learning'} ${trade.instrument} trade: ${trade.pnl > 0 ? '+' : ''}$${trade.pnl.toFixed(2)}`}
        ogImage={share.social_image_url}
        structuredData={{
          "@context": "https://schema.org",
          "@type": "SocialMediaPosting",
          "headline": share.title || `${trade.instrument} Trading Result`,
          "description": share.description,
          "datePublished": share.created_at,
          "author": {
            "@type": "Person",
            "name": userProfile?.display_name || "PipTrackr User"
          },
          "publisher": {
            "@type": "Organization",
            "name": "PipTrackr.com"
          }
        }}
      />
      <Navigation />
      
      <main className="container mx-auto px-4 py-8 pt-24">
        <div className="max-w-4xl mx-auto">
          {/* Header */}
          <div className="text-center mb-8">
            <div className="flex items-center justify-center gap-2 mb-4">
              <Trophy className="w-6 h-6 text-warning" />
              <h1 className="text-3xl font-bold">{share.title || `${trade.instrument} Trade Result`}</h1>
            </div>
            
            {share.description && (
              <p className="text-lg text-muted-foreground mb-4">
                {share.description}
              </p>
            )}
            
            <div className="flex items-center justify-center gap-4 text-sm text-muted-foreground">
              <div className="flex items-center gap-1">
                <Eye className="w-4 h-4" />
                <span>{share.view_count} views</span>
              </div>
              <div className="flex items-center gap-1">
                <Calendar className="w-4 h-4" />
                <span>Shared {format(new Date(share.created_at), 'MMM dd, yyyy')}</span>
              </div>
              {userProfile?.display_name && (
                <div className="flex items-center gap-1">
                  <span>by {userProfile.display_name}</span>
                </div>
              )}
            </div>
          </div>

          {/* Trade Summary */}
          <Card className="mb-8 border-l-4 border-l-primary">
            <CardHeader>
              <div className="flex items-center justify-between">
              <div>
                <CardTitle className="text-2xl flex items-center gap-2">
                  {trade.instrument}
                  <Badge variant={trade.side === 'buy' ? 'default' : 'secondary'}>
                    {trade.side.toUpperCase()}
                  </Badge>
                </CardTitle>
                <CardDescription>
                  {format(new Date(trade.opened_at), 'PPP')} • Size: {trade.size}
                </CardDescription>
              </div>
                <div className="text-right">
                  <div className={`text-3xl font-bold ${getPnlColor(trade.pnl)} flex items-center gap-2`}>
                    <PnlIcon className="w-8 h-8" />
                    {trade.pnl > 0 ? '+' : ''}${trade.pnl.toFixed(2)}
                  </div>
                  <div className="text-sm text-muted-foreground">
                    {trade.pnl > 0 ? 'Profit' : trade.pnl < 0 ? 'Loss' : 'Break Even'}
                  </div>
                </div>
              </div>
            </CardHeader>
          </Card>

          {/* Trade Details Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
            <Card>
              <CardContent className="p-6">
                <div className="flex items-center gap-2 mb-2">
                  <Target className="w-5 h-5 text-primary" />
                  <h3 className="font-semibold">Entry Price</h3>
                </div>
                <div className="text-2xl font-bold">{trade.entry_price}</div>
              </CardContent>
            </Card>

            {trade.exit_price && (
              <Card>
                <CardContent className="p-6">
                  <div className="flex items-center gap-2 mb-2">
                    <Target className="w-5 h-5 text-success" />
                    <h3 className="font-semibold">Exit Price</h3>
                  </div>
                  <div className="text-2xl font-bold">{trade.exit_price}</div>
                </CardContent>
              </Card>
            )}

            <Card>
              <CardContent className="p-6">
                <div className="flex items-center gap-2 mb-2">
                  <DollarSign className="w-5 h-5 text-warning" />
                  <h3 className="font-semibold">P&L</h3>
                </div>
                <div className={`text-2xl font-bold ${getPnlColor(trade.pnl)}`}>
                  {trade.pnl > 0 ? '+' : ''}${trade.pnl.toFixed(2)}
                </div>
              </CardContent>
            </Card>

            {trade.stop_loss && (
              <Card>
                <CardContent className="p-6">
                  <div className="flex items-center gap-2 mb-2">
                    <Activity className="w-5 h-5 text-danger" />
                    <h3 className="font-semibold">Stop Loss</h3>
                  </div>
                  <div className="text-2xl font-bold">{trade.stop_loss}</div>
                </CardContent>
              </Card>
            )}

            {trade.take_profit && (
              <Card>
                <CardContent className="p-6">
                  <div className="flex items-center gap-2 mb-2">
                    <TrendingUp className="w-5 h-5 text-success" />
                    <h3 className="font-semibold">Take Profit</h3>
                  </div>
                  <div className="text-2xl font-bold">{trade.take_profit}</div>
                </CardContent>
              </Card>
            )}

            {riskData && (
              <Card>
                <CardContent className="p-6">
                  <div className="flex items-center gap-2 mb-2">
                    <BarChart3 className="w-5 h-5 text-accent" />
                    <h3 className="font-semibold">Risk/Reward</h3>
                  </div>
                  <div className="text-2xl font-bold">1:{riskData.rr.toFixed(2)}</div>
                </CardContent>
              </Card>
            )}
          </div>

          {trade.closed_at && (
            <Card className="mb-8">
              <CardContent className="p-6">
                <div className="flex items-center gap-2 mb-4">
                  <Clock className="w-5 h-5 text-muted-foreground" />
                  <h3 className="font-semibold">Trade Duration</h3>
                </div>
                <div className="text-lg">
                  {format(new Date(trade.opened_at), 'PPp')} → {format(new Date(trade.closed_at), 'PPp')}
                </div>
                <div className="text-sm text-muted-foreground mt-2">
                  Duration: {Math.round((new Date(trade.closed_at).getTime() - new Date(trade.opened_at).getTime()) / (1000 * 60 * 60))} hours
                </div>
              </CardContent>
            </Card>
          )}

          {/* CTA Section */}
          <Card className="text-center py-12 bg-gradient-to-r from-primary/5 to-primary/10 border-primary/20">
            <CardContent>
              <Trophy className="w-16 h-16 text-primary mx-auto mb-6" />
              <h2 className="text-2xl font-bold mb-4">Start Your Trading Journey</h2>
              <p className="text-lg text-muted-foreground mb-6 max-w-2xl mx-auto">
                Join thousands of traders who use PipTrackr.com to track, analyze, and share their trades. 
                <span className="block mt-2 font-semibold text-success">
                  100% FREE - No premium plans required!
                </span>
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Button asChild size="lg" className="glow-hover">
                  <Link to="/auth">
                    <ArrowRight className="w-5 h-5 mr-2" />
                    Start FREE Now
                  </Link>
                </Button>
                <Button asChild variant="outline" size="lg">
                  <Link to="/app">
                    View Live Demo
                  </Link>
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </main>
      
      <Footer />
    </div>
  );
}