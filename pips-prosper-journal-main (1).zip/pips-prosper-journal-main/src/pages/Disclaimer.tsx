import { Navigation } from "@/components/Navigation";
import { Footer } from "@/components/Footer";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { AlertTriangle } from "lucide-react";
import { SEOHead } from "@/components/SEOHead";

const Disclaimer = () => {
  return (
    <div className="min-h-screen bg-background">
      <SEOHead 
        title="Risk Disclaimer - Trading Risks & Platform Limitations | PipTrackr.com"
        description="Important trading risk disclaimer. Understand the risks of forex trading and PipTrackr.com platform limitations. Trading involves substantial risk of loss."
        keywords="trading risk disclaimer, forex trading risks, investment disclaimer, trading warnings, financial risk warning"
        canonical={`${window.location.origin}/disclaimer`}
      />
      <Navigation />
      <main className="container mx-auto px-4 py-8 pt-24">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-12">
            <div className="flex items-center justify-center gap-2 mb-4">
              <AlertTriangle className="h-8 w-8 text-yellow-500" />
              <h1 className="text-4xl font-bold tracking-tight">Risk Disclaimer</h1>
            </div>
            <p className="text-muted-foreground">
              Important information about trading risks and platform usage
            </p>
          </div>

          <div className="space-y-8">
            <Card className="border-yellow-200 bg-yellow-50 dark:bg-yellow-950/20">
              <CardHeader>
                <CardTitle className="text-yellow-800 dark:text-yellow-200">
                  ⚠️ Trading Risk Warning
                </CardTitle>
              </CardHeader>
              <CardContent className="text-yellow-700 dark:text-yellow-300">
                <p className="font-semibold mb-4">
                  Trading financial instruments involves substantial risk of loss and is not suitable for all investors.
                </p>
                <ul className="space-y-2">
                  <li>• You could lose some or all of your initial investment</li>
                  <li>• Past performance is not indicative of future results</li>
                  <li>• Leverage can amplify both profits and losses</li>
                  <li>• Market volatility can result in rapid and substantial losses</li>
                </ul>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>No Investment Advice</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4 text-muted-foreground">
                  <p>
                    PipTrackr.com is a trading journal and analytics platform. We do not provide investment advice, 
                    trading signals, or recommendations to buy or sell any financial instruments.
                  </p>
                  <p>
                    All content, tools, and features provided are for educational and analytical purposes only. 
                    Any trading decisions you make are solely your responsibility.
                  </p>
                  <p>
                    You should consult with a qualified financial advisor before making any investment decisions.
                  </p>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Platform Limitations</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4 text-muted-foreground">
                  <p>
                    While we strive to provide accurate and reliable tools, PipTrackr.com cannot guarantee:
                  </p>
                  <ul className="space-y-2">
                    <li>• Complete accuracy of calculations or analytics</li>
                    <li>• Uninterrupted access to the platform</li>
                    <li>• Error-free operation of all features</li>
                    <li>• Compatibility with all trading platforms or brokers</li>
                  </ul>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>User Responsibility</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4 text-muted-foreground">
                  <p>As a user of PipTrackr.com, you are responsible for:</p>
                  <ul className="space-y-2">
                    <li>• Verifying the accuracy of all data you input</li>
                    <li>• Making your own independent trading decisions</li>
                    <li>• Understanding the risks associated with your trading activities</li>
                    <li>• Complying with all applicable laws and regulations</li>
                    <li>• Maintaining the security of your account</li>
                  </ul>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Regulatory Information</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4 text-muted-foreground">
                  <p>
                    PipTrackr.com is not a registered investment advisor, broker-dealer, or financial institution. 
                    We are not licensed to provide investment advice in any jurisdiction.
                  </p>
                  <p>
                    Different countries have different regulations regarding financial services and trading. 
                    It is your responsibility to ensure compliance with your local laws and regulations.
                  </p>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Data Accuracy</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4 text-muted-foreground">
                  <p>
                    While we make every effort to ensure data accuracy, we cannot guarantee that all information 
                    displayed is completely accurate, current, or complete.
                  </p>
                  <p>
                    Market data, calculations, and analytics are provided "as is" without warranty of any kind. 
                    You should verify all information independently before making trading decisions.
                  </p>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Third-Party Integration</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4 text-muted-foreground">
                  <p>
                    PipTrackr.com may integrate with third-party services, brokers, or data providers. 
                    We are not responsible for the accuracy, reliability, or security of third-party services.
                  </p>
                  <p>
                    Any issues with third-party integrations should be directed to the respective service provider.
                  </p>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Limitation of Liability</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4 text-muted-foreground">
                  <p>
                    In no event shall PipTrackr.com, its directors, employees, or affiliates be liable for any 
                    direct, indirect, incidental, consequential, or punitive damages arising from:
                  </p>
                  <ul className="space-y-2">
                    <li>• Use of our platform or services</li>
                    <li>• Trading losses or investment decisions</li>
                    <li>• Inaccurate data or calculations</li>
                    <li>• Platform downtime or technical issues</li>
                    <li>• Third-party integrations or services</li>
                  </ul>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Seek Professional Advice</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground">
                  Before engaging in any trading activities, we strongly recommend consulting with qualified 
                  financial professionals who can provide personalized advice based on your individual 
                  financial situation, risk tolerance, and investment objectives.
                </p>
              </CardContent>
            </Card>

            <Card className="bg-muted/50">
              <CardContent className="pt-6">
                <p className="text-center text-sm text-muted-foreground">
                  By using PipTrackr.com, you acknowledge that you have read, understood, and agree to this disclaimer.
                  <br />
                  Last updated: {new Date().toLocaleDateString()}
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
};

export default Disclaimer;