import { Navigation } from "@/components/Navigation";
import { Footer } from "@/components/Footer";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { SEOHead } from "@/components/SEOHead";

const Cookies = () => {
  return (
    <div className="min-h-screen bg-background">
      <SEOHead 
        title="Cookie Policy - PipTrackr.com Trading Journal"
        description="Learn about PipTrackr.com's cookie usage. Understand how we use cookies to improve your trading journal experience and protect your privacy."
        keywords="cookie policy, cookies, website cookies, trading journal cookies, privacy preferences"
        canonical={`${window.location.origin}/cookies`}
      />
      <Navigation />
      <main className="container mx-auto px-4 py-8 pt-24">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-12">
            <h1 className="text-4xl font-bold tracking-tight mb-4">Cookie Policy</h1>
            <p className="text-muted-foreground">
              Last updated: {new Date().toLocaleDateString()}
            </p>
          </div>

          <div className="space-y-8">
            <Card>
              <CardHeader>
                <CardTitle>What Are Cookies?</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground">
                  Cookies are small text files that are placed on your computer or mobile device when you visit our website. 
                  They help us provide you with a better experience by remembering your preferences and understanding how you use our service.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>How We Use Cookies</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4 text-muted-foreground">
                  <div>
                    <h4 className="font-semibold text-foreground mb-2">Essential Cookies</h4>
                    <p>These cookies are necessary for the website to function properly. They enable basic features like page navigation and access to secure areas.</p>
                  </div>
                  <div>
                    <h4 className="font-semibold text-foreground mb-2">Authentication Cookies</h4>
                    <p>These cookies keep you logged in and remember your session across page visits.</p>
                  </div>
                  <div>
                    <h4 className="font-semibold text-foreground mb-2">Preference Cookies</h4>
                    <p>These cookies remember your settings and preferences, such as theme selection and dashboard layout.</p>
                  </div>
                  <div>
                    <h4 className="font-semibold text-foreground mb-2">Analytics Cookies</h4>
                    <p>These cookies help us understand how visitors interact with our website by collecting and reporting information anonymously.</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Types of Cookies We Use</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="border rounded-lg p-4">
                    <h4 className="font-semibold mb-2">Session Cookies</h4>
                    <p className="text-muted-foreground text-sm">Temporary cookies that expire when you close your browser</p>
                  </div>
                  <div className="border rounded-lg p-4">
                    <h4 className="font-semibold mb-2">Persistent Cookies</h4>
                    <p className="text-muted-foreground text-sm">Cookies that remain on your device until they expire or you delete them</p>
                  </div>
                  <div className="border rounded-lg p-4">
                    <h4 className="font-semibold mb-2">First-Party Cookies</h4>
                    <p className="text-muted-foreground text-sm">Set directly by our website</p>
                  </div>
                  <div className="border rounded-lg p-4">
                    <h4 className="font-semibold mb-2">Third-Party Cookies</h4>
                    <p className="text-muted-foreground text-sm">Set by external services we use (e.g., analytics providers)</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Managing Your Cookie Preferences</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4 text-muted-foreground">
                  <p>You can control and manage cookies in several ways:</p>
                  <div>
                    <h4 className="font-semibold text-foreground mb-2">Browser Settings</h4>
                    <p>Most browsers allow you to control cookies through their settings. You can typically:</p>
                    <ul className="mt-2 space-y-1">
                      <li>• Delete all existing cookies</li>
                      <li>• Block all cookies</li>
                      <li>• Allow only first-party cookies</li>
                      <li>• Get notifications when cookies are set</li>
                    </ul>
                  </div>
                  <div>
                    <h4 className="font-semibold text-foreground mb-2">Our Cookie Settings</h4>
                    <p>We provide cookie preference settings within our application where you can control non-essential cookies.</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Impact of Disabling Cookies</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4 text-muted-foreground">
                  <p>Disabling cookies may impact your experience on our website:</p>
                  <ul className="space-y-2">
                    <li>• You may need to re-enter information repeatedly</li>
                    <li>• Some features may not work properly</li>
                    <li>• Your preferences won't be saved</li>
                    <li>• We won't be able to provide personalized experiences</li>
                  </ul>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Updates to This Policy</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground">
                  We may update this Cookie Policy from time to time to reflect changes in our practices or for other operational, 
                  legal, or regulatory reasons. Please check this page periodically for updates.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Contact Us</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground">
                  If you have any questions about our use of cookies, please contact us at:
                  <br />
                  Email: privacy@piptrakr.com
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
};

export default Cookies;