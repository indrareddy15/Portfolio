import { useEffect, useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { 
  Search, 
  Plus, 
  User, 
  Handshake, 
  Calendar,
  Edit,
  Trash2
} from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "@/hooks/use-toast";
import { useRealtime } from "@/hooks/useRealtime";

interface CrmNote {
  id: string;
  subject: string;
  body: string | null;
  user_id: string | null;
  affiliate_id: string | null;
  by_admin_id: string;
  created_at: string;
}

export default function CrmNotes() {
  const [notes, setNotes] = useState<CrmNote[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState("");
  const [newNote, setNewNote] = useState({
    contactType: "user",
    contactEmail: "",
    subject: "",
    body: ""
  });

  const fetchNotes = async () => {
    try {
      const { data, error } = await supabase
        .from('crm_notes')
        .select('*')
        .order('created_at', { ascending: false });

      if (error) throw error;
      setNotes(data || []);
    } catch (error) {
      console.error('Error fetching notes:', error);
      toast({
        title: "Error",
        description: "Failed to fetch notes",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const saveNote = async () => {
    if (!newNote.subject || !newNote.body) {
      toast({
        title: "Error",
        description: "Subject and content are required",
        variant: "destructive",
      });
      return;
    }

    try {
      const { data: currentUser } = await supabase.auth.getUser();
      if (!currentUser.user) throw new Error("Not authenticated");

      // For simplicity, we'll just save the note without linking to specific user/affiliate
      const { error } = await supabase
        .from('crm_notes')
        .insert({
          subject: newNote.subject,
          body: newNote.body,
          by_admin_id: currentUser.user.id,
          user_id: null, // Would need to lookup user by email
          affiliate_id: null // Would need to lookup affiliate by email
        });

      if (error) throw error;

      toast({
        title: "Success",
        description: "Note saved successfully",
      });

      setNewNote({
        contactType: "user",
        contactEmail: "",
        subject: "",
        body: ""
      });

      fetchNotes();
    } catch (error: any) {
      console.error('Error saving note:', error);
      toast({
        title: "Error",
        description: error.message || "Failed to save note",
        variant: "destructive",
      });
    }
  };

  const deleteNote = async (id: string) => {
    try {
      const { error } = await supabase
        .from('crm_notes')
        .delete()
        .eq('id', id);

      if (error) throw error;

      toast({
        title: "Success",
        description: "Note deleted successfully",
      });

      fetchNotes();
    } catch (error) {
      console.error('Error deleting note:', error);
      toast({
        title: "Error",
        description: "Failed to delete note",
        variant: "destructive",
      });
    }
  };

  useEffect(() => {
    fetchNotes();
  }, []);

  // Real-time CRM notes updates
  useRealtime([
    {
      table: 'crm_notes',
      events: ['INSERT', 'UPDATE', 'DELETE'],
      onInsert: (payload) => {
        console.log('New CRM note created:', payload.new);
        setNotes(prev => [payload.new, ...prev]);
        toast({
          title: "New Note Added! 📝",
          description: `Note: "${payload.new.subject}" has been created`,
        });
      },
      onUpdate: (payload) => {
        console.log('CRM note updated:', payload.new);
        setNotes(prev => prev.map(note => 
          note.id === payload.new.id ? payload.new : note
        ));
        toast({
          title: "Note Updated",
          description: `"${payload.new.subject}" has been modified`,
        });
      },
      onDelete: (payload) => {
        console.log('CRM note deleted:', payload.old);
        setNotes(prev => prev.filter(note => note.id !== payload.old.id));
        toast({
          title: "Note Deleted",
          description: `"${payload.old.subject}" has been removed`,
        });
      },
      channelName: 'admin-crm-notes-realtime'
    }
  ]);

  const filteredNotes = notes.filter(note =>
    note.subject.toLowerCase().includes(searchTerm.toLowerCase()) ||
    (note.body && note.body.toLowerCase().includes(searchTerm.toLowerCase()))
  );

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
      </div>
    );
  }
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-foreground">CRM Notes</h1>
          <p className="text-muted-foreground">
            Internal notes and communications for users and affiliates
          </p>
        </div>
        <Button>
          <Plus className="w-4 h-4 mr-2" />
          Add Note
        </Button>
      </div>

      {/* Search */}
      <Card className="glass-card border-card-border">
        <CardContent className="pt-6">
          <div className="flex space-x-4">
            <div className="flex-1">
              <div className="relative">
                <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="Search notes by subject, content, or contact..."
                  className="pl-8"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                />
              </div>
            </div>
            <Button>Search</Button>
          </div>
        </CardContent>
      </Card>

      {/* Add Note Form */}
      <Card className="glass-card border-card-border">
        <CardHeader>
          <CardTitle>Quick Note</CardTitle>
          <CardDescription>
            Add a new note for a user or affiliate
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid gap-4 md:grid-cols-2">
            <div>
              <label className="text-sm font-medium text-muted-foreground">Contact Type</label>
              <select 
                className="w-full mt-1 p-2 border border-input rounded-md bg-background"
                value={newNote.contactType}
                onChange={(e) => setNewNote({ ...newNote, contactType: e.target.value })}
              >
                <option value="user">User</option>
                <option value="affiliate">Affiliate</option>
              </select>
            </div>
            <div>
              <label className="text-sm font-medium text-muted-foreground">Contact Email</label>
              <Input 
                placeholder="Enter email address..." 
                className="mt-1" 
                value={newNote.contactEmail}
                onChange={(e) => setNewNote({ ...newNote, contactEmail: e.target.value })}
              />
            </div>
          </div>
          <div>
            <label className="text-sm font-medium text-muted-foreground">Subject</label>
            <Input 
              placeholder="Note subject..." 
              className="mt-1" 
              value={newNote.subject}
              onChange={(e) => setNewNote({ ...newNote, subject: e.target.value })}
            />
          </div>
          <div>
            <label className="text-sm font-medium text-muted-foreground">Note Content</label>
            <Textarea 
              placeholder="Write your note here..." 
              className="mt-1 min-h-[100px]"
              value={newNote.body}
              onChange={(e) => setNewNote({ ...newNote, body: e.target.value })}
            />
          </div>
          <Button onClick={saveNote}>Save Note</Button>
        </CardContent>
      </Card>

      {/* Notes List */}
      <div className="space-y-4">
        {filteredNotes.length === 0 ? (
          <Card className="glass-card border-card-border">
            <CardContent className="pt-6">
              <p className="text-center text-muted-foreground py-8">
                {searchTerm ? "No notes found matching your search" : "No notes yet. Create your first note above."}
              </p>
            </CardContent>
          </Card>
        ) : (
          filteredNotes.map((note) => (
            <Card key={note.id} className="glass-card border-card-border">
              <CardContent className="pt-6">
                <div className="flex items-start justify-between">
                  <div className="flex items-start space-x-3">
                    <div className="w-8 h-8 bg-primary/10 rounded-full flex items-center justify-center">
                      {note.affiliate_id ? (
                        <Handshake className="w-4 h-4 text-primary" />
                      ) : (
                        <User className="w-4 h-4 text-primary" />
                      )}
                    </div>
                    <div className="flex-1">
                      <div className="flex items-center space-x-2 mb-2">
                        <h3 className="font-medium text-foreground">{note.subject}</h3>
                        <Badge variant="outline" className={note.affiliate_id ? "text-success border-success" : ""}>
                          {note.affiliate_id ? "Affiliate" : "User"}
                        </Badge>
                      </div>
                      {note.body && (
                        <p className="text-sm text-muted-foreground mb-3 line-clamp-3">
                          {note.body}
                        </p>
                      )}
                      <div className="flex items-center space-x-4 text-xs text-muted-foreground">
                        <span className="flex items-center">
                          <Calendar className="w-3 h-3 mr-1" />
                          {new Date(note.created_at).toLocaleDateString()}
                        </span>
                        <span>By: Admin</span>
                      </div>
                    </div>
                  </div>
                  <div className="flex space-x-2">
                    <Button variant="ghost" size="sm">
                      <Edit className="w-3 h-3" />
                    </Button>
                    <Button 
                      variant="ghost" 
                      size="sm"
                      onClick={() => deleteNote(note.id)}
                    >
                      <Trash2 className="w-3 h-3" />
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))
        )}
      </div>
    </div>
  );
}