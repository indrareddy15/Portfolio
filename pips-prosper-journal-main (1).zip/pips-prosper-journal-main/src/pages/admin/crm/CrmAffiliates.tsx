import { useEffect, useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { 
  Search, 
  Filter, 
  MoreHorizontal, 
  CheckCircle, 
  XCircle, 
  Clock,
  DollarSign,
  TrendingUp,
  Users
} from "lucide-react";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "@/hooks/use-toast";
import { useRealtime } from "@/hooks/useRealtime";

interface AffiliateData {
  id: string;
  code: string;
  status: string;
  default_rate_pct: number;
  created_at: string;
  user_id: string;
  profiles?: {
    display_name: string | null;
  } | null;
  commissions?: {
    amount: number;
  }[];
  affiliate_attributions?: {
    id: string;
  }[];
}

interface AffiliateStats {
  total: number;
  active: number;
  totalEarnings: number;
  avgConversion: number;
}

export default function CrmAffiliates() {
  const [affiliates, setAffiliates] = useState<AffiliateData[]>([]);
  const [stats, setStats] = useState<AffiliateStats>({
    total: 0,
    active: 0,
    totalEarnings: 0,
    avgConversion: 3.2
  });
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState("");
  const [showAddDialog, setShowAddDialog] = useState(false);
  const [newAffiliate, setNewAffiliate] = useState({
    userEmail: "",
    code: "",
    rate: 10
  });

  const fetchAffiliates = async () => {
    try {
      const { data, error } = await supabase
        .from('affiliates')
        .select(`
          *,
          profiles:user_id (display_name),
          commissions (amount),
          affiliate_attributions (id)
        `)
        .order('created_at', { ascending: false });

      if (error) throw error;

      setAffiliates(data as any || []);

      // Calculate stats
      const totalEarnings = data?.reduce((acc, affiliate) => {
        const earnings = affiliate.commissions?.reduce((sum, comm) => sum + Number(comm.amount), 0) || 0;
        return acc + earnings;
      }, 0) || 0;

      setStats({
        total: data?.length || 0,
        active: data?.filter(a => a.status === 'active').length || 0,
        totalEarnings,
        avgConversion: 3.2 // This would be calculated from actual click/conversion data
      });
    } catch (error) {
      console.error('Error fetching affiliates:', error);
      toast({
        title: "Error",
        description: "Failed to fetch affiliates",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const updateAffiliateStatus = async (id: string, status: string) => {
    try {
      const { error } = await supabase
        .from('affiliates')
        .update({ status })
        .eq('id', id);

      if (error) throw error;

      toast({
        title: "Success",
        description: `Affiliate ${status} successfully`,
      });

      fetchAffiliates();
    } catch (error) {
      console.error('Error updating affiliate:', error);
      toast({
        title: "Error",
        description: "Failed to update affiliate status",
        variant: "destructive",
      });
    }
  };

  const addAffiliate = async () => {
    try {
      if (!newAffiliate.userEmail || !newAffiliate.code) {
        toast({
          title: "Missing Information",
          description: "Please provide user email and affiliate code",
          variant: "destructive",
        });
        return;
      }

      // First check if user exists
      const { data: userData, error: userError } = await supabase
        .from('profiles')
        .select('user_id')
        .eq('user_id', newAffiliate.userEmail)
        .single();

      if (userError) {
        toast({
          title: "User Not Found",
          description: "Please check the user email/ID",
          variant: "destructive",
        });
        return;
      }

      const { error } = await supabase
        .from('affiliates')
        .insert([{
          user_id: userData.user_id,
          code: newAffiliate.code,
          default_rate_pct: newAffiliate.rate,
          status: 'active'
        }]);

      if (error) throw error;

      setShowAddDialog(false);
      setNewAffiliate({ userEmail: "", code: "", rate: 10 });
      
      toast({
        title: "Success",
        description: "Affiliate added successfully",
      });
    } catch (error) {
      console.error('Error adding affiliate:', error);
      toast({
        title: "Error",
        description: "Failed to add affiliate. Code might already exist.",
        variant: "destructive",
      });
    }
  };

  useEffect(() => {
    fetchAffiliates();
  }, []);

  // Real-time subscriptions for affiliate data
  useRealtime([
    {
      table: 'affiliates',
      events: ['INSERT', 'UPDATE', 'DELETE'],
      onInsert: (payload) => {
        console.log('New affiliate created:', payload.new);
        fetchAffiliates(); // Refetch to get complete data with joins
        toast({
          title: "New Affiliate! 🤝",
          description: `Affiliate ${payload.new.code} has been created`,
        });
      },
      onUpdate: (payload) => {
        console.log('Affiliate updated:', payload.new);
        fetchAffiliates(); // Refetch to get updated stats
        if (payload.old.status !== payload.new.status) {
          toast({
            title: "Affiliate Status Changed",
            description: `${payload.new.code} is now ${payload.new.status}`,
          });
        }
      },
      onDelete: (payload) => {
        console.log('Affiliate deleted:', payload.old);
        setAffiliates(prev => prev.filter(aff => aff.id !== payload.old.id));
        toast({
          title: "Affiliate Removed",
          description: `Affiliate ${payload.old.code} has been deleted`,
        });
      },
      channelName: 'crm-affiliates-realtime'
    },
    {
      table: 'commissions',
      events: ['INSERT', 'UPDATE'],
      onInsert: (payload) => {
        console.log('New commission created:', payload.new);
        fetchAffiliates(); // Refetch to update earnings
        toast({
          title: "New Commission! 💰",
          description: `$${payload.new.amount} commission earned`,
        });
      },
      onUpdate: (payload) => {
        console.log('Commission updated:', payload.new);
        fetchAffiliates(); // Refetch to update earnings
      },
      channelName: 'crm-affiliates-realtime'
    },
    {
      table: 'affiliate_attributions',
      events: ['INSERT'],
      onInsert: (payload) => {
        console.log('New attribution:', payload.new);
        fetchAffiliates(); // Refetch to update customer count
      },
      channelName: 'crm-affiliates-realtime'
    }
  ]);

  const filteredAffiliates = affiliates.filter(affiliate =>
    affiliate.code.toLowerCase().includes(searchTerm.toLowerCase()) ||
    affiliate.profiles?.display_name?.toLowerCase().includes(searchTerm.toLowerCase())
  );

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
      </div>
    );
  }
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-foreground">Affiliate CRM</h1>
          <p className="text-muted-foreground">
            Manage affiliate relationships and performance
          </p>
        </div>
        <Dialog open={showAddDialog} onOpenChange={setShowAddDialog}>
          <DialogTrigger asChild>
            <Button>
              <Users className="w-4 h-4 mr-2" />
              Add Affiliate
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Add New Affiliate</DialogTitle>
              <DialogDescription>
                Create a new affiliate account for an existing user.
              </DialogDescription>
            </DialogHeader>
            <div className="space-y-4">
              <div>
                <Label htmlFor="user-email">User ID/Email</Label>
                <Input
                  id="user-email"
                  value={newAffiliate.userEmail}
                  onChange={(e) => setNewAffiliate(prev => ({ ...prev, userEmail: e.target.value }))}
                  placeholder="Enter user ID or email"
                />
              </div>
              <div>
                <Label htmlFor="affiliate-code">Affiliate Code</Label>
                <Input
                  id="affiliate-code"
                  value={newAffiliate.code}
                  onChange={(e) => setNewAffiliate(prev => ({ ...prev, code: e.target.value }))}
                  placeholder="Enter unique affiliate code"
                />
              </div>
              <div>
                <Label htmlFor="commission-rate">Commission Rate (%)</Label>
                <Input
                  id="commission-rate"
                  type="number"
                  min="0"
                  max="100"
                  value={newAffiliate.rate}
                  onChange={(e) => setNewAffiliate(prev => ({ ...prev, rate: parseFloat(e.target.value) || 0 }))}
                />
              </div>
              <div className="flex justify-end gap-2">
                <Button variant="outline" onClick={() => setShowAddDialog(false)}>
                  Cancel
                </Button>
                <Button onClick={addAffiliate}>
                  Add Affiliate
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {/* Affiliate Stats */}
      <div className="grid gap-4 md:grid-cols-3">
        <Card className="glass-card border-card-border">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              Active Affiliates
            </CardTitle>
            <CheckCircle className="h-4 w-4 text-success" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-foreground">{stats.total}</div>
            <p className="text-xs text-success">Total affiliate partners</p>
          </CardContent>
        </Card>

        <Card className="glass-card border-card-border">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              Total Earnings
            </CardTitle>
            <DollarSign className="h-4 w-4 text-primary" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-foreground">${stats.totalEarnings.toLocaleString()}</div>
            <p className="text-xs text-success">Total affiliate earnings</p>
          </CardContent>
        </Card>

        <Card className="glass-card border-card-border">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              Avg. Conversion
            </CardTitle>
            <TrendingUp className="h-4 w-4 text-primary" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-foreground">3.2%</div>
            <p className="text-xs text-success">+0.4% from last month</p>
          </CardContent>
        </Card>
      </div>

      {/* Search */}
      <Card className="glass-card border-card-border">
        <CardContent className="pt-6">
          <div className="flex space-x-4">
            <div className="flex-1">
              <div className="relative">
                <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="Search affiliates by name, email, or code..."
                  className="pl-8"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                />
              </div>
            </div>
            <Button variant="outline">
              <Filter className="w-4 h-4 mr-2" />
              Filter
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Affiliates Table */}
      <Card className="glass-card border-card-border">
        <CardHeader>
          <CardTitle>Affiliate Directory</CardTitle>
          <CardDescription>
            Manage your affiliate partners and their performance
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Affiliate</TableHead>
                <TableHead>Code</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Customers</TableHead>
                <TableHead>Total Earned</TableHead>
                <TableHead>Tier</TableHead>
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredAffiliates.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={7} className="text-center text-muted-foreground">
                    {searchTerm ? "No affiliates found matching your search" : "No affiliates found"}
                  </TableCell>
                </TableRow>
              ) : (
                filteredAffiliates.map((affiliate) => {
                  const totalEarnings = affiliate.commissions?.reduce((sum, comm) => sum + Number(comm.amount), 0) || 0;
                  const customerCount = affiliate.affiliate_attributions?.length || 0;
                  
                  return (
                    <TableRow key={affiliate.id}>
                      <TableCell className="font-medium">
                        <div>
                          <p className="font-medium">{affiliate.profiles?.display_name || 'Unknown'}</p>
                          <p className="text-sm text-muted-foreground">User ID: {affiliate.user_id.slice(-8)}</p>
                        </div>
                      </TableCell>
                      <TableCell>
                        <code className="bg-muted px-2 py-1 rounded text-xs">{affiliate.code}</code>
                      </TableCell>
                      <TableCell>
                        <Badge 
                          variant="outline" 
                          className={
                            affiliate.status === 'active' ? "text-success border-success" :
                            affiliate.status === 'pending' ? "text-warning border-warning" :
                            "text-destructive border-destructive"
                          }
                        >
                          {affiliate.status === 'active' && <CheckCircle className="w-3 h-3 mr-1" />}
                          {affiliate.status === 'pending' && <Clock className="w-3 h-3 mr-1" />}
                          {affiliate.status === 'rejected' && <XCircle className="w-3 h-3 mr-1" />}
                          {affiliate.status}
                        </Badge>
                      </TableCell>
                      <TableCell>{customerCount} customers</TableCell>
                      <TableCell>${totalEarnings.toLocaleString()}</TableCell>
                      <TableCell>
                        <Badge variant="default">Tier 1 ({affiliate.default_rate_pct}%)</Badge>
                      </TableCell>
                      <TableCell className="text-right">
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="ghost" className="h-8 w-8 p-0">
                              <MoreHorizontal className="h-4 w-4" />
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            <DropdownMenuItem>View Details</DropdownMenuItem>
                            {affiliate.status === 'pending' && (
                              <>
                                <DropdownMenuItem onClick={() => updateAffiliateStatus(affiliate.id, 'active')}>
                                  Approve
                                </DropdownMenuItem>
                                <DropdownMenuItem onClick={() => updateAffiliateStatus(affiliate.id, 'rejected')}>
                                  Reject
                                </DropdownMenuItem>
                              </>
                            )}
                            {affiliate.status === 'active' && (
                              <DropdownMenuItem onClick={() => updateAffiliateStatus(affiliate.id, 'paused')}>
                                Pause Account
                              </DropdownMenuItem>
                            )}
                            <DropdownMenuItem>Edit Rates</DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </TableCell>
                    </TableRow>
                  );
                })
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
}