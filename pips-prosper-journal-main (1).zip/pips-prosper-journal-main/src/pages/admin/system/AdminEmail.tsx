import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { AlertCircle, Send, RefreshCw, Eye, RotateCcw, Filter } from 'lucide-react';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { toast } from 'sonner';
import { useSupabaseAuth, useEmailLogs } from '@/hooks/useSupabaseAuth';
import { supabase } from '@/integrations/supabase/client';

export default function AdminEmail() {
  const [testEmail, setTestEmail] = useState('');
  const [testSubject, setTestSubject] = useState('');
  const [filterType, setFilterType] = useState<string>('all');
  const [filterStatus, setFilterStatus] = useState<string>('all');

  const { 
    signupConfirmMutation, 
    passwordResetMutation, 
    magicLinkMutation, 
    inviteUserMutation,
    resendEmail 
  } = useSupabaseAuth();

  const { logs, isLoading, refetch, setupRealtimeSubscription } = useEmailLogs();

  useEffect(() => {
    // Set up real-time subscription for email logs
    const unsubscribe = setupRealtimeSubscription();
    return unsubscribe;
  }, []);

  const handleTestEmail = async (type: 'signup_confirm' | 'password_reset' | 'magic_link' | 'invite') => {
    if (!testEmail) {
      toast.error('Please enter an email address');
      return;
    }

    const redirectTo = `${window.location.origin}/auth/callback`;
    
    switch (type) {
      case 'signup_confirm':
        signupConfirmMutation.mutate({ email: testEmail, redirectTo });
        break;
      case 'password_reset':
        passwordResetMutation.mutate({ email: testEmail, redirectTo });
        break;
      case 'magic_link':
        magicLinkMutation.mutate({ email: testEmail, redirectTo });
        break;
      case 'invite':
        inviteUserMutation.mutate({ email: testEmail, redirectTo });
        break;
    }
  };

  const handleResendLog = (log: any) => {
    resendEmail(log.template_key, log.to_email);
  };

  const filteredLogs = logs.filter(log => {
    const typeMatch = filterType === 'all' || log.template_key === filterType;
    const statusMatch = filterStatus === 'all' || log.status === filterStatus;
    return typeMatch && statusMatch;
  });

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'sent':
        return <Badge variant="default" className="bg-green-100 text-green-800">Sent</Badge>;
      case 'failed':
        return <Badge variant="destructive">Failed</Badge>;
      case 'queued':
        return <Badge variant="secondary">Queued</Badge>;
      default:
        return <Badge variant="outline">{status}</Badge>;
    }
  };

  const getTypeBadge = (type: string) => {
    const colors = {
      'signup_confirm': 'bg-blue-100 text-blue-800',
      'password_reset': 'bg-orange-100 text-orange-800', 
      'magic_link': 'bg-purple-100 text-purple-800',
      'invite': 'bg-green-100 text-green-800'
    };
    
    return (
      <Badge variant="outline" className={colors[type as keyof typeof colors] || ''}>
        {type.replace('_', ' ')}
      </Badge>
    );
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold">Email Management</h1>
        <Button
          onClick={() => refetch()}
          variant="outline"
          size="sm"
        >
          <RefreshCw className="mr-2 h-4 w-4" />
          Refresh Logs
        </Button>
      </div>

      <Tabs defaultValue="logs" className="w-full">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="logs">Email Logs</TabsTrigger>
          <TabsTrigger value="test">Test Emails</TabsTrigger>
          <TabsTrigger value="settings">Configuration</TabsTrigger>
        </TabsList>

        <TabsContent value="logs" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Eye className="mr-2 h-5 w-5" />
                Email Activity Logs
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex gap-4 mb-4">
                <div className="flex items-center gap-2">
                  <Filter className="h-4 w-4" />
                  <Select value={filterType} onValueChange={setFilterType}>
                    <SelectTrigger className="w-48">
                      <SelectValue placeholder="Filter by type" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Types</SelectItem>
                      <SelectItem value="signup_confirm">Signup Confirmation</SelectItem>
                      <SelectItem value="password_reset">Password Reset</SelectItem>
                      <SelectItem value="magic_link">Magic Link</SelectItem>
                      <SelectItem value="invite">Team Invite</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <Select value={filterStatus} onValueChange={setFilterStatus}>
                  <SelectTrigger className="w-32">
                    <SelectValue placeholder="Status" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Status</SelectItem>
                    <SelectItem value="sent">Sent</SelectItem>
                    <SelectItem value="failed">Failed</SelectItem>
                    <SelectItem value="queued">Queued</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              {isLoading ? (
                <div className="flex items-center justify-center py-8">
                  <RefreshCw className="h-6 w-6 animate-spin" />
                  <span className="ml-2">Loading email logs...</span>
                </div>
              ) : (
                <div className="rounded-md border">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Type</TableHead>
                        <TableHead>Recipient</TableHead>
                        <TableHead>Subject</TableHead>
                        <TableHead>Status</TableHead>
                        <TableHead>Sent At</TableHead>
                        <TableHead>Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {filteredLogs.length === 0 ? (
                        <TableRow>
                          <TableCell colSpan={6} className="text-center py-8 text-muted-foreground">
                            No email logs found
                          </TableCell>
                        </TableRow>
                      ) : (
                        filteredLogs.map((log) => (
                          <TableRow key={log.id}>
                            <TableCell>{getTypeBadge(log.template_key)}</TableCell>
                            <TableCell className="font-mono text-sm">{log.to_email}</TableCell>
                            <TableCell>{log.subject}</TableCell>
                            <TableCell>{getStatusBadge(log.status)}</TableCell>
                            <TableCell>{new Date(log.created_at).toLocaleString()}</TableCell>
                            <TableCell>
                              <Button
                                onClick={() => handleResendLog(log)}
                                variant="outline"
                                size="sm"
                                className="h-8"
                              >
                                <RotateCcw className="h-3 w-3 mr-1" />
                                Resend
                              </Button>
                            </TableCell>
                          </TableRow>
                        ))
                      )}
                    </TableBody>
                  </Table>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="test" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Test Supabase Auth Emails</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="testEmail">Test Email Address</Label>
                <Input
                  id="testEmail"
                  type="email"
                  placeholder="test@example.com"
                  value={testEmail}
                  onChange={(e) => setTestEmail(e.target.value)}
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <Button
                  onClick={() => handleTestEmail('signup_confirm')}
                  disabled={!testEmail || signupConfirmMutation.isPending}
                  className="w-full"
                >
                  {signupConfirmMutation.isPending && <RefreshCw className="mr-2 h-4 w-4 animate-spin" />}
                  <Send className="mr-2 h-4 w-4" />
                  Send Signup Confirmation
                </Button>

                <Button
                  onClick={() => handleTestEmail('password_reset')}
                  disabled={!testEmail || passwordResetMutation.isPending}
                  variant="outline"
                  className="w-full"
                >
                  {passwordResetMutation.isPending && <RefreshCw className="mr-2 h-4 w-4 animate-spin" />}
                  <Send className="mr-2 h-4 w-4" />
                  Send Password Reset
                </Button>

                <Button
                  onClick={() => handleTestEmail('magic_link')}
                  disabled={!testEmail || magicLinkMutation.isPending}
                  variant="outline"
                  className="w-full"
                >
                  {magicLinkMutation.isPending && <RefreshCw className="mr-2 h-4 w-4 animate-spin" />}
                  <Send className="mr-2 h-4 w-4" />
                  Send Magic Link
                </Button>

                <Button
                  onClick={() => handleTestEmail('invite')}
                  disabled={!testEmail || inviteUserMutation.isPending}
                  variant="outline"
                  className="w-full"
                >
                  {inviteUserMutation.isPending && <RefreshCw className="mr-2 h-4 w-4 animate-spin" />}
                  <Send className="mr-2 h-4 w-4" />
                  Send Team Invite
                </Button>
              </div>

              <Alert>
                <AlertCircle className="h-4 w-4" />
                <AlertDescription>
                  Test emails will be sent using Supabase Auth's native email system. 
                  Make sure email confirmation is enabled in your Supabase project settings.
                </AlertDescription>
              </Alert>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="settings" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Supabase Auth Configuration</CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <Alert>
                <AlertCircle className="h-4 w-4" />
                <AlertDescription>
                  This application now uses Supabase Auth's native email system. 
                  Configure email templates and settings in your Supabase dashboard under Authentication → Email Templates.
                </AlertDescription>
              </Alert>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label className="text-sm font-medium">Email Provider</Label>
                  <p className="text-sm text-muted-foreground">Supabase Auth (Native)</p>
                </div>
                <div>
                  <Label className="text-sm font-medium">Email Types</Label>
                  <p className="text-sm text-muted-foreground">Confirmation, Reset, Magic Link, Invite</p>
                </div>
                <div>
                  <Label className="text-sm font-medium">Rate Limiting</Label>
                  <p className="text-sm text-muted-foreground">3 emails per hour per recipient</p>
                </div>
                <div>
                  <Label className="text-sm font-medium">Real-time Logs</Label>
                  <p className="text-sm text-muted-foreground">Enabled with Supabase Realtime</p>
                </div>
              </div>

              <div className="p-4 bg-blue-50 border-blue-200 border rounded-lg">
                <h4 className="font-medium text-blue-800 mb-2">📧 Email Template Configuration</h4>
                <p className="text-xs text-blue-700 mb-2">
                  Customize your email templates in the Supabase dashboard:
                </p>
                <ol className="text-xs text-blue-700 space-y-1 list-decimal list-inside">
                  <li>Go to your Supabase project dashboard</li>
                  <li>Navigate to Authentication → Email Templates</li>
                  <li>Customize templates for: Confirm signup, Magic link, Reset password, Invite user</li>
                  <li>Add your brand colors, logo, and messaging</li>
                </ol>
              </div>

              <div className="p-4 bg-green-50 border-green-200 border rounded-lg">
                <h4 className="font-medium text-green-800 mb-2">✅ Current Configuration</h4>
                <ul className="text-xs text-green-700 space-y-1">
                  <li>• <strong>Site URL:</strong> Configure in Supabase Auth settings</li>
                  <li>• <strong>Redirect URLs:</strong> Set allowed domains in Supabase</li>
                  <li>• <strong>Email confirmation:</strong> Enable in Supabase Auth settings</li>
                  <li>• <strong>Rate limiting:</strong> Built into this application (3/hour)</li>
                </ul>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}