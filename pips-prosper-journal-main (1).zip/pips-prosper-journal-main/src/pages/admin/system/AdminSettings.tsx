import { useEffect, useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  SlidersHorizontal, 
  Save,
  Settings2,
  Database,
  Mail,
  Shield,
  Globe
} from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "@/hooks/use-toast";

interface SystemSettings {
  maintenance_mode: boolean;
  new_registrations: boolean;
  affiliate_program: boolean;
  default_commission_rate: number;
  min_payout_amount: number;
  payout_processing_days: number;
  support_email: string;
  company_name: string;
  site_url: string;
}

export default function AdminSettings() {
  const [settings, setSettings] = useState<SystemSettings>({
    maintenance_mode: false,
    new_registrations: true,
    affiliate_program: true,
    default_commission_rate: 30,
    min_payout_amount: 50,
    payout_processing_days: 14,
    support_email: "support@piptrackr.com",
    company_name: "PipTrackr.com",
    site_url: "https://piptrackr.com"
  });
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  const fetchSettings = async () => {
    try {
      const { data, error } = await supabase
        .from('cms_blocks')
        .select('*')
        .eq('key', 'system_settings')
        .single();

      if (error && error.code !== 'PGRST116') {
        throw error;
      }

      if (data?.content_json) {
        setSettings({ ...settings, ...(data.content_json as Partial<SystemSettings>) });
      }
    } catch (error) {
      console.error('Error fetching settings:', error);
    } finally {
      setLoading(false);
    }
  };

  const saveSettings = async () => {
    setSaving(true);
    try {
      const { error } = await supabase
        .from('cms_blocks')
        .upsert({
          key: 'system_settings',
          content_json: settings as any,
          updated_by: (await supabase.auth.getUser()).data.user?.id
        });

      if (error) throw error;

      toast({
        title: "Settings Saved",
        description: "System settings have been updated successfully.",
      });
    } catch (error) {
      console.error('Error saving settings:', error);
      toast({
        title: "Error",
        description: "Failed to save settings",
        variant: "destructive",
      });
    } finally {
      setSaving(false);
    }
  };

  useEffect(() => {
    fetchSettings();
  }, []);

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-foreground">System Settings</h1>
          <p className="text-muted-foreground">
            Configure system-wide settings and preferences
          </p>
        </div>
        <Button onClick={saveSettings} disabled={saving}>
          <Save className="w-4 h-4 mr-2" />
          {saving ? 'Saving...' : 'Save Settings'}
        </Button>
      </div>

      <Tabs defaultValue="general" className="space-y-6">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="general">
            <Settings2 className="w-4 h-4 mr-2" />
            General
          </TabsTrigger>
          <TabsTrigger value="affiliate">
            <SlidersHorizontal className="w-4 h-4 mr-2" />
            Affiliate
          </TabsTrigger>
          <TabsTrigger value="security">
            <Shield className="w-4 h-4 mr-2" />
            Security
          </TabsTrigger>
          <TabsTrigger value="company">
            <Globe className="w-4 h-4 mr-2" />
            Company
          </TabsTrigger>
        </TabsList>

        <TabsContent value="general" className="space-y-6">
          <Card className="glass-card border-card-border">
            <CardHeader>
              <CardTitle>System Status</CardTitle>
              <CardDescription>
                Control system availability and user access
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label htmlFor="maintenance">Maintenance Mode</Label>
                  <p className="text-sm text-muted-foreground">
                    Put the system in maintenance mode to prevent user access
                  </p>
                </div>
                <Switch
                  id="maintenance"
                  checked={settings.maintenance_mode}
                  onCheckedChange={(checked) =>
                    setSettings({ ...settings, maintenance_mode: checked })
                  }
                />
              </div>

              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label htmlFor="registrations">New Registrations</Label>
                  <p className="text-sm text-muted-foreground">
                    Allow new users to register for accounts
                  </p>
                </div>
                <Switch
                  id="registrations"
                  checked={settings.new_registrations}
                  onCheckedChange={(checked) =>
                    setSettings({ ...settings, new_registrations: checked })
                  }
                />
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="affiliate" className="space-y-6">
          <Card className="glass-card border-card-border">
            <CardHeader>
              <CardTitle>Affiliate Program Settings</CardTitle>
              <CardDescription>
                Configure affiliate program parameters and commission rates
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label htmlFor="affiliate-program">Affiliate Program</Label>
                  <p className="text-sm text-muted-foreground">
                    Enable or disable the affiliate program
                  </p>
                </div>
                <Switch
                  id="affiliate-program"
                  checked={settings.affiliate_program}
                  onCheckedChange={(checked) =>
                    setSettings({ ...settings, affiliate_program: checked })
                  }
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="commission-rate">Default Commission Rate (%)</Label>
                <Input
                  id="commission-rate"
                  type="number"
                  min="0"
                  max="100"
                  value={settings.default_commission_rate}
                  onChange={(e) =>
                    setSettings({ ...settings, default_commission_rate: parseInt(e.target.value) })
                  }
                />
                <p className="text-sm text-muted-foreground">
                  Default commission rate for new affiliates
                </p>
              </div>

              <div className="space-y-2">
                <Label htmlFor="min-payout">Minimum Payout Amount ($)</Label>
                <Input
                  id="min-payout"
                  type="number"
                  min="0"
                  value={settings.min_payout_amount}
                  onChange={(e) =>
                    setSettings({ ...settings, min_payout_amount: parseInt(e.target.value) })
                  }
                />
                <p className="text-sm text-muted-foreground">
                  Minimum amount required for payout requests
                </p>
              </div>

              <div className="space-y-2">
                <Label htmlFor="processing-days">Payout Processing Days</Label>
                <Input
                  id="processing-days"
                  type="number"
                  min="0"
                  value={settings.payout_processing_days}
                  onChange={(e) =>
                    setSettings({ ...settings, payout_processing_days: parseInt(e.target.value) })
                  }
                />
                <p className="text-sm text-muted-foreground">
                  Number of days to hold commission payments before processing
                </p>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="security" className="space-y-6">
          <Card className="glass-card border-card-border">
            <CardHeader>
              <CardTitle>Security Settings</CardTitle>
              <CardDescription>
                Configure security and authentication settings
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-2">
                <Label htmlFor="support-email">Support Email</Label>
                <Input
                  id="support-email"
                  type="email"
                  value={settings.support_email}
                  onChange={(e) =>
                    setSettings({ ...settings, support_email: e.target.value })
                  }
                />
                <p className="text-sm text-muted-foreground">
                  Email address for support and security notifications
                </p>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="company" className="space-y-6">
          <Card className="glass-card border-card-border">
            <CardHeader>
              <CardTitle>Company Information</CardTitle>
              <CardDescription>
                Update company details and branding information
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-2">
                <Label htmlFor="company-name">Company Name</Label>
                <Input
                  id="company-name"
                  value={settings.company_name}
                  onChange={(e) =>
                    setSettings({ ...settings, company_name: e.target.value })
                  }
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="site-url">Site URL</Label>
                <Input
                  id="site-url"
                  type="url"
                  value={settings.site_url}
                  onChange={(e) =>
                    setSettings({ ...settings, site_url: e.target.value })
                  }
                />
                <p className="text-sm text-muted-foreground">
                  Primary website URL for your application
                </p>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}