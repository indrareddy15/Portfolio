import { TeamManager } from "@/components/admin/TeamManager";

export default function AdminTeam() {
  return <TeamManager />;
}