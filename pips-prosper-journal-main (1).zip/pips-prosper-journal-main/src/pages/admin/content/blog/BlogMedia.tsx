import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from "@/components/ui/table";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { supabase } from "@/integrations/supabase/client";
import { 
  Plus, 
  Search, 
  MoreHorizontal, 
  Trash2, 
  Eye,
  Image,
  Upload,
  Download,
  Copy,
  Zap
} from "lucide-react";
import { toast } from "sonner";
import { format } from "date-fns";

interface MediaFile {
  id: string;
  url: string;
  alt: string | null;
  file_size: number | null;
  width: number | null;
  height: number | null;
  mime_type: string | null;
  created_at: string;
}

export default function BlogMedia() {
  const [mediaFiles, setMediaFiles] = useState<MediaFile[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState("");
  const [currentPage, setCurrentPage] = useState(1);
  const [totalFiles, setTotalFiles] = useState(0);
  const [uploading, setUploading] = useState(false);
  const filesPerPage = 20;

  useEffect(() => {
    fetchMediaFiles();
  }, [searchQuery, currentPage]);

  // Real-time updates for media files
  useEffect(() => {
    const channel = supabase
      .channel('blog-media-realtime')
      .on('postgres_changes', 
        { event: 'INSERT', schema: 'public', table: 'blog_media' },
        (payload) => {
          const newFile = payload.new as MediaFile;
          setMediaFiles(prev => [newFile, ...prev]);
          setTotalFiles(prev => prev + 1);
          toast.success('New media file uploaded');
        }
      )
      .on('postgres_changes', 
        { event: 'DELETE', schema: 'public', table: 'blog_media' },
        (payload) => {
          const deletedId = payload.old.id;
          setMediaFiles(prev => prev.filter(f => f.id !== deletedId));
          setTotalFiles(prev => prev - 1);
          toast.success('Media file deleted');
        }
      )
      .on('postgres_changes', 
        { event: 'UPDATE', schema: 'public', table: 'blog_media' },
        (payload) => {
          const updatedFile = payload.new as MediaFile;
          setMediaFiles(prev => prev.map(f => f.id === updatedFile.id ? updatedFile : f));
          toast.success('Media file updated');
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, []);

  const fetchMediaFiles = async () => {
    setLoading(true);
    
    try {
      let query = supabase
        .from('blog_media')
        .select('*')
        .order('created_at', { ascending: false });

      // Apply search filter
      if (searchQuery) {
        query = query.or(`alt.ilike.%${searchQuery}%,url.ilike.%${searchQuery}%`);
      }

      // Get total count
      const { count } = await supabase
        .from('blog_media')
        .select('*', { count: 'exact', head: true });
      setTotalFiles(count || 0);

      // Get paginated results
      const { data: filesData, error } = await query
        .range((currentPage - 1) * filesPerPage, currentPage * filesPerPage - 1);

      if (error) throw error;
      
      setMediaFiles(filesData || []);
      
    } catch (error) {
      console.error('Error fetching media files:', error);
      toast.error('Failed to fetch media files');
    } finally {
      setLoading(false);
    }
  };

  const handleFileUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const files = event.target.files;
    if (!files || files.length === 0) return;

    setUploading(true);
    
    try {
      const uploadPromises = Array.from(files).map(async (file) => {
        const fileExt = file.name.split('.').pop();
        const fileName = `${Date.now()}-${Math.random().toString(36).substring(7)}.${fileExt}`;
        const filePath = `media/${new Date().getFullYear()}/${String(new Date().getMonth() + 1).padStart(2, '0')}/${fileName}`;

        // Upload to storage
        const { error: uploadError } = await supabase.storage
          .from('blog-media')
          .upload(filePath, file);

        if (uploadError) throw uploadError;

        // Get public URL
        const { data: { publicUrl } } = supabase.storage
          .from('blog-media')
          .getPublicUrl(filePath);

        // Get image dimensions if it's an image
        let width: number | null = null;
        let height: number | null = null;
        
        if (file.type.startsWith('image/')) {
          await new Promise<void>((resolve) => {
            const img = document.createElement('img');
            img.onload = () => {
              width = img.width;
              height = img.height;
              resolve();
            };
            img.src = URL.createObjectURL(file);
          });
        }

        // Save to database
        const { error: dbError } = await supabase
          .from('blog_media')
          .insert({
            url: publicUrl,
            alt: file.name.replace(/\.[^/.]+$/, ""),
            file_size: file.size,
            width,
            height,
            mime_type: file.type
          });

        if (dbError) throw dbError;
      });

      await Promise.all(uploadPromises);
      toast.success(`${files.length} file(s) uploaded successfully`);
      
    } catch (error) {
      console.error('Error uploading files:', error);
      toast.error('Failed to upload files');
    } finally {
      setUploading(false);
      // Reset input
      event.target.value = '';
    }
  };

  const handleDelete = async (mediaFile: MediaFile) => {
    if (!confirm(`Are you sure you want to delete this media file?`)) return;
    
    try {
      // Delete from storage
      const urlParts = mediaFile.url.split('/');
      const pathParts = urlParts.slice(-4); // Get last 4 parts (media/year/month/filename)
      const filePath = pathParts.join('/');
      
      await supabase.storage.from('blog-media').remove([filePath]);
      
      // Delete from database
      const { error } = await supabase
        .from('blog_media')
        .delete()
        .eq('id', mediaFile.id);
      
      if (error) throw error;
      
    } catch (error) {
      console.error('Error deleting media file:', error);
      toast.error('Failed to delete media file');
    }
  };

  const copyUrl = async (url: string) => {
    try {
      await navigator.clipboard.writeText(url);
      toast.success('URL copied to clipboard');
    } catch (error) {
      toast.error('Failed to copy URL');
    }
  };

  const formatFileSize = (bytes: number | null) => {
    if (!bytes) return 'Unknown';
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(1024));
    return Math.round(bytes / Math.pow(1024, i) * 100) / 100 + ' ' + sizes[i];
  };

  const totalPages = Math.ceil(totalFiles / filesPerPage);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div>
            <h1 className="text-3xl font-bold text-foreground">Media Library</h1>
            <p className="text-muted-foreground">Manage your blog media files</p>
          </div>
          <Badge variant="outline" className="ml-2 text-xs">
            <Zap className="w-3 h-3 mr-1" />
            Real-time
          </Badge>
        </div>
        <div className="flex items-center gap-2">
          <input
            type="file"
            id="media-upload"
            multiple
            accept="image/*,video/*,audio/*,.pdf,.doc,.docx"
            onChange={handleFileUpload}
            className="hidden"
          />
          <label htmlFor="media-upload">
            <Button asChild disabled={uploading}>
              <span className="cursor-pointer">
                <Upload className="w-4 h-4 mr-2" />
                {uploading ? 'Uploading...' : 'Upload Files'}
              </span>
            </Button>
          </label>
        </div>
      </div>

      {/* Search */}
      <Card>
        <CardContent className="p-4">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground w-4 h-4" />
            <Input
              placeholder="Search media files..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10"
            />
          </div>
        </CardContent>
      </Card>

      {/* Media Files Grid/Table */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Image className="w-5 h-5" />
            Media Files ({totalFiles})
          </CardTitle>
        </CardHeader>
        <CardContent>
          {loading ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {[...Array(6)].map((_, i) => (
                <div key={i} className="animate-pulse">
                  <div className="aspect-video bg-muted rounded-lg mb-2"></div>
                  <div className="h-4 bg-muted rounded w-3/4 mb-1"></div>
                  <div className="h-3 bg-muted rounded w-1/2"></div>
                </div>
              ))}
            </div>
          ) : mediaFiles.length === 0 ? (
            <div className="text-center py-8">
              <Image className="w-12 h-12 mx-auto mb-4 text-muted-foreground" />
              <h3 className="text-lg font-medium text-muted-foreground mb-2">
                No media files found
              </h3>
              <p className="text-muted-foreground mb-4">
                Start by uploading your first media file.
              </p>
              <label htmlFor="media-upload">
                <Button asChild>
                  <span className="cursor-pointer">
                    <Plus className="w-4 h-4 mr-2" />
                    Upload Files
                  </span>
                </Button>
              </label>
            </div>
          ) : (
            <>
              {/* Grid View */}
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
                {mediaFiles.map((file) => (
                  <Card key={file.id} className="group hover:shadow-md transition-shadow">
                    <CardContent className="p-4">
                      {/* Media Preview */}
                      <div className="aspect-video bg-muted rounded-lg mb-3 flex items-center justify-center overflow-hidden">
                        {file.mime_type?.startsWith('image/') ? (
                          <img 
                            src={file.url} 
                            alt={file.alt || 'Media file'} 
                            className="w-full h-full object-cover"
                          />
                        ) : (
                          <div className="text-center p-4">
                            <Image className="w-8 h-8 mx-auto mb-2 text-muted-foreground" />
                            <div className="text-xs text-muted-foreground">
                              {file.mime_type || 'Unknown type'}
                            </div>
                          </div>
                        )}
                      </div>
                      
                      {/* File Info */}
                      <div className="space-y-2">
                        <div className="flex items-start justify-between gap-2">
                          <div className="flex-1 min-w-0">
                            <h4 className="text-sm font-medium truncate" title={file.alt || 'Untitled'}>
                              {file.alt || 'Untitled'}
                            </h4>
                            <div className="text-xs text-muted-foreground">
                              {file.width && file.height && `${file.width}×${file.height} • `}
                              {formatFileSize(file.file_size)}
                            </div>
                            <div className="text-xs text-muted-foreground">
                              {format(new Date(file.created_at), 'MMM dd, yyyy')}
                            </div>
                          </div>
                          
                          {/* Actions */}
                          <DropdownMenu>
                            <DropdownMenuTrigger asChild>
                              <Button variant="ghost" size="sm" className="opacity-0 group-hover:opacity-100 transition-opacity">
                                <MoreHorizontal className="w-4 h-4" />
                              </Button>
                            </DropdownMenuTrigger>
                            <DropdownMenuContent align="end">
                              <DropdownMenuItem onClick={() => window.open(file.url, '_blank')}>
                                <Eye className="w-4 h-4 mr-2" />
                                View
                              </DropdownMenuItem>
                              <DropdownMenuItem onClick={() => copyUrl(file.url)}>
                                <Copy className="w-4 h-4 mr-2" />
                                Copy URL
                              </DropdownMenuItem>
                              <DropdownMenuItem asChild>
                                <a href={file.url} download>
                                  <Download className="w-4 h-4 mr-2" />
                                  Download
                                </a>
                              </DropdownMenuItem>
                              <DropdownMenuItem 
                                onClick={() => handleDelete(file)}
                                className="text-red-600"
                              >
                                <Trash2 className="w-4 h-4 mr-2" />
                                Delete
                              </DropdownMenuItem>
                            </DropdownMenuContent>
                          </DropdownMenu>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>

              {/* Pagination */}
              {totalPages > 1 && (
                <div className="flex items-center justify-center space-x-2 mt-6">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setCurrentPage(prev => Math.max(prev - 1, 1))}
                    disabled={currentPage <= 1}
                  >
                    Previous
                  </Button>
                  
                  <span className="text-sm text-muted-foreground">
                    Page {currentPage} of {totalPages}
                  </span>
                  
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setCurrentPage(prev => Math.min(prev + 1, totalPages))}
                    disabled={currentPage >= totalPages}
                  >
                    Next
                  </Button>
                </div>
              )}
            </>
          )}
        </CardContent>
      </Card>
    </div>
  );
}