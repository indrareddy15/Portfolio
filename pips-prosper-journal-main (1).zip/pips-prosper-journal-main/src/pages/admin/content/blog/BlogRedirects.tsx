import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from "@/components/ui/table";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { supabase } from "@/integrations/supabase/client";
import { 
  Plus, 
  Search, 
  MoreHorizontal, 
  Edit, 
  Trash2,
  ExternalLink,
  Zap,
  Link as LinkIcon
} from "lucide-react";
import { toast } from "sonner";
import { format } from "date-fns";

interface BlogRedirect {
  id: string;
  from_path: string;
  to_url: string;
  status_code: number;
  note: string | null;
  created_at: string;
}

export default function BlogRedirects() {
  const [redirects, setRedirects] = useState<BlogRedirect[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState("");
  const [showCreateDialog, setShowCreateDialog] = useState(false);
  const [editingRedirect, setEditingRedirect] = useState<BlogRedirect | null>(null);
  const [formData, setFormData] = useState({
    from_path: "",
    to_url: "",
    status_code: 301,
    note: ""
  });

  useEffect(() => {
    fetchRedirects();
  }, [searchQuery]);

  // Real-time updates for redirects
  useEffect(() => {
    const channel = supabase
      .channel('blog-redirects-realtime')
      .on('postgres_changes', 
        { event: 'INSERT', schema: 'public', table: 'blog_redirects' },
        (payload) => {
          const newRedirect = payload.new as BlogRedirect;
          setRedirects(prev => [newRedirect, ...prev]);
          toast.success('Redirect created successfully');
        }
      )
      .on('postgres_changes', 
        { event: 'UPDATE', schema: 'public', table: 'blog_redirects' },
        (payload) => {
          const updatedRedirect = payload.new as BlogRedirect;
          setRedirects(prev => prev.map(redirect => 
            redirect.id === updatedRedirect.id ? updatedRedirect : redirect
          ));
          toast.success('Redirect updated successfully');
        }
      )
      .on('postgres_changes', 
        { event: 'DELETE', schema: 'public', table: 'blog_redirects' },
        (payload) => {
          const deletedId = payload.old.id;
          setRedirects(prev => prev.filter(redirect => redirect.id !== deletedId));
          toast.success('Redirect deleted successfully');
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, []);

  const fetchRedirects = async () => {
    setLoading(true);
    
    try {
      let query = supabase
        .from('blog_redirects')
        .select('*')
        .order('created_at', { ascending: false });

      // Apply search filter
      if (searchQuery) {
        query = query.or(`from_path.ilike.%${searchQuery}%,to_url.ilike.%${searchQuery}%,note.ilike.%${searchQuery}%`);
      }

      const { data, error } = await query;
      
      if (error) throw error;
      setRedirects(data || []);
      
    } catch (error) {
      console.error('Error fetching redirects:', error);
      toast.error('Failed to fetch redirects');
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.from_path.trim() || !formData.to_url.trim()) {
      toast.error('From path and to URL are required');
      return;
    }

    // Ensure from_path starts with /
    const fromPath = formData.from_path.startsWith('/') 
      ? formData.from_path 
      : `/${formData.from_path}`;
    
    try {
      if (editingRedirect) {
        // Update existing redirect
        const { error } = await supabase
          .from('blog_redirects')
          .update({
            from_path: fromPath,
            to_url: formData.to_url.trim(),
            status_code: formData.status_code,
            note: formData.note.trim() || null
          })
          .eq('id', editingRedirect.id);
        
        if (error) throw error;
      } else {
        // Create new redirect  
        const { error } = await supabase
          .from('blog_redirects')
          .insert({
            from_path: fromPath,
            to_url: formData.to_url.trim(),
            status_code: formData.status_code,
            note: formData.note.trim() || null
          });
        
        if (error) throw error;
      }
      
      // Reset form and close dialog
      setFormData({ from_path: "", to_url: "", status_code: 301, note: "" });
      setShowCreateDialog(false);
      setEditingRedirect(null);
      
    } catch (error: any) {
      console.error('Error saving redirect:', error);
      if (error.code === '23505') {
        toast.error('A redirect for this path already exists');
      } else {
        toast.error('Failed to save redirect');
      }
    }
  };

  const handleEdit = (redirect: BlogRedirect) => {
    setEditingRedirect(redirect);
    setFormData({
      from_path: redirect.from_path,
      to_url: redirect.to_url,
      status_code: redirect.status_code,
      note: redirect.note || ""
    });
    setShowCreateDialog(true);
  };

  const handleDelete = async (redirect: BlogRedirect) => {
    if (!confirm(`Are you sure you want to delete the redirect from "${redirect.from_path}"?`)) return;
    
    try {
      const { error } = await supabase
        .from('blog_redirects')
        .delete()
        .eq('id', redirect.id);
      
      if (error) throw error;
      
    } catch (error) {
      console.error('Error deleting redirect:', error);
      toast.error('Failed to delete redirect');
    }
  };

  const resetForm = () => {
    setFormData({ from_path: "", to_url: "", status_code: 301, note: "" });
    setEditingRedirect(null);
  };

  const getStatusBadge = (statusCode: number) => {
    const color = statusCode === 301 ? 'bg-green-100 text-green-800' : 
                  statusCode === 302 ? 'bg-blue-100 text-blue-800' : 
                  'bg-gray-100 text-gray-800';
    return <Badge className={color}>{statusCode}</Badge>;
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div>
            <h1 className="text-3xl font-bold text-foreground">URL Redirects</h1>
            <p className="text-muted-foreground">Manage URL redirects and rewrites</p>
          </div>
          <Badge variant="outline" className="ml-2 text-xs">
            <Zap className="w-3 h-3 mr-1" />
            Real-time
          </Badge>
        </div>
        <Dialog open={showCreateDialog} onOpenChange={(open) => {
          setShowCreateDialog(open);
          if (!open) resetForm();
        }}>
          <DialogTrigger asChild>
            <Button>
              <Plus className="w-4 h-4 mr-2" />
              New Redirect
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>
                {editingRedirect ? 'Edit Redirect' : 'Create New Redirect'}
              </DialogTitle>
            </DialogHeader>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <Label htmlFor="from_path">From Path</Label>
                <Input
                  id="from_path"
                  value={formData.from_path}
                  onChange={(e) => setFormData(prev => ({ ...prev, from_path: e.target.value }))}
                  placeholder="/old-page-url"
                  required
                  className="font-mono"
                />
                <p className="text-xs text-muted-foreground mt-1">
                  The path to redirect from (will automatically add / if missing)
                </p>
              </div>
              
              <div>
                <Label htmlFor="to_url">To URL</Label>
                <Input
                  id="to_url"
                  value={formData.to_url}
                  onChange={(e) => setFormData(prev => ({ ...prev, to_url: e.target.value }))}
                  placeholder="https://example.com/new-page or /new-page"
                  required
                  className="font-mono"
                />
                <p className="text-xs text-muted-foreground mt-1">
                  The destination URL or path
                </p>
              </div>
              
              <div>
                <Label htmlFor="status_code">Status Code</Label>
                <Select 
                  value={formData.status_code.toString()} 
                  onValueChange={(value) => setFormData(prev => ({ ...prev, status_code: parseInt(value) }))}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="301">301 - Permanent Redirect</SelectItem>
                    <SelectItem value="302">302 - Temporary Redirect</SelectItem>
                    <SelectItem value="307">307 - Temporary Redirect (Method Preserved)</SelectItem>
                    <SelectItem value="308">308 - Permanent Redirect (Method Preserved)</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <div>
                <Label htmlFor="note">Note (Optional)</Label>
                <Textarea
                  id="note"
                  value={formData.note}
                  onChange={(e) => setFormData(prev => ({ ...prev, note: e.target.value }))}
                  placeholder="Internal note about this redirect..."
                  rows={2}
                />
              </div>
              
              <div className="flex gap-2 justify-end">
                <Button type="button" variant="outline" onClick={() => setShowCreateDialog(false)}>
                  Cancel
                </Button>
                <Button type="submit">
                  {editingRedirect ? 'Update' : 'Create'} Redirect
                </Button>
              </div>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      {/* Search */}
      <Card>
        <CardContent className="p-4">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground w-4 h-4" />
            <Input
              placeholder="Search redirects..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10"
            />
          </div>
        </CardContent>
      </Card>

      {/* Redirects Table */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <LinkIcon className="w-5 h-5" />
            Redirects ({redirects.length})
          </CardTitle>
        </CardHeader>
        <CardContent>
          {loading ? (
            <div className="space-y-3">
              {[...Array(5)].map((_, i) => (
                <div key={i} className="flex items-center space-x-4 animate-pulse">
                  <div className="flex-1 space-y-2">
                    <div className="h-4 bg-muted rounded w-3/4"></div>
                    <div className="h-3 bg-muted rounded w-1/2"></div>
                  </div>
                </div>
              ))}
            </div>
          ) : redirects.length === 0 ? (
            <div className="text-center py-8">
              <LinkIcon className="w-12 h-12 mx-auto mb-4 text-muted-foreground" />
              <h3 className="text-lg font-medium text-muted-foreground mb-2">
                No redirects found
              </h3>
              <p className="text-muted-foreground mb-4">
                Create your first redirect to handle old URLs and improve SEO.
              </p>
              <Button onClick={() => setShowCreateDialog(true)}>
                <Plus className="w-4 h-4 mr-2" />
                Create Redirect
              </Button>
            </div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>From Path</TableHead>
                  <TableHead>To URL</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Note</TableHead>
                  <TableHead>Created</TableHead>
                  <TableHead className="w-[50px]"></TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {redirects.map((redirect) => (
                  <TableRow key={redirect.id}>
                    <TableCell>
                      <code className="text-sm bg-muted px-2 py-1 rounded">
                        {redirect.from_path}
                      </code>
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        <code className="text-sm bg-muted px-2 py-1 rounded max-w-xs truncate">
                          {redirect.to_url}
                        </code>
                        {redirect.to_url.startsWith('http') && (
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => window.open(redirect.to_url, '_blank')}
                          >
                            <ExternalLink className="w-3 h-3" />
                          </Button>
                        )}
                      </div>
                    </TableCell>
                    <TableCell>
                      {getStatusBadge(redirect.status_code)}
                    </TableCell>
                    <TableCell>
                      {redirect.note ? (
                        <span className="text-sm text-muted-foreground" title={redirect.note}>
                          {redirect.note.length > 50 ? `${redirect.note.substring(0, 50)}...` : redirect.note}
                        </span>
                      ) : (
                        <span className="text-muted-foreground">-</span>
                      )}
                    </TableCell>
                    <TableCell>
                      <span className="text-sm text-muted-foreground">
                        {format(new Date(redirect.created_at), 'MMM dd, yyyy')}
                      </span>
                    </TableCell>
                    <TableCell>
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="sm">
                            <MoreHorizontal className="w-4 h-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          <DropdownMenuItem onClick={() => handleEdit(redirect)}>
                            <Edit className="w-4 h-4 mr-2" />
                            Edit
                          </DropdownMenuItem>
                          <DropdownMenuItem 
                            onClick={() => handleDelete(redirect)}
                            className="text-red-600"
                          >
                            <Trash2 className="w-4 h-4 mr-2" />
                            Delete
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>
    </div>
  );
}