import { useEffect, useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { 
  Search, 
  Filter, 
  Download, 
  CreditCard, 
  Users, 
  TrendingUp,
  AlertTriangle,
  CheckCircle,
  XCircle,
  Calendar
} from "lucide-react";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "@/hooks/use-toast";
import { useRealtime } from "@/hooks/useRealtime";

interface Subscriber {
  id: string;
  email: string;
  subscribed: boolean;
  subscription_tier: string | null;
  subscription_end: string | null;
  created_at: string;
  updated_at: string;
  stripe_customer_id: string | null;
}

interface SubscriptionStats {
  activeSubscriptions: number;
  monthlyRevenue: number;
  churnRate: number;
  failedPayments: number;
  planBreakdown: {
    pro: number;
    basic: number;
    premium: number;
  };
}

export default function AdminSubscriptions() {
  const [subscribers, setSubscribers] = useState<Subscriber[]>([]);
  const [stats, setStats] = useState<SubscriptionStats>({
    activeSubscriptions: 0,
    monthlyRevenue: 0,
    churnRate: 0,
    failedPayments: 0,
    planBreakdown: { pro: 0, basic: 0, premium: 0 }
  });
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState("");

  const fetchSubscriptions = async () => {
    try {
      const { data, error } = await supabase
        .from('subscribers')
        .select('*')
        .order('created_at', { ascending: false });

      if (error) throw error;

      setSubscribers(data || []);

      // Calculate stats
      const activeSubscriptions = data?.filter(s => s.subscribed).length || 0;
      const planBreakdown = {
        pro: data?.filter(s => s.subscription_tier === 'pro').length || 0,
        basic: data?.filter(s => s.subscription_tier === 'basic').length || 0,
        premium: data?.filter(s => s.subscription_tier === 'premium').length || 0
      };

      const monthlyRevenue = data?.reduce((acc, sub) => {
        if (!sub.subscribed) return acc;
        const tierRevenue = sub.subscription_tier === 'pro' ? 29 : 
                           sub.subscription_tier === 'premium' ? 49 : 19;
        return acc + tierRevenue;
      }, 0) || 0;

      setStats({
        activeSubscriptions,
        monthlyRevenue,
        churnRate: 3.2, // This would be calculated based on historical data
        failedPayments: 0, // This would come from Stripe webhook data
        planBreakdown
      });
    } catch (error) {
      console.error('Error fetching subscriptions:', error);
      toast({
        title: "Error",
        description: "Failed to fetch subscriptions",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchSubscriptions();
  }, []);

  // Real-time subscription updates
  useRealtime([
    {
      table: 'subscribers',
      events: ['INSERT', 'UPDATE', 'DELETE'],
      onInsert: (payload) => {
        console.log('New subscriber:', payload.new);
        setSubscribers(prev => [payload.new, ...prev]);
        
        // Update stats
        setStats(prev => {
          const newActive = payload.new.subscribed ? prev.activeSubscriptions + 1 : prev.activeSubscriptions;
          const tierRevenue = payload.new.subscription_tier === 'pro' ? 29 : 
                             payload.new.subscription_tier === 'premium' ? 49 : 
                             payload.new.subscription_tier === 'basic' ? 19 : 0;
          const newRevenue = payload.new.subscribed ? prev.monthlyRevenue + tierRevenue : prev.monthlyRevenue;
          
          return {
            ...prev,
            activeSubscriptions: newActive,
            monthlyRevenue: newRevenue,
            planBreakdown: {
              ...prev.planBreakdown,
              [payload.new.subscription_tier || 'basic']: prev.planBreakdown[payload.new.subscription_tier as keyof typeof prev.planBreakdown] + 1
            }
          };
        });

        toast({
          title: "New Subscription! 🎉",
          description: `${payload.new.email} subscribed to ${payload.new.subscription_tier || 'basic'} plan`,
        });
      },
      onUpdate: (payload) => {
        console.log('Subscriber updated:', payload.new);
        setSubscribers(prev => prev.map(sub => 
          sub.id === payload.new.id ? payload.new : sub
        ));
        
        // If subscription status changed, update stats
        if (payload.old.subscribed !== payload.new.subscribed || 
            payload.old.subscription_tier !== payload.new.subscription_tier) {
          fetchSubscriptions(); // Refetch for accurate stats
          
          toast({
            title: payload.new.subscribed ? "Subscription Activated" : "Subscription Cancelled",
            description: `${payload.new.email} - ${payload.new.subscription_tier || 'basic'} plan`,
          });
        }
      },
      onDelete: (payload) => {
        console.log('Subscriber deleted:', payload.old);
        setSubscribers(prev => prev.filter(sub => sub.id !== payload.old.id));
        fetchSubscriptions(); // Refetch to update stats
        
        toast({
          title: "Subscription Removed",
          description: `${payload.old.email} subscription has been deleted`,
        });
      },
      channelName: 'admin-subscriptions-realtime'
    }
  ]);

  const filteredSubscribers = subscribers.filter(subscriber =>
    subscriber.email?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    subscriber.subscription_tier?.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const exportSubscriptions = () => {
    const csv = [
      ['Email', 'Plan', 'Status', 'Amount', 'Started', 'Ends'].join(','),
      ...filteredSubscribers.map(sub => [
        sub.email,
        sub.subscription_tier || 'Free',
        sub.subscribed ? 'Active' : 'Inactive',
        sub.subscription_tier === 'pro' ? '$29/month' : 
        sub.subscription_tier === 'premium' ? '$49/month' : 
        sub.subscription_tier === 'basic' ? '$19/month' : 'Free',
        new Date(sub.created_at).toLocaleDateString(),
        sub.subscription_end ? new Date(sub.subscription_end).toLocaleDateString() : 'N/A'
      ].join(','))
    ].join('\n');

    const blob = new Blob([csv], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'subscriptions-export.csv';
    a.click();
    window.URL.revokeObjectURL(url);

    toast({
      title: "Success",
      description: "Subscriptions exported successfully",
    });
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
      </div>
    );
  }
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-foreground">Subscriptions</h1>
          <p className="text-muted-foreground">
            Monitor subscription metrics, revenue, and customer lifecycle
          </p>
        </div>
        <div className="flex space-x-2">
          <Button variant="outline" onClick={exportSubscriptions}>
            <Download className="w-4 h-4 mr-2" />
            Export Data
          </Button>
          <Button variant="outline">
            <Filter className="w-4 h-4 mr-2" />
            Advanced Filters
          </Button>
        </div>
      </div>

      {/* Subscription Metrics */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Card className="glass-card border-card-border">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              Active Subscriptions
            </CardTitle>
            <Users className="h-4 w-4 text-primary" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-foreground">{stats.activeSubscriptions.toLocaleString()}</div>
            <p className="text-xs text-success">Active paying customers</p>
          </CardContent>
        </Card>

        <Card className="glass-card border-card-border">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              Monthly Revenue
            </CardTitle>
            <CreditCard className="h-4 w-4 text-primary" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-foreground">${stats.monthlyRevenue.toLocaleString()}</div>
            <p className="text-xs text-success">Monthly recurring revenue</p>
          </CardContent>
        </Card>

        <Card className="glass-card border-card-border">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              Churn Rate
            </CardTitle>
            <TrendingUp className="h-4 w-4 text-warning" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-foreground">3.2%</div>
            <p className="text-xs text-success">-0.5% from last month</p>
          </CardContent>
        </Card>

        <Card className="glass-card border-card-border">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              Failed Payments
            </CardTitle>
            <AlertTriangle className="h-4 w-4 text-destructive" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-foreground">23</div>
            <p className="text-xs text-warning">Requires attention</p>
          </CardContent>
        </Card>
      </div>

      {/* Plan Breakdown */}
      <div className="grid gap-6 md:grid-cols-2">
        <Card className="glass-card border-card-border">
          <CardHeader>
            <CardTitle>Subscription Plans</CardTitle>
            <CardDescription>
              Distribution of subscribers across different plans
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <div className="w-3 h-3 bg-primary rounded-full"></div>
                <span className="text-sm font-medium">Pro Plan ($29/month)</span>
              </div>
              <div className="text-right">
                <span className="text-sm font-bold">{stats.planBreakdown.pro}</span>
                <p className="text-xs text-muted-foreground">
                  {stats.activeSubscriptions > 0 ? Math.round((stats.planBreakdown.pro / stats.activeSubscriptions) * 100) : 0}% of total
                </p>
              </div>
            </div>
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <div className="w-3 h-3 bg-secondary rounded-full"></div>
                <span className="text-sm font-medium">Basic Plan ($19/month)</span>
              </div>
              <div className="text-right">
                <span className="text-sm font-bold">{stats.planBreakdown.basic}</span>
                <p className="text-xs text-muted-foreground">
                  {stats.activeSubscriptions > 0 ? Math.round((stats.planBreakdown.basic / stats.activeSubscriptions) * 100) : 0}% of total
                </p>
              </div>
            </div>
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <div className="w-3 h-3 bg-accent rounded-full"></div>
                <span className="text-sm font-medium">Premium Plan ($49/month)</span>
              </div>
              <div className="text-right">
                <span className="text-sm font-bold">{stats.planBreakdown.premium}</span>
                <p className="text-xs text-muted-foreground">
                  {stats.activeSubscriptions > 0 ? Math.round((stats.planBreakdown.premium / stats.activeSubscriptions) * 100) : 0}% of total
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="glass-card border-card-border">
          <CardHeader>
            <CardTitle>Recent Activity</CardTitle>
            <CardDescription>
              Latest subscription events and status changes
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center space-x-3">
              <CheckCircle className="w-4 h-4 text-success" />
              <div className="flex-1">
                <p className="text-sm font-medium">New Pro subscription</p>
                <p className="text-xs text-muted-foreground">sarah@trading.com • 2 hours ago</p>
              </div>
            </div>
            <div className="flex items-center space-x-3">
              <XCircle className="w-4 h-4 text-destructive" />
              <div className="flex-1">
                <p className="text-sm font-medium">Payment failed</p>
                <p className="text-xs text-muted-foreground">mike@forex.net • 4 hours ago</p>
              </div>
            </div>
            <div className="flex items-center space-x-3">
              <TrendingUp className="w-4 h-4 text-primary" />
              <div className="flex-1">
                <p className="text-sm font-medium">Upgraded to Premium</p>
                <p className="text-xs text-muted-foreground">john@trader.com • 6 hours ago</p>
              </div>
            </div>
            <div className="flex items-center space-x-3">
              <AlertTriangle className="w-4 h-4 text-warning" />
              <div className="flex-1">
                <p className="text-sm font-medium">Subscription cancelled</p>
                <p className="text-xs text-muted-foreground">alex@crypto.blog • 1 day ago</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Search */}
      <Card className="glass-card border-card-border">
        <CardContent className="pt-6">
          <div className="flex space-x-4">
            <div className="flex-1">
              <div className="relative">
                <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="Search subscriptions by user email, plan, or status..."
                  className="pl-8"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                />
              </div>
            </div>
            <Button>Search</Button>
          </div>
        </CardContent>
      </Card>

      {/* Subscriptions Table */}
      <Card className="glass-card border-card-border">
        <CardHeader>
          <CardTitle>All Subscriptions</CardTitle>
          <CardDescription>
            Complete list of customer subscriptions and billing status
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Customer</TableHead>
                <TableHead>Plan</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Amount</TableHead>
                <TableHead>Next Billing</TableHead>
                <TableHead>Started</TableHead>
                <TableHead>Affiliate</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredSubscribers.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={7} className="text-center text-muted-foreground">
                    {searchTerm ? "No subscriptions found matching your search" : "No subscriptions found"}
                  </TableCell>
                </TableRow>
              ) : (
                filteredSubscribers.map((subscriber) => (
                  <TableRow key={subscriber.id}>
                    <TableCell className="font-medium">
                      <div>
                        <p className="font-medium">{subscriber.email?.split('@')[0] || 'Unknown'}</p>
                        <p className="text-sm text-muted-foreground">{subscriber.email}</p>
                      </div>
                    </TableCell>
                    <TableCell>
                      <Badge variant={subscriber.subscription_tier ? "default" : "secondary"}>
                        {subscriber.subscription_tier ? `${subscriber.subscription_tier} Plan` : 'Free'}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      <Badge 
                        variant="outline" 
                        className={subscriber.subscribed ? "text-success border-success" : "text-muted-foreground border-muted"}
                      >
                        {subscriber.subscribed ? (
                          <>
                            <CheckCircle className="w-3 h-3 mr-1" />
                            Active
                          </>
                        ) : (
                          'Inactive'
                        )}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      {subscriber.subscription_tier === 'pro' ? '$29.00/month' :
                       subscriber.subscription_tier === 'premium' ? '$49.00/month' :
                       subscriber.subscription_tier === 'basic' ? '$19.00/month' : 'Free'}
                    </TableCell>
                    <TableCell>
                      {subscriber.subscription_end ? (
                        <div className="flex items-center text-sm">
                          <Calendar className="w-3 h-3 mr-1 text-muted-foreground" />
                          {new Date(subscriber.subscription_end).toLocaleDateString()}
                        </div>
                      ) : (
                        <span className="text-sm text-muted-foreground">Never</span>
                      )}
                    </TableCell>
                    <TableCell className="text-sm text-muted-foreground">
                      {new Date(subscriber.created_at).toLocaleDateString()}
                    </TableCell>
                    <TableCell>
                      <span className="text-muted-foreground text-sm">Direct</span>
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
}