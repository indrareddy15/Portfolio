import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  Users, 
  MousePointer, 
  UserPlus, 
  CreditCard, 
  TrendingUp, 
  Globe, 
  Smartphone,
  Monitor,
  RefreshCw
} from "lucide-react";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';

// Mock real-time data (in production, this would come from GA4 API or WebSocket)
const useRealtimeData = () => {
  const [realtimeUsers, setRealtimeUsers] = useState(42);
  const [topPages, setTopPages] = useState([
    { path: '/app/dashboard', users: 15 },
    { path: '/pricing', users: 8 },
    { path: '/', users: 6 },
    { path: '/app/journal', users: 5 },
    { path: '/affiliates', users: 4 }
  ]);

  useEffect(() => {
    // Simulate real-time updates
    const interval = setInterval(() => {
      setRealtimeUsers(prev => prev + Math.floor(Math.random() * 3) - 1);
    }, 5000);

    return () => clearInterval(interval);
  }, []);

  return { realtimeUsers, topPages };
};

// Mock analytics data (would be fetched from database/GA4)
const mockAnalyticsData = {
  last7Days: {
    users: 1247,
    sessions: 1843,
    signups: 89,
    imports: 156,
    subscriptions: 23,
    conversionRate: 1.85
  },
  last28Days: {
    users: 4521,
    sessions: 6789,
    signups: 287,
    imports: 578,
    subscriptions: 67,
    conversionRate: 1.48
  },
  trafficSources: [
    { name: 'Organic Search', value: 42, color: '#008ffd' },
    { name: 'Direct', value: 28, color: '#00d4aa' },
    { name: 'Social Media', value: 15, color: '#ff6b6b' },
    { name: 'Referral', value: 10, color: '#feca57' },
    { name: 'Paid Search', value: 5, color: '#ff9ff3' }
  ],
  deviceBreakdown: [
    { name: 'Desktop', value: 65, color: '#008ffd' },
    { name: 'Mobile', value: 28, color: '#00d4aa' },
    { name: 'Tablet', value: 7, color: '#ff6b6b' }
  ],
  dailyTrend: [
    { date: '2024-01-01', users: 45, sessions: 67, signups: 3 },
    { date: '2024-01-02', users: 52, sessions: 78, signups: 5 },
    { date: '2024-01-03', users: 48, sessions: 71, signups: 4 },
    { date: '2024-01-04', users: 61, sessions: 89, signups: 7 },
    { date: '2024-01-05', users: 55, sessions: 82, signups: 6 },
    { date: '2024-01-06', users: 47, sessions: 69, signups: 4 },
    { date: '2024-01-07', users: 58, sessions: 86, signups: 8 }
  ]
};

export default function MarketingOverview() {
  const { realtimeUsers, topPages } = useRealtimeData();
  const [selectedPeriod, setSelectedPeriod] = useState<'7d' | '28d'>('7d');
  const [lastRefresh, setLastRefresh] = useState(new Date());

  const currentData = selectedPeriod === '7d' ? mockAnalyticsData.last7Days : mockAnalyticsData.last28Days;

  const refreshData = () => {
    setLastRefresh(new Date());
    // In production, this would trigger a data refetch
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-semibold">Analytics Overview</h2>
          <p className="text-muted-foreground">
            Last updated: {lastRefresh.toLocaleTimeString()}
          </p>
        </div>
        <Button onClick={refreshData} variant="outline" size="sm">
          <RefreshCw className="h-4 w-4 mr-2" />
          Refresh
        </Button>
      </div>

      {/* Real-time Section */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <div className="h-3 w-3 bg-green-500 rounded-full animate-pulse" />
            Real-time Activity (Last 30 minutes)
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Active Users */}
            <div className="space-y-4">
              <div className="flex items-center gap-4">
                <div className="text-3xl font-bold text-primary">{realtimeUsers}</div>
                <div className="text-muted-foreground">Active users</div>
              </div>
            </div>

            {/* Top Pages */}
            <div className="space-y-3">
              <h4 className="font-medium">Top Active Pages</h4>
              <div className="space-y-2">
                {topPages.map((page, index) => (
                  <div key={page.path} className="flex items-center justify-between text-sm">
                    <span className="font-mono text-muted-foreground">{page.path}</span>
                    <Badge variant="secondary">{page.users} users</Badge>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Period Selector */}
      <Tabs value={selectedPeriod} onValueChange={(value) => setSelectedPeriod(value as '7d' | '28d')}>
        <TabsList>
          <TabsTrigger value="7d">Last 7 Days</TabsTrigger>
          <TabsTrigger value="28d">Last 28 Days</TabsTrigger>
        </TabsList>

        <TabsContent value={selectedPeriod} className="space-y-6">
          {/* Key Metrics Cards */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 gap-4">
            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between space-y-0">
                  <div className="space-y-2">
                    <p className="text-sm font-medium text-muted-foreground">Users</p>
                    <p className="text-2xl font-bold">{currentData.users.toLocaleString()}</p>
                  </div>
                  <Users className="h-8 w-8 text-primary" />
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between space-y-0">
                  <div className="space-y-2">
                    <p className="text-sm font-medium text-muted-foreground">Sessions</p>
                    <p className="text-2xl font-bold">{currentData.sessions.toLocaleString()}</p>
                  </div>
                  <MousePointer className="h-8 w-8 text-primary" />
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between space-y-0">
                  <div className="space-y-2">
                    <p className="text-sm font-medium text-muted-foreground">Sign-ups</p>
                    <p className="text-2xl font-bold">{currentData.signups}</p>
                  </div>
                  <UserPlus className="h-8 w-8 text-primary" />
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between space-y-0">
                  <div className="space-y-2">
                    <p className="text-sm font-medium text-muted-foreground">Imports</p>
                    <p className="text-2xl font-bold">{currentData.imports}</p>
                  </div>
                  <TrendingUp className="h-8 w-8 text-primary" />
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between space-y-0">
                  <div className="space-y-2">
                    <p className="text-sm font-medium text-muted-foreground">Subscriptions</p>
                    <p className="text-2xl font-bold">{currentData.subscriptions}</p>
                  </div>
                  <CreditCard className="h-8 w-8 text-primary" />
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between space-y-0">
                  <div className="space-y-2">
                    <p className="text-sm font-medium text-muted-foreground">Conv. Rate</p>
                    <p className="text-2xl font-bold">{currentData.conversionRate}%</p>
                  </div>
                  <TrendingUp className="h-8 w-8 text-primary" />
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Charts Section */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Daily Trend Chart */}
            <Card>
              <CardHeader>
                <CardTitle>Daily Trend</CardTitle>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <LineChart data={mockAnalyticsData.dailyTrend}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="date" tickFormatter={(date) => new Date(date).toLocaleDateString()} />
                    <YAxis />
                    <Tooltip labelFormatter={(date) => new Date(date).toLocaleDateString()} />
                    <Line type="monotone" dataKey="users" stroke="#008ffd" strokeWidth={2} />
                    <Line type="monotone" dataKey="signups" stroke="#00d4aa" strokeWidth={2} />
                  </LineChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            {/* Traffic Sources */}
            <Card>
              <CardHeader>
                <CardTitle>Traffic Sources</CardTitle>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <PieChart>
                    <Pie
                      data={mockAnalyticsData.trafficSources}
                      cx="50%"
                      cy="50%"
                      outerRadius={80}
                      fill="#8884d8"
                      dataKey="value"
                      label={({ name, value }) => `${name} ${value}%`}
                    >
                      {mockAnalyticsData.trafficSources.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={entry.color} />
                      ))}
                    </Pie>
                    <Tooltip />
                  </PieChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          </div>

          {/* Device Breakdown */}
          <Card>
            <CardHeader>
              <CardTitle>Device Breakdown</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                {mockAnalyticsData.deviceBreakdown.map((device) => {
                  const Icon = device.name === 'Desktop' ? Monitor : device.name === 'Mobile' ? Smartphone : Globe;
                  return (
                    <div key={device.name} className="flex items-center gap-4 p-4 border rounded-lg">
                      <Icon className="h-8 w-8 text-primary" />
                      <div>
                        <p className="font-medium">{device.name}</p>
                        <p className="text-2xl font-bold text-primary">{device.value}%</p>
                      </div>
                    </div>
                  );
                })}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}