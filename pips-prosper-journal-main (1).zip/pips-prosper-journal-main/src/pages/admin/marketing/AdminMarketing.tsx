import { Suspense, lazy } from "react";
import { Routes, Route } from "react-router-dom";
import { Skeleton } from "@/components/ui/skeleton";
import { SEOHead } from "@/components/SEOHead";

// Lazy load marketing pages for better performance
const MarketingOverview = lazy(() => import("./MarketingOverview"));
const MarketingAcquisition = lazy(() => import("./MarketingAcquisition"));
const MarketingEvents = lazy(() => import("./MarketingEvents"));
const MarketingCampaigns = lazy(() => import("./MarketingCampaigns"));
const MarketingSEO = lazy(() => import("./MarketingSEO"));
const MarketingExperiments = lazy(() => import("./MarketingExperiments"));
const MarketingPixels = lazy(() => import("./MarketingPixels"));

const LoadingSkeleton = () => (
  <div className="space-y-6">
    <Skeleton className="h-8 w-48" />
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
      {Array.from({ length: 4 }).map((_, i) => (
        <Skeleton key={i} className="h-24" />
      ))}
    </div>
    <Skeleton className="h-64 w-full" />
  </div>
);

export default function AdminMarketing() {
  return (
    <>
        <SEOHead 
          title="Marketing & Analytics - Admin Dashboard"
          description="Comprehensive marketing analytics, campaign management, and tracking tools"
        />
      
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-poppins font-bold text-foreground">
            Marketing & Analytics
          </h1>
          <p className="text-muted-foreground mt-1">
            Track performance, manage campaigns, and optimize conversions
          </p>
        </div>

        <Suspense fallback={<LoadingSkeleton />}>
          <Routes>
            <Route index element={<MarketingOverview />} />
            <Route path="acquisition" element={<MarketingAcquisition />} />
            <Route path="events" element={<MarketingEvents />} />
            <Route path="campaigns" element={<MarketingCampaigns />} />
            <Route path="seo" element={<MarketingSEO />} />
            <Route path="experiments" element={<MarketingExperiments />} />
            <Route path="pixels" element={<MarketingPixels />} />
          </Routes>
        </Suspense>
      </div>
    </>
  );
}