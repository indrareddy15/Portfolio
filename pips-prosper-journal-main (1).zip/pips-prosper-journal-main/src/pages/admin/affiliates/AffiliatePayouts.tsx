import { useEffect, useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { 
  Wallet, 
  CheckCircle, 
  XCircle, 
  Clock,
  Eye,
  Filter,
  Search,
  Plus,
  RefreshCw,
  DollarSign,
  AlertCircle,
  Send,
  Ban,
  Trash2,
  MoreHorizontal,
  Download
} from "lucide-react";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "@/hooks/use-toast";
import { useRealtime } from "@/hooks/useRealtime";
import { useAnalytics } from "@/hooks/useAnalytics";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import { 
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { PayoutActionDialog } from "./PayoutActionDialog";
import { PayoutBulkActions } from "../../../components/admin/PayoutBulkActions";

interface Payout {
  id: string;
  affiliate_id: string;
  amount: number;
  currency: string;
  details_json: any;
  method: string;
  reference: string;
  status: string; // Keep as string to match database
  created_at: string;
  updated_at: string;
  processed_at?: string;
  processed_by?: string;
  rejection_reason?: string;
  notes?: string;
  affiliate?: {
    code: string;
    user_id: string;
  };
}

interface PayoutStats {
  totalPayouts: number;
  pendingAmount: number;
  processedAmount: number;
  pendingCount: number;
}

export default function AffiliatePayouts() {
  const [payouts, setPayouts] = useState<Payout[]>([]);
  const [stats, setStats] = useState<PayoutStats>({
    totalPayouts: 0,
    pendingAmount: 0,
    processedAmount: 0,
    pendingCount: 0
  });
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState("");
  const [statusFilter, setStatusFilter] = useState<string>("all");
  const [showNewPayoutDialog, setShowNewPayoutDialog] = useState(false);
  const [selectedPayouts, setSelectedPayouts] = useState<string[]>([]);
  const [newPayoutForm, setNewPayoutForm] = useState({
    affiliate_id: '',
    amount: '',
    method: 'bank',
    currency: 'USD'
  });
  const [affiliates, setAffiliates] = useState<any[]>([]);
  const [creatingPayout, setCreatingPayout] = useState(false);
  const [actionDialog, setActionDialog] = useState<{
    show: boolean;
    type: 'approve' | 'process' | 'mark_paid' | 'reject' | 'cancel' | null;
    payout: Payout | null;
    reference?: string;
    notes?: string;
    rejection_reason?: string;
  }>({ show: false, type: null, payout: null });
  const [bulkActionInProgress, setBulkActionInProgress] = useState(false);
  
  const analytics = useAnalytics();

  const fetchPayouts = async () => {
    try {
      const { data, error } = await supabase
        .from('payouts')
        .select(`
          *,
          affiliates:affiliate_id (
            code,
            user_id
          )
        `)
        .order('created_at', { ascending: false });

      if (error) throw error;

      setPayouts(data || []);

      // Calculate stats
      const totalPayouts = data?.length || 0;
      const pendingAmount = data?.filter(p => ['requested', 'processing'].includes(p.status)).reduce((sum, p) => sum + p.amount, 0) || 0;
      const processedAmount = data?.filter(p => p.status === 'paid').reduce((sum, p) => sum + p.amount, 0) || 0;
      const pendingCount = data?.filter(p => ['requested', 'processing'].includes(p.status)).length || 0;

      setStats({ totalPayouts, pendingAmount, processedAmount, pendingCount });
    } catch (error) {
      console.error('Error fetching payouts:', error);
      toast({
        title: "Error",
        description: "Failed to fetch payouts",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const fetchAffiliates = async () => {
    try {
      const { data, error } = await supabase
        .from('affiliates')
        .select('id, code, status')
        .eq('status', 'active')
        .order('code');

      if (error) throw error;
      setAffiliates(data || []);
    } catch (error) {
      console.error('Error fetching affiliates:', error);
    }
  };

  const createNewPayout = async () => {
    if (!newPayoutForm.affiliate_id || !newPayoutForm.amount) {
      toast({
        title: "Error",
        description: "Please fill in all required fields",
        variant: "destructive",
      });
      return;
    }

    try {
      setCreatingPayout(true);

      const { error } = await supabase
        .from('payouts')
        .insert({
          affiliate_id: newPayoutForm.affiliate_id,
          amount: parseFloat(newPayoutForm.amount),
          currency: newPayoutForm.currency,
          method: newPayoutForm.method,
          status: 'requested',
          details_json: {
            created_by_admin: true,
            created_at: new Date().toISOString()
          }
        });

      if (error) throw error;

      toast({
        title: "Success",
        description: "Payout created successfully",
      });

      setShowNewPayoutDialog(false);
      setNewPayoutForm({
        affiliate_id: '',
        amount: '',
        method: 'bank',
        currency: 'USD'
      });
      
      fetchPayouts();
    } catch (error) {
      console.error('Error creating payout:', error);
      toast({
        title: "Error",
        description: "Failed to create payout",
        variant: "destructive",
      });
    } finally {
      setCreatingPayout(false);
    }
  };

  const handlePayoutAction = async (action: string, payout: Payout, additionalData?: any) => {
    try {
      setBulkActionInProgress(true);
      
      const response = await supabase.functions.invoke('payout-operations', {
        body: {
          operation: action,
          payout_id: payout.id,
          ...additionalData
        }
      });

      if (response.error) throw response.error;

      // Track analytics
      switch (action) {
        case 'approve':
        case 'process':
          analytics.trackPayoutRequested(payout.affiliate_id, payout.amount, payout.method);
          break;
        case 'mark_paid':
          analytics.trackPayoutPaid(payout.affiliate_id, payout.amount, additionalData?.reference || '');
          break;
      }

      toast({
        title: "Success",
        description: `Payout ${action === 'mark_paid' ? 'marked as paid' : action + 'd'} successfully`,
      });

      setActionDialog({ show: false, type: null, payout: null });
      fetchPayouts();
    } catch (error: any) {
      console.error('Error updating payout:', error);
      toast({
        title: "Error",
        description: error.message || "Failed to update payout",
        variant: "destructive",
      });
    } finally {
      setBulkActionInProgress(false);
    }
  };

  const handleBulkAction = async (action: string) => {
    if (selectedPayouts.length === 0) {
      toast({
        title: "No Selection",
        description: "Please select payouts to perform bulk actions",
        variant: "destructive",
      });
      return;
    }

    try {
      setBulkActionInProgress(true);
      
      const response = await supabase.functions.invoke('payout-operations', {
        body: {
          operation: 'bulk_action',
          payout_ids: selectedPayouts,
          bulk_action: action
        }
      });

      if (response.error) throw response.error;

      toast({
        title: "Bulk Action Complete",
        description: `${selectedPayouts.length} payouts ${action}d successfully`,
      });

      setSelectedPayouts([]);
      fetchPayouts();
    } catch (error: any) {
      console.error('Error with bulk action:', error);
      toast({
        title: "Error",
        description: error.message || "Failed to complete bulk action",
        variant: "destructive",
      });
    } finally {
      setBulkActionInProgress(false);
    }
  };

  useEffect(() => {
    fetchPayouts();
    fetchAffiliates();
  }, []);

  // Real-time payout updates
  useRealtime([
    {
      table: 'payouts',
      events: ['INSERT', 'UPDATE', 'DELETE'],
      onInsert: (payload) => {
        console.log('New payout request:', payload.new);
        setPayouts(prev => [payload.new, ...prev]);
        
        // Update stats
        setStats(prev => ({
          ...prev,
          totalPayouts: prev.totalPayouts + 1,
          pendingAmount: payload.new.status === 'requested' 
            ? prev.pendingAmount + Number(payload.new.amount)
            : prev.pendingAmount
        }));

        toast({
          title: "New Payout Request! 💸",
          description: `$${payload.new.amount} payout requested`,
        });
      },
      onUpdate: (payload) => {
        console.log('Payout updated:', payload.new);
        setPayouts(prev => prev.map(payout => 
          payout.id === payload.new.id ? payload.new : payout
        ));
        
        // Update stats if status changed
        if (payload.old.status !== payload.new.status) {
          const amount = Number(payload.new.amount);
          
          setStats(prev => {
            let newPending = prev.pendingAmount;
            let newProcessed = prev.processedAmount;
            
            // Remove from old status
            if (['requested', 'processing'].includes(payload.old.status)) newPending -= amount;
            if (payload.old.status === 'paid') newProcessed -= amount;
            
            // Add to new status
            if (['requested', 'processing'].includes(payload.new.status)) newPending += amount;
            if (payload.new.status === 'paid') newProcessed += amount;
            
            return {
              ...prev,
              pendingAmount: newPending,
              processedAmount: newProcessed
            };
          });
          
          toast({
            title: "Payout Status Updated",
            description: `Payout ${getStatusDisplayName(payload.new.status)}`,
          });
        }
      },
      onDelete: (payload) => {
        console.log('Payout deleted:', payload.old);
        setPayouts(prev => prev.filter(payout => payout.id !== payload.old.id));
        
        // Update stats
        const amount = Number(payload.old.amount);
        setStats(prev => ({
          ...prev,
          totalPayouts: prev.totalPayouts - 1,
          pendingAmount: ['requested', 'processing'].includes(payload.old.status)
            ? prev.pendingAmount - amount 
            : prev.pendingAmount,
          processedAmount: payload.old.status === 'paid'
            ? prev.processedAmount - amount
            : prev.processedAmount
        }));

        toast({
          title: "Payout Removed",
          description: "A payout request has been deleted",
        });
      },
      channelName: 'admin-payouts-realtime'
    }
  ]);

  const filteredPayouts = payouts.filter(payout => {
    const matchesSearch = payout.affiliate?.code?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      payout.method.toLowerCase().includes(searchTerm.toLowerCase()) ||
      payout.status.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesStatus = statusFilter === 'all' || payout.status === statusFilter;
    
    return matchesSearch && matchesStatus;
  });

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'requested': return 'text-warning border-warning';
      case 'processing': return 'text-blue-600 border-blue-600';
      case 'paid': return 'text-success border-success';
      case 'failed': return 'text-destructive border-destructive';
      case 'rejected': return 'text-destructive border-destructive';
      case 'canceled': return 'text-muted-foreground border-muted-foreground';
      default: return 'text-muted-foreground border-muted-foreground';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'requested': return <Clock className="w-3 h-3 mr-1" />;
      case 'processing': return <RefreshCw className="w-3 h-3 mr-1" />;
      case 'paid': return <CheckCircle className="w-3 h-3 mr-1" />;
      case 'failed': return <XCircle className="w-3 h-3 mr-1" />;
      case 'rejected': return <Ban className="w-3 h-3 mr-1" />;
      case 'canceled': return <XCircle className="w-3 h-3 mr-1" />;
      default: return null;
    }
  };

  const getStatusDisplayName = (status: string) => {
    switch (status) {
      case 'requested': return 'requested';
      case 'processing': return 'processing';
      case 'paid': return 'paid';
      case 'failed': return 'failed';
      case 'rejected': return 'rejected';
      case 'canceled': return 'canceled';
      default: return status;
    }
  };

  const canPerformAction = (status: string, action: string) => {
    switch (action) {
      case 'approve':
      case 'process':
        return status === 'requested';
      case 'mark_paid':
        return ['requested', 'processing'].includes(status);
      case 'reject':
        return status === 'requested';
      case 'cancel':
        return ['requested', 'processing'].includes(status);
      default:
        return false;
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6 p-2 sm:p-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-bold text-foreground">Affiliate Payouts</h1>
          <p className="text-muted-foreground">
            Process and manage affiliate commission payouts
          </p>
        </div>
        <Button className="sm:w-auto" onClick={() => setShowNewPayoutDialog(true)}>
          <Plus className="w-4 h-4 mr-2" />
          New Payout
        </Button>
      </div>

      {/* Payout Stats */}
      <div className="grid gap-4 grid-cols-2 lg:grid-cols-4">
        <Card className="glass-card border-card-border">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              Total Payouts
            </CardTitle>
            <Wallet className="h-4 w-4 text-primary" />
          </CardHeader>
          <CardContent>
            <div className="text-xl sm:text-2xl font-bold text-foreground">{stats.totalPayouts}</div>
            <p className="text-xs text-muted-foreground">All time</p>
          </CardContent>
        </Card>

        <Card className="glass-card border-card-border">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              Pending Amount
            </CardTitle>
            <Clock className="h-4 w-4 text-warning" />
          </CardHeader>
          <CardContent>
            <div className="text-xl sm:text-2xl font-bold text-foreground">${stats.pendingAmount.toFixed(2)}</div>
            <p className="text-xs text-warning">{stats.pendingCount} requests</p>
          </CardContent>
        </Card>

        <Card className="glass-card border-card-border">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              Processed This Month
            </CardTitle>
            <CheckCircle className="h-4 w-4 text-success" />
          </CardHeader>
          <CardContent>
            <div className="text-xl sm:text-2xl font-bold text-foreground">${stats.processedAmount.toFixed(2)}</div>
            <p className="text-xs text-success">Completed payouts</p>
          </CardContent>
        </Card>

        <Card className="glass-card border-card-border">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              Processing Time
            </CardTitle>
            <Clock className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-xl sm:text-2xl font-bold text-foreground">2.3</div>
            <p className="text-xs text-muted-foreground">Average days</p>
          </CardContent>
        </Card>
      </div>

      {/* Search and Filters */}
      <Card className="glass-card border-card-border">
        <CardContent className="pt-6">
          <div className="flex flex-col sm:flex-row gap-4">
            <div className="flex-1">
              <div className="relative">
                <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="Search by affiliate code, method, or status..."
                  className="pl-8"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                />
              </div>
            </div>
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger className="w-[150px]">
                <SelectValue placeholder="All Status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Status</SelectItem>
                <SelectItem value="requested">Requested</SelectItem>
                <SelectItem value="processing">Processing</SelectItem>
                <SelectItem value="paid">Paid</SelectItem>
                <SelectItem value="rejected">Rejected</SelectItem>
                <SelectItem value="canceled">Canceled</SelectItem>
                <SelectItem value="failed">Failed</SelectItem>
              </SelectContent>
            </Select>
            <Button variant="outline" className="sm:w-auto">
              <Filter className="w-4 h-4 mr-2" />
              Filter
            </Button>
          </div>
          
          <PayoutBulkActions
            selectedPayouts={selectedPayouts}
            onClearSelection={() => setSelectedPayouts([])}
            onBulkAction={handleBulkAction}
            loading={bulkActionInProgress}
          />
        </CardContent>
      </Card>

      {/* Payouts Table */}
      <Card className="glass-card border-card-border">
        <CardHeader>
          <CardTitle>Payout Requests</CardTitle>
          <CardDescription>
            Review and process affiliate payout requests
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="w-12">
                    <Checkbox
                      checked={selectedPayouts.length === filteredPayouts.length && filteredPayouts.length > 0}
                      onCheckedChange={(checked) => {
                        if (checked) {
                          setSelectedPayouts(filteredPayouts.map(p => p.id));
                        } else {
                          setSelectedPayouts([]);
                        }
                      }}
                    />
                  </TableHead>
                  <TableHead>Affiliate</TableHead>
                  <TableHead>Amount</TableHead>
                  <TableHead>Method</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Requested</TableHead>
                  <TableHead>Processed</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredPayouts.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={7} className="text-center text-muted-foreground">
                      {searchTerm ? "No payouts found matching your search" : "No payout requests found"}
                    </TableCell>
                  </TableRow>
                ) : (
                  filteredPayouts.map((payout) => (
                    <TableRow key={payout.id}>
                      <TableCell>
                        <Checkbox
                          checked={selectedPayouts.includes(payout.id)}
                          onCheckedChange={(checked) => {
                            if (checked) {
                              setSelectedPayouts(prev => [...prev, payout.id]);
                            } else {
                              setSelectedPayouts(prev => prev.filter(id => id !== payout.id));
                            }
                          }}
                        />
                      </TableCell>
                      <TableCell className="font-medium">
                        {payout.affiliate?.code || 'N/A'}
                      </TableCell>
                      <TableCell className="font-semibold">
                        ${payout.amount.toFixed(2)}
                      </TableCell>
                      <TableCell>
                        <Badge variant="secondary">{payout.method}</Badge>
                      </TableCell>
                      <TableCell>
                        <Badge 
                          variant="outline"
                          className={getStatusColor(payout.status)}
                        >
                          {getStatusIcon(payout.status)}
                          {getStatusDisplayName(payout.status)}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-sm text-muted-foreground">
                        {new Date(payout.created_at).toLocaleDateString()}
                      </TableCell>
                      <TableCell className="text-sm text-muted-foreground">
                        {payout.status === 'paid' ? new Date(payout.processed_at || payout.updated_at).toLocaleDateString() : '-'}
                      </TableCell>
                      <TableCell className="text-right">
                        <div className="flex items-center space-x-1">
                          <Checkbox
                            checked={selectedPayouts.includes(payout.id)}
                            onCheckedChange={(checked) => {
                              if (checked) {
                                setSelectedPayouts(prev => [...prev, payout.id]);
                              } else {
                                setSelectedPayouts(prev => prev.filter(id => id !== payout.id));
                              }
                            }}
                          />
                          <Button variant="ghost" size="sm">
                            <Eye className="w-3 h-3" />
                          </Button>
                          <DropdownMenu>
                            <DropdownMenuTrigger asChild>
                              <Button variant="ghost" size="sm">
                                <MoreHorizontal className="w-3 h-3" />
                              </Button>
                            </DropdownMenuTrigger>
                            <DropdownMenuContent align="end">
                              {canPerformAction(payout.status, 'approve') && (
                                <DropdownMenuItem onClick={() => setActionDialog({ show: true, type: 'approve', payout })}>
                                  <CheckCircle className="w-3 h-3 mr-2" />
                                  Approve
                                </DropdownMenuItem>
                              )}
                              {canPerformAction(payout.status, 'process') && (
                                <DropdownMenuItem onClick={() => setActionDialog({ show: true, type: 'process', payout })}>
                                  <RefreshCw className="w-3 h-3 mr-2" />
                                  Mark Processing
                                </DropdownMenuItem>
                              )}
                              {canPerformAction(payout.status, 'mark_paid') && (
                                <DropdownMenuItem onClick={() => setActionDialog({ show: true, type: 'mark_paid', payout })}>
                                  <DollarSign className="w-3 h-3 mr-2" />
                                  Mark Paid
                                </DropdownMenuItem>
                              )}
                              <DropdownMenuSeparator />
                              {canPerformAction(payout.status, 'reject') && (
                                <DropdownMenuItem onClick={() => setActionDialog({ show: true, type: 'reject', payout })}>
                                  <Ban className="w-3 h-3 mr-2" />
                                  Reject
                                </DropdownMenuItem>
                              )}
                              {canPerformAction(payout.status, 'cancel') && (
                                <DropdownMenuItem onClick={() => setActionDialog({ show: true, type: 'cancel', payout })}>
                                  <XCircle className="w-3 h-3 mr-2" />
                                  Cancel
                                </DropdownMenuItem>
                              )}
                            </DropdownMenuContent>
                          </DropdownMenu>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>

      {/* Action Dialog */}
      <PayoutActionDialog
        isOpen={actionDialog.show}
        onClose={() => setActionDialog({ show: false, type: null, payout: null })}
        onConfirm={(data) => handlePayoutAction(actionDialog.type!, actionDialog.payout!, data)}
        action={actionDialog.type}
        payout={actionDialog.payout}
        loading={bulkActionInProgress}
      />

      {/* New Payout Dialog */}
      <Dialog open={showNewPayoutDialog} onOpenChange={setShowNewPayoutDialog}>
        <DialogContent className="sm:max-w-[425px]">
          <DialogHeader>
            <DialogTitle>Create New Payout</DialogTitle>
            <DialogDescription>
              Create a manual payout for an affiliate
            </DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="grid gap-2">
              <Label htmlFor="affiliate">Affiliate</Label>
              <Select
                value={newPayoutForm.affiliate_id}
                onValueChange={(value) => setNewPayoutForm(prev => ({ ...prev, affiliate_id: value }))}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select affiliate" />
                </SelectTrigger>
                <SelectContent>
                  {affiliates.map((affiliate) => (
                    <SelectItem key={affiliate.id} value={affiliate.id}>
                      {affiliate.code}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            
            <div className="grid gap-2">
              <Label htmlFor="amount">Amount</Label>
              <Input
                id="amount"
                type="number"
                step="0.01"
                placeholder="0.00"
                value={newPayoutForm.amount}
                onChange={(e) => setNewPayoutForm(prev => ({ ...prev, amount: e.target.value }))}
              />
            </div>

            <div className="grid gap-2">
              <Label htmlFor="method">Payment Method</Label>
              <Select
                value={newPayoutForm.method}
                onValueChange={(value) => setNewPayoutForm(prev => ({ ...prev, method: value }))}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="bank">Bank Transfer</SelectItem>
                  <SelectItem value="paypal">PayPal</SelectItem>
                  <SelectItem value="crypto">Cryptocurrency</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="grid gap-2">
              <Label htmlFor="currency">Currency</Label>
              <Select
                value={newPayoutForm.currency}
                onValueChange={(value) => setNewPayoutForm(prev => ({ ...prev, currency: value }))}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="USD">USD</SelectItem>
                  <SelectItem value="EUR">EUR</SelectItem>
                  <SelectItem value="GBP">GBP</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          
          <div className="flex justify-end gap-2">
            <Button 
              variant="outline" 
              onClick={() => setShowNewPayoutDialog(false)}
              disabled={creatingPayout}
            >
              Cancel
            </Button>
            <Button 
              onClick={createNewPayout}
              disabled={creatingPayout || !newPayoutForm.affiliate_id || !newPayoutForm.amount}
            >
              {creatingPayout ? (
                <>
                  <RefreshCw className="w-4 h-4 mr-2 animate-spin" />
                  Creating...
                </>
              ) : (
                'Create Payout'
              )}
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}