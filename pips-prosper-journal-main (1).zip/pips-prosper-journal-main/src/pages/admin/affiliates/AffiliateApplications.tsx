import { useEffect, useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { 
  CheckCircle, 
  XCircle, 
  Clock, 
  Eye,
  Filter,
  Search
} from "lucide-react";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "@/hooks/use-toast";

interface AffiliateApplication {
  id: string;
  full_name: string;
  email: string;
  phone: string | null;
  country: string;
  platform_type: string;
  platform_url: string | null;
  audience_size: string | null;
  experience_level: string;
  content_type: string | null;
  promotion_strategy: string;
  previous_programs: string | null;
  status: string;
  created_at: string;
  updated_at: string;
}

interface ApplicationStats {
  pending: number;
  approved: number;
  rejected: number;
  rejectionRate: number;
}

export default function AffiliateApplications() {
  const [applications, setApplications] = useState<AffiliateApplication[]>([]);
  const [stats, setStats] = useState<ApplicationStats>({
    pending: 0,
    approved: 0,
    rejected: 0,
    rejectionRate: 0
  });
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState("");

  const fetchApplications = async () => {
    try {
      const { data, error } = await supabase
        .from('affiliate_applications')
        .select('*')
        .order('created_at', { ascending: false });

      if (error) throw error;

      setApplications(data || []);

      // Calculate stats
      const pending = data?.filter(app => app.status === 'pending').length || 0;
      const approved = data?.filter(app => app.status === 'approved').length || 0;
      const rejected = data?.filter(app => app.status === 'rejected').length || 0;
      const rejectionRate = data && data.length > 0 ? (rejected / data.length) * 100 : 0;

      setStats({ pending, approved, rejected, rejectionRate });
    } catch (error) {
      console.error('Error fetching applications:', error);
      toast({
        title: "Error",
        description: "Failed to fetch applications",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const updateApplicationStatus = async (id: string, status: 'approved' | 'rejected') => {
    try {
      const { error } = await supabase
        .from('affiliate_applications')
        .update({ status })
        .eq('id', id);

      if (error) throw error;

      toast({
        title: "Success",
        description: `Application ${status} successfully`,
      });

      fetchApplications();
    } catch (error) {
      console.error('Error updating application:', error);
      toast({
        title: "Error",
        description: "Failed to update application",
        variant: "destructive",
      });
    }
  };

  useEffect(() => {
    fetchApplications();

    // Set up real-time subscription for new applications
    const channel = supabase
      .channel('affiliate-applications-changes')
      .on(
        'postgres_changes',
        {
          event: 'INSERT',
          schema: 'public',
          table: 'affiliate_applications'
        },
        (payload) => {
          console.log('New affiliate application received:', payload.new);
          
          // Add the new application to the existing list
          setApplications(prev => [payload.new as AffiliateApplication, ...prev]);
          
          // Update stats (since applications are auto-approved)
          setStats(prev => ({
            ...prev,
            approved: prev.approved + 1
          }));

          // Show a toast notification
          toast({
            title: "New Application Auto-Approved! 🎉",
            description: `${payload.new.full_name} has been automatically approved as an affiliate`,
          });
        }
      )
      .on(
        'postgres_changes',
        {
          event: 'UPDATE',
          schema: 'public',
          table: 'affiliate_applications'
        },
        (payload) => {
          console.log('Affiliate application updated:', payload.new);
          
          // Update the application in the list
          setApplications(prev => 
            prev.map(app => 
              app.id === payload.new.id ? payload.new as AffiliateApplication : app
            )
          );
          
          // Recalculate stats when status changes
          if (payload.old.status !== payload.new.status) {
            fetchApplications(); // Refetch to ensure accurate stats
          }
        }
      )
      .subscribe();

    // Cleanup subscription on unmount
    return () => {
      supabase.removeChannel(channel);
    };
  }, []);

  const filteredApplications = applications.filter(app =>
    app.full_name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    app.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
    app.platform_type.toLowerCase().includes(searchTerm.toLowerCase())
  );

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
      </div>
    );
  }
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-foreground">Affiliate Applications</h1>
          <p className="text-muted-foreground">
            Review and manage incoming affiliate program applications
          </p>
        </div>
      </div>

      {/* Application Stats */}
      <div className="grid gap-4 md:grid-cols-3">
        <Card className="glass-card border-card-border">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              Pending Review
            </CardTitle>
            <Clock className="h-4 w-4 text-warning" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-foreground">{stats.pending}</div>
            <p className="text-xs text-warning">Requires action</p>
          </CardContent>
        </Card>

        <Card className="glass-card border-card-border">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              Approved This Month
            </CardTitle>
            <CheckCircle className="h-4 w-4 text-success" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-foreground">{stats.approved}</div>
            <p className="text-xs text-success">This month</p>
          </CardContent>
        </Card>

        <Card className="glass-card border-card-border">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              Rejection Rate
            </CardTitle>
            <XCircle className="h-4 w-4 text-destructive" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-foreground">{stats.rejectionRate.toFixed(1)}%</div>
            <p className="text-xs text-muted-foreground">All time rate</p>
          </CardContent>
        </Card>
      </div>

      {/* Search and Filters */}
      <Card className="glass-card border-card-border">
        <CardContent className="pt-6">
          <div className="flex space-x-4">
            <div className="flex-1">
              <div className="relative">
                <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="Search applications by name, email, or platform..."
                  className="pl-8"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                />
              </div>
            </div>
            <Button variant="outline">
              <Filter className="w-4 h-4 mr-2" />
              Filter
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Applications Table */}
      <Card className="glass-card border-card-border">
        <CardHeader>
          <CardTitle>Recent Applications</CardTitle>
          <CardDescription>
            Review affiliate program applications and take action
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Applicant</TableHead>
                <TableHead>Platform</TableHead>
                <TableHead>Audience</TableHead>
                <TableHead>Experience</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Submitted</TableHead>
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredApplications.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={7} className="text-center text-muted-foreground">
                    {searchTerm ? "No applications found matching your search" : "No applications found"}
                  </TableCell>
                </TableRow>
              ) : (
                filteredApplications.map((app) => (
                  <TableRow key={app.id}>
                    <TableCell className="font-medium">
                      <div>
                        <p className="font-medium">{app.full_name}</p>
                        <p className="text-sm text-muted-foreground">{app.email}</p>
                      </div>
                    </TableCell>
                    <TableCell>
                      <div>
                        <p className="text-sm">{app.platform_type}</p>
                        <p className="text-xs text-muted-foreground">{app.platform_url || 'N/A'}</p>
                      </div>
                    </TableCell>
                    <TableCell>{app.audience_size || 'N/A'}</TableCell>
                    <TableCell>
                      <Badge variant="secondary">{app.experience_level}</Badge>
                    </TableCell>
                    <TableCell>
                      <Badge 
                        variant="outline"
                        className={
                          app.status === 'pending' ? "text-warning border-warning" :
                          app.status === 'approved' ? "text-success border-success" :
                          "text-destructive border-destructive"
                        }
                      >
                        {app.status === 'pending' && <Clock className="w-3 h-3 mr-1" />}
                        {app.status === 'approved' && <CheckCircle className="w-3 h-3 mr-1" />}
                        {app.status === 'rejected' && <XCircle className="w-3 h-3 mr-1" />}
                        {app.status}
                      </Badge>
                    </TableCell>
                    <TableCell className="text-xs text-muted-foreground">
                      {new Date(app.created_at).toLocaleDateString()}
                    </TableCell>
                    <TableCell className="text-right">
                      <div className="flex space-x-2 justify-end">
                        <Button variant="ghost" size="sm">
                          <Eye className="w-3 h-3" />
                        </Button>
                        {app.status === 'pending' && (
                          <>
                            <Button 
                              variant="outline" 
                              size="sm" 
                              className="text-success border-success"
                              onClick={() => updateApplicationStatus(app.id, 'approved')}
                            >
                              <CheckCircle className="w-3 h-3 mr-1" />
                              Approve
                            </Button>
                            <Button 
                              variant="outline" 
                              size="sm" 
                              className="text-destructive border-destructive"
                              onClick={() => updateApplicationStatus(app.id, 'rejected')}
                            >
                              <XCircle className="w-3 h-3 mr-1" />
                              Reject
                            </Button>
                          </>
                        )}
                        {app.status !== 'pending' && (
                          <Button variant="outline" size="sm" disabled>
                            {app.status}
                          </Button>
                        )}
                      </div>
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
}