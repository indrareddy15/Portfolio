import { useEffect, useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { 
  Search, 
  Filter, 
  MoreHorizontal, 
  TrendingUp, 
  Users, 
  DollarSign,
  Calendar,
  Edit,
  Pause,
  Ban
} from "lucide-react";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "@/hooks/use-toast";

interface Affiliate {
  id: string;
  user_id: string;
  code: string;
  status: string;
  default_rate_pct: number;
  created_at: string;
}

interface AffiliateStats {
  totalAffiliates: number;
  topPerformers: number;
  totalCustomers: number;
  totalCommissions: number;
}

export default function AffiliateDirectory() {
  const [affiliates, setAffiliates] = useState<Affiliate[]>([]);
  const [stats, setStats] = useState<AffiliateStats>({
    totalAffiliates: 0,
    topPerformers: 0,
    totalCustomers: 0,
    totalCommissions: 0
  });
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState("");

  const fetchAffiliates = async () => {
    try {
      const { data, error } = await supabase
        .from('affiliates')
        .select('*')
        .order('created_at', { ascending: false });

      if (error) throw error;

      setAffiliates(data || []);

      // Calculate stats
      const totalAffiliates = data?.length || 0;
      const topPerformers = data?.filter(aff => aff.default_rate_pct >= 15).length || 0;
      
      setStats({
        totalAffiliates,
        topPerformers,
        totalCustomers: 0, // This would come from actual sales data
        totalCommissions: 0 // This would come from actual commission data
      });

    } catch (error) {
      console.error('Error fetching affiliates:', error);
      toast({
        title: "Error",
        description: "Failed to fetch affiliates",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchAffiliates();

    // Set up real-time subscription for new affiliates
    const channel = supabase
      .channel('affiliates-changes')
      .on(
        'postgres_changes',
        {
          event: 'INSERT',
          schema: 'public',
          table: 'affiliates'
        },
        (payload) => {
          console.log('New affiliate created:', payload.new);
          
          // Add the new affiliate to the existing list
          setAffiliates(prev => [payload.new as Affiliate, ...prev]);
          
          // Update stats
          setStats(prev => ({
            ...prev,
            totalAffiliates: prev.totalAffiliates + 1,
            topPerformers: payload.new.default_rate_pct >= 15 ? prev.topPerformers + 1 : prev.topPerformers
          }));

          // Show a toast notification
          toast({
            title: "New Affiliate Approved! 🎉",
            description: `${payload.new.code} has been automatically approved and activated`,
          });
        }
      )
      .on(
        'postgres_changes',
        {
          event: 'UPDATE',
          schema: 'public',
          table: 'affiliates'
        },
        (payload) => {
          console.log('Affiliate updated:', payload.new);
          
          // Update the affiliate in the list
          setAffiliates(prev => 
            prev.map(aff => 
              aff.id === payload.new.id ? payload.new as Affiliate : aff
            )
          );
        }
      )
      .subscribe();

    // Cleanup subscription on unmount
    return () => {
      supabase.removeChannel(channel);
    };
  }, []);

  const filteredAffiliates = affiliates.filter(aff =>
    aff.code.toLowerCase().includes(searchTerm.toLowerCase()) ||
    aff.user_id.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const getTierInfo = (rate: number) => {
    if (rate >= 20) return { name: "Tier 3", color: "bg-gradient-to-r from-yellow-500 to-amber-500" };
    if (rate >= 15) return { name: "Tier 2", color: "bg-gradient-to-r from-green-500 to-emerald-500" };
    return { name: "Tier 1", color: "bg-gradient-to-r from-blue-500 to-cyan-500" };
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-foreground">Affiliate Directory</h1>
          <p className="text-muted-foreground">
            Complete directory of all affiliate partners and their performance
          </p>
        </div>
        <Button>
          <Users className="w-4 h-4 mr-2" />
          Export Directory
        </Button>
      </div>

      {/* Directory Stats */}
      <div className="grid gap-4 md:grid-cols-4">
        <Card className="glass-card border-card-border">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              Total Affiliates
            </CardTitle>
            <Users className="h-4 w-4 text-primary" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-foreground">{stats.totalAffiliates}</div>
            <p className="text-xs text-success">Auto-approved affiliates</p>
          </CardContent>
        </Card>

        <Card className="glass-card border-card-border">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              Top Performers
            </CardTitle>
            <TrendingUp className="h-4 w-4 text-success" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-foreground">{stats.topPerformers}</div>
            <p className="text-xs text-muted-foreground">High-tier affiliates</p>
          </CardContent>
        </Card>

        <Card className="glass-card border-card-border">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              Total Customers
            </CardTitle>
            <Users className="h-4 w-4 text-primary" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-foreground">{stats.totalCustomers}</div>
            <p className="text-xs text-success">Via affiliate referrals</p>
          </CardContent>
        </Card>

        <Card className="glass-card border-card-border">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              Total Commissions
            </CardTitle>
            <DollarSign className="h-4 w-4 text-primary" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-foreground">${stats.totalCommissions.toLocaleString()}</div>
            <p className="text-xs text-success">All-time earnings</p>
          </CardContent>
        </Card>
      </div>

      {/* Search and Filters */}
      <Card className="glass-card border-card-border">
        <CardContent className="pt-6">
          <div className="flex space-x-4">
            <div className="flex-1">
              <div className="relative">
                <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="Search affiliates by name or code..."
                  className="pl-8"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                />
              </div>
            </div>
            <Button variant="outline">
              <Filter className="w-4 h-4 mr-2" />
              Filter by Tier
            </Button>
            <Button variant="outline">
              <Filter className="w-4 h-4 mr-2" />
              Filter by Status
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Affiliates Directory Table */}
      <Card className="glass-card border-card-border">
        <CardHeader>
          <CardTitle>All Affiliates</CardTitle>
          <CardDescription>
            Complete list of affiliate partners with performance metrics
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Affiliate</TableHead>
                <TableHead>Code</TableHead>
                <TableHead>Tier</TableHead>
                <TableHead>Customers</TableHead>
                <TableHead>Revenue</TableHead>
                <TableHead>Earned</TableHead>
                <TableHead>Joined</TableHead>
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredAffiliates.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={8} className="text-center text-muted-foreground">
                    {searchTerm ? "No affiliates found matching your search" : "No affiliates found"}
                  </TableCell>
                </TableRow>
              ) : (
                filteredAffiliates.map((affiliate) => {
                  const tierInfo = getTierInfo(affiliate.default_rate_pct);
                  return (
                    <TableRow key={affiliate.id}>
                      <TableCell className="font-medium">
                        <div>
                          <p className="font-medium">Affiliate {affiliate.code}</p>
                          <p className="text-sm text-muted-foreground">{affiliate.user_id}</p>
                          <Badge 
                            variant="outline" 
                            className={
                              affiliate.status === 'active' ? "text-success border-success mt-1" :
                              affiliate.status === 'pending' ? "text-warning border-warning mt-1" :
                              "text-muted-foreground border-muted mt-1"
                            }
                          >
                            {affiliate.status}
                          </Badge>
                        </div>
                      </TableCell>
                      <TableCell>
                        <code className="bg-muted px-2 py-1 rounded text-xs">{affiliate.code}</code>
                      </TableCell>
                      <TableCell>
                        <Badge variant="default" className={`${tierInfo.color} text-white`}>
                          {tierInfo.name} ({affiliate.default_rate_pct}%)
                        </Badge>
                      </TableCell>
                      <TableCell>0 customers</TableCell>
                      <TableCell>$0</TableCell>
                      <TableCell>$0</TableCell>
                      <TableCell>
                        <div className="flex items-center text-sm text-muted-foreground">
                          <Calendar className="w-3 h-3 mr-1" />
                          {new Date(affiliate.created_at).toLocaleDateString()}
                        </div>
                      </TableCell>
                      <TableCell className="text-right">
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="ghost" className="h-8 w-8 p-0">
                              <MoreHorizontal className="h-4 w-4" />
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            <DropdownMenuItem>
                              <Edit className="mr-2 h-4 w-4" />
                              Edit Details
                            </DropdownMenuItem>
                            <DropdownMenuItem>
                              <TrendingUp className="mr-2 h-4 w-4" />
                              View Analytics
                            </DropdownMenuItem>
                            <DropdownMenuSeparator />
                            <DropdownMenuItem>
                              <Pause className="mr-2 h-4 w-4" />
                              Pause Account
                            </DropdownMenuItem>
                            <DropdownMenuItem className="text-destructive">
                              <Ban className="mr-2 h-4 w-4" />
                              Suspend Account
                            </DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </TableCell>
                    </TableRow>
                  );
                })
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
}