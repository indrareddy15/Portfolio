import { AffiliateCommissionManager } from "@/components/admin/AffiliateCommissionManager";
import { useEffect, useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { 
  DollarSign, 
  TrendingUp, 
  Users, 
  Eye,
  Filter,
  Search,
  Download,
  Settings
} from "lucide-react";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "@/hooks/use-toast";
import { useRealtime } from "@/hooks/useRealtime";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

interface Commission {
  id: string;
  affiliate_id: string;
  amount: number;
  currency: string;
  customer_user_id: string;
  effective_rate_pct: number;
  hold_until: string;
  notes: string;
  plan_name: string;
  status: string;
  created_at: string;
  updated_at: string;
  affiliate?: {
    code: string;
    user_id: string;
  };
}

interface CommissionStats {
  totalCommissions: number;
  pendingAmount: number;
  paidAmount: number;
  activeAffiliates: number;
}

export default function AffiliateCommissions() {
  const [commissions, setCommissions] = useState<Commission[]>([]);
  const [stats, setStats] = useState<CommissionStats>({
    totalCommissions: 0,
    pendingAmount: 0,
    paidAmount: 0,
    activeAffiliates: 0
  });
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState("");

  const fetchCommissions = async () => {
    try {
      const { data, error } = await supabase
        .from('commissions')
        .select(`
          *,
          affiliates:affiliate_id (
            code,
            user_id
          )
        `)
        .order('created_at', { ascending: false });

      if (error) throw error;

      setCommissions(data || []);

      // Calculate stats
      const totalCommissions = data?.length || 0;
      const pendingAmount = data?.filter(c => c.status === 'pending').reduce((sum, c) => sum + c.amount, 0) || 0;
      const paidAmount = data?.filter(c => c.status === 'paid').reduce((sum, c) => sum + c.amount, 0) || 0;
      const activeAffiliates = new Set(data?.map(c => c.affiliate_id)).size || 0;

      setStats({ totalCommissions, pendingAmount, paidAmount, activeAffiliates });
    } catch (error) {
      console.error('Error fetching commissions:', error);
      toast({
        title: "Error",
        description: "Failed to fetch commissions",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const updateCommissionStatus = async (id: string, status: 'paid' | 'cancelled') => {
    try {
      const { error } = await supabase
        .from('commissions')
        .update({ status })
        .eq('id', id);

      if (error) throw error;

      toast({
        title: "Success",
        description: `Commission ${status} successfully`,
      });

      fetchCommissions();
    } catch (error) {
      console.error('Error updating commission:', error);
      toast({
        title: "Error",
        description: "Failed to update commission",
        variant: "destructive",
      });
    }
  };

  useEffect(() => {
    fetchCommissions();
  }, []);

  // Real-time commission updates
  useRealtime([
    {
      table: 'commissions',
      events: ['INSERT', 'UPDATE', 'DELETE'],
      onInsert: (payload) => {
        console.log('New commission created:', payload.new);
        setCommissions(prev => [payload.new, ...prev]);
        
        // Update stats
        setStats(prev => ({
          ...prev,
          totalCommissions: prev.totalCommissions + 1,
          paidAmount: prev.paidAmount + Number(payload.new.amount)
        }));

        toast({
          title: "New Commission! 💰",
          description: `$${payload.new.amount} commission earned for affiliate ${payload.new.affiliate_id}`,
        });
      },
      onUpdate: (payload) => {
        console.log('Commission updated:', payload.new);
        setCommissions(prev => prev.map(comm => 
          comm.id === payload.new.id ? payload.new : comm
        ));
        
        // Update stats if status changed
        const oldAmount = Number(payload.old.amount);
        const newAmount = Number(payload.new.amount);
        
        if (payload.old.status !== payload.new.status || oldAmount !== newAmount) {
          fetchCommissions(); // Refetch for accurate stats
          
          toast({
            title: "Commission Updated",
            description: `Commission status changed to ${payload.new.status}`,
          });
        }
      },
      onDelete: (payload) => {
        console.log('Commission deleted:', payload.old);
        setCommissions(prev => prev.filter(comm => comm.id !== payload.old.id));
        
        // Update stats
        setStats(prev => ({
          ...prev,
          totalCommissions: prev.totalCommissions - 1,
          paidAmount: prev.paidAmount - Number(payload.old.amount)
        }));

        toast({
          title: "Commission Removed",
          description: "A commission has been deleted",
        });
      },
      channelName: 'admin-commissions-realtime'
    }
  ]);

  const filteredCommissions = commissions.filter(commission =>
    commission.affiliate?.code?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    commission.status.toLowerCase().includes(searchTerm.toLowerCase())
  );

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6 p-2 sm:p-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-bold text-foreground">Affiliate Commissions</h1>
          <p className="text-muted-foreground">
            Track and manage affiliate commission payments
          </p>
        </div>
        <Button className="sm:w-auto">
          <Download className="w-4 h-4 mr-2" />
          Export
        </Button>
      </div>

      {/* Commission Stats */}
      <div className="grid gap-4 grid-cols-2 lg:grid-cols-4">
        <Card className="glass-card border-card-border">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              Total Commissions
            </CardTitle>
            <TrendingUp className="h-4 w-4 text-primary" />
          </CardHeader>
          <CardContent>
            <div className="text-xl sm:text-2xl font-bold text-foreground">{stats.totalCommissions}</div>
            <p className="text-xs text-muted-foreground">All time</p>
          </CardContent>
        </Card>

        <Card className="glass-card border-card-border">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              Pending Amount
            </CardTitle>
            <DollarSign className="h-4 w-4 text-warning" />
          </CardHeader>
          <CardContent>
            <div className="text-xl sm:text-2xl font-bold text-foreground">${stats.pendingAmount.toFixed(2)}</div>
            <p className="text-xs text-warning">Awaiting payment</p>
          </CardContent>
        </Card>

        <Card className="glass-card border-card-border">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              Paid Amount
            </CardTitle>
            <DollarSign className="h-4 w-4 text-success" />
          </CardHeader>
          <CardContent>
            <div className="text-xl sm:text-2xl font-bold text-foreground">${stats.paidAmount.toFixed(2)}</div>
            <p className="text-xs text-success">This month</p>
          </CardContent>
        </Card>

        <Card className="glass-card border-card-border">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              Active Affiliates
            </CardTitle>
            <Users className="h-4 w-4 text-primary" />
          </CardHeader>
          <CardContent>
            <div className="text-xl sm:text-2xl font-bold text-foreground">{stats.activeAffiliates}</div>
            <p className="text-xs text-muted-foreground">Earning commissions</p>
          </CardContent>
        </Card>
      </div>

      {/* Tabs for Commission Management */}
      <Tabs defaultValue="overview" className="space-y-6">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="overview">Commission Overview</TabsTrigger>
          <TabsTrigger value="settings">
            <Settings className="h-4 w-4 mr-2" />
            Rate Management
          </TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-6">
          {/* Search and Filters */}
          <Card className="glass-card border-card-border">
            <CardContent className="pt-6">
              <div className="flex flex-col sm:flex-row gap-4">
                <div className="flex-1">
                  <div className="relative">
                    <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
                    <Input
                      placeholder="Search by affiliate code or status..."
                      className="pl-8"
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                    />
                  </div>
                </div>
                <Button variant="outline" className="sm:w-auto">
                  <Filter className="w-4 h-4 mr-2" />
                  Filter
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* Commissions Table */}
          <Card className="glass-card border-card-border">
            <CardHeader>
              <CardTitle>Recent Commissions</CardTitle>
              <CardDescription>
                Track affiliate commission earnings and payments
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Affiliate Code</TableHead>
                      <TableHead>Amount</TableHead>
                      <TableHead>Rate (%)</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Date</TableHead>
                      <TableHead className="text-right">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredCommissions.length === 0 ? (
                      <TableRow>
                        <TableCell colSpan={6} className="text-center text-muted-foreground">
                          {searchTerm ? "No commissions found matching your search" : "No commissions found"}
                        </TableCell>
                      </TableRow>
                    ) : (
                      filteredCommissions.map((commission) => (
                        <TableRow key={commission.id}>
                          <TableCell className="font-medium">
                            {commission.affiliate?.code || 'N/A'}
                          </TableCell>
                          <TableCell className="font-semibold text-success">
                            ${commission.amount.toFixed(2)}
                          </TableCell>
                          <TableCell>{commission.effective_rate_pct}%</TableCell>
                          <TableCell>
                            <Badge 
                              variant="outline"
                              className={
                                commission.status === 'pending' ? "text-warning border-warning" :
                                commission.status === 'paid' ? "text-success border-success" :
                                "text-destructive border-destructive"
                              }
                            >
                              {commission.status}
                            </Badge>
                          </TableCell>
                          <TableCell className="text-sm text-muted-foreground">
                            {new Date(commission.created_at).toLocaleDateString()}
                          </TableCell>
                          <TableCell className="text-right">
                            <div className="flex space-x-2 justify-end">
                              <Button variant="ghost" size="sm">
                                <Eye className="w-3 h-3" />
                              </Button>
                              {commission.status === 'pending' && (
                                <>
                                  <Button 
                                    variant="outline" 
                                    size="sm" 
                                    className="text-success border-success"
                                    onClick={() => updateCommissionStatus(commission.id, 'paid')}
                                  >
                                    Mark Paid
                                  </Button>
                                  <Button 
                                    variant="outline" 
                                    size="sm" 
                                    className="text-destructive border-destructive"
                                    onClick={() => updateCommissionStatus(commission.id, 'cancelled')}
                                  >
                                    Cancel
                                  </Button>
                                </>
                              )}
                            </div>
                          </TableCell>
                        </TableRow>
                      ))
                    )}
                  </TableBody>
                </Table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="settings">
          <AffiliateCommissionManager />
        </TabsContent>
      </Tabs>
    </div>
  );
}