import { useState, useEffect } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Separator } from "@/components/ui/separator";
import { 
  Settings, 
  Percent, 
  DollarSign,
  Mail,
  Globe,
  Save,
  RefreshCw
} from "lucide-react";
import { toast } from "@/hooks/use-toast";

interface AffiliateSettings {
  defaultCommissionRate: number;
  minimumPayout: number;
  payoutFrequency: string;
  cookieDuration: number;
  autoApproval: boolean;
  emailNotifications: boolean;
  trackingDomain: string;
  termsAndConditions: string;
  welcomeMessage: string;
}

export default function AffiliateSettings() {
  const [settings, setSettings] = useState<AffiliateSettings>({
    defaultCommissionRate: 30,
    minimumPayout: 100,
    payoutFrequency: 'monthly',
    cookieDuration: 90,
    autoApproval: false,
    emailNotifications: true,
    trackingDomain: 'track.piptrackr.com',
    termsAndConditions: 'Please review our affiliate terms and conditions before participating in the program...',
    welcomeMessage: 'Welcome to the PipTrackr.com affiliate program! We\'re excited to work with you.'
  });
  
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    // Load settings from localStorage for now
    const savedSettings = localStorage.getItem('affiliate_settings');
    if (savedSettings) {
      try {
        setSettings(JSON.parse(savedSettings));
      } catch (error) {
        console.error('Error loading saved settings:', error);
      }
    }
  }, []);

  const handleInputChange = async (field: keyof AffiliateSettings, value: any) => {
    const newSettings = {
      ...settings,
      [field]: value
    };
    setSettings(newSettings);
    
    // Auto-save to localStorage for real-time updates
    localStorage.setItem('affiliate_settings', JSON.stringify(newSettings));
    
    toast({
      title: "Settings Updated",
      description: `${field} has been updated in real-time`,
    });
  };

  const handleSave = async () => {
    setLoading(true);
    try {
      // Save to localStorage (in production this would save to database)
      localStorage.setItem('affiliate_settings', JSON.stringify(settings));
      
      toast({
        title: "Success",
        description: "Affiliate settings saved successfully",
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to save settings",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-6 p-2 sm:p-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-bold text-foreground">Affiliate Settings</h1>
          <p className="text-muted-foreground">
            Configure global affiliate program settings and policies (Real-time updates enabled)
          </p>
        </div>
        <Button onClick={handleSave} disabled={loading} className="sm:w-auto">
          {loading ? (
            <RefreshCw className="w-4 h-4 mr-2 animate-spin" />
          ) : (
            <Save className="w-4 h-4 mr-2" />
          )}
          Save Settings
        </Button>
      </div>

      <div className="grid gap-6 lg:grid-cols-2">
        {/* Commission Settings */}
        <Card className="glass-card border-card-border">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Percent className="w-5 h-5 text-primary" />
              Commission Settings
            </CardTitle>
            <CardDescription>
              Configure commission rates and payout policies
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="commission-rate">Default Commission Rate (%)</Label>
              <Input
                id="commission-rate"
                type="number"
                min="0"
                max="100"
                value={settings.defaultCommissionRate}
                onChange={(e) => handleInputChange('defaultCommissionRate', parseFloat(e.target.value))}
              />
              <p className="text-xs text-muted-foreground">
                Default commission rate for new affiliates
              </p>
            </div>

            <div className="space-y-2">
              <Label htmlFor="minimum-payout">Minimum Payout Amount ($)</Label>
              <Input
                id="minimum-payout"
                type="number"
                min="0"
                value={settings.minimumPayout}
                onChange={(e) => handleInputChange('minimumPayout', parseFloat(e.target.value))}
              />
              <p className="text-xs text-muted-foreground">
                Minimum amount required before payout request
              </p>
            </div>

            <div className="space-y-2">
              <Label htmlFor="payout-frequency">Payout Frequency</Label>
              <select
                id="payout-frequency"
                className="w-full px-3 py-2 border border-input rounded-md bg-background"
                value={settings.payoutFrequency}
                onChange={(e) => handleInputChange('payoutFrequency', e.target.value)}
              >
                <option value="weekly">Weekly</option>
                <option value="monthly">Monthly</option>
                <option value="quarterly">Quarterly</option>
              </select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="cookie-duration">Cookie Duration (days)</Label>
              <Input
                id="cookie-duration"
                type="number"
                min="1"
                max="365"
                value={settings.cookieDuration}
                onChange={(e) => handleInputChange('cookieDuration', parseInt(e.target.value))}
              />
              <p className="text-xs text-muted-foreground">
                How long affiliate tracking cookies last
              </p>
            </div>
          </CardContent>
        </Card>

        {/* Application Settings */}
        <Card className="glass-card border-card-border">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Settings className="w-5 h-5 text-primary" />
              Application Settings
            </CardTitle>
            <CardDescription>
              Manage affiliate application and approval process
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between">
              <div className="space-y-0.5">
                <Label>Auto-approve Applications</Label>
                <p className="text-xs text-muted-foreground">
                  Automatically approve new affiliate applications
                </p>
              </div>
              <Switch
                checked={settings.autoApproval}
                onCheckedChange={(checked) => handleInputChange('autoApproval', checked)}
              />
            </div>

            <Separator />

            <div className="flex items-center justify-between">
              <div className="space-y-0.5">
                <Label>Email Notifications</Label>
                <p className="text-xs text-muted-foreground">
                  Send email notifications for important events
                </p>
              </div>
              <Switch
                checked={settings.emailNotifications}
                onCheckedChange={(checked) => handleInputChange('emailNotifications', checked)}
              />
            </div>

            <Separator />

            <div className="space-y-2">
              <Label htmlFor="tracking-domain">Tracking Domain</Label>
              <Input
                id="tracking-domain"
                value={settings.trackingDomain}
                onChange={(e) => handleInputChange('trackingDomain', e.target.value)}
                placeholder="track.yoursite.com"
              />
              <p className="text-xs text-muted-foreground">
                Custom domain for affiliate tracking links
              </p>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Content Settings */}
      <Card className="glass-card border-card-border">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Mail className="w-5 h-5 text-primary" />
            Content & Messaging
          </CardTitle>
          <CardDescription>
            Customize messages and content shown to affiliates
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="space-y-2">
            <Label htmlFor="welcome-message">Welcome Message</Label>
            <Textarea
              id="welcome-message"
              rows={3}
              value={settings.welcomeMessage}
              onChange={(e) => handleInputChange('welcomeMessage', e.target.value)}
              placeholder="Enter welcome message for new affiliates..."
            />
            <p className="text-xs text-muted-foreground">
              Message shown to newly approved affiliates
            </p>
          </div>

          <div className="space-y-2">
            <Label htmlFor="terms-conditions">Terms and Conditions</Label>
            <Textarea
              id="terms-conditions"
              rows={6}
              value={settings.termsAndConditions}
              onChange={(e) => handleInputChange('termsAndConditions', e.target.value)}
              placeholder="Enter affiliate program terms and conditions..."
            />
            <p className="text-xs text-muted-foreground">
              Terms and conditions for the affiliate program
            </p>
          </div>
        </CardContent>
      </Card>

      {/* Quick Actions */}
      <Card className="glass-card border-card-border">
        <CardHeader>
          <CardTitle>Quick Actions</CardTitle>
          <CardDescription>
            Useful tools and actions for affiliate management
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid gap-4 grid-cols-1 sm:grid-cols-2 lg:grid-cols-4">
            <Button variant="outline" className="h-auto p-4 flex flex-col items-center gap-2">
              <DollarSign className="w-6 h-6 text-primary" />
              <span className="text-sm">Bulk Payout</span>
            </Button>
            <Button variant="outline" className="h-auto p-4 flex flex-col items-center gap-2">
              <Mail className="w-6 h-6 text-primary" />
              <span className="text-sm">Send Newsletter</span>
            </Button>
            <Button variant="outline" className="h-auto p-4 flex flex-col items-center gap-2">
              <Globe className="w-6 h-6 text-primary" />
              <span className="text-sm">Export Data</span>
            </Button>
            <Button variant="outline" className="h-auto p-4 flex flex-col items-center gap-2">
              <RefreshCw className="w-6 h-6 text-primary" />
              <span className="text-sm">Sync Analytics</span>
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}