import { Navigation } from "@/components/Navigation";
import { Footer } from "@/components/Footer";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { 
  MessageSquare, 
  BookOpen, 
  Video, 
  Mail, 
  Phone, 
  Clock,
  Search,
  ChevronRight
} from "lucide-react";
import { SEOHead } from "@/components/SEOHead";

const Support = () => {
  const faqs = [
    {
      question: "How do I import trades from my broker?",
      answer: "You can import trades using our CSV import feature. Go to your Dashboard, click 'Import Data', select your broker platform, and upload your trade history CSV file. We support MT4, MT5, cTrader, and custom formats."
    },
    {
      question: "Can I export my trading data?",
      answer: "Yes! You can export all your data at any time. Go to Settings > Account Settings > Data Management and click 'Export Data'. This will generate a comprehensive JSON file with all your trades, strategies, and analytics."
    },
    {
      question: "How is my trading data secured?",
      answer: "We use bank-grade security with AES-256 encryption, secure cloud infrastructure, and strict access controls. Your data is encrypted both in transit and at rest. We never share your trading data with third parties."
    },
    {
      question: "What's included in the Premium subscription?",
      answer: "Premium includes unlimited trades, advanced analytics, strategy management, CSV import/export, psychology tracking, priority support, and access to all new features as they're released."
    },
    {
      question: "Can I cancel my subscription anytime?",
      answer: "Yes, you can cancel your subscription at any time through the customer portal. Your access will continue until the end of your current billing period, and no further charges will be made."
    },
    {
      question: "Do you offer refunds?",
      answer: "We offer a 30-day money-back guarantee for new subscriptions. If you're not satisfied within the first 30 days, contact support for a full refund."
    }
  ];

  const supportChannels = [
    {
      title: "Live Chat",
      description: "Get instant help from our support team",
      icon: MessageSquare,
      availability: "24/7",
      responseTime: "< 5 minutes"
    },
    {
      title: "Email Support",
      description: "Send us detailed questions or feedback",
      icon: Mail,
      availability: "24/7",
      responseTime: "< 2 hours"
    },
    {
      title: "Phone Support",
      description: "Speak directly with our experts",
      icon: Phone,
      availability: "Mon-Fri 9AM-6PM EST",
      responseTime: "Immediate"
    }
  ];

  const resources = [
    {
      title: "Knowledge Base",
      description: "Comprehensive guides and tutorials",
      icon: BookOpen,
      link: "/help"
    },
    {
      title: "Video Tutorials",
      description: "Step-by-step video guides",
      icon: Video,
      link: "/tutorials"
    },
    {
      title: "Trading Academy",
      description: "Learn trading fundamentals",
      icon: BookOpen,
      link: "/academy"
    }
  ];

  return (
    <div className="min-h-screen bg-background">
      <SEOHead 
        title="Support & Help Center - PipTrackr.com Trading Journal"
        description="Get help with PipTrackr.com trading journal. Access FAQs, contact support, and find answers to common questions about forex trading analytics."
        keywords="trading journal support, piptrakr help, customer support, trading journal faq, help center"
        canonical={`${window.location.origin}/support`}
      />
      <Navigation />
      <main className="container mx-auto px-4 py-8 pt-24">
        <div className="max-w-6xl mx-auto">
          {/* Hero Section */}
          <div className="text-center mb-16">
            <h1 className="text-4xl font-bold tracking-tight mb-6">
              How can we help you?
            </h1>
            <p className="text-muted-foreground text-lg mb-8">
              Find answers to your questions or get in touch with our support team
            </p>
            
            {/* Search Bar */}
            <div className="max-w-md mx-auto relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
              <Input 
                placeholder="Search for help..." 
                className="pl-10 h-12"
              />
            </div>
          </div>

          {/* Support Channels */}
          <div className="grid gap-6 md:grid-cols-3 mb-16">
            {supportChannels.map((channel, index) => {
              const Icon = channel.icon;
              return (
                <Card key={index} className="hover:shadow-lg transition-shadow">
                  <CardHeader className="text-center">
                    <Icon className="h-12 w-12 mx-auto mb-4 text-primary" />
                    <CardTitle>{channel.title}</CardTitle>
                    <CardDescription>{channel.description}</CardDescription>
                  </CardHeader>
                  <CardContent className="text-center space-y-2">
                    <div className="flex justify-between text-sm">
                      <span className="text-muted-foreground">Availability:</span>
                      <Badge variant="secondary">{channel.availability}</Badge>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-muted-foreground">Response:</span>
                      <span className="font-medium">{channel.responseTime}</span>
                    </div>
                    <Button className="w-full mt-4">
                      Get Help
                      <ChevronRight className="ml-2 h-4 w-4" />
                    </Button>
                  </CardContent>
                </Card>
              );
            })}
          </div>

          {/* FAQ Section */}
          <div className="mb-16">
            <h2 className="text-3xl font-bold text-center mb-8">Frequently Asked Questions</h2>
            <Card>
              <CardContent className="p-6">
                <Accordion type="single" collapsible className="w-full">
                  {faqs.map((faq, index) => (
                    <AccordionItem key={index} value={`item-${index}`}>
                      <AccordionTrigger className="text-left">
                        {faq.question}
                      </AccordionTrigger>
                      <AccordionContent className="text-muted-foreground">
                        {faq.answer}
                      </AccordionContent>
                    </AccordionItem>
                  ))}
                </Accordion>
              </CardContent>
            </Card>
          </div>

          {/* Help Resources */}
          <div className="mb-16">
            <h2 className="text-3xl font-bold text-center mb-8">Help Resources</h2>
            <div className="grid gap-6 md:grid-cols-3">
              {resources.map((resource, index) => {
                const Icon = resource.icon;
                return (
                  <Card key={index} className="hover:shadow-lg transition-shadow cursor-pointer">
                    <CardHeader className="text-center">
                      <Icon className="h-10 w-10 mx-auto mb-3 text-primary" />
                      <CardTitle className="text-xl">{resource.title}</CardTitle>
                      <CardDescription>{resource.description}</CardDescription>
                    </CardHeader>
                    <CardContent className="text-center">
                      <Button variant="outline" className="w-full">
                        Explore
                        <ChevronRight className="ml-2 h-4 w-4" />
                      </Button>
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          </div>

          {/* Contact Card */}
          <Card className="bg-gradient-to-r from-primary/5 to-primary/10 border-primary/20">
            <CardHeader className="text-center">
              <CardTitle className="text-2xl">Still need help?</CardTitle>
              <CardDescription className="text-lg">
                Our support team is ready to assist you with any questions or issues
              </CardDescription>
            </CardHeader>
            <CardContent className="text-center">
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Button size="lg">
                  <MessageSquare className="mr-2 h-5 w-5" />
                  Start Live Chat
                </Button>
                <Button variant="outline" size="lg">
                  <Mail className="mr-2 h-5 w-5" />
                  Send Email
                </Button>
              </div>
              <div className="flex items-center justify-center gap-2 mt-6 text-sm text-muted-foreground">
                <Clock className="h-4 w-4" />
                Average response time: 2 hours
              </div>
            </CardContent>
          </Card>
        </div>
      </main>
      <Footer />
    </div>
  );
};

export default Support;