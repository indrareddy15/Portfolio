import { Navigation } from "@/components/Navigation";
import { Footer } from "@/components/Footer";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { BookOpen, Video, Download, Clock, Star, Users } from "lucide-react";
import { SEOHead } from "@/components/SEOHead";

const Learn = () => {
  const courses = [
    {
      title: "Trading Fundamentals",
      description: "Master the basics of financial markets, technical analysis, and trading psychology.",
      lessons: 12,
      duration: "4 hours",
      level: "Beginner",
      rating: 4.8,
      students: 2500,
      topics: ["Market Basics", "Chart Reading", "Risk Management", "Psychology"]
    },
    {
      title: "Advanced Technical Analysis",
      description: "Deep dive into advanced charting techniques, indicators, and pattern recognition.",
      lessons: 18,
      duration: "6 hours",
      level: "Advanced",
      rating: 4.9,
      students: 1200,
      topics: ["Advanced Patterns", "Custom Indicators", "Multi-timeframe Analysis", "Strategy Development"]
    },
    {
      title: "Risk Management Mastery",
      description: "Learn professional risk management techniques used by institutional traders.",
      lessons: 15,
      duration: "5 hours",
      level: "Intermediate",
      rating: 4.7,
      students: 1800,
      topics: ["Position Sizing", "Portfolio Risk", "Hedging Strategies", "Stress Testing"]
    },
    {
      title: "Trading Psychology",
      description: "Overcome emotional barriers and develop the mindset of successful traders.",
      lessons: 10,
      duration: "3 hours",
      level: "All Levels",
      rating: 4.9,
      students: 3200,
      topics: ["Emotional Control", "Discipline", "Cognitive Biases", "Mental Performance"]
    }
  ];

  const resources = [
    {
      title: "Trading Glossary",
      description: "Comprehensive dictionary of trading terms and concepts",
      type: "Reference",
      icon: BookOpen
    },
    {
      title: "Strategy Templates",
      description: "Ready-to-use trading strategy templates for various markets",
      type: "Templates",
      icon: Download
    },
    {
      title: "Market Analysis Videos",
      description: "Weekly market analysis and trading opportunities",
      type: "Videos",
      icon: Video
    },
    {
      title: "Webinar Archive",
      description: "Access to recorded educational webinars",
      type: "Webinars",
      icon: Video
    }
  ];

  return (
    <div className="min-h-screen bg-background">
      <SEOHead 
        title="Learn Trading - Free Forex Trading Education | PipTrackr.com"
        description="Master forex trading with our comprehensive courses. Learn technical analysis, risk management, trading psychology, and more. Free trading education from industry experts."
        keywords="forex trading education, learn trading, forex courses, trading tutorials, technical analysis course, risk management, trading psychology"
        canonical={`${window.location.origin}/learn`}
      />
      <Navigation />
      <main className="container mx-auto px-4 py-8 pt-24">
        <div className="max-w-6xl mx-auto">
          {/* Hero Section */}
          <div className="text-center mb-16">
            <h1 className="text-4xl font-bold tracking-tight mb-6">
              Learn to Trade Like a Pro
            </h1>
            <p className="text-muted-foreground text-lg leading-relaxed max-w-2xl mx-auto">
              Comprehensive trading education from industry experts. Master technical analysis, 
              risk management, and trading psychology with our structured courses.
            </p>
          </div>

          {/* Featured Courses */}
          <div className="mb-16">
            <h2 className="text-3xl font-bold mb-8">Featured Courses</h2>
            <div className="grid gap-6 md:grid-cols-2">
              {courses.map((course, index) => (
                <Card key={index} className="hover:shadow-lg transition-shadow">
                  <div className="h-48 bg-gradient-primary rounded-t-lg"></div>
                  <CardHeader>
                    <div className="flex items-center justify-between mb-2">
                      <Badge variant={course.level === "Beginner" ? "secondary" : course.level === "Advanced" ? "default" : "outline"}>
                        {course.level}
                      </Badge>
                      <div className="flex items-center gap-1 text-sm text-muted-foreground">
                        <Star className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                        {course.rating}
                      </div>
                    </div>
                    <CardTitle className="hover:text-primary cursor-pointer transition-colors">
                      {course.title}
                    </CardTitle>
                    <CardDescription>{course.description}</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="flex items-center gap-4 text-sm text-muted-foreground mb-4">
                      <div className="flex items-center gap-1">
                        <BookOpen className="h-4 w-4" />
                        {course.lessons} lessons
                      </div>
                      <div className="flex items-center gap-1">
                        <Clock className="h-4 w-4" />
                        {course.duration}
                      </div>
                      <div className="flex items-center gap-1">
                        <Users className="h-4 w-4" />
                        {course.students.toLocaleString()}
                      </div>
                    </div>
                    
                    <div className="flex flex-wrap gap-1 mb-4">
                      {course.topics.map((topic, topicIndex) => (
                        <Badge key={topicIndex} variant="outline" className="text-xs">
                          {topic}
                        </Badge>
                      ))}
                    </div>
                    
                    <Button className="w-full">
                      Start Learning
                    </Button>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>

          {/* Learning Resources */}
          <div className="mb-16">
            <h2 className="text-3xl font-bold mb-8">Learning Resources</h2>
            <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
              {resources.map((resource, index) => {
                const Icon = resource.icon;
                return (
                  <Card key={index} className="hover:shadow-lg transition-shadow cursor-pointer">
                    <CardHeader className="text-center">
                      <Icon className="h-12 w-12 mx-auto mb-3 text-primary" />
                      <CardTitle className="text-lg">{resource.title}</CardTitle>
                      <CardDescription>{resource.description}</CardDescription>
                    </CardHeader>
                    <CardContent className="text-center">
                      <Badge variant="outline">{resource.type}</Badge>
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          </div>

          {/* Learning Path */}
          <Card className="mb-16">
            <CardHeader className="text-center">
              <CardTitle className="text-2xl">Structured Learning Path</CardTitle>
              <CardDescription className="text-lg">
                Follow our recommended progression to become a successful trader
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid gap-6 md:grid-cols-4">
                <div className="text-center">
                  <div className="w-12 h-12 bg-primary text-primary-foreground rounded-full flex items-center justify-center mx-auto mb-3 font-bold">
                    1
                  </div>
                  <h4 className="font-semibold mb-2">Foundation</h4>
                  <p className="text-sm text-muted-foreground">Learn market basics and terminology</p>
                </div>
                <div className="text-center">
                  <div className="w-12 h-12 bg-primary text-primary-foreground rounded-full flex items-center justify-center mx-auto mb-3 font-bold">
                    2
                  </div>
                  <h4 className="font-semibold mb-2">Analysis</h4>
                  <p className="text-sm text-muted-foreground">Master technical and fundamental analysis</p>
                </div>
                <div className="text-center">
                  <div className="w-12 h-12 bg-primary text-primary-foreground rounded-full flex items-center justify-center mx-auto mb-3 font-bold">
                    3
                  </div>
                  <h4 className="font-semibold mb-2">Strategy</h4>
                  <p className="text-sm text-muted-foreground">Develop and test trading strategies</p>
                </div>
                <div className="text-center">
                  <div className="w-12 h-12 bg-primary text-primary-foreground rounded-full flex items-center justify-center mx-auto mb-3 font-bold">
                    4
                  </div>
                  <h4 className="font-semibold mb-2">Mastery</h4>
                  <p className="text-sm text-muted-foreground">Refine skills and achieve consistency</p>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* CTA Section */}
          <Card className="bg-gradient-to-r from-primary/5 to-primary/10 border-primary/20">
            <CardHeader className="text-center">
              <CardTitle className="text-2xl">Start Your Learning Journey</CardTitle>
              <CardDescription className="text-lg">
                Join thousands of traders who have improved their performance with our education
              </CardDescription>
            </CardHeader>
            <CardContent className="text-center">
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Button size="lg">
                  Browse All Courses
                </Button>
                <Button variant="outline" size="lg">
                  Free Resources
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </main>
      <Footer />
    </div>
  );
};

export default Learn;