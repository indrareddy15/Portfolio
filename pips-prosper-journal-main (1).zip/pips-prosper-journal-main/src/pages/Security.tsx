import { Navigation } from "@/components/Navigation";
import { Footer } from "@/components/Footer";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Shield, Lock, Eye, Server, Key, FileCheck } from "lucide-react";
import { SEOHead } from "@/components/SEOHead";

const Security = () => {
  const features = [
    {
      icon: Shield,
      title: "End-to-End Encryption",
      description: "All data is encrypted in transit and at rest using AES-256 encryption"
    },
    {
      icon: Lock,
      title: "Multi-Factor Authentication",
      description: "Secure your account with 2FA using authenticator apps or SMS"
    },
    {
      icon: Eye,
      title: "Privacy by Design",
      description: "We never sell your data and follow strict privacy guidelines"
    },
    {
      icon: Server,
      title: "Secure Infrastructure",
      description: "Hosted on enterprise-grade cloud infrastructure with 99.9% uptime"
    },
    {
      icon: Key,
      title: "API Security",
      description: "All API endpoints are secured with rate limiting and authentication"
    },
    {
      icon: FileCheck,
      title: "Compliance",
      description: "SOC 2 Type II compliant with regular security audits"
    }
  ];

  const certifications = [
    "SOC 2 Type II",
    "ISO 27001",
    "GDPR Compliant",
    "PCI DSS Level 1"
  ];

  return (
    <div className="min-h-screen bg-background">
      <SEOHead 
        title="Security & Data Protection - PipTrackr.com Trading Journal"
        description="Learn about PipTrackr.com's enterprise-grade security measures. Bank-level encryption, SOC 2 compliance, and comprehensive data protection for your trading data."
        keywords="trading data security, encryption, data protection, secure trading journal, SOC 2 compliance, bank grade security"
        canonical={`${window.location.origin}/security`}
      />
      <Navigation />
      <main className="container mx-auto px-4 py-8 pt-24">
        <div className="max-w-4xl mx-auto">
          {/* Hero Section */}
          <div className="text-center mb-16">
            <Badge variant="secondary" className="mb-4">Security & Trust</Badge>
            <h1 className="text-4xl font-bold tracking-tight mb-6">
              Your Data, Secured
            </h1>
            <p className="text-muted-foreground text-lg leading-relaxed">
              We take security seriously. Your trading data is protected by enterprise-grade 
              security measures and industry-leading compliance standards.
            </p>
          </div>

          {/* Security Features */}
          <div className="grid gap-6 md:grid-cols-2 mb-16">
            {features.map((feature, index) => {
              const Icon = feature.icon;
              return (
                <Card key={index}>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-3">
                      <Icon className="h-6 w-6 text-primary" />
                      {feature.title}
                    </CardTitle>
                    <CardDescription>{feature.description}</CardDescription>
                  </CardHeader>
                </Card>
              );
            })}
          </div>

          {/* Data Protection */}
          <Card className="mb-16">
            <CardHeader>
              <CardTitle>Data Protection & Privacy</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <h4 className="font-semibold mb-2">What we collect:</h4>
                <p className="text-muted-foreground">
                  We only collect the trading data you choose to share and basic account information 
                  necessary to provide our services.
                </p>
              </div>
              <div>
                <h4 className="font-semibold mb-2">How we protect it:</h4>
                <p className="text-muted-foreground">
                  All data is encrypted using AES-256 encryption, transmitted over HTTPS, and stored 
                  in secure, geographically distributed data centers.
                </p>
              </div>
              <div>
                <h4 className="font-semibold mb-2">Your control:</h4>
                <p className="text-muted-foreground">
                  You can export or delete your data at any time. We provide granular privacy controls 
                  and transparent data usage policies.
                </p>
              </div>
            </CardContent>
          </Card>

          {/* Infrastructure */}
          <Card className="mb-16">
            <CardHeader>
              <CardTitle>Infrastructure Security</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid gap-4 md:grid-cols-2">
                <div>
                  <h4 className="font-semibold mb-2">Cloud Security</h4>
                  <p className="text-muted-foreground text-sm">
                    Hosted on AWS with enterprise-grade security controls, DDoS protection, 
                    and automated backups.
                  </p>
                </div>
                <div>
                  <h4 className="font-semibold mb-2">Network Security</h4>
                  <p className="text-muted-foreground text-sm">
                    All traffic is encrypted in transit using TLS 1.3, with WAF protection 
                    and intrusion detection systems.
                  </p>
                </div>
                <div>
                  <h4 className="font-semibold mb-2">Access Control</h4>
                  <p className="text-muted-foreground text-sm">
                    Role-based access control with the principle of least privilege, 
                    regular access reviews, and audit logging.
                  </p>
                </div>
                <div>
                  <h4 className="font-semibold mb-2">Monitoring</h4>
                  <p className="text-muted-foreground text-sm">
                    24/7 security monitoring with automated threat detection, 
                    incident response, and regular penetration testing.
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Certifications */}
          <Card className="mb-16">
            <CardHeader>
              <CardTitle>Certifications & Compliance</CardTitle>
              <CardDescription>
                We maintain the highest standards of security and privacy compliance
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid gap-4 md:grid-cols-2">
                {certifications.map((cert, index) => (
                  <div key={index} className="flex items-center gap-3">
                    <Badge variant="outline">{cert}</Badge>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Security Practices */}
          <Card>
            <CardHeader>
              <CardTitle>Security Best Practices</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div>
                  <h4 className="font-semibold">For Your Account:</h4>
                  <ul className="text-muted-foreground text-sm mt-2 space-y-1">
                    <li>• Use a strong, unique password</li>
                    <li>• Enable two-factor authentication</li>
                    <li>• Regularly review your account activity</li>
                    <li>• Log out from shared computers</li>
                  </ul>
                </div>
                <div>
                  <h4 className="font-semibold">Our Commitment:</h4>
                  <ul className="text-muted-foreground text-sm mt-2 space-y-1">
                    <li>• Regular security audits and penetration testing</li>
                    <li>• Prompt security updates and patches</li>
                    <li>• Transparent incident reporting</li>
                    <li>• Continuous monitoring and improvement</li>
                  </ul>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </main>
      <Footer />
    </div>
  );
};

export default Security;