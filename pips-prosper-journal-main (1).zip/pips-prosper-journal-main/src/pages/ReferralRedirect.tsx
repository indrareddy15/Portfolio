import { useEffect, useState } from "react";
import { useParams, useNavigate, useSearchParams } from "react-router-dom";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Loader2, ExternalLink, AlertCircle } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { setAffiliateCookie } from "@/utils/affiliateTracking";

export default function ReferralRedirect() {
  const { code } = useParams<{ code: string }>();
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [affiliateData, setAffiliateData] = useState<any>(null);

  useEffect(() => {
    const handleRedirect = async () => {
      if (!code) {
        setError("Invalid referral link");
        setLoading(false);
        return;
      }

      try {
        // Track the click and get affiliate data
        const response = await supabase.functions.invoke('affiliate-track', {
          body: {
            code,
            utm_source: searchParams.get('utm_source'),
            utm_medium: searchParams.get('utm_medium'),
            utm_campaign: searchParams.get('utm_campaign'),
            utm_content: searchParams.get('utm_content'),
            utm_term: searchParams.get('utm_term'),
          }
        });

        if (response.error) {
          console.error('Error tracking affiliate click:', response.error);
          setError("Invalid referral code");
          setLoading(false);
          return;
        }

        const { affiliate_id, affiliate_code, utm } = response.data;

        // Set affiliate cookie
        setAffiliateCookie({
          affiliate_id,
          affiliate_code,
          utm: utm || {},
          timestamp: Date.now()
        });

        // Get affiliate info for display
        const { data: affiliate } = await supabase
          .from('affiliates')
          .select('*')
          .eq('id', affiliate_id)
          .single();

        setAffiliateData({
          code: affiliate_code,
          ...affiliate
        });

        // Auto-redirect after 3 seconds
        setTimeout(() => {
          window.location.href = '/';
        }, 3000);

      } catch (error) {
        console.error('Error processing referral:', error);
        setError("Failed to process referral link");
      } finally {
        setLoading(false);
      }
    };

    handleRedirect();
  }, [code, searchParams]);

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-background via-background to-muted/20">
        <Card className="w-full max-w-md">
          <CardHeader className="text-center">
            <CardTitle className="flex items-center justify-center gap-2">
              <Loader2 className="h-5 w-5 animate-spin" />
              Processing Referral
            </CardTitle>
          </CardHeader>
          <CardContent className="text-center">
            <p className="text-muted-foreground">
              Please wait while we process your referral link...
            </p>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-background via-background to-muted/20">
        <Card className="w-full max-w-md">
          <CardHeader className="text-center">
            <CardTitle className="flex items-center justify-center gap-2 text-destructive">
              <AlertCircle className="h-5 w-5" />
              Invalid Referral Link
            </CardTitle>
          </CardHeader>
          <CardContent className="text-center space-y-4">
            <p className="text-muted-foreground">{error}</p>
            <Button onClick={() => navigate('/')} className="w-full">
              Continue to PipTrackr.com
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-background via-background to-muted/20">
      <Card className="w-full max-w-md">
        <CardHeader className="text-center">
          <Badge className="mb-4 mx-auto w-fit">
            Referral Tracked
          </Badge>
          <CardTitle>Welcome to PipTrackr.com!</CardTitle>
        </CardHeader>
        <CardContent className="text-center space-y-4">
          <p className="text-muted-foreground">
            You've been referred by affiliate <strong>{affiliateData?.code}</strong>. 
            Any subscription you purchase will be attributed to them.
          </p>
          
          <div className="bg-muted/50 rounded-lg p-4 text-sm">
            <p className="font-medium mb-2">Referral Benefits:</p>
            <ul className="text-muted-foreground space-y-1">
              <li>• Priority support</li>
              <li>• Access to exclusive content</li>
              <li>• Community membership</li>
            </ul>
          </div>

          <div className="flex flex-col gap-2">
            <Button onClick={() => window.location.href = '/'} className="w-full">
              <ExternalLink className="h-4 w-4 mr-2" />
              Continue to PipTrackr.com
            </Button>
            
            <p className="text-xs text-muted-foreground">
              Redirecting automatically in a few seconds...
            </p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}