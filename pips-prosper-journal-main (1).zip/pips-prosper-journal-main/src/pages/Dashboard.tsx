import { useState, lazy, Suspense } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Skeleton } from "@/components/ui/skeleton";
import { Navigation } from "@/components/Navigation";
import { Footer } from "@/components/Footer";
import { DashboardCharts } from "@/components/Charts/DashboardCharts";
import { SEOHead } from "@/components/SEOHead";
import { useToast } from "@/hooks/use-toast";
import { 
  BarChart3, 
  TrendingUp, 
  DollarSign, 
  Calendar,
  Target,
  Activity,
  Plus,
  RefreshCw,
  TrendingDown
} from "lucide-react";

// Lazy load heavy components with proper error handling
const TradeForm = lazy(() => 
  import("@/components/TradeForm").then(module => ({ default: module.TradeForm }))
  .catch(error => {
    console.error('Failed to load TradeForm:', error);
    return { default: () => <div>Error loading TradeForm</div> };
  })
);

const TradesTable = lazy(() => 
  import("@/components/TradesTable").then(module => ({ default: module.TradesTable }))
  .catch(error => {
    console.error('Failed to load TradesTable:', error);
    return { default: () => <div>Error loading TradesTable</div> };
  })
);

const AnalyticsDashboard = lazy(() => 
  import("@/components/Analytics/AnalyticsDashboard").then(module => ({ default: module.AnalyticsDashboard }))
  .catch(error => {
    console.error('Failed to load AnalyticsDashboard:', error);
    return { default: () => <div>Error loading AnalyticsDashboard</div> };
  })
);

const ImportWizard = lazy(() => 
  import("@/components/ImportSystem/ImportWizard").then(module => ({ default: module.ImportWizard }))
  .catch(error => {
    console.error('Failed to load ImportWizard:', error);
    return { default: () => <div>Error loading ImportWizard</div> };
  })
);

const CustomizableDashboard = lazy(() => 
  import("@/components/Dashboard/CustomizableDashboard").then(module => ({ default: module.CustomizableDashboard }))
  .catch(error => {
    console.error('Failed to load CustomizableDashboard:', error);
    return { default: () => <div>Error loading CustomizableDashboard</div> };
  })
);

const GamificationDashboard = lazy(() => 
  import("@/components/Gamification/GamificationDashboard").then(module => ({ default: module.GamificationDashboard }))
  .catch(error => {
    console.error('Failed to load GamificationDashboard:', error);
    return { default: () => <div>Error loading GamificationDashboard</div> };
  })
);

const PropChallengeTracker = lazy(() => 
  import("@/components/PropFirm/PropChallengeTracker").then(module => ({ default: module.PropChallengeTracker }))
  .catch(error => {
    console.error('Failed to load PropChallengeTracker:', error);
    return { default: () => <div>Error loading PropChallengeTracker</div> };
  })
);

const AITradeCoach = lazy(() => 
  import("@/components/AI/AITradeCoach").then(module => ({ default: module.AITradeCoach }))
  .catch(error => {
    console.error('Failed to load AITradeCoach:', error);
    return { default: () => <div>Error loading AITradeCoach</div> };
  })
);

const PsychologyDashboard = lazy(() => 
  import("@/components/Psychology/PsychologyDashboard").then(module => ({ default: module.PsychologyDashboard }))
  .catch(error => {
    console.error('Failed to load PsychologyDashboard:', error);
    return { default: () => <div>Error loading PsychologyDashboard</div> };
  })
);

const TradingCalendar = lazy(() => 
  import("@/components/Calendar/TradingCalendar").then(module => ({ default: module.TradingCalendar }))
  .catch(error => {
    console.error('Failed to load TradingCalendar:', error);
    return { default: () => <div>Error loading TradingCalendar</div> };
  })
);

const SharingDashboard = lazy(() => 
  import("@/components/Sharing/SharingDashboard").then(module => ({ default: module.SharingDashboard }))
  .catch(error => {
    console.error('Failed to load SharingDashboard:', error);
    return { default: () => <div>Error loading SharingDashboard</div> };
  })
);

const StrategyManager = lazy(() => 
  import("@/components/Strategy/StrategyManager").then(module => ({ default: module.StrategyManager }))
  .catch(error => {
    console.error('Failed to load StrategyManager:', error);
    return { default: () => <div>Error loading StrategyManager</div> };
  })
);

const AccountSettings = lazy(() => 
  import("@/components/Settings/AccountSettings").then(module => ({ default: module.AccountSettings }))
  .catch(error => {
    console.error('Failed to load AccountSettings:', error);
    return { default: () => <div>Error loading AccountSettings</div> };
  })
);

const LoadingSkeleton = () => (
  <div className="space-y-6">
    <Skeleton className="h-32 w-full" />
    <Skeleton className="h-64 w-full" />
    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
      <Skeleton className="h-24" />
      <Skeleton className="h-24" />
      <Skeleton className="h-24" />
    </div>
  </div>
);

export default function Dashboard() {
  const [refreshTrigger, setRefreshTrigger] = useState(0);
  const [activeTab, setActiveTab] = useState("journal");
  const [marketData, setMarketData] = useState({
    sp500: { value: 4567.89, change: 1.2, changeValue: 54.23 },
    nasdaq: { value: 15234.67, change: -0.8, changeValue: -123.45 },
    usdeur: { value: 1.0894, change: 0.3, changeValue: 0.0032 }
  });
  const [todaysStats, setTodaysStats] = useState({
    pnl: 1247,
    trades: { completed: 8, total: 12 },
    winRate: 75,
    portfolio: 47200
  });
  const { toast } = useToast();

  const handleTradeAdded = () => {
    setRefreshTrigger(prev => prev + 1);
    // Update today's stats
    setTodaysStats(prev => ({
      ...prev,
      trades: { ...prev.trades, completed: prev.trades.completed + 1 },
      pnl: prev.pnl + Math.floor(Math.random() * 200) - 100 // Simulate P&L change
    }));
    toast({
      title: "Trade Added Successfully",
      description: "Your new trade has been recorded and analytics updated.",
    });
  };

  const handleQuickTrade = () => {
    setActiveTab("add-trade");
    toast({
      title: "Quick Trade",
      description: "Redirected to add trade section",
    });
  };

  const handleViewAnalytics = () => {
    setActiveTab("analytics");
    toast({
      title: "Analytics Dashboard",
      description: "Loading your trading analytics",
    });
  };

  const refreshMarketData = () => {
    // Simulate real market data updates
    setMarketData(prev => ({
      sp500: {
        ...prev.sp500,
        change: (Math.random() - 0.5) * 4, // -2% to +2%
        changeValue: (Math.random() - 0.5) * 200
      },
      nasdaq: {
        ...prev.nasdaq,
        change: (Math.random() - 0.5) * 4,
        changeValue: (Math.random() - 0.5) * 500
      },
      usdeur: {
        ...prev.usdeur,
        change: (Math.random() - 0.5) * 2,
        changeValue: (Math.random() - 0.5) * 0.01
      }
    }));
    toast({
      title: "Market Data Updated",
      description: "Latest market prices have been refreshed",
    });
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-muted/5 to-primary/5">
      <SEOHead 
        title="Forex Trading Dashboard - Track MT4, MT5 & Prop Firm Trades | PipTrackr.com"
        description="Professional forex trading dashboard for MT4, MT5, and prop firm traders. Track performance, analyze trades, and monitor your trading journal in real-time."
        keywords="forex trading dashboard, mt4 dashboard, mt5 dashboard, prop firm dashboard, trading journal dashboard, forex analytics, trading performance tracker"
        canonical="https://piptrakr.com/dashboard"
      />
      <Navigation />
      {/* Header */}
      <div className="border-b border-card-border bg-background/80 backdrop-blur-xl sticky top-16 z-40 mt-16">
        <div className="container mx-auto px-4 py-6">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-poppins font-bold text-foreground">
                Trading Dashboard
              </h1>
              <p className="text-muted-foreground mt-1">
                Track your trades, analyze performance, and improve your strategy
              </p>
            </div>
            <Badge className="bg-primary/10 text-primary border-primary/20">
              Welcome Back!
            </Badge>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="container mx-auto px-4 py-8 space-y-8">
        {/* Hero Dashboard Section */}
        <div className="relative overflow-hidden rounded-2xl bg-gradient-to-br from-primary via-primary-dark to-secondary p-4 sm:p-6 lg:p-8 text-white animate-fade-in">
          <div className="absolute inset-0 bg-gradient-to-r from-primary/20 to-transparent" />
          <div className="absolute top-0 right-0 w-32 h-32 sm:w-64 sm:h-64 bg-white/5 rounded-full -translate-y-16 sm:-translate-y-32 translate-x-16 sm:translate-x-32" />
          <div className="absolute bottom-0 left-0 w-24 h-24 sm:w-48 sm:h-48 bg-white/5 rounded-full translate-y-12 sm:translate-y-24 -translate-x-12 sm:-translate-x-24" />
          
          <div className="relative z-10 grid grid-cols-1 xl:grid-cols-2 gap-6 lg:gap-8 items-center">
            {/* Left Content */}
            <div className="space-y-4 lg:space-y-6">
              <div className="space-y-2">
                <Badge className="bg-white/20 text-white border-white/30 mb-2 lg:mb-4">
                  Professional Trader Dashboard
                </Badge>
                <h1 className="text-2xl sm:text-3xl lg:text-4xl xl:text-5xl font-poppins font-bold leading-tight">
                  Master Your Trading Journey
                </h1>
                <p className="text-sm sm:text-base lg:text-lg text-white/90 leading-relaxed">
                  Track performance, analyze patterns, and execute winning strategies with our comprehensive trading platform.
                </p>
              </div>
              
              <div className="flex flex-col sm:flex-row gap-3 lg:gap-4">
                <Button 
                  size="lg" 
                  className="bg-white text-primary hover:bg-white/90 font-semibold px-4 lg:px-6 py-2 lg:py-3 text-sm lg:text-base"
                  onClick={handleQuickTrade}
                >
                  <Plus className="h-4 w-4 lg:h-5 lg:w-5 mr-2" />
                  New Trade
                </Button>
                <Button 
                  variant="outline" 
                  size="lg" 
                  className="border-white/30 text-white hover:bg-white/20 hover:border-white/50 hover:shadow-lg hover:shadow-white/20 font-semibold px-4 lg:px-6 py-2 lg:py-3 text-sm lg:text-base transition-all duration-300"
                  onClick={handleViewAnalytics}
                >
                  <BarChart3 className="h-4 w-4 lg:h-5 lg:w-5 mr-2 transition-transform duration-300 group-hover:scale-110" />
                  Analytics
                </Button>
              </div>
            </div>
            
            {/* Right Content - Live Stats */}
            <div className="space-y-3 lg:space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="text-lg sm:text-xl font-poppins font-semibold text-white/95">Today's Performance</h3>
                <Button 
                  variant="ghost" 
                  size="sm" 
                  className="text-white/80 hover:text-white hover:bg-white/10 p-2"
                  onClick={refreshMarketData}
                >
                  <RefreshCw className="h-3 w-3 sm:h-4 sm:w-4" />
                </Button>
              </div>
              <div className="grid grid-cols-2 gap-3 lg:gap-4">
                <div className="bg-white/10 backdrop-blur-sm rounded-xl p-3 lg:p-4 border border-white/20 hover:bg-white/20 transition-colors cursor-pointer">
                  <div className="flex items-center gap-2 lg:gap-3">
                    <div className={`p-1.5 lg:p-2 rounded-lg ${todaysStats.pnl >= 0 ? 'bg-success/20' : 'bg-danger/20'}`}>
                      {todaysStats.pnl >= 0 ? 
                        <TrendingUp className="h-3 w-3 sm:h-4 sm:w-4 lg:h-5 lg:w-5 text-white" /> : 
                        <TrendingDown className="h-3 w-3 sm:h-4 sm:w-4 lg:h-5 lg:w-5 text-white" />
                      }
                    </div>
                    <div className="min-w-0">
                      <p className="text-xs sm:text-sm text-white/80 truncate">Today's P&L</p>
                      <p className={`text-sm sm:text-lg lg:text-xl font-bold truncate ${todaysStats.pnl >= 0 ? 'text-white' : 'text-red-200'}`}>
                        {todaysStats.pnl >= 0 ? '+' : ''}${todaysStats.pnl.toLocaleString()}
                      </p>
                    </div>
                  </div>
                </div>
                
                <div className="bg-white/10 backdrop-blur-sm rounded-xl p-3 lg:p-4 border border-white/20 hover:bg-white/20 transition-colors cursor-pointer">
                  <div className="flex items-center gap-2 lg:gap-3">
                    <div className="p-1.5 lg:p-2 bg-warning/20 rounded-lg">
                      <Activity className="h-3 w-3 sm:h-4 sm:w-4 lg:h-5 lg:w-5 text-white" />
                    </div>
                    <div className="min-w-0">
                      <p className="text-xs sm:text-sm text-white/80 truncate">Trades</p>
                      <p className="text-sm sm:text-lg lg:text-xl font-bold text-white truncate">
                        {todaysStats.trades.completed} / {todaysStats.trades.total}
                      </p>
                    </div>
                  </div>
                </div>
                
                <div className="bg-white/10 backdrop-blur-sm rounded-xl p-3 lg:p-4 border border-white/20 hover:bg-white/20 transition-colors cursor-pointer">
                  <div className="flex items-center gap-2 lg:gap-3">
                    <div className="p-1.5 lg:p-2 bg-info/20 rounded-lg">
                      <Target className="h-3 w-3 sm:h-4 sm:w-4 lg:h-5 lg:w-5 text-white" />
                    </div>
                    <div className="min-w-0">
                      <p className="text-xs sm:text-sm text-white/80 truncate">Win Rate</p>
                      <p className="text-sm sm:text-lg lg:text-xl font-bold text-white truncate">{todaysStats.winRate}%</p>
                    </div>
                  </div>
                </div>
                
                <div className="bg-white/10 backdrop-blur-sm rounded-xl p-3 lg:p-4 border border-white/20 hover:bg-white/20 transition-colors cursor-pointer">
                  <div className="flex items-center gap-2 lg:gap-3">
                    <div className="p-1.5 lg:p-2 bg-accent/20 rounded-lg">
                      <DollarSign className="h-3 w-3 sm:h-4 sm:w-4 lg:h-5 lg:w-5 text-white" />
                    </div>
                    <div className="min-w-0">
                      <p className="text-xs sm:text-sm text-white/80 truncate">Portfolio</p>
                      <p className="text-sm sm:text-lg lg:text-xl font-bold text-white truncate">
                        ${(todaysStats.portfolio / 1000).toFixed(1)}K
                      </p>
                    </div>
                  </div>
                </div>
              </div>
              
              {/* Quick Market Ticker */}
              <div className="bg-white/10 backdrop-blur-sm rounded-xl p-3 lg:p-4 border border-white/20">
                <div className="flex items-center justify-between text-xs sm:text-sm mb-2">
                  <span className="text-white/80">Market Status:</span>
                  <div className="flex items-center gap-2">
                    <div className="h-1.5 w-1.5 sm:h-2 sm:w-2 bg-success rounded-full animate-pulse"></div>
                    <span className="text-white font-medium">Open</span>
                  </div>
                </div>
                <div className="space-y-1 lg:space-y-2 text-xs">
                  <div className="flex justify-between items-center">
                    <span className="text-white/70">S&P 500</span>
                    <div className="flex items-center gap-2">
                      <span className="text-white text-right">{marketData.sp500.value.toLocaleString()}</span>
                      <span className={`text-right min-w-0 ${marketData.sp500.change >= 0 ? 'text-green-300' : 'text-red-300'}`}>
                        {marketData.sp500.change >= 0 ? '+' : ''}{marketData.sp500.change.toFixed(1)}%
                      </span>
                    </div>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-white/70">NASDAQ</span>
                    <div className="flex items-center gap-2">
                      <span className="text-white text-right">{marketData.nasdaq.value.toLocaleString()}</span>
                      <span className={`text-right min-w-0 ${marketData.nasdaq.change >= 0 ? 'text-green-300' : 'text-red-300'}`}>
                        {marketData.nasdaq.change >= 0 ? '+' : ''}{marketData.nasdaq.change.toFixed(1)}%
                      </span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Enhanced Dashboard Charts */}
        <DashboardCharts />

        {/* Welcome & Quick Actions Section */}
        <div className="grid grid-cols-1 xl:grid-cols-3 gap-4 sm:gap-6 animate-fade-in">
          {/* Welcome Banner */}
          <Card className="xl:col-span-2 relative overflow-hidden bg-gradient-to-r from-primary/10 via-primary/5 to-background border-primary/20 hover:shadow-lg hover:shadow-primary/10 transition-all duration-300">
            <div className="absolute inset-0 bg-gradient-to-r from-primary/5 to-transparent" />
            <CardHeader className="relative z-10 pb-3 sm:pb-4">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div className="space-y-1">
                  <CardTitle className="text-lg sm:text-xl font-poppins text-foreground">
                    Good morning, Trader! 🚀
                  </CardTitle>
                  <div className="text-sm text-muted-foreground">
                    Ready to make some profitable trades today? Your portfolio is performing well.
                  </div>
                </div>
                <Badge className="bg-success/10 text-success border-success/20 px-3 py-1 w-fit">
                  Active
                </Badge>
              </div>
            </CardHeader>
            <CardContent className="relative z-10 pt-0">
              <div className="flex flex-col sm:flex-row flex-wrap gap-2 sm:gap-3">
                <Button size="sm" className="bg-primary hover:bg-primary-dark hover:shadow-lg hover:shadow-primary/30 text-primary-foreground text-xs sm:text-sm transition-all duration-300 group">
                  <Plus className="h-3 w-3 sm:h-4 sm:w-4 mr-2 transition-transform duration-300 group-hover:rotate-90" />
                  Quick Trade
                </Button>
                <Button variant="outline" size="sm" className="border-primary/20 text-primary hover:bg-primary/10 hover:border-primary/40 hover:shadow-md hover:shadow-primary/20 text-xs sm:text-sm transition-all duration-300 group">
                  <BarChart3 className="h-3 w-3 sm:h-4 sm:w-4 mr-2 text-primary transition-transform duration-300 group-hover:scale-110" />
                  View Analysis
                </Button>
                <Button variant="outline" size="sm" className="border-primary/20 text-primary hover:bg-primary/10 hover:border-primary/40 hover:shadow-md hover:shadow-primary/20 text-xs sm:text-sm transition-all duration-300 group">
                  <Calendar className="h-3 w-3 sm:h-4 sm:w-4 mr-2 text-primary transition-transform duration-300 group-hover:bounce" />
                  Trading Plan
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* Market Status */}
          <Card className="relative overflow-hidden bg-gradient-to-br from-secondary/5 via-background to-secondary/5 border-secondary/20 hover:shadow-lg transition-all duration-300">
            <CardHeader className="pb-2 sm:pb-3">
              <CardTitle className="text-base sm:text-lg font-poppins flex items-center gap-2">
                <Activity className="h-4 w-4 sm:h-5 sm:w-5 text-primary animate-pulse" />
                Market Status
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3 sm:space-y-4 pt-0">
              <div className="space-y-2 sm:space-y-3">
                <div className="flex items-center justify-between p-2 sm:p-3 rounded-lg bg-success/5 border border-success/20">
                  <div className="min-w-0">
                    <p className="font-medium text-xs sm:text-sm text-foreground truncate">S&P 500</p>
                    <p className="text-xs text-muted-foreground">4,567.89</p>
                  </div>
                  <div className="text-right">
                    <p className="text-xs sm:text-sm font-medium text-success">+1.2%</p>
                    <p className="text-xs text-success">+54.23</p>
                  </div>
                </div>
                
                <div className="flex items-center justify-between p-2 sm:p-3 rounded-lg bg-danger/5 border border-danger/20">
                  <div className="min-w-0">
                    <p className="font-medium text-xs sm:text-sm text-foreground truncate">NASDAQ</p>
                    <p className="text-xs text-muted-foreground">15,234.67</p>
                  </div>
                  <div className="text-right">
                    <p className="text-xs sm:text-sm font-medium text-danger">-0.8%</p>
                    <p className="text-xs text-danger">-123.45</p>
                  </div>
                </div>

                <div className="flex items-center justify-between p-2 sm:p-3 rounded-lg bg-warning/5 border border-warning/20">
                  <div className="min-w-0">
                    <p className="font-medium text-xs sm:text-sm text-foreground truncate">USD/EUR</p>
                    <p className="text-xs text-muted-foreground">1.0894</p>
                  </div>
                  <div className="text-right">
                    <p className="text-xs sm:text-sm font-medium text-warning">+0.3%</p>
                    <p className="text-xs text-warning">+0.0032</p>
                  </div>
                </div>
              </div>
              
              <div className="pt-2 border-t border-border">
                <div className="text-xs text-muted-foreground flex items-center gap-1">
                  <div className="h-1.5 w-1.5 sm:h-2 sm:w-2 bg-success rounded-full animate-pulse"></div>
                  <span className="truncate">Markets open • Last updated 2 min ago</span>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Quick Overview Section */}
        <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4 sm:gap-6 animate-fade-in">
          <Card className="group relative overflow-hidden bg-gradient-to-br from-primary/5 via-primary/10 to-primary/15 border-primary/30 hover:border-primary/50 transition-all duration-300 hover:shadow-lg hover:shadow-primary/20 animate-scale-in">
            <div className="absolute inset-0 bg-gradient-to-br from-primary/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2 relative z-10">
              <CardTitle className="text-xs sm:text-sm font-medium text-foreground truncate">Total P&L</CardTitle>
              <div className="p-1.5 sm:p-2 rounded-full bg-primary/10 group-hover:bg-primary/20 transition-colors duration-300 flex-shrink-0">
                <DollarSign className="h-3 w-3 sm:h-4 sm:w-4 text-primary" />
              </div>
            </CardHeader>
            <CardContent className="relative z-10 pt-0">
              <div className="text-lg sm:text-2xl font-bold text-primary mb-1">+$12,450</div>
              <div className="flex items-center text-xs">
                <TrendingUp className="h-3 w-3 text-success mr-1 flex-shrink-0" />
                <span className="text-success font-medium">+20.1%</span>
                <span className="text-muted-foreground ml-1 truncate">from last month</span>
              </div>
            </CardContent>
          </Card>

          <Card className="group relative overflow-hidden bg-gradient-to-br from-success/5 via-success/10 to-success/15 border-success/30 hover:border-success/50 transition-all duration-300 hover:shadow-lg hover:shadow-success/20 animate-scale-in" style={{animationDelay: '100ms'}}>
            <div className="absolute inset-0 bg-gradient-to-br from-success/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2 relative z-10">
              <CardTitle className="text-xs sm:text-sm font-medium text-foreground truncate">Win Rate</CardTitle>
              <div className="p-1.5 sm:p-2 rounded-full bg-success/10 group-hover:bg-success/20 transition-colors duration-300 flex-shrink-0">
                <Target className="h-3 w-3 sm:h-4 sm:w-4 text-success" />
              </div>
            </CardHeader>
            <CardContent className="relative z-10 pt-0">
              <div className="text-lg sm:text-2xl font-bold text-success mb-1">68.5%</div>
              <div className="flex items-center text-xs">
                <TrendingUp className="h-3 w-3 text-success mr-1 flex-shrink-0" />
                <span className="text-success font-medium">+5.2%</span>
                <span className="text-muted-foreground ml-1 truncate">from last month</span>
              </div>
            </CardContent>
          </Card>

          <Card className="group relative overflow-hidden bg-gradient-to-br from-warning/5 via-warning/10 to-warning/15 border-warning/30 hover:border-warning/50 transition-all duration-300 hover:shadow-lg hover:shadow-warning/20 animate-scale-in" style={{animationDelay: '200ms'}}>
            <div className="absolute inset-0 bg-gradient-to-br from-warning/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2 relative z-10">
              <CardTitle className="text-xs sm:text-sm font-medium text-foreground truncate">Total Trades</CardTitle>
              <div className="p-1.5 sm:p-2 rounded-full bg-warning/10 group-hover:bg-warning/20 transition-colors duration-300 flex-shrink-0">
                <Activity className="h-3 w-3 sm:h-4 sm:w-4 text-warning" />
              </div>
            </CardHeader>
            <CardContent className="relative z-10 pt-0">
              <div className="text-lg sm:text-2xl font-bold text-warning mb-1">247</div>
              <div className="flex items-center text-xs">
                <Plus className="h-3 w-3 text-success mr-1 flex-shrink-0" />
                <span className="text-success font-medium">+12</span>
                <span className="text-muted-foreground ml-1 truncate">this week</span>
              </div>
            </CardContent>
          </Card>

          <Card className="group relative overflow-hidden bg-gradient-to-br from-info/5 via-info/10 to-info/15 border-info/30 hover:border-info/50 transition-all duration-300 hover:shadow-lg hover:shadow-info/20 animate-scale-in" style={{animationDelay: '300ms'}}>
            <div className="absolute inset-0 bg-gradient-to-br from-info/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2 relative z-10">
              <CardTitle className="text-xs sm:text-sm font-medium text-foreground truncate">Avg. Daily Return</CardTitle>
              <div className="p-1.5 sm:p-2 rounded-full bg-info/10 group-hover:bg-info/20 transition-colors duration-300 flex-shrink-0">
                <TrendingUp className="h-3 w-3 sm:h-4 sm:w-4 text-info" />
              </div>
            </CardHeader>
            <CardContent className="relative z-10 pt-0">
              <div className="text-lg sm:text-2xl font-bold text-info mb-1">2.8%</div>
              <div className="flex items-center text-xs">
                <TrendingUp className="h-3 w-3 text-success mr-1 flex-shrink-0" />
                <span className="text-success font-medium">+0.4%</span>
                <span className="text-muted-foreground ml-1 truncate">from last month</span>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Main Tabs */}
        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          <TabsList className="grid w-full grid-cols-2 sm:grid-cols-4 lg:grid-cols-6 xl:grid-cols-12 gap-1 h-auto">
            <TabsTrigger value="dashboard" className="text-xs sm:text-sm">Dashboard</TabsTrigger>
            <TabsTrigger value="journal" className="text-xs sm:text-sm">Journal</TabsTrigger>
            <TabsTrigger value="add-trade" className="text-xs sm:text-sm">Add Trade</TabsTrigger>
            <TabsTrigger value="analytics" className="text-xs sm:text-sm">Analytics</TabsTrigger>
            <TabsTrigger value="gamification" className="text-xs sm:text-sm">Gamification</TabsTrigger>
            <TabsTrigger value="prop-firm" className="text-xs sm:text-sm">Prop Firm</TabsTrigger>
            <TabsTrigger value="ai-coach" className="text-xs sm:text-sm">AI Coach</TabsTrigger>
            <TabsTrigger value="psychology" className="text-xs sm:text-sm">Psychology</TabsTrigger>
            <TabsTrigger value="calendar" className="text-xs sm:text-sm">Calendar</TabsTrigger>
            <TabsTrigger value="sharing" className="text-xs sm:text-sm">Sharing</TabsTrigger>
            <TabsTrigger value="import" className="text-xs sm:text-sm">Import</TabsTrigger>
            <TabsTrigger value="strategy" className="text-xs sm:text-sm">Strategies</TabsTrigger>
            <TabsTrigger value="settings" className="text-xs sm:text-sm">Settings</TabsTrigger>
          </TabsList>

          <TabsContent value="dashboard" className="space-y-6">
            <Suspense fallback={<LoadingSkeleton />}>
              <CustomizableDashboard />
            </Suspense>
          </TabsContent>

          <TabsContent value="journal" className="space-y-6">
            <Suspense fallback={<LoadingSkeleton />}>
              <TradesTable refreshTrigger={refreshTrigger} />
            </Suspense>
          </TabsContent>

          <TabsContent value="add-trade" className="space-y-6">
            <Suspense fallback={<LoadingSkeleton />}>
              <TradeForm onTradeAdded={handleTradeAdded} />
            </Suspense>
          </TabsContent>

          <TabsContent value="analytics" className="space-y-6">
            <Suspense fallback={<LoadingSkeleton />}>
              <AnalyticsDashboard />
            </Suspense>
          </TabsContent>

          <TabsContent value="gamification" className="space-y-6">
            <Suspense fallback={<LoadingSkeleton />}>
              <GamificationDashboard />
            </Suspense>
          </TabsContent>

          <TabsContent value="prop-firm" className="space-y-6">
            <Suspense fallback={<LoadingSkeleton />}>
              <PropChallengeTracker />
            </Suspense>
          </TabsContent>

          <TabsContent value="ai-coach" className="space-y-6">
            <Suspense fallback={<LoadingSkeleton />}>
              <AITradeCoach />
            </Suspense>
          </TabsContent>

          <TabsContent value="psychology" className="space-y-6">
            <Suspense fallback={<LoadingSkeleton />}>
              <PsychologyDashboard />
            </Suspense>
          </TabsContent>

          <TabsContent value="calendar" className="space-y-6">
            <Suspense fallback={<LoadingSkeleton />}>
              <TradingCalendar />
            </Suspense>
          </TabsContent>

          <TabsContent value="sharing" className="space-y-6">
            <Suspense fallback={<LoadingSkeleton />}>
              <SharingDashboard />
            </Suspense>
          </TabsContent>

          <TabsContent value="import" className="space-y-6">
            <Suspense fallback={<LoadingSkeleton />}>
              <ImportWizard />
            </Suspense>
          </TabsContent>

          <TabsContent value="strategy" className="space-y-6">
            <Suspense fallback={<LoadingSkeleton />}>
              <StrategyManager />
            </Suspense>
          </TabsContent>

          <TabsContent value="settings" className="space-y-6">
            <Suspense fallback={<LoadingSkeleton />}>
              <AccountSettings />
            </Suspense>
          </TabsContent>
        </Tabs>
      </div>
      <Footer />
    </div>
  );
}