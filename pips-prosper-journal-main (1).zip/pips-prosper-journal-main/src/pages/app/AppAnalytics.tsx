import { Suspense, lazy } from "react"
import { useSearchParams } from "react-router-dom"
import { Skeleton } from "@/components/ui/skeleton"
import { SEOHead } from "@/components/SEOHead"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { RealTimeSessionsAnalytics } from "@/components/RealTimeSessionsAnalytics"
import { RealTimeRiskAnalytics } from "@/components/RealTimeRiskAnalytics"
import { RealTimeTradingCalendar } from "@/components/RealTimeTradingCalendar"
import { RealTimeMistakesAnalytics } from "@/components/RealTimeMistakesAnalytics"
import { ModernTradingCalendar } from "@/components/ModernTradingCalendar"

const AnalyticsDashboard = lazy(() => 
  import("@/components/Analytics/AnalyticsDashboard").then(module => ({ default: module.AnalyticsDashboard }))
  .catch(error => {
    console.error('Failed to load AnalyticsDashboard:', error);
    return { default: () => <div>Error loading AnalyticsDashboard</div> };
  })
);

const LoadingSkeleton = () => (
  <div className="space-y-6">
    <Skeleton className="h-64 w-full" />
    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
      <Skeleton className="h-48" />
      <Skeleton className="h-48" />
      <Skeleton className="h-48" />
    </div>
  </div>
);

export default function AppAnalytics() {
  const [searchParams, setSearchParams] = useSearchParams()
  const activeTab = searchParams.get('tab') || 'overview'

  const handleTabChange = (value: string) => {
    setSearchParams({ tab: value })
  }

  return (
    <div className="space-y-6">
      <SEOHead 
        title="Analytics Dashboard - PipTrackr.com"
        description="Comprehensive trading analytics and performance insights"
      />
      
      <div>
        <h1 className="text-3xl font-poppins font-bold text-foreground">
          Analytics Dashboard
        </h1>
        <p className="text-muted-foreground mt-1">
          Deep dive into your trading performance and patterns
        </p>
      </div>

      <Tabs value={activeTab} onValueChange={handleTabChange} className="space-y-6">
        <TabsList className="grid w-full grid-cols-6">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="instruments">Instruments</TabsTrigger>
          <TabsTrigger value="sessions">Sessions</TabsTrigger>
          <TabsTrigger value="calendar">Calendar</TabsTrigger>
          <TabsTrigger value="risk">Risk</TabsTrigger>
          <TabsTrigger value="mistakes">Mistakes</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-6">
          <Suspense fallback={<LoadingSkeleton />}>
            <AnalyticsDashboard />
          </Suspense>
        </TabsContent>

        <TabsContent value="instruments" className="space-y-6">
          <Suspense fallback={<LoadingSkeleton />}>
            <AnalyticsDashboard />
          </Suspense>
        </TabsContent>

        <TabsContent value="sessions" className="space-y-6">
          <Suspense fallback={<LoadingSkeleton />}>
            <RealTimeSessionsAnalytics />
          </Suspense>
        </TabsContent>

        <TabsContent value="calendar" className="space-y-6">
          <Suspense fallback={<LoadingSkeleton />}>
            <ModernTradingCalendar />
          </Suspense>
        </TabsContent>

        <TabsContent value="risk" className="space-y-6">
          <Suspense fallback={<LoadingSkeleton />}>
            <RealTimeRiskAnalytics />
          </Suspense>
        </TabsContent>

        <TabsContent value="mistakes" className="space-y-6">
          <Suspense fallback={<LoadingSkeleton />}>
            <RealTimeMistakesAnalytics />
          </Suspense>
        </TabsContent>
      </Tabs>
    </div>
  )
}