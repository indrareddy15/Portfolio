import { useState, useEffect } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { 
  Copy, 
  ExternalLink, 
  QrCode, 
  Download,
  Plus,
  Trash2,
  Eye,
  Link
} from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { toast } from "@/hooks/use-toast";
import { generateReferralLink, generateShortReferralLink } from "@/utils/affiliateTracking";
import { Skeleton } from "@/components/ui/skeleton";
import { QRCodeSVG } from "qrcode.react";

interface AffiliateLink {
  id: string;
  name: string;
  url: string;
  clicks: number;
  conversions: number;
  created_at: string;
}

export default function AffiliateLinks() {
  const { user } = useAuth();
  const [loading, setLoading] = useState(true);
  const [affiliate, setAffiliate] = useState<any>(null);
  const [customLinks, setCustomLinks] = useState<AffiliateLink[]>([]);
  const [showQRCode, setShowQRCode] = useState<string | null>(null);
  
  // UTM Builder state
  const [utmSource, setUtmSource] = useState("");
  const [utmMedium, setUtmMedium] = useState("");
  const [utmCampaign, setUtmCampaign] = useState("");
  const [utmContent, setUtmContent] = useState("");
  const [utmTerm, setUtmTerm] = useState("");
  
  // Custom link creation
  const [linkName, setLinkName] = useState("");
  const [customUtmParams, setCustomUtmParams] = useState({
    utm_source: "",
    utm_medium: "",
    utm_campaign: "",
    utm_content: "",
    utm_term: ""
  });

  const fetchAffiliateData = async () => {
    if (!user) return;

    try {
      setLoading(true);

      // Get affiliate profile
      const { data: affiliateData, error: affiliateError } = await supabase
        .from("affiliates")
        .select("*")
        .eq("user_id", user.id)
        .single();

      if (affiliateError) {
        throw affiliateError;
      }

      setAffiliate(affiliateData);

      // Get click stats for custom links (simplified for demo)
      // In a real implementation, you'd track custom links separately
      setCustomLinks([]);

    } catch (error) {
      console.error('Error fetching affiliate data:', error);
      toast({
        title: "Error",
        description: "Failed to load affiliate data",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchAffiliateData();
  }, [user]);

  const copyToClipboard = (text: string, label: string) => {
    navigator.clipboard.writeText(text);
    toast({
      title: "Copied!",
      description: `${label} copied to clipboard`
    });
  };

  const generateLink = (type: 'main' | 'short' | 'utm') => {
    if (!affiliate) return "";

    const baseUrl = window.location.origin;
    
    if (type === 'main') {
      return generateReferralLink(affiliate.code, baseUrl);
    } else if (type === 'short') {
      return generateShortReferralLink(affiliate.code, baseUrl);
    } else if (type === 'utm') {
      const utmParams = {
        utm_source: utmSource,
        utm_medium: utmMedium,
        utm_campaign: utmCampaign,
        utm_content: utmContent,
        utm_term: utmTerm
      };
      
      // Remove empty values
      const cleanParams = Object.fromEntries(
        Object.entries(utmParams).filter(([_, value]) => value !== "")
      );
      
      return generateReferralLink(affiliate.code, baseUrl, cleanParams);
    }
    
    return "";
  };

  const testLink = (url: string) => {
    window.open(url, '_blank');
  };

  const saveCustomLink = () => {
    if (!linkName.trim()) {
      toast({
        title: "Error",
        description: "Please enter a link name",
        variant: "destructive"
      });
      return;
    }

    const utmParams = Object.fromEntries(
      Object.entries(customUtmParams).filter(([_, value]) => value !== "")
    );

    const url = generateReferralLink(affiliate.code, window.location.origin, utmParams);
    
    const newLink: AffiliateLink = {
      id: Date.now().toString(),
      name: linkName,
      url,
      clicks: 0,
      conversions: 0,
      created_at: new Date().toISOString()
    };

    setCustomLinks(prev => [...prev, newLink]);
    setLinkName("");
    setCustomUtmParams({
      utm_source: "",
      utm_medium: "",
      utm_campaign: "",
      utm_content: "",
      utm_term: ""
    });

    toast({
      title: "Success",
      description: "Custom link saved"
    });
  };

  const deleteCustomLink = (id: string) => {
    setCustomLinks(prev => prev.filter(link => link.id !== id));
    toast({
      title: "Deleted",
      description: "Custom link removed"
    });
  };

  if (loading) {
    return (
      <div className="space-y-6">
        <div>
          <Skeleton className="h-8 w-48 mb-2" />
          <Skeleton className="h-4 w-64" />
        </div>
        
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {[...Array(4)].map((_, i) => (
            <Card key={i}>
              <CardHeader>
                <Skeleton className="h-6 w-32 mb-2" />
                <Skeleton className="h-4 w-48" />
              </CardHeader>
              <CardContent>
                <Skeleton className="h-10 w-full mb-4" />
                <Skeleton className="h-8 w-24" />
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    );
  }

  if (!affiliate || affiliate.status !== 'active') {
    return (
      <div className="max-w-2xl mx-auto text-center py-12">
        <Link className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
        <h2 className="text-2xl font-semibold mb-2">Affiliate Links Unavailable</h2>
        <p className="text-muted-foreground">
          Your affiliate account must be active to access referral links.
        </p>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-3xl font-bold">Referral Links</h1>
        <p className="text-muted-foreground">
          Generate and manage your affiliate referral links
        </p>
      </div>

      <Tabs defaultValue="basic" className="space-y-6">
        <TabsList>
          <TabsTrigger value="basic">Basic Links</TabsTrigger>
          <TabsTrigger value="utm">UTM Builder</TabsTrigger>
          <TabsTrigger value="custom">Custom Links</TabsTrigger>
        </TabsList>

        <TabsContent value="basic" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Main Referral Link */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Link className="h-5 w-5" />
                  Main Referral Link
                </CardTitle>
                <CardDescription>
                  Your primary affiliate link for general use
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex gap-2">
                  <Input
                    value={generateLink('main')}
                    readOnly
                    className="font-mono text-sm"
                  />
                  <Button
                    size="icon"
                    variant="outline"
                    onClick={() => copyToClipboard(generateLink('main'), 'Main link')}
                  >
                    <Copy className="h-4 w-4" />
                  </Button>
                </div>
                <div className="flex gap-2">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => testLink(generateLink('main'))}
                  >
                    <ExternalLink className="h-4 w-4 mr-2" />
                    Test Link
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setShowQRCode(generateLink('main'))}
                  >
                    <QrCode className="h-4 w-4 mr-2" />
                    QR Code
                  </Button>
                </div>
              </CardContent>
            </Card>

            {/* Short Link */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Link className="h-5 w-5" />
                  Short Link
                </CardTitle>
                <CardDescription>
                  Shortened version for social media and messaging
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex gap-2">
                  <Input
                    value={generateLink('short')}
                    readOnly
                    className="font-mono text-sm"
                  />
                  <Button
                    size="icon"
                    variant="outline"
                    onClick={() => copyToClipboard(generateLink('short'), 'Short link')}
                  >
                    <Copy className="h-4 w-4" />
                  </Button>
                </div>
                <div className="flex gap-2">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => testLink(generateLink('short'))}
                  >
                    <ExternalLink className="h-4 w-4 mr-2" />
                    Test Link
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setShowQRCode(generateLink('short'))}
                  >
                    <QrCode className="h-4 w-4 mr-2" />
                    QR Code
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Affiliate Code Display */}
          <Card>
            <CardHeader>
              <CardTitle>Your Affiliate Code</CardTitle>
              <CardDescription>
                Use this code in custom implementations or manual tracking
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex items-center gap-4">
                <Badge variant="secondary" className="text-lg px-4 py-2 font-mono">
                  {affiliate.code}
                </Badge>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => copyToClipboard(affiliate.code, 'Affiliate code')}
                >
                  <Copy className="h-4 w-4 mr-2" />
                  Copy Code
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="utm" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>UTM Parameter Builder</CardTitle>
              <CardDescription>
                Create trackable links with custom UTM parameters for campaign tracking
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="utm_source">Source</Label>
                  <Input
                    id="utm_source"
                    placeholder="e.g., newsletter, twitter, youtube"
                    value={utmSource}
                    onChange={(e) => setUtmSource(e.target.value)}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="utm_medium">Medium</Label>
                  <Input
                    id="utm_medium"
                    placeholder="e.g., email, social, video"
                    value={utmMedium}
                    onChange={(e) => setUtmMedium(e.target.value)}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="utm_campaign">Campaign</Label>
                  <Input
                    id="utm_campaign"
                    placeholder="e.g., summer_promo, launch_week"
                    value={utmCampaign}
                    onChange={(e) => setUtmCampaign(e.target.value)}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="utm_content">Content</Label>
                  <Input
                    id="utm_content"
                    placeholder="e.g., banner_ad, text_link"
                    value={utmContent}
                    onChange={(e) => setUtmContent(e.target.value)}
                  />
                </div>
                <div className="space-y-2 md:col-span-2">
                  <Label htmlFor="utm_term">Term</Label>
                  <Input
                    id="utm_term"
                    placeholder="e.g., trading_journal, forex_tracker"
                    value={utmTerm}
                    onChange={(e) => setUtmTerm(e.target.value)}
                  />
                </div>
              </div>

              <div className="border-t pt-4">
                <Label>Generated Link</Label>
                <div className="flex gap-2 mt-2">
                  <Input
                    value={generateLink('utm')}
                    readOnly
                    className="font-mono text-sm"
                  />
                  <Button
                    size="icon"
                    variant="outline"
                    onClick={() => copyToClipboard(generateLink('utm'), 'UTM link')}
                    disabled={!generateLink('utm')}
                  >
                    <Copy className="h-4 w-4" />
                  </Button>
                </div>
                <div className="flex gap-2 mt-2">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => testLink(generateLink('utm'))}
                    disabled={!generateLink('utm')}
                  >
                    <ExternalLink className="h-4 w-4 mr-2" />
                    Test Link
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setShowQRCode(generateLink('utm'))}
                    disabled={!generateLink('utm')}
                  >
                    <QrCode className="h-4 w-4 mr-2" />
                    QR Code
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="custom" className="space-y-6">
          {/* Create Custom Link */}
          <Card>
            <CardHeader>
              <CardTitle>Create Custom Link</CardTitle>
              <CardDescription>
                Save frequently used links with custom names and parameters
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="link_name">Link Name</Label>
                <Input
                  id="link_name"
                  placeholder="e.g., YouTube Campaign, Newsletter #5"
                  value={linkName}
                  onChange={(e) => setLinkName(e.target.value)}
                />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>Source</Label>
                  <Input
                    placeholder="e.g., newsletter"
                    value={customUtmParams.utm_source}
                    onChange={(e) => setCustomUtmParams(prev => ({
                      ...prev,
                      utm_source: e.target.value
                    }))}
                  />
                </div>
                <div className="space-y-2">
                  <Label>Medium</Label>
                  <Input
                    placeholder="e.g., email"
                    value={customUtmParams.utm_medium}
                    onChange={(e) => setCustomUtmParams(prev => ({
                      ...prev,
                      utm_medium: e.target.value
                    }))}
                  />
                </div>
                <div className="space-y-2">
                  <Label>Campaign</Label>
                  <Input
                    placeholder="e.g., summer_promo"
                    value={customUtmParams.utm_campaign}
                    onChange={(e) => setCustomUtmParams(prev => ({
                      ...prev,
                      utm_campaign: e.target.value
                    }))}
                  />
                </div>
                <div className="space-y-2">
                  <Label>Content</Label>
                  <Input
                    placeholder="e.g., banner_ad"
                    value={customUtmParams.utm_content}
                    onChange={(e) => setCustomUtmParams(prev => ({
                      ...prev,
                      utm_content: e.target.value
                    }))}
                  />
                </div>
              </div>

              <Button
                onClick={saveCustomLink}
                disabled={!linkName.trim()}
                className="w-full"
              >
                <Plus className="h-4 w-4 mr-2" />
                Save Custom Link
              </Button>
            </CardContent>
          </Card>

          {/* Saved Custom Links */}
          <Card>
            <CardHeader>
              <CardTitle>Saved Custom Links</CardTitle>
              <CardDescription>
                Manage your saved referral links
              </CardDescription>
            </CardHeader>
            <CardContent>
              {customLinks.length === 0 ? (
                <p className="text-center text-muted-foreground py-8">
                  No custom links saved yet. Create one above to get started.
                </p>
              ) : (
                <div className="space-y-4">
                  {customLinks.map((link) => (
                    <div key={link.id} className="border rounded-lg p-4">
                      <div className="flex items-center justify-between mb-2">
                        <h4 className="font-semibold">{link.name}</h4>
                        <div className="flex items-center gap-2">
                          <Badge variant="outline">{link.clicks} clicks</Badge>
                          <Badge variant="outline">{link.conversions} conversions</Badge>
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => deleteCustomLink(link.id)}
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      </div>
                      <div className="flex gap-2 mb-2">
                        <Input
                          value={link.url}
                          readOnly
                          className="font-mono text-sm"
                        />
                        <Button
                          size="icon"
                          variant="outline"
                          onClick={() => copyToClipboard(link.url, link.name)}
                        >
                          <Copy className="h-4 w-4" />
                        </Button>
                      </div>
                      <div className="flex gap-2">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => testLink(link.url)}
                        >
                          <ExternalLink className="h-4 w-4 mr-2" />
                          Test
                        </Button>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => setShowQRCode(link.url)}
                        >
                          <QrCode className="h-4 w-4 mr-2" />
                          QR Code
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* QR Code Modal */}
      {showQRCode && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50" onClick={() => setShowQRCode(null)}>
          <Card className="max-w-sm mx-4" onClick={(e) => e.stopPropagation()}>
            <CardHeader>
              <CardTitle>QR Code</CardTitle>
              <CardDescription>Scan to visit your referral link</CardDescription>
            </CardHeader>
            <CardContent className="flex flex-col items-center space-y-4">
              <div className="bg-white p-4 rounded-lg">
                <QRCodeSVG
                  value={showQRCode}
                  size={200}
                  bgColor="#ffffff"
                  fgColor="#000000"
                  level="M"
                  includeMargin={false}
                />
              </div>
              <div className="flex gap-2 w-full">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => {
                    const svg = document.querySelector('.qr-code svg');
                    if (svg) {
                      const svgData = new XMLSerializer().serializeToString(svg);
                      const canvas = document.createElement('canvas');
                      const ctx = canvas.getContext('2d');
                      const img = new Image();
                      img.onload = () => {
                        canvas.width = img.width;
                        canvas.height = img.height;
                        ctx?.drawImage(img, 0, 0);
                        const pngFile = canvas.toDataURL('image/png');
                        const downloadLink = document.createElement('a');
                        downloadLink.download = 'affiliate-qr-code';
                        downloadLink.href = pngFile;
                        downloadLink.click();
                      };
                      img.src = 'data:image/svg+xml;base64,' + btoa(svgData);
                    }
                  }}
                >
                  <Download className="h-4 w-4 mr-2" />
                  Download PNG
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setShowQRCode(null)}
                >
                  Close
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      )}
    </div>
  );
}