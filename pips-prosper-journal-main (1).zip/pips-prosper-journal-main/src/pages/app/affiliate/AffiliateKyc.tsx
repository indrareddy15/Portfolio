import { useEffect, useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { 
  Shield, 
  CheckCircle, 
  XCircle, 
  Clock,
  AlertCircle,
  RefreshCw,
  FileText
} from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { toast } from "@/hooks/use-toast";

interface KycData {
  id: string;
  status: string;
  files_json: any;
  created_at: string;
  updated_at: string;
}

interface AffiliateData {
  id: string;
  status: string;
  code: string;
}

export default function AffiliateKyc() {
  const { user } = useAuth();
  const [loading, setLoading] = useState(true);
  const [affiliate, setAffiliate] = useState<AffiliateData | null>(null);
  const [kycData, setKycData] = useState<KycData | null>(null);
  const [verifying, setVerifying] = useState(false);

  const fetchKycData = async () => {
    if (!user) return;

    try {
      setLoading(true);

      // Get affiliate profile
      const { data: affiliateData, error: affiliateError } = await supabase
        .from("affiliates")
        .select("*")
        .eq("user_id", user.id)
        .single();

      if (affiliateError) throw affiliateError;
      setAffiliate(affiliateData);

      if (affiliateData.status !== 'active') {
        setLoading(false);
        return;
      }

      // Get KYC data
      const { data: kycResult, error: kycError } = await supabase
        .from("affiliate_kyc")
        .select("*")
        .eq("affiliate_id", affiliateData.id)
        .maybeSingle();

      if (kycError) throw kycError;
      setKycData(kycResult as KycData);

    } catch (error) {
      console.error('Error fetching KYC data:', error);
      toast({
        title: "Error",
        description: "Failed to load KYC data",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const startVerification = async () => {
    if (!affiliate) return;

    try {
      setVerifying(true);

      // Call Veriff API through edge function
      const { data, error } = await supabase.functions.invoke('start-kyc-verification', {
        body: {
          affiliate_id: affiliate.id,
          callback_url: `${window.location.origin}/app/affiliate/kyc`
        }
      });

      if (error) throw error;

      if (data.verification_url) {
        // Redirect to Veriff verification
        window.location.href = data.verification_url;
      }

    } catch (error) {
      console.error('Error starting verification:', error);
      toast({
        title: "Error",
        description: "Failed to start KYC verification",
        variant: "destructive"
      });
    } finally {
      setVerifying(false);
    }
  };

  useEffect(() => {
    fetchKycData();
  }, [user]);

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
      </div>
    );
  }

  if (!affiliate || affiliate.status !== 'active') {
    return (
      <div className="max-w-2xl mx-auto text-center py-12">
        <Shield className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
        <h2 className="text-2xl font-semibold mb-2">KYC Verification Unavailable</h2>
        <p className="text-muted-foreground">
          Your affiliate account must be active to access KYC verification.
        </p>
      </div>
    );
  }

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'approved':
        return <CheckCircle className="h-5 w-5 text-green-600" />;
      case 'rejected':
        return <XCircle className="h-5 w-5 text-red-600" />;
      case 'pending':
        return <Clock className="h-5 w-5 text-amber-600" />;
      default:
        return <AlertCircle className="h-5 w-5 text-muted-foreground" />;
    }
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'approved':
        return <Badge className="bg-green-100 text-green-800">Verified</Badge>;
      case 'rejected':
        return <Badge variant="destructive">Rejected</Badge>;
      case 'pending':
        return <Badge variant="secondary">Under Review</Badge>;
      default:
        return <Badge variant="outline">Not Started</Badge>;
    }
  };

  const isEligibleForVerification = affiliate && affiliate.status === 'active';
  const canStartVerification = isEligibleForVerification && (!kycData || kycData.status === 'rejected');

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">KYC Verification</h1>
          <p className="text-muted-foreground">
            Complete identity verification to unlock payout eligibility
          </p>
        </div>
        <Button 
          onClick={fetchKycData} 
          variant="outline"
          disabled={loading}
        >
          <RefreshCw className={`h-4 w-4 mr-2 ${loading ? 'animate-spin' : ''}`} />
          Refresh
        </Button>
      </div>

      {/* KYC Status Overview */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Shield className="h-6 w-6 text-primary" />
              <div>
                <CardTitle>Verification Status</CardTitle>
                <CardDescription>
                  Current state of your identity verification
                </CardDescription>
              </div>
            </div>
            {kycData && getStatusIcon(kycData.status)}
          </div>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center justify-between">
            <span className="font-medium">Status</span>
            {kycData ? getStatusBadge(kycData.status) : getStatusBadge('not_started')}
          </div>

          {kycData && (
            <>
              <div className="flex items-center justify-between">
                <span className="font-medium">Submitted</span>
                <span className="text-sm text-muted-foreground">
                  {new Date(kycData.created_at).toLocaleDateString()}
                </span>
              </div>
              
              <div className="flex items-center justify-between">
                <span className="font-medium">Last Updated</span>
                <span className="text-sm text-muted-foreground">
                  {new Date(kycData.updated_at).toLocaleDateString()}
                </span>
              </div>

              {kycData.files_json && Array.isArray(kycData.files_json) && kycData.files_json.length > 0 && (
                <div className="pt-4">
                  <h4 className="font-medium mb-2">Submitted Documents</h4>
                  <div className="space-y-2">
                    {kycData.files_json.map((file: any, index: number) => (
                      <div key={index} className="flex items-center gap-2 p-2 bg-muted/50 rounded">
                        <FileText className="h-4 w-4 text-muted-foreground" />
                        <span className="text-sm">{file.name || `Document ${index + 1}`}</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </>
          )}
        </CardContent>
      </Card>

      {/* Verification Requirements */}
      <Card>
        <CardHeader>
          <CardTitle>Verification Requirements</CardTitle>
          <CardDescription>
            To complete KYC verification, you'll need to provide:
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            <div className="flex items-center gap-3">
              <div className="w-2 h-2 bg-primary rounded-full"></div>
              <span>Government-issued photo ID (passport, driver's license, or ID card)</span>
            </div>
            <div className="flex items-center gap-3">
              <div className="w-2 h-2 bg-primary rounded-full"></div>
              <span>Proof of address (utility bill or bank statement, max 3 months old)</span>
            </div>
            <div className="flex items-center gap-3">
              <div className="w-2 h-2 bg-primary rounded-full"></div>
              <span>Live selfie verification</span>
            </div>
            <div className="flex items-center gap-3">
              <div className="w-2 h-2 bg-primary rounded-full"></div>
              <span>Complete business information form</span>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Start Verification */}
      <Card>
        <CardHeader>
          <CardTitle>Start Verification Process</CardTitle>
          <CardDescription>
            Complete the secure identity verification process powered by Veriff
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          {!isEligibleForVerification ? (
            <Alert>
              <AlertCircle className="h-4 w-4" />
              <AlertDescription>
                Your affiliate account must be active to start KYC verification.
              </AlertDescription>
            </Alert>
          ) : kycData?.status === 'approved' ? (
            <Alert>
              <CheckCircle className="h-4 w-4" />
              <AlertDescription>
                Your identity has been successfully verified! You can now request payouts.
              </AlertDescription>
            </Alert>
          ) : kycData?.status === 'pending' ? (
            <Alert>
              <Clock className="h-4 w-4" />
              <AlertDescription>
                Your verification is currently under review. This typically takes 1-2 business days.
                We'll notify you via email once the review is complete.
              </AlertDescription>
            </Alert>
          ) : (
            <div className="space-y-4">
              {kycData?.status === 'rejected' && (
                <Alert variant="destructive">
                  <XCircle className="h-4 w-4" />
                  <AlertDescription>
                    Your previous verification was rejected. Please ensure all documents are clear,
                    valid, and match your personal information before resubmitting.
                  </AlertDescription>
                </Alert>
              )}
              
              <Button 
                onClick={startVerification}
                disabled={verifying || !canStartVerification}
                className="w-full"
                size="lg"
              >
                {verifying ? (
                  <>
                    <RefreshCw className="h-4 w-4 mr-2 animate-spin" />
                    Starting Verification...
                  </>
                ) : (
                  <>
                    <Shield className="h-4 w-4 mr-2" />
                    {kycData?.status === 'rejected' ? 'Restart Verification' : 'Start Verification'}
                  </>
                )}
              </Button>

              <div className="text-xs text-muted-foreground text-center space-y-1">
                <p>• Verification is powered by Veriff, a trusted identity verification provider</p>
                <p>• The process typically takes 5-10 minutes to complete</p>
                <p>• Your data is encrypted and handled according to GDPR standards</p>
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Help & Support */}
      <Card>
        <CardHeader>
          <CardTitle>Need Help?</CardTitle>
          <CardDescription>
            Common questions about KYC verification
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4 text-sm">
            <div>
              <h4 className="font-medium mb-1">Why is KYC required?</h4>
              <p className="text-muted-foreground">
                KYC (Know Your Customer) verification is required by financial regulations to prevent
                fraud and money laundering. It helps us ensure secure and compliant payouts.
              </p>
            </div>
            <div>
              <h4 className="font-medium mb-1">How long does verification take?</h4>
              <p className="text-muted-foreground">
                The verification process typically takes 1-2 business days to review once submitted.
                You'll receive an email notification with the results.
              </p>
            </div>
            <div>
              <h4 className="font-medium mb-1">Is my data secure?</h4>
              <p className="text-muted-foreground">
                Yes, all verification is handled by Veriff, a certified identity verification provider.
                Your data is encrypted and processed according to strict security and privacy standards.
              </p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}