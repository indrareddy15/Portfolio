import { useEffect, useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  Download, 
  Copy,
  Eye,
  Code,
  Image as ImageIcon,
  FileText,
  Palette,
  ExternalLink
} from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { toast } from "@/hooks/use-toast";
import { generateReferralLink } from "@/utils/affiliateTracking";
import { Skeleton } from "@/components/ui/skeleton";

interface CreativeAsset {
  id: string;
  name: string;
  type: string;
  url: string;
  size_bytes?: number;
  tags: string[];
  created_at: string;
}

export default function AffiliateCreatives() {
  const { user } = useAuth();
  const [loading, setLoading] = useState(true);
  const [affiliate, setAffiliate] = useState<any>(null);
  const [assets, setAssets] = useState<CreativeAsset[]>([]);

  const fetchCreativeData = async () => {
    if (!user) return;

    try {
      setLoading(true);

      // Get affiliate profile
      const { data: affiliateData, error: affiliateError } = await supabase
        .from("affiliates")
        .select("*")
        .eq("user_id", user.id)
        .single();

      if (affiliateError) throw affiliateError;
      setAffiliate(affiliateData);

      // Get creative assets
      const { data: assetsData, error: assetsError } = await supabase
        .from("creative_assets")
        .select("*")
        .order("created_at", { ascending: false });

      if (assetsError) throw assetsError;
      setAssets(assetsData || []);

    } catch (error) {
      console.error('Error fetching creative data:', error);
      toast({
        title: "Error",
        description: "Failed to load creative assets",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchCreativeData();
  }, [user]);

  const copyToClipboard = (text: string, label: string) => {
    navigator.clipboard.writeText(text);
    toast({
      title: "Copied!",
      description: `${label} copied to clipboard`
    });
  };

  const downloadAsset = (url: string, name: string) => {
    const link = document.createElement('a');
    link.href = url;
    link.download = name;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    
    toast({
      title: "Downloaded",
      description: `${name} has been downloaded`
    });
  };

  const generateBannerCode = (size: string, affiliateCode: string) => {
    const referralLink = generateReferralLink(affiliateCode, window.location.origin, {
      utm_source: 'partner',
      utm_medium: 'banner',
      utm_campaign: 'affiliate'
    });

    return `<!-- PipTrackr.com ${size} Banner -->
<a href="${referralLink}" target="_blank" rel="noopener">
  <img src="${window.location.origin}/affiliate-banners/${size}.png" 
       alt="PipTrackr.com - Professional Trading Journal" 
       style="border: none; display: block; max-width: 100%;" />
</a>`;
  };

  const generateTextLinkCode = (affiliateCode: string, text: string = "Try PipTrackr.com") => {
    const referralLink = generateReferralLink(affiliateCode, window.location.origin, {
      utm_source: 'partner',
      utm_medium: 'text',
      utm_campaign: 'affiliate'
    });

    return `<a href="${referralLink}" target="_blank" rel="noopener" style="color: #008ffd; text-decoration: none; font-weight: 500;">${text}</a>`;
  };

  // Mock creative assets for demo
  const mockAssets: CreativeAsset[] = [
    {
      id: '1',
      name: 'PipTrackr.com Logo - Light',
      type: 'logo',
      url: '/api/placeholder/200/100',
      size_bytes: 15420,
      tags: ['logo', 'light', 'png'],
      created_at: new Date().toISOString()
    },
    {
      id: '2',
      name: 'PipTrackr.com Logo - Dark',
      type: 'logo',
      url: '/api/placeholder/200/100',
      size_bytes: 16250,
      tags: ['logo', 'dark', 'png'],
      created_at: new Date().toISOString()
    },
    {
      id: '3',
      name: 'Banner 728x90',
      type: 'banner',
      url: '/api/placeholder/728/90',
      size_bytes: 45200,
      tags: ['banner', 'leaderboard', 'png'],
      created_at: new Date().toISOString()
    },
    {
      id: '4',
      name: 'Banner 300x250',
      type: 'banner',
      url: '/api/placeholder/300/250',
      size_bytes: 38500,
      tags: ['banner', 'medium', 'png'],
      created_at: new Date().toISOString()
    },
    {
      id: '5',
      name: 'Product Screenshot - Dashboard',
      type: 'screenshot',
      url: '/api/placeholder/800/600',
      size_bytes: 125000,
      tags: ['screenshot', 'dashboard', 'jpg'],
      created_at: new Date().toISOString()
    }
  ];

  const displayAssets = assets.length > 0 ? assets : mockAssets;

  if (loading) {
    return (
      <div className="space-y-6">
        <div>
          <Skeleton className="h-8 w-48 mb-2" />
          <Skeleton className="h-4 w-64" />
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {[...Array(6)].map((_, i) => (
            <Card key={i}>
              <CardContent className="p-4">
                <Skeleton className="h-32 w-full mb-4" />
                <Skeleton className="h-4 w-24 mb-2" />
                <Skeleton className="h-6 w-32" />
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    );
  }

  if (!affiliate || affiliate.status !== 'active') {
    return (
      <div className="max-w-2xl mx-auto text-center py-12">
        <ImageIcon className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
        <h2 className="text-2xl font-semibold mb-2">Creatives Unavailable</h2>
        <p className="text-muted-foreground">
          Your affiliate account must be active to access marketing materials.
        </p>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-3xl font-bold">Marketing Creatives</h1>
        <p className="text-muted-foreground">
          Download banners, logos, and promotional materials for your campaigns
        </p>
      </div>

      <Tabs defaultValue="assets" className="space-y-6">
        <TabsList>
          <TabsTrigger value="assets">Assets</TabsTrigger>
          <TabsTrigger value="code">HTML Code</TabsTrigger>
          <TabsTrigger value="guidelines">Brand Guidelines</TabsTrigger>
        </TabsList>

        <TabsContent value="assets" className="space-y-6">
          {/* Asset Categories */}
          <div className="flex flex-wrap gap-2 mb-6">
            <Badge variant="secondary" className="cursor-pointer">All</Badge>
            <Badge variant="outline" className="cursor-pointer">Logos</Badge>
            <Badge variant="outline" className="cursor-pointer">Banners</Badge>
            <Badge variant="outline" className="cursor-pointer">Screenshots</Badge>
            <Badge variant="outline" className="cursor-pointer">Social Media</Badge>
          </div>

          {/* Assets Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {displayAssets.map((asset) => (
              <Card key={asset.id} className="overflow-hidden">
                <div className="aspect-video bg-muted flex items-center justify-center">
                  <img 
                    src={asset.url} 
                    alt={asset.name}
                    className="max-w-full max-h-full object-contain"
                  />
                </div>
                <CardContent className="p-4">
                  <div className="space-y-2">
                    <h3 className="font-semibold truncate">{asset.name}</h3>
                    <div className="flex flex-wrap gap-1">
                      {asset.tags.map(tag => (
                        <Badge key={tag} variant="outline" className="text-xs">
                          {tag}
                        </Badge>
                      ))}
                    </div>
                    {asset.size_bytes && (
                      <p className="text-xs text-muted-foreground">
                        {(asset.size_bytes / 1024).toFixed(1)} KB
                      </p>
                    )}
                    <div className="flex gap-2 pt-2">
                      <Button 
                        size="sm" 
                        variant="outline"
                        onClick={() => window.open(asset.url, '_blank')}
                      >
                        <Eye className="h-4 w-4 mr-1" />
                        Preview
                      </Button>
                      <Button 
                        size="sm"
                        onClick={() => downloadAsset(asset.url, asset.name)}
                      >
                        <Download className="h-4 w-4 mr-1" />
                        Download
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          {/* Asset Request */}
          <Card>
            <CardHeader>
              <CardTitle>Need Custom Assets?</CardTitle>
              <CardDescription>
                Can't find what you're looking for? Request custom marketing materials.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Button variant="outline">
                <ExternalLink className="h-4 w-4 mr-2" />
                Request Custom Assets
              </Button>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="code" className="space-y-6">
          {/* HTML Banner Codes */}
          <Card>
            <CardHeader>
              <CardTitle>Banner HTML Code</CardTitle>
              <CardDescription>
                Copy and paste these HTML snippets with your affiliate link
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              {/* Leaderboard Banner */}
              <div className="space-y-2">
                <h4 className="font-semibold">Leaderboard Banner (728x90)</h4>
                <div className="bg-muted p-4 rounded-lg">
                  <code className="text-sm">
                    {generateBannerCode('728x90', affiliate.code)}
                  </code>
                </div>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => copyToClipboard(generateBannerCode('728x90', affiliate.code), 'Leaderboard banner code')}
                >
                  <Copy className="h-4 w-4 mr-2" />
                  Copy Code
                </Button>
              </div>

              {/* Medium Rectangle Banner */}
              <div className="space-y-2">
                <h4 className="font-semibold">Medium Rectangle (300x250)</h4>
                <div className="bg-muted p-4 rounded-lg">
                  <code className="text-sm">
                    {generateBannerCode('300x250', affiliate.code)}
                  </code>
                </div>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => copyToClipboard(generateBannerCode('300x250', affiliate.code), 'Medium rectangle banner code')}
                >
                  <Copy className="h-4 w-4 mr-2" />
                  Copy Code
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* Text Links */}
          <Card>
            <CardHeader>
              <CardTitle>Text Link HTML Code</CardTitle>
              <CardDescription>
                Customizable text links with your affiliate tracking
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <label className="text-sm font-medium">Link Text</label>
                <Input 
                  placeholder="Try PipTrackr.com"
                  onChange={(e) => {
                    // Update preview in real-time
                  }}
                />
              </div>
              <div className="space-y-2">
                <h4 className="font-semibold">Generated HTML</h4>
                <div className="bg-muted p-4 rounded-lg">
                  <code className="text-sm">
                    {generateTextLinkCode(affiliate.code)}
                  </code>
                </div>
                <div className="flex gap-2">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => copyToClipboard(generateTextLinkCode(affiliate.code), 'Text link code')}
                  >
                    <Copy className="h-4 w-4 mr-2" />
                    Copy Code
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => window.open(generateReferralLink(affiliate.code, window.location.origin), '_blank')}
                  >
                    <Eye className="h-4 w-4 mr-2" />
                    Preview Link
                  </Button>
                </div>
              </div>
              <div className="space-y-2">
                <h4 className="font-semibold">Preview</h4>
                <div className="p-4 border rounded-lg bg-background">
                  <a 
                    href={generateReferralLink(affiliate.code, window.location.origin)}
                    target="_blank"
                    rel="noopener"
                    className="text-primary hover:underline font-medium"
                  >
                    Try PipTrackr.com
                  </a>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Social Media Links */}
          <Card>
            <CardHeader>
              <CardTitle>Social Media Posts</CardTitle>
              <CardDescription>
                Pre-written social media content with your affiliate link
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <h4 className="font-semibold">Twitter/X Post</h4>
                <div className="bg-muted p-4 rounded-lg">
                  <p className="text-sm">
                    🚀 Level up your trading with PipTrackr.com! 📊<br/>
                    Advanced analytics, psychology tracking, and prop firm challenges all in one platform.<br/>
                    {generateReferralLink(affiliate.code, window.location.origin)}<br/>
                    #TradingJournal #Forex #TradingAnalytics
                  </p>
                </div>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => copyToClipboard(
                    `🚀 Level up your trading with PipTrackr.com! 📊\nAdvanced analytics, psychology tracking, and prop firm challenges all in one platform.\n${generateReferralLink(affiliate.code, window.location.origin)}\n#TradingJournal #Forex #TradingAnalytics`,
                    'Twitter post'
                  )}
                >
                  <Copy className="h-4 w-4 mr-2" />
                  Copy Post
                </Button>
              </div>

              <div className="space-y-2">
                <h4 className="font-semibold">LinkedIn Post</h4>
                <div className="bg-muted p-4 rounded-lg">
                  <p className="text-sm">
                    After trying multiple trading journals, I finally found the perfect solution: PipTrackr.com.<br/><br/>
                    
                    What sets it apart:<br/>
                    ✅ Advanced analytics with 20+ metrics<br/>
                    ✅ Psychology tracking and mood analysis<br/>
                    ✅ Prop firm challenge integration<br/>
                    ✅ AI-powered trade insights<br/><br/>
                    
                    If you're serious about improving your trading performance, give it a try:<br/>
                    {generateReferralLink(affiliate.code, window.location.origin)}
                  </p>
                </div>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => copyToClipboard(
                    `After trying multiple trading journals, I finally found the perfect solution: PipTrackr.com.\n\nWhat sets it apart:\n✅ Advanced analytics with 20+ metrics\n✅ Psychology tracking and mood analysis\n✅ Prop firm challenge integration\n✅ AI-powered trade insights\n\nIf you're serious about improving your trading performance, give it a try:\n${generateReferralLink(affiliate.code, window.location.origin)}`,
                    'LinkedIn post'
                  )}
                >
                  <Copy className="h-4 w-4 mr-2" />
                  Copy Post
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="guidelines" className="space-y-6">
          {/* Brand Guidelines */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Palette className="h-5 w-5" />
                Brand Guidelines
              </CardTitle>
              <CardDescription>
                Follow these guidelines when promoting PipTrackr.com
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              {/* Brand Colors */}
              <div className="space-y-3">
                <h4 className="font-semibold">Brand Colors</h4>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  <div className="space-y-2">
                    <div className="w-full h-16 bg-[#008ffd] rounded-lg"></div>
                    <div className="text-center">
                      <div className="font-medium">Primary Blue</div>
                      <div className="text-xs text-muted-foreground">#008ffd</div>
                    </div>
                  </div>
                  <div className="space-y-2">
                    <div className="w-full h-16 bg-[#00d4aa] rounded-lg"></div>
                    <div className="text-center">
                      <div className="font-medium">Success Green</div>
                      <div className="text-xs text-muted-foreground">#00d4aa</div>
                    </div>
                  </div>
                  <div className="space-y-2">
                    <div className="w-full h-16 bg-[#8b5cf6] rounded-lg"></div>
                    <div className="text-center">
                      <div className="font-medium">Accent Purple</div>
                      <div className="text-xs text-muted-foreground">#8b5cf6</div>
                    </div>
                  </div>
                  <div className="space-y-2">
                    <div className="w-full h-16 bg-gradient-to-r from-[#008ffd] to-[#8b5cf6] rounded-lg"></div>
                    <div className="text-center">
                      <div className="font-medium">Primary Gradient</div>
                      <div className="text-xs text-muted-foreground">Brand gradient</div>
                    </div>
                  </div>
                </div>
              </div>

              {/* Logo Usage */}
              <div className="space-y-3">
                <h4 className="font-semibold">Logo Usage</h4>
                <div className="space-y-2 text-sm">
                  <div className="flex items-start gap-2">
                    <div className="w-2 h-2 bg-green-500 rounded-full mt-2"></div>
                    <span>Use the logo on clean, uncluttered backgrounds</span>
                  </div>
                  <div className="flex items-start gap-2">
                    <div className="w-2 h-2 bg-green-500 rounded-full mt-2"></div>
                    <span>Maintain adequate clear space around the logo</span>
                  </div>
                  <div className="flex items-start gap-2">
                    <div className="w-2 h-2 bg-green-500 rounded-full mt-2"></div>
                    <span>Use high-resolution versions for print materials</span>
                  </div>
                  <div className="flex items-start gap-2">
                    <div className="w-2 h-2 bg-red-500 rounded-full mt-2"></div>
                    <span>Don't distort, rotate, or modify the logo</span>
                  </div>
                  <div className="flex items-start gap-2">
                    <div className="w-2 h-2 bg-red-500 rounded-full mt-2"></div>
                    <span>Don't use the logo on busy or low-contrast backgrounds</span>
                  </div>
                </div>
              </div>

              {/* Messaging Guidelines */}
              <div className="space-y-3">
                <h4 className="font-semibold">Messaging Guidelines</h4>
                <div className="space-y-4">
                  <div>
                    <h5 className="font-medium text-green-600 mb-2">✅ Do:</h5>
                    <ul className="text-sm space-y-1 ml-4">
                      <li>• Focus on the benefits for traders</li>
                      <li>• Mention specific features like analytics and prop firm integration</li>
                      <li>• Use authentic, personal testimonials</li>
                      <li>• Highlight the professional and advanced nature of the tool</li>
                      <li>• Include proper disclosures about affiliate relationships</li>
                    </ul>
                  </div>
                  <div>
                    <h5 className="font-medium text-red-600 mb-2">❌ Don't:</h5>
                    <ul className="text-sm space-y-1 ml-4">
                      <li>• Make unrealistic profit claims or guarantees</li>
                      <li>• Use aggressive or misleading sales tactics</li>
                      <li>• Bid on branded keywords in paid ads</li>
                      <li>• Create fake reviews or testimonials</li>
                      <li>• Spam social media or forums</li>
                    </ul>
                  </div>
                </div>
              </div>

              {/* Compliance */}
              <div className="space-y-3">
                <h4 className="font-semibold">Compliance & Legal</h4>
                <div className="bg-amber-50 border border-amber-200 rounded-lg p-4">
                  <p className="text-sm">
                    <strong>Important:</strong> All affiliate marketing must comply with FTC guidelines. 
                    You must clearly disclose your affiliate relationship when promoting PipTrackr.com. 
                    Use phrases like "I earn a commission if you purchase through my link" or 
                    "#affiliate" in social media posts.
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}