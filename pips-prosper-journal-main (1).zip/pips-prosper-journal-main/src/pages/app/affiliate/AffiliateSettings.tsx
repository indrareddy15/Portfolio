import { useEffect, useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { 
  User, 
  CreditCard,
  FileText,
  Shield,
  Bell,
  Save,
  Upload,
  CheckCircle,
  AlertCircle,
  Edit
} from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { toast } from "@/hooks/use-toast";
import { Skeleton } from "@/components/ui/skeleton";

interface AffiliateProfile {
  id: string;
  code: string;
  status: string;
  default_rate_pct: number;
  created_at: string;
  display_name?: string;
  bio?: string;
  website?: string;
  social_links?: any;
  payout_method?: string;
  payout_details?: any;
  tax_info?: any;
  kyc_status?: string;
  email_notifications?: boolean;
  marketing_emails?: boolean;
}

export default function AffiliateSettings() {
  const { user } = useAuth();
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [affiliate, setAffiliate] = useState<AffiliateProfile | null>(null);
  const [formData, setFormData] = useState({
    display_name: '',
    bio: '',
    website: '',
    twitter: '',
    youtube: '',
    linkedin: '',
    instagram: '',
    bank_name: '',
    account_holder: '',
    account_number: '',
    routing_number: '',
    paypal_email: '',
    crypto_address: '',
    crypto_type: 'BTC',
    tax_id: '',
    business_name: '',
    address_line1: '',
    address_line2: '',
    city: '',
    state: '',
    zip_code: '',
    country: 'US',
    email_notifications: true,
    marketing_emails: true
  });

  const fetchAffiliateSettings = async () => {
    if (!user) return;

    try {
      setLoading(true);

      const { data: affiliateData, error } = await supabase
        .from("affiliates")
        .select("*")
        .eq("user_id", user.id)
        .single();

      if (error) throw error;

      setAffiliate(affiliateData);

      // Populate form data
      if (affiliateData) {
        setFormData(prev => ({
          ...prev,
          display_name: (affiliateData as any).display_name || '',
          bio: (affiliateData as any).bio || '',
          website: (affiliateData as any).website || '',
          ...((affiliateData as any).social_links || {}),
          ...((affiliateData as any).payout_details || {}),
          ...((affiliateData as any).tax_info || {}),
          email_notifications: (affiliateData as any).email_notifications ?? true,
          marketing_emails: (affiliateData as any).marketing_emails ?? true
        }));
      }

    } catch (error) {
      console.error('Error fetching affiliate settings:', error);
      toast({
        title: "Error",
        description: "Failed to load affiliate settings",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const saveSettings = async (section: string) => {
    if (!affiliate) return;

    try {
      setSaving(true);

      let updateData: any = {};

      switch (section) {
        case 'profile':
          updateData = {
            display_name: formData.display_name,
            bio: formData.bio,
            website: formData.website,
            social_links: {
              twitter: formData.twitter,
              youtube: formData.youtube,
              linkedin: formData.linkedin,
              instagram: formData.instagram
            }
          };
          break;

        case 'payout':
          updateData = {
            payout_method: formData.paypal_email ? 'paypal' : 'bank',
            payout_details: {
              bank_name: formData.bank_name,
              account_holder: formData.account_holder,
              account_number: formData.account_number,
              routing_number: formData.routing_number,
              paypal_email: formData.paypal_email,
              crypto_address: formData.crypto_address,
              crypto_type: formData.crypto_type
            }
          };
          break;

        case 'tax':
          updateData = {
            tax_info: {
              tax_id: formData.tax_id,
              business_name: formData.business_name,
              address_line1: formData.address_line1,
              address_line2: formData.address_line2,
              city: formData.city,
              state: formData.state,
              zip_code: formData.zip_code,
              country: formData.country
            }
          };
          break;

        case 'notifications':
          updateData = {
            email_notifications: formData.email_notifications,
            marketing_emails: formData.marketing_emails
          };
          break;
      }

      const { error } = await supabase
        .from("affiliates")
        .update(updateData)
        .eq("id", affiliate.id);

      if (error) throw error;

      toast({
        title: "Saved",
        description: "Settings have been updated successfully"
      });

      // Refresh data
      await fetchAffiliateSettings();

    } catch (error) {
      console.error('Error saving settings:', error);
      toast({
        title: "Error",
        description: "Failed to save settings",
        variant: "destructive"
      });
    } finally {
      setSaving(false);
    }
  };

  const requestCodeChange = async () => {
    toast({
      title: "Code Change Request",
      description: "Your request has been submitted. Admin will review and contact you within 24 hours."
    });
  };

  useEffect(() => {
    fetchAffiliateSettings();
  }, [user]);

  if (loading) {
    return (
      <div className="space-y-6">
        <div>
          <Skeleton className="h-8 w-48 mb-2" />
          <Skeleton className="h-4 w-64" />
        </div>
        
        <div className="space-y-4">
          {[...Array(3)].map((_, i) => (
            <Card key={i}>
              <CardHeader>
                <Skeleton className="h-6 w-32 mb-2" />
                <Skeleton className="h-4 w-48" />
              </CardHeader>
              <CardContent>
                <Skeleton className="h-32 w-full" />
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    );
  }

  if (!affiliate) {
    return (
      <div className="max-w-2xl mx-auto text-center py-12">
        <User className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
        <h2 className="text-2xl font-semibold mb-2">Settings Unavailable</h2>
        <p className="text-muted-foreground">
          You need an affiliate account to access settings.
        </p>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-3xl font-bold">Affiliate Settings</h1>
        <p className="text-muted-foreground">
          Manage your affiliate profile, payout methods, and preferences
        </p>
      </div>

      {/* Account Status */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Shield className="h-5 w-5" />
            Account Status
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex items-center justify-between">
            <div className="space-y-1">
              <div className="flex items-center gap-2">
                <Badge 
                  variant={affiliate.status === 'active' ? 'default' : 'secondary'}
                  className="capitalize"
                >
                  {affiliate.status}
                </Badge>
                <span className="text-sm text-muted-foreground">
                  Commission Rate: {affiliate.default_rate_pct}%
                </span>
              </div>
              <p className="text-sm text-muted-foreground">
                Affiliate since {new Date(affiliate.created_at).toLocaleDateString()}
              </p>
            </div>
            <div className="text-right">
              <div className="font-mono text-lg font-semibold">{affiliate.code}</div>
              <Button variant="outline" size="sm" onClick={requestCodeChange}>
                <Edit className="h-4 w-4 mr-2" />
                Request Code Change
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      <Tabs defaultValue="profile" className="space-y-6">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="profile">Profile</TabsTrigger>
          <TabsTrigger value="payout">Payout</TabsTrigger>
          <TabsTrigger value="tax">Tax & KYC</TabsTrigger>
          <TabsTrigger value="notifications">Notifications</TabsTrigger>
        </TabsList>

        <TabsContent value="profile" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <User className="h-5 w-5" />
                Public Profile
              </CardTitle>
              <CardDescription>
                This information may be displayed publicly on affiliate leaderboards
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="display_name">Display Name</Label>
                <Input
                  id="display_name"
                  value={formData.display_name}
                  onChange={(e) => setFormData(prev => ({ ...prev, display_name: e.target.value }))}
                  placeholder="Your public display name"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="bio">Bio</Label>
                <Textarea
                  id="bio"
                  value={formData.bio}
                  onChange={(e) => setFormData(prev => ({ ...prev, bio: e.target.value }))}
                  placeholder="Tell us about yourself and your trading experience..."
                  rows={3}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="website">Website</Label>
                <Input
                  id="website"
                  type="url"
                  value={formData.website}
                  onChange={(e) => setFormData(prev => ({ ...prev, website: e.target.value }))}
                  placeholder="https://your-website.com"
                />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="twitter">Twitter/X</Label>
                  <Input
                    id="twitter"
                    value={formData.twitter}
                    onChange={(e) => setFormData(prev => ({ ...prev, twitter: e.target.value }))}
                    placeholder="@username"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="youtube">YouTube</Label>
                  <Input
                    id="youtube"
                    value={formData.youtube}
                    onChange={(e) => setFormData(prev => ({ ...prev, youtube: e.target.value }))}
                    placeholder="Channel URL or @handle"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="linkedin">LinkedIn</Label>
                  <Input
                    id="linkedin"
                    value={formData.linkedin}
                    onChange={(e) => setFormData(prev => ({ ...prev, linkedin: e.target.value }))}
                    placeholder="Profile URL or username"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="instagram">Instagram</Label>
                  <Input
                    id="instagram"
                    value={formData.instagram}
                    onChange={(e) => setFormData(prev => ({ ...prev, instagram: e.target.value }))}
                    placeholder="@username"
                  />
                </div>
              </div>

              <Button onClick={() => saveSettings('profile')} disabled={saving}>
                <Save className="h-4 w-4 mr-2" />
                Save Profile
              </Button>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="payout" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <CreditCard className="h-5 w-5" />
                Payout Methods
              </CardTitle>
              <CardDescription>
                Configure how you'd like to receive your affiliate earnings
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              {/* Bank Transfer */}
              <div className="space-y-4">
                <h4 className="font-semibold">Bank Transfer (ACH)</h4>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="bank_name">Bank Name</Label>
                    <Input
                      id="bank_name"
                      value={formData.bank_name}
                      onChange={(e) => setFormData(prev => ({ ...prev, bank_name: e.target.value }))}
                      placeholder="Chase Bank"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="account_holder">Account Holder Name</Label>
                    <Input
                      id="account_holder"
                      value={formData.account_holder}
                      onChange={(e) => setFormData(prev => ({ ...prev, account_holder: e.target.value }))}
                      placeholder="John Doe"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="account_number">Account Number</Label>
                    <Input
                      id="account_number"
                      value={formData.account_number}
                      onChange={(e) => setFormData(prev => ({ ...prev, account_number: e.target.value }))}
                      placeholder="••••••••••••"
                      type="password"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="routing_number">Routing Number</Label>
                    <Input
                      id="routing_number"
                      value={formData.routing_number}
                      onChange={(e) => setFormData(prev => ({ ...prev, routing_number: e.target.value }))}
                      placeholder="021000021"
                    />
                  </div>
                </div>
              </div>

              {/* PayPal */}
              <div className="space-y-4 opacity-50">
                <h4 className="font-semibold">
                  PayPal 
                  <Badge variant="outline" className="ml-2">Coming Soon</Badge>
                </h4>
                <div className="space-y-2">
                  <Label htmlFor="paypal_email">PayPal Email</Label>
                  <Input
                    id="paypal_email"
                    type="email"
                    value={formData.paypal_email}
                    onChange={(e) => setFormData(prev => ({ ...prev, paypal_email: e.target.value }))}
                    placeholder="your-email@paypal.com"
                    disabled
                  />
                </div>
              </div>

              {/* Cryptocurrency */}
              <div className="space-y-4 opacity-50">
                <h4 className="font-semibold">
                  Cryptocurrency 
                  <Badge variant="outline" className="ml-2">Coming Soon</Badge>
                </h4>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="crypto_type">Cryptocurrency</Label>
                    <Select value={formData.crypto_type} disabled>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="BTC">Bitcoin (BTC)</SelectItem>
                        <SelectItem value="ETH">Ethereum (ETH)</SelectItem>
                        <SelectItem value="USDC">USD Coin (USDC)</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="crypto_address">Wallet Address</Label>
                    <Input
                      id="crypto_address"
                      value={formData.crypto_address}
                      onChange={(e) => setFormData(prev => ({ ...prev, crypto_address: e.target.value }))}
                      placeholder="1A1zP1eP5QGefi2DMPTfTL5SLmv7DivfNa"
                      disabled
                    />
                  </div>
                </div>
              </div>

              <Button onClick={() => saveSettings('payout')} disabled={saving}>
                <Save className="h-4 w-4 mr-2" />
                Save Payout Details
              </Button>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="tax" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <FileText className="h-5 w-5" />
                Tax Information & KYC
              </CardTitle>
              <CardDescription>
                Required for tax reporting and identity verification
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <Alert>
                <Shield className="h-4 w-4" />
                <AlertDescription>
                  This information is securely encrypted and only used for tax reporting and compliance purposes.
                </AlertDescription>
              </Alert>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="tax_id">Tax ID / SSN</Label>
                  <Input
                    id="tax_id"
                    value={formData.tax_id}
                    onChange={(e) => setFormData(prev => ({ ...prev, tax_id: e.target.value }))}
                    placeholder="XXX-XX-XXXX"
                    type="password"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="business_name">Business Name (Optional)</Label>
                  <Input
                    id="business_name"
                    value={formData.business_name}
                    onChange={(e) => setFormData(prev => ({ ...prev, business_name: e.target.value }))}
                    placeholder="Your LLC or Business Name"
                  />
                </div>
              </div>

              <div className="space-y-4">
                <h4 className="font-semibold">Address Information</h4>
                <div className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="address_line1">Address Line 1</Label>
                    <Input
                      id="address_line1"
                      value={formData.address_line1}
                      onChange={(e) => setFormData(prev => ({ ...prev, address_line1: e.target.value }))}
                      placeholder="123 Main St"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="address_line2">Address Line 2 (Optional)</Label>
                    <Input
                      id="address_line2"
                      value={formData.address_line2}
                      onChange={(e) => setFormData(prev => ({ ...prev, address_line2: e.target.value }))}
                      placeholder="Apt 4B"
                    />
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="city">City</Label>
                      <Input
                        id="city"
                        value={formData.city}
                        onChange={(e) => setFormData(prev => ({ ...prev, city: e.target.value }))}
                        placeholder="New York"
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="state">State</Label>
                      <Input
                        id="state"
                        value={formData.state}
                        onChange={(e) => setFormData(prev => ({ ...prev, state: e.target.value }))}
                        placeholder="NY"
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="zip_code">ZIP Code</Label>
                      <Input
                        id="zip_code"
                        value={formData.zip_code}
                        onChange={(e) => setFormData(prev => ({ ...prev, zip_code: e.target.value }))}
                        placeholder="10001"
                      />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="country">Country</Label>
                    <Select value={formData.country} onValueChange={(value) => setFormData(prev => ({ ...prev, country: value }))}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="US">United States</SelectItem>
                        <SelectItem value="CA">Canada</SelectItem>
                        <SelectItem value="GB">United Kingdom</SelectItem>
                        <SelectItem value="AU">Australia</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              </div>

              <div className="space-y-4">
                <h4 className="font-semibold">Document Upload</h4>
                <div className="border-2 border-dashed border-muted rounded-lg p-6 text-center">
                  <Upload className="h-8 w-8 text-muted-foreground mx-auto mb-2" />
                  <p className="text-sm text-muted-foreground mb-2">
                    Upload ID verification documents (Driver's License, Passport, etc.)
                  </p>
                  <Button variant="outline" size="sm">
                    <Upload className="h-4 w-4 mr-2" />
                    Choose Files
                  </Button>
                </div>
              </div>

              <Button onClick={() => saveSettings('tax')} disabled={saving}>
                <Save className="h-4 w-4 mr-2" />
                Save Tax Information
              </Button>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="notifications" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Bell className="h-5 w-5" />
                Email Notifications
              </CardTitle>
              <CardDescription>
                Control which emails you receive from the affiliate program
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <h4 className="font-medium">Commission Notifications</h4>
                    <p className="text-sm text-muted-foreground">
                      Get notified when you earn new commissions
                    </p>
                  </div>
                  <Switch
                    checked={formData.email_notifications}
                    onCheckedChange={(checked) => setFormData(prev => ({ ...prev, email_notifications: checked }))}
                  />
                </div>

                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <h4 className="font-medium">Payout Updates</h4>
                    <p className="text-sm text-muted-foreground">
                      Get notified about payout status changes
                    </p>
                  </div>
                  <Switch
                    checked={formData.email_notifications}
                    onCheckedChange={(checked) => setFormData(prev => ({ ...prev, email_notifications: checked }))}
                  />
                </div>

                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <h4 className="font-medium">Marketing Tips</h4>
                    <p className="text-sm text-muted-foreground">
                      Receive marketing tips and best practices
                    </p>
                  </div>
                  <Switch
                    checked={formData.marketing_emails}
                    onCheckedChange={(checked) => setFormData(prev => ({ ...prev, marketing_emails: checked }))}
                  />
                </div>

                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <h4 className="font-medium">Product Updates</h4>
                    <p className="text-sm text-muted-foreground">
                      Learn about new features you can promote
                    </p>
                  </div>
                  <Switch
                    checked={formData.marketing_emails}
                    onCheckedChange={(checked) => setFormData(prev => ({ ...prev, marketing_emails: checked }))}
                  />
                </div>

                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <h4 className="font-medium">Monthly Reports</h4>
                    <p className="text-sm text-muted-foreground">
                      Monthly summary of your affiliate performance
                    </p>
                  </div>
                  <Switch
                    checked={formData.marketing_emails}
                    onCheckedChange={(checked) => setFormData(prev => ({ ...prev, marketing_emails: checked }))}
                  />
                </div>
              </div>

              <Button onClick={() => saveSettings('notifications')} disabled={saving}>
                <Save className="h-4 w-4 mr-2" />
                Save Notification Preferences
              </Button>
            </CardContent>
          </Card>

          {/* Data & Privacy */}
          <Card>
            <CardHeader>
              <CardTitle>Data & Privacy</CardTitle>
              <CardDescription>
                Manage your affiliate account data and privacy settings
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-4">
                <Button variant="outline" className="w-full justify-start">
                  <FileText className="h-4 w-4 mr-2" />
                  Download My Affiliate Data
                </Button>

                <Button variant="outline" className="w-full justify-start">
                  <FileText className="h-4 w-4 mr-2" />
                  View Privacy Policy
                </Button>

                <Alert>
                  <AlertCircle className="h-4 w-4" />
                  <AlertDescription>
                    Need to close your affiliate account? Contact support at affiliate@piptrackr.com. 
                    All pending commissions will be paid out according to our terms.
                  </AlertDescription>
                </Alert>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}