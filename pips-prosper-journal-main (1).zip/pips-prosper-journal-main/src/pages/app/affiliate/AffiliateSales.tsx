import { useEffect, useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { 
  Download, 
  Filter,
  Search,
  ExternalLink,
  Calendar,
  DollarSign,
  TrendingUp,
  Users,
  RefreshCw
} from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { Skeleton } from "@/components/ui/skeleton";
import { toast } from "@/hooks/use-toast";

interface SaleRecord {
  id: string;
  customer_masked: string;
  customer_user_id: string;
  stripe_invoice_id: string;
  plan: string;
  subscription_amount: number;
  commission_amount: number;
  commission_rate: number;
  status: string;
  created_at: string;
  hold_until?: string;
  notes?: string;
  utm_source?: string;
  utm_medium?: string;
  utm_campaign?: string;
}

interface SalesStats {
  totalSales: number;
  totalCommissions: number;
  avgOrderValue: number;
  conversionRate: number;
  topPlan: string;
  topSource: string;
}

export default function AffiliateSales() {
  const { user } = useAuth();
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [affiliate, setAffiliate] = useState<any>(null);
  const [sales, setSales] = useState<SaleRecord[]>([]);
  const [filteredSales, setFilteredSales] = useState<SaleRecord[]>([]);
  const [stats, setStats] = useState<SalesStats | null>(null);
  
  // Filters
  const [searchTerm, setSearchTerm] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const [planFilter, setPlanFilter] = useState("all");
  const [dateFilter, setDateFilter] = useState("all");

  const fetchSalesData = async () => {
    if (!user) return;

    try {
      setLoading(true);

      // Get affiliate profile
      const { data: affiliateData, error: affiliateError } = await supabase
        .from("affiliates")
        .select("*")
        .eq("user_id", user.id)
        .single();

      if (affiliateError) throw affiliateError;
      setAffiliate(affiliateData);

      if (affiliateData.status !== 'active') {
        setLoading(false);
        return;
      }

      // Get commissions (sales)
      const { data: commissionsData, error: commissionsError } = await supabase
        .from("commissions")
        .select("*")
        .eq("affiliate_id", affiliateData.id)
        .order("created_at", { ascending: false });

      if (commissionsError) throw commissionsError;

      // Get clicks for UTM data
      const { data: clicksData } = await supabase
        .from("affiliate_clicks")
        .select("*")
        .eq("affiliate_id", affiliateData.id);

      // Transform data for display
      const salesRecords: SaleRecord[] = commissionsData?.map(commission => {
        const originalAmount = commission.type === 'rev_share' 
          ? parseFloat(commission.amount.toString()) / (parseFloat(commission.rate_pct.toString()) / 100)
          : 0;

        // Try to find matching click for UTM data (simplified)
        const relatedClick = clicksData?.find(click => 
          Math.abs(new Date(click.created_at).getTime() - new Date(commission.created_at).getTime()) < 24 * 60 * 60 * 1000
        );

        return {
          id: commission.id,
          customer_masked: `***${commission.customer_user_id.slice(-4)}`,
          customer_user_id: commission.customer_user_id,
          stripe_invoice_id: commission.stripe_invoice_id || '',
          plan: commission.notes?.includes('Premium') ? 'Premium' : 
                commission.notes?.includes('Pro') ? 'Pro' : 
                commission.notes?.includes('Enterprise') ? 'Enterprise' : 'Basic',
          subscription_amount: originalAmount,
          commission_amount: parseFloat(commission.amount.toString()),
          commission_rate: parseFloat(commission.rate_pct.toString()),
          status: commission.status,
          created_at: commission.created_at,
          hold_until: commission.hold_until,
          notes: commission.notes,
          utm_source: (relatedClick?.utm_json as any)?.utm_source,
          utm_medium: (relatedClick?.utm_json as any)?.utm_medium,
          utm_campaign: (relatedClick?.utm_json as any)?.utm_campaign,
        };
      }) || [];

      setSales(salesRecords);
      setFilteredSales(salesRecords);

      // Calculate stats
      const revShareSales = salesRecords.filter(s => s.commission_amount > 0);
      const totalSales = revShareSales.length;
      const totalCommissions = revShareSales.reduce((sum, s) => sum + s.commission_amount, 0);
      const avgOrderValue = totalSales > 0 ? revShareSales.reduce((sum, s) => sum + s.subscription_amount, 0) / totalSales : 0;
      
      // Get total clicks for conversion rate
      const totalClicks = clicksData?.length || 0;
      const conversionRate = totalClicks > 0 ? (totalSales / totalClicks) * 100 : 0;
      
      // Find top plan and source
      const planCounts = revShareSales.reduce((acc, s) => {
        acc[s.plan] = (acc[s.plan] || 0) + 1;
        return acc;
      }, {} as Record<string, number>);
      
      const sourceCounts = revShareSales.reduce((acc, s) => {
        const source = s.utm_source || 'Direct';
        acc[source] = (acc[source] || 0) + 1;
        return acc;
      }, {} as Record<string, number>);

      const topPlan = Object.keys(planCounts).reduce((a, b) => planCounts[a] > planCounts[b] ? a : b, 'N/A');
      const topSource = Object.keys(sourceCounts).reduce((a, b) => sourceCounts[a] > sourceCounts[b] ? a : b, 'N/A');

      setStats({
        totalSales,
        totalCommissions,
        avgOrderValue,
        conversionRate,
        topPlan,
        topSource
      });

    } catch (error) {
      console.error('Error fetching sales data:', error);
      toast({
        title: "Error",
        description: "Failed to load sales data",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const handleRefresh = async () => {
    setRefreshing(true);
    await fetchSalesData();
    setRefreshing(false);
    toast({
      title: "Refreshed",
      description: "Sales data has been updated"
    });
  };

  const applyFilters = () => {
    let filtered = [...sales];

    // Search filter
    if (searchTerm) {
      filtered = filtered.filter(sale => 
        sale.customer_masked.toLowerCase().includes(searchTerm.toLowerCase()) ||
        sale.plan.toLowerCase().includes(searchTerm.toLowerCase()) ||
        sale.stripe_invoice_id.toLowerCase().includes(searchTerm.toLowerCase()) ||
        (sale.utm_campaign && sale.utm_campaign.toLowerCase().includes(searchTerm.toLowerCase()))
      );
    }

    // Status filter
    if (statusFilter !== 'all') {
      filtered = filtered.filter(sale => sale.status === statusFilter);
    }

    // Plan filter
    if (planFilter !== 'all') {
      filtered = filtered.filter(sale => sale.plan === planFilter);
    }

    // Date filter
    if (dateFilter !== 'all') {
      const now = new Date();
      const filterDate = new Date();
      
      switch (dateFilter) {
        case '7d':
          filterDate.setDate(now.getDate() - 7);
          break;
        case '30d':
          filterDate.setDate(now.getDate() - 30);
          break;
        case '90d':
          filterDate.setDate(now.getDate() - 90);
          break;
      }
      
      if (dateFilter !== 'all') {
        filtered = filtered.filter(sale => new Date(sale.created_at) >= filterDate);
      }
    }

    setFilteredSales(filtered);
  };

  useEffect(() => {
    applyFilters();
  }, [searchTerm, statusFilter, planFilter, dateFilter, sales]);

  useEffect(() => {
    fetchSalesData();
  }, [user]);

  const exportToCSV = () => {
    const headers = [
      'Date',
      'Customer',
      'Plan',
      'Amount',
      'Commission',
      'Rate %',
      'Status',
      'Source',
      'Campaign',
      'Invoice ID'
    ].join(',');

    const rows = filteredSales.map(sale => [
      new Date(sale.created_at).toLocaleDateString(),
      sale.customer_masked,
      sale.plan,
      sale.subscription_amount.toFixed(2),
      sale.commission_amount.toFixed(2),
      sale.commission_rate.toFixed(1),
      sale.status,
      sale.utm_source || 'Direct',
      sale.utm_campaign || '',
      sale.stripe_invoice_id
    ].join(','));

    const csv = [headers, ...rows].join('\n');
    const blob = new Blob([csv], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `affiliate-sales-${new Date().toISOString().split('T')[0]}.csv`;
    a.click();
    URL.revokeObjectURL(url);

    toast({
      title: "Exported",
      description: "Sales data exported to CSV"
    });
  };

  if (loading) {
    return (
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <Skeleton className="h-8 w-32 mb-2" />
            <Skeleton className="h-4 w-48" />
          </div>
          <Skeleton className="h-10 w-24" />
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
          {[...Array(4)].map((_, i) => (
            <Card key={i}>
              <CardHeader className="pb-2">
                <Skeleton className="h-4 w-20 mb-2" />
                <Skeleton className="h-8 w-16" />
              </CardHeader>
            </Card>
          ))}
        </div>
      </div>
    );
  }

  if (!affiliate || affiliate.status !== 'active') {
    return (
      <div className="max-w-2xl mx-auto text-center py-12">
        <Users className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
        <h2 className="text-2xl font-semibold mb-2">Sales Tracking Unavailable</h2>
        <p className="text-muted-foreground">
          Your affiliate account must be active to view sales data.
        </p>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Sales & Conversions</h1>
          <p className="text-muted-foreground">
            Track all your successful referrals and commissions
          </p>
        </div>
        <div className="flex gap-2">
          <Button 
            onClick={handleRefresh} 
            disabled={refreshing}
            variant="outline"
          >
            <RefreshCw className={`h-4 w-4 mr-2 ${refreshing ? 'animate-spin' : ''}`} />
            Refresh
          </Button>
          <Button onClick={exportToCSV} disabled={filteredSales.length === 0}>
            <Download className="h-4 w-4 mr-2" />
            Export CSV
          </Button>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Sales</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats?.totalSales || 0}</div>
            <p className="text-xs text-muted-foreground">
              {stats?.conversionRate.toFixed(1)}% conversion rate
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Commissions</CardTitle>
            <DollarSign className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">${stats?.totalCommissions.toFixed(2) || '0.00'}</div>
            <p className="text-xs text-muted-foreground">
              From {stats?.totalSales || 0} sales
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Avg Order Value</CardTitle>
            <TrendingUp className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">${stats?.avgOrderValue.toFixed(2) || '0.00'}</div>
            <p className="text-xs text-muted-foreground">
              Per conversion
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Top Plan</CardTitle>
            <Calendar className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats?.topPlan || 'N/A'}</div>
            <p className="text-xs text-muted-foreground">
              Most popular
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Filters */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Filter className="h-5 w-5" />
            Filters
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
            <div className="space-y-2">
              <label className="text-sm font-medium">Search</label>
              <div className="relative">
                <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="Customer, plan, invoice..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>
            </div>

            <div className="space-y-2">
              <label className="text-sm font-medium">Status</label>
              <Select value={statusFilter} onValueChange={setStatusFilter}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Status</SelectItem>
                  <SelectItem value="pending">Pending</SelectItem>
                  <SelectItem value="approved">Approved</SelectItem>
                  <SelectItem value="paid">Paid</SelectItem>
                  <SelectItem value="void">Void</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <label className="text-sm font-medium">Plan</label>
              <Select value={planFilter} onValueChange={setPlanFilter}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Plans</SelectItem>
                  <SelectItem value="Basic">Basic</SelectItem>
                  <SelectItem value="Premium">Premium</SelectItem>
                  <SelectItem value="Pro">Pro</SelectItem>
                  <SelectItem value="Enterprise">Enterprise</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <label className="text-sm font-medium">Date Range</label>
              <Select value={dateFilter} onValueChange={setDateFilter}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Time</SelectItem>
                  <SelectItem value="7d">Last 7 days</SelectItem>
                  <SelectItem value="30d">Last 30 days</SelectItem>
                  <SelectItem value="90d">Last 90 days</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <label className="text-sm font-medium">Results</label>
              <div className="text-sm text-muted-foreground pt-2">
                {filteredSales.length} of {sales.length} sales
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Sales Table */}
      <Card>
        <CardHeader>
          <CardTitle>Sales History</CardTitle>
          <CardDescription>
            Detailed view of all your successful referrals
          </CardDescription>
        </CardHeader>
        <CardContent>
          {filteredSales.length === 0 ? (
            <div className="text-center py-12">
              <Users className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
              <h3 className="text-lg font-semibold mb-2">No Sales Found</h3>
              <p className="text-muted-foreground mb-4">
                {sales.length === 0 
                  ? "You haven't made any sales yet. Share your referral links to get started!"
                  : "No sales match your current filters. Try adjusting the filters above."
                }
              </p>
            </div>
          ) : (
            <div className="rounded-md border">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Date</TableHead>
                    <TableHead>Customer</TableHead>
                    <TableHead>Plan</TableHead>
                    <TableHead>Amount</TableHead>
                    <TableHead>Commission</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Source</TableHead>
                    <TableHead>Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredSales.map((sale) => (
                    <TableRow key={sale.id}>
                      <TableCell>
                        <div className="space-y-1">
                          <div className="font-medium">
                            {new Date(sale.created_at).toLocaleDateString()}
                          </div>
                          <div className="text-xs text-muted-foreground">
                            {new Date(sale.created_at).toLocaleTimeString()}
                          </div>
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="font-mono text-sm">
                          {sale.customer_masked}
                        </div>
                      </TableCell>
                      <TableCell>
                        <Badge variant="outline">{sale.plan}</Badge>
                      </TableCell>
                      <TableCell>
                        <div className="font-medium">
                          ${sale.subscription_amount.toFixed(2)}
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="space-y-1">
                          <div className="font-medium">
                            ${sale.commission_amount.toFixed(2)}
                          </div>
                          <div className="text-xs text-muted-foreground">
                            {sale.commission_rate.toFixed(1)}%
                          </div>
                        </div>
                      </TableCell>
                      <TableCell>
                        <Badge 
                          variant={
                            sale.status === 'paid' ? 'default' :
                            sale.status === 'approved' ? 'secondary' :
                            sale.status === 'pending' ? 'outline' : 'destructive'
                          }
                        >
                          {sale.status}
                        </Badge>
                        {sale.status === 'pending' && sale.hold_until && (
                          <div className="text-xs text-muted-foreground mt-1">
                            Available {new Date(sale.hold_until).toLocaleDateString()}
                          </div>
                        )}
                      </TableCell>
                      <TableCell>
                        <div className="space-y-1">
                          <div className="text-sm">
                            {sale.utm_source || 'Direct'}
                          </div>
                          {sale.utm_campaign && (
                            <div className="text-xs text-muted-foreground">
                              {sale.utm_campaign}
                            </div>
                          )}
                        </div>
                      </TableCell>
                      <TableCell>
                        {sale.stripe_invoice_id && (
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => window.open(`https://dashboard.stripe.com/invoices/${sale.stripe_invoice_id}`, '_blank')}
                          >
                            <ExternalLink className="h-4 w-4" />
                          </Button>
                        )}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}