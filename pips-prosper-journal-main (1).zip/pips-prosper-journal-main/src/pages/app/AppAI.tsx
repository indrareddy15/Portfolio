import { Suspense, lazy } from "react"
import { Skeleton } from "@/components/ui/skeleton"
import { SEOHead } from "@/components/SEOHead"

const AITradeCoach = lazy(() => 
  import("@/components/AI/AITradeCoach").then(module => ({ default: module.AITradeCoach }))
  .catch(error => {
    console.error('Failed to load AITradeCoach:', error);
    return { default: () => <div>Error loading AITradeCoach</div> };
  })
);

const LoadingSkeleton = () => (
  <div className="space-y-6">
    <Skeleton className="h-32 w-full" />
    <Skeleton className="h-64 w-full" />
  </div>
);

export default function AppAI() {
  return (
    <div className="space-y-6">
      <SEOHead 
        title="AI Trading Coach - PipTrackr.com"
        description="Get AI-powered insights and coaching for your trades"
      />
      
      <div>
        <h1 className="text-3xl font-poppins font-bold text-foreground">
          AI Trading Coach
        </h1>
        <p className="text-muted-foreground mt-1">
          Get personalized insights and recommendations from your AI coach
        </p>
      </div>

      <Suspense fallback={<LoadingSkeleton />}>
        <AITradeCoach />
      </Suspense>
    </div>
  )
}