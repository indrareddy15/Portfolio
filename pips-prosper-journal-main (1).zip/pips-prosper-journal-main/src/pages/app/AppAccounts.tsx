import { useState, useEffect } from "react";
import { Plus, Edit2, Trash2, TrendingUp, Target, AlertCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { toast } from "@/hooks/use-toast";
import { calculateTradingMetrics } from "@/utils/metricsCalculator";

interface Account {
  id: string;
  account_type: string;
  broker_name: string;
  nickname: string;
  account_size: number;
  currency: string;
  risk_preference: number;
  balance: number;
  equity: number;
  free_margin: number;
  margin: number;
  is_active: boolean;
  created_at: string;
}

interface AccountGoal {
  id: string;
  account_id: string;
  goal_type: string;
  target_value: number;
  current_value: number;
  target_date: string;
  is_achieved: boolean;
}

interface AccountMetrics {
  [accountId: string]: {
    totalTrades: number;
    winRate: number;
    totalPnL: number;
    maxDrawdown: number;
    profitFactor: number;
  };
}

export default function AppAccounts() {
  const { user } = useAuth();
  const [accounts, setAccounts] = useState<Account[]>([]);
  const [accountMetrics, setAccountMetrics] = useState<AccountMetrics>({});
  const [goals, setGoals] = useState<AccountGoal[]>([]);
  const [loading, setLoading] = useState(true);
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [editingAccount, setEditingAccount] = useState<Account | null>(null);

  // Form state
  const [formData, setFormData] = useState({
    account_type: "demo",
    broker_name: "",
    nickname: "",
    account_size: 10000,
    currency: "USD",
    risk_preference: 1.0,
    balance: 10000,
  });

  const fetchAccounts = async () => {
    if (!user) return;

    try {
      const { data: accountsData, error: accountsError } = await supabase
        .from("accounts")
        .select("*")
        .eq("user_id", user.id)
        .order("created_at", { ascending: false });

      if (accountsError) throw accountsError;
      setAccounts(accountsData || []);

      // Fetch goals
      const { data: goalsData, error: goalsError } = await supabase
        .from("account_goals")
        .select("*")
        .eq("user_id", user.id);

      if (goalsError) throw goalsError;
      setGoals(goalsData || []);

      // Calculate metrics for each account
      const metrics: AccountMetrics = {};
      for (const account of accountsData || []) {
        const { data: trades } = await supabase
          .from("trades")
          .select("*")
          .eq("account_id", account.id)
          .not("exit_price", "is", null);

        if (trades && trades.length > 0) {
          // Transform trades to match TradeData interface
          const transformedTrades = trades.map((trade: any) => ({
            id: trade.id,
            account_id: trade.account_id,
            symbol: 'EURUSD', // Default for now
            direction: 'buy' as 'buy' | 'sell', // Default for now
            entry_price: trade.entry_price || 0,
            exit_price: trade.exit_price || 0,
            stop_loss: trade.stop_loss || 0,
            take_profit: trade.take_profit || 0,
            lot_size: 1, // Default for now
            opened_at: trade.opened_at || trade.created_at,
            closed_at: trade.closed_at,
            pnl: trade.converted_pnl || trade.pnl || 0,
            pips: trade.pips || 0,
            commission: trade.commission || 0,
            swap: trade.swap || 0,
          }));

          const calculatedMetrics = calculateTradingMetrics(transformedTrades, account.balance);
          metrics[account.id] = {
            totalTrades: calculatedMetrics.totalTrades,
            winRate: calculatedMetrics.winRate,
            totalPnL: calculatedMetrics.totalPnL,
            maxDrawdown: calculatedMetrics.maxDrawdown,
            profitFactor: calculatedMetrics.profitFactor,
          };
        } else {
          metrics[account.id] = {
            totalTrades: 0,
            winRate: 0,
            totalPnL: 0,
            maxDrawdown: 0,
            profitFactor: 0,
          };
        }
      }
      setAccountMetrics(metrics);

    } catch (error) {
      console.error("Error fetching accounts:", error);
      toast({
        title: "Error",
        description: "Failed to load accounts",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchAccounts();
  }, [user]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) return;

    try {
      const accountData = {
        ...formData,
        user_id: user.id,
        name: formData.nickname, // Required field mapping
        equity: formData.balance,
        free_margin: formData.balance * 0.8, // Estimate
        margin: formData.balance * 0.2, // Estimate
      };

      if (editingAccount) {
        const { error } = await supabase
          .from("accounts")
          .update(accountData)
          .eq("id", editingAccount.id);

        if (error) throw error;
        toast({ title: "Success", description: "Account updated successfully" });
      } else {
        const { error } = await supabase
          .from("accounts")
          .insert(accountData);

        if (error) throw error;
        toast({ title: "Success", description: "Account created successfully" });
      }

      setIsAddDialogOpen(false);
      setEditingAccount(null);
      setFormData({
        account_type: "demo",
        broker_name: "",
        nickname: "",
        account_size: 10000,
        currency: "USD",
        risk_preference: 1.0,
        balance: 10000,
      });
      fetchAccounts();
    } catch (error: any) {
      console.error("Error saving account:", error);
      toast({
        title: "Error",
        description: error.message || "Failed to save account",
        variant: "destructive",
      });
    }
  };

  const handleEdit = (account: Account) => {
    setEditingAccount(account);
    setFormData({
      account_type: account.account_type,
      broker_name: account.broker_name,
      nickname: account.nickname,
      account_size: account.account_size,
      currency: account.currency,
      risk_preference: account.risk_preference,
      balance: account.balance,
    });
    setIsAddDialogOpen(true);
  };

  const handleDelete = async (accountId: string) => {
    try {
      const { error } = await supabase
        .from("accounts")
        .update({ is_active: false })
        .eq("id", accountId);

      if (error) throw error;
      toast({ title: "Success", description: "Account archived successfully" });
      fetchAccounts();
    } catch (error) {
      console.error("Error archiving account:", error);
      toast({
        title: "Error",
        description: "Failed to archive account",
        variant: "destructive",
      });
    }
  };

  const getAccountHealth = (account: Account, metrics: AccountMetrics[string]) => {
    const healthScore = Math.max(0, Math.min(100, 
      (metrics?.profitFactor || 0) * 10 + 
      (metrics?.winRate || 0) - 
      (metrics?.maxDrawdown || 0)
    ));
    
    if (healthScore >= 70) return { status: "Excellent", color: "bg-green-500", textColor: "text-green-700" };
    if (healthScore >= 50) return { status: "Good", color: "bg-blue-500", textColor: "text-blue-700" };
    if (healthScore >= 30) return { status: "Fair", color: "bg-yellow-500", textColor: "text-yellow-700" };
    return { status: "Poor", color: "bg-red-500", textColor: "text-red-700" };
  };

  if (loading) {
    return (
      <div className="p-6 space-y-6">
        <div className="h-8 w-48 bg-muted animate-pulse rounded" />
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {[1, 2, 3].map(i => (
            <div key={i} className="h-48 bg-muted animate-pulse rounded-lg" />
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="p-6 space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Account Management</h1>
          <p className="text-muted-foreground">
            Manage your trading accounts and monitor performance
          </p>
        </div>
        <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
          <DialogTrigger asChild>
            <Button>
              <Plus className="mr-2 h-4 w-4" />
              Add Account
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-md">
            <DialogHeader>
              <DialogTitle>
                {editingAccount ? "Edit Account" : "Add New Account"}
              </DialogTitle>
              <DialogDescription>
                {editingAccount ? "Update account details" : "Create a new trading account"}
              </DialogDescription>
            </DialogHeader>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="account_type">Account Type</Label>
                  <Select
                    value={formData.account_type}
                    onValueChange={(value) => setFormData({ ...formData, account_type: value })}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="demo">Demo</SelectItem>
                      <SelectItem value="live">Live</SelectItem>
                      <SelectItem value="broker">Broker</SelectItem>
                      <SelectItem value="prop_firm">Prop Firm</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="currency">Currency</Label>
                  <Select
                    value={formData.currency}
                    onValueChange={(value) => setFormData({ ...formData, currency: value })}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="USD">USD</SelectItem>
                      <SelectItem value="EUR">EUR</SelectItem>
                      <SelectItem value="GBP">GBP</SelectItem>
                      <SelectItem value="JPY">JPY</SelectItem>
                      <SelectItem value="AUD">AUD</SelectItem>
                      <SelectItem value="CAD">CAD</SelectItem>
                      <SelectItem value="CHF">CHF</SelectItem>
                      <SelectItem value="NZD">NZD</SelectItem>
                      <SelectItem value="INR">INR</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              
              <div>
                <Label htmlFor="broker_name">Broker/Firm Name</Label>
                <Input
                  id="broker_name"
                  value={formData.broker_name}
                  onChange={(e) => setFormData({ ...formData, broker_name: e.target.value })}
                  placeholder="e.g., IC Markets, FTMO"
                  required
                />
              </div>
              
              <div>
                <Label htmlFor="nickname">Account Nickname</Label>
                <Input
                  id="nickname"
                  value={formData.nickname}
                  onChange={(e) => setFormData({ ...formData, nickname: e.target.value })}
                  placeholder="e.g., ICMarkets-1, FTMO Challenge"
                  required
                />
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="account_size">Account Size</Label>
                  <Input
                    id="account_size"
                    type="number"
                    value={formData.account_size}
                    onChange={(e) => setFormData({ ...formData, account_size: Number(e.target.value) })}
                    min="100"
                    required
                  />
                </div>
                <div>
                  <Label htmlFor="balance">Current Balance</Label>
                  <Input
                    id="balance"
                    type="number"
                    value={formData.balance}
                    onChange={(e) => setFormData({ ...formData, balance: Number(e.target.value) })}
                    min="0"
                    step="0.01"
                    required
                  />
                </div>
              </div>
              
              <div>
                <Label htmlFor="risk_preference">Risk Per Trade (%)</Label>
                <Input
                  id="risk_preference"
                  type="number"
                  value={formData.risk_preference}
                  onChange={(e) => setFormData({ ...formData, risk_preference: Number(e.target.value) })}
                  min="0.1"
                  max="10"
                  step="0.1"
                  required
                />
              </div>
              
              <div className="flex justify-end space-x-2">
                <Button type="button" variant="outline" onClick={() => {
                  setIsAddDialogOpen(false);
                  setEditingAccount(null);
                }}>
                  Cancel
                </Button>
                <Button type="submit">
                  {editingAccount ? "Update" : "Create"} Account
                </Button>
              </div>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      {/* Account Health Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {accounts.filter(acc => acc.is_active).map((account) => {
          const metrics = accountMetrics[account.id] || {
            totalTrades: 0,
            winRate: 0,
            totalPnL: 0,
            maxDrawdown: 0,
            profitFactor: 0,
          };
          const health = getAccountHealth(account, metrics);
          const equityPercent = account.balance > 0 ? (account.equity / account.balance) * 100 : 100;
          const marginPercent = account.equity > 0 ? (account.margin / account.equity) * 100 : 0;
          
          return (
            <Card key={account.id} className="relative">
              <CardHeader className="pb-3">
                <div className="flex items-center justify-between">
                  <Badge variant={account.account_type === 'live' ? 'default' : 'secondary'}>
                    {account.account_type.toUpperCase()}
                  </Badge>
                  <div className="flex items-center space-x-1">
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={() => handleEdit(account)}
                    >
                      <Edit2 className="h-4 w-4" />
                    </Button>
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={() => handleDelete(account.id)}
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
                <div>
                  <CardTitle className="text-lg">{account.nickname}</CardTitle>
                  <CardDescription>{account.broker_name}</CardDescription>
                </div>
              </CardHeader>
              
              <CardContent className="space-y-4">
                {/* Account Health */}
                <div className="flex items-center justify-between">
                  <span className="text-sm font-medium">Health Status</span>
                  <Badge className={`${health.color} text-white`}>
                    {health.status}
                  </Badge>
                </div>
                
                {/* Balance Info */}
                <div className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span>Balance:</span>
                    <span className="font-medium">
                      {account.currency} {account.balance.toLocaleString()}
                    </span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span>Equity:</span>
                    <span className={`font-medium ${equityPercent >= 95 ? 'text-green-600' : equityPercent >= 90 ? 'text-yellow-600' : 'text-red-600'}`}>
                      {account.currency} {account.equity.toLocaleString()}
                    </span>
                  </div>
                  <Progress value={equityPercent} className="h-2" />
                </div>
                
                {/* Margin Info */}
                <div className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span>Margin Used:</span>
                    <span className={`font-medium ${marginPercent <= 30 ? 'text-green-600' : marginPercent <= 60 ? 'text-yellow-600' : 'text-red-600'}`}>
                      {marginPercent.toFixed(1)}%
                    </span>
                  </div>
                  <Progress value={marginPercent} className="h-1" />
                </div>
                
                {/* Trading Stats */}
                <div className="grid grid-cols-2 gap-4 pt-2 border-t">
                  <div className="text-center">
                    <div className="text-lg font-bold text-primary">
                      {metrics.totalTrades || 0}
                    </div>
                    <div className="text-xs text-muted-foreground">Trades</div>
                  </div>
                  <div className="text-center">
                    <div className="text-lg font-bold text-green-600">
                      {metrics.winRate?.toFixed(1) || '0.0'}%
                    </div>
                    <div className="text-xs text-muted-foreground">Win Rate</div>
                  </div>
                </div>
                
                <div className="grid grid-cols-2 gap-4">
                  <div className="text-center">
                    <div className={`text-lg font-bold ${(metrics.totalPnL || 0) >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                      {account.currency} {(metrics.totalPnL || 0).toLocaleString()}
                    </div>
                    <div className="text-xs text-muted-foreground">P&L</div>
                  </div>
                  <div className="text-center">
                    <div className="text-lg font-bold text-red-600">
                      -{metrics.maxDrawdown?.toFixed(1) || '0.0'}%
                    </div>
                    <div className="text-xs text-muted-foreground">Max DD</div>
                  </div>
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* Account Comparison Table */}
      {accounts.filter(acc => acc.is_active).length > 1 && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <TrendingUp className="h-5 w-5" />
              Account Comparison
            </CardTitle>
            <CardDescription>
              Compare performance across all your trading accounts
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Account</TableHead>
                  <TableHead>Type</TableHead>
                  <TableHead>Balance</TableHead>
                  <TableHead>Trades</TableHead>
                  <TableHead>Win Rate</TableHead>
                  <TableHead>P&L</TableHead>
                  <TableHead>Max DD</TableHead>
                  <TableHead>PF</TableHead>
                  <TableHead>Risk %</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {accounts.filter(acc => acc.is_active).map((account) => {
                  const metrics = accountMetrics[account.id] || {
                    totalTrades: 0,
                    winRate: 0,
                    totalPnL: 0,
                    maxDrawdown: 0,
                    profitFactor: 0,
                  };
                  return (
                    <TableRow key={account.id}>
                      <TableCell>
                        <div>
                          <div className="font-medium">{account.nickname}</div>
                          <div className="text-sm text-muted-foreground">
                            {account.broker_name}
                          </div>
                        </div>
                      </TableCell>
                      <TableCell>
                        <Badge variant={account.account_type === 'live' ? 'default' : 'secondary'}>
                          {account.account_type}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <div className="font-mono">
                          {account.currency} {account.balance.toLocaleString()}
                        </div>
                      </TableCell>
                      <TableCell>{metrics.totalTrades || 0}</TableCell>
                      <TableCell>
                        <span className={metrics.winRate && metrics.winRate >= 50 ? 'text-green-600' : 'text-red-600'}>
                          {metrics.winRate?.toFixed(1) || '0.0'}%
                        </span>
                      </TableCell>
                      <TableCell>
                        <span className={`font-mono ${(metrics.totalPnL || 0) >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                          {account.currency} {(metrics.totalPnL || 0).toLocaleString()}
                        </span>
                      </TableCell>
                      <TableCell>
                        <span className="text-red-600">
                          -{metrics.maxDrawdown?.toFixed(1) || '0.0'}%
                        </span>
                      </TableCell>
                      <TableCell>
                        <span className={metrics.profitFactor && metrics.profitFactor >= 1 ? 'text-green-600' : 'text-red-600'}>
                          {metrics.profitFactor?.toFixed(2) || '0.00'}
                        </span>
                      </TableCell>
                      <TableCell>
                        <span className={account.risk_preference <= 2 ? 'text-green-600' : account.risk_preference <= 5 ? 'text-yellow-600' : 'text-red-600'}>
                          {account.risk_preference}%
                        </span>
                      </TableCell>
                    </TableRow>
                  );
                })}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      )}

      {accounts.filter(acc => acc.is_active).length === 0 && (
        <Card className="text-center py-12">
          <CardContent>
            <AlertCircle className="mx-auto h-12 w-12 text-muted-foreground mb-4" />
            <h3 className="text-lg font-semibold mb-2">No Trading Accounts</h3>
            <p className="text-muted-foreground mb-4">
              Create your first trading account to start tracking your performance
            </p>
            <Button onClick={() => setIsAddDialogOpen(true)}>
              <Plus className="mr-2 h-4 w-4" />
              Add Your First Account
            </Button>
          </CardContent>
        </Card>
      )}
    </div>
  );
}