import { Suspense, lazy } from "react"
import { Skeleton } from "@/components/ui/skeleton"
import { SEOHead } from "@/components/SEOHead"

const PsychologyDashboard = lazy(() => 
  import("@/components/Psychology/PsychologyDashboard").then(module => ({ default: module.PsychologyDashboard }))
  .catch(error => {
    console.error('Failed to load PsychologyDashboard:', error);
    return { default: () => <div>Error loading PsychologyDashboard</div> };
  })
);

const LoadingSkeleton = () => (
  <div className="space-y-6">
    <Skeleton className="h-32 w-full" />
    <Skeleton className="h-64 w-full" />
  </div>
);

export default function AppPsychology() {
  return (
    <div className="space-y-6">
      <SEOHead 
        title="Trading Psychology - PipTrackr.com"
        description="Track and improve your trading psychology and mindset"
      />
      
      <div>
        <h1 className="text-3xl font-poppins font-bold text-foreground">
          Trading Psychology
        </h1>
        <p className="text-muted-foreground mt-1">
          Monitor your trading mindset and emotional patterns
        </p>
      </div>

      <Suspense fallback={<LoadingSkeleton />}>
        <PsychologyDashboard />
      </Suspense>
    </div>
  )
}