import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { SEOHead } from "@/components/SEOHead"
import { Target, Plus, Edit, Trash2, TrendingUp } from "lucide-react"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"

const goals = [
  {
    id: 1,
    title: "Monthly Profit Target",
    target: 5000,
    current: 3250,
    type: "Profit",
    deadline: "End of Month",
    status: "In Progress"
  },
  {
    id: 2,
    title: "Win Rate Improvement", 
    target: 75,
    current: 68.5,
    type: "Percentage",
    deadline: "Next Quarter",
    status: "In Progress"
  },
  {
    id: 3,
    title: "Maximum Drawdown Limit",
    target: -10,
    current: -5.2,
    type: "Risk",
    deadline: "Ongoing",
    status: "On Track"
  }
]

const rules = [
  {
    id: 1,
    title: "Risk per Trade",
    description: "Never risk more than 2% per trade",
    type: "Risk Management",
    active: true
  },
  {
    id: 2,
    title: "Daily Loss Limit",
    description: "Stop trading if daily loss exceeds $500",
    type: "Risk Management", 
    active: true
  },
  {
    id: 3,
    title: "Maximum Positions",
    description: "Never hold more than 5 positions simultaneously",
    type: "Position Management",
    active: true
  },
  {
    id: 4,
    title: "Trading Hours",
    description: "Only trade during 9 AM - 5 PM EST",
    type: "Time Management",
    active: false
  }
]

export default function AppGoals() {
  const getProgress = (current: number, target: number, type: string) => {
    if (type === "Risk") {
      return Math.min(100, Math.abs(current / target) * 100)
    }
    return Math.min(100, (current / target) * 100)
  }

  return (
    <div className="space-y-6">
      <SEOHead 
        title="Goals & Rules - PipTrackr.com"
        description="Set and track your trading goals and rules"
      />
      
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-poppins font-bold text-foreground">
            Goals & Rules
          </h1>
          <p className="text-muted-foreground mt-1">
            Set trading goals and create rules to maintain discipline
          </p>
        </div>
        <Button className="bg-primary hover:bg-primary-dark">
          <Plus className="h-4 w-4 mr-2" />
          Add Goal
        </Button>
      </div>

      {/* Trading Goals */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Target className="h-5 w-5 text-primary" />
            Trading Goals
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {goals.map((goal) => (
            <div key={goal.id} className="p-4 border rounded-lg">
              <div className="flex items-start justify-between mb-3">
                <div className="flex-1">
                  <h3 className="font-semibold">{goal.title}</h3>
                  <div className="flex items-center gap-2 mt-1">
                    <Badge variant="outline">{goal.type}</Badge>
                    <span className="text-sm text-muted-foreground">Due: {goal.deadline}</span>
                  </div>
                </div>
                <div className="flex gap-2">
                  <Button variant="outline" size="sm">
                    <Edit className="h-4 w-4" />
                  </Button>
                  <Button variant="outline" size="sm">
                    <Trash2 className="h-4 w-4 text-destructive" />
                  </Button>
                </div>
              </div>
              
              <div className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span>Progress</span>
                  <span>{goal.current}{goal.type === "Percentage" ? "%" : goal.type === "Risk" ? "%" : ""} / {goal.target}{goal.type === "Percentage" ? "%" : goal.type === "Risk" ? "%" : ""}</span>
                </div>
                <Progress 
                  value={getProgress(goal.current, goal.target, goal.type)} 
                  className="h-2"
                />
                <div className="flex justify-between items-center">
                  <Badge 
                    variant={goal.status === "On Track" ? "default" : "secondary"}
                    className={goal.status === "On Track" ? "bg-success" : ""}
                  >
                    {goal.status}
                  </Badge>
                  <span className="text-sm text-muted-foreground">
                    {Math.round(getProgress(goal.current, goal.target, goal.type))}% complete
                  </span>
                </div>
              </div>
            </div>
          ))}
        </CardContent>
      </Card>

      {/* Trading Rules */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <TrendingUp className="h-5 w-5 text-warning" />
            Trading Rules
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {rules.map((rule) => (
            <div key={rule.id} className="flex items-center justify-between p-4 border rounded-lg">
              <div className="flex-1">
                <h3 className="font-semibold">{rule.title}</h3>
                <p className="text-sm text-muted-foreground mt-1">{rule.description}</p>
                <Badge variant="outline" className="mt-2">{rule.type}</Badge>
              </div>
              
              <div className="flex items-center gap-3">
                <Badge 
                  variant={rule.active ? "default" : "secondary"}
                  className={rule.active ? "bg-success" : ""}
                >
                  {rule.active ? "Active" : "Inactive"}
                </Badge>
                <div className="flex gap-2">
                  <Button variant="outline" size="sm">
                    <Edit className="h-4 w-4" />
                  </Button>
                  <Button variant="outline" size="sm">
                    <Trash2 className="h-4 w-4 text-destructive" />
                  </Button>
                </div>
              </div>
            </div>
          ))}
        </CardContent>
      </Card>

      {/* Add New Forms */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Add New Goal</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <Label htmlFor="goalTitle">Goal Title</Label>
              <Input id="goalTitle" placeholder="e.g., Monthly Profit Target" />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="goalType">Type</Label>
                <select id="goalType" className="w-full p-2 border rounded-lg">
                  <option>Profit</option>
                  <option>Percentage</option>
                  <option>Risk</option>
                  <option>Trades</option>
                </select>
              </div>
              <div>
                <Label htmlFor="goalTarget">Target</Label>
                <Input id="goalTarget" type="number" placeholder="5000" />
              </div>
            </div>
            <Button className="w-full">
              <Plus className="h-4 w-4 mr-2" />
              Add Goal
            </Button>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Add New Rule</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <Label htmlFor="ruleTitle">Rule Title</Label>
              <Input id="ruleTitle" placeholder="e.g., Risk per Trade" />
            </div>
            <div>
              <Label htmlFor="ruleDesc">Description</Label>
              <Input id="ruleDesc" placeholder="e.g., Never risk more than 2% per trade" />
            </div>
            <div>
              <Label htmlFor="ruleType">Category</Label>
              <select id="ruleType" className="w-full p-2 border rounded-lg">
                <option>Risk Management</option>
                <option>Position Management</option>
                <option>Time Management</option>
                <option>Strategy</option>
              </select>
            </div>
            <Button className="w-full">
              <Plus className="h-4 w-4 mr-2" />
              Add Rule
            </Button>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}