import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { SEOHead } from "@/components/SEOHead"
import { Database, Download, Upload, Trash2, RefreshCw, Shield, AlertTriangle } from "lucide-react"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Separator } from "@/components/ui/separator"

const dataStats = [
  {
    label: "Total Trades",
    value: "2,847",
    size: "1.2 MB"
  },
  {
    label: "Account Data",
    value: "5",
    size: "45 KB"
  },
  {
    label: "Analytics Cache",
    value: "125",
    size: "890 KB"
  },
  {
    label: "Attachments",
    value: "23",
    size: "12.3 MB"
  }
]

const backupHistory = [
  {
    id: 1,
    date: "2024-01-15 10:30 AM",
    type: "Automatic",
    size: "14.2 MB",
    status: "Completed"
  },
  {
    id: 2,
    date: "2024-01-10 02:15 AM", 
    type: "Automatic",
    size: "13.8 MB",
    status: "Completed"
  },
  {
    id: 3,
    date: "2024-01-05 02:15 AM",
    type: "Manual",
    size: "13.1 MB", 
    status: "Completed"
  }
]

export default function AppData() {
  return (
    <div className="space-y-6">
      <SEOHead 
        title="Data Management - PipTrackr.com"
        description="Manage your trading data, backups, and privacy settings"
      />
      
      <div>
        <h1 className="text-3xl font-poppins font-bold text-foreground">
          Data Management
        </h1>
        <p className="text-muted-foreground mt-1">
          Manage your data storage, backups, and privacy settings
        </p>
      </div>

      {/* Data Overview */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Database className="h-5 w-5 text-primary" />
            Data Overview
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
            {dataStats.map((stat, index) => (
              <div key={index} className="p-4 border rounded-lg text-center">
                <p className="text-lg font-bold text-primary">{stat.value}</p>
                <p className="text-sm text-muted-foreground">{stat.label}</p>
                <p className="text-xs text-muted-foreground mt-1">{stat.size}</p>
              </div>
            ))}
          </div>
          
          <div className="space-y-2">
            <div className="flex justify-between text-sm">
              <span>Storage Used</span>
              <span>14.5 MB / 1 GB</span>
            </div>
            <Progress value={1.45} className="h-2" />
            <p className="text-xs text-muted-foreground">
              You're using 1.45% of your available storage
            </p>
          </div>
        </CardContent>
      </Card>

      {/* Data Export & Import */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Download className="h-5 w-5 text-success" />
              Export Data
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <p className="text-sm text-muted-foreground">
              Download all your trading data in standard formats
            </p>
            
            <div className="space-y-2">
              <Button variant="outline" className="w-full justify-start">
                <Download className="h-4 w-4 mr-2" />
                Export All Trades (CSV)
              </Button>
              <Button variant="outline" className="w-full justify-start">
                <Download className="h-4 w-4 mr-2" />
                Export Account Data (JSON)
              </Button>
              <Button variant="outline" className="w-full justify-start">
                <Download className="h-4 w-4 mr-2" />
                Export Complete Backup (ZIP)
              </Button>
            </div>
            
            <div className="pt-2 border-t">
              <Button className="w-full bg-success hover:bg-success/90">
                <Download className="h-4 w-4 mr-2" />
                Request Complete Export
              </Button>
              <p className="text-xs text-muted-foreground mt-2">
                Complete export will be emailed within 24 hours
              </p>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Upload className="h-5 w-5 text-info" />
              Import Data
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <p className="text-sm text-muted-foreground">
              Import trading data from other platforms or backups
            </p>
            
            <div className="space-y-2">
              <Button variant="outline" className="w-full justify-start">
                <Upload className="h-4 w-4 mr-2" />
                Import from CSV
              </Button>
              <Button variant="outline" className="w-full justify-start">
                <Upload className="h-4 w-4 mr-2" />
                Import MT4/MT5 History
              </Button>
              <Button variant="outline" className="w-full justify-start">
                <Upload className="h-4 w-4 mr-2" />
                Restore from Backup
              </Button>
            </div>
            
            <div className="p-3 bg-warning/10 border border-warning/20 rounded-lg">
              <div className="flex items-start gap-2">
                <AlertTriangle className="h-4 w-4 text-warning flex-shrink-0 mt-0.5" />
                <div className="text-xs">
                  <p className="font-medium text-warning">Import Warning</p>
                  <p className="text-muted-foreground">
                    Importing will merge with existing data. Duplicate trades will be detected and skipped.
                  </p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Backup History */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="flex items-center gap-2">
              <Shield className="h-5 w-5 text-warning" />
              Backup History
            </CardTitle>
            <Button variant="outline" size="sm">
              <RefreshCw className="h-4 w-4 mr-2" />
              Create Backup
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {backupHistory.map((backup, index) => (
              <div key={backup.id}>
                <div className="flex items-center justify-between">
                  <div>
                    <p className="font-medium">{backup.date}</p>
                    <div className="flex items-center gap-2 mt-1">
                      <Badge variant={backup.type === "Automatic" ? "default" : "secondary"}>
                        {backup.type}
                      </Badge>
                      <span className="text-sm text-muted-foreground">{backup.size}</span>
                    </div>
                  </div>
                  <div className="flex items-center gap-3">
                    <Badge 
                      variant={backup.status === "Completed" ? "default" : "secondary"}
                      className={backup.status === "Completed" ? "bg-success" : ""}
                    >
                      {backup.status}
                    </Badge>
                    <div className="flex gap-2">
                      <Button variant="outline" size="sm">
                        <Download className="h-4 w-4" />
                      </Button>
                      <Button variant="outline" size="sm">
                        <Upload className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                </div>
                {index < backupHistory.length - 1 && <Separator className="mt-4" />}
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Data Deletion */}
      <Card className="border-destructive/20">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-destructive">
            <Trash2 className="h-5 w-5" />
            Data Deletion
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="p-4 bg-destructive/10 border border-destructive/20 rounded-lg">
            <div className="flex items-start gap-3">
              <AlertTriangle className="h-5 w-5 text-destructive flex-shrink-0 mt-0.5" />
              <div>
                <p className="font-medium text-destructive">Danger Zone</p>
                <p className="text-sm text-muted-foreground mt-1">
                  These actions are permanent and cannot be undone. Please proceed with caution.
                </p>
              </div>
            </div>
          </div>
          
          <div className="space-y-3">
            <Button variant="outline" className="w-full justify-start text-destructive border-destructive/20">
              <Trash2 className="h-4 w-4 mr-2" />
              Delete Trade History (Keep Account)
            </Button>
            <Button variant="outline" className="w-full justify-start text-destructive border-destructive/20">
              <Trash2 className="h-4 w-4 mr-2" />
              Delete All Analytics Data
            </Button>
            <Button variant="destructive" className="w-full">
              <Trash2 className="h-4 w-4 mr-2" />
              Delete Account & All Data
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}