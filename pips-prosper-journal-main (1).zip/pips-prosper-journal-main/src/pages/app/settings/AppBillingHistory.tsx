import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Download, ExternalLink, RefreshCw, CreditCard } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/useAuth";
import { SEOHead } from "@/components/SEOHead";
import { useRealtime } from "@/hooks/useRealtime";

interface Invoice {
  id: string;
  stripe_invoice_id: string;
  amount_due: number;
  currency: string;
  status: string;
  hosted_invoice_url?: string;
  invoice_pdf_url?: string;
  created_at: string;
}

interface UserSubscription {
  plan_id?: string;
  status: string;
  current_period_end?: string;
  stripe_customer_id?: string;
  cancel_at_period_end: boolean;
}

interface Plan {
  id: string;
  name: string;
  price_amount: number;
  price_currency: string;
  billing_cycle: string;
}

export default function AppBillingHistory() {
  const [invoices, setInvoices] = useState<Invoice[]>([]);
  const [userSubscription, setUserSubscription] = useState<UserSubscription | null>(null);
  const [currentPlan, setCurrentPlan] = useState<Plan | null>(null);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const { user } = useAuth();

  // Real-time updates for invoices
  useRealtime([
    {
      table: 'user_invoices',
      events: ['INSERT', 'UPDATE', 'DELETE'],
      onInsert: () => fetchInvoices(),
      onUpdate: () => fetchInvoices(),
      onDelete: () => fetchInvoices(),
      showToasts: false
    }
  ]);

  const fetchInvoices = async () => {
    if (!user) return;

    try {
      const { data, error } = await supabase
        .from('user_invoices')
        .select('*')
        .eq('user_id', user.id)
        .order('created_at', { ascending: false });

      if (error) throw error;
      setInvoices(data || []);
    } catch (error) {
      console.error('Error fetching invoices:', error);
      toast({
        title: "Error",
        description: "Failed to load billing history",
        variant: "destructive"
      });
    }
  };

  const fetchUserSubscription = async () => {
    if (!user) return;

    try {
      const { data, error } = await supabase
        .from('user_subscriptions')
        .select('*')
        .eq('user_id', user.id)
        .eq('status', 'active')
        .maybeSingle();

      if (error) throw error;
      setUserSubscription(data);

      // Fetch current plan details if subscription exists
      if (data?.plan_id) {
        const { data: planData, error: planError } = await supabase
          .from('plans')
          .select('*')
          .eq('id', data.plan_id)
          .single();

        if (!planError) {
          setCurrentPlan(planData);
        }
      }
    } catch (error) {
      console.error('Error fetching user subscription:', error);
    }
  };

  useEffect(() => {
    const loadData = async () => {
      setLoading(true);
      await Promise.all([
        fetchInvoices(),
        fetchUserSubscription()
      ]);
      setLoading(false);
    };
    loadData();
  }, [user]);

  const handleRefresh = async () => {
    setRefreshing(true);
    await Promise.all([
      fetchInvoices(),
      fetchUserSubscription()
    ]);
    setRefreshing(false);
    toast({
      title: "Updated",
      description: "Billing information refreshed"
    });
  };

  const handleManageBilling = async () => {
    if (!user) return;

    try {
      const { data, error } = await supabase.functions.invoke('pricing-billing-portal');
      
      if (error) throw error;

      if (data?.url) {
        window.open(data.url, '_blank');
      }
    } catch (error: any) {
      console.error('Error opening billing portal:', error);
      toast({
        title: "Error",
        description: error.message || "Failed to open billing portal",
        variant: "destructive"
      });
    }
  };

  const handleDownloadInvoice = (invoice: Invoice) => {
    if (invoice.invoice_pdf_url) {
      window.open(invoice.invoice_pdf_url, '_blank');
    } else if (invoice.hosted_invoice_url) {
      window.open(invoice.hosted_invoice_url, '_blank');
    } else {
      toast({
        title: "Unavailable",
        description: "Invoice download is not available",
        variant: "destructive"
      });
    }
  };

  const formatAmount = (amount: number, currency: string) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: currency.toUpperCase()
    }).format(amount);
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });
  };

  const getStatusBadge = (status: string) => {
    const statusMap = {
      paid: { variant: "default" as const, label: "Paid" },
      open: { variant: "secondary" as const, label: "Pending" },
      void: { variant: "outline" as const, label: "Void" },
      uncollectible: { variant: "destructive" as const, label: "Failed" },
      draft: { variant: "outline" as const, label: "Draft" }
    };

    const config = statusMap[status as keyof typeof statusMap] || { variant: "outline" as const, label: status };
    return <Badge variant={config.variant}>{config.label}</Badge>;
  };

  const formatPrice = (amount: number, currency: string, cycle: string) => {
    const formattedAmount = new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: currency
    }).format(amount);
    
    return amount === 0 ? 'Free' : `${formattedAmount}/${cycle}`;
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <SEOHead
        title="Billing History - PipTrackr.com"
        description="View your billing history and manage your PipTrackr.com subscription"
      />

      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Billing History</h1>
          <p className="text-muted-foreground">
            View your invoices and manage your subscription
          </p>
        </div>
        <div className="flex space-x-2">
          <Button 
            variant="outline" 
            onClick={handleRefresh}
            disabled={refreshing}
          >
            <RefreshCw className={`w-4 h-4 mr-2 ${refreshing ? 'animate-spin' : ''}`} />
            Refresh
          </Button>
          {userSubscription && (
            <Button onClick={handleManageBilling}>
              <CreditCard className="w-4 h-4 mr-2" />
              Manage Billing
            </Button>
          )}
        </div>
      </div>

      {/* Current Subscription */}
      {currentPlan && userSubscription && (
        <Card>
          <CardHeader>
            <CardTitle>Current Subscription</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <div className="text-lg font-semibold">{currentPlan.name}</div>
                <div className="text-muted-foreground">
                  {formatPrice(currentPlan.price_amount, currentPlan.price_currency, currentPlan.billing_cycle)}
                </div>
              </div>
              <div className="text-right">
                <div className="text-sm text-muted-foreground">Status</div>
                <Badge variant="default">Active</Badge>
              </div>
            </div>

            {userSubscription.current_period_end && (
              <div>
                <div className="text-sm text-muted-foreground mb-1">
                  {userSubscription.cancel_at_period_end ? 'Cancels on' : 'Next billing date'}
                </div>
                <div className="font-medium">
                  {formatDate(userSubscription.current_period_end)}
                </div>
              </div>
            )}

            {userSubscription.cancel_at_period_end && (
              <div className="p-3 bg-warning/10 border border-warning/20 rounded-lg">
                <div className="text-sm text-warning-foreground">
                  Your subscription will be canceled at the end of the current billing period.
                </div>
              </div>
            )}
          </CardContent>
        </Card>
      )}

      {/* Invoices Table */}
      <Card>
        <CardHeader>
          <CardTitle>Invoice History</CardTitle>
        </CardHeader>
        <CardContent>
          {invoices.length > 0 ? (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Date</TableHead>
                  <TableHead>Description</TableHead>
                  <TableHead>Amount</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {invoices.map((invoice) => (
                  <TableRow key={invoice.id}>
                    <TableCell>
                      {formatDate(invoice.created_at)}
                    </TableCell>
                    <TableCell>
                      <div>
                        <div className="font-medium">
                          {currentPlan?.name || 'Subscription'}
                        </div>
                        <div className="text-sm text-muted-foreground">
                          Invoice #{invoice.stripe_invoice_id.slice(-6)}
                        </div>
                      </div>
                    </TableCell>
                    <TableCell>
                      {formatAmount(invoice.amount_due, invoice.currency)}
                    </TableCell>
                    <TableCell>
                      {getStatusBadge(invoice.status)}
                    </TableCell>
                    <TableCell className="text-right">
                      <div className="flex justify-end space-x-2">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => handleDownloadInvoice(invoice)}
                          disabled={!invoice.hosted_invoice_url && !invoice.invoice_pdf_url}
                        >
                          <Download className="w-4 h-4 mr-1" />
                          Download
                        </Button>
                        {invoice.hosted_invoice_url && (
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => window.open(invoice.hosted_invoice_url, '_blank')}
                          >
                            <ExternalLink className="w-4 h-4 mr-1" />
                            View
                          </Button>
                        )}
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          ) : (
            <div className="text-center py-12">
              <CreditCard className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
              <h3 className="text-lg font-semibold mb-2">No invoices yet</h3>
              <p className="text-muted-foreground mb-4">
                Your billing history will appear here once you subscribe to a plan.
              </p>
              <Button onClick={() => window.location.href = '/subscription'}>
                View Plans
              </Button>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}