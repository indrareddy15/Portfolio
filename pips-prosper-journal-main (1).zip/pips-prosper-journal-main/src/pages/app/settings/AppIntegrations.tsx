import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { SEOHead } from "@/components/SEOHead"
import { Switch } from "@/components/ui/switch"
import { Badge } from "@/components/ui/badge"
import { Settings, Zap, ExternalLink } from "lucide-react"

const integrations = [
  {
    id: 1,
    name: "TradingView",
    description: "Connect with TradingView for advanced charting and alerts",
    icon: "📈",
    status: "Connected",
    enabled: true,
    features: ["Charts", "Alerts", "Indicators"]
  },
  {
    id: 2,
    name: "Discord",
    description: "Get trade notifications in your Discord server",
    icon: "💬", 
    status: "Available",
    enabled: false,
    features: ["Notifications", "Bot Commands", "Community"]
  },
  {
    id: 3,
    name: "Telegram",
    description: "Receive instant trade alerts via Telegram bot",
    icon: "📱",
    status: "Available", 
    enabled: false,
    features: ["Instant Alerts", "Bot Integration", "Group Chat"]
  },
  {
    id: 4,
    name: "Email Alerts",
    description: "Get email notifications for important trading events",
    icon: "📧",
    status: "Connected",
    enabled: true,
    features: ["Trade Alerts", "Weekly Reports", "Account Updates"]
  },
  {
    id: 5,
    name: "Zapier",
    description: "Connect with 3000+ apps via Zapier automation",
    icon: "⚡",
    status: "Available",
    enabled: false,
    features: ["Automation", "Workflows", "Data Sync"]
  },
  {
    id: 6,
    name: "Google Sheets",
    description: "Sync your trade data with Google Sheets",
    icon: "📊",
    status: "Available",
    enabled: false,
    features: ["Data Sync", "Real-time Updates", "Custom Reports"]
  }
]

export default function AppIntegrations() {
  return (
    <div className="space-y-6">
      <SEOHead 
        title="Integrations - PipTrackr.com"
        description="Connect PipTrackr.com with your favorite trading tools and platforms"
      />
      
      <div>
        <h1 className="text-3xl font-poppins font-bold text-foreground">
          Integrations
        </h1>
        <p className="text-muted-foreground mt-1">
          Connect PipTrackr.com with your favorite tools and platforms
        </p>
      </div>

      {/* Active Integrations */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Zap className="h-5 w-5 text-primary" />
            Active Integrations
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {integrations.filter(i => i.enabled).map((integration) => (
              <div key={integration.id} className="flex items-center justify-between p-3 bg-success/5 border border-success/20 rounded-lg">
                <div className="flex items-center gap-3">
                  <span className="text-2xl">{integration.icon}</span>
                  <div>
                    <p className="font-medium">{integration.name}</p>
                    <p className="text-sm text-muted-foreground">{integration.description}</p>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <Badge className="bg-success text-success-foreground">Active</Badge>
                  <Button variant="outline" size="sm">
                    <Settings className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Available Integrations */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {integrations.map((integration) => (
          <Card key={integration.id} className="hover:shadow-md transition-all duration-300">
            <CardHeader className="pb-3">
              <div className="flex items-start justify-between">
                <div className="flex items-center gap-3">
                  <span className="text-3xl">{integration.icon}</span>
                  <div>
                    <CardTitle className="text-lg">{integration.name}</CardTitle>
                    <Badge 
                      variant={integration.status === "Connected" ? "default" : "secondary"}
                      className={integration.status === "Connected" ? "bg-success mt-1" : "mt-1"}
                    >
                      {integration.status}
                    </Badge>
                  </div>
                </div>
                <Switch 
                  checked={integration.enabled} 
                  className="data-[state=checked]:bg-primary"
                />
              </div>
            </CardHeader>
            
            <CardContent className="space-y-4">
              <p className="text-sm text-muted-foreground">
                {integration.description}
              </p>
              
              <div>
                <p className="text-sm font-medium mb-2">Features:</p>
                <div className="flex flex-wrap gap-1">
                  {integration.features.map((feature, index) => (
                    <Badge key={index} variant="outline" className="text-xs">
                      {feature}
                    </Badge>
                  ))}
                </div>
              </div>
              
              <div className="flex gap-2 pt-2">
                {integration.enabled ? (
                  <>
                    <Button variant="outline" size="sm" className="flex-1">
                      <Settings className="h-4 w-4 mr-1" />
                      Configure
                    </Button>
                    <Button variant="outline" size="sm">
                      Disconnect
                    </Button>
                  </>
                ) : (
                  <Button size="sm" className="flex-1">
                    Connect
                  </Button>
                )}
                <Button variant="outline" size="sm">
                  <ExternalLink className="h-4 w-4" />
                </Button>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  )
}