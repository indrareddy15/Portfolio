import { Suspense, lazy } from "react"
import { Skeleton } from "@/components/ui/skeleton"
import { SEOHead } from "@/components/SEOHead"

const PropMetricsDashboard = lazy(() => 
  import("@/components/PropFirm/PropMetricsDashboard").then(module => ({ default: module.PropMetricsDashboard }))
  .catch(error => {
    console.error('Failed to load PropMetricsDashboard:', error);
    return { default: () => <div>Error loading PropMetricsDashboard</div> };
  })
);

const PropChallengeTracker = lazy(() => 
  import("@/components/PropFirm/PropChallengeTracker").then(module => ({ default: module.PropChallengeTracker }))
  .catch(error => {
    console.error('Failed to load PropChallengeTracker:', error);
    return { default: () => <div>Error loading PropChallengeTracker</div> };
  })
);

const LoadingSkeleton = () => (
  <div className="space-y-6">
    <Skeleton className="h-32 w-full" />
    <Skeleton className="h-64 w-full" />
  </div>
);

export default function AppProp() {
  return (
    <div className="space-y-6">
      <SEOHead 
        title="Prop Firm Challenge Tracker - PipTrackr.com"
        description="Track your prop firm challenge progress and rules"
      />
      
      <div>
        <h1 className="text-3xl font-poppins font-bold text-foreground">
          Prop Metrics Tracker
        </h1>
        <p className="text-muted-foreground mt-1">
          Monitor your prop firm challenge progress and performance
        </p>
      </div>

      <Suspense fallback={<LoadingSkeleton />}>
        <PropMetricsDashboard />
      </Suspense>
      
      <Suspense fallback={<LoadingSkeleton />}>
        <PropChallengeTracker />
      </Suspense>
    </div>
  )
}