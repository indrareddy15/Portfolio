import { Routes, Route, Navigate } from "react-router-dom";
import AffiliateOverview from "./affiliate/AffiliateOverview";
import AffiliateLinks from "./affiliate/AffiliateLinks";
import AffiliateSales from "./affiliate/AffiliateSales";
import AffiliatePayouts from "./affiliate/AffiliatePayouts";
import AffiliateKyc from "./affiliate/AffiliateKyc";
import AffiliateContract from "./affiliate/AffiliateContract";
import AffiliateCreatives from "./affiliate/AffiliateCreatives";
import AffiliateSettings from "./affiliate/AffiliateSettings";

export default function AppAffiliate() {
  return (
    <Routes>
      <Route path="/overview" element={<AffiliateOverview />} />
      <Route path="/links" element={<AffiliateLinks />} />
      <Route path="/sales" element={<AffiliateSales />} />
      <Route path="/payouts" element={<AffiliatePayouts />} />
      <Route path="/kyc" element={<AffiliateKyc />} />
      <Route path="/contract" element={<AffiliateContract />} />
      <Route path="/creatives" element={<AffiliateCreatives />} />
      <Route path="/settings" element={<AffiliateSettings />} />
      <Route path="/" element={<Navigate to="/app/affiliate/overview" replace />} />
    </Routes>
  );
}