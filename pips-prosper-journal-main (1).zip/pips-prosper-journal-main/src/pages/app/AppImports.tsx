import { ImportWizard } from "@/components/ImportSystem/ImportWizard"
import { SEOHead } from "@/components/SEOHead"

export default function AppImports() {
  return (
    <div className="space-y-6">
      <SEOHead 
        title="Import Trading Data - PipTrackr.com"
        description="Import your trading data from various sources"
      />
      
      <div>
        <h1 className="text-3xl font-poppins font-bold text-foreground">
          Import Trading Data
        </h1>
        <p className="text-muted-foreground mt-1">
          Currently available: Manual CSV import • Platform integrations coming soon
        </p>
      </div>

      <ImportWizard />
    </div>
  )
}