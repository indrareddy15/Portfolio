import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Switch } from "@/components/ui/switch";
import { SEOHead } from "@/components/SEOHead";
import { 
  Grid3X3, 
  Plus, 
  Download, 
  Star, 
  Clock,
  Edit,
  Trash2,
  Eye,
  Share,
  Heart,
  TrendingUp,
  Users,
  Zap
} from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";

interface TradingTemplate {
  id: string;
  name: string;
  description: string;
  category: string;
  preview: string;
  content: any;
  is_public: boolean;
  rating: number;
  downloads: number;
  tags: string[];
  active: boolean;
  created_at: string;
  updated_at: string;
  user_id: string;
}

const categories = [
  "Strategy",
  "Scalping", 
  "Swing Trading",
  "Day Trading",
  "Risk Management",
  "News Trading",
  "Technical Analysis",
  "Fundamental Analysis"
];

const templateTags = [
  "Forex", "Crypto", "Stocks", "Options", "Futures",
  "Beginner", "Intermediate", "Advanced", "Professional",
  "High Frequency", "Low Risk", "Automated", "Manual"
];

export default function AppTemplates() {
  const [templates, setTemplates] = useState<TradingTemplate[]>([]);
  const [loading, setLoading] = useState(true);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingTemplate, setEditingTemplate] = useState<TradingTemplate | null>(null);
  const [selectedCategory, setSelectedCategory] = useState<string>("All");
  const [viewMode, setViewMode] = useState<'my' | 'public' | 'all'>('all');
  const { user } = useAuth();
  const { toast } = useToast();

  const [formData, setFormData] = useState({
    name: "",
    description: "",
    category: "Strategy",
    preview: "",
    content: {},
    is_public: false,
    tags: [] as string[]
  });

  const fetchTemplates = async () => {
    if (!user) return;

    try {
      let query = supabase.from("trading_templates").select("*");

      // Apply view mode filter
      if (viewMode === 'my') {
        query = query.eq('user_id', user.id);
      } else if (viewMode === 'public') {
        query = query.eq('is_public', true);
      } else {
        // 'all' - show user's templates + public templates
        query = query.or(`user_id.eq.${user.id},is_public.eq.true`);
      }

      query = query.eq('active', true).order('downloads', { ascending: false });

      const { data, error } = await query;

      if (error) throw error;
      setTemplates(data || []);
    } catch (error: any) {
      toast({
        variant: "destructive",
        title: "Error loading templates",
        description: error.message,
      });
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchTemplates();
  }, [user, viewMode]);

  // Real-time updates
  useEffect(() => {
    if (!user) return;

    const channel = supabase
      .channel('templates-changes')
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'trading_templates'
        },
        (payload) => {
          console.log('Template updated:', payload);
          
          if (payload.eventType === 'INSERT') {
            const newTemplate = payload.new as TradingTemplate;
            // Only add if it matches current view mode
            if ((viewMode === 'my' && newTemplate.user_id === user.id) ||
                (viewMode === 'public' && newTemplate.is_public) ||
                (viewMode === 'all' && (newTemplate.user_id === user.id || newTemplate.is_public))) {
              setTemplates(prev => [newTemplate, ...prev]);
              if (newTemplate.user_id !== user.id) {
                toast({
                  title: "New Template Available",
                  description: `${newTemplate.name} has been published`,
                });
              }
            }
          } else if (payload.eventType === 'UPDATE') {
            setTemplates(prev => prev.map(template => 
              template.id === payload.new.id ? payload.new as TradingTemplate : template
            ));
          } else if (payload.eventType === 'DELETE') {
            setTemplates(prev => prev.filter(template => template.id !== payload.old.id));
            toast({
              title: "Template Removed",
              description: "Template is no longer available",
            });
          }
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [user, viewMode, toast]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) return;

    try {
      const templateData = {
        ...formData,
        user_id: user.id,
        active: true
      };

      if (editingTemplate) {
        const { error } = await supabase
          .from("trading_templates")
          .update(templateData)
          .eq("id", editingTemplate.id);

        if (error) throw error;

        toast({
          title: "Template Updated",
          description: "Your trading template has been updated successfully.",
        });
      } else {
        const { error } = await supabase
          .from("trading_templates")
          .insert([templateData]);

        if (error) throw error;

        toast({
          title: "Template Created",
          description: "Your new trading template has been created successfully.",
        });
      }

      setIsDialogOpen(false);
      setEditingTemplate(null);
      resetForm();
    } catch (error: any) {
      toast({
        variant: "destructive",
        title: "Error saving template",
        description: error.message,
      });
    }
  };

  const handleEdit = (template: TradingTemplate) => {
    setEditingTemplate(template);
    setFormData({
      name: template.name,
      description: template.description || "",
      category: template.category,
      preview: template.preview || "",
      content: template.content,
      is_public: template.is_public,
      tags: template.tags || []
    });
    setIsDialogOpen(true);
  };

  const handleDelete = async (template: TradingTemplate) => {
    if (!confirm(`Are you sure you want to delete "${template.name}"?`)) return;

    try {
      const { error } = await supabase
        .from("trading_templates")
        .delete()
        .eq("id", template.id);

      if (error) throw error;
    } catch (error: any) {
      toast({
        variant: "destructive",
        title: "Error deleting template",
        description: error.message,
      });
    }
  };

  const handleDownload = async (template: TradingTemplate) => {
    try {
      // Increment download count
      const { error } = await supabase
        .from("trading_templates")
        .update({ downloads: template.downloads + 1 })
        .eq("id", template.id);

      if (error) throw error;

      // Create downloadable content
      const content = {
        template: template,
        downloadedAt: new Date().toISOString(),
        downloadedBy: user?.id
      };

      const blob = new Blob([JSON.stringify(content, null, 2)], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `${template.name.replace(/\s+/g, '_')}_template.json`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);

      toast({
        title: "Template Downloaded",
        description: `${template.name} has been downloaded successfully.`,
      });
    } catch (error: any) {
      toast({
        variant: "destructive",
        title: "Error downloading template",
        description: error.message,
      });
    }
  };

  const resetForm = () => {
    setFormData({
      name: "",
      description: "",
      category: "Strategy",
      preview: "",
      content: {},
      is_public: false,
      tags: []
    });
  };

  const filteredTemplates = selectedCategory === "All" 
    ? templates 
    : templates.filter(template => template.category === selectedCategory);

  const isOwnTemplate = (template: TradingTemplate) => template.user_id === user?.id;

  if (loading) {
    return (
      <div className="space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {[1, 2, 3, 4, 5, 6].map(i => (
            <Card key={i} className="glass-card border-card-border">
              <CardContent className="p-6">
                <div className="animate-pulse space-y-4">
                  <div className="h-4 bg-muted rounded"></div>
                  <div className="h-20 bg-muted rounded"></div>
                  <div className="h-4 bg-muted rounded w-1/2"></div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-8">
      <SEOHead 
        title="Trading Templates - PipTrackr.com"
        description="Real-time trading strategy templates and frameworks"
      />
      
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-poppins font-bold text-foreground flex items-center gap-3">
            <Grid3X3 className="h-8 w-8 text-primary" />
            Trading Templates
          </h1>
          <p className="text-muted-foreground mt-1">
            Real-time trading strategies and frameworks - create, share, and discover
          </p>
        </div>
        
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger asChild>
            <Button 
              variant="default"
              onClick={() => {
                setEditingTemplate(null);
                resetForm();
              }}
            >
              <Plus className="h-4 w-4 mr-2" />
              Create Template
            </Button>
          </DialogTrigger>
          
          <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle className="flex items-center gap-2">
                <Grid3X3 className="h-5 w-5 text-primary" />
                {editingTemplate ? "Edit Template" : "Create New Template"}
              </DialogTitle>
            </DialogHeader>
            
            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="name">Template Name</Label>
                  <Input
                    id="name"
                    value={formData.name}
                    onChange={(e) => setFormData(prev => ({ ...prev, name: e.target.value }))}
                    placeholder="e.g., Scalping Strategy Template"
                    required
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="category">Category</Label>
                  <Select value={formData.category} onValueChange={(value) => setFormData(prev => ({ ...prev, category: value }))}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select category" />
                    </SelectTrigger>
                    <SelectContent>
                      {categories.map((category) => (
                        <SelectItem key={category} value={category}>
                          {category}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="description">Description</Label>
                <Textarea
                  id="description"
                  value={formData.description}
                  onChange={(e) => setFormData(prev => ({ ...prev, description: e.target.value }))}
                  placeholder="Describe this template and its use cases..."
                  rows={3}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="preview">Preview Text</Label>
                <Input
                  id="preview"
                  value={formData.preview}
                  onChange={(e) => setFormData(prev => ({ ...prev, preview: e.target.value }))}
                  placeholder="Quick preview or summary..."
                />
              </div>

              <div className="flex items-center space-x-2">
                <Switch
                  id="is_public"
                  checked={formData.is_public}
                  onCheckedChange={(checked) => setFormData(prev => ({ ...prev, is_public: checked }))}
                />
                <Label htmlFor="is_public" className="flex items-center gap-2">
                  <Users className="h-4 w-4" />
                  Make this template public (share with community)
                </Label>
              </div>

              <div className="flex justify-end space-x-2">
                <Button 
                  type="button" 
                  variant="outline" 
                  onClick={() => setIsDialogOpen(false)}
                >
                  Cancel
                </Button>
                <Button type="submit" variant="default">
                  {editingTemplate ? "Update Template" : "Create Template"}
                </Button>
              </div>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      {/* View Mode Toggle */}
      <div className="flex items-center gap-4">
        <div className="flex gap-2">
          <Button 
            variant={viewMode === 'all' ? "default" : "outline"}
            size="sm"
            onClick={() => setViewMode('all')}
          >
            <Zap className="h-4 w-4 mr-1" />
            All Templates
          </Button>
          <Button 
            variant={viewMode === 'my' ? "default" : "outline"}
            size="sm"
            onClick={() => setViewMode('my')}
          >
            <Users className="h-4 w-4 mr-1" />
            My Templates
          </Button>
          <Button 
            variant={viewMode === 'public' ? "default" : "outline"}
            size="sm"
            onClick={() => setViewMode('public')}
          >
            <Share className="h-4 w-4 mr-1" />
            Community
          </Button>
        </div>
      </div>

      {/* Category Filter */}
      <div className="flex flex-wrap gap-2">
        <Button 
          variant={selectedCategory === "All" ? "default" : "outline"}
          size="sm"
          onClick={() => setSelectedCategory("All")}
        >
          All ({templates.length})
        </Button>
        {categories.map((category) => {
          const count = templates.filter(t => t.category === category).length;
          return (
            <Button 
              key={category}
              variant={selectedCategory === category ? "default" : "outline"}
              size="sm"
              onClick={() => setSelectedCategory(category)}
            >
              {category} ({count})
            </Button>
          );
        })}
      </div>

      {/* Templates Grid */}
      {filteredTemplates.length === 0 ? (
        <Card className="glass-card border-card-border">
          <CardContent className="p-12 text-center">
            <Grid3X3 className="w-16 h-16 mx-auto mb-4 text-primary opacity-50" />
            <h3 className="text-lg font-semibold mb-2">No Templates Found</h3>
            <p className="text-muted-foreground mb-6">
              {viewMode === 'my' 
                ? "You haven't created any templates yet. Create your first template to get started!"
                : "No templates available for the selected category. Try a different filter or create a new template."
              }
            </p>
            <Button onClick={() => setIsDialogOpen(true)}>
              <Plus className="w-4 h-4 mr-2" />
              Create Template
            </Button>
          </CardContent>
        </Card>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredTemplates.map((template) => (
            <Card 
              key={template.id} 
              className="group glass-card border-card-border hover:shadow-elegant transition-all duration-300"
            >
              <CardHeader className="pb-3">
                <div className="flex items-start justify-between">
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-2">
                      <Badge variant="secondary">
                        {template.category}
                      </Badge>
                      {template.is_public && (
                        <Badge variant="outline" className="text-xs">
                          <Users className="h-3 w-3 mr-1" />
                          Public
                        </Badge>
                      )}
                      {isOwnTemplate(template) && (
                        <Badge variant="outline" className="text-xs text-success">
                          <Heart className="h-3 w-3 mr-1" />
                          Mine
                        </Badge>
                      )}
                    </div>
                    <CardTitle className="text-lg font-poppins leading-tight">
                      {template.name}
                    </CardTitle>
                  </div>
                  <Grid3X3 className="h-8 w-8 text-primary flex-shrink-0" />
                </div>
              </CardHeader>
              
              <CardContent className="space-y-4">
                <p className="text-sm text-muted-foreground">
                  {template.description}
                </p>
                
                {template.preview && (
                  <div className="bg-muted/30 p-3 rounded-lg">
                    <p className="text-xs text-muted-foreground font-medium mb-1">Preview:</p>
                    <p className="text-sm">{template.preview}</p>
                  </div>
                )}
                
                <div className="flex items-center justify-between text-sm text-muted-foreground">
                  <div className="flex items-center gap-1">
                    <Star className="h-4 w-4 fill-warning text-warning" />
                    <span>{template.rating.toFixed(1)}</span>
                  </div>
                  <div className="flex items-center gap-1">
                    <Download className="h-4 w-4" />
                    <span>{template.downloads.toLocaleString()}</span>
                  </div>
                  <div className="flex items-center gap-1">
                    <Clock className="h-4 w-4" />
                    <span>{new Date(template.created_at).toLocaleDateString()}</span>
                  </div>
                </div>
                
                <div className="flex gap-1">
                  {isOwnTemplate(template) ? (
                    <>
                      <Button
                        variant="outline"
                        size="sm"
                        className="flex-1"
                        onClick={() => handleEdit(template)}
                      >
                        <Edit className="h-3 w-3 mr-1" />
                        Edit
                      </Button>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => handleDelete(template)}
                        className="text-destructive hover:text-destructive"
                      >
                        <Trash2 className="h-3 w-3" />
                      </Button>
                    </>
                  ) : (
                    <>
                      <Button variant="outline" size="sm" className="flex-1">
                        <Eye className="h-3 w-3 mr-1" />
                        Preview
                      </Button>
                      <Button 
                        size="sm" 
                        className="flex-1"
                        onClick={() => handleDownload(template)}
                      >
                        <Download className="h-3 w-3 mr-1" />
                        Use Template
                      </Button>
                    </>
                  )}
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      {/* Quick Stats */}
      {templates.length > 0 && (
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
          <Card className="glass-card border-card-border">
            <CardContent className="p-4 text-center">
              <div className="text-2xl font-bold text-foreground">{templates.length}</div>
              <div className="text-sm text-muted-foreground">Total Templates</div>
            </CardContent>
          </Card>
          <Card className="glass-card border-card-border">
            <CardContent className="p-4 text-center">
              <div className="text-2xl font-bold text-success">
                {templates.filter(t => t.user_id === user?.id).length}
              </div>
              <div className="text-sm text-muted-foreground">My Templates</div>
            </CardContent>
          </Card>
          <Card className="glass-card border-card-border">
            <CardContent className="p-4 text-center">
              <div className="text-2xl font-bold text-primary">
                {templates.filter(t => t.is_public).length}
              </div>
              <div className="text-sm text-muted-foreground">Public Templates</div>
            </CardContent>
          </Card>
          <Card className="glass-card border-card-border">
            <CardContent className="p-4 text-center">
              <div className="text-2xl font-bold text-warning">
                {templates.reduce((sum, t) => sum + t.downloads, 0)}
              </div>
              <div className="text-sm text-muted-foreground">Total Downloads</div>
            </CardContent>
          </Card>
        </div>
      )}
    </div>
  );
}