import { useState, useEffect, useCallback } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { DashboardCharts } from "@/components/Charts/DashboardCharts";
import { RealTimeEquityChart } from "@/components/RealTimeEquityChart";
import { QuickActions } from "@/components/QuickActions";
import { SEOHead } from "@/components/SEOHead";
import { RealTimeMetricsCards } from "@/components/RealTimeMetricsCards";
import { StrategyPerformanceTable } from "@/components/Strategy/StrategyPerformanceTable";
import { StrategyFilteredMetrics } from "@/components/Dashboard/StrategyFilteredMetrics";
import { DashboardTradingCalendar } from "@/components/DashboardTradingCalendar";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/useAuth";
import { supabase } from "@/integrations/supabase/client";
import { 
  TrendingUp, 
  DollarSign, 
  Target,
  Activity,
  RefreshCw,
  TrendingDown,
  Wifi,
  WifiOff
} from "lucide-react";
import { useNavigate } from "react-router-dom";

export default function AppDashboard() {
  const [selectedStrategy, setSelectedStrategy] = useState<string | null>(null);
  const [isRealTimeConnected, setIsRealTimeConnected] = useState(false);
  const [lastUpdate, setLastUpdate] = useState(new Date());
  const [tradesData, setTradesData] = useState<any[]>([]);
  const [accountsData, setAccountsData] = useState<any[]>([]);
  const [marketData, setMarketData] = useState({
    sp500: { value: 4567.89, change: 1.2, changeValue: 54.23 },
    nasdaq: { value: 15234.67, change: -0.8, changeValue: -123.45 },
    usdeur: { value: 1.0894, change: 0.3, changeValue: 0.0032 }
  });
  const [todaysStats, setTodaysStats] = useState({
    pnl: 0,
    trades: { completed: 0, total: 0 },
    winRate: 0,
    portfolio: 0
  });
  const { toast } = useToast();
  const { user } = useAuth();
  const navigate = useNavigate();

  // Load initial data
  const loadTrades = useCallback(async () => {
    if (!user?.id) return;
    
    try {
      const { data, error } = await supabase
        .from('trades')
        .select('*')
        .eq('user_id', user.id)
        .order('opened_at', { ascending: false });
      
      if (error) throw error;
      setTradesData(data || []);
    } catch (error) {
      console.error('Error loading trades:', error);
    }
  }, [user?.id]);

  const loadAccounts = useCallback(async () => {
    if (!user?.id) return;
    
    try {
      const { data, error } = await supabase
        .from('accounts')
        .select('*')
        .eq('user_id', user.id)
        .eq('archived', false);
      
      if (error) throw error;
      setAccountsData(data || []);
    } catch (error) {
      console.error('Error loading accounts:', error);
    }
  }, [user?.id]);

  // Calculate real-time today's stats from actual data
  const calculateTodaysStats = useCallback(() => {
    if (!tradesData || tradesData.length === 0) {
      setTodaysStats({
        pnl: 0,
        trades: { completed: 0, total: 0 },
        winRate: 0,
        portfolio: accountsData?.reduce((sum, account) => sum + (account.balance || 0), 0) || 0
      });
      return;
    }
    
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    
    const todaysTrades = tradesData.filter(trade => {
      const tradeDate = new Date(trade.opened_at);
      return tradeDate >= today;
    });

    const completedTrades = todaysTrades.filter(trade => trade.closed_at);
    const totalPnl = completedTrades.reduce((sum, trade) => sum + (trade.pnl || 0), 0);
    const winningTrades = completedTrades.filter(trade => (trade.pnl || 0) > 0);
    const winRate = completedTrades.length > 0 ? (winningTrades.length / completedTrades.length) * 100 : 0;
    
    const totalPortfolio = accountsData?.reduce((sum, account) => sum + (account.balance || 0), 0) || 0;

    setTodaysStats({
      pnl: totalPnl,
      trades: { completed: completedTrades.length, total: todaysTrades.length },
      winRate: Math.round(winRate),
      portfolio: totalPortfolio
    });
    setLastUpdate(new Date());
  }, [tradesData, accountsData]);

  // Real-time market data simulation
  const updateMarketData = useCallback(() => {
    setMarketData(prev => ({
      sp500: {
        ...prev.sp500,
        value: prev.sp500.value + (Math.random() - 0.5) * 10,
        change: prev.sp500.change + (Math.random() - 0.5) * 0.5
      },
      nasdaq: {
        ...prev.nasdaq,
        value: prev.nasdaq.value + (Math.random() - 0.5) * 50,
        change: prev.nasdaq.change + (Math.random() - 0.5) * 0.3
      },
      usdeur: {
        ...prev.usdeur,
        value: prev.usdeur.value + (Math.random() - 0.5) * 0.01,
        change: prev.usdeur.change + (Math.random() - 0.5) * 0.1
      }
    }));
    setLastUpdate(new Date());
  }, []);

  const refreshMarketData = () => {
    updateMarketData();
    toast({
      title: "Market Data Refreshed",
      description: "Real-time market data has been updated",
      duration: 2000,
    });
  };

  const refreshAllData = async () => {
    setLastUpdate(new Date());
    await Promise.all([
      loadTrades(),
      loadAccounts()
    ]);
    updateMarketData();
    toast({
      title: "Dashboard Refreshed",
      description: "All data has been updated successfully",
      duration: 2000,
    });
  };

  // Load initial data on mount
  useEffect(() => {
    loadTrades();
    loadAccounts();
  }, [loadTrades, loadAccounts]);

  // Real-time database subscription for trades
  useEffect(() => {
    if (!user?.id) return;

    const channel = supabase
      .channel(`dashboard-realtime-${user.id}`)
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'trades',
          filter: `user_id=eq.${user.id}`
        },
        (payload) => {
          console.log('Real-time trade update:', payload);
          loadTrades(); // Reload trades to get fresh data
          
          // Show toast for new trades
          if (payload.eventType === 'INSERT') {
            toast({
              title: "New Trade Added",
              description: `Trade for ${payload.new.instrument} has been recorded`,
              duration: 3000,
            });
          }
        }
      )
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'accounts',
          filter: `user_id=eq.${user.id}`
        },
        (payload) => {
          console.log('Real-time account update:', payload);
          loadAccounts(); // Reload accounts to get fresh data
        }
      )
      .subscribe((status) => {
        if (status === 'SUBSCRIBED') {
          setIsRealTimeConnected(true);
          console.log('Real-time dashboard connection established');
          toast({
            title: "Real-time Connected",
            description: "Live data updates are now active",
            duration: 2000,
          });
        } else if (status === 'CHANNEL_ERROR') {
          setIsRealTimeConnected(false);
          console.error('Real-time dashboard connection failed');
        }
      });

    return () => {
      supabase.removeChannel(channel);
      setIsRealTimeConnected(false);
    };
  }, [user?.id, loadTrades, loadAccounts, toast]);

  // Auto-update market data every 3 seconds
  useEffect(() => {
    const interval = setInterval(updateMarketData, 3000);
    return () => clearInterval(interval);
  }, [updateMarketData]);

  // Calculate today's stats when data changes
  useEffect(() => {
    calculateTodaysStats();
  }, [calculateTodaysStats]);

  return (
    <div className="space-y-4 sm:space-y-6 lg:space-y-8 animate-fade-in">
      <SEOHead 
        title="Trading Dashboard - PipTrackr.com"
        description="Your comprehensive trading dashboard overview"
      />

      {/* Dashboard Header with Refresh Button */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-4 sm:p-6 bg-card/50 backdrop-blur-sm rounded-xl border border-border/50">
        <div className="space-y-1">
          <h1 className="text-xl sm:text-2xl lg:text-3xl font-bold text-foreground">
            Trading Dashboard
          </h1>
          <p className="text-sm text-muted-foreground">
            Real-time overview of your trading performance
          </p>
        </div>
        
        <div className="flex items-center gap-2 sm:gap-3">
          {/* Real-time Status Indicator */}
          <div className="flex items-center gap-2 px-3 py-1.5 rounded-lg border">
            {isRealTimeConnected ? (
              <>
                <div className="w-2 h-2 bg-success rounded-full animate-pulse" />
                <span className="text-xs font-medium text-success hidden sm:inline">LIVE</span>
              </>
            ) : (
              <>
                <div className="w-2 h-2 bg-danger rounded-full" />
                <span className="text-xs font-medium text-danger hidden sm:inline">OFFLINE</span>
              </>
            )}
          </div>
          
          {/* Last Update Time */}
          <div className="hidden md:block text-xs text-muted-foreground">
            Last: {lastUpdate.toLocaleTimeString()}
          </div>
          
          {/* Refresh Button */}
          <Button
            onClick={refreshAllData}
            variant="outline"
            size="sm"
            className="gap-2 hover:bg-primary hover:text-primary-foreground transition-all duration-200"
          >
            <RefreshCw className="h-4 w-4" />
            <span className="hidden sm:inline">Refresh</span>
          </Button>
        </div>
      </div>

      {/* Hero Dashboard Section */}
      <div className="relative overflow-hidden rounded-xl sm:rounded-2xl bg-gradient-to-br from-primary via-primary-dark to-secondary p-3 sm:p-6 lg:p-8 text-white animate-fade-in">
        <div className="absolute inset-0 bg-gradient-to-r from-primary/20 to-transparent animate-pulse" />
        <div className="absolute inset-0 bg-gradient-to-l from-secondary/10 via-transparent to-primary/10 animate-[shimmer_3s_ease-in-out_infinite]" />
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_50%,rgba(255,255,255,0.1),transparent_70%)] animate-[pulse_4s_ease-in-out_infinite]" />
        <div className="absolute top-0 right-0 w-32 h-32 sm:w-64 sm:h-64 bg-white/5 rounded-full -translate-y-16 sm:-translate-y-32 translate-x-16 sm:translate-x-32" />
        <div className="absolute bottom-0 left-0 w-24 h-24 sm:w-48 sm:h-48 bg-white/5 rounded-full translate-y-12 sm:translate-y-24 -translate-x-12 sm:-translate-x-24" />
        
        <div className="relative z-10 grid grid-cols-1 lg:grid-cols-3 gap-4 sm:gap-6 lg:gap-8 items-center">
          {/* Left Content */}
          <div className="lg:col-span-2 space-y-3 sm:space-y-4 lg:space-y-6">
            <div className="space-y-2">
              <Badge className="bg-white/20 text-white border-white/30 mb-2 text-xs sm:text-sm">
                Professional Trader Dashboard
              </Badge>
              <h2 className="text-xl sm:text-2xl lg:text-3xl xl:text-4xl font-poppins font-bold leading-tight">
                Master Your Trading Journey
              </h2>
              <p className="text-sm sm:text-base lg:text-lg text-white/90 leading-relaxed">
                Track performance, analyze patterns, and execute winning strategies with our comprehensive trading platform.
              </p>
            </div>
          </div>
          
          {/* Right Content - Live Stats */}
          <div className="space-y-3 lg:space-y-4 animate-fade-in">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
              <div className="flex flex-col sm:flex-row sm:items-center gap-2 sm:gap-3">
                <h3 className="text-base sm:text-lg lg:text-xl font-poppins font-semibold text-white/95">Today's Performance</h3>
                <div className="flex items-center gap-2">
                  {isRealTimeConnected ? (
                    <div className="flex items-center gap-1.5 px-2 py-1 bg-success/20 rounded-lg border border-success/30">
                      <Wifi className="h-3 w-3 text-success animate-pulse" />
                      <span className="text-xs text-success font-medium">LIVE</span>
                    </div>
                  ) : (
                    <div className="flex items-center gap-1.5 px-2 py-1 bg-danger/20 rounded-lg border border-danger/30">
                      <WifiOff className="h-3 w-3 text-danger" />
                      <span className="text-xs text-danger font-medium">OFFLINE</span>
                    </div>
                  )}
                  <span className="text-xs text-white/60 hidden sm:inline">
                    {lastUpdate.toLocaleTimeString()}
                  </span>
                </div>
              </div>
              <Button 
                variant="ghost" 
                size="sm" 
                className="text-white/80 hover:text-white hover:bg-white/10 p-2 self-start sm:self-auto"
                onClick={refreshAllData}
              >
                <RefreshCw className="h-3 w-3 sm:h-4 sm:w-4" />
              </Button>
            </div>
            <div className="grid grid-cols-2 gap-2 sm:gap-3 lg:gap-4">
              <div 
                className="bg-white/10 backdrop-blur-sm rounded-xl p-3 lg:p-4 border border-white/20 hover:bg-white/20 transition-all duration-300 cursor-pointer hover:scale-105 animate-scale-in"
                onClick={() => navigate('/app/analytics')}
                aria-label="View detailed analytics"
              >
                <div className="flex items-center gap-2 lg:gap-3">
                  <div className={`p-1.5 lg:p-2 rounded-lg transition-all duration-500 ${todaysStats.pnl >= 0 ? 'bg-success/20 animate-pulse' : 'bg-danger/20'}`}>
                    {todaysStats.pnl >= 0 ? 
                      <TrendingUp className="h-3 w-3 sm:h-4 sm:w-4 lg:h-5 lg:w-5 text-white animate-bounce" /> : 
                      <TrendingDown className="h-3 w-3 sm:h-4 sm:w-4 lg:h-5 lg:w-5 text-white animate-bounce" />
                    }
                  </div>
                  <div className="min-w-0">
                    <p className="text-xs sm:text-sm text-white/80 truncate">Today's P&L</p>
                    <p className={`text-sm sm:text-lg lg:text-xl font-bold truncate transition-all duration-500 ${todaysStats.pnl >= 0 ? 'text-white animate-pulse' : 'text-red-200'}`}>
                      {todaysStats.pnl >= 0 ? '+' : ''}${todaysStats.pnl.toLocaleString()}
                    </p>
                  </div>
                </div>
              </div>
              
              <div className="bg-white/10 backdrop-blur-sm rounded-xl p-3 lg:p-4 border border-white/20 hover:bg-white/20 transition-all duration-300 cursor-pointer hover:scale-105 animate-scale-in" onClick={() => navigate('/app/journal')} aria-label="Open Journal">
                <div className="flex items-center gap-2 lg:gap-3">
                  <div className="p-1.5 lg:p-2 bg-warning/20 rounded-lg animate-pulse">
                    <Activity className="h-3 w-3 sm:h-4 sm:w-4 lg:h-5 lg:w-5 text-white" />
                  </div>
                  <div className="min-w-0">
                    <p className="text-xs sm:text-sm text-white/80 truncate">Trades</p>
                    <p className="text-sm sm:text-lg lg:text-xl font-bold text-white truncate animate-fade-in">
                      {todaysStats.trades.completed} / {todaysStats.trades.total}
                    </p>
                  </div>
                </div>
              </div>
              
              <div className="bg-white/10 backdrop-blur-sm rounded-xl p-3 lg:p-4 border border-white/20 hover:bg-white/20 transition-all duration-300 cursor-pointer hover:scale-105 animate-scale-in" onClick={() => navigate('/app/analytics/overview')} aria-label="View Win Rate Analytics">
                <div className="flex items-center gap-2 lg:gap-3">
                  <div className="p-1.5 lg:p-2 bg-info/20 rounded-lg animate-pulse">
                    <Target className="h-3 w-3 sm:h-4 sm:w-4 lg:h-5 lg:w-5 text-white" />
                  </div>
                  <div className="min-w-0">
                    <p className="text-xs sm:text-sm text-white/80 truncate">Win Rate</p>
                    <p className="text-sm sm:text-lg lg:text-xl font-bold text-white truncate animate-fade-in">{todaysStats.winRate}%</p>
                  </div>
                </div>
              </div>
              
              <div className="bg-white/10 backdrop-blur-sm rounded-xl p-3 lg:p-4 border border-white/20 hover:bg-white/20 transition-all duration-300 cursor-pointer hover:scale-105 animate-scale-in" onClick={() => navigate('/app/settings/accounts')} aria-label="Manage Accounts">
                <div className="flex items-center gap-2 lg:gap-3">
                  <div className="p-1.5 lg:p-2 bg-accent/20 rounded-lg animate-pulse">
                    <DollarSign className="h-3 w-3 sm:h-4 sm:w-4 lg:h-5 lg:w-5 text-white" />
                  </div>
                  <div className="min-w-0">
                    <p className="text-xs sm:text-sm text-white/80 truncate">Portfolio</p>
                    <p className="text-sm sm:text-lg lg:text-xl font-bold text-white truncate animate-fade-in">
                      ${(todaysStats.portfolio / 1000).toFixed(1)}K
                    </p>
                  </div>
                </div>
              </div>
            </div>
            
            {/* Enhanced Real-time Market Ticker */}
            <div className="bg-white/10 backdrop-blur-sm rounded-xl p-3 lg:p-4 border border-white/20 animate-fade-in">
              <div className="flex items-center justify-between text-xs sm:text-sm mb-2">
                <span className="text-white/80">Market Status:</span>
                <div className="flex items-center gap-2">
                  <div className="h-1.5 w-1.5 sm:h-2 sm:w-2 bg-success rounded-full animate-pulse"></div>
                  <span className="text-white font-medium">Open</span>
                  <span className="text-white/60 text-xs ml-2">
                    Last: {lastUpdate.toLocaleTimeString()}
                  </span>
                </div>
              </div>
              <div className="space-y-1 lg:space-y-2 text-xs">
                <div className="flex justify-between items-center animate-fade-in">
                  <span className="text-white/70">S&P 500</span>
                  <div className="flex items-center gap-2">
                    <span className="text-white text-right animate-shimmer">{marketData.sp500.value.toLocaleString()}</span>
                    <span className={`text-right min-w-0 transition-all duration-500 ${marketData.sp500.change >= 0 ? 'text-green-300 animate-pulse' : 'text-red-300 animate-pulse'}`}>
                      {marketData.sp500.change >= 0 ? '+' : ''}{marketData.sp500.change.toFixed(1)}%
                    </span>
                  </div>
                </div>
                <div className="flex justify-between items-center animate-fade-in">
                  <span className="text-white/70">NASDAQ</span>
                  <div className="flex items-center gap-2">
                    <span className="text-white text-right animate-shimmer">{marketData.nasdaq.value.toLocaleString()}</span>
                    <span className={`text-right min-w-0 transition-all duration-500 ${marketData.nasdaq.change >= 0 ? 'text-green-300 animate-pulse' : 'text-red-300 animate-pulse'}`}>
                      {marketData.nasdaq.change >= 0 ? '+' : ''}{marketData.nasdaq.change.toFixed(1)}%
                    </span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Strategy Performance Overview */}
      <StrategyPerformanceTable 
        onStrategySelect={setSelectedStrategy}
        selectedStrategy={selectedStrategy}
      />

      {/* Strategy Filtered Metrics */}
      <StrategyFilteredMetrics selectedStrategy={selectedStrategy} />
      
      {/* Real-time Metrics Cards */}
      <RealTimeMetricsCards />
      
      {/* Real-time Equity Chart */}
      <RealTimeEquityChart />
      
      {/* Enhanced Dashboard Charts */}
      <DashboardCharts />

      {/* Real-time Trading Summary & Quick Actions */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4 sm:gap-6 lg:gap-8">
        <div className="lg:col-span-8">
          <Card className="border-border/50 bg-card/80 backdrop-blur-sm shadow-lg h-full">
            <CardHeader className="pb-4">
              <div className="flex items-center justify-between">
                <CardTitle className="text-xl font-poppins flex items-center gap-2">
                  <Activity className="h-5 w-5 text-primary" />
                  Live Trading Summary
                </CardTitle>
                <div className="flex items-center gap-2">
                  {isRealTimeConnected ? (
                    <Badge variant="secondary" className="text-xs bg-success/10 text-success border-success/20 animate-pulse">
                      <div className="h-1.5 w-1.5 bg-success rounded-full mr-1 animate-ping" />
                      Real-time Active
                    </Badge>
                  ) : (
                    <Badge variant="secondary" className="text-xs bg-danger/10 text-danger border-danger/20">
                      <WifiOff className="h-3 w-3 mr-1" />
                      Offline
                    </Badge>
                  )}
                </div>
              </div>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="space-y-4">
                  <div className="flex items-center justify-between p-4 bg-muted/50 rounded-lg border">
                    <div className="flex items-center gap-3">
                      <div className={`p-2 rounded-lg transition-all duration-300 ${todaysStats.pnl >= 0 ? 'bg-success/10 animate-pulse' : 'bg-danger/10'}`}>
                        {todaysStats.pnl >= 0 ? 
                          <TrendingUp className="h-4 w-4 text-success" /> : 
                          <TrendingDown className="h-4 w-4 text-danger" />
                        }
                      </div>
                      <div>
                        <p className="text-sm text-muted-foreground">Today's P&L</p>
                        <p className={`text-lg font-bold transition-all duration-300 ${todaysStats.pnl >= 0 ? 'text-success animate-pulse' : 'text-danger'}`}>
                          {todaysStats.pnl >= 0 ? '+' : ''}${todaysStats.pnl.toLocaleString()}
                        </p>
                      </div>
                    </div>
                  </div>
                  
                  <div className="flex items-center justify-between p-4 bg-muted/50 rounded-lg border">
                    <div className="flex items-center gap-3">
                      <div className="p-2 bg-warning/10 rounded-lg">
                        <Activity className="h-4 w-4 text-warning" />
                      </div>
                      <div>
                        <p className="text-sm text-muted-foreground">Active Trades</p>
                        <p className="text-lg font-bold animate-fade-in">
                          {tradesData.filter(t => !t.closed_at).length} / {tradesData.length}
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
                
                <div className="space-y-4">
                  <div className="flex items-center justify-between p-4 bg-muted/50 rounded-lg border">
                    <div className="flex items-center gap-3">
                      <div className="p-2 bg-info/10 rounded-lg">
                        <Target className="h-4 w-4 text-info" />
                      </div>
                      <div>
                        <p className="text-sm text-muted-foreground">Win Rate</p>
                        <p className="text-lg font-bold animate-fade-in">{todaysStats.winRate}%</p>
                      </div>
                    </div>
                  </div>
                  
                  <div className="flex items-center justify-between p-4 bg-muted/50 rounded-lg border">
                    <div className="flex items-center gap-3">
                      <div className="p-2 bg-accent/10 rounded-lg">
                        <DollarSign className="h-4 w-4 text-accent" />
                      </div>
                      <div>
                        <p className="text-sm text-muted-foreground">Portfolio Value</p>
                        <p className="text-lg font-bold animate-fade-in">
                          ${(todaysStats.portfolio / 1000).toFixed(1)}K
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              
              <div className="flex items-center gap-2 text-xs text-muted-foreground">
                <div className="h-1.5 w-1.5 bg-success rounded-full animate-pulse" />
                <span>Last updated: {lastUpdate.toLocaleTimeString()}</span>
                <span className="mx-2">•</span>
                <span>{accountsData.length} Account{accountsData.length !== 1 ? 's' : ''} Connected</span>
              </div>
            </CardContent>
          </Card>
        </div>
        
        <div className="lg:col-span-4">
          <QuickActions />
        </div>
      </div>

      {/* Real-time Overview Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 lg:gap-6">
        <Card className="border-border/50 bg-card/80 backdrop-blur-sm shadow-lg hover:shadow-xl transition-all duration-300 hover:scale-105 relative overflow-hidden">
          <div className="absolute inset-0 bg-gradient-to-br from-success/5 to-transparent" />
          <CardContent className="p-4 lg:p-6 relative">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Total Trades</p>
                <p className="text-xl lg:text-2xl font-bold animate-fade-in">{tradesData.length}</p>
              </div>
              <div className="p-2 lg:p-3 bg-success/10 rounded-lg animate-pulse">
                <Activity className="h-5 w-5 lg:h-6 lg:w-6 text-success" />
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card className="border-border/50 bg-card/80 backdrop-blur-sm shadow-lg hover:shadow-xl transition-all duration-300 hover:scale-105 relative overflow-hidden">
          <div className="absolute inset-0 bg-gradient-to-br from-info/5 to-transparent" />
          <CardContent className="p-4 lg:p-6 relative">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Winning Trades</p>
                <p className="text-xl lg:text-2xl font-bold text-info animate-fade-in">
                  {tradesData.filter(t => t.closed_at && (t.pnl || 0) > 0).length}
                </p>
              </div>
              <div className="p-2 lg:p-3 bg-info/10 rounded-lg animate-pulse">
                <Target className="h-5 w-5 lg:h-6 lg:w-6 text-info" />
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card className="border-border/50 bg-card/80 backdrop-blur-sm shadow-lg hover:shadow-xl transition-all duration-300 hover:scale-105 relative overflow-hidden">
          <div className="absolute inset-0 bg-gradient-to-br from-warning/5 to-transparent" />
          <CardContent className="p-4 lg:p-6 relative">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Active Accounts</p>
                <p className="text-xl lg:text-2xl font-bold text-warning animate-fade-in">{accountsData.length}</p>
              </div>
              <div className="p-2 lg:p-3 bg-warning/10 rounded-lg animate-pulse">
                <DollarSign className="h-5 w-5 lg:h-6 lg:w-6 text-warning" />
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card className="border-border/50 bg-card/80 backdrop-blur-sm shadow-lg hover:shadow-xl transition-all duration-300 hover:scale-105 relative overflow-hidden">
          <div className={`absolute inset-0 bg-gradient-to-br ${todaysStats.pnl >= 0 ? 'from-success/5' : 'from-danger/5'} to-transparent`} />
          <CardContent className="p-4 lg:p-6 relative">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Total P&L</p>
                <p className={`text-xl lg:text-2xl font-bold animate-fade-in transition-all duration-300 ${
                  tradesData.filter(t => t.closed_at).reduce((sum, t) => sum + (t.pnl || 0), 0) >= 0 ? 'text-success' : 'text-danger'
                }`}>
                  {tradesData.filter(t => t.closed_at).reduce((sum, t) => sum + (t.pnl || 0), 0) >= 0 ? '+' : ''}
                  ${tradesData.filter(t => t.closed_at).reduce((sum, t) => sum + (t.pnl || 0), 0).toLocaleString()}
                </p>
              </div>
              <div className={`p-2 lg:p-3 rounded-lg animate-pulse ${
                tradesData.filter(t => t.closed_at).reduce((sum, t) => sum + (t.pnl || 0), 0) >= 0 ? 'bg-success/10' : 'bg-danger/10'
              }`}>
                {tradesData.filter(t => t.closed_at).reduce((sum, t) => sum + (t.pnl || 0), 0) >= 0 ? 
                  <TrendingUp className="h-5 w-5 lg:h-6 lg:w-6 text-success" /> : 
                  <TrendingDown className="h-5 w-5 lg:h-6 lg:w-6 text-danger" />
                }
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
      
      {/* Trading Calendar Section */}
      <DashboardTradingCalendar />
    </div>
  );
}