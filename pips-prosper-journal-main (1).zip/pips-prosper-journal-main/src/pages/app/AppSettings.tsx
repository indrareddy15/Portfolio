import { Suspense, lazy } from "react"
import { Skeleton } from "@/components/ui/skeleton"
import { SEOHead } from "@/components/SEOHead"
import { OnboardingSettings } from "@/components/Settings/OnboardingSettings"

const AccountSettings = lazy(() => 
  import("@/components/Settings/AccountSettings").then(module => ({ default: module.AccountSettings }))
  .catch(error => {
    console.error('Failed to load AccountSettings:', error);
    return { default: () => <div>Error loading AccountSettings</div> };
  })
);

const LoadingSkeleton = () => (
  <div className="space-y-6">
    <Skeleton className="h-32 w-full" />
    <Skeleton className="h-64 w-full" />
  </div>
);

export default function AppSettings() {
  return (
    <div className="space-y-6">
      <SEOHead 
        title="Account Settings - PipTrackr.com"
        description="Manage your account settings and preferences"
      />
      
      <div>
        <h1 className="text-3xl font-poppins font-bold text-foreground">
          Account Settings
        </h1>
        <p className="text-muted-foreground mt-1">
          Manage your profile, preferences, and account configuration
        </p>
      </div>

      {/* Onboarding Settings */}
      <OnboardingSettings />

      {/* Account Settings */}
      <Suspense fallback={<LoadingSkeleton />}>
        <AccountSettings />
      </Suspense>
    </div>
  )
}