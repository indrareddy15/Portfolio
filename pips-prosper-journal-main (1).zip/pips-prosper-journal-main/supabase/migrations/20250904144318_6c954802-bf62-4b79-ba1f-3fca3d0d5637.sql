-- Enable RLS on tables that are missing it
ALTER TABLE public.instrument_stats ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.session_stats ENABLE ROW LEVEL SECURITY;