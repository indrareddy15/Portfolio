-- Create polls table
CREATE TABLE public.blog_polls (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  post_id UUID REFERENCES public.blog_posts(id) ON DELETE CASCADE,
  title TEXT NOT NULL,
  description TEXT,
  poll_type TEXT NOT NULL DEFAULT 'single' CHECK (poll_type IN ('single', 'multiple')),
  options_json JSONB NOT NULL DEFAULT '[]'::jsonb,
  allow_custom_answers BOOLEAN DEFAULT false,
  expires_at TIMESTAMP WITH TIME ZONE,
  is_active BOOLEAN DEFAULT true,
  total_votes INTEGER DEFAULT 0,
  position INTEGER DEFAULT 0,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS on polls
ALTER TABLE public.blog_polls ENABLE ROW LEVEL SECURITY;

-- Create policies for polls
CREATE POLICY "Anyone can view active polls in published posts"
ON public.blog_polls FOR SELECT
USING (
  is_active = true AND 
  EXISTS (
    SELECT 1 FROM public.blog_posts 
    WHERE id = post_id 
    AND status = 'published' 
    AND (publish_at IS NULL OR publish_at <= now())
  )
);

CREATE POLICY "Admins can manage all polls"
ON public.blog_polls FOR ALL
USING (has_role(auth.uid(), 'admin'::app_role))
WITH CHECK (has_role(auth.uid(), 'admin'::app_role));

-- Create poll votes table
CREATE TABLE public.blog_poll_votes (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  poll_id UUID NOT NULL REFERENCES public.blog_polls(id) ON DELETE CASCADE,
  user_id UUID,
  selected_options JSONB NOT NULL DEFAULT '[]'::jsonb,
  custom_answer TEXT,
  ip_address INET,
  user_agent TEXT,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS on poll votes
ALTER TABLE public.blog_poll_votes ENABLE ROW LEVEL SECURITY;

-- Create policies for poll votes
CREATE POLICY "Anyone can vote on polls"
ON public.blog_poll_votes FOR INSERT
WITH CHECK (true);

CREATE POLICY "Users can view their own votes"
ON public.blog_poll_votes FOR SELECT
USING (
  auth.uid() = user_id OR 
  (auth.uid() IS NULL AND ip_address = inet_client_addr())
);

CREATE POLICY "Admins can view all poll votes"
ON public.blog_poll_votes FOR SELECT
USING (has_role(auth.uid(), 'admin'::app_role));

-- Create Q&A table
CREATE TABLE public.blog_qna (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  post_id UUID REFERENCES public.blog_posts(id) ON DELETE CASCADE,
  title TEXT NOT NULL,
  description TEXT,
  is_active BOOLEAN DEFAULT true,
  allow_anonymous BOOLEAN DEFAULT true,
  moderated BOOLEAN DEFAULT true,
  position INTEGER DEFAULT 0,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS on Q&A
ALTER TABLE public.blog_qna ENABLE ROW LEVEL SECURITY;

-- Create policies for Q&A
CREATE POLICY "Anyone can view active Q&A in published posts"
ON public.blog_qna FOR SELECT
USING (
  is_active = true AND 
  EXISTS (
    SELECT 1 FROM public.blog_posts 
    WHERE id = post_id 
    AND status = 'published' 
    AND (publish_at IS NULL OR publish_at <= now())
  )
);

CREATE POLICY "Admins can manage all Q&A"
ON public.blog_qna FOR ALL
USING (has_role(auth.uid(), 'admin'::app_role))
WITH CHECK (has_role(auth.uid(), 'admin'::app_role));

-- Create Q&A questions table
CREATE TABLE public.blog_qna_questions (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  qna_id UUID NOT NULL REFERENCES public.blog_qna(id) ON DELETE CASCADE,
  user_id UUID,
  author_name TEXT,
  author_email TEXT,
  question TEXT NOT NULL,
  is_approved BOOLEAN DEFAULT false,
  is_featured BOOLEAN DEFAULT false,
  upvotes INTEGER DEFAULT 0,
  ip_address INET,
  user_agent TEXT,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS on Q&A questions
ALTER TABLE public.blog_qna_questions ENABLE ROW LEVEL SECURITY;

-- Create policies for Q&A questions
CREATE POLICY "Anyone can submit questions"
ON public.blog_qna_questions FOR INSERT
WITH CHECK (true);

CREATE POLICY "Anyone can view approved questions"
ON public.blog_qna_questions FOR SELECT
USING (is_approved = true);

CREATE POLICY "Users can view their own questions"
ON public.blog_qna_questions FOR SELECT
USING (auth.uid() = user_id);

CREATE POLICY "Admins can manage all questions"
ON public.blog_qna_questions FOR ALL
USING (has_role(auth.uid(), 'admin'::app_role))
WITH CHECK (has_role(auth.uid(), 'admin'::app_role));

-- Create Q&A answers table
CREATE TABLE public.blog_qna_answers (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  question_id UUID NOT NULL REFERENCES public.blog_qna_questions(id) ON DELETE CASCADE,
  author_id UUID REFERENCES public.blog_authors(id),
  answer TEXT NOT NULL,
  is_official BOOLEAN DEFAULT false,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS on Q&A answers
ALTER TABLE public.blog_qna_answers ENABLE ROW LEVEL SECURITY;

-- Create policies for Q&A answers
CREATE POLICY "Anyone can view answers to approved questions"
ON public.blog_qna_answers FOR SELECT
USING (
  EXISTS (
    SELECT 1 FROM public.blog_qna_questions 
    WHERE id = question_id AND is_approved = true
  )
);

CREATE POLICY "Admins can manage all answers"
ON public.blog_qna_answers FOR ALL
USING (has_role(auth.uid(), 'admin'::app_role))
WITH CHECK (has_role(auth.uid(), 'admin'::app_role));

-- Create indexes for better performance
CREATE INDEX idx_blog_polls_post_id ON public.blog_polls(post_id);
CREATE INDEX idx_blog_poll_votes_poll_id ON public.blog_poll_votes(poll_id);
CREATE INDEX idx_blog_poll_votes_user_id ON public.blog_poll_votes(user_id);
CREATE INDEX idx_blog_qna_post_id ON public.blog_qna(post_id);
CREATE INDEX idx_blog_qna_questions_qna_id ON public.blog_qna_questions(qna_id);
CREATE INDEX idx_blog_qna_questions_approved ON public.blog_qna_questions(is_approved);
CREATE INDEX idx_blog_qna_answers_question_id ON public.blog_qna_answers(question_id);

-- Create triggers for updated_at
CREATE TRIGGER update_blog_polls_updated_at
  BEFORE UPDATE ON public.blog_polls
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_blog_qna_updated_at
  BEFORE UPDATE ON public.blog_qna
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_blog_qna_questions_updated_at
  BEFORE UPDATE ON public.blog_qna_questions
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_blog_qna_answers_updated_at
  BEFORE UPDATE ON public.blog_qna_answers
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at_column();