-- Enable real-time for logo_settings table
ALTER TABLE public.logo_settings REPLICA IDENTITY FULL;

-- Add logo_settings to realtime publication
DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_publication_tables 
        WHERE pubname = 'supabase_realtime' 
        AND tablename = 'logo_settings'
    ) THEN
        ALTER PUBLICATION supabase_realtime ADD TABLE public.logo_settings;
    END IF;
END $$;