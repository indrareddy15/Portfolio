-- Create trade shares table for sharing individual trades
CREATE TABLE public.trade_shares (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  trade_id uuid NOT NULL,
  user_id uuid NOT NULL,
  share_token text NOT NULL UNIQUE,
  title text,
  description text,
  is_public boolean NOT NULL DEFAULT true,
  is_active boolean NOT NULL DEFAULT true,
  view_count integer NOT NULL DEFAULT 0,
  certificate_generated boolean NOT NULL DEFAULT false,
  certificate_url text,
  social_image_url text,
  expires_at timestamp with time zone,
  created_at timestamp with time zone NOT NULL DEFAULT now(),
  updated_at timestamp with time zone NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.trade_shares ENABLE ROW LEVEL SECURITY;

-- Create RLS policies
CREATE POLICY "Users can create their own trade shares"
  ON public.trade_shares FOR INSERT
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can view their own trade shares"
  ON public.trade_shares FOR SELECT
  USING (auth.uid() = user_id);

CREATE POLICY "Users can update their own trade shares"
  ON public.trade_shares FOR UPDATE
  USING (auth.uid() = user_id);

CREATE POLICY "Public can view active public trade shares"
  ON public.trade_shares FOR SELECT
  USING (is_public = true AND is_active = true);

-- Create trade certificates table
CREATE TABLE public.trade_certificates (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  trade_share_id uuid NOT NULL REFERENCES public.trade_shares(id) ON DELETE CASCADE,
  user_id uuid NOT NULL,
  trade_id uuid NOT NULL,
  certificate_type text NOT NULL DEFAULT 'standard',
  performance_data jsonb NOT NULL DEFAULT '{}',
  certificate_url text,
  social_image_url text,
  template_data jsonb NOT NULL DEFAULT '{}',
  generated_at timestamp with time zone NOT NULL DEFAULT now(),
  created_at timestamp with time zone NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.trade_certificates ENABLE ROW LEVEL SECURITY;

-- Create RLS policies
CREATE POLICY "Users can create their own certificates"
  ON public.trade_certificates FOR INSERT
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can view their own certificates"
  ON public.trade_certificates FOR SELECT
  USING (auth.uid() = user_id);

CREATE POLICY "Public can view certificates for public shares"
  ON public.trade_certificates FOR SELECT
  USING (
    trade_share_id IN (
      SELECT id FROM public.trade_shares 
      WHERE is_public = true AND is_active = true
    )
  );

-- Create share analytics table
CREATE TABLE public.share_analytics (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  trade_share_id uuid NOT NULL REFERENCES public.trade_shares(id) ON DELETE CASCADE,
  event_type text NOT NULL, -- 'view', 'click', 'signup', 'share'
  source text, -- 'facebook', 'twitter', 'linkedin', 'direct', etc.
  user_agent text,
  ip_address inet,
  referrer text,
  metadata jsonb DEFAULT '{}',
  created_at timestamp with time zone NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.share_analytics ENABLE ROW LEVEL SECURITY;

-- Create RLS policies
CREATE POLICY "Analytics are insertable by anyone"
  ON public.share_analytics FOR INSERT
  WITH CHECK (true);

CREATE POLICY "Users can view analytics for their shares"
  ON public.share_analytics FOR SELECT
  USING (
    trade_share_id IN (
      SELECT id FROM public.trade_shares 
      WHERE user_id = auth.uid()
    )
  );

CREATE POLICY "Admins can view all analytics"
  ON public.share_analytics FOR SELECT
  USING (has_role(auth.uid(), 'admin'::app_role));

-- Create indexes for performance
CREATE INDEX idx_trade_shares_token ON public.trade_shares(share_token);
CREATE INDEX idx_trade_shares_user_id ON public.trade_shares(user_id);
CREATE INDEX idx_trade_shares_public ON public.trade_shares(is_public, is_active);
CREATE INDEX idx_trade_certificates_share_id ON public.trade_certificates(trade_share_id);
CREATE INDEX idx_share_analytics_share_id ON public.share_analytics(trade_share_id);
CREATE INDEX idx_share_analytics_event ON public.share_analytics(event_type, created_at);

-- Create function to generate share token
CREATE OR REPLACE FUNCTION public.generate_share_token()
RETURNS text
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  RETURN 'trade_' || LOWER(SUBSTRING(MD5(RANDOM()::text), 1, 12));
END;
$$;

-- Create function to increment view count
CREATE OR REPLACE FUNCTION public.increment_share_view(share_token_param text)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  UPDATE public.trade_shares 
  SET view_count = view_count + 1 
  WHERE share_token = share_token_param AND is_active = true;
  
  -- Insert analytics
  INSERT INTO public.share_analytics (trade_share_id, event_type, ip_address, user_agent)
  SELECT id, 'view', inet_client_addr(), current_setting('request.headers')::json->>'user-agent'
  FROM public.trade_shares 
  WHERE share_token = share_token_param AND is_active = true;
END;
$$;

-- Create updated_at trigger
CREATE TRIGGER update_trade_shares_updated_at
  BEFORE UPDATE ON public.trade_shares
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at_column();