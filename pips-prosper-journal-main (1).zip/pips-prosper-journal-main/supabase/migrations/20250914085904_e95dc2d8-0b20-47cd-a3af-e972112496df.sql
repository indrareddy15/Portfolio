-- Fix function search_path security issues
DROP FUNCTION public.generate_share_token();
DROP FUNCTION public.increment_share_view(text);

-- Recreate functions with proper search_path
CREATE OR REPLACE FUNCTION public.generate_share_token()
RETURNS text
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  RETURN 'trade_' || LOWER(SUBSTRING(MD5(RANDOM()::text), 1, 12));
END;
$$;

-- Create function to increment view count with proper search_path
CREATE OR REPLACE FUNCTION public.increment_share_view(share_token_param text)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  UPDATE public.trade_shares 
  SET view_count = view_count + 1 
  WHERE share_token = share_token_param AND is_active = true;
  
  -- Insert analytics (simplified to avoid header issues)
  INSERT INTO public.share_analytics (trade_share_id, event_type)
  SELECT id, 'view'
  FROM public.trade_shares 
  WHERE share_token = share_token_param AND is_active = true;
END;
$$;