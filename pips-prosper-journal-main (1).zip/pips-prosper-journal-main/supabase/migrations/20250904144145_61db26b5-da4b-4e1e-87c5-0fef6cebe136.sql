-- Create remaining tables and RLS policies

-- Create instrument_stats table
CREATE TABLE IF NOT EXISTS public.instrument_stats (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL,
  symbol text NOT NULL,
  trade_count integer DEFAULT 0,
  pnl numeric DEFAULT 0,
  win_rate numeric DEFAULT 0,
  avg_rr numeric DEFAULT 0,
  updated_at timestamptz NOT NULL DEFAULT now(),
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE(user_id, symbol)
);

-- Create session_stats table
CREATE TABLE IF NOT EXISTS public.session_stats (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL,
  session text NOT NULL, -- 'London', 'NY', 'Asia', 'Other'
  pnl numeric DEFAULT 0,
  trade_count integer DEFAULT 0,
  updated_at timestamptz NOT NULL DEFAULT now(),
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE(user_id, session)
);

-- Add unique constraint for provider trade IDs to prevent dupes
CREATE UNIQUE INDEX IF NOT EXISTS trades_provider_unique 
ON public.trades(user_id, provider_trade_id) 
WHERE provider_trade_id IS NOT NULL;

-- Add indexes for performance on trades table
CREATE INDEX IF NOT EXISTS idx_trades_user_id_status ON public.trades(user_id, status);
CREATE INDEX IF NOT EXISTS idx_trades_user_id_opened_at ON public.trades(user_id, opened_at DESC);
CREATE INDEX IF NOT EXISTS idx_instrument_stats_user_id ON public.instrument_stats(user_id);
CREATE INDEX IF NOT EXISTS idx_session_stats_user_id ON public.session_stats(user_id);