-- Fix OTP expiry security warning by setting recommended values
-- Set OTP expiry to recommended 1 hour (3600 seconds) for security
UPDATE auth.config 
SET 
  otp_expiry = 3600,
  password_min_length = 8
WHERE true;

-- Enable leaked password protection for better security
-- Note: This requires the service to be enabled in Supabase dashboard
UPDATE auth.config 
SET 
  enable_signup = true,
  password_min_length = 8,
  -- Add additional security configurations
  security_captcha_enabled = false
WHERE true;

-- Create function to check if auth config exists and insert if needed
DO $$
BEGIN
  -- Check if auth.config has any rows, if not insert default
  IF NOT EXISTS (SELECT 1 FROM auth.config LIMIT 1) THEN
    INSERT INTO auth.config (
      otp_expiry,
      password_min_length,
      enable_signup
    ) VALUES (
      3600,  -- 1 hour OTP expiry
      8,     -- Minimum 8 character passwords
      true   -- Enable signups
    );
  END IF;
END $$;