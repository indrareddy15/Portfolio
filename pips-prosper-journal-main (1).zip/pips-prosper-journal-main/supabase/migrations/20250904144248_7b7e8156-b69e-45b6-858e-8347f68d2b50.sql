-- Create triggers for updated_at columns on new tables

CREATE TRIGGER update_trade_legs_updated_at
  BEFORE UPDATE ON public.trade_legs
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_equity_snapshots_updated_at
  BEFORE UPDATE ON public.equity_snapshots
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_metrics_summary_updated_at
  BEFORE UPDATE ON public.metrics_summary
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_instrument_stats_updated_at
  BEFORE UPDATE ON public.instrument_stats
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_session_stats_updated_at
  BEFORE UPDATE ON public.session_stats
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at_column();