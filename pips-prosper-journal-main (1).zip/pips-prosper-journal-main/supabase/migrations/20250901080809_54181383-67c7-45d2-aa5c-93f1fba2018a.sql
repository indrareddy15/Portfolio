-- Fix audit_logs security vulnerabilities
-- Drop existing overly permissive service role policy
DROP POLICY IF EXISTS "Service role can insert audit logs" ON public.audit_logs;

-- Create a more restrictive service role policy for INSERT only
CREATE POLICY "Service role insert only audit logs" 
ON public.audit_logs 
FOR INSERT 
WITH CHECK (
  (auth.jwt() ->> 'role') = 'service_role'
);

-- Ensure only system administrators can view audit logs
-- Drop and recreate the admin policy to be more explicit
DROP POLICY IF EXISTS "Admins can view audit logs" ON public.audit_logs;

CREATE POLICY "System administrators can view audit logs" 
ON public.audit_logs 
FOR SELECT 
USING (
  -- Only allow admins to view audit logs
  has_role(auth.uid(), 'admin'::app_role)
);

-- Explicitly deny all other operations except SELECT for admins and INSERT for service role
CREATE POLICY "Deny all other audit log operations" 
ON public.audit_logs 
FOR ALL 
USING (false);

-- Add policy to allow admins to manage audit logs if needed (UPDATE/DELETE)
CREATE POLICY "Admins can manage audit logs" 
ON public.audit_logs 
FOR UPDATE, DELETE
USING (
  has_role(auth.uid(), 'admin'::app_role)
);

-- Create a view for audit logs that further restricts sensitive data for non-super-admins
CREATE OR REPLACE VIEW public.audit_logs_view AS
SELECT 
  id,
  table_name,
  operation,
  record_id,
  user_role,
  created_at,
  -- Mask sensitive data
  CASE 
    WHEN has_role(auth.uid(), 'admin'::app_role) THEN user_id
    ELSE NULL::uuid
  END as user_id,
  CASE 
    WHEN has_role(auth.uid(), 'admin'::app_role) THEN ip_address
    ELSE NULL::inet
  END as ip_address,
  CASE 
    WHEN has_role(auth.uid(), 'admin'::app_role) THEN user_agent
    ELSE 'REDACTED'::text
  END as user_agent,
  -- Only show data changes to super admins
  CASE 
    WHEN has_role(auth.uid(), 'admin'::app_role) THEN old_values
    ELSE NULL::jsonb
  END as old_values,
  CASE 
    WHEN has_role(auth.uid(), 'admin'::app_role) THEN new_values
    ELSE NULL::jsonb
  END as new_values
FROM public.audit_logs
WHERE has_role(auth.uid(), 'admin'::app_role);

-- Grant appropriate permissions on the view
GRANT SELECT ON public.audit_logs_view TO authenticated;

-- Enable RLS on the view (though views inherit from base table)
ALTER VIEW public.audit_logs_view SET (security_barrier = true);

-- Add comment explaining the security model
COMMENT ON TABLE public.audit_logs IS 'Sensitive audit log table. Only accessible to system administrators. Contains user activity, IP addresses, and data changes.';
COMMENT ON VIEW public.audit_logs_view IS 'Secure view of audit logs with sensitive data masked for non-admin users.';