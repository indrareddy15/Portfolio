-- Fix audit_logs security vulnerabilities (corrected version)
-- Drop existing overly permissive service role policy
DROP POLICY IF EXISTS "Service role can insert audit logs" ON public.audit_logs;
DROP POLICY IF EXISTS "Service role full access to audit logs" ON public.audit_logs;

-- Create a more restrictive service role policy for INSERT only
CREATE POLICY "Service role insert only audit logs" 
ON public.audit_logs 
FOR INSERT 
WITH CHECK (
  (auth.jwt() ->> 'role') = 'service_role'
);

-- Ensure only system administrators can view audit logs
-- Drop and recreate the admin policy to be more explicit
DROP POLICY IF EXISTS "Admins can view audit logs" ON public.audit_logs;

CREATE POLICY "System administrators can view audit logs" 
ON public.audit_logs 
FOR SELECT 
USING (
  -- Only allow admins to view audit logs
  has_role(auth.uid(), 'admin'::app_role)
);

-- Add separate policies for admin management operations
CREATE POLICY "Admins can update audit logs" 
ON public.audit_logs 
FOR UPDATE
USING (
  has_role(auth.uid(), 'admin'::app_role)
)
WITH CHECK (
  has_role(auth.uid(), 'admin'::app_role)
);

CREATE POLICY "Admins can delete audit logs" 
ON public.audit_logs 
FOR DELETE
USING (
  has_role(auth.uid(), 'admin'::app_role)
);

-- Add comment explaining the security model
COMMENT ON TABLE public.audit_logs IS 'Sensitive audit log table. Only accessible to system administrators. Contains user activity, IP addresses, and data changes.';