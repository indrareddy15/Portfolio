-- Create notices table if not exists
CREATE TABLE IF NOT EXISTS public.notices (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  title TEXT NOT NULL,
  message TEXT NOT NULL,
  link_url TEXT,
  link_text TEXT DEFAULT 'Learn More',
  type TEXT CHECK (type IN ('info', 'success', 'warning', 'error')) DEFAULT 'info',
  priority INTEGER DEFAULT 1,
  is_active BOOLEAN DEFAULT true,
  show_on_website BOOLEAN DEFAULT true,
  show_on_dashboard BOOLEAN DEFAULT true,
  expires_at TIMESTAMP WITH TIME ZONE,
  created_by UUID REFERENCES auth.users(id),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.notices ENABLE ROW LEVEL SECURITY;

-- Create policies for notices
CREATE POLICY "Admin users can manage notices" 
ON public.notices 
FOR ALL 
USING (
  EXISTS (
    SELECT 1 FROM public.user_roles 
    WHERE user_id = auth.uid() 
    AND role = 'admin'
  )
);

-- Create policy for public reading of active notices
CREATE POLICY "Everyone can read active notices" 
ON public.notices 
FOR SELECT 
USING (is_active = true AND (expires_at IS NULL OR expires_at > now()));

-- Enable realtime for notices
ALTER TABLE public.notices REPLICA IDENTITY FULL;
ALTER PUBLICATION supabase_realtime ADD TABLE public.notices;

-- Create trigger for updated_at
CREATE TRIGGER update_notices_updated_at
  BEFORE UPDATE ON public.notices
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at_column();