-- Enable realtime for trades table to ensure CSV imports trigger dashboard updates
ALTER TABLE public.trades REPLICA IDENTITY FULL;

-- Add trades table to realtime publication if not already added
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_publication_tables 
    WHERE pubname = 'supabase_realtime' AND tablename = 'trades'
  ) THEN
    ALTER PUBLICATION supabase_realtime ADD TABLE public.trades;
  END IF;
END $$;

-- Enable realtime for import_jobs table
ALTER TABLE public.import_jobs REPLICA IDENTITY FULL;

-- Add import_jobs table to realtime publication
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_publication_tables 
    WHERE pubname = 'supabase_realtime' AND tablename = 'import_jobs'
  ) THEN
    ALTER PUBLICATION supabase_realtime ADD TABLE public.import_jobs;
  END IF;
END $$;