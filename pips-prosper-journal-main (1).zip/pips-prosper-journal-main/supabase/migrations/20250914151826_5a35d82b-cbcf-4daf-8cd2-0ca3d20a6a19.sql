-- Add trade type and prop challenge fields to trades table
ALTER TABLE public.trades ADD COLUMN trade_type text DEFAULT 'broker' CHECK (trade_type IN ('broker', 'prop_firm'));
ALTER TABLE public.trades ADD COLUMN prop_challenge_id uuid REFERENCES public.prop_challenges(id);

-- Add index for better performance on prop challenge trades
CREATE INDEX idx_trades_prop_challenge ON public.trades(prop_challenge_id);
CREATE INDEX idx_trades_trade_type ON public.trades(trade_type);

-- Add real-time updates for trades table
ALTER TABLE public.trades REPLICA IDENTITY FULL;
ALTER PUBLICATION supabase_realtime ADD TABLE public.trades;