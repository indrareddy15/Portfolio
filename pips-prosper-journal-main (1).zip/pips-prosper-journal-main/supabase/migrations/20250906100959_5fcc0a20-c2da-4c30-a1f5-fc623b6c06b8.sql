-- Extend existing accounts table with missing fields
ALTER TABLE public.accounts 
ADD COLUMN IF NOT EXISTS size_cents INTEGER,
ADD COLUMN IF NOT EXISTS risk_pct DECIMAL(5,2) DEFAULT 1.0,
ADD COLUMN IF NOT EXISTS margin_pct DECIMAL(5,2),
ADD COLUMN IF NOT EXISTS status TEXT DEFAULT 'active' CHECK (status IN ('active', 'archived'));

-- Create instruments table for contract specifications
CREATE TABLE IF NOT EXISTS public.instruments (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  symbol TEXT NOT NULL UNIQUE,
  class TEXT NOT NULL CHECK (class IN ('forex', 'metals', 'indices', 'crypto')),
  contract_size DECIMAL(15,2) DEFAULT 100000,
  pip_decimal INTEGER DEFAULT 4,
  tick_size DECIMAL(10,8) DEFAULT 0.0001,
  quote_ccy TEXT DEFAULT 'USD',
  is_active BOOLEAN DEFAULT true,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Enable RLS for instruments
ALTER TABLE public.instruments ENABLE ROW LEVEL SECURITY;

-- Policy for instruments - anyone can view active instruments
CREATE POLICY "Anyone can view active instruments" 
ON public.instruments 
FOR SELECT 
USING (is_active = true);

-- Admins can manage instruments
CREATE POLICY "Admins can manage instruments" 
ON public.instruments 
FOR ALL 
USING (has_role(auth.uid(), 'admin'::app_role));

-- Create connections table for integrations
CREATE TABLE IF NOT EXISTS public.connections (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL,
  account_id UUID REFERENCES public.accounts(id),
  provider TEXT NOT NULL CHECK (provider IN ('mt4_ea', 'mt5_ea', 'mt_investor', 'ctrader', 'tradingview', 'tradelocker', 'binance', 'bybit')),
  status TEXT NOT NULL DEFAULT 'disconnected' CHECK (status IN ('connected', 'disconnected', 'error', 'pending')),
  label TEXT,
  client_id TEXT,
  client_secret TEXT,
  access_token TEXT,
  refresh_token TEXT,
  server TEXT,
  login TEXT,
  investor_pass TEXT,
  webhook_secret TEXT,
  expires_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Enable RLS for connections
ALTER TABLE public.connections ENABLE ROW LEVEL SECURITY;

-- Policies for connections
CREATE POLICY "Users can manage their own connections" 
ON public.connections 
FOR ALL 
USING (auth.uid() = user_id);

-- Create sync_logs table
CREATE TABLE IF NOT EXISTS public.sync_logs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  account_id UUID NOT NULL REFERENCES public.accounts(id),
  provider TEXT NOT NULL,
  level TEXT NOT NULL DEFAULT 'info' CHECK (level IN ('info', 'warn', 'error')),
  message TEXT NOT NULL,
  meta JSONB DEFAULT '{}',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Enable RLS for sync_logs
ALTER TABLE public.sync_logs ENABLE ROW LEVEL SECURITY;

-- Policies for sync_logs
CREATE POLICY "Users can view their account sync logs" 
ON public.sync_logs 
FOR SELECT 
USING (
  account_id IN (
    SELECT id FROM public.accounts WHERE user_id = auth.uid()
  )
);

-- Create fx_rates_new table for currency conversion (avoiding conflict with existing)
CREATE TABLE IF NOT EXISTS public.fx_rates_new (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  base_currency TEXT NOT NULL,
  quote_currency TEXT NOT NULL,
  rate_date DATE NOT NULL,
  rate DECIMAL(15,8) NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE(base_currency, quote_currency, rate_date)
);

-- Enable RLS for fx_rates_new
ALTER TABLE public.fx_rates_new ENABLE ROW LEVEL SECURITY;

-- Policy for fx_rates_new - anyone can view
CREATE POLICY "Anyone can view fx rates new" 
ON public.fx_rates_new 
FOR SELECT 
USING (true);

-- Admins can manage fx_rates_new
CREATE POLICY "Admins can manage fx rates new" 
ON public.fx_rates_new 
FOR ALL 
USING (has_role(auth.uid(), 'admin'::app_role));

-- Create metrics_snapshots table
CREATE TABLE IF NOT EXISTS public.metrics_snapshots (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL,
  account_id UUID REFERENCES public.accounts(id), -- NULL means ALL accounts
  scope TEXT NOT NULL DEFAULT 'last30d' CHECK (scope IN ('last7d', 'last30d', 'all', 'custom')),
  from_date TIMESTAMPTZ,
  to_date TIMESTAMPTZ,
  win_pct DECIMAL(5,2),
  profit_factor DECIMAL(10,4),
  avg_rr DECIMAL(10,4),
  max_dd_pct DECIMAL(5,2),
  avg_risk_pct DECIMAL(5,2),
  trades_count INTEGER DEFAULT 0,
  net_pnl_cents INTEGER DEFAULT 0,
  breakdown JSONB DEFAULT '{}',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Enable RLS for metrics_snapshots
ALTER TABLE public.metrics_snapshots ENABLE ROW LEVEL SECURITY;

-- Policies for metrics_snapshots
CREATE POLICY "Users can manage their own metrics snapshots" 
ON public.metrics_snapshots 
FOR ALL 
USING (auth.uid() = user_id);

-- Create equity_points table
CREATE TABLE IF NOT EXISTS public.equity_points (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL,
  account_id UUID REFERENCES public.accounts(id),
  timestamp TIMESTAMPTZ NOT NULL,
  balance_cents INTEGER NOT NULL,
  drawdown_pct DECIMAL(5,2),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Enable RLS for equity_points
ALTER TABLE public.equity_points ENABLE ROW LEVEL SECURITY;

-- Policies for equity_points
CREATE POLICY "Users can manage their own equity points" 
ON public.equity_points 
FOR ALL 
USING (auth.uid() = user_id);