-- Enhanced Affiliate Program Schema with Tiered Commissions and Admin System

-- Add new columns to existing affiliates table for tier support
ALTER TABLE public.affiliates ADD COLUMN IF NOT EXISTS lifetime_approved_count INTEGER DEFAULT 0;
ALTER TABLE public.affiliates ADD COLUMN IF NOT EXISTS override_mode TEXT DEFAULT 'none' CHECK (override_mode IN ('none', 'flat', 'custom_tiers', 'promo_window'));
ALTER TABLE public.affiliates ADD COLUMN IF NOT EXISTS flat_pct NUMERIC(5,2);
ALTER TABLE public.affiliates ADD COLUMN IF NOT EXISTS custom_tiers_json JSONB;
ALTER TABLE public.affiliates ADD COLUMN IF NOT EXISTS promo_start TIMESTAMPTZ;
ALTER TABLE public.affiliates ADD COLUMN IF NOT EXISTS promo_end TIMESTAMPTZ;

-- Create affiliate tier snapshots for auditing
CREATE TABLE IF NOT EXISTS public.affiliate_tier_snapshots (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  affiliate_id UUID NOT NULL REFERENCES public.affiliates(id) ON DELETE CASCADE,
  at_date DATE NOT NULL DEFAULT CURRENT_DATE,
  tier_level INTEGER NOT NULL CHECK (tier_level IN (1, 2, 3)),
  effective_rate_pct NUMERIC(5,2) NOT NULL,
  approved_count INTEGER NOT NULL,
  created_at TIMESTAMPTZ DEFAULT now()
);

-- Create CMS blocks for dynamic content management
CREATE TABLE IF NOT EXISTS public.cms_blocks (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  key TEXT NOT NULL UNIQUE,
  content_json JSONB NOT NULL DEFAULT '{}',
  updated_by UUID REFERENCES auth.users(id),
  updated_at TIMESTAMPTZ DEFAULT now(),
  created_at TIMESTAMPTZ DEFAULT now()
);

-- Create CRM notes for admin use
CREATE TABLE IF NOT EXISTS public.crm_notes (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  subject TEXT NOT NULL,
  body TEXT,
  user_id UUID REFERENCES auth.users(id),
  affiliate_id UUID REFERENCES public.affiliates(id),
  by_admin_id UUID REFERENCES auth.users(id) NOT NULL,
  created_at TIMESTAMPTZ DEFAULT now(),
  CHECK ((user_id IS NOT NULL AND affiliate_id IS NULL) OR (user_id IS NULL AND affiliate_id IS NOT NULL))
);

-- Create campaigns table for marketing management
CREATE TABLE IF NOT EXISTS public.campaigns (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  utm_preset_json JSONB DEFAULT '{}',
  creative_ids UUID[] DEFAULT '{}',
  active BOOLEAN DEFAULT true,
  created_by UUID REFERENCES auth.users(id),
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now()
);

-- Update commissions table with enhanced tracking
ALTER TABLE public.commissions ADD COLUMN IF NOT EXISTS tier_level INTEGER CHECK (tier_level IN (1, 2, 3));
ALTER TABLE public.commissions ADD COLUMN IF NOT EXISTS effective_rate_pct NUMERIC(5,2);
ALTER TABLE public.commissions ADD COLUMN IF NOT EXISTS plan_name TEXT;

-- Enable RLS on new tables
ALTER TABLE public.affiliate_tier_snapshots ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.cms_blocks ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.crm_notes ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.campaigns ENABLE ROW LEVEL SECURITY;

-- RLS Policies for affiliate_tier_snapshots
CREATE POLICY "Affiliates can view their own tier snapshots" 
ON public.affiliate_tier_snapshots FOR SELECT 
USING (affiliate_id IN (
  SELECT id FROM public.affiliates WHERE user_id = auth.uid()
));

-- RLS Policies for cms_blocks
CREATE POLICY "Anyone can view cms blocks" 
ON public.cms_blocks FOR SELECT 
USING (true);

CREATE POLICY "Admins can manage cms blocks" 
ON public.cms_blocks FOR ALL 
USING (has_role(auth.uid(), 'admin'::app_role) OR has_role(auth.uid(), 'owner'::app_role));

-- RLS Policies for crm_notes  
CREATE POLICY "Admins can manage all crm notes" 
ON public.crm_notes FOR ALL 
USING (has_role(auth.uid(), 'admin'::app_role) OR has_role(auth.uid(), 'owner'::app_role));

CREATE POLICY "Users can view notes about themselves" 
ON public.crm_notes FOR SELECT 
USING (user_id = auth.uid() OR (affiliate_id IN (
  SELECT id FROM public.affiliates WHERE user_id = auth.uid()
)));

-- RLS Policies for campaigns
CREATE POLICY "Admins can manage campaigns" 
ON public.campaigns FOR ALL 
USING (has_role(auth.uid(), 'admin'::app_role) OR has_role(auth.uid(), 'owner'::app_role));

CREATE POLICY "Anyone can view active campaigns" 
ON public.campaigns FOR SELECT 
USING (active = true);

-- Insert default CMS blocks
INSERT INTO public.cms_blocks (key, content_json) VALUES 
('home_affiliate_strip', '{"enabled": true, "title": "Become a PipsJournal Affiliate", "subtitle": "Earn 30% recurring commissions", "cta": "Learn More"}'),
('home_affiliate_section', '{"enabled": true, "title": "Earn with PipsJournal", "bullets": ["30% recurring commissions", "90-day cookie window", "Real-time dashboard"], "cta": "Join Affiliate Program"}'),
('footer_affiliate_link', '{"enabled": true, "text": "Affiliate Program"}'),
('affiliate_faqs', '{"items": []}')
ON CONFLICT (key) DO NOTHING;