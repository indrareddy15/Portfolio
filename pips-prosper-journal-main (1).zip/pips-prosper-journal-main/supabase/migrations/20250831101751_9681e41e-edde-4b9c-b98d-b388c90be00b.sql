-- Create gamification tables
CREATE TABLE public.consistency_scores (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL,
  score INTEGER NOT NULL DEFAULT 0 CHECK (score >= 0 AND score <= 100),
  trading_days INTEGER NOT NULL DEFAULT 0,
  consecutive_days INTEGER NOT NULL DEFAULT 0,
  last_trade_date DATE,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

CREATE TABLE public.user_badges (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL,
  badge_type TEXT NOT NULL,
  badge_name TEXT NOT NULL,
  badge_description TEXT,
  earned_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  metadata JSONB
);

CREATE TABLE public.streaks (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL,
  streak_type TEXT NOT NULL, -- 'trading_days', 'no_revenge_trading', 'green_days', etc.
  current_count INTEGER NOT NULL DEFAULT 0,
  best_count INTEGER NOT NULL DEFAULT 0,
  last_date DATE,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create prop firm challenge tables
CREATE TABLE public.prop_challenges (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL,
  challenge_name TEXT NOT NULL,
  start_date DATE NOT NULL,
  end_date DATE NOT NULL,
  target_profit DECIMAL,
  max_daily_loss DECIMAL NOT NULL,
  max_overall_loss DECIMAL NOT NULL,
  min_trading_days INTEGER NOT NULL DEFAULT 10,
  max_lot_size DECIMAL,
  current_profit DECIMAL DEFAULT 0,
  current_daily_loss DECIMAL DEFAULT 0,
  current_overall_loss DECIMAL DEFAULT 0,
  trading_days_count INTEGER DEFAULT 0,
  status TEXT DEFAULT 'active' CHECK (status IN ('active', 'passed', 'failed', 'paused')),
  rules_json JSONB,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

CREATE TABLE public.challenge_daily_results (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  challenge_id UUID NOT NULL,
  user_id UUID NOT NULL,
  date DATE NOT NULL,
  daily_pnl DECIMAL DEFAULT 0,
  passed BOOLEAN DEFAULT true,
  fail_reasons TEXT[],
  trades_count INTEGER DEFAULT 0,
  largest_lot DECIMAL DEFAULT 0,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create AI insights table
CREATE TABLE public.ai_insights (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL,
  insight_type TEXT NOT NULL, -- 'daily', 'weekly', 'pattern', 'recommendation'
  title TEXT NOT NULL,
  content TEXT NOT NULL,
  metadata JSONB,
  is_read BOOLEAN DEFAULT false,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create dashboard layouts table
CREATE TABLE public.dashboard_layouts (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL,
  layout_name TEXT NOT NULL,
  layout_data JSONB NOT NULL,
  is_default BOOLEAN DEFAULT false,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create sharing tables
CREATE TABLE public.public_journals (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL,
  display_name TEXT,
  bio TEXT,
  is_public BOOLEAN DEFAULT false,
  public_link TEXT UNIQUE,
  view_count INTEGER DEFAULT 0,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

CREATE TABLE public.share_links (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL,
  link_type TEXT NOT NULL, -- 'private', 'coach', 'investor'
  share_token TEXT UNIQUE NOT NULL,
  password_hash TEXT,
  expires_at TIMESTAMP WITH TIME ZONE,
  permissions JSONB, -- what data to share
  view_count INTEGER DEFAULT 0,
  last_viewed_at TIMESTAMP WITH TIME ZONE,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create news events table for calendar
CREATE TABLE public.news_events (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  date DATE NOT NULL,
  time TIME,
  title TEXT NOT NULL,
  description TEXT,
  impact_level TEXT CHECK (impact_level IN ('low', 'medium', 'high')),
  currency TEXT,
  category TEXT,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS on all tables
ALTER TABLE public.consistency_scores ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.user_badges ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.streaks ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.prop_challenges ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.challenge_daily_results ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.ai_insights ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.dashboard_layouts ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.public_journals ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.share_links ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.news_events ENABLE ROW LEVEL SECURITY;

-- Create RLS policies
-- Consistency scores policies
CREATE POLICY "Users can view their own consistency scores" ON public.consistency_scores FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "Users can insert their own consistency scores" ON public.consistency_scores FOR INSERT WITH CHECK (auth.uid() = user_id);
CREATE POLICY "Users can update their own consistency scores" ON public.consistency_scores FOR UPDATE USING (auth.uid() = user_id);

-- User badges policies
CREATE POLICY "Users can view their own badges" ON public.user_badges FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "Users can insert their own badges" ON public.user_badges FOR INSERT WITH CHECK (auth.uid() = user_id);

-- Streaks policies
CREATE POLICY "Users can view their own streaks" ON public.streaks FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "Users can insert their own streaks" ON public.streaks FOR INSERT WITH CHECK (auth.uid() = user_id);
CREATE POLICY "Users can update their own streaks" ON public.streaks FOR UPDATE USING (auth.uid() = user_id);

-- Prop challenges policies
CREATE POLICY "Users can view their own challenges" ON public.prop_challenges FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "Users can insert their own challenges" ON public.prop_challenges FOR INSERT WITH CHECK (auth.uid() = user_id);
CREATE POLICY "Users can update their own challenges" ON public.prop_challenges FOR UPDATE USING (auth.uid() = user_id);
CREATE POLICY "Users can delete their own challenges" ON public.prop_challenges FOR DELETE USING (auth.uid() = user_id);

-- Challenge daily results policies
CREATE POLICY "Users can view their own challenge results" ON public.challenge_daily_results FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "Users can insert their own challenge results" ON public.challenge_daily_results FOR INSERT WITH CHECK (auth.uid() = user_id);
CREATE POLICY "Users can update their own challenge results" ON public.challenge_daily_results FOR UPDATE USING (auth.uid() = user_id);

-- AI insights policies
CREATE POLICY "Users can view their own insights" ON public.ai_insights FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "Users can insert their own insights" ON public.ai_insights FOR INSERT WITH CHECK (auth.uid() = user_id);
CREATE POLICY "Users can update their own insights" ON public.ai_insights FOR UPDATE USING (auth.uid() = user_id);

-- Dashboard layouts policies
CREATE POLICY "Users can view their own layouts" ON public.dashboard_layouts FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "Users can insert their own layouts" ON public.dashboard_layouts FOR INSERT WITH CHECK (auth.uid() = user_id);
CREATE POLICY "Users can update their own layouts" ON public.dashboard_layouts FOR UPDATE USING (auth.uid() = user_id);
CREATE POLICY "Users can delete their own layouts" ON public.dashboard_layouts FOR DELETE USING (auth.uid() = user_id);

-- Public journals policies
CREATE POLICY "Users can view all public journals" ON public.public_journals FOR SELECT USING (is_public = true OR auth.uid() = user_id);
CREATE POLICY "Users can insert their own journal" ON public.public_journals FOR INSERT WITH CHECK (auth.uid() = user_id);
CREATE POLICY "Users can update their own journal" ON public.public_journals FOR UPDATE USING (auth.uid() = user_id);

-- Share links policies
CREATE POLICY "Users can view their own share links" ON public.share_links FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "Users can insert their own share links" ON public.share_links FOR INSERT WITH CHECK (auth.uid() = user_id);
CREATE POLICY "Users can update their own share links" ON public.share_links FOR UPDATE USING (auth.uid() = user_id);
CREATE POLICY "Users can delete their own share links" ON public.share_links FOR DELETE USING (auth.uid() = user_id);

-- News events policies (public read-only)
CREATE POLICY "Everyone can view news events" ON public.news_events FOR SELECT USING (true);

-- Create triggers for updated_at columns
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ language 'plpgsql';

CREATE TRIGGER update_consistency_scores_updated_at BEFORE UPDATE ON public.consistency_scores FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_streaks_updated_at BEFORE UPDATE ON public.streaks FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_prop_challenges_updated_at BEFORE UPDATE ON public.prop_challenges FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_dashboard_layouts_updated_at BEFORE UPDATE ON public.dashboard_layouts FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_public_journals_updated_at BEFORE UPDATE ON public.public_journals FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- Add foreign key constraints
ALTER TABLE public.consistency_scores ADD CONSTRAINT consistency_scores_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;
ALTER TABLE public.user_badges ADD CONSTRAINT user_badges_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;
ALTER TABLE public.streaks ADD CONSTRAINT streaks_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;
ALTER TABLE public.prop_challenges ADD CONSTRAINT prop_challenges_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;
ALTER TABLE public.challenge_daily_results ADD CONSTRAINT challenge_daily_results_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;
ALTER TABLE public.challenge_daily_results ADD CONSTRAINT challenge_daily_results_challenge_id_fkey FOREIGN KEY (challenge_id) REFERENCES public.prop_challenges(id) ON DELETE CASCADE;
ALTER TABLE public.ai_insights ADD CONSTRAINT ai_insights_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;
ALTER TABLE public.dashboard_layouts ADD CONSTRAINT dashboard_layouts_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;
ALTER TABLE public.public_journals ADD CONSTRAINT public_journals_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;
ALTER TABLE public.share_links ADD CONSTRAINT share_links_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;

-- Create indexes for better performance
CREATE INDEX idx_consistency_scores_user_id ON public.consistency_scores(user_id);
CREATE INDEX idx_user_badges_user_id ON public.user_badges(user_id);
CREATE INDEX idx_streaks_user_id ON public.streaks(user_id);
CREATE INDEX idx_prop_challenges_user_id ON public.prop_challenges(user_id);
CREATE INDEX idx_challenge_daily_results_challenge_id ON public.challenge_daily_results(challenge_id);
CREATE INDEX idx_ai_insights_user_id ON public.ai_insights(user_id);
CREATE INDEX idx_dashboard_layouts_user_id ON public.dashboard_layouts(user_id);
CREATE INDEX idx_public_journals_user_id ON public.public_journals(user_id);
CREATE INDEX idx_share_links_user_id ON public.share_links(user_id);
CREATE INDEX idx_news_events_date ON public.news_events(date);