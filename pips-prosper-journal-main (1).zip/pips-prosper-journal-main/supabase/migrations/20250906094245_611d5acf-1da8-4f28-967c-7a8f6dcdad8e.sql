-- Update app_role enum to include more roles
ALTER TYPE app_role ADD VALUE IF NOT EXISTS 'developer';
ALTER TYPE app_role ADD VALUE IF NOT EXISTS 'sales';
ALTER TYPE app_role ADD VALUE IF NOT EXISTS 'support';
ALTER TYPE app_role ADD VALUE IF NOT EXISTS 'marketing';
ALTER TYPE app_role ADD VALUE IF NOT EXISTS 'finance';

-- Create team_invitations table for managing invites
CREATE TABLE IF NOT EXISTS public.team_invitations (
    id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
    email text NOT NULL,
    role app_role NOT NULL,
    invited_by uuid REFERENCES auth.users(id) NOT NULL,
    status text NOT NULL DEFAULT 'pending',
    expires_at timestamp with time zone NOT NULL DEFAULT (now() + interval '7 days'),
    accepted_at timestamp with time zone,
    created_at timestamp with time zone NOT NULL DEFAULT now(),
    updated_at timestamp with time zone NOT NULL DEFAULT now()
);

-- Enable RLS on team_invitations
ALTER TABLE public.team_invitations ENABLE ROW LEVEL SECURITY;

-- Create policies for team_invitations
CREATE POLICY "Admins can manage team invitations" 
ON public.team_invitations 
FOR ALL 
USING (has_role(auth.uid(), 'admin'::app_role))
WITH CHECK (has_role(auth.uid(), 'admin'::app_role));

-- Create role permissions table
CREATE TABLE IF NOT EXISTS public.role_permissions (
    id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
    role app_role NOT NULL,
    permission text NOT NULL,
    created_at timestamp with time zone NOT NULL DEFAULT now(),
    UNIQUE(role, permission)
);

-- Enable RLS on role_permissions
ALTER TABLE public.role_permissions ENABLE ROW LEVEL SECURITY;

-- Create policy for role_permissions
CREATE POLICY "Anyone can view role permissions" 
ON public.role_permissions 
FOR SELECT 
USING (true);

CREATE POLICY "Admins can manage role permissions" 
ON public.role_permissions 
FOR ALL 
USING (has_role(auth.uid(), 'admin'::app_role))
WITH CHECK (has_role(auth.uid(), 'admin'::app_role));

-- Insert default permissions for each role
INSERT INTO public.role_permissions (role, permission) VALUES
-- Admin permissions (full access)
('admin', 'view_all'),
('admin', 'manage_users'),
('admin', 'manage_roles'),
('admin', 'manage_affiliates'),
('admin', 'manage_pricing'),
('admin', 'manage_settings'),
('admin', 'manage_branding'),
('admin', 'view_analytics'),
('admin', 'manage_crm'),
('admin', 'manage_marketing'),
('admin', 'manage_forex'),

-- Developer permissions
('developer', 'view_users'),
('developer', 'manage_settings'),
('developer', 'view_analytics'),
('developer', 'manage_forex'),

-- Sales permissions
('sales', 'view_users'),
('sales', 'manage_crm'),
('sales', 'view_analytics'),
('sales', 'manage_affiliates'),

-- Support permissions
('support', 'view_users'),
('support', 'manage_crm'),
('support', 'view_analytics'),

-- Marketing permissions
('marketing', 'manage_affiliates'),
('marketing', 'manage_marketing'),
('marketing', 'manage_branding'),
('marketing', 'view_analytics'),

-- Finance permissions
('finance', 'view_analytics'),
('finance', 'manage_pricing'),
('finance', 'view_users')

ON CONFLICT (role, permission) DO NOTHING;

-- Create function to get user permissions
CREATE OR REPLACE FUNCTION public.get_user_permissions(user_id uuid)
RETURNS text[]
LANGUAGE sql
STABLE SECURITY DEFINER
SET search_path = public
AS $$
  SELECT ARRAY_AGG(DISTINCT rp.permission)
  FROM public.user_roles ur
  JOIN public.role_permissions rp ON ur.role = rp.role
  WHERE ur.user_id = user_id;
$$;

-- Create function to check if user has permission
CREATE OR REPLACE FUNCTION public.has_permission(user_id uuid, permission_name text)
RETURNS boolean
LANGUAGE sql
STABLE SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1
    FROM public.user_roles ur
    JOIN public.role_permissions rp ON ur.role = rp.role
    WHERE ur.user_id = user_id
      AND rp.permission = permission_name
  );
$$;

-- Add triggers for updated_at
CREATE TRIGGER update_team_invitations_updated_at
    BEFORE UPDATE ON public.team_invitations
    FOR EACH ROW
    EXECUTE FUNCTION public.update_updated_at_column();