-- Enable real-time for prop challenges and related tables
ALTER TABLE public.prop_challenges REPLICA IDENTITY FULL;
ALTER TABLE public.challenge_daily_results REPLICA IDENTITY FULL;
ALTER TABLE public.trades REPLICA IDENTITY FULL;

-- Add tables to realtime publication
DO $$
BEGIN
    -- Add prop_challenges to realtime
    IF NOT EXISTS (
        SELECT 1 FROM pg_publication_tables 
        WHERE pubname = 'supabase_realtime' 
        AND tablename = 'prop_challenges'
    ) THEN
        ALTER PUBLICATION supabase_realtime ADD TABLE public.prop_challenges;
    END IF;
    
    -- Add challenge_daily_results to realtime
    IF NOT EXISTS (
        SELECT 1 FROM pg_publication_tables 
        WHERE pubname = 'supabase_realtime' 
        AND tablename = 'challenge_daily_results'
    ) THEN
        ALTER PUBLICATION supabase_realtime ADD TABLE public.challenge_daily_results;
    END IF;
    
    -- Add trades to realtime (if not already added)
    IF NOT EXISTS (
        SELECT 1 FROM pg_publication_tables 
        WHERE pubname = 'supabase_realtime' 
        AND tablename = 'trades'
    ) THEN
        ALTER PUBLICATION supabase_realtime ADD TABLE public.trades;
    END IF;
END $$;