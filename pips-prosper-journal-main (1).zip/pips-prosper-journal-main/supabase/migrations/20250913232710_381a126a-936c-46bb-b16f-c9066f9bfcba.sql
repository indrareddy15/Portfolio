-- Create trade history table for tracking trade modifications
CREATE TABLE public.trade_history (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  trade_id uuid NOT NULL,
  user_id uuid NOT NULL,
  action text NOT NULL, -- 'created', 'updated', 'closed', 'deleted'
  old_values jsonb,
  new_values jsonb NOT NULL,
  changed_fields text[],
  ip_address inet,
  user_agent text,
  created_at timestamp with time zone NOT NULL DEFAULT now()
);

-- Enable RLS on trade_history
ALTER TABLE public.trade_history ENABLE ROW LEVEL SECURITY;

-- RLS policies for trade_history
CREATE POLICY "Users can view their own trade history"
ON public.trade_history
FOR SELECT
USING (auth.uid() = user_id);

CREATE POLICY "System can insert trade history"
ON public.trade_history
FOR INSERT
WITH CHECK (auth.uid() = user_id);

-- Create indexes for better performance
CREATE INDEX idx_trade_history_trade_id ON public.trade_history(trade_id);
CREATE INDEX idx_trade_history_user_id ON public.trade_history(user_id);
CREATE INDEX idx_trade_history_created_at ON public.trade_history(created_at DESC);

-- Create function to automatically log trade changes
CREATE OR REPLACE FUNCTION public.log_trade_changes()
RETURNS TRIGGER AS $$
BEGIN
  -- Log INSERT
  IF TG_OP = 'INSERT' THEN
    INSERT INTO public.trade_history (
      trade_id,
      user_id,
      action,
      new_values,
      changed_fields
    ) VALUES (
      NEW.id,
      NEW.user_id,
      'created',
      to_jsonb(NEW),
      ARRAY['*'] -- All fields for new record
    );
    RETURN NEW;
  END IF;

  -- Log UPDATE
  IF TG_OP = 'UPDATE' THEN
    DECLARE
      changed_fields text[] := '{}';
      field_name text;
    BEGIN
      -- Check each field for changes
      FOR field_name IN 
        SELECT column_name 
        FROM information_schema.columns 
        WHERE table_name = 'trades' 
        AND table_schema = 'public'
        AND column_name NOT IN ('updated_at', 'created_at')
      LOOP
        IF to_jsonb(OLD) -> field_name IS DISTINCT FROM to_jsonb(NEW) -> field_name THEN
          changed_fields := array_append(changed_fields, field_name);
        END IF;
      END LOOP;

      -- Only log if there are actual changes
      IF array_length(changed_fields, 1) > 0 THEN
        INSERT INTO public.trade_history (
          trade_id,
          user_id,
          action,
          old_values,
          new_values,
          changed_fields
        ) VALUES (
          NEW.id,
          NEW.user_id,
          CASE 
            WHEN OLD.closed_at IS NULL AND NEW.closed_at IS NOT NULL THEN 'closed'
            ELSE 'updated'
          END,
          to_jsonb(OLD),
          to_jsonb(NEW),
          changed_fields
        );
      END IF;
    END;
    RETURN NEW;
  END IF;

  -- Log DELETE
  IF TG_OP = 'DELETE' THEN
    INSERT INTO public.trade_history (
      trade_id,
      user_id,
      action,
      old_values,
      new_values,
      changed_fields
    ) VALUES (
      OLD.id,
      OLD.user_id,
      'deleted',
      to_jsonb(OLD),
      '{}'::jsonb,
      ARRAY['*']
    );
    RETURN OLD;
  END IF;

  RETURN NULL;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Create trigger on trades table
DROP TRIGGER IF EXISTS trades_history_trigger ON public.trades;
CREATE TRIGGER trades_history_trigger
  AFTER INSERT OR UPDATE OR DELETE ON public.trades
  FOR EACH ROW
  EXECUTE FUNCTION public.log_trade_changes();

-- Add realtime publication for trade_history
ALTER PUBLICATION supabase_realtime ADD TABLE public.trade_history;