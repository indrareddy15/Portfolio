-- Update affiliate settings to reflect PipTrackr.com domain and 10% commission with 30 day cookies
UPDATE public.affiliate_settings 
SET 
  default_commission_rate = 10.00,
  cookie_duration = 30,
  tracking_domain = 'track.piptrackr.com',
  welcome_message = 'Welcome to the PipTrackr.com affiliate program! We''re excited to work with you.'
WHERE true;

-- Update affiliates table to set default rate to 10%
UPDATE public.affiliates 
SET 
  default_rate_pct = 10.00,
  cookie_window_days = 30
WHERE true;