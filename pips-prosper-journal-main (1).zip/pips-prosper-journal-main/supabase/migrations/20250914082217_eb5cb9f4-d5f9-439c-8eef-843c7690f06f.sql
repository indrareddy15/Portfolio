-- Fix RLS policy for share_links table INSERT operation
DROP POLICY IF EXISTS "Users can insert their own share links" ON public.share_links;

CREATE POLICY "Users can insert their own share links" 
ON public.share_links 
FOR INSERT 
WITH CHECK (auth.uid() = user_id);