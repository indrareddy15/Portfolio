-- Create a function to set up a test user (admin use only)
CREATE OR REPLACE FUNCTION create_test_user()
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
    test_user_id UUID;
BEGIN
    -- Note: This function should only be called by admins
    -- The actual user creation must be done through Supabase Auth Dashboard or API
    -- This function will just ensure the user has proper roles and profile
    
    -- Check if user already exists in auth.users (read-only check)
    SELECT id INTO test_user_id 
    FROM auth.users 
    WHERE email = 'piptrackr@gmail.com' 
    LIMIT 1;
    
    -- If user exists, set up profile and roles
    IF test_user_id IS NOT NULL THEN
        -- Ensure profile exists
        INSERT INTO public.profiles (user_id, display_name)
        VALUES (test_user_id, 'Test User')
        ON CONFLICT (user_id) DO NOTHING;
        
        -- Ensure user role exists
        INSERT INTO public.user_roles (user_id, role)
        VALUES (test_user_id, 'user'::app_role)
        ON CONFLICT (user_id, role) DO NOTHING;
        
        -- Also give admin role for testing
        INSERT INTO public.user_roles (user_id, role)
        VALUES (test_user_id, 'admin'::app_role)
        ON CONFLICT (user_id, role) DO NOTHING;
        
        RAISE NOTICE 'Test user profile and roles configured successfully';
    ELSE
        RAISE NOTICE 'User not found in auth.users. Please create the user through Supabase Dashboard first.';
    END IF;
END;
$$;