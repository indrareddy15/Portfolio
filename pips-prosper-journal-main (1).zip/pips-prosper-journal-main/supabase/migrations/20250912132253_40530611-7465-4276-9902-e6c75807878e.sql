-- Fix affiliate_applications table security vulnerabilities
-- This addresses the security finding: Affiliate Personal Information Could Be Stolen

-- First, ensure RLS is enabled on the table
ALTER TABLE public.affiliate_applications ENABLE ROW LEVEL SECURITY;

-- Drop all existing policies to clean up duplicates and start fresh
DROP POLICY IF EXISTS "Admins can manage all applications" ON public.affiliate_applications;
DROP POLICY IF EXISTS "Admins can view all applications" ON public.affiliate_applications;
DROP POLICY IF EXISTS "Deny anonymous access" ON public.affiliate_applications;
DROP POLICY IF EXISTS "Service role full access" ON public.affiliate_applications;
DROP POLICY IF EXISTS "Users can create own applications only" ON public.affiliate_applications;
DROP POLICY IF EXISTS "Users can update own applications" ON public.affiliate_applications;
DROP POLICY IF EXISTS "deny_anonymous_access" ON public.affiliate_applications;
DROP POLICY IF EXISTS "secure_admin_manage_all" ON public.affiliate_applications;
DROP POLICY IF EXISTS "secure_admin_select_all" ON public.affiliate_applications;
DROP POLICY IF EXISTS "secure_service_role_access" ON public.affiliate_applications;
DROP POLICY IF EXISTS "secure_user_insert_own" ON public.affiliate_applications;
DROP POLICY IF EXISTS "secure_user_select_own" ON public.affiliate_applications;
DROP POLICY IF EXISTS "secure_user_update_own" ON public.affiliate_applications;

-- Make user_id NOT NULL to ensure proper RLS enforcement
-- First, update any NULL user_id records to prevent constraint violations
UPDATE public.affiliate_applications 
SET user_id = '00000000-0000-0000-0000-000000000000'::uuid 
WHERE user_id IS NULL;

-- Now make the column NOT NULL
ALTER TABLE public.affiliate_applications 
ALTER COLUMN user_id SET NOT NULL;

-- Create comprehensive and secure RLS policies

-- 1. Service role access (for backend operations)
CREATE POLICY "service_role_full_access" 
ON public.affiliate_applications 
FOR ALL 
TO service_role
USING (true) 
WITH CHECK (true);

-- 2. Authenticated users can insert their own applications
CREATE POLICY "authenticated_users_can_insert_own_applications" 
ON public.affiliate_applications 
FOR INSERT 
TO authenticated
WITH CHECK (auth.uid() = user_id);

-- 3. Users can select only their own applications
CREATE POLICY "users_can_select_own_applications" 
ON public.affiliate_applications 
FOR SELECT 
TO authenticated
USING (auth.uid() = user_id);

-- 4. Users can update only their own applications (and only specific fields)
CREATE POLICY "users_can_update_own_applications" 
ON public.affiliate_applications 
FOR UPDATE 
TO authenticated
USING (auth.uid() = user_id)
WITH CHECK (auth.uid() = user_id);

-- 5. Only admins can select all applications
CREATE POLICY "admins_can_select_all_applications" 
ON public.affiliate_applications 
FOR SELECT 
TO authenticated
USING (has_role(auth.uid(), 'admin'::app_role));

-- 6. Only admins can update any application
CREATE POLICY "admins_can_update_all_applications" 
ON public.affiliate_applications 
FOR UPDATE 
TO authenticated
USING (has_role(auth.uid(), 'admin'::app_role))
WITH CHECK (has_role(auth.uid(), 'admin'::app_role));

-- 7. Only admins can delete applications  
CREATE POLICY "admins_can_delete_applications" 
ON public.affiliate_applications 
FOR DELETE 
TO authenticated
USING (has_role(auth.uid(), 'admin'::app_role));

-- 8. Explicitly deny all access to anonymous users
CREATE POLICY "deny_anonymous_access_to_affiliate_applications" 
ON public.affiliate_applications 
FOR ALL 
TO anon
USING (false) 
WITH CHECK (false);