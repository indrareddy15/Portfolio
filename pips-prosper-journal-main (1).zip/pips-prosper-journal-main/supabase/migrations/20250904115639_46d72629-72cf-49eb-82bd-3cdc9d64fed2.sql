-- Insert default plans and features for PipTrackr.com

-- Insert default plans
INSERT INTO public.plans (name, description, price_amount, billing_cycle, is_active, sort_order) VALUES
('Free', 'Perfect for getting started', 0.00, 'monthly', true, 1),
('Pro', 'For serious traders', 19.99, 'monthly', true, 2),
('Elite', 'For professional traders', 49.99, 'monthly', true, 3);

-- Get plan IDs for features
DO $$ 
DECLARE 
    free_plan_id UUID;
    pro_plan_id UUID;
    elite_plan_id UUID;
BEGIN
    -- Get plan IDs
    SELECT id INTO free_plan_id FROM public.plans WHERE name = 'Free';
    SELECT id INTO pro_plan_id FROM public.plans WHERE name = 'Pro';
    SELECT id INTO elite_plan_id FROM public.plans WHERE name = 'Elite';
    
    -- Insert features for Free plan
    INSERT INTO public.plan_features (plan_id, label, is_included, sort_order) VALUES
    (free_plan_id, 'Basic trade logging', true, 1),
    (free_plan_id, 'Manual trade entry', true, 2),
    (free_plan_id, 'CSV import', false, 3),
    (free_plan_id, 'Advanced analytics', false, 4),
    (free_plan_id, 'AI trade insights', false, 5),
    (free_plan_id, 'Priority support', false, 6),
    (free_plan_id, 'Custom integrations', false, 7);
    
    -- Insert features for Pro plan
    INSERT INTO public.plan_features (plan_id, label, is_included, sort_order) VALUES
    (pro_plan_id, 'Basic trade logging', true, 1),
    (pro_plan_id, 'Manual trade entry', true, 2),
    (pro_plan_id, 'CSV import', true, 3),
    (pro_plan_id, 'Advanced analytics', true, 4),
    (pro_plan_id, 'AI trade insights', false, 5),
    (pro_plan_id, 'Priority support', false, 6),
    (pro_plan_id, 'Custom integrations', false, 7);
    
    -- Insert features for Elite plan
    INSERT INTO public.plan_features (plan_id, label, is_included, sort_order) VALUES
    (elite_plan_id, 'Basic trade logging', true, 1),
    (elite_plan_id, 'Manual trade entry', true, 2),
    (elite_plan_id, 'CSV import', true, 3),
    (elite_plan_id, 'Advanced analytics', true, 4),
    (elite_plan_id, 'AI trade insights', true, 5),
    (elite_plan_id, 'Priority support', true, 6),
    (elite_plan_id, 'Custom integrations', true, 7);
END $$;