-- Create affiliate contracts table
CREATE TABLE public.affiliate_contracts (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    affiliate_id UUID NOT NULL REFERENCES public.affiliates(id) ON DELETE CASCADE,
    contract_type TEXT NOT NULL DEFAULT 'standard',
    contract_version TEXT NOT NULL DEFAULT '1.0',
    signed_at TIMESTAMP WITH TIME ZONE,
    signed_ip INET,
    signed_user_agent TEXT,
    status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'signed', 'rejected')),
    contract_data JSONB DEFAULT '{}',
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
    updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS on affiliate contracts
ALTER TABLE public.affiliate_contracts ENABLE ROW LEVEL SECURITY;

-- Create policies for affiliate contracts
CREATE POLICY "Affiliates can view their own contracts"
    ON public.affiliate_contracts
    FOR SELECT
    USING (affiliate_id IN (
        SELECT id FROM public.affiliates WHERE user_id = auth.uid()
    ));

CREATE POLICY "Affiliates can insert their own contracts"
    ON public.affiliate_contracts
    FOR INSERT
    WITH CHECK (affiliate_id IN (
        SELECT id FROM public.affiliates WHERE user_id = auth.uid()
    ));

CREATE POLICY "Affiliates can update their own contracts"
    ON public.affiliate_contracts
    FOR UPDATE
    USING (affiliate_id IN (
        SELECT id FROM public.affiliates WHERE user_id = auth.uid()
    ));

CREATE POLICY "Admins can manage all contracts"
    ON public.affiliate_contracts
    FOR ALL
    USING (has_role(auth.uid(), 'admin'::app_role));

-- Add updated_at trigger
CREATE TRIGGER update_affiliate_contracts_updated_at
    BEFORE UPDATE ON public.affiliate_contracts
    FOR EACH ROW
    EXECUTE FUNCTION public.update_updated_at_column();

-- Update payouts table to require KYC and contract completion
ALTER TABLE public.payouts 
ADD COLUMN IF NOT EXISTS kyc_required BOOLEAN DEFAULT TRUE,
ADD COLUMN IF NOT EXISTS contract_required BOOLEAN DEFAULT TRUE;

-- Add minimum payout threshold to affiliates table
ALTER TABLE public.affiliates 
ADD COLUMN IF NOT EXISTS minimum_payout NUMERIC DEFAULT 100.00;