-- Update trades table with new fields
ALTER TABLE public.trades 
ADD COLUMN IF NOT EXISTS status trade_status DEFAULT 'open',
ADD COLUMN IF NOT EXISTS commission numeric DEFAULT 0,
ADD COLUMN IF NOT EXISTS swap numeric DEFAULT 0,
ADD COLUMN IF NOT EXISTS fees numeric DEFAULT 0,
ADD COLUMN IF NOT EXISTS raw_pnl_quote numeric,
ADD COLUMN IF NOT EXISTS fx_rate_used numeric DEFAULT 1,
ADD COLUMN IF NOT EXISTS pnl_account numeric,
ADD COLUMN IF NOT EXISTS rr numeric,
ADD COLUMN IF NOT EXISTS pips_or_ticks numeric,
ADD COLUMN IF NOT EXISTS account_ccy text DEFAULT 'USD',
ADD COLUMN IF NOT EXISTS source trade_source DEFAULT 'manual',
ADD COLUMN IF NOT EXISTS provider_trade_id text,
ADD COLUMN IF NOT EXISTS lots numeric,
ADD COLUMN IF NOT EXISTS quantity numeric;

-- Update instruments table with new fields
ALTER TABLE public.instruments
ADD COLUMN IF NOT EXISTS contract_size numeric DEFAULT 100000,
ADD COLUMN IF NOT EXISTS point_value numeric DEFAULT 1,
ADD COLUMN IF NOT EXISTS tick_size numeric DEFAULT 0.0001;