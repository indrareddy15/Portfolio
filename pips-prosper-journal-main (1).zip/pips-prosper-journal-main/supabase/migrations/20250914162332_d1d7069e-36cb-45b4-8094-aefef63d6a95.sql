-- Enable realtime for blog tables that need it
ALTER TABLE blog_posts REPLICA IDENTITY FULL;
ALTER TABLE blog_categories REPLICA IDENTITY FULL;
ALTER TABLE blog_authors REPLICA IDENTITY FULL;
ALTER TABLE blog_tags REPLICA IDENTITY FULL;
ALTER TABLE blog_media REPLICA IDENTITY FULL;

-- Enable realtime for blog tables
ALTER PUBLICATION supabase_realtime ADD TABLE blog_posts;
ALTER PUBLICATION supabase_realtime ADD TABLE blog_categories;
ALTER PUBLICATION supabase_realtime ADD TABLE blog_authors;
ALTER PUBLICATION supabase_realtime ADD TABLE blog_tags;
ALTER PUBLICATION supabase_realtime ADD TABLE blog_media;