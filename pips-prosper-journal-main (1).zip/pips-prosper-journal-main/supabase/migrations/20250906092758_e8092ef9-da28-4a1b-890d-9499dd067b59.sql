-- Enable RLS and create policies for instrument_stats and session_stats tables
ALTER TABLE public.instrument_stats ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.session_stats ENABLE ROW LEVEL SECURITY;

-- Create policies for instrument_stats
CREATE POLICY "Users can manage their own instrument stats" 
ON public.instrument_stats 
FOR ALL 
USING (auth.uid() = user_id)
WITH CHECK (auth.uid() = user_id);

-- Create policies for session_stats  
CREATE POLICY "Users can manage their own session stats" 
ON public.session_stats 
FOR ALL 
USING (auth.uid() = user_id)
WITH CHECK (auth.uid() = user_id);

-- Enable realtime for logo_settings table
ALTER TABLE public.logo_settings REPLICA IDENTITY FULL;
ALTER PUBLICATION supabase_realtime ADD TABLE public.logo_settings;