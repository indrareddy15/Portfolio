-- Fix the function with proper search path for security
CREATE OR REPLACE FUNCTION public.auto_approve_affiliate_application()
RETURNS TRIGGER AS $$
DECLARE
    affiliate_code TEXT;
BEGIN
    -- Generate a unique affiliate code
    affiliate_code := 'AFF' || UPPER(SUBSTRING(MD5(NEW.id::text), 1, 8));
    
    -- Auto-approve the application
    NEW.status := 'approved';
    
    -- Create affiliate record immediately after approval
    INSERT INTO public.affiliates (
        user_id,
        code,
        status,
        default_rate_pct
    ) VALUES (
        NEW.user_id,
        affiliate_code,
        'active',
        10.00
    );
    
    RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = public;