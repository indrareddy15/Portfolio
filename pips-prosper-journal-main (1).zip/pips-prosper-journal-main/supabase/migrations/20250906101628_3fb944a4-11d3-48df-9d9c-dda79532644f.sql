-- Insert seed data for common instruments using correct column names
INSERT INTO public.instruments (symbol, class, lot_units, pip_size, price_precision, pip_precision, quote_ccy, contract_size, tick_size, pricing_mode, is_active) VALUES
  -- Major Forex Pairs
  ('EURUSD', 'forex', 100000, 0.0001, 5, 1, 'USD', 100000, 0.0001, 'forex', true),
  ('GBPUSD', 'forex', 100000, 0.0001, 5, 1, 'USD', 100000, 0.0001, 'forex', true),
  ('USDJPY', 'forex', 100000, 0.01, 3, 1, 'JPY', 100000, 0.01, 'forex', true),
  ('USDCHF', 'forex', 100000, 0.0001, 5, 1, 'CHF', 100000, 0.0001, 'forex', true),
  ('AUDUSD', 'forex', 100000, 0.0001, 5, 1, 'USD', 100000, 0.0001, 'forex', true),
  ('USDCAD', 'forex', 100000, 0.0001, 5, 1, 'CAD', 100000, 0.0001, 'forex', true),
  ('NZDUSD', 'forex', 100000, 0.0001, 5, 1, 'USD', 100000, 0.0001, 'forex', true),
  ('EURJPY', 'forex', 100000, 0.01, 3, 1, 'JPY', 100000, 0.01, 'forex', true),
  ('GBPJPY', 'forex', 100000, 0.01, 3, 1, 'JPY', 100000, 0.01, 'forex', true),
  ('EURGBP', 'forex', 100000, 0.0001, 5, 1, 'GBP', 100000, 0.0001, 'forex', true),
  
  -- Metals
  ('XAUUSD', 'metals', 100, 0.01, 2, 1, 'USD', 100, 0.01, 'forex', true),
  ('XAGUSD', 'metals', 5000, 0.001, 3, 1, 'USD', 5000, 0.001, 'forex', true),
  
  -- Indices
  ('US30', 'indices', 1, 1, 0, 1, 'USD', 1, 1, 'forex', true),
  ('NAS100', 'indices', 1, 0.1, 1, 1, 'USD', 1, 0.1, 'forex', true),
  ('SPX500', 'indices', 1, 0.1, 1, 1, 'USD', 1, 0.1, 'forex', true),
  ('GER30', 'indices', 1, 1, 0, 1, 'EUR', 1, 1, 'forex', true),
  ('UK100', 'indices', 1, 1, 0, 1, 'GBP', 1, 1, 'forex', true),
  
  -- Crypto
  ('BTCUSD', 'crypto', 1, 0.1, 1, 1, 'USD', 1, 0.1, 'forex', true),
  ('ETHUSD', 'crypto', 1, 0.01, 2, 1, 'USD', 1, 0.01, 'forex', true),
  ('ADAUSD', 'crypto', 1, 0.0001, 4, 1, 'USD', 1, 0.0001, 'forex', true)
ON CONFLICT (symbol) DO NOTHING;

-- Update calculation functions with correct column names
DROP FUNCTION IF EXISTS public.calculate_pip_value(TEXT, DECIMAL, TEXT);
DROP FUNCTION IF EXISTS public.calculate_trade_pnl(TEXT, TEXT, DECIMAL, DECIMAL, DECIMAL, INTEGER, INTEGER, TEXT);

-- Create updated calculation helper functions
CREATE OR REPLACE FUNCTION public.calculate_pip_value(
  symbol TEXT,
  lots DECIMAL,
  account_currency TEXT DEFAULT 'USD'
) RETURNS DECIMAL AS $$
DECLARE
  instrument_rec RECORD;
  pip_value DECIMAL;
  fx_rate DECIMAL := 1.0;
BEGIN
  -- Get instrument details
  SELECT * INTO instrument_rec FROM public.instruments WHERE instruments.symbol = calculate_pip_value.symbol LIMIT 1;
  
  IF NOT FOUND THEN
    RETURN 0;
  END IF;
  
  -- Calculate base pip value using correct column names
  pip_value := (instrument_rec.pip_size * lots * instrument_rec.contract_size);
  
  -- Convert to account currency if needed
  IF instrument_rec.quote_ccy != account_currency THEN
    SELECT rate INTO fx_rate 
    FROM public.fx_rates_new 
    WHERE base_currency = instrument_rec.quote_ccy 
      AND quote_currency = account_currency 
      AND rate_date <= CURRENT_DATE
    ORDER BY rate_date DESC 
    LIMIT 1;
    
    IF fx_rate IS NULL THEN
      fx_rate := 1.0;
    END IF;
    
    pip_value := pip_value * fx_rate;
  END IF;
  
  RETURN pip_value;
END;
$$ LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path = public;

-- Create updated function to calculate trade PnL
CREATE OR REPLACE FUNCTION public.calculate_trade_pnl(
  symbol TEXT,
  side TEXT,
  lots DECIMAL,
  entry_price DECIMAL,
  exit_price DECIMAL,
  commission_cents INTEGER DEFAULT 0,
  swap_cents INTEGER DEFAULT 0,
  account_currency TEXT DEFAULT 'USD'
) RETURNS INTEGER AS $$
DECLARE
  instrument_rec RECORD;
  direction INTEGER := 1;
  pnl_raw DECIMAL;
  fx_rate DECIMAL := 1.0;
  pnl_cents INTEGER;
BEGIN
  -- Get instrument details
  SELECT * INTO instrument_rec FROM public.instruments WHERE instruments.symbol = calculate_trade_pnl.symbol LIMIT 1;
  
  IF NOT FOUND THEN
    RETURN 0;
  END IF;
  
  -- Set direction multiplier
  IF side = 'short' THEN
    direction := -1;
  END IF;
  
  -- Calculate raw PnL using correct column names
  pnl_raw := (exit_price - entry_price) * direction * lots * instrument_rec.contract_size;
  
  -- Convert to account currency if needed
  IF instrument_rec.quote_ccy != account_currency THEN
    SELECT rate INTO fx_rate 
    FROM public.fx_rates_new 
    WHERE base_currency = instrument_rec.quote_ccy 
      AND quote_currency = account_currency 
      AND rate_date <= CURRENT_DATE
    ORDER BY rate_date DESC 
    LIMIT 1;
    
    IF fx_rate IS NULL THEN
      fx_rate := 1.0;
    END IF;
    
    pnl_raw := pnl_raw * fx_rate;
  END IF;
  
  -- Convert to cents and subtract fees
  pnl_cents := (pnl_raw * 100)::INTEGER - COALESCE(commission_cents, 0) - COALESCE(swap_cents, 0);
  
  RETURN pnl_cents;
END;
$$ LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path = public;