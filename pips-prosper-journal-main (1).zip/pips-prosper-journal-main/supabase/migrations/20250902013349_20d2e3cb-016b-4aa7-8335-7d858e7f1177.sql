-- Enable real-time for affiliate applications table
ALTER TABLE public.affiliate_applications REPLICA IDENTITY FULL;

-- Add the table to the real-time publication  
ALTER PUBLICATION supabase_realtime ADD TABLE public.affiliate_applications;

-- Enable real-time for affiliates table too
ALTER TABLE public.affiliates REPLICA IDENTITY FULL;
ALTER PUBLICATION supabase_realtime ADD TABLE public.affiliates;

-- Create a trigger function to auto-approve applications
CREATE OR REPLACE FUNCTION public.auto_approve_affiliate_application()
RETURNS TRIGGER AS $$
DECLARE
    affiliate_code TEXT;
BEGIN
    -- Generate a unique affiliate code
    affiliate_code := 'AFF' || UPPER(SUBSTRING(MD5(NEW.id::text), 1, 8));
    
    -- Auto-approve the application
    NEW.status := 'approved';
    
    -- Create affiliate record immediately after approval
    INSERT INTO public.affiliates (
        user_id,
        code,
        status,
        default_rate_pct
    ) VALUES (
        NEW.user_id,
        affiliate_code,
        'active',
        10.00
    );
    
    RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Create trigger to auto-approve applications on insert
CREATE OR REPLACE TRIGGER trigger_auto_approve_affiliate
    BEFORE INSERT ON public.affiliate_applications
    FOR EACH ROW
    EXECUTE FUNCTION public.auto_approve_affiliate_application();