-- Add new roles to app_role enum
ALTER TYPE app_role ADD VALUE IF NOT EXISTS 'developer';
ALTER TYPE app_role ADD VALUE IF NOT EXISTS 'sales';
ALTER TYPE app_role ADD VALUE IF NOT EXISTS 'support';
ALTER TYPE app_role ADD VALUE IF NOT EXISTS 'marketing';
ALTER TYPE app_role ADD VALUE IF NOT EXISTS 'finance';