-- Create a webhook function to send welcome emails for new affiliates
CREATE OR REPLACE FUNCTION public.notify_new_affiliate()
RETURNS TRIGGER AS $$
DECLARE
    webhook_url TEXT;
    payload JSON;
BEGIN
    -- Set the webhook URL to our edge function
    webhook_url := 'https://pwpxzlcpdbqjckvmkwlw.supabase.co/functions/v1/send-affiliate-welcome';
    
    -- Prepare the payload
    payload := json_build_object(
        'type', 'INSERT',
        'table', 'affiliates',
        'record', row_to_json(NEW),
        'old_record', null
    );
    
    -- Make async HTTP request to the webhook (this is a fire-and-forget call)
    PERFORM net.http_post(
        url := webhook_url,
        body := payload::text,
        headers := jsonb_build_object(
            'Content-Type', 'application/json',
            'Authorization', 'Bearer ' || current_setting('app.settings.service_role_key', true)
        )
    );
    
    RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Create trigger to send welcome email when affiliate is created
CREATE OR REPLACE TRIGGER trigger_notify_new_affiliate
    AFTER INSERT ON public.affiliates
    FOR EACH ROW
    EXECUTE FUNCTION public.notify_new_affiliate();