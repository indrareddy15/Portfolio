-- Fix the security warning by setting search_path in the function
CREATE OR REPLACE FUNCTION public.log_trade_changes()
RETURNS TRIGGER AS $$
BEGIN
  -- Log INSERT
  IF TG_OP = 'INSERT' THEN
    INSERT INTO public.trade_history (
      trade_id,
      user_id,
      action,
      new_values,
      changed_fields
    ) VALUES (
      NEW.id,
      NEW.user_id,
      'created',
      to_jsonb(NEW),
      ARRAY['*'] -- All fields for new record
    );
    RETURN NEW;
  END IF;

  -- Log UPDATE
  IF TG_OP = 'UPDATE' THEN
    DECLARE
      changed_fields text[] := '{}';
      field_name text;
    BEGIN
      -- Check each field for changes
      FOR field_name IN 
        SELECT column_name 
        FROM information_schema.columns 
        WHERE table_name = 'trades' 
        AND table_schema = 'public'
        AND column_name NOT IN ('updated_at', 'created_at')
      LOOP
        IF to_jsonb(OLD) -> field_name IS DISTINCT FROM to_jsonb(NEW) -> field_name THEN
          changed_fields := array_append(changed_fields, field_name);
        END IF;
      END LOOP;

      -- Only log if there are actual changes
      IF array_length(changed_fields, 1) > 0 THEN
        INSERT INTO public.trade_history (
          trade_id,
          user_id,
          action,
          old_values,
          new_values,
          changed_fields
        ) VALUES (
          NEW.id,
          NEW.user_id,
          CASE 
            WHEN OLD.closed_at IS NULL AND NEW.closed_at IS NOT NULL THEN 'closed'
            ELSE 'updated'
          END,
          to_jsonb(OLD),
          to_jsonb(NEW),
          changed_fields
        );
      END IF;
    END;
    RETURN NEW;
  END IF;

  -- Log DELETE
  IF TG_OP = 'DELETE' THEN
    INSERT INTO public.trade_history (
      trade_id,
      user_id,
      action,
      old_values,
      new_values,
      changed_fields
    ) VALUES (
      OLD.id,
      OLD.user_id,
      'deleted',
      to_jsonb(OLD),
      '{}'::jsonb,
      ARRAY['*']
    );
    RETURN OLD;
  END IF;

  RETURN NULL;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = public;