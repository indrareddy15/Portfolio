-- Continue creating the remaining tables for the extended schema

-- Create prop_rules table
CREATE TABLE IF NOT EXISTS public.prop_rules (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  account_id UUID UNIQUE NOT NULL REFERENCES public.accounts(id),
  daily_loss_pct DECIMAL(5,2) NOT NULL,
  max_loss_pct DECIMAL(5,2) NOT NULL,
  min_days INTEGER NOT NULL DEFAULT 10,
  max_lots DECIMAL(10,2),
  end_date DATE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Enable RLS for prop_rules
ALTER TABLE public.prop_rules ENABLE ROW LEVEL SECURITY;

-- Policies for prop_rules
CREATE POLICY "Users can manage their account prop rules" 
ON public.prop_rules 
FOR ALL 
USING (
  account_id IN (
    SELECT id FROM public.accounts WHERE user_id = auth.uid()
  )
);

-- Create prop_daily_results table
CREATE TABLE IF NOT EXISTS public.prop_daily_results (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  account_id UUID NOT NULL REFERENCES public.accounts(id),
  result_date DATE NOT NULL,
  passed BOOLEAN NOT NULL DEFAULT true,
  fail_reasons TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE(account_id, result_date)
);

-- Enable RLS for prop_daily_results
ALTER TABLE public.prop_daily_results ENABLE ROW LEVEL SECURITY;

-- Policies for prop_daily_results
CREATE POLICY "Users can manage their account prop results" 
ON public.prop_daily_results 
FOR ALL 
USING (
  account_id IN (
    SELECT id FROM public.accounts WHERE user_id = auth.uid()
  )
);

-- Create strategies table
CREATE TABLE IF NOT EXISTS public.strategies (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL,
  name TEXT NOT NULL,
  rules_json JSONB DEFAULT '{}',
  active BOOLEAN DEFAULT true,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Enable RLS for strategies
ALTER TABLE public.strategies ENABLE ROW LEVEL SECURITY;

-- Policies for strategies
CREATE POLICY "Users can manage their own strategies" 
ON public.strategies 
FOR ALL 
USING (auth.uid() = user_id);

-- Add indexes for performance
CREATE INDEX IF NOT EXISTS idx_connections_user_provider ON public.connections(user_id, provider, status);
CREATE INDEX IF NOT EXISTS idx_sync_logs_account_provider ON public.sync_logs(account_id, provider, created_at);
CREATE INDEX IF NOT EXISTS idx_fx_rates_new_date ON public.fx_rates_new(rate_date);
CREATE INDEX IF NOT EXISTS idx_metrics_snapshots_user_account ON public.metrics_snapshots(user_id, account_id, scope, created_at);
CREATE INDEX IF NOT EXISTS idx_equity_points_user_account ON public.equity_points(user_id, account_id, timestamp);

-- Add updated_at triggers for tables that need them
CREATE TRIGGER update_instruments_updated_at
  BEFORE UPDATE ON public.instruments
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_connections_updated_at
  BEFORE UPDATE ON public.connections
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_prop_rules_updated_at
  BEFORE UPDATE ON public.prop_rules
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_strategies_updated_at
  BEFORE UPDATE ON public.strategies
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at_column();