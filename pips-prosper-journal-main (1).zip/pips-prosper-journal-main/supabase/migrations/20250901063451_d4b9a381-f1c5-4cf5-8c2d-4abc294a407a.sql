-- Update RLS policy to remove moderator access to affiliate applications
-- Only admins and application owners should be able to view applications

DROP POLICY IF EXISTS "Users can view their own applications" ON public.affiliate_applications;

CREATE POLICY "Users can view their own applications" 
ON public.affiliate_applications 
FOR SELECT 
USING ((auth.uid() = user_id) OR has_role(auth.uid(), 'admin'::app_role));