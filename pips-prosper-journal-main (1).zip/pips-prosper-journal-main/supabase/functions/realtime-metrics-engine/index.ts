import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

interface Trade {
  id: string;
  user_id: string;
  account_id: string;
  instrument: string;
  side: string;
  entry_price: number;
  exit_price?: number;
  lots?: number;
  size?: number;
  commission?: number;
  swap?: number;
  fees?: number;
  opened_at: string;
  closed_at?: string;
  status?: string;
  raw_pnl_quote?: number;
  fx_rate_used?: number;
  pnl_account?: number;
  pips_or_ticks?: number;
  rr?: number;
  account_ccy?: string;
}

interface MetricsCalculation {
  total_pnl: number;
  net_pnl: number;
  win_rate: number;
  avg_rr: number;
  profit_factor: number;
  expectancy: number;
  max_dd: number;
  sharpe: number;
  longest_win: number;
  longest_loss: number;
  trade_count: number;
}

serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseClient = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
    );

    const { user_id, trade_id } = await req.json();

    if (!user_id) {
      throw new Error('user_id is required');
    }

    console.log('Starting metrics calculation for user:', user_id);

    // Get all trades for this user
    const { data: trades, error: tradesError } = await supabaseClient
      .from('trades')
      .select('*')
      .eq('user_id', user_id)
      .order('opened_at', { ascending: true });

    if (tradesError) {
      throw tradesError;
    }

    console.log(`Found ${trades?.length || 0} trades for user ${user_id}`);

    // Calculate metrics
    const metrics = calculateMetrics(trades || []);
    
    // Update or insert metrics_summary for all_time scope
    const { error: metricsError } = await supabaseClient
      .from('metrics_summary')
      .upsert({
        user_id,
        scope: 'all_time',
        start_ts: null,
        end_ts: null,
        ...metrics,
      });

    if (metricsError) {
      console.error('Error updating metrics summary:', metricsError);
      throw metricsError;
    }

    // Update instrument stats
    await updateInstrumentStats(supabaseClient, user_id, trades || []);

    // Update session stats  
    await updateSessionStats(supabaseClient, user_id, trades || []);

    // Create equity snapshot if we have a specific trade
    if (trade_id) {
      await createEquitySnapshot(supabaseClient, user_id, trades || []);
    }

    console.log('Metrics calculation completed successfully');

    return new Response(
      JSON.stringify({ 
        success: true, 
        metrics,
        message: 'Metrics updated successfully' 
      }),
      {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 200,
      }
    );

  } catch (error) {
    console.error('Error in metrics calculation:', error);
    return new Response(
      JSON.stringify({ 
        error: error.message,
        success: false 
      }),
      {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 500,
      }
    );
  }
});

function calculateMetrics(trades: Trade[]): MetricsCalculation {
  console.log('Calculating metrics for', trades.length, 'trades');

  if (!trades.length) {
    return {
      total_pnl: 0,
      net_pnl: 0,
      win_rate: 0,
      avg_rr: 0,
      profit_factor: 0,
      expectancy: 0,
      max_dd: 0,
      sharpe: 0,
      longest_win: 0,
      longest_loss: 0,
      trade_count: 0,
    };
  }

  const closedTrades = trades.filter(t => t.status === 'closed' && t.pnl_account !== null);
  
  if (!closedTrades.length) {
    return {
      total_pnl: 0,
      net_pnl: 0,
      win_rate: 0,
      avg_rr: 0,
      profit_factor: 0,
      expectancy: 0,
      max_dd: 0,
      sharpe: 0,
      longest_win: 0,
      longest_loss: 0,
      trade_count: trades.length,
    };
  }

  // Basic calculations
  const total_pnl = closedTrades.reduce((sum, t) => sum + (t.pnl_account || 0), 0);
  const net_pnl = total_pnl - closedTrades.reduce((sum, t) => 
    sum + (t.commission || 0) + (t.swap || 0) + (t.fees || 0), 0);

  const winningTrades = closedTrades.filter(t => (t.pnl_account || 0) > 0);
  const losingTrades = closedTrades.filter(t => (t.pnl_account || 0) < 0);
  
  const win_rate = closedTrades.length > 0 ? winningTrades.length / closedTrades.length : 0;

  // Average R:R calculation
  const rrTrades = closedTrades.filter(t => t.rr && t.rr > 0);
  const avg_rr = rrTrades.length > 0 ? 
    rrTrades.reduce((sum, t) => sum + (t.rr || 0), 0) / rrTrades.length : 0;

  // Profit factor
  const grossProfit = winningTrades.reduce((sum, t) => sum + (t.pnl_account || 0), 0);
  const grossLoss = Math.abs(losingTrades.reduce((sum, t) => sum + (t.pnl_account || 0), 0));
  const profit_factor = grossLoss > 0 ? grossProfit / grossLoss : 0;

  // Expectancy
  const expectancy = closedTrades.length > 0 ? net_pnl / closedTrades.length : 0;

  // Calculate drawdown
  let runningBalance = 0;
  let peak = 0;
  let maxDrawdown = 0;

  closedTrades.forEach(trade => {
    runningBalance += (trade.pnl_account || 0);
    if (runningBalance > peak) {
      peak = runningBalance;
    }
    const drawdown = (peak - runningBalance) / (peak || 1);
    if (drawdown > maxDrawdown) {
      maxDrawdown = drawdown;
    }
  });

  // Streak calculations
  let currentWinStreak = 0;
  let currentLossStreak = 0;
  let longestWin = 0;
  let longestLoss = 0;

  closedTrades.forEach(trade => {
    if ((trade.pnl_account || 0) > 0) {
      currentWinStreak++;
      currentLossStreak = 0;
      if (currentWinStreak > longestWin) {
        longestWin = currentWinStreak;
      }
    } else {
      currentLossStreak++;
      currentWinStreak = 0;
      if (currentLossStreak > longestLoss) {
        longestLoss = currentLossStreak;
      }
    }
  });

  // Sharpe ratio (simplified - would need risk-free rate for proper calculation)
  const returns = closedTrades.map(t => (t.pnl_account || 0));
  const meanReturn = returns.reduce((a, b) => a + b, 0) / returns.length;
  const variance = returns.reduce((sum, r) => sum + Math.pow(r - meanReturn, 2), 0) / returns.length;
  const stdDev = Math.sqrt(variance);
  const sharpe = stdDev > 0 ? meanReturn / stdDev : 0;

  return {
    total_pnl,
    net_pnl,
    win_rate,
    avg_rr,
    profit_factor,
    expectancy,
    max_dd: maxDrawdown,
    sharpe,
    longest_win: longestWin,
    longest_loss: longestLoss,
    trade_count: trades.length,
  };
}

async function updateInstrumentStats(supabaseClient: any, userId: string, trades: Trade[]) {
  const instrumentGroups = trades.reduce((acc: any, trade) => {
    if (!acc[trade.instrument]) {
      acc[trade.instrument] = [];
    }
    acc[trade.instrument].push(trade);
    return acc;
  }, {});

  for (const [symbol, symbolTrades] of Object.entries(instrumentGroups)) {
    const tradesArray = symbolTrades as Trade[];
    const closedTrades = tradesArray.filter(t => t.status === 'closed' && t.pnl_account !== null);
    
    const pnl = closedTrades.reduce((sum, t) => sum + (t.pnl_account || 0), 0);
    const winningTrades = closedTrades.filter(t => (t.pnl_account || 0) > 0);
    const win_rate = closedTrades.length > 0 ? winningTrades.length / closedTrades.length : 0;
    
    const rrTrades = closedTrades.filter(t => t.rr && t.rr > 0);
    const avg_rr = rrTrades.length > 0 ? 
      rrTrades.reduce((sum, t) => sum + (t.rr || 0), 0) / rrTrades.length : 0;

    await supabaseClient
      .from('instrument_stats')
      .upsert({
        user_id: userId,
        symbol,
        trade_count: tradesArray.length,
        pnl,
        win_rate,
        avg_rr,
      });
  }
}

async function updateSessionStats(supabaseClient: any, userId: string, trades: Trade[]) {
  const sessionGroups = trades.reduce((acc: any, trade) => {
    const session = getTradingSession(new Date(trade.opened_at));
    if (!acc[session]) {
      acc[session] = [];
    }
    acc[session].push(trade);
    return acc;
  }, {});

  for (const [session, sessionTrades] of Object.entries(sessionGroups)) {
    const tradesArray = sessionTrades as Trade[];
    const closedTrades = tradesArray.filter(t => t.status === 'closed' && t.pnl_account !== null);
    const pnl = closedTrades.reduce((sum, t) => sum + (t.pnl_account || 0), 0);

    await supabaseClient
      .from('session_stats')
      .upsert({
        user_id: userId,
        session,
        pnl,
        trade_count: tradesArray.length,
      });
  }
}

async function createEquitySnapshot(supabaseClient: any, userId: string, trades: Trade[]) {
  const closedTrades = trades.filter(t => t.status === 'closed' && t.pnl_account !== null);
  const totalEquity = closedTrades.reduce((sum, t) => sum + (t.pnl_account || 0), 0);

  await supabaseClient
    .from('equity_snapshots')
    .insert({
      user_id: userId,
      time_utc: new Date().toISOString(),
      equity_account: totalEquity,
    });
}

function getTradingSession(timestamp: Date): string {
  const utcHour = timestamp.getUTCHours();
  
  if ((utcHour >= 22) || (utcHour < 8)) {
    return 'Asian';
  } else if (utcHour >= 8 && utcHour < 16) {
    return 'London';
  } else if (utcHour >= 13 && utcHour < 21) {
    return 'NY';
  } else {
    return 'Other';
  }
}