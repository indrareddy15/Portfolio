import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import Stripe from "https://esm.sh/stripe@14.21.0";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.45.0";

const logStep = (step: string, details?: any) => {
  const detailsStr = details ? ` - ${JSON.stringify(details)}` : '';
  console.log(`[PRICING-WEBHOOK] ${step}${detailsStr}`);
};

serve(async (req) => {
  try {
    logStep("Webhook received");

    const stripeKey = Deno.env.get('STRIPE_SECRET_KEY');
    if (!stripeKey) {
      throw new Error('STRIPE_SECRET_KEY is not set');
    }

    const signature = req.headers.get('stripe-signature');
    if (!signature) {
      throw new Error('No Stripe signature found');
    }

    const body = await req.text();
    const stripe = new Stripe(stripeKey, { apiVersion: '2023-10-16' });

    // Verify webhook signature (you'll need to set STRIPE_WEBHOOK_SECRET)
    let event;
    try {
      const webhookSecret = Deno.env.get('STRIPE_WEBHOOK_SECRET');
      if (webhookSecret) {
        event = stripe.webhooks.constructEvent(body, signature, webhookSecret);
      } else {
        // For development - parse without verification
        event = JSON.parse(body);
        logStep("WARNING: Webhook signature not verified (no STRIPE_WEBHOOK_SECRET)");
      }
    } catch (err) {
      logStep("Webhook signature verification failed", { error: err.message });
      return new Response(`Webhook signature verification failed: ${err.message}`, { status: 400 });
    }

    logStep("Event received", { type: event.type, id: event.id });

    // Create Supabase client with service role for database writes
    const supabaseService = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? '',
      { auth: { persistSession: false } }
    );

    // Handle different event types
    switch (event.type) {
      case 'checkout.session.completed': {
        const session = event.data.object as Stripe.Checkout.Session;
        logStep("Processing checkout.session.completed", { sessionId: session.id });

        if (session.mode === 'subscription' && session.subscription) {
          // Get subscription details
          const subscription = await stripe.subscriptions.retrieve(session.subscription as string);
          const customerId = session.customer as string;
          
          // Find user by customer ID
          const customer = await stripe.customers.retrieve(customerId);
          const userEmail = (customer as Stripe.Customer).email;
          
          if (userEmail) {
            // Update user subscription
            await supabaseService.from('user_subscriptions').upsert({
              user_id: session.metadata?.user_id,
              plan_id: session.metadata?.plan_id || null,
              stripe_customer_id: customerId,
              stripe_subscription_id: subscription.id,
              status: subscription.status,
              current_period_start: new Date(subscription.current_period_start * 1000).toISOString(),
              current_period_end: new Date(subscription.current_period_end * 1000).toISOString(),
              cancel_at_period_end: subscription.cancel_at_period_end,
            }, { 
              onConflict: 'user_id',
              ignoreDuplicates: false 
            });
            
            logStep("Subscription record updated");
          }
        }
        break;
      }

      case 'customer.subscription.updated':
      case 'customer.subscription.deleted': {
        const subscription = event.data.object as Stripe.Subscription;
        logStep(`Processing ${event.type}`, { subscriptionId: subscription.id });

        await supabaseService
          .from('user_subscriptions')
          .update({
            status: subscription.status,
            current_period_start: new Date(subscription.current_period_start * 1000).toISOString(),
            current_period_end: new Date(subscription.current_period_end * 1000).toISOString(),
            cancel_at_period_end: subscription.cancel_at_period_end,
          })
          .eq('stripe_subscription_id', subscription.id);

        logStep("Subscription updated");
        break;
      }

      case 'invoice.payment_succeeded':
      case 'invoice.payment_failed':
      case 'invoice.finalized': {
        const invoice = event.data.object as Stripe.Invoice;
        logStep(`Processing ${event.type}`, { invoiceId: invoice.id });

        // Find user by customer ID
        if (invoice.customer) {
          const { data: subscription } = await supabaseService
            .from('user_subscriptions')
            .select('user_id')
            .eq('stripe_customer_id', invoice.customer)
            .single();

          if (subscription?.user_id) {
            await supabaseService.from('user_invoices').upsert({
              user_id: subscription.user_id,
              stripe_invoice_id: invoice.id,
              amount_due: (invoice.amount_due || 0) / 100, // Convert from cents
              currency: invoice.currency?.toUpperCase() || 'USD',
              status: invoice.status as any,
              hosted_invoice_url: invoice.hosted_invoice_url,
              invoice_pdf_url: invoice.invoice_pdf,
            }, { 
              onConflict: 'stripe_invoice_id',
              ignoreDuplicates: false 
            });
            
            logStep("Invoice record updated");
          }
        }
        break;
      }

      default:
        logStep("Unhandled event type", { type: event.type });
    }

    return new Response(JSON.stringify({ received: true }), {
      headers: { 'Content-Type': 'application/json' },
      status: 200,
    });

  } catch (error: any) {
    const errorMessage = error instanceof Error ? error.message : String(error);
    logStep("ERROR", { message: errorMessage, stack: error?.stack });
    
    return new Response(JSON.stringify({ error: errorMessage }), {
      headers: { 'Content-Type': 'application/json' },
      status: 500,
    });
  }
});