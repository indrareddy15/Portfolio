import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.7.1'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
  'Content-Type': 'application/xml',
}

interface BlogPost {
  id: string;
  title: string;
  slug: string;
  excerpt: string;
  body_md: string;
  cover_url: string;
  publish_at: string;
  updated_at: string;
  category: {
    name: string;
    slug: string;
  };
  author: {
    name: string;
    slug: string;
  };
}

serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const url = new URL(req.url);
    const feedType = url.searchParams.get('type') || 'rss';
    const limit = parseInt(url.searchParams.get('limit') || '50');
    
    // Initialize Supabase client
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const supabase = createClient(supabaseUrl, supabaseKey);

    // Fetch blog settings
    const { data: settings } = await supabase
      .from('blog_settings')
      .select('*');
    
    const generalSettings = settings?.find(s => s.key === 'general')?.value || {};
    const siteTitle = generalSettings.siteTitle || 'PipTrackr Blog';
    const siteDescription = generalSettings.siteDescription || 'Trading insights, tips and strategies from PipTrackr';
    const siteUrl = 'https://piptrackr.com';

    // Fetch published posts
    const { data: posts, error } = await supabase
      .from('blog_posts')
      .select(`
        id,
        title,
        slug,
        excerpt,
        body_md,
        cover_url,
        publish_at,
        updated_at,
        category:blog_categories(name, slug),
        author:blog_authors(name, slug)
      `)
      .eq('status', 'published')
      .lte('publish_at', new Date().toISOString())
      .order('publish_at', { ascending: false })
      .limit(limit);

    if (error) {
      throw error;
    }

    const typedPosts = posts as BlogPost[];

    // Generate RSS XML
    const rssXml = generateRSSFeed({
      title: siteTitle,
      description: siteDescription,
      link: `${siteUrl}/blog`,
      posts: typedPosts,
      siteUrl
    });

    return new Response(rssXml, {
      headers: {
        ...corsHeaders,
        'Cache-Control': 'public, max-age=3600', // Cache for 1 hour
      },
    });

  } catch (error) {
    console.error('Error generating RSS feed:', error);
    return new Response(
      `<?xml version="1.0" encoding="UTF-8"?>
      <error>Failed to generate RSS feed</error>`,
      {
        status: 500,
        headers: corsHeaders,
      }
    );
  }
});

function generateRSSFeed(config: {
  title: string;
  description: string;
  link: string;
  posts: BlogPost[];
  siteUrl: string;
}): string {
  const { title, description, link, posts, siteUrl } = config;
  const buildDate = new Date().toUTCString();

  const items = posts.map(post => {
    const postUrl = `${siteUrl}/blog/${post.slug}`;
    const pubDate = new Date(post.publish_at).toUTCString();
    
    // Clean up HTML for RSS (simple markdown to HTML conversion)
    const content = post.body_md
      .replace(/^# (.*$)/gim, '<h1>$1</h1>')
      .replace(/^## (.*$)/gim, '<h2>$1</h2>')
      .replace(/^### (.*$)/gim, '<h3>$1</h3>')
      .replace(/\*\*(.*)\*\*/gim, '<strong>$1</strong>')
      .replace(/\*(.*)\*/gim, '<em>$1</em>')
      .replace(/\n\n/g, '</p><p>')
      .replace(/^/, '<p>')
      .replace(/$/, '</p>');

    return `
      <item>
        <title><![CDATA[${post.title}]]></title>
        <link>${postUrl}</link>
        <guid>${postUrl}</guid>
        <pubDate>${pubDate}</pubDate>
        <author>noreply@piptrackr.com (${post.author.name})</author>
        <category><![CDATA[${post.category.name}]]></category>
        <description><![CDATA[${post.excerpt || post.title}]]></description>
        <content:encoded><![CDATA[${content}]]></content:encoded>
        ${post.cover_url ? `<media:content url="${post.cover_url}" type="image/jpeg" />` : ''}
      </item>
    `;
  }).join('');

  return `<?xml version="1.0" encoding="UTF-8"?>
<rss version="2.0" 
     xmlns:content="http://purl.org/rss/1.0/modules/content/"
     xmlns:media="http://search.yahoo.com/mrss/">
  <channel>
    <title><![CDATA[${title}]]></title>
    <description><![CDATA[${description}]]></description>
    <link>${link}</link>
    <language>en-us</language>
    <lastBuildDate>${buildDate}</lastBuildDate>
    <generator>PipTrackr Blog Engine</generator>
    ${items}
  </channel>
</rss>`;
}