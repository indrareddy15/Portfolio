import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.45.0";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

const handler = async (req: Request): Promise<Response> => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const url = new URL(req.url);
    const email = url.searchParams.get('email');
    const templateKey = url.searchParams.get('template');
    const reason = url.searchParams.get('reason') || 'user_request';

    if (!email) {
      return new Response(
        `
        <html>
          <head><title>Invalid Request</title></head>
          <body style="font-family: Arial, sans-serif; max-width: 600px; margin: 50px auto; padding: 20px;">
            <h1>Invalid Request</h1>
            <p>Email address is required to unsubscribe.</p>
          </body>
        </html>
        `,
        { 
          status: 400, 
          headers: { ...corsHeaders, 'Content-Type': 'text/html' } 
        }
      );
    }

    const supabase = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
    );

    // Handle POST request (form submission)
    if (req.method === 'POST') {
      const formData = await req.formData();
      const confirmEmail = formData.get('email')?.toString();
      const selectedTemplates = formData.getAll('templates');
      const customReason = formData.get('custom_reason')?.toString() || 'user_request';

      if (confirmEmail !== email) {
        return new Response(
          `
          <html>
            <head><title>Email Mismatch</title></head>
            <body style="font-family: Arial, sans-serif; max-width: 600px; margin: 50px auto; padding: 20px;">
              <h1>Email Mismatch</h1>
              <p>The email address doesn't match. Please try again.</p>
              <a href="?email=${email}">Go back</a>
            </body>
          </html>
          `,
          { 
            status: 400, 
            headers: { ...corsHeaders, 'Content-Type': 'text/html' } 
          }
        );
      }

      // Process unsubscribe requests
      const unsubscribePromises = selectedTemplates.map(template => 
        supabase
          .from('email_unsubscribes')
          .insert({
            email: confirmEmail,
            template_key: template.toString(),
            reason: customReason
          })
      );

      await Promise.all(unsubscribePromises);

      console.log(`Unsubscribed ${confirmEmail} from ${selectedTemplates.length} templates`);

      return new Response(
        `
        <html>
          <head>
            <title>Successfully Unsubscribed</title>
            <style>
              body { font-family: Arial, sans-serif; max-width: 600px; margin: 50px auto; padding: 20px; }
              .success { background: #f0f8ff; border: 1px solid #0066cc; border-radius: 8px; padding: 20px; }
              .contact { margin-top: 30px; padding: 15px; background: #f8f9fa; border-radius: 6px; }
            </style>
          </head>
          <body>
            <div class="success">
              <h1 style="color: #0066cc;">✓ Successfully Unsubscribed</h1>
              <p>You have been unsubscribed from the selected email types.</p>
              <p><strong>Email:</strong> ${confirmEmail}</p>
              <p><strong>Templates:</strong> ${selectedTemplates.join(', ')}</p>
            </div>
            <div class="contact">
              <h3>Need Help?</h3>
              <p>If you have any questions or need assistance, please contact us at <a href="mailto:support@piptrackr.com">support@piptrackr.com</a></p>
            </div>
          </body>
        </html>
        `,
        { 
          status: 200, 
          headers: { ...corsHeaders, 'Content-Type': 'text/html' } 
        }
      );
    }

    // Handle GET request (show unsubscribe form)
    const availableTemplates = [
      'team_invite',
      'affiliate_approved', 
      'commission_approved',
      'payout_processed',
      'trial_welcome',
      'onboarding_day2',
      'onboarding_day5',
      'contact_confirmation'
    ];

    return new Response(
      `
      <html>
        <head>
          <title>Unsubscribe - PipTrackr</title>
          <style>
            body { 
              font-family: Arial, sans-serif; 
              max-width: 600px; 
              margin: 50px auto; 
              padding: 20px; 
              background-color: #f8f9fa;
            }
            .container { 
              background: white; 
              padding: 30px; 
              border-radius: 8px; 
              box-shadow: 0 2px 10px rgba(0,0,0,0.1); 
            }
            .header { 
              text-align: center; 
              margin-bottom: 30px; 
              padding-bottom: 20px; 
              border-bottom: 1px solid #e9ecef; 
            }
            .form-group { 
              margin-bottom: 20px; 
            }
            label { 
              display: block; 
              margin-bottom: 5px; 
              font-weight: bold; 
              color: #333; 
            }
            input[type="email"], textarea { 
              width: 100%; 
              padding: 10px; 
              border: 1px solid #ddd; 
              border-radius: 4px; 
              font-size: 14px; 
            }
            .checkbox-group { 
              margin: 15px 0; 
            }
            .checkbox-group label { 
              display: flex; 
              align-items: center; 
              margin-bottom: 10px; 
              font-weight: normal; 
            }
            .checkbox-group input { 
              margin-right: 10px; 
              width: auto; 
            }
            button { 
              background: #dc3545; 
              color: white; 
              padding: 12px 24px; 
              border: none; 
              border-radius: 4px; 
              cursor: pointer; 
              font-size: 16px; 
              width: 100%; 
            }
            button:hover { 
              background: #c82333; 
            }
            .info { 
              background: #e3f2fd; 
              border: 1px solid #2196f3; 
              border-radius: 4px; 
              padding: 15px; 
              margin-bottom: 20px; 
            }
          </style>
        </head>
        <body>
          <div class="container">
            <div class="header">
              <h1>Unsubscribe from PipTrackr Emails</h1>
              <p>We're sorry to see you go. Please select which emails you'd like to unsubscribe from.</p>
            </div>
            
            <div class="info">
              <strong>Email Address:</strong> ${email}
            </div>

            <form method="POST">
              <input type="hidden" name="email" value="${email}" />
              
              <div class="form-group">
                <label>Confirm your email address:</label>
                <input type="email" name="email" value="${email}" required />
              </div>

              <div class="form-group">
                <label>Select email types to unsubscribe from:</label>
                <div class="checkbox-group">
                  ${availableTemplates.map(template => `
                    <label>
                      <input type="checkbox" name="templates" value="${template}" ${templateKey === template ? 'checked' : ''} />
                      ${template.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase())}
                    </label>
                  `).join('')}
                </div>
              </div>

              <div class="form-group">
                <label>Reason for unsubscribing (optional):</label>
                <textarea name="custom_reason" rows="3" placeholder="Help us improve by telling us why you're unsubscribing..."></textarea>
              </div>

              <button type="submit">Unsubscribe</button>
            </form>

            <div style="margin-top: 30px; text-align: center; font-size: 12px; color: #666;">
              <p>If you have any questions, please contact us at <a href="mailto:support@piptrackr.com">support@piptrackr.com</a></p>
            </div>
          </div>
        </body>
      </html>
      `,
      { 
        status: 200, 
        headers: { ...corsHeaders, 'Content-Type': 'text/html' } 
      }
    );

  } catch (error) {
    console.error('Unsubscribe error:', error);
    return new Response(
      `
      <html>
        <head><title>Error</title></head>
        <body style="font-family: Arial, sans-serif; max-width: 600px; margin: 50px auto; padding: 20px;">
          <h1>Something went wrong</h1>
          <p>We're sorry, but there was an error processing your request. Please try again later or contact support.</p>
          <p><a href="mailto:support@piptrackr.com">support@piptrackr.com</a></p>
        </body>
      </html>
      `,
      { 
        status: 500, 
        headers: { ...corsHeaders, 'Content-Type': 'text/html' } 
      }
    );
  }
};

serve(handler);