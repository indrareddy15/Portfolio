import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.45.0";
import sgMail from "npm:@sendgrid/mail@8.1.4";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

interface EmailPayload {
  templateKey: string;
  to: string;
  data: Record<string, any>;
  options?: {
    cc?: string[];
    bcc?: string[];
    subjectOverride?: string;
    locale?: string;
  };
}

// Initialize SendGrid
const sendGridApiKey = Deno.env.get("SENDGRID_API_KEY");
if (!sendGridApiKey) {
  console.error("SENDGRID_API_KEY is not configured");
} else {
  sgMail.setApiKey(sendGridApiKey);
}

class SendGridProvider {
  private fromName: string;
  private fromAddress: string;
  private replyTo: string;

  constructor(config: {
    fromName: string;
    fromAddress: string;
    replyTo: string;
  }) {
    this.fromName = config.fromName;
    this.fromAddress = config.fromAddress;
    this.replyTo = config.replyTo;
  }

  async sendRaw(
    to: string,
    subject: string,
    html: string,
    options?: {
      cc?: string[];
      bcc?: string[];
      categories?: string[];
      customArgs?: Record<string, string>;
    }
  ): Promise<{ messageId?: string; success: boolean; error?: string }> {
    try {
      const msg = {
        to,
        from: {
          name: this.fromName,
          email: this.fromAddress,
        },
        replyTo: this.replyTo,
        subject,
        html,
        ...(options?.cc && { cc: options.cc }),
        ...(options?.bcc && { bcc: options.bcc }),
        ...(options?.categories && { categories: options.categories }),
        ...(options?.customArgs && { customArgs: options.customArgs })
      };

      console.log(`Sending email via SendGrid Web API to ${to} with subject: ${subject}`);
      
      const [response] = await sgMail.send(msg);
      const messageId = response.headers?.['x-message-id'];
      
      console.log(`Email sent successfully via SendGrid. Message ID: ${messageId}`);

      return {
        success: true,
        messageId: messageId || undefined
      };
    } catch (error: any) {
      const reason = error?.response?.body || error?.message || 'Unknown error';
      console.error('SendGrid send error:', reason);
      return {
        success: false,
        error: `SendGrid error: ${reason}`
      };
    }
  }
}

// Simple template renderer for edge function
function renderTemplate(templateKey: string, data: Record<string, any>): { subject: string; html: string } {
  const brandColor = '#008ffd';
  const logoUrl = 'https://piptrackr.com/logo.png';
  
  const header = `
    <table width="100%" cellpadding="0" cellspacing="0" style="background-color: #f8f9fa; font-family: 'Segoe UI', Tahoma, 'Helvetica Neue', Arial, sans-serif;">
      <tr>
        <td align="center" style="padding: 40px 20px;">
          <table width="600" cellpadding="0" cellspacing="0" style="max-width: 600px; background-color: #ffffff; border-radius: 8px; overflow: hidden; box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);">
            <tr style="background: linear-gradient(135deg, ${brandColor} 0%, #0066cc 100%);">
              <td align="center" style="padding: 30px 20px;">
                <img src="${logoUrl}" alt="PipTrackr" style="height: 40px; margin-bottom: 20px;" />
                <h1 style="color: #ffffff; font-size: 28px; font-weight: 600; margin: 0; text-shadow: 0 2px 4px rgba(0,0,0,0.1);">
                  PipTrackr
                </h1>
              </td>
            </tr>
            <tr>
              <td style="padding: 40px 30px;">
  `;

  const footer = `
              </td>
            </tr>
            <tr style="background-color: #f8f9fa; border-top: 1px solid #e9ecef;">
              <td style="padding: 30px; text-align: center;">
                <p style="color: #6c757d; font-size: 14px; margin: 0 0 15px 0;">
                  This email was sent from PipTrackr, your trading journal platform.
                </p>
                <p style="color: #6c757d; font-size: 12px; margin: 0;">
                  If you have questions, reply to this email or contact us at support@piptrackr.com
                </p>
              </td>
            </tr>
          </table>
        </td>
      </tr>
    </table>
  `;

  const templates: Record<string, { subject: string; content: string }> = {
    team_invite: {
      subject: `You're invited to join ${data.teamName} on PipTrackr`,
      content: `
        <h2 style="color: #333; font-size: 24px; margin-bottom: 20px;">You're Invited!</h2>
        <p style="color: #555; font-size: 16px; line-height: 1.6; margin-bottom: 20px;">
          ${data.inviterName} has invited you to join <strong>${data.teamName}</strong> on PipTrackr.
        </p>
        <table cellpadding="0" cellspacing="0" style="margin: 30px 0;">
          <tr>
            <td>
              <a href="${data.inviteUrl}" style="display: inline-block; padding: 14px 28px; background: linear-gradient(135deg, ${brandColor} 0%, #0066cc 100%); color: #ffffff; text-decoration: none; border-radius: 6px; font-weight: 600; font-size: 16px;">
                Accept Invitation
              </a>
            </td>
          </tr>
        </table>
      `
    },
    affiliate_approved: {
      subject: 'Welcome to the PipTrackr Affiliate Program!',
      content: `
        <h2 style="color: #333; font-size: 24px; margin-bottom: 20px;">Welcome to Our Affiliate Program! 🎉</h2>
        <p>Congratulations! Your affiliate application has been approved.</p>
        <div style="background-color: #f8f9fa; padding: 20px; border-radius: 6px; margin: 20px 0;">
          <h3>Your Affiliate Details:</h3>
          <p><strong>Affiliate Code:</strong> ${data.affiliateCode}</p>
          <p><strong>Commission Rate:</strong> ${data.commissionRate}%</p>
          <p><strong>Your Referral Link:</strong></p>
          <code style="background-color: #fff; padding: 8px; border-radius: 4px; display: block; margin-top: 5px;">${data.referralLink}</code>
        </div>
        <table cellpadding="0" cellspacing="0" style="margin: 30px 0;">
          <tr>
            <td>
              <a href="${data.dashboardUrl}" style="display: inline-block; padding: 14px 28px; background: linear-gradient(135deg, ${brandColor} 0%, #0066cc 100%); color: #ffffff; text-decoration: none; border-radius: 6px; font-weight: 600; font-size: 16px;">
                Go to Affiliate Dashboard
              </a>
            </td>
          </tr>
        </table>
      `
    },
    trial_welcome: {
      subject: 'Welcome to PipTrackr - Let\'s get you started!',
      content: `
        <h2 style="color: #333; font-size: 24px; margin-bottom: 20px;">Welcome to PipTrackr! 🚀</h2>
        <p>Hi ${data.userName}, welcome to PipTrackr! We're excited to help you take your trading to the next level.</p>
        <table cellpadding="0" cellspacing="0" style="margin: 30px 0;">
          <tr>
            <td>
              <a href="${data.dashboardUrl}" style="display: inline-block; padding: 14px 28px; background: linear-gradient(135deg, ${brandColor} 0%, #0066cc 100%); color: #ffffff; text-decoration: none; border-radius: 6px; font-weight: 600; font-size: 16px;">
                Get Started Now
              </a>
            </td>
          </tr>
        </table>
      `
    }
  };

  const template = templates[templateKey] || {
    subject: 'Notification from PipTrackr',
    content: `<h2>Hello!</h2><p>This is a notification from PipTrackr.</p>`
  };

  return {
    subject: template.subject,
    html: header + template.content + footer
  };
}

const handler = async (req: Request): Promise<Response> => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { emailId } = await req.json();

    if (!emailId) {
      return new Response(
        JSON.stringify({ error: 'Email ID is required' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    const supabase = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
    );

    // Fetch email from queue
    const { data: emailLog, error: fetchError } = await supabase
      .from('email_logs')
      .select('*')
      .eq('id', emailId)
      .eq('status', 'queued')
      .single();

    if (fetchError || !emailLog) {
      console.error('Email not found or already processed:', fetchError);
      return new Response(
        JSON.stringify({ error: 'Email not found or already processed' }),
        { status: 404, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Mark as processing
    await supabase
      .from('email_logs')
      .update({ status: 'processing', attempts: emailLog.attempts + 1 })
      .eq('id', emailId);

    const payload = emailLog.payload as EmailPayload;

    // Initialize SendGrid provider
    const provider = new SendGridProvider({
      fromName: Deno.env.get('EMAIL_FROM_NAME') ?? 'PipTrackr',
      fromAddress: Deno.env.get('EMAIL_FROM_ADDRESS') ?? 'noreply@piptrackr.com',
      replyTo: Deno.env.get('EMAIL_REPLY_TO') ?? 'support@piptrackr.com'
    });

    // Render template
    const { subject, html } = renderTemplate(payload.templateKey, payload.data);

    // Send email with categories for tracking
    const result = await provider.sendRaw(
      payload.to,
      payload.options?.subjectOverride || subject,
      html,
      {
        ...payload.options,
        categories: [payload.templateKey],
        customArgs: {
          templateKey: payload.templateKey,
          emailId: emailId
        }
      }
    );

    if (result.success) {
      // Mark as sent
      await supabase
        .from('email_logs')
        .update({
          status: 'sent',
          subject: payload.options?.subjectOverride || subject,
          sg_message_id: result.messageId
        })
        .eq('id', emailId);

      console.log(`Email ${emailId} sent successfully`);
    } else {
      // Mark as failed
      await supabase
        .from('email_logs')
        .update({
          status: 'failed',
          last_error: result.error
        })
        .eq('id', emailId);

      console.error(`Email ${emailId} failed:`, result.error);
    }

    return new Response(
      JSON.stringify({ success: result.success, messageId: result.messageId }),
      { status: 200, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );

  } catch (error) {
    console.error('Process email error:', error);
    return new Response(
      JSON.stringify({ error: 'Internal server error' }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
};

serve(handler);