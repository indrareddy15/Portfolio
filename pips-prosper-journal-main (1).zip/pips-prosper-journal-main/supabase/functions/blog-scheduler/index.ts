import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.7.1'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    // Initialize Supabase client
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const supabase = createClient(supabaseUrl, supabaseKey);

    const now = new Date().toISOString();
    
    // Find scheduled posts that should be published
    const { data: scheduledPosts, error: fetchError } = await supabase
      .from('blog_posts')
      .select('id, title, slug, publish_at')
      .eq('status', 'scheduled')
      .lte('publish_at', now);

    if (fetchError) {
      console.error('Error fetching scheduled posts:', fetchError);
      throw fetchError;
    }

    console.log(`Found ${scheduledPosts?.length || 0} posts to publish`);

    if (!scheduledPosts || scheduledPosts.length === 0) {
      return new Response(
        JSON.stringify({ 
          success: true, 
          message: 'No posts to publish',
          published: 0 
        }),
        {
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        }
      );
    }

    // Update posts to published status
    const postIds = scheduledPosts.map(post => post.id);
    
    const { error: updateError } = await supabase
      .from('blog_posts')
      .update({ 
        status: 'published',
        publish_at: now // Update to actual publish time
      })
      .in('id', postIds);

    if (updateError) {
      console.error('Error publishing posts:', updateError);
      throw updateError;
    }

    // Log the published posts
    const publishedTitles = scheduledPosts.map(post => post.title);
    console.log('Published posts:', publishedTitles);

    // Optional: Trigger sitemap regeneration
    try {
      const sitemapResponse = await fetch(`${supabaseUrl}/functions/v1/blog-sitemap?type=blog`, {
        headers: {
          'Authorization': `Bearer ${supabaseKey}`,
        }
      });
      
      if (sitemapResponse.ok) {
        console.log('Sitemap regenerated successfully');
      } else {
        console.warn('Failed to regenerate sitemap');
      }
    } catch (sitemapError) {
      console.warn('Error regenerating sitemap:', sitemapError);
      // Don't fail the whole operation for sitemap issues
    }

    return new Response(
      JSON.stringify({ 
        success: true, 
        message: `Published ${scheduledPosts.length} posts`,
        published: scheduledPosts.length,
        posts: scheduledPosts.map(post => ({
          id: post.id,
          title: post.title,
          slug: post.slug
        }))
      }),
      {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      }
    );

  } catch (error) {
    console.error('Error in blog scheduler:', error);
    return new Response(
      JSON.stringify({ 
        success: false, 
        error: error.message 
      }),
      {
        status: 500,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      }
    );
  }
});