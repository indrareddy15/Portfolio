import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req: Request) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseKey = Deno.env.get('SUPABASE_ANON_KEY')!;
    const supabase = createClient(supabaseUrl, supabaseKey, {
      auth: {
        autoRefreshToken: false,
        persistSession: false
      }
    });

    // Get user from JWT
    const authHeader = req.headers.get('authorization');
    if (!authHeader) {
      throw new Error('No authorization header');
    }

    const token = authHeader.replace('Bearer ', '');
    const { data: { user }, error: userError } = await supabase.auth.getUser(token);
    
    if (userError || !user) {
      throw new Error('Unauthorized');
    }

    const { shareId } = await req.json();

    if (!shareId) {
      throw new Error('Share ID required');
    }

    // Generate new secure random token
    const newShareToken = crypto.randomUUID() + crypto.randomUUID().replace(/-/g, '');

    // Update the share link with new token
    const { data, error } = await supabase
      .from('share_links')
      .update({ 
        share_token: newShareToken,
        // Reset view count when regenerating
        view_count: 0,
        last_viewed_at: null
      })
      .eq('id', shareId)
      .eq('user_id', user.id)
      .select()
      .single();

    if (error) {
      console.error('Update error:', error);
      throw new Error('Failed to regenerate share link');
    }

    const shareUrl = `${req.headers.get('origin') || 'https://piptrakr.com'}/s/${newShareToken}`;

    return new Response(JSON.stringify({
      success: true,
      data: {
        id: data.id,
        token: newShareToken,
        url: shareUrl,
        expires_at: data.expires_at,
        created_at: data.created_at
      }
    }), {
      headers: { 'Content-Type': 'application/json', ...corsHeaders },
      status: 200
    });

  } catch (error) {
    console.error('Error regenerating share link:', error);
    return new Response(JSON.stringify({
      success: false,
      error: error.message
    }), {
      headers: { 'Content-Type': 'application/json', ...corsHeaders },
      status: 400
    });
  }
});