import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.7.1'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
  'Content-Type': 'application/xml',
}

serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const url = new URL(req.url);
    const type = url.searchParams.get('type') || 'main';
    const siteUrl = 'https://piptrackr.com';
    
    // Initialize Supabase client
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const supabase = createClient(supabaseUrl, supabaseKey);

    let sitemapXml = '';

    if (type === 'main') {
      // Main sitemap index
      sitemapXml = generateMainSitemap(siteUrl);
    } else if (type === 'blog') {
      // Blog posts sitemap
      const { data: posts, error } = await supabase
        .from('blog_posts')
        .select('slug, publish_at, updated_at')
        .eq('status', 'published')
        .lte('publish_at', new Date().toISOString())
        .order('publish_at', { ascending: false });

      if (error) throw error;

      const { data: categories } = await supabase
        .from('blog_categories')
        .select('slug, updated_at');

      const { data: tags } = await supabase
        .from('blog_tags')
        .select('slug, created_at');

      sitemapXml = generateBlogSitemap({
        siteUrl,
        posts: posts || [],
        categories: categories || [],
        tags: tags || []
      });
    }

    return new Response(sitemapXml, {
      headers: {
        ...corsHeaders,
        'Cache-Control': 'public, max-age=3600', // Cache for 1 hour
      },
    });

  } catch (error) {
    console.error('Error generating sitemap:', error);
    return new Response(
      `<?xml version="1.0" encoding="UTF-8"?>
      <error>Failed to generate sitemap</error>`,
      {
        status: 500,
        headers: corsHeaders,
      }
    );
  }
});

function generateMainSitemap(siteUrl: string): string {
  const lastmod = new Date().toISOString().split('T')[0]; // YYYY-MM-DD format

  return `<?xml version="1.0" encoding="UTF-8"?>
<sitemapindex xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
  <sitemap>
    <loc>${siteUrl}/sitemap-pages.xml</loc>
    <lastmod>${lastmod}</lastmod>
  </sitemap>
  <sitemap>
    <loc>${siteUrl}/api/blog-sitemap?type=blog</loc>
    <lastmod>${lastmod}</lastmod>
  </sitemap>
</sitemapindex>`;
}

function generateBlogSitemap(config: {
  siteUrl: string;
  posts: Array<{ slug: string; publish_at: string; updated_at: string }>;
  categories: Array<{ slug: string; updated_at: string }>;
  tags: Array<{ slug: string; created_at: string }>;
}): string {
  const { siteUrl, posts, categories, tags } = config;

  // Blog main page
  const blogMainUrl = `
  <url>
    <loc>${siteUrl}/blog</loc>
    <lastmod>${new Date().toISOString().split('T')[0]}</lastmod>
    <changefreq>daily</changefreq>
    <priority>0.8</priority>
  </url>`;

  // Blog posts
  const postUrls = posts.map(post => {
    const lastmod = new Date(post.updated_at).toISOString().split('T')[0];
    return `
  <url>
    <loc>${siteUrl}/blog/${post.slug}</loc>
    <lastmod>${lastmod}</lastmod>
    <changefreq>monthly</changefreq>
    <priority>0.6</priority>
  </url>`;
  }).join('');

  // Category pages
  const categoryUrls = categories.map(category => {
    const lastmod = new Date(category.updated_at).toISOString().split('T')[0];
    return `
  <url>
    <loc>${siteUrl}/blog/category/${category.slug}</loc>
    <lastmod>${lastmod}</lastmod>
    <changefreq>weekly</changefreq>
    <priority>0.5</priority>
  </url>`;
  }).join('');

  // Tag pages
  const tagUrls = tags.map(tag => {
    const lastmod = new Date(tag.created_at).toISOString().split('T')[0];
    return `
  <url>
    <loc>${siteUrl}/blog/tag/${tag.slug}</loc>
    <lastmod>${lastmod}</lastmod>
    <changefreq>weekly</changefreq>
    <priority>0.4</priority>
  </url>`;
  }).join('');

  return `<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
  ${blogMainUrl}
  ${postUrls}
  ${categoryUrls}
  ${tagUrls}
</urlset>`;
}