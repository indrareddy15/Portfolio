import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import { Resend } from "npm:resend@2.0.0";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.45.0";

const resend = new Resend(Deno.env.get("RESEND_API_KEY"));

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

interface OnboardingEmailRequest {
  email: string;
  name: string;
  emailType: 'welcome' | 'day2' | 'day5' | 'day10';
}

const getEmailContent = (type: string, name: string) => {
  const templates = {
    welcome: {
      subject: "Welcome to PipsJournal - Your Trading Journey Starts Now! 🚀",
      html: `
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; background: #f3f7ff; padding: 20px;">
          <div style="background: white; padding: 30px; border-radius: 12px; box-shadow: 0 4px 24px rgba(0,143,253,0.1);">
            <div style="text-align: center; margin-bottom: 30px;">
              <h1 style="color: #008ffd; font-size: 28px; margin-bottom: 10px;">Welcome to PipsJournal!</h1>
              <p style="color: #666; font-size: 16px;">The complete trading journal for forex, MT4, and prop firms</p>
            </div>
            
            <p style="color: #333; font-size: 16px; line-height: 1.6;">Hi ${name},</p>
            
            <p style="color: #333; font-size: 16px; line-height: 1.6;">
              Welcome to PipsJournal! We're thrilled to have you join thousands of traders who are transforming 
              their trading performance with data-driven insights.
            </p>
            
            <div style="background: #008ffd; color: white; padding: 20px; border-radius: 8px; margin: 25px 0;">
              <h3 style="margin-top: 0; font-size: 18px;">🎯 Get Started in 3 Steps:</h3>
              <ol style="margin: 15px 0; padding-left: 20px;">
                <li style="margin-bottom: 8px;">Add your first trade manually or import from MT4/MT5</li>
                <li style="margin-bottom: 8px;">Explore your analytics dashboard</li>
                <li style="margin-bottom: 8px;">Set up TradingView webhooks for automatic tracking</li>
              </ol>
            </div>
            
            <div style="text-align: center; margin: 30px 0;">
              <a href="https://pipsjournal.com/app/journal" 
                 style="background: #008ffd; color: white; padding: 15px 30px; text-decoration: none; 
                        border-radius: 8px; font-weight: bold; display: inline-block;">
                Add Your First Trade
              </a>
            </div>
            
            <p style="color: #666; font-size: 14px; line-height: 1.6;">
              Need help? Reply to this email or check our 
              <a href="https://pipsjournal.com/learn" style="color: #008ffd;">learning center</a> 
              for guides and tutorials.
            </p>
            
            <p style="color: #333; font-size: 16px; line-height: 1.6;">
              Happy trading!<br>
              The PipsJournal Team
            </p>
          </div>
        </div>
      `
    },
    
    day2: {
      subject: "Ready to import your trading history? 📈",
      html: `
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; background: #f3f7ff; padding: 20px;">
          <div style="background: white; padding: 30px; border-radius: 12px; box-shadow: 0 4px 24px rgba(0,143,253,0.1);">
            <h1 style="color: #008ffd; font-size: 24px; margin-bottom: 20px;">Import Your Trading History</h1>
            
            <p style="color: #333; font-size: 16px; line-height: 1.6;">Hi ${name},</p>
            
            <p style="color: #333; font-size: 16px; line-height: 1.6;">
              Ready to supercharge your trading analysis? Import your existing trades from MT4, MT5, 
              or any CSV file to get instant insights into your performance.
            </p>
            
            <div style="background: #e5efff; padding: 20px; border-radius: 8px; margin: 25px 0;">
              <h3 style="color: #008ffd; margin-top: 0;">✨ What you'll get:</h3>
              <ul style="color: #333; margin: 15px 0; padding-left: 20px;">
                <li>Automatic P&L calculations</li>
                <li>Win/loss ratio analysis</li>
                <li>Best and worst performing pairs</li>
                <li>Session performance breakdown</li>
              </ul>
            </div>
            
            <div style="text-align: center; margin: 30px 0;">
              <a href="https://pipsjournal.com/app/imports" 
                 style="background: #008ffd; color: white; padding: 15px 30px; text-decoration: none; 
                        border-radius: 8px; font-weight: bold; display: inline-block;">
                Import Trades Now
              </a>
            </div>
            
            <p style="color: #666; font-size: 14px; line-height: 1.6;">
              Need help with importing? Our 
              <a href="https://pipsjournal.com/learn" style="color: #008ffd;">step-by-step guides</a> 
              make it easy.
            </p>
          </div>
        </div>
      `
    },
    
    day5: {
      subject: "Discover your trading patterns with Analytics 📊",
      html: `
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; background: #f3f7ff; padding: 20px;">
          <div style="background: white; padding: 30px; border-radius: 12px; box-shadow: 0 4px 24px rgba(0,143,253,0.1);">
            <h1 style="color: #008ffd; font-size: 24px; margin-bottom: 20px;">Unlock Your Trading Analytics</h1>
            
            <p style="color: #333; font-size: 16px; line-height: 1.6;">Hi ${name},</p>
            
            <p style="color: #333; font-size: 16px; line-height: 1.6;">
              Now that you have some trades in your journal, it's time to discover the patterns 
              and insights that will take your trading to the next level.
            </p>
            
            <div style="background: #e5efff; padding: 20px; border-radius: 8px; margin: 25px 0;">
              <h3 style="color: #008ffd; margin-top: 0;">🔍 Explore Your Analytics:</h3>
              <ul style="color: #333; margin: 15px 0; padding-left: 20px;">
                <li>Session performance heatmaps</li>
                <li>Risk-reward ratio analysis</li>
                <li>Currency pair performance</li>
                <li>Monthly profit/loss trends</li>
                <li>Trading psychology insights</li>
              </ul>
            </div>
            
            <div style="text-align: center; margin: 30px 0;">
              <a href="https://pipsjournal.com/app/analytics" 
                 style="background: #008ffd; color: white; padding: 15px 30px; text-decoration: none; 
                        border-radius: 8px; font-weight: bold; display: inline-block;">
                View Analytics Dashboard
              </a>
            </div>
            
            <p style="color: #666; font-size: 14px; line-height: 1.6;">
              Pro tip: Use filters to analyze specific time periods or trading sessions!
            </p>
          </div>
        </div>
      `
    },
    
    day10: {
      subject: "Meet your AI Trading Coach 🤖",
      html: `
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; background: #f3f7ff; padding: 20px;">
          <div style="background: white; padding: 30px; border-radius: 12px; box-shadow: 0 4px 24px rgba(0,143,253,0.1);">
            <h1 style="color: #008ffd; font-size: 24px; margin-bottom: 20px;">Your AI Trading Coach is Ready!</h1>
            
            <p style="color: #333; font-size: 16px; line-height: 1.6;">Hi ${name},</p>
            
            <p style="color: #333; font-size: 16px; line-height: 1.6;">
              You've been journaling for over a week now – that's fantastic! Your AI Trading Coach 
              has been analyzing your performance and is ready to provide personalized insights.
            </p>
            
            <div style="background: linear-gradient(135deg, #008ffd, #0b1e3a); color: white; padding: 25px; border-radius: 8px; margin: 25px 0;">
              <h3 style="margin-top: 0; font-size: 18px;">🚀 AI Coach Features:</h3>
              <ul style="margin: 15px 0; padding-left: 20px;">
                <li>Personalized trading recommendations</li>
                <li>Risk management suggestions</li>
                <li>Pattern recognition insights</li>
                <li>Performance improvement plans</li>
                <li>Prop firm readiness scoring</li>
              </ul>
            </div>
            
            <div style="text-align: center; margin: 30px 0;">
              <a href="https://pipsjournal.com/app/ai" 
                 style="background: linear-gradient(135deg, #008ffd, #0b1e3a); color: white; padding: 15px 30px; 
                        text-decoration: none; border-radius: 8px; font-weight: bold; display: inline-block;">
                Meet Your AI Coach
              </a>
            </div>
            
            <div style="background: #fff3cd; border: 1px solid #ffeaa7; padding: 15px; border-radius: 8px; margin: 20px 0;">
              <p style="color: #856404; margin: 0; font-size: 14px;">
                💡 <strong>Pro Tip:</strong> The more you journal, the smarter your AI coach becomes!
              </p>
            </div>
            
            <p style="color: #333; font-size: 16px; line-height: 1.6;">
              Keep up the excellent work!<br>
              The PipsJournal Team
            </p>
          </div>
        </div>
      `
    }
  };

  return templates[type as keyof typeof templates] || templates.welcome;
};

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { email, name, emailType }: OnboardingEmailRequest = await req.json();

    if (!email || !name || !emailType) {
      return new Response(
        JSON.stringify({ error: "Missing required fields: email, name, emailType" }),
        {
          status: 400,
          headers: { "Content-Type": "application/json", ...corsHeaders },
        }
      );
    }

    const content = getEmailContent(emailType, name);

    const emailResponse = await resend.emails.send({
      from: "PipsJournal <onboarding@pipsjournal.com>",
      to: [email],
      subject: content.subject,
      html: content.html,
    });

    console.log(`Onboarding email sent successfully (${emailType}):`, emailResponse);

    // Log email in database for tracking
    const supabaseClient = createClient(
      Deno.env.get("SUPABASE_URL") ?? "",
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? "",
      { auth: { persistSession: false } }
    );

    await supabaseClient.from('email_logs').insert({
      recipient_email: email,
      email_type: emailType,
      status: 'sent',
      sent_at: new Date().toISOString(),
      email_id: emailResponse.data?.id,
    });

    return new Response(JSON.stringify({ 
      success: true, 
      emailId: emailResponse.data?.id,
      type: emailType 
    }), {
      status: 200,
      headers: {
        "Content-Type": "application/json",
        ...corsHeaders,
      },
    });

  } catch (error: any) {
    console.error("Error in send-onboarding-email function:", error);
    
    return new Response(
      JSON.stringify({ error: error.message }),
      {
        status: 500,
        headers: { "Content-Type": "application/json", ...corsHeaders },
      }
    );
  }
});