import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

interface CreateShareRequest {
  scope: 'account' | 'all_accounts';
  account_id?: string;
  include_trades: boolean;
  mask_currency: boolean;
  hide_brokers: boolean;
  hide_open: boolean;
  passcode?: string;
  expires_at?: string;
}

serve(async (req: Request) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseKey = Deno.env.get('SUPABASE_ANON_KEY')!;
    const supabase = createClient(supabaseUrl, supabaseKey, {
      auth: {
        autoRefreshToken: false,
        persistSession: false
      }
    });

    // Get user from JWT
    const authHeader = req.headers.get('authorization');
    if (!authHeader) {
      throw new Error('No authorization header');
    }

    const token = authHeader.replace('Bearer ', '');
    const { data: { user }, error: userError } = await supabase.auth.getUser(token);
    
    if (userError || !user) {
      throw new Error('Unauthorized');
    }

    const { 
      scope, 
      account_id, 
      include_trades = true,
      mask_currency = false,
      hide_brokers = false, 
      hide_open = false,
      passcode,
      expires_at
    }: CreateShareRequest = await req.json();

    // Generate secure random token (32+ characters)
    const shareToken = crypto.randomUUID() + crypto.randomUUID().replace(/-/g, '');
    
    // Hash passcode if provided
    let passwordHash = null;
    if (passcode) {
      const encoder = new TextEncoder();
      const data = encoder.encode(passcode);
      const hashBuffer = await crypto.subtle.digest('SHA-256', data);
      passwordHash = Array.from(new Uint8Array(hashBuffer))
        .map(b => b.toString(16).padStart(2, '0'))
        .join('');
    }

    // Create share link with existing table structure
    const { data: shareLink, error: insertError } = await supabase
      .from('share_links')
      .insert({
        user_id: user.id,
        link_type: scope,
        share_token: shareToken,
        password_hash: passwordHash,
        expires_at: expires_at ? new Date(expires_at).toISOString() : null,
        permissions: {
          account_id: account_id || null,
          include_trades,
          mask_currency,
          hide_brokers,
          hide_open
        },
        view_count: 0
      })
      .select()
      .single();

    if (insertError) {
      console.error('Insert error:', insertError);
      throw new Error('Failed to create share link');
    }

    const shareUrl = `${req.headers.get('origin') || 'https://piptrakr.com'}/s/${shareToken}`;

    return new Response(JSON.stringify({
      success: true,
      data: {
        id: shareLink.id,
        token: shareToken,
        url: shareUrl,
        expires_at: shareLink.expires_at,
        created_at: shareLink.created_at
      }
    }), {
      headers: { 'Content-Type': 'application/json', ...corsHeaders },
      status: 200
    });

  } catch (error) {
    console.error('Error creating share link:', error);
    return new Response(JSON.stringify({
      success: false,
      error: error.message
    }), {
      headers: { 'Content-Type': 'application/json', ...corsHeaders },
      status: 400
    });
  }
});