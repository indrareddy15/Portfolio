import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import Stripe from "https://esm.sh/stripe@14.21.0";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

const logStep = (step: string, details?: any) => {
  const detailsStr = details ? ` - ${JSON.stringify(details)}` : '';
  console.log(`[CREATE-STRIPE-PRODUCT] ${step}${detailsStr}`);
};

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    logStep("Function started");

    const stripeKey = Deno.env.get('STRIPE_SECRET_KEY');
    if (!stripeKey) {
      throw new Error('STRIPE_SECRET_KEY is not set');
    }

    const { name, description, price_amount, currency, billing_cycle } = await req.json();
    logStep("Request data received", { name, price_amount, currency, billing_cycle });

    if (!name || typeof price_amount !== 'number' || !currency || !billing_cycle) {
      throw new Error('Missing required fields: name, price_amount, currency, billing_cycle');
    }

    const stripe = new Stripe(stripeKey, { apiVersion: '2023-10-16' });

    // Create Stripe Product
    const product = await stripe.products.create({
      name: name,
      description: description || `${name} subscription plan`,
      metadata: {
        source: 'piptrackr_admin'
      }
    });
    logStep("Stripe product created", { productId: product.id });

    // Create Stripe Price
    const price = await stripe.prices.create({
      product: product.id,
      unit_amount: Math.round(price_amount * 100), // Convert to cents
      currency: currency.toLowerCase(),
      recurring: billing_cycle !== 'one_time' ? {
        interval: billing_cycle === 'yearly' ? 'year' : 'month'
      } : undefined,
      metadata: {
        source: 'piptrackr_admin'
      }
    });
    logStep("Stripe price created", { priceId: price.id, amount: price.unit_amount });

    const response = {
      product_id: product.id,
      price_id: price.id,
      product: product,
      price: price
    };

    logStep("Success", response);

    return new Response(JSON.stringify(response), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      status: 200,
    });

  } catch (error: any) {
    const errorMessage = error instanceof Error ? error.message : String(error);
    logStep("ERROR", { message: errorMessage, stack: error?.stack });
    
    return new Response(JSON.stringify({ error: errorMessage }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      status: 500,
    });
  }
});