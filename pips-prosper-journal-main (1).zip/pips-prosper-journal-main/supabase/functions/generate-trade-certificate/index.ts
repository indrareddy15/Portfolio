import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.39.3'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

Deno.serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabase = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_ANON_KEY') ?? '',
      {
        auth: {
          autoRefreshToken: false,
          persistSession: false
        }
      }
    );

    const { shareId } = await req.json();

    // Get share and trade data
    const { data: share, error: shareError } = await supabase
      .from('trade_shares')
      .select(`
        *,
        trades(*)
      `)
      .eq('id', shareId)
      .single();

    if (shareError || !share) {
      throw new Error('Share not found');
    }

    // Generate certificate (mock implementation)
    const certificateUrl = `https://piptrakr.com/certificates/${share.share_token}.png`;
    const socialImageUrl = `https://piptrakr.com/social/${share.share_token}.png`;

    // Update share with certificate info
    await supabase
      .from('trade_shares')
      .update({
        certificate_generated: true,
        certificate_url: certificateUrl,
        social_image_url: socialImageUrl
      })
      .eq('id', shareId);

    // Create certificate record
    await supabase
      .from('trade_certificates')
      .insert({
        trade_share_id: shareId,
        user_id: share.user_id,
        trade_id: share.trade_id,
        certificate_type: 'standard',
        performance_data: {
          pnl: share.trades.pnl,
          instrument: share.trades.instrument,
          side: share.trades.side
        },
        certificate_url: certificateUrl,
        social_image_url: socialImageUrl
      });

    return new Response(
      JSON.stringify({ 
        success: true, 
        certificateUrl,
        socialImageUrl
      }),
      { 
        headers: { 
          ...corsHeaders, 
          'Content-Type': 'application/json' 
        } 
      }
    );

  } catch (error) {
    console.error('Certificate generation error:', error);
    return new Response(
      JSON.stringify({ 
        error: error.message || 'Failed to generate certificate' 
      }),
      { 
        status: 400, 
        headers: { 
          ...corsHeaders, 
          'Content-Type': 'application/json' 
        } 
      }
    );
  }
});