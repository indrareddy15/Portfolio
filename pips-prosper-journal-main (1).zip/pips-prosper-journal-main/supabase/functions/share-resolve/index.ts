import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req: Request) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseServiceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const supabase = createClient(supabaseUrl, supabaseServiceKey);

    const url = new URL(req.url);
    const token = url.searchParams.get('token');
    const passcode = url.searchParams.get('passcode');

    if (!token) {
      throw new Error('Token required');
    }

    // Get share link
    const { data: shareLink, error: linkError } = await supabase
      .from('share_links')
      .select(`
        *,
        accounts (
          id, name, nickname, broker_name, currency, balance, equity,
          start_balance, created_at
        ),
        profiles (
          display_name
        )
      `)
      .eq('share_token', token)
      .single();

    if (linkError || !shareLink) {
      return new Response(JSON.stringify({
        success: false,
        error: 'Invalid or expired link'
      }), {
        headers: { 'Content-Type': 'application/json', ...corsHeaders },
        status: 404
      });
    }

    // Check if link is expired or revoked
    if (shareLink.expires_at && new Date(shareLink.expires_at) < new Date()) {
      return new Response(JSON.stringify({
        success: false,
        error: 'Link has expired'
      }), {
        headers: { 'Content-Type': 'application/json', ...corsHeaders },
        status: 410
      });
    }

    // Check passcode if required
    if (shareLink.password_hash && passcode) {
      const encoder = new TextEncoder();
      const data = encoder.encode(passcode);
      const hashBuffer = await crypto.subtle.digest('SHA-256', data);
      const providedHash = Array.from(new Uint8Array(hashBuffer))
        .map(b => b.toString(16).padStart(2, '0'))
        .join('');
      
      if (providedHash !== shareLink.password_hash) {
        return new Response(JSON.stringify({
          success: false,
          error: 'Invalid passcode'
        }), {
          headers: { 'Content-Type': 'application/json', ...corsHeaders },
          status: 401
        });
      }
    } else if (shareLink.password_hash && !passcode) {
      return new Response(JSON.stringify({
        success: false,
        error: 'Passcode required',
        requires_passcode: true
      }), {
        headers: { 'Content-Type': 'application/json', ...corsHeaders },
        status: 401
      });
    }

    // Log the view
    const clientIP = req.headers.get('cf-connecting-ip') || req.headers.get('x-forwarded-for') || 'unknown';
    const userAgent = req.headers.get('user-agent') || 'unknown';

    await supabase.from('shared_views_log').insert({
      share_link_id: shareLink.id,
      ip: clientIP,
      ua: userAgent
    });

    // Update view count
    await supabase
      .from('share_links')
      .update({ 
        view_count: (shareLink.view_count || 0) + 1,
        last_viewed_at: new Date().toISOString()
      })
      .eq('id', shareLink.id);

    // Fetch metrics based on scope
    let metricsData = null;
    let tradesData = null;
    const permissions = shareLink.permissions || {};

    if (shareLink.link_type === 'account' && permissions.account_id) {
      // Single account metrics
      const { data: trades } = await supabase
        .from('trades')
        .select('*')
        .eq('account_id', permissions.account_id)
        .eq('user_id', shareLink.user_id)
        .order('opened_at', { ascending: false });

      tradesData = trades || [];
    } else if (shareLink.link_type === 'all_accounts') {
      // All accounts metrics  
      const { data: trades } = await supabase
        .from('trades')
        .select(`
          *,
          accounts (name, nickname, broker_name)
        `)
        .eq('user_id', shareLink.user_id)
        .order('opened_at', { ascending: false });

      tradesData = trades || [];
    }

    // Calculate metrics
    const closedTrades = tradesData?.filter(t => t.closed_at) || [];
    const winningTrades = closedTrades.filter(t => t.pnl > 0);
    const losingTrades = closedTrades.filter(t => t.pnl < 0);
    
    metricsData = {
      totalTrades: closedTrades.length,
      winningTrades: winningTrades.length,
      losingTrades: losingTrades.length,
      winRate: closedTrades.length > 0 ? (winningTrades.length / closedTrades.length * 100) : 0,
      totalPnL: closedTrades.reduce((sum, t) => sum + (t.pnl || 0), 0),
      grossProfit: winningTrades.reduce((sum, t) => sum + (t.pnl || 0), 0),
      grossLoss: Math.abs(losingTrades.reduce((sum, t) => sum + (t.pnl || 0), 0)),
      profitFactor: 0,
      avgRR: 0,
      maxDrawdown: 0
    };

    if (metricsData.grossLoss > 0) {
      metricsData.profitFactor = metricsData.grossProfit / metricsData.grossLoss;
    }

    // Sanitize data based on permissions
    if (permissions.mask_currency) {
      metricsData.totalPnL = null;
      metricsData.grossProfit = null; 
      metricsData.grossLoss = null;
      
      if (tradesData) {
        tradesData.forEach(trade => {
          trade.pnl = null;
          trade.commission = null;
          trade.swap = null;
        });
      }

      if (shareLink.accounts) {
        shareLink.accounts.balance = null;
        shareLink.accounts.equity = null;
        shareLink.accounts.start_balance = null;
      }
    }

    if (permissions.hide_brokers) {
      if (shareLink.accounts) {
        shareLink.accounts.broker_name = 'Hidden';
      }
      if (tradesData) {
        tradesData.forEach(trade => {
          if (trade.accounts) {
            trade.accounts.broker_name = 'Hidden';
          }
        });
      }
    }

    if (permissions.hide_open) {
      tradesData = tradesData?.filter(t => t.closed_at) || [];
    }

    if (!permissions.include_trades) {
      tradesData = [];
    }

    return new Response(JSON.stringify({
      success: true,
      data: {
        shareLink: {
          id: shareLink.id,
          link_type: shareLink.link_type,
          permissions: shareLink.permissions,
          created_at: shareLink.created_at,
          expires_at: shareLink.expires_at
        },
        account: shareLink.accounts,
        user: {
          display_name: shareLink.profiles?.display_name || 'Anonymous Trader'
        },
        metrics: metricsData,
        trades: tradesData
      }
    }), {
      headers: { 'Content-Type': 'application/json', ...corsHeaders },
      status: 200
    });

  } catch (error) {
    console.error('Error resolving share link:', error);
    return new Response(JSON.stringify({
      success: false,
      error: error.message
    }), {
      headers: { 'Content-Type': 'application/json', ...corsHeaders },
      status: 500
    });
  }
});