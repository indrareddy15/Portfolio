import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.45.0";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

const handler = async (req: Request): Promise<Response> => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabase = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
    );

    console.log('Processing scheduled emails...');

    // Get emails that are scheduled and due to be sent
    const { data: scheduledEmails, error } = await supabase
      .from('email_logs')
      .select('*')
      .eq('status', 'scheduled')
      .lte('payload->scheduledFor', new Date().toISOString())
      .limit(50);

    if (error) {
      console.error('Failed to fetch scheduled emails:', error);
      return new Response(
        JSON.stringify({ error: 'Failed to fetch scheduled emails' }),
        { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    let processedCount = 0;
    let errorCount = 0;

    if (scheduledEmails && scheduledEmails.length > 0) {
      console.log(`Found ${scheduledEmails.length} scheduled emails to process`);

      for (const email of scheduledEmails) {
        try {
          // Update status to queued
          await supabase
            .from('email_logs')
            .update({ status: 'queued' })
            .eq('id', email.id);

          // Trigger email processing
          const response = await fetch(`${Deno.env.get('SUPABASE_URL')}/functions/v1/process-email`, {
            method: 'POST',
            headers: {
              'Authorization': `Bearer ${Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')}`,
              'Content-Type': 'application/json'
            },
            body: JSON.stringify({ emailId: email.id })
          });

          if (response.ok) {
            processedCount++;
            console.log(`Scheduled email ${email.id} queued for processing`);
          } else {
            throw new Error(`HTTP ${response.status}: ${await response.text()}`);
          }
        } catch (error) {
          errorCount++;
          console.error(`Failed to process scheduled email ${email.id}:`, error);
          
          // Mark as failed
          await supabase
            .from('email_logs')
            .update({ 
              status: 'failed',
              last_error: `Scheduling error: ${error instanceof Error ? error.message : 'Unknown error'}`
            })
            .eq('id', email.id);
        }
      }
    }

    // Also process failed email retries
    console.log('Processing email retries...');
    
    const oneHourAgo = new Date(Date.now() - 60 * 60 * 1000);
    
    const { data: failedEmails, error: retryError } = await supabase
      .from('email_logs')
      .select('*')
      .eq('status', 'failed')
      .lt('attempts', 3)
      .lt('updated_at', oneHourAgo.toISOString())
      .limit(20);

    let retriedCount = 0;

    if (!retryError && failedEmails && failedEmails.length > 0) {
      console.log(`Found ${failedEmails.length} failed emails to retry`);

      for (const email of failedEmails) {
        try {
          // Calculate delay based on attempt count (exponential backoff)
          const delay = Math.pow(2, email.attempts) * 60 * 1000; // 1min, 2min, 4min
          const shouldRetry = Date.now() - new Date(email.updated_at).getTime() > delay;

          if (!shouldRetry) {
            continue;
          }

          // Reset to queued for retry
          await supabase
            .from('email_logs')
            .update({ status: 'queued' })
            .eq('id', email.id);

          // Trigger processing
          const response = await fetch(`${Deno.env.get('SUPABASE_URL')}/functions/v1/process-email`, {
            method: 'POST',
            headers: {
              'Authorization': `Bearer ${Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')}`,
              'Content-Type': 'application/json'
            },
            body: JSON.stringify({ emailId: email.id })
          });

          if (response.ok) {
            retriedCount++;
            console.log(`Failed email ${email.id} queued for retry (attempt ${email.attempts + 1})`);
          }
        } catch (error) {
          console.error(`Failed to retry email ${email.id}:`, error);
        }
      }
    }

    const result = {
      success: true,
      scheduledProcessed: processedCount,
      scheduledErrors: errorCount,
      retriedEmails: retriedCount,
      timestamp: new Date().toISOString()
    };

    console.log('Email scheduler completed:', result);

    return new Response(
      JSON.stringify(result),
      { status: 200, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );

  } catch (error) {
    console.error('Email scheduler error:', error);
    return new Response(
      JSON.stringify({ 
        error: 'Internal server error',
        details: error instanceof Error ? error.message : 'Unknown error'
      }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
};

serve(handler);