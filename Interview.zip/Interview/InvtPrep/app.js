function debounce(func, delay) {
    let timer;
    return function (...args) {
        clearTimeout(timer)
        timer = setTimeout(() => {
            func.apply(this, args)
        }, delay)
    }
}


function searchApi(query) {
    console.log(query);
}

const debouncedSearch = debounce(searchApi, 3000)

// Simulate rapid user typing:
debouncedSearch("a");
debouncedSearch("ab");
debouncedSearch("abc");  // Only this call will trigger after 3000ms

const authMiddleware = (req, res, next) => {
    const authHeader = req.headers.authorization;

    if (!authHeader) {
        return res.status(401).json({ message: "" })
    }

    const token = authHeader.split(" ")[1]

    try {
        const secretKey = process.env.JWT_SECRET
        const decoded = jwt.verify(token, secretKey)
        req.user = decoded
        next()
    } catch (error) {
        return res.status(401).json({ message: "" })
    }
}

const validationMiddleware = (req, res, next) => {
    const error = validationResult(req)

    if (!error) {
        return res.status(400).json({ message: "" })
    }
    next()
}

// throttle
function throttle(func, delay) {
    let lastCall = 0;

    return function (...args) {
        const now = Date.now()

        if (now - lastCall >= delay) {
            lastCall = now
            func.apply(args, delay)
        }
    }
}

// pagination
function paginate(arr, pageNumber, pageSize) {
    const startIndex = (pageNumber - 1) * pageSize
    const endIndex = startIndex + pageSize
    return arr.slice(startIndex, endIndex)
}