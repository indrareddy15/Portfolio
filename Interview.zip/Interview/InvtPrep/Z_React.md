# React.js README

## 1. What is React

- ReactJS is an open-source JavaScript library developed by Facebook. It is used for building user interfaces and optimized web applications.
  It contains a set of optimized functions and is used for building single page applications in which the entire app is rendered in a single HTML file.

## 2. Why React

- Start with drawbacks: When dealing with JavaScript, it contains large boilerplate code and modular system designing of components becomes difficult.
  React addresses the major issue of reloading by using the Virtual DOM.

  - Ease of maintenance.
  - Performance improvements.
  - Scalability.
  - Reusability of code.

  React supports two types of architecture:

  1. Class-based.
  2. Functional-based (the most recent one).

  ### Note:

  - JQuery uses direct access of the DOM, which is expensive to handle.
  - Angular is a framework, which means it has a large ecosystem; everything comes under a single package including data manipulation.

## 3. Explain the concept of virtual DOM

- Virtual DOM is an object-like structure similar to the Actual DOM, but the Virtual DOM is lightweight, in-memory, and easy to manage.
- It will only contain necessary mapping elements and their CSS.
- When it comes to actual DOM manipulation, it is very expensive.
- For example Suppose we have many updates or deletions it becomes an expensive process and will degrade performance.
  The Virtual DOM is present and the data flow is always in a single direction.

- How Virtual DOM works? - The Virtual DOM works in five simple steps.

  - Initial Render -> Explain
  - State or Props Change
  - Reconciliation
  - Diffing Algorithm
  - Efficient DOM Updates

    For Example

    - Whenever the first state or prop changes, the Virtual DOM will have an exact copy of the actual DOM (V1).
    - Then, the next state or prop update occurs. Suppose if there are five clicks, all will be merged into one (V2). From here, React undergoes the process called RECONCILIATION.
    - Reconciliation is the process where the Diffing Algorithm takes place, updating the Actual DOM with the most efficient changes.
    - The Diffing Algorithm compares the Virtual DOMs, and based on the comparison, it updates the most efficient one.

## 4. What are Components in React

- In Vanilla JavaScript, creating reusable components is very difficult.
- Components are small snippets of code put together to make the app easier to manage.
- A component is one of the core building blocks of React.
- React supports two types of architecture:
- **Class-based**.
- **Functional-based** (the most recent one).

## 5. Explain the building blocks of React?

- Components: These are reusable blocks of code that return HTML.
- JSX: It stands for JavaScript and XML and allows you to write HTML in React.
- Props and State: props are like function parameters and State is similar to variables.
- Context: This allows data to be passed through components as props in a hierarchy.
- Virtual DOM: It is a lightweight copy of the actual DOM which makes DOM manipulation easier.

## 6. How do you create component in React

- As we know, there are two types of components in React:

  - **Class-based**: Class components are a little more complex than functional components. They require more boilerplate code. Data can be passed from one class component to another class component.

    - Class-based components mainly work with Life Cycle Methods.
    - Class-based components start with the keyword `class` and extend `React.Component`.
    - `React.Component` is the parent class from the React library.
    - There are methods associated with class-based components:

    - Constructor: The constructor method is only required when there is state in the class.
    - It is called when an instance of the component is created.
    - The `super` keyword is used for calling the constructor of the parent class.

    - Why use super?
    - for Inheritance, Accessing

    - Render: The render method is used to display UI by returning JSX.
    - JSX is a JavaScript code template which converts the HTML syntax to a React function call.
    - React function calls help to construct the Virtual DOM, which updates the actual DOM and displays it in the UI.

    - Example: This is how a React function call helps to create a virtual DOM
    - `JSX code: const element = <h1>Hello, world!</h1>`
    - After Babel transformation:
    - `const element = React.createElement('h1', null, 'Hello, world!')`

  - **Functional-based**:
    - You declare a functional component using a JavaScript function.
    - This function returns JSX. JSX stands for JavaScript XML.
    - It allows you to write HTML-like syntax within your JavaScript code.
    - JSX makes your components more readable and maintainable.

## 7. How do browsers read JSX

- Browsers are not capable of reading JSX directly and can only understand pure JavaScript.
- The Babel library is used to convert any React code into JavaScript that renders in the UI.
- Web browsers read JSX with the help of a transpiler. Transpilers are used to convert JSX into JavaScript.
- The transpiler is called Babel.

## 8. What are States and Props

- States are more like variables. States are passed within the component only and can be modified.
- Props are used to pass data from one component to another; mostly props are passed as function arguments.
- Props cannot be modified (immutable).
- In class-based components, both state and props are objects.
- State acts as a local variable to that particular component.
- For using state in a class-based component, we need to initialize the constructor method and use the super keyword because we are extending from React.Component.
- In functional components, state depends on how you define it. Props can be used with both state and functional components.

## 9. What is JSX?

- JSX stands for JavaScript XML. It is a template language similar to HTML. It allows us to directly write HTML in React (within JavaScript code).
- JSX is converted into React function calls using the Babel transpiler library, which converts any JSX code into JavaScript that renders in the UI.
- Once these functions are called, they help to build the Virtual DOM. Then rendering happens; during rendering, RECONCILIATION happens and the Diffing Algorithm takes place.

## 10. What are Life Cycle Methods in React

- Life cycle methods describe how the life cycle of the component evolves.
- Three phases of life cycle methods are Mounting Phase, Updating Phase, and Destroying Phase (Unmounting Phase).
- **Mounting Phase**: There are methods associated with the mounting phase:
  - constructor(): This method is called before the component is mounted. 
  - It is used for initializing state and binding the event handlers in order to avoid side effects in this method.
  - render(): This method is mandatory and is responsible for rendering the component's UI based on its current state and props because it returns the JSX.
  - componentDidMount(): This method gets executed when the component is loaded into the DOM.
  - It will get triggered after the first invocation of the render method. componentDidMount will only run once in its entire life cycle.
  - It is commonly used to perform tasks such as fetching data from an API or setting up subscriptions.
- **Updating Phase**:
  - componentDidUpdate(): This method is triggered whenever there are changes to the state or props.
  - React initiates a re-render, and before this re-render occurs, this method has access to the previous state (prevState) and previous props (prevProps).
  - Compare current props and state with prevState and prevProps; if it returns true, then the component will re-render, otherwise not.
- **Unmounting Phase**: `componentWillUnmount()`
  - This method is called immediately before a component is unmounted and destroyed. It is used to perform cleanup tasks such as removing event listeners or canceling subscriptions.
    {This will happen only with conditional rendering}

## 11. What are keys in React

- Keys are special string attributes. They have unique identifiers for the React element. Keys are mainly used for dynamic list rendering in the UI.
  For example, if you want to update or delete an item in a list, the key plays a major role.

## 12. Explain the creation of a List in react?

- Lists are very useful when it comes to developing the UI of any website. Lists are mainly used for displaying menus on a website, for example, the navbar menu.

## 13. What are hooks in React

- Hooks are used in functional Components
- A major problem in class-based components is sharing business logic across different components,
- Higher Order Components (HOC) passing one component to another component that returns a new component is not scalable.
- Hooks are the native React APIs (functions) which interact with different aspects of React. 
- Hooks are independent and can be shared.
- we can reuse our business logic by converting it into a hook and reusing it in the component.
- If we want to use a hook, we need a prefix like "useXXX" and some of the important hooks are "useState", "useEffect", etc.
- For example: if we want to create a custom hook like "**useWindowResizer**" that allows you to track and resize the window size and determine the screen size based on the width

##### 1. Basic Hooks:

- `useState()`
- `useEffect()`
- `useContext()`

##### 2. Additional Hooks:

- `useReducer()`
- `useMemo()`
- `useCallback()`
- `useRef()`
- `useLayoutEffect()`

## 14. How do you handle events in React

- Event handling works very differently in different browsers (Firefox, Safari). 
- The React team came up with a new system in React called Synthetic Events.
- Synthetic events in React have the same interface as actual DOM events.
- Synthetic Events are a new way of handling events in React.
- The event object is attached to the root element and this root element will capture the event with the help of event bubbling and then it will check what is happening in the React application.
- Key Features of Synthetic Events

  - Normalization:
    For instance, properties and methods of native events like `stopPropagation()` and `preventDefault()`
  - Event Pooling:
    `event.persist()` to retain the event object for asynchronous operations.
  - Event Types:
    React provides synthetic events for various types of interactions, including mouse events (onClick, onMouseEnter, etc.), keyboard events (onKeyPress, onKeyDown, etc.), and form events (onChange, onSubmit, etc.)

  #### List of common synthetic events are

- `onClick`
- `onChange`
- `onSubmit`
- `onKeyDown`, `onKeyUp`
- `onFocus`, `onBlur`
- `onMouseEnter`, `onMouseLeave`
- `onTouchStart`, `onTouchEnd`

## 15. What is useState in React and How it is used in React

- useState is one of the most useful hooks in React which comes from the React native API.
- It allows functional components to manage state before each render.
- useState is a function that returns an array of two items: the first one is the state variable and the second one is the updater function which updates that particular state.
- (If we want to use a default value, we use it directly, i.e. `useState("DefaultValue")`).
- If we want to update the state, there are two ways:
  - First way is by using a callback; it will accept the previous (sample) value.
  - When updating state with a callback function, you can access the previous state (also known as the current state) as an argument in the callback.
  - This method ensures that you're always working with the latest state, even if state updates are batched or asynchronous.
  - For example: `setCount(prevCount => prevCount + 1)` Using callback to update state
  - If it is an object, we need to take a copy of the object and then add the new property because all the other properties will be erased otherwise.
  - When updating state with an object, you should not directly modify the state variable. Instead, create a new object that represents the updated state.
  - This ensures that you're not mutating the original state, which could lead to unexpected behavior and bugs.
  - If the state is an object, you need to take a copy of the object and then update the specific property you want to change. This is because updating a single property directly will erase all other properties.
  - For example: setUser(prevUser => ({ ...prevUser, name: 'Jane' }));

## 16. Explain useEffect in React and How does it work

- useEffect is one of the most useful hooks in React which comes from the React native API.
- useEffect will perform side effects of the application; it is similar to life cycle methods in class-based components.
- useEffect will accept two parameters: one is a callback function and the other is a dependency array ==> `useEffect(() => {callback}, [dependency array])`
- useEffect executes asynchronous functions like API calls, function calls, and network calls.
- useEffect accepts the callback and gets executed when the useEffect runs.
- useEffect will run after the first return of the JSX. It will at least run once in a functional component.
- If the dependency array is not there, useEffect will run continuously whenever any state or prop changes. `infineLoop`
- `The dependency array will tell when to execute after executing at least once`.
- After the first return, it will get executed; post that, based on what is there in the dependency array (["State" or "Prop"]) that will get executed.
- If the dependency array ([]) is empty, state or prop is trapped because when state or prop goes into the array, there will be no items in the array, then useEffect will run only once.
- If the dependency array (["State" or "Prop"]) has a value, then it will check if state or prop is updated; then useEffect will get triggered again.
- Now useEffect can also have a return function which is called a cleanup function. This is used when the component gets removed; then the return statement will get executed. This is to avoid memory leaks.
