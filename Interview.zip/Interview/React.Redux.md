# React Redux & Redux Toolkit - Complete Interview Guide

## Table of Contents

1. [Introduction](#introduction)
2. [Core Redux Concepts](#core-redux-concepts)
3. [React Redux](#react-redux)
4. [Redux Toolkit (RTK)](#redux-toolkit-rtk)
5. [Common Interview Questions](#common-interview-questions)
6. [Advanced Interview Questions](#advanced-interview-questions)
7. [Redux vs Context API](#redux-vs-context-api)
8. [Performance & Best Practices](#performance--best-practices)
9. [Version Comparison Table](#version-comparison-table)

---

## Introduction

**Redux** is a predictable state container for JavaScript applications, most commonly used with React.It helps you manage and centralize your application’s state in a single source of truth
**React Redux** is the official React bindings for Redux, while **Redux Toolkit (RTK)** is the official, opinionated, batteries-included toolset for efficient Redux development.

### Key Benefits

- **Predictable state updates**: Unidirectional data flow
- **Centralized state management**: Single source of truth
- **Debugging capabilities**: Time-travel debugging with DevTools
- **Ecosystem**: Rich middleware and tooling ecosystem
- **Scalability**: Works well for large applications

---

## Core Redux Concepts

### 1. The Three Principles

1. **Single source of truth**: The global state is stored in a single store
2. **State is read-only**: Only actions can change the state
3. **Changes are made with pure functions**: Reducers are pure functions

### 2. Core Building Blocks

- **Store**: Holds the application state and business logic.
- **Actions**: Plain JavaScript objects or functions that describe what happened
- **Reducers**: Pure functions that specify how state changes
- **Dispatch**: Method to trigger actions
- **Selectors**: Functions to extract specific data from state

---

## React Redux

### Installation

```bash
npm install redux react-redux
```

### Basic Setup

```jsx
// store.js
import { createStore } from "redux";
import { Provider } from "react-redux";
import rootReducer from "./reducers";

const store = createStore(rootReducer);

// App.js
import { Provider } from "react-redux";
import store from "./store";

function App() {
  return (
    <Provider store={store}>
      <MyComponent />
    </Provider>
  );
}
```

### Core Hooks

- `useSelector`: Extract data from Redux store
- `useDispatch`: Get dispatch function
- `useStore`: Access the store directly (rarely used)

---

## Redux Toolkit (RTK)

### Installation

```bash
npm install @reduxjs/toolkit react-redux
```

### Key Features

- **configureStore**: Simplified store setup
- **createSlice**: Combines actions and reducers
- **createAsyncThunk**: Handles async logic
- **RTK Query**: Data fetching and caching solution
- **Immer integration**: Immutable updates with mutable syntax

### Basic Setup

```jsx
// store.js
import { configureStore } from "@reduxjs/toolkit";
import counterSlice from "./counterSlice";

export const store = configureStore({
  reducer: {
    counter: counterSlice,
  },
});

// counterSlice.js
import { createSlice } from "@reduxjs/toolkit";

const counterSlice = createSlice({
  name: "counter",
  initialState: { value: 0 },
  reducers: {
    increment: (state) => {
      state.value += 1;
    },
    decrement: (state) => {
      state.value -= 1;
    },
  },
});

export const { increment, decrement } = counterSlice.actions;
export default counterSlice.reducer;
```

---

## Common Interview Questions

### 1. What is Redux and why would you use it?

**Answer**: Redux is a predictable state container for JavaScript applications. It helps manage application state in a predictable way using a unidirectional data flow pattern.

**Why use Redux:**

- **Centralized state management**: Single source of truth for application state
- **Predictable state updates**: State can only be changed by dispatching actions
- **Debugging**: Time-travel debugging with Redux DevTools
- **Testing**: Easy to test pure functions (reducers)
- **Scalability**: Works well for large, complex applications

```jsx
// Without Redux - prop drilling
function App() {
  const [user, setUser] = useState(null);
  return <ParentComponent user={user} setUser={setUser} />;
}

function ParentComponent({ user, setUser }) {
  return <ChildComponent user={user} setUser={setUser} />;
}

function ChildComponent({ user, setUser }) {
  return <GrandChildComponent user={user} setUser={setUser} />;
}

// With Redux - direct access
function GrandChildComponent() {
  const user = useSelector((state) => state.user);
  const dispatch = useDispatch();

  return <div>{user.name}</div>;
}
```

### 2. Explain the Redux data flow (unidirectional data flow)

**Answer**: Redux follows a strict unidirectional data flow:

1. **Action**: An event is triggered (user click, API response, etc.)
2. **Dispatch**: Action is dispatched to the store
3. **Reducer**: Store runs the reducer function with current state and action
4. **State Update**: Reducer returns new state
5. **UI Update**: Components subscribed to state re-render

```jsx
// 1. Action
const incrementAction = { type: "INCREMENT" };

// 2. Dispatch
dispatch(incrementAction);

// 3. Reducer
function counterReducer(state = { count: 0 }, action) {
  switch (action.type) {
    case "INCREMENT":
      return { count: state.count + 1 }; // 4. New state
    default:
      return state;
  }
}

// 5. Component re-renders
function Counter() {
  const count = useSelector((state) => state.count); // Subscribes to state
  return <div>{count}</div>;
}
```

### 3. What are actions and action creators?

**Answer**:

- **Actions**: Plain JavaScript objects that describe what happened. Must have a `type` property.
- **Action Creators**: Functions that return action objects.

```jsx
// Action (plain object)
const incrementAction = {
  type: "INCREMENT",
  payload: 1,
};

// Action Creator (function)
function increment(amount = 1) {
  return {
    type: "INCREMENT",
    payload: amount,
  };
}

// Usage
dispatch(increment(5));

// With Redux Toolkit
const counterSlice = createSlice({
  name: "counter",
  initialState: { value: 0 },
  reducers: {
    increment: (state, action) => {
      state.value += action.payload || 1;
    },
  },
});

// RTK automatically creates action creators
export const { increment } = counterSlice.actions;
dispatch(increment(5)); // { type: 'counter/increment', payload: 5 }
```

### 4. What are reducers and what rules must they follow?

**Answer**: Reducers are pure functions that take the current state and an action, and return a new state.

**Rules for reducers:**

1. **Pure functions**: Same input always produces same output
2. **No side effects**: No API calls, routing, or other side effects
3. **Immutable updates**: Never mutate the original state
4. **Return new state**: Always return a new state object

```jsx
// ❌ Bad reducer (mutates state)
function badReducer(state, action) {
  switch (action.type) {
    case "ADD_TODO":
      state.todos.push(action.payload); // Mutation!
      return state;
    default:
      return state;
  }
}

// ✅ Good reducer (immutable updates)
function goodReducer(state = initialState, action) {
  switch (action.type) {
    case "ADD_TODO":
      return {
        ...state,
        todos: [...state.todos, action.payload], // New array
      };
    case "TOGGLE_TODO":
      return {
        ...state,
        todos: state.todos.map((todo) =>
          todo.id === action.payload.id
            ? { ...todo, completed: !todo.completed }
            : todo
        ),
      };
    default:
      return state;
  }
}

// With Redux Toolkit (Immer allows "mutations")
const todosSlice = createSlice({
  name: "todos",
  initialState: { todos: [] },
  reducers: {
    addTodo: (state, action) => {
      state.todos.push(action.payload); // Looks like mutation, but Immer handles it
    },
    toggleTodo: (state, action) => {
      const todo = state.todos.find((todo) => todo.id === action.payload.id);
      if (todo) {
        todo.completed = !todo.completed;
      }
    },
  },
});
```

### 5. What is the difference between useSelector and connect?

**Answer**: Both are used to connect React components to Redux store, but they represent different paradigms:

| Aspect          | useSelector                | connect                      |
| --------------- | -------------------------- | ---------------------------- |
| **Paradigm**    | Hooks-based                | HOC-based                    |
| **Syntax**      | Simple and direct          | More verbose                 |
| **Performance** | Manual optimization needed | Automatic shallow comparison |
| **TypeScript**  | Easier to type             | More complex typing          |
| **Debugging**   | Easier to debug            | Harder to debug              |

```jsx
// useSelector approach (modern)
import { useSelector, useDispatch } from "react-redux";

function TodoList() {
  const todos = useSelector((state) => state.todos);
  const dispatch = useDispatch();

  return (
    <div>
      {todos.map((todo) => (
        <div key={todo.id}>{todo.text}</div>
      ))}
    </div>
  );
}

// connect approach (legacy)
import { connect } from "react-redux";

function TodoList({ todos, addTodo }) {
  return (
    <div>
      {todos.map((todo) => (
        <div key={todo.id}>{todo.text}</div>
      ))}
    </div>
  );
}

const mapStateToProps = (state) => ({
  todos: state.todos,
});

const mapDispatchToProps = {
  addTodo,
};

export default connect(mapStateToProps, mapDispatchToProps)(TodoList);
```

### 6. How do you handle asynchronous operations in Redux?

**Answer**: Redux doesn't handle async operations by default. You need middleware:

**Options:**

1. **Redux Thunk**: Allows action creators to return functions
2. **Redux Saga**: Uses generator functions for complex async flows
3. **Redux Toolkit's createAsyncThunk**: Built-in async handling
4. **RTK Query**: Data fetching and caching solution

```jsx
// 1. Redux Thunk
const fetchUser = (userId) => {
  return async (dispatch, getState) => {
    dispatch({ type: "FETCH_USER_START" });
    try {
      const response = await api.getUser(userId);
      dispatch({ type: "FETCH_USER_SUCCESS", payload: response.data });
    } catch (error) {
      dispatch({ type: "FETCH_USER_ERROR", payload: error.message });
    }
  };
};

// Usage
dispatch(fetchUser(123));

// 2. Redux Toolkit createAsyncThunk
const fetchUser = createAsyncThunk(
  "users/fetchUser",
  async (userId, { rejectWithValue }) => {
    try {
      const response = await api.getUser(userId);
      return response.data;
    } catch (error) {
      return rejectWithValue(error.message);
    }
  }
);

// In slice
const userSlice = createSlice({
  name: "user",
  initialState: {
    data: null,
    loading: false,
    error: null,
  },
  extraReducers: (builder) => {
    builder
      .addCase(fetchUser.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(fetchUser.fulfilled, (state, action) => {
        state.loading = false;
        state.data = action.payload;
      })
      .addCase(fetchUser.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload;
      });
  },
});

// 3. RTK Query
const api = createApi({
  reducerPath: "api",
  baseQuery: fetchBaseQuery({ baseUrl: "/api" }),
  endpoints: (builder) => ({
    getUser: builder.query({
      query: (userId) => `users/${userId}`,
    }),
  }),
});

const { useGetUserQuery } = api;

// In component
function UserProfile({ userId }) {
  const { data: user, error, isLoading } = useGetUserQuery(userId);

  if (isLoading) return <div>Loading...</div>;
  if (error) return <div>Error: {error.message}</div>;
  return <div>{user.name}</div>;
}
```

### 7. What is Redux middleware and can you name some popular ones?

**Answer**: Middleware provides a third-party extension point between dispatching an action and the moment it reaches the reducer. It's used for logging, crash reporting, async operations, etc.

**Popular middleware:**

- **redux-thunk**: Async actions
- **redux-saga**: Complex async flows with generators
- **redux-logger**: Logging actions and state changes
- **redux-persist**: Persist state to localStorage
- **redux-devtools-extension**: Browser debugging tools

```jsx
// Middleware signature
const middleware = (store) => (next) => (action) => {
  // Logic before action reaches reducer
  console.log("Dispatching:", action);

  const result = next(action); // Pass action to next middleware/reducer

  // Logic after action has been processed
  console.log("New state:", store.getState());

  return result;
};

// Custom logging middleware
const logger = (store) => (next) => (action) => {
  console.group(action.type);
  console.info("dispatching", action);
  let result = next(action);
  console.log("next state", store.getState());
  console.groupEnd();
  return result;
};

// Apply middleware
import { createStore, applyMiddleware } from "redux";
import thunk from "redux-thunk";

const store = createStore(rootReducer, applyMiddleware(thunk, logger));

// With Redux Toolkit (middleware included by default)
const store = configureStore({
  reducer: rootReducer,
  middleware: (getDefaultMiddleware) => getDefaultMiddleware().concat(logger),
});
```

### 8. What are selectors and why are they important?

**Answer**: Selectors are functions that extract specific pieces of data from the Redux store state. They encapsulate the knowledge of the state structure and can compute derived data.

**Benefits:**

- **Encapsulation**: Hide state structure from components
- **Reusability**: Use same selector in multiple components
- **Performance**: Memoization with reselect
- **Derived data**: Compute values based on state
- **Testing**: Easy to test in isolation

```jsx
// Basic selectors
const selectTodos = (state) => state.todos;
const selectUser = (state) => state.user;
const selectTodoById = (state, todoId) =>
  state.todos.find((todo) => todo.id === todoId);

// Derived data selectors
const selectCompletedTodos = (state) =>
  state.todos.filter((todo) => todo.completed);

const selectActiveTodos = (state) =>
  state.todos.filter((todo) => !todo.completed);

const selectTodoCount = (state) => state.todos.length;

// Memoized selectors with reselect
import { createSelector } from "reselect";

const selectTodos = (state) => state.todos;
const selectFilter = (state) => state.filter;

const selectVisibleTodos = createSelector(
  [selectTodos, selectFilter],
  (todos, filter) => {
    switch (filter) {
      case "COMPLETED":
        return todos.filter((todo) => todo.completed);
      case "ACTIVE":
        return todos.filter((todo) => !todo.completed);
      default:
        return todos;
    }
  }
);

// Usage in component
function TodoList() {
  const visibleTodos = useSelector(selectVisibleTodos);
  const completedCount = useSelector(selectCompletedTodos).length;

  return (
    <div>
      <p>Completed: {completedCount}</p>
      {visibleTodos.map((todo) => (
        <TodoItem key={todo.id} todo={todo} />
      ))}
    </div>
  );
}

// RTK Query selectors
const api = createApi({
  // ... api definition
});

// Auto-generated selectors
const { selectById: selectUserById, selectAll: selectAllUsers } =
  api.endpoints.getUsers.select();
```

### 9. How do you structure a Redux application?

**Answer**: There are several common patterns for structuring Redux applications:

**1. Feature-based structure (Recommended):**

```
src/
  features/
    todos/
      todosSlice.js
      TodoList.js
      TodoItem.js
      index.js
    users/
      userSlice.js
      UserProfile.js
      index.js
  app/
    store.js
    rootReducer.js
  shared/
    components/
    utils/
```

**2. File-type structure (Legacy):**

```
src/
  actions/
    todoActions.js
    userActions.js
  reducers/
    todoReducer.js
    userReducer.js
    index.js
  components/
    TodoList.js
    UserProfile.js
  store.js
```

**Redux Toolkit approach:**

```jsx
// features/todos/todosSlice.js
import { createSlice, createAsyncThunk } from "@reduxjs/toolkit";

export const fetchTodos = createAsyncThunk("todos/fetchTodos", async () => {
  const response = await api.getTodos();
  return response.data;
});

const todosSlice = createSlice({
  name: "todos",
  initialState: {
    items: [],
    loading: false,
    error: null,
  },
  reducers: {
    addTodo: (state, action) => {
      state.items.push(action.payload);
    },
    toggleTodo: (state, action) => {
      const todo = state.items.find((todo) => todo.id === action.payload);
      if (todo) {
        todo.completed = !todo.completed;
      }
    },
  },
  extraReducers: (builder) => {
    builder
      .addCase(fetchTodos.pending, (state) => {
        state.loading = true;
      })
      .addCase(fetchTodos.fulfilled, (state, action) => {
        state.loading = false;
        state.items = action.payload;
      })
      .addCase(fetchTodos.rejected, (state, action) => {
        state.loading = false;
        state.error = action.error.message;
      });
  },
});

export const { addTodo, toggleTodo } = todosSlice.actions;
export default todosSlice.reducer;

// Selectors
export const selectTodos = (state) => state.todos.items;
export const selectTodosLoading = (state) => state.todos.loading;
export const selectTodosError = (state) => state.todos.error;

// app/store.js
import { configureStore } from "@reduxjs/toolkit";
import todosReducer from "../features/todos/todosSlice";
import usersReducer from "../features/users/usersSlice";

export const store = configureStore({
  reducer: {
    todos: todosReducer,
    users: usersReducer,
  },
});
```

### 10. What is the difference between Redux and Context API?

**Answer**: Both solve state management problems but have different use cases:

| Aspect             | Redux                     | Context API                      |
| ------------------ | ------------------------- | -------------------------------- |
| **Purpose**        | Global state management   | Share data between components    |
| **Complexity**     | More complex setup        | Simpler setup                    |
| **Performance**    | Optimized with selectors  | Can cause unnecessary re-renders |
| **DevTools**       | Excellent debugging tools | Limited debugging                |
| **Middleware**     | Rich ecosystem            | No built-in middleware           |
| **Learning Curve** | Steeper                   | Gentler                          |
| **Bundle Size**    | Larger                    | Part of React                    |

```jsx
// Context API approach
const UserContext = createContext();

function UserProvider({ children }) {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(false);

  const login = async (credentials) => {
    setLoading(true);
    try {
      const userData = await api.login(credentials);
      setUser(userData);
    } finally {
      setLoading(false);
    }
  };

  return (
    <UserContext.Provider value={{ user, loading, login }}>
      {children}
    </UserContext.Provider>
  );
}

function useUser() {
  const context = useContext(UserContext);
  if (!context) {
    throw new Error("useUser must be used within UserProvider");
  }
  return context;
}

// Redux approach
const userSlice = createSlice({
  name: "user",
  initialState: { data: null, loading: false },
  reducers: {},
  extraReducers: (builder) => {
    builder
      .addCase(loginUser.pending, (state) => {
        state.loading = true;
      })
      .addCase(loginUser.fulfilled, (state, action) => {
        state.loading = false;
        state.data = action.payload;
      });
  },
});

function LoginForm() {
  const dispatch = useDispatch();
  const { user, loading } = useSelector((state) => state.user);

  const handleLogin = (credentials) => {
    dispatch(loginUser(credentials));
  };
}
```

**When to use each:**

- **Redux**: Large applications, complex state logic, need debugging tools
- **Context API**: Small to medium applications, simple state sharing, component-specific state

---

## Advanced Interview Questions

### 11. How do you handle optimistic updates in Redux?

**Answer**: Optimistic updates immediately update the UI assuming the operation will succeed, then handle failures if they occur.

```jsx
// Optimistic update pattern
const todosSlice = createSlice({
  name: "todos",
  initialState: { items: [] },
  reducers: {
    addTodoOptimistic: (state, action) => {
      // Immediately add todo with temporary ID
      state.items.push({
        ...action.payload,
        id: `temp_${Date.now()}`,
        pending: true,
      });
    },
    confirmTodoAdded: (state, action) => {
      // Replace temporary todo with server response
      const { tempId, serverTodo } = action.payload;
      const index = state.items.findIndex((todo) => todo.id === tempId);
      if (index !== -1) {
        state.items[index] = { ...serverTodo, pending: false };
      }
    },
    revertTodoAdd: (state, action) => {
      // Remove failed todo
      state.items = state.items.filter((todo) => todo.id !== action.payload);
    },
  },
});

// Async thunk with optimistic update
const addTodoOptimistic = createAsyncThunk(
  "todos/addTodoOptimistic",
  async (todoData, { dispatch, rejectWithValue }) => {
    const tempId = `temp_${Date.now()}`;

    // 1. Optimistic update
    dispatch(
      todosSlice.actions.addTodoOptimistic({
        ...todoData,
        id: tempId,
      })
    );

    try {
      // 2. Make API call
      const response = await api.addTodo(todoData);

      // 3. Confirm success
      dispatch(
        todosSlice.actions.confirmTodoAdded({
          tempId,
          serverTodo: response.data,
        })
      );

      return response.data;
    } catch (error) {
      // 4. Revert on failure
      dispatch(todosSlice.actions.revertTodoAdd(tempId));
      return rejectWithValue(error.message);
    }
  }
);
```

### 12. How do you implement undo/redo functionality in Redux?

**Answer**: Implement undo/redo by maintaining a history of states:

```jsx
// Undo/Redo higher-order reducer
function undoable(reducer) {
  const initialState = {
    past: [],
    present: reducer(undefined, {}),
    future: [],
  };

  return function (state = initialState, action) {
    const { past, present, future } = state;

    switch (action.type) {
      case "UNDO":
        if (past.length === 0) return state;
        return {
          past: past.slice(0, past.length - 1),
          present: past[past.length - 1],
          future: [present, ...future],
        };

      case "REDO":
        if (future.length === 0) return state;
        return {
          past: [...past, present],
          present: future[0],
          future: future.slice(1),
        };

      case "CLEAR_HISTORY":
        return {
          past: [],
          present,
          future: [],
        };

      default:
        const newPresent = reducer(present, action);
        if (present === newPresent) return state;

        return {
          past: [...past, present],
          present: newPresent,
          future: [],
        };
    }
  };
}

// Usage
const todosReducer = undoable(todosSlice.reducer);

// Component
function UndoRedoButtons() {
  const { past, future } = useSelector((state) => state.todos);
  const dispatch = useDispatch();

  return (
    <div>
      <button
        onClick={() => dispatch({ type: "UNDO" })}
        disabled={past.length === 0}
      >
        Undo
      </button>
      <button
        onClick={() => dispatch({ type: "REDO" })}
        disabled={future.length === 0}
      >
        Redo
      </button>
    </div>
  );
}
```

### 13. How do you handle entity normalization in Redux?

**Answer**: Normalize nested data to avoid duplication and make updates easier:

```jsx
// Normalized state structure
const initialState = {
  users: {
    byId: {},
    allIds: [],
  },
  posts: {
    byId: {},
    allIds: [],
  },
  comments: {
    byId: {},
    allIds: [],
  },
};

// Using RTK's createEntityAdapter
import { createEntityAdapter, createSlice } from "@reduxjs/toolkit";

const usersAdapter = createEntityAdapter();
const postsAdapter = createEntityAdapter();

const usersSlice = createSlice({
  name: "users",
  initialState: usersAdapter.getInitialState(),
  reducers: {
    userAdded: usersAdapter.addOne,
    userUpdated: usersAdapter.updateOne,
    userRemoved: usersAdapter.removeOne,
  },
  extraReducers: (builder) => {
    builder.addCase(fetchUsers.fulfilled, (state, action) => {
      usersAdapter.setAll(state, action.payload);
    });
  },
});

// Selectors
export const {
  selectById: selectUserById,
  selectIds: selectUserIds,
  selectEntities: selectUserEntities,
  selectAll: selectAllUsers,
  selectTotal: selectTotalUsers,
} = usersAdapter.getSelectors((state) => state.users);

// Denormalized selectors
export const selectPostWithAuthor = createSelector(
  [selectPostById, selectUserEntities],
  (post, userEntities) => ({
    ...post,
    author: userEntities[post.authorId],
  })
);

// Usage in component
function PostList() {
  const posts = useSelector(selectAllPosts);
  const userEntities = useSelector(selectUserEntities);

  return (
    <div>
      {posts.map((post) => (
        <div key={post.id}>
          <h3>{post.title}</h3>
          <p>By: {userEntities[post.authorId]?.name}</p>
        </div>
      ))}
    </div>
  );
}
```

### 14. How do you implement real-time updates with Redux?

**Answer**: Integrate WebSockets or Server-Sent Events with Redux:

```jsx
// WebSocket middleware
const websocketMiddleware = (store) => (next) => (action) => {
  if (action.type === "WEBSOCKET_CONNECT") {
    const ws = new WebSocket(action.payload.url);

    ws.onopen = () => {
      store.dispatch({ type: "WEBSOCKET_CONNECTED" });
    };

    ws.onmessage = (event) => {
      const data = JSON.parse(event.data);
      store.dispatch({
        type: "WEBSOCKET_MESSAGE_RECEIVED",
        payload: data,
      });
    };

    ws.onclose = () => {
      store.dispatch({ type: "WEBSOCKET_DISCONNECTED" });
    };

    ws.onerror = (error) => {
      store.dispatch({
        type: "WEBSOCKET_ERROR",
        payload: error,
      });
    };

    // Store WebSocket instance for later use
    store.ws = ws;
  }

  if (action.type === "WEBSOCKET_SEND") {
    if (store.ws && store.ws.readyState === WebSocket.OPEN) {
      store.ws.send(JSON.stringify(action.payload));
    }
  }

  return next(action);
};

// Slice with real-time updates
const chatSlice = createSlice({
  name: "chat",
  initialState: {
    messages: [],
    connected: false,
    users: [],
  },
  reducers: {
    websocketConnected: (state) => {
      state.connected = true;
    },
    websocketDisconnected: (state) => {
      state.connected = false;
    },
    messageReceived: (state, action) => {
      state.messages.push(action.payload);
    },
    userJoined: (state, action) => {
      state.users.push(action.payload);
    },
    userLeft: (state, action) => {
      state.users = state.users.filter((user) => user.id !== action.payload.id);
    },
  },
  extraReducers: (builder) => {
    builder
      .addCase({ type: "WEBSOCKET_CONNECTED" }, (state) => {
        state.connected = true;
      })
      .addCase({ type: "WEBSOCKET_MESSAGE_RECEIVED" }, (state, action) => {
        const { type, data } = action.payload;
        switch (type) {
          case "NEW_MESSAGE":
            state.messages.push(data);
            break;
          case "USER_JOINED":
            state.users.push(data);
            break;
          case "USER_LEFT":
            state.users = state.users.filter((user) => user.id !== data.id);
            break;
        }
      });
  },
});

// Component
function ChatRoom() {
  const { messages, connected, users } = useSelector((state) => state.chat);
  const dispatch = useDispatch();

  useEffect(() => {
    dispatch({
      type: "WEBSOCKET_CONNECT",
      payload: { url: "ws://localhost:8080/chat" },
    });

    return () => {
      dispatch({ type: "WEBSOCKET_DISCONNECT" });
    };
  }, [dispatch]);

  const sendMessage = (message) => {
    dispatch({
      type: "WEBSOCKET_SEND",
      payload: { type: "SEND_MESSAGE", data: message },
    });
  };

  return (
    <div>
      <div>Status: {connected ? "Connected" : "Disconnected"}</div>
      <div>Users: {users.length}</div>
      <div>
        {messages.map((msg) => (
          <div key={msg.id}>{msg.text}</div>
        ))}
      </div>
    </div>
  );
}
```

### 15. How do you implement caching strategies with Redux?

**Answer**: Implement various caching strategies based on your needs:

```jsx
// RTK Query with caching
const api = createApi({
  reducerPath: "api",
  baseQuery: fetchBaseQuery({
    baseUrl: "/api",
  }),
  tagTypes: ["User", "Post"],
  endpoints: (builder) => ({
    // Cache for 60 seconds
    getUsers: builder.query({
      query: () => "users",
      keepUnusedDataFor: 60,
      providesTags: ["User"],
    }),

    // Cache indefinitely until invalidated
    getUserProfile: builder.query({
      query: (userId) => `users/${userId}`,
      keepUnusedDataFor: Infinity,
      providesTags: (result, error, userId) => [{ type: "User", id: userId }],
    }),

    updateUser: builder.mutation({
      query: ({ id, ...patch }) => ({
        url: `users/${id}`,
        method: "PATCH",
        body: patch,
      }),
      // Invalidate specific user cache
      invalidatesTags: (result, error, { id }) => [{ type: "User", id }],
    }),
  }),
});

// Manual caching with timestamps
const cacheSlice = createSlice({
  name: "cache",
  initialState: {
    data: {},
    timestamps: {},
    expirationTime: 5 * 60 * 1000, // 5 minutes
  },
  reducers: {
    setCacheData: (state, action) => {
      const { key, data } = action.payload;
      state.data[key] = data;
      state.timestamps[key] = Date.now();
    },
    clearExpiredCache: (state) => {
      const now = Date.now();
      Object.keys(state.timestamps).forEach((key) => {
        if (now - state.timestamps[key] > state.expirationTime) {
          delete state.data[key];
          delete state.timestamps[key];
        }
      });
    },
  },
});

// Cache-aware thunk
const fetchUserWithCache = createAsyncThunk(
  "users/fetchUserWithCache",
  async (userId, { getState, dispatch }) => {
    const state = getState();
    const cacheKey = `user_${userId}`;
    const cached = state.cache.data[cacheKey];
    const timestamp = state.cache.timestamps[cacheKey];

    // Check if cache is valid
    if (
      cached &&
      timestamp &&
      Date.now() - timestamp < state.cache.expirationTime
    ) {
      return cached;
    }

    // Fetch fresh data
    const response = await api.getUser(userId);
    const userData = response.data;

    // Update cache
    dispatch(
      cacheSlice.actions.setCacheData({
        key: cacheKey,
        data: userData,
      })
    );

    return userData;
  }
);

// Selective cache invalidation
const invalidateUserCache = createAsyncThunk(
  "cache/invalidateUser",
  async (userId, { dispatch, getState }) => {
    const cacheKey = `user_${userId}`;

    // Remove from cache
    dispatch(cacheSlice.actions.clearCacheKey(cacheKey));

    // Optionally refetch
    return dispatch(fetchUserWithCache(userId));
  }
);
```

---

## Redux vs Context API

### When to Choose Redux

**Use Redux when:**

- Large application with complex state logic
- Many components need access to the same data
- State updates are frequent and complex
- You need time-travel debugging
- Team is comfortable with Redux patterns
- You need middleware for side effects

```jsx
// Complex state updates better suited for Redux
const ecommerceSlice = createSlice({
  name: "ecommerce",
  initialState: {
    cart: { items: [], total: 0, discount: 0 },
    inventory: {},
    user: null,
    recommendations: [],
    recentlyViewed: [],
  },
  reducers: {
    addToCart: (state, action) => {
      const { productId, quantity } = action.payload;
      const existingItem = state.cart.items.find(
        (item) => item.id === productId
      );

      if (existingItem) {
        existingItem.quantity += quantity;
      } else {
        state.cart.items.push({ id: productId, quantity });
      }

      // Update total
      state.cart.total = state.cart.items.reduce((total, item) => {
        const product = state.inventory[item.id];
        return total + product.price * item.quantity;
      }, 0);

      // Apply discount
      if (state.cart.total > 100) {
        state.cart.discount = state.cart.total * 0.1;
      }

      // Add to recently viewed
      if (!state.recentlyViewed.includes(productId)) {
        state.recentlyViewed.unshift(productId);
        state.recentlyViewed = state.recentlyViewed.slice(0, 10);
      }
    },
  },
});
```

### When to Choose Context API

**Use Context API when:**

- Small to medium applications
- Simple state sharing (user auth, theme, language)
- Component-tree specific state
- Minimal state updates
- Want to avoid additional dependencies

```jsx
// Simple state better suited for Context
const ThemeContext = createContext();

function ThemeProvider({ children }) {
  const [theme, setTheme] = useState("light");
  const [language, setLanguage] = useState("en");

  const toggleTheme = () => {
    setTheme((prev) => (prev === "light" ? "dark" : "light"));
  };

  const value = {
    theme,
    language,
    setLanguage,
    toggleTheme,
  };

  return (
    <ThemeContext.Provider value={value}>{children}</ThemeContext.Provider>
  );
}

// Simple usage
function Header() {
  const { theme, toggleTheme } = useContext(ThemeContext);

  return (
    <header className={`header ${theme}`}>
      <button onClick={toggleTheme}>
        Switch to {theme === "light" ? "dark" : "light"} mode
      </button>
    </header>
  );
}
```

---

## Performance & Best Practices

### 1. Optimize useSelector Usage

```jsx
// ❌ Bad: Creates new object every render
const todoData = useSelector((state) => ({
  todos: state.todos,
  filter: state.filter,
}));

// ✅ Good: Use multiple selectors
const todos = useSelector((state) => state.todos);
const filter = useSelector((state) => state.filter);

// ✅ Good: Use memoized selector
const selectTodoData = useMemo(
  () =>
    createSelector(
      [(state) => state.todos, (state) => state.filter],
      (todos, filter) => ({ todos, filter })
    ),
  []
);
const todoData = useSelector(selectTodoData);

// ✅ Good: Use shallowEqual for objects
import { shallowEqual } from "react-redux";
const todoData = useSelector(
  (state) => ({
    todos: state.todos,
    filter: state.filter,
  }),
  shallowEqual
);
```

### 2. Avoid Unnecessary Re-renders

```jsx
// ❌ Bad: Component re-renders when any todo changes
function TodoCount() {
  const todos = useSelector((state) => state.todos);
  return <div>Count: {todos.length}</div>;
}

// ✅ Good: Only re-render when count changes
const selectTodoCount = (state) => state.todos.length;
function TodoCount() {
  const count = useSelector(selectTodoCount);
  return <div>Count: {count}</div>;
}

// ✅ Good: Memoize expensive computations
const selectCompletedTodoCount = createSelector(
  [(state) => state.todos],
  (todos) => todos.filter((todo) => todo.completed).length
);
```

### 3. Normalize State Structure

```jsx
// ❌ Bad: Nested structure is hard to update
const badState = {
  posts: [
    {
      id: 1,
      title: "Post 1",
      author: { id: 1, name: "John" },
      comments: [
        { id: 1, text: "Great post!", author: { id: 2, name: "Jane" } },
      ],
    },
  ],
};

// ✅ Good: Normalized structure
const goodState = {
  posts: {
    byId: {
      1: { id: 1, title: "Post 1", authorId: 1, commentIds: [1] },
    },
    allIds: [1],
  },
  users: {
    byId: {
      1: { id: 1, name: "John" },
      2: { id: 2, name: "Jane" },
    },
    allIds: [1, 2],
  },
  comments: {
    byId: {
      1: { id: 1, text: "Great post!", authorId: 2 },
    },
    allIds: [1],
  },
};
```

### 4. Use RTK Query for Data Fetching

```jsx
// ✅ RTK Query handles caching, loading states, and more
const api = createApi({
  reducerPath: "api",
  baseQuery: fetchBaseQuery({ baseUrl: "/api" }),
  tagTypes: ["Todo"],
  endpoints: (builder) => ({
    getTodos: builder.query({
      query: () => "todos",
      providesTags: ["Todo"],
    }),
    addTodo: builder.mutation({
      query: (newTodo) => ({
        url: "todos",
        method: "POST",
        body: newTodo,
      }),
      invalidatesTags: ["Todo"],
    }),
  }),
});

// Automatic loading states and caching
function TodoList() {
  const { data: todos, error, isLoading } = useGetTodosQuery();

  if (isLoading) return <div>Loading...</div>;
  if (error) return <div>Error: {error.message}</div>;

  return (
    <div>
      {todos.map((todo) => (
        <TodoItem key={todo.id} todo={todo} />
      ))}
    </div>
  );
}
```

---

## Version Comparison Table

| Feature               | Redux (Classic)          | Redux Toolkit             |
| --------------------- | ------------------------ | ------------------------- |
| **Setup Complexity**  | High (boilerplate)       | Low (batteries included)  |
| **Action Creators**   | Manual                   | Auto-generated            |
| **Immutable Updates** | Manual (spread operator) | Immer integration         |
| **Async Logic**       | Requires middleware      | createAsyncThunk built-in |
| **DevTools**          | Manual setup             | Pre-configured            |
| **Bundle Size**       | Varies by middleware     | Optimized                 |
| **TypeScript**        | Community types          | Built-in types            |
| **Learning Curve**    | Steep                    | Gentler                   |
| **Boilerplate**       | High                     | Minimal                   |

### Migration from Redux to RTK

```jsx
// Before (Classic Redux)
// actionTypes.js
export const ADD_TODO = 'ADD_TODO'
export const TOGGLE_TODO = 'TOGGLE_TODO'

// actions.js
export const addTodo = (text) => ({
  type: ADD_TODO,
  payload: { id: Date.now(), text, completed: false }
})

export const toggleTodo = (id) => ({
  type: TOGGLE_TODO,
  payload: { id }
})

// reducer.js
const initialState = { todos: [] }

export default function todosReducer(state = initialState, action) {
  switch (action.type) {
    case ADD_TODO:
      return {
        ...state,
        todos: [...state.todos, action.payload]
      }
    case TOGGLE_TODO:
      return {
        ...state,
        todos: state.todos.map(todo =>
          todo.id === action.payload.id
            ? { ...todo, completed: !todo.completed }
            : todo
        )
      }
    default:
      return state
  }
}

// After (Redux Toolkit)
import { createSlice } from '@reduxjs/toolkit'

const todosSlice = createSlice({
  name: 'todos',
  initialState: { todos: [] },
  reducers: {
    addTodo: (state, action) => {
      state.todos.push({
        id: Date.now(),
        text: action.payload,
        completed: false
      })
    },
    toggleTodo: (state, action) => {
      const todo = state.todos.find(todo => todo.id === action.payload)
      if (todo) {
        todo.completed = !todo.completed
      }
    }
  }
})

export const { addTodo, toggleTodo } = todosSlice.actions
export default todosSlice.reducer
```

### Performance Comparison

| Metric                  | Classic Redux              | Redux Toolkit                    |
| ----------------------- | -------------------------- | -------------------------------- |
| **Bundle Size**         | ~8KB (redux + react-redux) | ~14KB (includes Immer, Reselect) |
| **Runtime Performance** | Fast                       | Fast (Immer optimizations)       |
| **Development Speed**   | Slower (more boilerplate)  | Faster (less boilerplate)        |
| **Debugging**           | Manual DevTools setup      | Auto-configured DevTools         |
| **Type Safety**         | Manual TypeScript setup    | Built-in TypeScript support      |

---

## Conclusion

Redux and Redux Toolkit are powerful tools for state management in React applications. Understanding the core concepts, patterns, and best practices is crucial for React developers. The evolution from classic Redux to Redux Toolkit shows a trend toward reduced boilerplate and improved developer experience.

### Key Takeaways for Interviews:

1. **Understand the fundamentals**: Actions, reducers, store, and unidirectional data flow
2. **Know when to use Redux**: Large applications with complex state logic
3. **Be familiar with Redux Toolkit**: Modern Redux development approach
4. **Understand async patterns**: Thunks, sagas, and RTK Query
5. **Know performance optimizations**: Selectors, normalization, and memoization
6. **Compare with alternatives**: Context API, Zustand, Jotai
7. **Understand middleware**: How it works and popular examples
8. **Know best practices**: Code organization, testing, and debugging

This comprehensive guide covers everything you need to confidently discuss Redux concepts in your React interview!
