# JavaScript Interview Questions & Answers

_Organized by complexity: Advanced → Intermediate → Basic → Coding Problems_

---

## 🔥 **ADVANCED CONCEPTS** (Must Know for Senior Positions)

### **1. What is the event loop?**

The event loop is JavaScript's mechanism for handling asynchronous operations. It continuously checks the call stack and executes tasks from the task queue when the stack is empty.

**How it works:**

1. Call stack executes synchronous code
2. Asynchronous operations go to Web APIs
3. Completed operations move to task queue
4. Event loop moves tasks from queue to stack when stack is empty
5. Macro-task queue (also called the task queue):
   Includes setTimeout, setInterval, I/O, etc.
6. Micro-task queue:
   Includes Promises, queueMicrotask, MutationObserver, etc.

   **_Executes synchronous code ==> Runs all microtasks in the microtask queue ==> Then takes the macro-task from the macro-task queue_**

   **_Microtasks are always processed before the next macro-task_**

```javascript
console.log("1");
setTimeout(() => console.log("2"), 0);
Promise.resolve().then(() => console.log("3"));
console.log("4");
// Output: 1, 4, 3, 2
```

### **2. What is a prototype chain?**

The prototype chain is JavaScript's inheritance mechanism. When accessing a property, JavaScript looks on the object first, then its prototype, then the prototype's prototype, until reaching `Object.prototype` or `null`.

```javascript
function Person(name) {
  this.name = name;
}
Person.prototype.greet = function () {
  return `Hello, I'm ${this.name}`;
};

const john = new Person("John");
console.log(john.greet()); // "Hello, I'm John"
// john → Person.prototype → Object.prototype → null
```

### **3. What are closures and their uses?**

A closure is when an inner function has access to variables from its outer scope even after the outer function has finished executing.

**Uses:**

- Data privacy
- Module pattern
- Callbacks
- Partial application

```javascript
function outerFunction(x) {
  return function innerFunction(y) {
    return x + y; // Inner function has access to 'x'
  };
}

const add5 = outerFunction(5);
console.log(add5(3)); // 8
```

### **4. What is the difference between call, apply, and bind?**

All three methods set the `this` context of a function.

- **call**: Invokes immediately, arguments passed individually
- **apply**: Invokes immediately, arguments passed as array
- **bind**: Returns new function, doesn't invoke immediately

```javascript
const person = { name: "John" };

function greet(greeting, punctuation) {
  return `${greeting} ${this.name}${punctuation}`;
}

// call
greet.call(person, "Hello", "!"); // "Hello John!"

// apply
greet.apply(person, ["Hello", "!"]); // "Hello John!"

// bind
const boundGreet = greet.bind(person);
boundGreet("Hello", "!"); // "Hello John!"
```

### **5. What is memoization?**

Memoization is an optimization technique that stores expensive function call results and returns cached results for same inputs.

    Advantages of Memoization
        Performance Improvement
        Reduces Time Complexity
        Optimizes Repeated Calls
        Simple to Implement

    When to Use Memoization
        When a function is pure (output depends only on inputs, no side effects).
        When the function is called repeatedly with the same inputs.
        When the function is computationally expensive.

```javascript
function memoize(fn) {
  const cache = {};
  return function (...args) {
    const key = JSON.stringify(args);
    if (key in cache) {
      return cache[key];
    }
    cache[key] = fn.apply(this, args);
    return cache[key];
  };
}

const expensiveFunction = memoize((n) => {
  console.log("Computing...");
  return n * n;
});

expensiveFunction(5); // Computing... 25
expensiveFunction(5); // 25 (from cache)
```

### **6. What is the currying function?**

Currying transforms a function with multiple arguments into a sequence of functions, each taking a single argument.

```javascript
// Normal function
function add(a, b, c) {
  return a + b + c;
}

// Curried function
function curriedAdd(a) {
  return function (b) {
    return function (c) {
      return a + b + c;
    };
  };
}

const add5 = curriedAdd(5);
const add5And3 = add5(3);
console.log(add5And3(2)); // 10

// ES6 arrow functions
const curriedAddArrow = (a) => (b) => (c) => a + b + c;
```

### **7. What is a Temporal Dead Zone?**

The Temporal Dead Zone is the time between the start of a scope and the point where a `let` or `const` variable is declared. Accessing the variable during this time throws a ReferenceError.

```javascript
console.log(x); // ReferenceError: Cannot access 'x' before initialization
let x = 5;

// vs var (hoisted and initialized with undefined)
console.log(y); // undefined
var y = 10;
```

### **8. Explain Implicit Type Coercion in JavaScript**

JavaScript automatically converts values from one type to another when needed.

```javascript
// String coercion
"5" + 3; // '53' (number to string)
"5" - 3; // 2 (string to number)

// Boolean coercion
if ("hello") {
} // true (non-empty string)
if ("") {
} // false (empty string)

// Equality coercion
"5" == 5; // true (string converted to number)
"5" === 5; // false (no coercion)
```

### **8. Explain Type Conversion in JavaScript**

Definition: Explicitly converting a value from one type to another using functions or methods.

```javascript
// String to number
const num = Number("123"); // 123

// Number to string
const str = String(456); // "456"

// Boolean to number
const boolNum = Number(true); // 1
```

    Difference

| Aspect         | Type Conversion                     | Type Coercion                        |
| -------------- | ----------------------------------- | ------------------------------------ |
| How it happens | Explicit (programmer does it)       | Implicit (done automatically)        |
| Control        | You have control                    | JavaScript controls it               |
| Example syntax | `Number("123")`, `String(456)`      | `5 + "5"`, `"10" - 2`                |
| Use case       | When you want to ensure type safety | Happens during mixed-type operations |
| Predictability | More predictable                    | Sometimes confusing or surprising    |

### **9. What are pure and impure functions?**

**Pure functions:**

- Same input always produces same output (Always returns the same output for the same input)
- No side effects
- Don't modify external state

- Characteristics:
  Deterministic (same input → same output)
  No side effects (no modifying outside variables, no I/O, no changing global state)
  Easier to test and debug
  Can be memoized easily

**Impure functions:**

- May produce different outputs for same input (May return different outputs for the same inputs because it depends on or modifies external state.)
- Have side effects
- Modify external state

- Characteristics:
  Non-deterministic (same input might produce different output)
  Causes side effects
  Harder to test and debug because of external dependencies

```javascript
// Pure function
function add(a, b) {
  return a + b; // Always same output for same input
}

// Impure function
let counter = 0;
function incrementCounter() {
  counter++; // Modifies external state
  return counter;
}
```

### **10. What is debouncing and throttling?**

**Debouncing:** Delays function execution until after a specified time has passed since the last call.

```javascript
function debounce(func, delay) {
  let timeoutId;
  return function (...args) {
    clearTimeout(timeoutId);
    timeoutId = setTimeout(() => func.apply(this, args), delay);
  };
}

// Usage: Search input
const searchInput = debounce(searchAPI, 300);
```

**Throttling:** Limits function execution to once every specified time period.

```javascript
function throttle(func, delay) {
  let lastExecTime = 0;
  return function (...args) {
    const now = Date.now();
    if (now - lastExecTime > delay) {
      lastExecTime = now;
      func.apply(this, args);
    }
  };
}

// Usage: Scroll events
window.addEventListener("scroll", throttle(handleScroll, 100));
```

---

## 🔶 **INTERMEDIATE CONCEPTS**

### **11. What is Hoisting?**

Hoisting is a JavaScript mechanism where variable and function declarations are moved to the top of their scope (either global or function scope) before code execution during compilation.

- JavaScript does two things during hoisting:
  - Declarations are hoisted.
  - Initializations (assignments) are not hoisted.

```javascript
// What you write
console.log(x); // undefined (not error)
var x = 5;
sayHello(); // "Hello!" (works)

function sayHello() {
  console.log("Hello!");
}

// What JavaScript sees
var x; // hoisted
function sayHello() {
  // hoisted
  console.log("Hello!");
}
console.log(x); // undefined
x = 5;
```

### **12. What is the purpose of the `this` keyword?**

- `this` refers to the object that is executing the current function.
- `this` keyword allows a function to access the **object that invoked it**, enabling **dynamic context binding**.

## 🧾 Contexts and `this` Behavior

| Invocation Type          | What `this` Refers To                                   |
| ------------------------ | ------------------------------------------------------- |
| Global Context           | `window` (in browsers), or `global` (in Node.js)        |
| Function Call            | Global object (`window`), or `undefined` in strict mode |
| Method Call (`obj.fn()`) | The object owning the method (`obj`)                    |
| Constructor Function     | The new object being created (`new` keyword)            |
| Arrow Function           | Lexically inherits `this` from surrounding scope        |

```javascript
const person = {
  name: "John",
  greet: function () {
    return `Hello, I'm ${this.name}`; // this = person object
  },
  greetArrow: () => {
    return `Hello, I'm ${this.name}`; // this = global object
  },
};

person.greet(); // "Hello, I'm John"
person.greetArrow(); // "Hello, I'm undefined"
```

### **13. What are Promises and promise chaining?**

- Promises handle asynchronous operations and represent a value that may be available now, in the future, or never.
- A Promise is an object that represents the eventual result (or failure) of an asynchronous operation.

### Promise States

| State       | Description                                   |
| ----------- | --------------------------------------------- |
| `pending`   | Initial state; neither fulfilled nor rejected |
| `fulfilled` | Operation completed successfully              |
| `rejected`  | Operation failed                              |

### What is Promise Chaining?

- Promise chaining allows multiple asynchronous operations to run in sequence, where the output of one .then() is passed to the next.

```javascript
const fetchUser = new Promise((resolve, reject) => {
  setTimeout(() => {
    resolve({ id: 1, name: "John" });
  }, 1000);
});

// Promise chaining
fetchUser
  .then((user) => {
    console.log(user);
    return fetch(`/posts/${user.id}`);
  })
  .then((posts) => console.log(posts))
  .catch((error) => console.error(error));
```

### **14. What are callback functions and callback hell?**

A callback function is a function that is passed as an argument to another function and is executed after that function has finished executing

- In simple terms, a callback is a way of saying: "When you're done, call me."

**Callback Hell: (Pyramid of Doom)** Nested callbacks that make code hard to read and maintain.

- Callback hell refers to the nested structure of callbacks that occur when many asynchronous operations are dependent on each other. This can result in deeply nested code that is hard to read, maintain, and debug

```javascript
// Callback hell
getData(function (a) {
  getMoreData(a, function (b) {
    getEvenMoreData(b, function (c) {
      // This is callback hell
    });
  });
});

// Solution: Promises or async/await
async function fetchData() {
  const a = await getData();
  const b = await getMoreData(a);
  const c = await getEvenMoreData(b);
  return c;
}
```

### **15. What is an IIFE (Immediately Invoked Function Expression)?**

- A function that runs immediately after being defined.
- The primary purpose of an IIFE is to create a self-contained scope for variables and functions, preventing them from interfering with the rest of the code in the global scope.

```javascript
// Standard IIFE
(function () {
  console.log("IIFE executed!");
})();

// Without extra brackets (using unary operators)
!(function () {
  console.log("IIFE without extra brackets!");
})();

+(function () {
  console.log("Another way!");
})();
```

### **16. What are Classes in ES6?**

- ES6 classes provide a cleaner syntax for creating objects and inheritance.
- It's like a blue print for creating an Object

```javascript
class Person {
  constructor(name, age) {
    this.name = name;
    this.age = age;
  }

  greet() {
    return `Hello, I'm ${this.name}`;
  }

  static species() {
    return "Homo sapiens";
  }
}

class Student extends Person {
  constructor(name, age, grade) {
    super(name, age);
    this.grade = grade;
  }

  study() {
    return `${this.name} is studying`;
  }
}

const student = new Student("Alice", 20, "A");
```

### **17. What are modules and why do you need them?**

Modules help organize code into separate files and control what's exported/imported.

```javascript
// math.js
export function add(a, b) {
  return a + b;
}

export const PI = 3.14159;

export default function multiply(a, b) {
  return a * b;
}

// main.js
import multiply, { add, PI } from "./math.js";

console.log(add(2, 3)); // 5
console.log(multiply(4, 5)); // 20
console.log(PI); // 3.14159
```

### **18. What is the difference between `let` and `var`?**

| `var`                  | `let`                |
| ---------------------- | -------------------- |
| Function scoped        | Block scoped         |
| Hoisted with undefined | Hoisted but in TDZ   |
| Can be redeclared      | Cannot be redeclared |
| Added to window object | Not added to window  |

```javascript
function example() {
  if (true) {
    var x = 1;
    let y = 2;
  }
  console.log(x); // 1 (accessible)
  console.log(y); // ReferenceError: y is not defined
}
```

### **19. What are arrow functions?**

- It was introduced in ES6 features more like it's Functional Programming concept
- Arrow functions provide a shorter syntax and don't have their own `this` `arguments`, or `super` binding.
- Arrow functions make code more expressive, especially when used in methods like `map`, `filter`, and `reduce`
- Cannot be used as constructors

```javascript
// Regular function
function add(a, b) {
  return a + b;
}

// Arrow function
const add = (a, b) => a + b;

// Multiple lines
const multiply = (a, b) => {
  const result = a * b;
  return result;
};

// No parameters
const greet = () => "Hello!";

// Single parameter (parentheses optional)
const square = (x) => x * x;
```

### **20. What is event bubbling and capturing?**

When an event (like a `click`) occurs on an element, it doesn't just affect that element—it travels through the DOM in **phases**:

1. **Capturing Phase** – from the `document` down to the target element.
2. **Target Phase** – the event reaches the target element.
3. **Bubbling Phase** – the event bubbles back up from the target to the root.

**Event Bubbling:** Events propagate from target element up to root.
**Event Capturing:** Events propagate from root down to target element.

```javascript
// HTML: <div id="outer"><div id="inner">Click me</div></div>

document.getElementById("outer").addEventListener(
  "click",
  () => {
    console.log("Outer clicked");
  },
  false
); // false = bubbling (default)

document.getElementById("inner").addEventListener(
  "click",
  () => {
    console.log("Inner clicked");
  },
  false
);

// Clicking inner div outputs:
// Inner clicked
// Outer clicked
```

---

## 🔷 **BASIC CONCEPTS**

### **21. What are the different data types in JavaScript?**

**Primitive types:**

- Number, String, Boolean, Undefined, Null, Symbol, BigInt

**Non-primitive types:**

- Object (includes arrays, functions, dates, etc.)

```javascript
// Primitive
let num = 42;
let str = "hello";
let bool = true;
let undef = undefined;
let nul = null;
let sym = Symbol("id");
let bigInt = 123n;

// Non-primitive
let obj = { name: "John" };
let arr = [1, 2, 3];
let func = function () {};
```

### **22. What is the difference between `==` and `===`?**

- `==` (loose equality): Performs type coercion
- `===` (strict equality): No type coercion

```javascript
5 == "5"; // true (string '5' converted to number)
5 === "5"; // false (different types)

null == undefined; // true
null === undefined; // false

0 == false; // true
0 === false; // false
```

### **23. What is the difference between `null` and `undefined`?**

- `undefined`: Variable declared but not assigned
- `null`: Intentional absence of value

```javascript
let x; // undefined
let y = null; // null

typeof undefined; // 'undefined'
typeof null; // 'object' (known bug in JavaScript)

undefined == null; // true
undefined === null; // false
```

### **24. What is Object Destructuring?**

Extracting properties from objects or elements from arrays.

```javascript
// Object destructuring
const person = { name: "John", age: 30, city: "NYC" };
const { name, age } = person;
console.log(name); // 'John'

// Array destructuring
const numbers = [1, 2, 3, 4, 5];
const [first, second, ...rest] = numbers;
console.log(first); // 1
console.log(rest); // [3, 4, 5]

// Default values
const { name, country = "USA" } = person;
```

### **25. What is the difference between slice and splice?**

| `slice()`               | `splice()`                           |
| ----------------------- | ------------------------------------ |
| Returns new array       | Modifies original array              |
| Doesn't change original | Changes original                     |
| slice(start, end)       | splice(start, deleteCount, ...items) |

```javascript
const arr = [1, 2, 3, 4, 5];

// slice (doesn't modify original)
const sliced = arr.slice(1, 3); // [2, 3]
console.log(arr); // [1, 2, 3, 4, 5] (unchanged)

// splice (modifies original)
const spliced = arr.splice(1, 2, "a", "b"); // [2, 3]
console.log(arr); // [1, 'a', 'b', 4, 5] (modified)
```

### **26. What are spread and rest operators?**

**Spread (...):** Expands elements - The spread operator is used to expand or unpack elements from an array or object into individual elements.

- Copying an array or object.
- Merging multiple arrays or objects.
- Passing multiple arguments to a function.

**Rest (...):** Collects elements - The rest operator is used to collect multiple elements into a single array or object

- Function arguments to capture all passed arguments.
- Object destructuring to collect remaining properties.

```javascript
// Spread
const arr1 = [1, 2, 3];
const arr2 = [...arr1, 4, 5]; // [1, 2, 3, 4, 5]

const obj1 = { a: 1, b: 2 };
const obj2 = { ...obj1, c: 3 }; // { a: 1, b: 2, c: 3 }

// Rest
function sum(...numbers) {
  return numbers.reduce((total, num) => total + num, 0);
}

sum(1, 2, 3, 4); // 10
```

### **27. What is a conditional operator?**

The ternary operator `? :` is a shorthand for if-else.

```javascript
const age = 18;
const status = age >= 18 ? "adult" : "minor";

// Chaining
const score = 85;
const grade = score >= 90 ? "A" : score >= 80 ? "B" : score >= 70 ? "C" : "F";
```

### **28. What is the difference between parameters and arguments?**

- **Parameters:** Variables in function definition
- **Arguments:** Actual values passed to function

```javascript
function greet(name, age) {
  // name, age are parameters
  console.log(`Hello ${name}, you are ${age}`);
}

greet("John", 25); // 'John', 25 are arguments
```

### **29. What is JSON and its common operations?**

JSON (JavaScript Object Notation) is a text format for storing and transporting data.

```javascript
const obj = { name: "John", age: 30 };

// Object to JSON string
const jsonString = JSON.stringify(obj);
console.log(jsonString); // '{"name":"John","age":30}'

// JSON string to object
const parsedObj = JSON.parse(jsonString);
console.log(parsedObj); // { name: 'John', age: 30 }
```

### **30. What is the difference between `for...in` and `for...of`?**

- In JavaScript, both the `for...in` and `for...of` loops allow you to iterate over data, but they are used for different purposes. The key difference is how they iterate and what they return.

- `for...in`: The `for...in` loop is used to **iterate over object properties** or **array indices**. It returns the **keys** (or indices) of the object or array.

- `for...of`: Iterates over iterable values - The `for...of` loop is used to **iterate over object properties** or **array indices**. It returns the **Values** (or indices) of the object or array.

```javascript
const arr = ["a", "b", "c"];
const obj = { x: 1, y: 2, z: 3 };

// for...in (keys/indices)
for (let key in obj) {
  console.log(key); // 'x', 'y', 'z'
}

for (let index in arr) {
  console.log(index); // '0', '1', '2'
}

// for...of (values)
for (let value of arr) {
  console.log(value); // 'a', 'b', 'c'
}
```

---

## 💻 **CODING PROBLEMS** (Practice Questions)

### **1. Reverse a string**

```javascript
function reverseString(str) {
  return str.split("").reverse().join("");
}

// Alternative
function reverseString2(str) {
  let reversed = "";
  for (let i = str.length - 1; i >= 0; i--) {
    reversed += str[i];
  }
  return reversed;
}
```

### **2. Check if a string is palindrome**

```javascript
function isPalindrome(str) {
  const cleaned = str.toLowerCase().replace(/[^a-z0-9]/g, "");
  return cleaned === cleaned.split("").reverse().join("");
}

console.log(isPalindrome("A man a plan a canal Panama")); // true
```

### **3. Find largest number in array**

```javascript
function findLargest(arr) {
  return Math.max(...arr);
}

// Alternative
function findLargest2(arr) {
  let largest = arr[0];
  for (let i = 1; i < arr.length; i++) {
    if (arr[i] > largest) {
      largest = arr[i];
    }
  }
  return largest;
}
```

### **4. Sum of array elements**

```javascript
function sumArray(arr) {
  return arr.reduce((sum, num) => sum + num, 0);
}

// Alternative
function sumArray2(arr) {
  let sum = 0;
  for (let num of arr) {
    sum += num;
  }
  return sum;
}
```

### **5. Check if number is prime**

```javascript
function isPrime(num) {
  if (num < 2) return false;
  for (let i = 2; i <= Math.sqrt(num); i++) {
    if (num % i === 0) return false;
  }
  return true;
}
```

### **6. Fibonacci sequence**

```javascript
function fibonacci(n) {
  if (n <= 1) return n;

  let a = 0,
    b = 1;
  for (let i = 2; i <= n; i++) {
    [a, b] = [b, a + b];
  }
  return b;
}

// Generate sequence up to n terms
function fibonacciSequence(n) {
  const sequence = [];
  for (let i = 0; i < n; i++) {
    sequence.push(fibonacci(i));
  }
  return sequence;
}
```

### **7. Calculate factorial**

```javascript
function factorial(n) {
  if (n <= 1) return 1;
  return n * factorial(n - 1);
}

// Iterative version
function factorialIterative(n) {
  let result = 1;
  for (let i = 2; i <= n; i++) {
    result *= i;
  }
  return result;
}
```

### **8. Merge two arrays**

```javascript
function mergeArrays(arr1, arr2) {
  return [...arr1, ...arr2];
}

// Remove duplicates
function mergeUnique(arr1, arr2) {
  return [...new Set([...arr1, ...arr2])];
}
```

### **9. Find intersection of two arrays**

```javascript
function intersection(arr1, arr2) {
  return arr1.filter((value) => arr2.includes(value));
}

// Remove duplicates from result
function intersectionUnique(arr1, arr2) {
  return [...new Set(arr1.filter((value) => arr2.includes(value)))];
}
```

### **10. Remove first element from array**

```javascript
function removeFirst(arr) {
  return arr.slice(1);
}

// Modify original array
function removeFirstMutate(arr) {
  return arr.shift();
}
```

---

## 📚 **ADDITIONAL IMPORTANT TOPICS**

### **Optional Chaining**

```javascript
const user = {
  profile: {
    name: "John",
  },
};

// Without optional chaining
const name = user && user.profile && user.profile.name;

// With optional chaining
const name2 = user?.profile?.name;
const email = user?.profile?.email ?? "No email"; // Nullish coalescing
```

### **Pass by Value vs Pass by Reference**

```javascript
// Primitives: Pass by value
let a = 5;
let b = a;
a = 10;
console.log(b); // 5 (unchanged)

// Objects: Pass by reference
let obj1 = { x: 5 };
let obj2 = obj1;
obj1.x = 10;
console.log(obj2.x); // 10 (changed)
```

### **Array and String Mutation Methods**

```javascript
// Array mutation methods (modify original)
const mutatingMethods = [
  "push",
  "pop",
  "shift",
  "unshift",
  "splice",
  "sort",
  "reverse",
  "fill",
];

// Non-mutating methods (return new array)
const nonMutatingMethods = [
  "slice",
  "concat",
  "map",
  "filter",
  "reduce",
  "join",
  "indexOf",
];

// Strings are immutable in JavaScript
let str = "hello";
str.toUpperCase(); // Returns new string
console.log(str); // 'hello' (unchanged)
```

---

## 🔥 **ADDITIONAL ADVANCED CONCEPTS**

### **31. In JavaScript, how many different methods can you make an object?**

There are **8 main ways** to create objects in JavaScript:

```javascript
// 1. Object Literal
const obj1 = { name: "John", age: 25 };

// 2. new Object()
const obj2 = new Object();
obj2.name = "John";

// 3. Constructor Function
function Person(name, age) {
  this.name = name;
  this.age = age;
}
const obj3 = new Person("John", 25);

// 4. Object.create()
const personProto = {
  greet() {
    return "Hello";
  },
};
const obj4 = Object.create(personProto);

// 5. ES6 Classes
class PersonClass {
  constructor(name, age) {
    this.name = name;
    this.age = age;
  }
}
const obj5 = new PersonClass("John", 25);

// 6. Factory Function
function createPerson(name, age) {
  return { name, age };
}
const obj6 = createPerson("John", 25);

// 7. Object.assign()
const obj7 = Object.assign({}, { name: "John" }, { age: 25 });

// 8. Using Prototype
function PersonProto() {}
PersonProto.prototype.name = "John";
const obj8 = new PersonProto();
```

### **32. Difference between prototypal and classical inheritance**

| **Classical Inheritance**      | **Prototypal Inheritance**      |
| ------------------------------ | ------------------------------- |
| Classes are blueprints         | Objects inherit from objects    |
| Instances created from classes | Objects can be created directly |
| Static hierarchy               | Dynamic hierarchy               |
| Found in Java, C#              | Native to JavaScript            |

```javascript
// Classical (ES6 Classes - syntactic sugar)
class Animal {
  constructor(name) {
    this.name = name;
  }
  speak() {
    return `${this.name} makes a sound`;
  }
}

class Dog extends Animal {
  speak() {
    return `${this.name} barks`;
  }
}

// Prototypal (True JavaScript way)
const animal = {
  speak() {
    return `${this.name} makes a sound`;
  },
};

const dog = Object.create(animal);
dog.name = "Buddy";
dog.speak = function () {
  return `${this.name} barks`;
};
```

### **33. What is a first order function?**

A **first-order function** is a function that:

- Doesn't take functions as arguments
- Doesn't return functions
- Only operates on primitive data types

```javascript
// First-order functions
function add(a, b) {
  return a + b; // Only operates on numbers
}

function greet(name) {
  return `Hello ${name}`; // Only operates on strings
}

// Higher-order functions (NOT first-order)
function higherOrder(fn) {
  return fn(); // Takes function as argument
}

function createMultiplier(x) {
  return function (y) {
    return x * y;
  }; // Returns function
}
```

### **34. What is a service worker and how do you manipulate DOM using it?**

**Service Worker** is a script that runs in the background, separate from web pages, enabling features like push notifications and background sync.

**⚠️ Important:** Service workers **CANNOT directly access DOM** because they run in a different thread.

```javascript
// Registering service worker (in main thread)
if ("serviceWorker" in navigator) {
  navigator.serviceWorker
    .register("/sw.js")
    .then((registration) => console.log("SW registered"))
    .catch((error) => console.log("SW registration failed"));
}

// service-worker.js
self.addEventListener("install", (event) => {
  console.log("Service worker installing...");
});

// To communicate with main thread (where DOM access is possible)
self.addEventListener("message", (event) => {
  // Send message back to main thread
  event.ports[0].postMessage({
    action: "updateDOM",
    data: "Some data",
  });
});

// In main thread - handling messages from SW
navigator.serviceWorker.addEventListener("message", (event) => {
  if (event.data.action === "updateDOM") {
    // Now you can manipulate DOM
    document.getElementById("status").textContent = event.data.data;
  }
});
```

### **35. What is web storage and What is a Cookie?**

## 🌐 Web Storage vs Cookies

### What is Web Storage?

Web Storage provides **client-side storage** mechanisms that allow websites to store data locally within the user's browser. It mainly consists of two types:

- **localStorage**: Stores data with no expiration time — data persists even when the browser is closed and reopened.
- **sessionStorage**: Stores data for the duration of the page session — data is cleared when the browser tab is closed.

### What is a Cookie?

Cookies are small text files stored by the browser that hold data specific to a particular website. Cookies are sent automatically with every HTTP request to the server, which makes them useful for things like session management and personalization.

---

### Feature Comparison: localStorage vs sessionStorage vs Cookies

| Feature           | **localStorage**                       | **sessionStorage**           | **Cookies**                       |
| ----------------- | -------------------------------------- | ---------------------------- | --------------------------------- |
| **Capacity**      | ~5-10 MB                               | ~5-10 MB                     | ~4 KB                             |
| **Lifetime**      | Until manually cleared                 | Until the browser tab closes | Set by expiration date/time       |
| **Server Access** | No                                     | No                           | Yes, sent with every HTTP request |
| **Scope**         | Same-origin (domain + protocol + port) | Specific to the browser tab  | Domain and path (configurable)    |

---

### Summary

- **Web Storage** (`localStorage` and `sessionStorage`) provides larger, client-side storage that is **not sent to the server**.
- **Cookies** are smaller in size but **automatically sent** with each HTTP request to the server, making them useful for authentication and tracking.
- Choose **localStorage** for persistent data you want to keep across sessions.
- Choose **sessionStorage** for temporary data tied to a single tab.
- Use **Cookies** when you need to share data with the server on every request.

---

If you want, I can add code examples demonstrating how to use localStorage, sessionStorage, and cookies as well!

```javascript
// localStorage
localStorage.setItem("user", JSON.stringify({ name: "John" }));
const user = JSON.parse(localStorage.getItem("user"));
localStorage.removeItem("user");
localStorage.clear();

// sessionStorage
sessionStorage.setItem("temp", "value");
const temp = sessionStorage.getItem("temp");

// Cookies
document.cookie =
  "username=john; expires=Thu, 18 Dec 2024 12:00:00 UTC; path=/";
console.log(document.cookie); // "username=john"

// Better cookie handling
function setCookie(name, value, days) {
  const date = new Date();
  date.setTime(date.getTime() + days * 24 * 60 * 60 * 1000);
  document.cookie = `${name}=${value}; expires=${date.toUTCString()}; path=/`;
}

function getCookie(name) {
  const value = `; ${document.cookie}`;
  const parts = value.split(`; ${name}=`);
  if (parts.length === 2) return parts.pop().split(";").shift();
}
```

### **36. What do you mean by strict mode in JavaScript?**

**Strict mode** is a way to opt into a restricted variant of JavaScript that eliminates silent errors and improves performance.

```javascript
"use strict";

// Strict mode effects:
// 1. Variables must be declared
x = 10; // ReferenceError: x is not defined

// 2. Deleting variables/functions is not allowed
var y = 10;
delete y; // SyntaxError

// 3. Duplicate parameter names not allowed
function test(a, a) {} // SyntaxError

// 4. this is undefined in functions (not global object)
function show() {
  console.log(this); // undefined (not window)
}

// 5. Octal literals not allowed
var num = 010; // SyntaxError

// 6. with statement not allowed
with (Math) {
  // SyntaxError
  x = cos(2);
}

// Function-level strict mode
function strictFunction() {
  "use strict";
  // Strict mode only applies here
}
```

### **37. What is eval and why should you avoid it?**

`eval()` executes JavaScript code represented as a string. It's generally considered **dangerous** and should be avoided.

### **38. What is the difference between window and document?**

| **window**                    | **document**          |
| ----------------------------- | --------------------- |
| Global object                 | Part of window object |
| Browser window                | Web page content      |
| Contains all global variables | Contains DOM elements |
| Browser API access            | DOM manipulation      |

```javascript
// window - Global object
console.log(window.innerWidth); // Browser width
console.log(window.location.href); // Current URL
window.alert("Hello"); // Browser alert

// Global variables are window properties
var globalVar = "test";
console.log(window.globalVar); // 'test'

// document - DOM interface
console.log(document.title); // Page title
console.log(document.URL); // Page URL
document.getElementById("myId"); // DOM element

// Relationship
console.log(window.document === document); // true
console.log(document.defaultView === window); // true

// Key differences:
// window: setTimeout, setInterval, localStorage, location
// document: getElementById, querySelector, createElement, body
```

### **39. What is isNaN and the difference between isNaN and Number.isNaN?**

### What is `isNaN`?

`isNaN` is a global JavaScript function used to check whether a value is **NaN** ("Not-a-Number"). It returns `true` if the value **cannot be converted to a valid number**, and `false` otherwise.

### Important Note:

- `isNaN` **first converts** the value to a number before checking if it is `NaN`.
- Because of this coercion, `isNaN` can sometimes give confusing results.

```javascript
// isNaN() - Global function (with type coercion)
console.log(isNaN(NaN)); // true
console.log(isNaN("hello")); // true (coerced to NaN)
console.log(isNaN("123")); // false (coerced to 123)
console.log(isNaN(true)); // false (coerced to 1)
console.log(isNaN(undefined)); // true (coerced to NaN)

// Number.isNaN() - ES6 method (strict, no coercion)
console.log(Number.isNaN(NaN)); // true
console.log(Number.isNaN("hello")); // false (no coercion)
console.log(Number.isNaN("123")); // false
console.log(Number.isNaN(true)); // false
console.log(Number.isNaN(undefined)); // false

// Reliable NaN check without Number.isNaN
function isReallyNaN(value) {
  return value !== value; // NaN is the only value not equal to itself
}

// Best practice: Use Number.isNaN for strict checking
function safeCheck(value) {
  if (Number.isNaN(value)) {
    console.log("Value is NaN");
  }
}
```

### **40. What is BOM (Browser Object Model)?**

**BOM** The BOM (Browser Object Model) is a set of objects provided by the browser that allows JavaScript to interact with the browser outside of the web page's content.

Unlike the DOM (Document Object Model), which deals with the structure and content of web pages, the BOM provides access to the browser environment itself — like the window, browser history, screen dimensions, and more.

```javascript
// window object (root of BOM)
console.log(window.innerWidth, window.innerHeight);

// location object
console.log(location.href); // Current URL
location.reload(); // Reload page
location.assign("https://google.com"); // Navigate

// navigator object
console.log(navigator.userAgent); // Browser info
console.log(navigator.language); // Browser language
console.log(navigator.onLine); // Online status

// history object
history.back(); // Go back
history.forward(); // Go forward
history.go(-2); // Go back 2 pages

// screen object
console.log(screen.width, screen.height);
console.log(screen.availWidth); // Available width

// Complete BOM structure:
const bomInfo = {
  window: {
    location: location.href,
    navigator: navigator.userAgent,
    history: history.length,
    screen: `${screen.width}x${screen.height}`,
    document: document.title,
  },
};
```

### **41. What is setTimeout and setInterval?**

- JavaScript provides two timing functions for delayed and repeated execution of code:

**setTimeout**:

- Executes a function **once** after a specified delay (in milliseconds).
- Returns a timeout ID that can be used to cancel the timeout.

**setInterval**

- Executes a function repeatedly at specified time intervals (in milliseconds).
- Returns an interval ID that can be used to cancel the interval.

```javascript
// setTimeout - Execute once
const timeoutId = setTimeout(() => {
  console.log("Executed after 2 seconds");
}, 2000);

// Clear timeout
clearTimeout(timeoutId);

// setTimeout with parameters
setTimeout(
  (name, age) => {
    console.log(`Hello ${name}, age ${age}`);
  },
  1000,
  "John",
  25
);

// setInterval - Execute repeatedly
const intervalId = setInterval(() => {
  console.log("Every 3 seconds");
}, 3000);

// Clear interval
clearInterval(intervalId);

// Common patterns:
// 1. Delayed execution
function delayedExecution() {
  setTimeout(() => {
    console.log("Delayed operation");
  }, 1000);
}

// 2. Polling
function startPolling() {
  const pollInterval = setInterval(() => {
    // Check for updates
    fetchUpdates().then((data) => {
      if (data.shouldStop) {
        clearInterval(pollInterval);
      }
    });
  }, 5000);
}

// 3. Auto-clear timeout
function autoTimeout() {
  let counter = 0;
  const id = setInterval(() => {
    counter++;
    console.log(`Count: ${counter}`);
    if (counter >= 5) {
      clearInterval(id);
    }
  }, 1000);
}
```

### **42. What is event delegation?**

**Event Delegation** uses event bubbling to handle events for multiple elements with a single event listener on a parent element. is a technique in JavaScript where instead of attaching event listeners to multiple child elements individually, you attach a single event listener to their
**common parent**. This parent listens for events that bubble up from its children and handles them based on the event target.

---

### How It Works

- Events in the DOM **bubble up** from the target element to its parents.
- By adding one listener to a parent element, you can monitor events from all its child elements.
- This reduces the number of event listeners, improving performance and making code easier to manage.

```javascript
// Without delegation (inefficient)
document.querySelectorAll(".button").forEach((button) => {
  button.addEventListener("click", handleClick);
});

// With delegation (efficient)
document.getElementById("container").addEventListener("click", (event) => {
  if (event.target.classList.contains("button")) {
    handleClick(event);
  }
});

// Practical example: Dynamic list
const list = document.getElementById("todo-list");

// Handle clicks on any list item (even future ones)
list.addEventListener("click", (event) => {
  if (event.target.tagName === "LI") {
    console.log("List item clicked:", event.target.textContent);
  }

  if (event.target.classList.contains("delete-btn")) {
    event.target.parentElement.remove();
  }
});

// Add new items dynamically
function addTodoItem(text) {
  const li = document.createElement("li");
  li.innerHTML = `
        ${text}
        <button class="delete-btn">Delete</button>
    `;
  list.appendChild(li); // Event delegation handles this automatically
}

// Benefits:
// 1. Better performance (fewer event listeners)
// 2. Works with dynamically added elements
// 3. Less memory usage
// 4. Simpler code maintenance
```

### **43. What are PWAs (Progressive Web Apps)?**

**PWAs** are web applications that use modern web technologies to provide native app-like experiences.

```javascript
// Key features and implementation:

// 1. Service Worker (for offline functionality)
if ('serviceWorker' in navigator) {
    navigator.serviceWorker.register('/sw.js');
}

// 2. Web App Manifest (for installability)
// manifest.json
{
    "name": "My PWA",
    "short_name": "PWA",
    "start_url": "/",
    "display": "standalone",
    "background_color": "#ffffff",
    "theme_color": "#000000",
    "icons": [
        {
            "src": "icon-192.png",
            "sizes": "192x192",
            "type": "image/png"
        }
    ]
}

// 3. HTTPS requirement
// PWAs must be served over HTTPS

// 4. Responsive design
@media (max-width: 768px) {
    /* Mobile styles */
}

// 5. App-like navigation
// Implement SPA routing

// 6. Push notifications
navigator.serviceWorker.ready.then(registration => {
    return registration.pushManager.subscribe({
        userVisibleOnly: true,
        applicationServerKey: urlBase64ToUint8Array(publicVapidKey)
    });
});

// PWA Benefits:
// - Installable without app store
// - Offline functionality
// - Push notifications
// - Fast loading
// - Secure (HTTPS)
// - Responsive design
```

### **44. What is a polyfill?**

A **polyfill** is code that implements features that are not natively supported by a browser.

```javascript
// Example: Array.includes() polyfill for older browsers
if (!Array.prototype.includes) {
  Array.prototype.includes = function (searchElement, fromIndex) {
    "use strict";
    if (this == null) {
      throw new TypeError(
        "Array.prototype.includes called on null or undefined"
      );
    }

    const object = Object(this);
    const len = parseInt(object.length) || 0;

    if (len === 0) return false;

    const start = parseInt(fromIndex) || 0;
    let k = start >= 0 ? start : Math.max(len + start, 0);

    while (k < len) {
      if (object[k] === searchElement) {
        return true;
      }
      k++;
    }
    return false;
  };
}

// Promise polyfill (simplified)
if (typeof Promise === "undefined") {
  window.Promise = function (executor) {
    const self = this;
    self.state = "pending";
    self.value = undefined;
    self.handlers = [];

    function resolve(value) {
      if (self.state === "pending") {
        self.state = "fulfilled";
        self.value = value;
        self.handlers.forEach((handler) => handler.onFulfilled(value));
      }
    }

    function reject(reason) {
      if (self.state === "pending") {
        self.state = "rejected";
        self.value = reason;
        self.handlers.forEach((handler) => handler.onRejected(reason));
      }
    }

    executor(resolve, reject);
  };
}

// fetch() polyfill check
if (!window.fetch) {
  // Load fetch polyfill
  const script = document.createElement("script");
  script.src =
    "https://cdn.jsdelivr.net/npm/whatwg-fetch@3.6.2/dist/fetch.umd.js";
  document.head.appendChild(script);
}

// Common polyfills:
// - Babel (ES6+ syntax)
// - core-js (ES6+ APIs)
// - whatwg-fetch (fetch API)
// - intersection-observer
```

### **45. What is a Regular Expression?**

**Regular Expressions** are patterns used to match character combinations in strings.

```javascript
// Basic syntax
const regex1 = /pattern/flags;
const regex2 = new RegExp('pattern', 'flags');

// Common flags:
// g - global (find all matches)
// i - case insensitive
// m - multiline

// Examples:
const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
const phoneRegex = /^\d{3}-\d{3}-\d{4}$/;
const urlRegex = /https?:\/\/(www\.)?[-a-zA-Z0-9@:%._\+~#=]{1,256}\.[a-zA-Z0-9()]{1,6}\b([-a-zA-Z0-9()@:%_\+.~#?&//=]*)/;

// Methods:
const text = "Hello World 123";
const pattern = /\d+/g;

// test() - returns boolean
console.log(pattern.test(text)); // true

// exec() - returns match details
console.log(pattern.exec(text)); // ['123', index: 12, ...]

// match() - string method
console.log(text.match(/\w+/g)); // ['Hello', 'World', '123']

// replace() - string method
console.log(text.replace(/\d+/g, 'NUMBER')); // "Hello World NUMBER"

// split() - string method
console.log(text.split(/\s+/)); // ['Hello', 'World', '123']

// Common patterns:
const patterns = {
    email: /^[^\s@]+@[^\s@]+\.[^\s@]+$/,
    phone: /^\+?[\d\s\-\(\)]+$/,
    creditCard: /^\d{4}[\s\-]?\d{4}[\s\-]?\d{4}[\s\-]?\d{4}$/,
    strongPassword: /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/,
    hexColor: /^#([A-Fa-f0-9]{6}|[A-Fa-f0-9]{3})$/,
    ipAddress: /^(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/
};

// Validation function
function validateInput(input, type) {
    return patterns[type] ? patterns[type].test(input) : false;
}
```

### **46. What is a Set, WeakSet, Map, and WeakMap?**

These are ES6 collection types with different characteristics.

```javascript
// SET - Collection of unique values
const set = new Set();
set.add(1);
set.add(2);
set.add(2); // Duplicate ignored
console.log(set); // Set {1, 2}

// Set methods
console.log(set.has(1)); // true
console.log(set.size); // 2
set.delete(1);
set.clear();

// Array to Set (remove duplicates)
const arr = [1, 2, 2, 3, 3, 4];
const uniqueArr = [...new Set(arr)]; // [1, 2, 3, 4]

// WEAKSET - Collection of objects only, weakly referenced
const weakSet = new WeakSet();
const obj1 = {};
const obj2 = {};

weakSet.add(obj1);
weakSet.add(obj2);
// weakSet.add(1); // TypeError: only objects allowed

console.log(weakSet.has(obj1)); // true
// No size property or iteration

// MAP - Key-value pairs with any type of keys
const map = new Map();
map.set("string", "value");
map.set(1, "number key");
map.set(true, "boolean key");

console.log(map.get("string")); // 'value'
console.log(map.size); // 3

// Iteration
for (let [key, value] of map) {
  console.log(key, value);
}

// WEAKMAP - Like Map but keys must be objects, weakly referenced
const weakMap = new WeakMap();
const keyObj = {};

weakMap.set(keyObj, "associated value");
console.log(weakMap.get(keyObj)); // 'associated value'

// Differences summary:
const comparison = {
  Set: {
    keys: "Any type",
    size: "Available",
    iteration: "Possible",
    garbageCollection: "No automatic cleanup",
  },
  WeakSet: {
    keys: "Objects only",
    size: "Not available",
    iteration: "Not possible",
    garbageCollection: "Automatic cleanup",
  },
  Map: {
    keys: "Any type",
    size: "Available",
    iteration: "Possible",
    garbageCollection: "No automatic cleanup",
  },
  WeakMap: {
    keys: "Objects only",
    size: "Not available",
    iteration: "Not possible",
    garbageCollection: "Automatic cleanup",
  },
};
```

### **47. What are different error handling statements?**

JavaScript provides several mechanisms for error handling.

```javascript
// 1. try...catch...finally
try {
  // Code that might throw an error
  let result = riskyOperation();
  console.log(result);
} catch (error) {
  // Handle the error
  console.error("Error occurred:", error.message);
} finally {
  // Always executed (cleanup code)
  console.log("Cleanup performed");
}

// 2. Throwing custom errors
function validateAge(age) {
  if (age < 0) {
    throw new Error("Age cannot be negative");
  }
  if (age > 150) {
    throw new RangeError("Age seems unrealistic");
  }
  return age;
}

// 3. Error types
try {
  validateAge(-5);
} catch (error) {
  if (error instanceof RangeError) {
    console.log("Range error:", error.message);
  } else if (error instanceof TypeError) {
    console.log("Type error:", error.message);
  } else {
    console.log("General error:", error.message);
  }
}

// 4. Custom Error classes
class ValidationError extends Error {
  constructor(message, field) {
    super(message);
    this.name = "ValidationError";
    this.field = field;
  }
}

class NetworkError extends Error {
  constructor(message, status) {
    super(message);
    this.name = "NetworkError";
    this.status = status;
  }
}

// 5. Async error handling
async function fetchData() {
  try {
    const response = await fetch("/api/data");
    if (!response.ok) {
      throw new NetworkError("Failed to fetch", response.status);
    }
    const data = await response.json();
    return data;
  } catch (error) {
    if (error instanceof NetworkError) {
      console.error("Network issue:", error.status);
    } else {
      console.error("Unexpected error:", error.message);
    }
    throw error; // Re-throw if needed
  }
}

// 6. Promise error handling
promise
  .then((result) => console.log(result))
  .catch((error) => console.error("Promise rejected:", error))
  .finally(() => console.log("Promise settled"));

// 7. Global error handling
window.addEventListener("error", (event) => {
  console.error("Global error:", event.error);
});

window.addEventListener("unhandledrejection", (event) => {
  console.error("Unhandled promise rejection:", event.reason);
  event.preventDefault(); // Prevent default browser behavior
});
```

### **48. What is Babel?**

**Babel** is a JavaScript compiler that transforms modern JavaScript (ES6+) into backward-compatible code.

```javascript
// Modern JavaScript (ES6+)
const greet = (name = 'World') => {
    return `Hello, ${name}!`;
};

const { name, age } = person;
const newArray = [...oldArray, 4, 5, 6];

class Person {
    constructor(name) {
        this.name = name;
    }

    async getData() {
        const response = await fetch('/api/user');
        return response.json();
    }
}

// Babel transforms to (ES5)
var greet = function greet() {
    var name = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : 'World';
    return 'Hello, ' + name + '!';
};

var name = person.name;
var age = person.age;
var newArray = [].concat(oldArray, [4, 5, 6]);

// Babel configuration (.babelrc or babel.config.js)
{
    "presets": [
        ["@babel/preset-env", {
            "targets": {
                "browsers": ["last 2 versions"]
            }
        }]
    ],
    "plugins": [
        "@babel/plugin-proposal-class-properties",
        "@babel/plugin-transform-async-to-generator"
    ]
}

// Common Babel presets:
// @babel/preset-env - Smart preset for modern JS
// @babel/preset-react - For React JSX
// @babel/preset-typescript - For TypeScript

// Babel plugins:
// @babel/plugin-transform-arrow-functions
// @babel/plugin-transform-classes
// @babel/plugin-transform-async-to-generator
// @babel/plugin-proposal-optional-chaining
```

### **49. What are tasks, microtasks, and different event loops?**

Understanding the **event loop** architecture is crucial for JavaScript performance.

```javascript
// Event Loop Components:
// 1. Call Stack
// 2. Web APIs (Browser) / C++ APIs (Node.js)
// 3. Task Queue (Macro Task Queue)
// 4. Microtask Queue
// 5. Event Loop

// MACROTASKS (Task Queue):
console.log("1"); // Synchronous

setTimeout(() => console.log("2"), 0); // Macrotask
setInterval(() => console.log("3"), 100); // Macrotask
setImmediate(() => console.log("4")); // Node.js only

// MICROTASKS (Microtask Queue):
Promise.resolve().then(() => console.log("5")); // Microtask
queueMicrotask(() => console.log("6")); // Microtask

console.log("7"); // Synchronous

// Output: 1, 7, 5, 6, 2, 4, 3

// Event Loop Priority:
// 1. Call Stack (synchronous code)
// 2. Microtask Queue (Promise.then, queueMicrotask)
// 3. Task Queue (setTimeout, setInterval, DOM events)

// Detailed example:
console.log("Start");

setTimeout(() => console.log("Timeout 1"), 0);

Promise.resolve()
  .then(() => {
    console.log("Promise 1");
    return Promise.resolve();
  })
  .then(() => {
    console.log("Promise 2");
  });

setTimeout(() => console.log("Timeout 2"), 0);

queueMicrotask(() => console.log("Microtask"));

console.log("End");

// Output:
// Start
// End
// Promise 1
// Microtask
// Promise 2
// Timeout 1
// Timeout 2

// Different environments:
// Browser: setTimeout, DOM events, HTTP requests
// Node.js: process.nextTick (highest priority), setImmediate
```

### **50. What is the call stack and execution context?**

**Call Stack**: LIFO structure tracking function calls
**Execution Context**: Environment where code is executed

```javascript
// CALL STACK Example
function first() {
  console.log("First function");
  second();
  console.log("First function end");
}

function second() {
  console.log("Second function");
  third();
  console.log("Second function end");
}

function third() {
  console.log("Third function");
}

first();

// Call Stack Flow:
// 1. [global execution context]
// 2. [global, first()]
// 3. [global, first(), second()]
// 4. [global, first(), second(), third()]
// 5. [global, first(), second()] // third() popped
// 6. [global, first()] // second() popped
// 7. [global] // first() popped

// EXECUTION CONTEXT has 3 types:
// 1. Global Execution Context
// 2. Function Execution Context
// 3. Eval Execution Context

// PHASES of Execution Context:
// 1. Creation Phase
//    - Variable Environment
//    - Lexical Environment
//    - this binding
// 2. Execution Phase

function example() {
  var a = 10; // Function scoped
  let b = 20; // Block scoped
  const c = 30; // Block scoped

  function inner() {
    console.log(a, b, c); // Access outer scope
  }

  inner();
}

// Execution Context for example():
// Creation Phase:
// - Variable Environment: { a: undefined }
// - Lexical Environment: { b: <uninitialized>, c: <uninitialized>, inner: <function> }
// - this: global object (or undefined in strict mode)

// Execution Phase:
// - a = 10
// - b = 20
// - c = 30
// - Execute inner()

// LEXICAL SCOPE - where variables are defined determines access
function outer() {
  const outerVar = "I am outer";

  function inner() {
    const innerVar = "I am inner";
    console.log(outerVar); // Can access outer scope

    function deepInner() {
      console.log(innerVar, outerVar); // Can access both
    }

    deepInner();
  }

  inner();
  // console.log(innerVar); // ReferenceError - can't access inner scope
}
```

### **51. How do you redeclare variables in a switch block without an error?**

The issue occurs because `switch` statements create a **single block scope**, causing redeclaration errors.

```javascript
// ❌ Problem: Redeclaration error
function problemExample(value) {
  switch (value) {
    case 1:
      let x = "case 1";
      console.log(x);
      break;
    case 2:
      let x = "case 2"; // SyntaxError: Identifier 'x' has already been declared
      console.log(x);
      break;
  }
}

// ✅ Solution 1: Use block scopes with curly braces
function solution1(value) {
  switch (value) {
    case 1: {
      let x = "case 1";
      console.log(x);
      break;
    }
    case 2: {
      let x = "case 2"; // Now works - different block scope
      console.log(x);
      break;
    }
  }
}

// ✅ Solution 2: Use var (function scoped)
function solution2(value) {
  switch (value) {
    case 1:
      var x = "case 1";
      console.log(x);
      break;
    case 2:
      x = "case 2"; // Reassignment, not redeclaration
      console.log(x);
      break;
  }
}

// ✅ Solution 3: Declare variable outside switch
function solution3(value) {
  let x;
  switch (value) {
    case 1:
      x = "case 1";
      console.log(x);
      break;
    case 2:
      x = "case 2";
      console.log(x);
      break;
  }
}

// ✅ Solution 4: Use different variable names
function solution4(value) {
  switch (value) {
    case 1:
      let result1 = "case 1";
      console.log(result1);
      break;
    case 2:
      let result2 = "case 2";
      console.log(result2);
      break;
  }
}
```

---

## 🔶 **MORE INTERMEDIATE CONCEPTS**

### **52. What is TypeScript and its advantages?**

**TypeScript** is a superset of JavaScript that adds static type checking.

```typescript
// JavaScript vs TypeScript

// JavaScript (runtime errors)
function greet(name) {
  return "Hello " + name.toUpperCase();
}
greet(123); // Runtime error: name.toUpperCase is not a function

// TypeScript (compile-time errors)
function greet(name: string): string {
  return "Hello " + name.toUpperCase();
}
greet(123); // Compile error: Argument of type 'number' is not assignable to parameter of type 'string'

// TypeScript features:
interface User {
  id: number;
  name: string;
  email?: string; // Optional property
}

class UserService {
  private users: User[] = [];

  addUser(user: User): void {
    this.users.push(user);
  }

  findUser(id: number): User | undefined {
    return this.users.find((user) => user.id === id);
  }
}

// Generics
function identity<T>(arg: T): T {
  return arg;
}

// Union types
function format(value: string | number): string {
  return value.toString();
}

// Advantages:
// 1. Early error detection
// 2. Better IDE support (autocomplete, refactoring)
// 3. Self-documenting code
// 4. Easier refactoring
// 5. Better team collaboration
// 6. Gradual adoption (JavaScript is valid TypeScript)
```

### **53. What is V8 JavaScript engine?**

**V8** is Google's open-source JavaScript engine that powers Chrome and Node.js.

```javascript
// V8 Architecture:
// 1. Parser - Converts JavaScript to AST (Abstract Syntax Tree)
// 2. Ignition - Interpreter that generates bytecode
// 3. TurboFan - Optimizing compiler for hot code
// 4. Garbage Collector - Memory management

// V8 Optimization Techniques:

// 1. Hidden Classes (Maps)
function Point(x, y) {
  this.x = x; // Hidden class 1
  this.y = y; // Hidden class 2
}

// Optimized: Same property order
const p1 = new Point(1, 2);
const p2 = new Point(3, 4);

// Deoptimized: Different property order
const p3 = new Point(5, 6);
p3.z = 7; // Changes hidden class, slows access

// 2. Inline Caching
const obj = { a: 1, b: 2 };
function getA(object) {
  return object.a; // V8 caches property location
}

// 3. Just-In-Time (JIT) Compilation
// Hot functions get compiled to optimized machine code

// V8 Memory Management:
// - Young Generation (new objects)
// - Old Generation (long-lived objects)
// - Mark-and-Sweep garbage collection
// - Generational collection

// Performance tips for V8:
// 1. Use consistent object shapes
// 2. Avoid deleting properties
// 3. Use typed arrays for numeric data
// 4. Minimize prototype chain depth
// 5. Use modern JavaScript features (V8 optimizes them)
```

### **54. What are some ES6 features?**

**ES6 (ES2015)** introduced many powerful features to JavaScript.

```javascript
// 1. let and const
let variable = "can change";
const constant = "cannot change";

// 2. Arrow functions
const add = (a, b) => a + b;
const multiply = (a, b) => {
  const result = a * b;
  return result;
};

// 3. Template literals
const name = "John";
const greeting = `Hello, ${name}! Today is ${new Date().toDateString()}`;

// 4. Destructuring
const person = { name: "Alice", age: 30, city: "NYC" };
const { name, age } = person;
const [first, second] = [1, 2, 3];

// 5. Default parameters
function greet(name = "World", greeting = "Hello") {
  return `${greeting}, ${name}!`;
}

// 6. Rest and spread operators
function sum(...numbers) {
  return numbers.reduce((total, num) => total + num, 0);
}
const arr1 = [1, 2, 3];
const arr2 = [...arr1, 4, 5, 6];

// 7. Classes
class Animal {
  constructor(name) {
    this.name = name;
  }

  speak() {
    return `${this.name} makes a sound`;
  }
}

class Dog extends Animal {
  speak() {
    return `${this.name} barks`;
  }
}

// 8. Modules
export const PI = 3.14159;
export default function calculate() {}

// 9. Promises
const promise = new Promise((resolve, reject) => {
  setTimeout(() => resolve("Success!"), 1000);
});

// 10. for...of loop
for (const item of [1, 2, 3]) {
  console.log(item);
}

// 11. Map and Set
const map = new Map();
map.set("key", "value");
const set = new Set([1, 2, 3, 3]); // [1, 2, 3]

// 12. Symbol
const id = Symbol("id");
const obj = { [id]: "unique identifier" };

// 13. Iterators and Generators
function* fibonacci() {
  let [a, b] = [0, 1];
  while (true) {
    yield a;
    [a, b] = [b, a + b];
  }
}

// 14. Proxy
const target = { name: "John" };
const proxy = new Proxy(target, {
  get(obj, prop) {
    console.log(`Accessing ${prop}`);
    return obj[prop];
  },
});
```

### **55. What are typed arrays?**

**Typed Arrays** provide a mechanism for accessing raw binary data efficiently.

```javascript
// Types of Typed Arrays:
// Int8Array, Uint8Array, Uint8ClampedArray
// Int16Array, Uint16Array
// Int32Array, Uint32Array
// Float32Array, Float64Array
// BigInt64Array, BigUint64Array

// Creating typed arrays:
const buffer = new ArrayBuffer(16); // 16 bytes
const int32View = new Int32Array(buffer); // 4 elements (4 bytes each)
const uint8View = new Uint8Array(buffer); // 16 elements (1 byte each)

// Direct creation:
const numbers = new Float32Array([1.1, 2.2, 3.3]);
const bytes = new Uint8Array(8); // 8 zeros

// Working with typed arrays:
numbers[0] = 10.5;
console.log(numbers.length); // 3
console.log(numbers.byteLength); // 12 (3 * 4 bytes)

// ArrayBuffer and views:
const buffer2 = new ArrayBuffer(24);
const idView = new Uint32Array(buffer2, 0, 1); // 1 element at offset 0
const nameView = new Uint8Array(buffer2, 4, 16); // 16 elements at offset 4
const scoreView = new Float32Array(buffer2, 20, 1); // 1 element at offset 20

// Binary data manipulation:
function stringToBytes(str) {
  const bytes = new Uint8Array(str.length);
  for (let i = 0; i < str.length; i++) {
    bytes[i] = str.charCodeAt(i);
  }
  return bytes;
}

function bytesToString(bytes) {
  return Array.from(bytes, (byte) => String.fromCharCode(byte)).join("");
}

// Use cases:
// 1. Image processing
const imageData = new Uint8ClampedArray(width * height * 4); // RGBA

// 2. Audio processing
const audioBuffer = new Float32Array(sampleRate * duration);

// 3. WebGL
const vertices = new Float32Array([-1.0, -1.0, 1.0, -1.0, 0.0, 1.0]);

// 4. File I/O
async function readFile(file) {
  const arrayBuffer = await file.arrayBuffer();
  const bytes = new Uint8Array(arrayBuffer);
  return bytes;
}

// Performance benefits:
// - More efficient memory usage
// - Faster access to binary data
// - Better performance for numeric computations
// - Direct interface with native APIs
```

---

**Good luck with your interview! Focus on understanding concepts rather than memorizing answers. Practice coding problems regularly and be ready to explain your thought process.**
