## 1. What are template literals in JavaScript?

- This template literals feature of ES6
- It way to creating strings that are more flexible and readable than traditional string syntax
- They are enclosed by backticks (`) instead of single (') or double (") quotes and allow for
  - 1.  String Interpolation
  - 2.  Multi-line Strings
  - 3.  Expression Evaluation
  - 4. Tagged Templates

## 2.What is Hoisting?

- Hoisting is a JavaScript mechanism where variables, function declarations and classes are moved to the top of their scope before code execution
- JavaScript does two things during hoisting:
  - Declarations are hoisted.
  - Initializations (assignments) are not hoisted.

```javascript
// What you write
console.log(x); // undefined (not error)
var x = 5;
sayHello(); // "Hello!" (works)

function sayHello() {
  console.log("Hello!");
}

// What JavaScript sees
var x; // hoisted
function sayHello() {
  // hoisted
  console.log("Hello!");
}
console.log(x); // undefined
x = 5;
```
