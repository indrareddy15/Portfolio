function authMiddleware(req, res, next) {
    const authHeader = req.header.authorization;

    if (!authHeader) {
        res.status(401).json({ message: "Indra" })
    }

    const token = authHeader.split("")
    try {
        const secret = ""
        const decode = jwt.verify(token, secret)
        req.user = decode
        next()
    } catch (error) {
        res.status(401).json({ message: "" })
    }
}


const pagination = (arr, pageNumer, pageSize) => {
    const strId = (pageNumer - 1) * pageSize
    const endId = strId + pageSize
    return arr.slice(strId, endId)
}

function debounce(func, delay) {
    let timerId;
    return function (...args) {
        clearTimeout(timerId);
        timerId = setTimeout(() => {
            func.apply(this, args)
        }, delay)
    }
}

function throttling(func, limit) {
    const lastCall = 0
    return function (...args) {
        const now = Date.now()
        if (now - lastCall >= limit) {
            func.apply(this, args)
        }
    }
}

const promise = new Promise((resolve, reject) => {
    let success = true;
    if (success) {
        resolve("Success")
    } else {
        reject("reject")
    }
})

promise.then((res) => {
    console.log(res)
}).catch((err) => {
    console.log(err);
})

const app = async () => {
    const d1 = await fetch("")
    const d2 = await d1.json()
    return d2
}

app()

const testPromise = new Promise((resolve, reject) => {
    let success;
    if (success) {
        resolve
    } else {
        reject
    }
})

testPromise.then((res) => console.log(res)).catch((err) => console.log(err))

function debounce(func, delay) {
    let timer
    return function (...args) {
        clearTimeout(timer)
        timer = setTimeout(() => {
            func.apply(this, args)
        }, delay)
    }
}