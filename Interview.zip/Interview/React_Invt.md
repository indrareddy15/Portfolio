# React Interview Questions

## What is React?

React (aka React.js or ReactJS) is an open-source front-end JavaScript library for building user interfaces based on components.

## What are the major features of React?

- **Component-Based Architecture**
- **Virtual DOM**
- **JSX (JavaScript XML)**
- **Unidirectional Data Flow**
- **Declarative UI**
- **React Hooks**
- **Context API**
- **Error Boundaries**
- **Server-Side Rendering (SSR)**
- **Concurrent Mode**
- **React Server Components**
- **Suspense**

## What are the advantages of React?

- Increases the application's performance with Virtual DOM.
- JSX makes code easy to read and write.
- It renders both on client and server side (SSR).
- Easy to integrate with frameworks (Angular, Backbone) since it is only a view library.
- Easy to write unit and integration tests with tools such as Jest.

## What are the limitations of React?

- React is just a view library, not a full framework.
- There is a learning curve for beginners who are new to web development.
- Integrating React into a traditional MVC framework requires some additional configuration.
- The code complexity increases with inline templating and JSX.
- Too many smaller components leading to over engineering or boilerplate.

## What is JSX?

JSX stands for JavaScript XML and it is an XML-like syntax extension to ECMAScript. Basically it just provides the syntactic sugar for the `React.createElement(type, props, ...children)` function, giving us expressiveness of JavaScript along with HTML like template syntax.

**Note:** JSX is stricter than HTML

## What is the difference between an Element and a Component?

### Element:

- A plain JavaScript object that represents a DOM node or another component.
- Usually via JSX (e.g., `<div>Hello</div>`) or by calling `React.createElement()` directly.
- React elements are immutable. Once created, they cannot be changed.
- They are the building blocks that React uses to create and update the DOM.

### Component:

- A function or class that can return React elements (or other components). It encapsulates logic, state, and UI.
- **Types:**
  - **Functional Component:** A function that returns JSX.
  - **Class Component (legacy):** A class that extends React.Component.
- Components can be reused, composed, and can manage their own state and lifecycle

## How to create components in React?

### 1. Class Components

### 2. Function Components

As we there are two types of the components in React:

### **Class Components**

The class components are a little more complex than the functional components. It requires large boilerplate code. Data can be passed from one class component to another class component.

- Class Components mainly work in Life Cycle Methods
- Class Components start with the keyword "class" and extend to `React.Component`. `React.Component` is the parent class from the React library.

**Methods associated with class-based components:**

- **Constructor:** The constructor method is only required when there is state in the class. It is called when an instance of the component is created. The `super` keyword is used for calling the constructor of the parent class.

- **Why use super?** Inheritance, Accessing

- **Render:** The render method is used to display UI by returning JSX. JSX is JavaScript code template which converts the HTML syntax to React function call. React function calls help to construct the Virtual DOM, which updates the actual DOM and displays it in the UI.

**Example:** This is how a React function call helps to create a virtual DOM

```javascript
// JSX code:
const element = <h1>Hello, world!</h1>;

// After Babel transformation:
const element = React.createElement("h1", null, "Hello, world!");
```

### **Function Components**

You declare a functional component using a JavaScript function. This function returns JSX, JSX stands for JavaScript XML. It allows you to write HTML-like syntax within your JavaScript code. JSX makes your components more readable and maintainable.

## What are Pure Components?

A Pure Component is a React component that renders the same output for the same props and state, and it automatically handles shouldComponentUpdate with a shallow comparison. This can improve performance by preventing unnecessary re-renders.

**Use PureComponent or React.memo when:**

- You have a component that renders the same output given the same props/state.
- Performance is being affected by unnecessary re-renders.
- Props and state are simple (flat, not deeply nested).

## What is state in React?

_(Content to be added)_

## What are props in React?

Props are inputs to components. They are single values or objects containing a set of values that are passed to components on creation similar to HTML-tag attributes.

**The primary purpose of props in React is to provide following component functionality:**

- Pass custom data to your component.
- Trigger state changes.
- Use via `this.props.reactProp` inside component's render() method.

## What are synthetic events in React?

SyntheticEvent is a cross-browser wrapper around the browser's native event like `stopPropagation()` and `preventDefault()`. The native events can be accessed directly from synthetic events using nativeEvent attribute.

**List of common synthetic events are:**

- `onClick`
- `onChange`
- `onSubmit`
- `onKeyDown`, `onKeyUp`
- `onFocus`, `onBlur`
- `onMouseEnter`, `onMouseLeave`
- `onTouchStart`, `onTouchEnd`

## What is "key" prop and what is the benefit of using it in arrays of elements?

A key is a special attribute you should include when mapping over arrays to render data. Key prop helps React identify which items have changed, are added, or are removed.

**Benefits of key:**

- Enables React to efficiently update and re-render components.
- Prevents unnecessary re-renders by reusing components when possible.
- Helps maintain internal state of list items correctly.

## What is Virtual DOM? and How Virtual DOM works?

Virtual DOM is an object-like structure similar to the Actual DOM, but the Virtual DOM is lightweight, in-memory, and easy to manage. It will only contain necessary mapping elements and their CSS.

When it comes to actual DOM manipulation, it is very expensive. Suppose we have many updates or deletions; it becomes an expensive process and will degrade performance. The Virtual DOM is present and the data flow is always in a single direction.

### How Virtual DOM works?

The Virtual DOM works in five simple steps:

1. **Initial Render**
2. **State or Props Change**
3. **Diffing Algorithm**
4. **Reconciliation**
5. **Efficient DOM Updates**

**For Example:**

- Whenever the first state or prop changes, the Virtual DOM will have an exact copy of the actual DOM (V1).
- Then, the next state or prop update occurs. If there are five clicks, all will be merged into one (V2). From here, React undergoes the process called **RECONCILIATION**.
- Reconciliation is the process where the Diffing Algorithm takes place, updating the Actual DOM with the most efficient changes.
- The Diffing Algorithm compares the Virtual DOMs, and based on the comparison, it updates the most efficient one.

## What Are Controlled Components in React?

A controlled component is a component whose form data is fully managed by React through state. In other words, the input values are controlled by React state rather than the DOM (e.g, elements like `<input>`, `<textarea>`, or `<select>`) using React's internal state mechanism.

**Note:** React re-renders the component every time the input value changes.

**When to Use Controlled Components:**

- You need form validation
- You need real-time input processing (e.g. filtering, formatting)
- You want to fully manage form behavior from React state

## What Are Uncontrolled Components in React?

Uncontrolled components are form elements not controlled by React state. Instead, their data is handled directly by the DOM — just like in traditional HTML forms. In other words, the input's value is managed by the browser, and you access it when needed using refs.

**When to Use Uncontrolled Components:**

- You don't need to track input value in real time
- You want simpler form handling (e.g. a quick form submission)
- You're integrating with non-React code or legacy systems

### Comparison Table

| Feature           | **Controlled**                   | **Uncontrolled**                  |
| ----------------- | -------------------------------- | --------------------------------- |
| Value managed by  | React (`useState`)               | DOM (via `ref`)                   |
| Accessing value   | Through state                    | Through `ref.current.value`       |
| Real-time updates | Available                        | Not tracked automatically         |
| Use case          | Dynamic validation, live updates | Simple forms, non-reactive inputs |

## What is Lifting State Up in React?

When two or more components need access to the same piece of state, keeping the state in one of them causes inconsistencies. Instead, move (or "lift") the state up to their common parent, and pass it down via props.

## What are Higher-Order Components?

A Higher-Order Component is a function that takes a component and returns a new component. It promotes code reuse and separation of concerns. Widely used in libraries like Redux (`connect()`), React Router (`withRouter()`), etc.

## What is children prop?

In React, the children prop is a special built-in prop that allows components to receive and render nested content passed between their opening and closing tags.

- `children` is a prop automatically available to every component.
- It contains the nested JSX inside the component's tags.
- It makes components more flexible and composable

## Why React uses className over class attribute?

_(Content to be added)_

## What are portals in React?

_(Content to be added)_

## Why fragments are better than container divs?

- Fragments are a bit faster and use less memory by not creating an extra DOM node. This only has a real benefit on very large and deep trees.
- Some CSS mechanisms like Flexbox and CSS Grid have a special parent-child relationships, and adding divs in the middle makes it hard to keep the desired layout.
- The DOM Inspector is less cluttered.

## What are Stateful vs Stateless Components in React?

- **Stateful Components:** Manage data, handle events, change UI over time.
- **Stateless Components:** Just take inputs (props) and render outputs — no internal data management.

### Comparison Table

| Feature                         | **Stateful Component**                 | **Stateless Component**                |
| ------------------------------- | -------------------------------------- | -------------------------------------- |
| Manages internal state          | ✅ Yes                                 | ❌ No                                  |
| Uses `useState` or `this.state` | ✅ Yes                                 | ❌ No                                  |
| Behavior changes over time      | ✅ Yes                                 | ❌ No (output is fixed based on props) |
| Complexity                      | Higher (logic + UI)                    | Lower (just UI)                        |
| Reusability                     | Less reusable (tied to specific logic) | Highly reusable                        |
| Examples                        | Forms, modals, interactive widgets     | Buttons, labels, pure UI               |
| Also known as                   | **Smart**, **Container Component**     | **Dumb**, **Presentational Component** |

## What is the use of react-dom package?

The react-dom package is a core library in React that provides DOM-specific methods to interact with the browser. While react handles creating components and managing their state/logic, react-dom handles rendering those components to the DOM.

### Common Use Cases of react-dom

| Method                     | Description                                                                                         |
| -------------------------- | --------------------------------------------------------------------------------------------------- |
| `createRoot()` (React 18+) | Creates a root for rendering with **concurrent features**                                           |
| `render()` (pre-React 18)  | Renders a React element into the DOM (deprecated in React 18)                                       |
| `hydrate()`                | Used for **server-side rendering (SSR)** to attach React to existing markup                         |
| `unmountComponentAtNode()` | Removes a mounted React component from the DOM                                                      |
| `findDOMNode()` (legacy)   | Accesses the underlying DOM node (not recommended in modern React)                                  |
| `createPortal()`           | Renders children into a DOM node **outside the parent hierarchy** (used for modals, tooltips, etc.) |

## What are the different ways to style a React component?

### 1. Inline Styles

We can directly style an element using inline style attributes. Make sure the value of style is a JavaScript object.

### 2. CSS Stylesheets

We can create a separate CSS file and write all the styles for the component inside that file. This file needs to be imported inside the component file.

### 3. CSS Modules

We can create a separate CSS module and import this module inside our component. Create a file with ".module.css" extension, e.g., `styles.module.css`.

### 4. Styled Components

### 5. Tailwind CSS (Utility-First Framework)

## What are the Pointer Events supported in React?

- `onPointerDown`
- `onPointerMove`
- `onPointerUp`
- `onPointerCancel`
- `onGotPointerCapture`
- `onLostPointerCapture`
- `onPointerEnter`
- `onPointerLeave`
- `onPointerOver`
- `onPointerOut`

## How to conditionally apply class attributes?

```javascript
<div className={`btn-panel ${this.props.visible ? 'show' : 'hidden'}`}>
```

## What are named export and default export in React?

### Default Export

You can only have one default export per file. It's typically used when a module exports one main thing.

### Named Export

You can export multiple values from a module. Each value must be imported using its exact name (unless renamed with `as`).

## What is the difference between React context and React Redux?

| Feature                | **React Context**                                        | **React Redux**                                             |
| ---------------------- | -------------------------------------------------------- | ----------------------------------------------------------- |
| **Purpose**            | Sharing global data like theme, auth, language           | Managing complex application state with predictable updates |
| **Built-in?**          | Yes (comes with React)                                   | No (external library)                                       |
| **Best for**           | Small to medium-scale apps or non-frequent state updates | Large-scale apps with complex state logic                   |
| **State Updates**      | Triggers re-renders of all consumers                     | Uses selectors to optimize rendering                        |
| **Middleware support** | ❌ Not built-in                                          | ✅ Supports middleware (e.g., redux-thunk, redux-saga)      |
| **DevTools Support**   | ❌ Minimal                                               | ✅ Powerful Redux DevTools                                  |
| **Boilerplate Code**   | ✅ Less                                                  | ❌ More (actions, reducers, store setup)                    |
| **Async Support**      | ❌ Manual (e.g., useEffect)                              | ✅ Built-in with middleware                                 |
| **Performance**        | Can suffer with deeply nested trees or frequent updates  | Highly optimized with memoization and selectors             |
| **Community Support**  | Moderate                                                 | Large and mature ecosystem                                  |

## What are the benefits of using TypeScript with ReactJS?

Below are some of the benefits of using TypeScript with ReactJS:

- It is possible to use the latest JavaScript features
- Use of interfaces for complex type definitions
- IDEs such as VS Code are made for TypeScript
- Avoid bugs with the ease of readability and validation

## What is the difference between useState and useRef hook?

The difference between useState and useRef in React lies in how they store data, trigger re-renders, and their use cases. Both are hooks for managing state-like values, but they behave quite differently.

### useState:

Used to store reactive state — any change will cause the component to re-render. Best for data that affects the UI.

### useRef:

Stores a mutable reference that does not cause re-render when updated. Often used to reference DOM elements or hold persistent values between renders.

### Comparison Table

| Feature                          | `useState`                                 | `useRef`                                              |
| -------------------------------- | ------------------------------------------ | ----------------------------------------------------- |
| **Triggers re-render?**          | ✅ Yes (when state changes)                | ❌ No (changing `.current` does not re-render)        |
| **Stores value across renders?** | ✅ Yes                                     | ✅ Yes                                                |
| **Use case**                     | UI state that affects rendering            | Mutable value that persists, doesn't affect rendering |
| **Type of value**                | Any value (primitives, objects)            | A `.current` object reference                         |
| **Common use cases**             | Form inputs, toggles, counters, UI updates | DOM refs, timers, previous values, mutable flags      |

## What is useLayoutEffect in react?

`useLayoutEffect` is a hook that runs synchronously after all DOM mutations but before the browser paints. It is similar to `useEffect`, but with a key difference in timing.

**Use useLayoutEffect when:**

- You need to read layout or synchronously measure the DOM (e.g. dimensions, scroll position).
- You want to mutate the DOM and avoid flickers before the browser paints.
- You're integrating with non-React libraries that require DOM reads/writes immediately after updates.

## What is useReducer in React?

The `useReducer` hook is a React hook used to manage complex state logic inside functional components. It is conceptually similar to Redux. i.e, Instead of directly updating state like with `useState`, you dispatch an action to a reducer function, and the reducer returns the new state. It's an alternative to `useState`, but more structured similar to how Redux works.

`useReducer` is a React Hook that lets you manage state in a predictable, centralized way, especially when:

- State is complex
- State updates depend on previous state
- You want clear logic separation (like Redux, but local)
- It's inspired by the Redux pattern: dispatching actions to a reducer that updates the state.

## Can you combine useReducer with useContext?

Yes, it's common to combine `useReducer` with `useContext` to build a lightweight state management system similar to Redux.

## How Do You Use useRef to Access a DOM Element in React? Give an example.

The `useRef` hook is commonly used in React to directly reference and interact with DOM elements like focusing an input, scrolling to a section, or controlling media elements.

Take Google browser as an example: Scroll to a specific element, like when you search for some part of the content in the browser and click on it, it will scroll down to that part.

When you assign a ref to a DOM element using `useRef`, React gives you access to the underlying DOM node via the `.current` property of the ref object. `useRef` is used to persist values across renders in React.

**Some of the common use cases are:**

- Automatically focus an input when a component mounts.
- Scroll to a specific element.
- Measure element dimensions (offsetWidth, clientHeight).
- Control video/audio playback.
- Integrate with non-React libraries (like D3 or jQuery).

## Explain about types of Hooks in React.

### Built-in Hooks

The built-in Hooks are divided into 2 parts as given below:

#### 1. Basic Hooks:

- `useState()`
- `useEffect()`
- `useContext()`

#### 2. Additional Hooks:

- `useReducer()`
- `useMemo()`
- `useCallback()`
- `useRef()`
- `useLayoutEffect()`

### 2. Custom Hooks

## Explain Strict Mode in React.

React Strict Mode is a development-only tool that helps you identify potential problems in your React application. It adds extra checks and warnings for its children — but does not render any visible UI and has no effect in production.

## Debounce vs Throttle Comparison Chart

| Feature                         | **Debounce**                                      | **Throttle**                                      |
| ------------------------------- | ------------------------------------------------- | ------------------------------------------------- |
| **When it runs**                | After user stops triggering for `delay` ms        | At most once every `limit` ms                     |
| **Used for**                    | Final action only                                 | Regular interval updates during continuous events |
| **Best for**                    | Search inputs, form validation, window resize end | Scroll animations, tracking, drag/drop            |
| **Ignores intermediate calls?** | Yes                                               | Yes                                               |
| **Timing Control**              | Waits for silence                                 | Fires periodically                                |
