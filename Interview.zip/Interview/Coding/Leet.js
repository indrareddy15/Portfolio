// Two Sum solutions in JavaScript for the main approaches:
// Brute Force (Nested loops)

function twoSum(arr, target) {
    for (let i = 0; i < arr.length; i++) {
        for (let j = i + 1; j < arr.length; j++) {
            if (arr[i] + arr[j] === target) {
                return [i, j]
            }
        }
    }
    return []
}

console.log(twoSum([3, 2, 4], 6));

// Hash Map / Object (Optimal solution)

function twoSumM(arr, target) {
    let nMap = {}

    for (let i = 0; i < arr.length; i++) {
        const comp = target - arr[i]
        if (comp in nMap) {
            return [nMap[comp], i]
        }
        nMap[arr[i]] = i
    }
    return []
}

console.log(twoSumM([3, 2, 4], 6));


// -------------------------------------------------------------------------------------------------

// Maximum Subarray Sum
// Brute Force Approach:

function maxSubArraySum(nums) {
    let maxSum = -Infinity;
    let n = nums.length
    for (let i = 0; i < n; i++) {
        let currSum = 0
        for (let j = i; j < n; j++) {
            currSum += nums[j]
            if (currSum > maxSum) {
                maxSum = currSum
            }
        }
    }
    return maxSum
}

console.log(maxSubArraySum([3, -4, 5, 4, -1, 7, -8]))

// Maximum Sub Array Kadnae's algo
function maxSubKadnaesSum(num) {
    let currSum = 0;
    let maxSum = -Infinity

    for (let i = 0; i < num.length; i++) {
        currSum += num[i]
        maxSum = Math.max(currSum, maxSum)


        if (currSum < 0) {
            currSum = 0
        }
    }
    return maxSum
}

console.log(maxSubKadnaesSum([3, -4, 5, 4, -1, 7, -8]))

// Product of Array Except Self
// Brute Force

function productArray(num) {
    const ans = []

    for (let i = 0; i < num.length; i++) {
        let product = 1
        for (let j = 0; j < num.length; j++) {
            if (i !== j) {
                product *= num[j]
            }
        }
        ans.push(product)
    }
    return ans
}

console.log(productArray([1, 2, 3, 4]))
/// Brute force: O(n²) — because of the nested loops

// Optimal approach
function productArrayO(num) {
    const n = num.length
    const res = []

    let prefix = 1
    for (let i = 0; i < n; i++) {
        res[i] = prefix
        prefix *= num[i]
    }

    let suffix = 1
    for (let i = n - 1; i >= 0; i--) {
        res[i] *= suffix
        suffix *= num[i]
    }
    return res
}

console.log(productArrayO([1, 2, 3, 4]));

// Pow(X,N) Power exponential Problem
// Brute Force
function pow(x, n) {
    if (n === 0) return 1;

    let isNegative = n < 0
    n = Math.abs(n)

    let res = 1;
    for (let i = 0; i <= n; i++) {
        res *= x
    }
    return isNegative ? 1 / res : res
}

console.log(pow(2, 10))
console.log(pow(2, -2))
console.log(pow(5, 3))
console.log(pow(2, 0))
console.log(pow(0.0001, 10000))

// Buy and Sell Stock
// Brute Force

function bestTime(prices) {
    let maxProfit = 0
    let n = prices.length;

    for (let i = 0; i < n; i++) {
        for (let j = i + 1; j < n; j++) {
            const profit = prices[j] - prices[i]

            if (profit > maxProfit) {
                maxProfit = profit
            }
        }
    }
    return maxProfit;
}

console.log(bestTime([7, 1, 5, 3, 6, 4]));

// optimal

function maxProfit(prices) {
    let minPrice = Infinity;
    let maxProfit = 0

    for (let i = 0; i < prices.length; i++) {
        if (prices[i] < minPrice) {
            minPrice = prices[i]
        } else {
            const profit = prices[i] - minPrice
            if (profit > maxProfit) {
                maxProfit = profit
            }
        }
    }
    return maxProfit
}
console.log(maxProfit([7, 1, 5, 3, 6, 4]));

// Container With Most Water
function maxArea(height) {
    let left = 0;
    let right = height.length - 1
    let maxWater = 0

    while (left < right) {
        const width = right - left;
        const currHeight = Math.min(height[left], height[right])
        const currWater = width * currHeight

        maxWater = Math.max(maxWater, currWater)

        if (height[left] < height[right]) {
            left++
        } else {
            right--
        }
    }
    return maxWater
}

console.log(maxArea([1, 8, 6, 2, 5, 4, 8, 3, 7]))

// Valid Palindrome

function isPalindrome(str) {
    let left = 0;
    let right = str.length - 1;

    while (left < right) {
        if (str[left].toLowerCase() !== str[right].toLowerCase()) {
            return false
        }
        left++
        right--
    }
    return true
}

console.log(isPalindrome("A man, a plan, a canal: Panama")); // true
console.log(isPalindrome("race a car")); 