// Find Minimum in Rotated Sorted Array

// Binary Search Approach - Optimal
// Time Complexity: O(log n), Space Complexity: O(1)
function findMin(nums) {
    let left = 0;
    let right = nums.length - 1

    while (left < right) {
        let mid = Math.floor((left + right) / 2)

        if (nums[mid] > nums[right]) {
            left = mid + 1
        } else {
            right = mid
        }
    }
    return nums[left]
}

// Linear Search Approach (for comparison)
// Time Complexity: O(n), Space Complexity: O(1)
function findMinLinear(nums) {
    let min = nums[0]
    for (let i = 1; i < nums.length; i++) {
        if (nums[i] < min) {
            min = nums[i]
        }
    }
    return min
}

// Find minimum with duplicates allowed
// Time Complexity: O(log n) average, O(n) worst case
function findMinWithDuplicates(nums) {
    let left = 0;
    let right = nums.length - 1;

    while (left < right) {
        let mid = Math.floor((left + right) / 2);

        if (nums[mid] > nums[right]) {
            left = mid + 1;
        } else if (nums[mid] < nums[right]) {
            right = mid;
        } else {
            // nums[mid] === nums[right], can't determine which side to go
            right--;
        }
    }
    return nums[left];
}

// Test cases
console.log("Find Min in Rotated Array:", findMin([3, 4, 5, 1, 2]))      // Output: 1
console.log("Find Min in Rotated Array:", findMin([4, 5, 6, 7, 0, 1, 2])) // Output: 0
console.log("Find Min in Rotated Array:", findMin([11, 13, 15, 17]))      // Output: 11
console.log("Find Min Linear:", findMinLinear([1]))                       // Output: 1