// Valid Parentheses

// Stack Approach - Optimal
// Time Complexity: O(n), Space Complexity: O(n)
function isValidParentheses(s) {
    let matched = {
        ")": "(",
        "}": "{",
        "]": "["
    }
    let stack = []

    for (let ch of s) {
        if (ch === "(" || ch === "{" || ch === "[") {
            stack.push(ch)
        } else {
            if (stack.length === 0 || stack.pop() !== matched[ch]) {
                return false
            }
        }
    }
    return stack.length === 0
}

// Alternative implementation with cleaner logic
function isValidParenthesesAlt(s) {
    const stack = []
    const pairs = {
        '(': ')',
        '[': ']',
        '{': '}'
    }

    for (let char of s) {
        if (pairs[char]) {
            // Opening bracket
            stack.push(char)
        } else {
            // Closing bracket
            const last = stack.pop()
            if (pairs[last] !== char) {
                return false
            }
        }
    }

    return stack.length === 0
}

// Counter approach (only works for single type of parentheses)
function isValidSingleType(s) {
    let count = 0

    for (let char of s) {
        if (char === '(') {
            count++
        } else if (char === ')') {
            count--
            if (count < 0) return false
        }
    }

    return count === 0
}

// Test cases
console.log("Valid Parentheses:", isValidParentheses("()"));          // true
console.log("Valid Parentheses:", isValidParentheses("()[]{}"));      // true
console.log("Valid Parentheses:", isValidParentheses("(]"));          // false
console.log("Valid Parentheses:", isValidParentheses("([)]"));        // false
console.log("Valid Parentheses:", isValidParentheses("{[]}"));        // true

console.log("Valid Parentheses Alt:", isValidParenthesesAlt("()"));   // true
console.log("Valid Single Type:", isValidSingleType("(())"));         // true