// Two Sum - Multiple Approaches

// Two Sum - Brute Force Approach
// Time Complexity: O(n²), Space Complexity: O(1)
function twoSumBruteForce(arr, tar) {
    const n = arr.length
    for (let i = 0; i < n; i++) {
        for (let j = i + 1; j < n; j++) {
            if (arr[i] + arr[j] === tar) {
                return [arr[i], arr[j]]
            }
        }
    }
    return []
}

// Two Sum - Hash Map Approach (Optimal)
// Time Complexity: O(n), Space Complexity: O(n)
function twoSumHashMap(arr, tar) {
    let map = new Map()

    for (let i = 0; i < arr.length; i++) {
        let comp = tar - arr[i]

        if (map.has(comp)) {
            return [map.get(comp), i]
        }
        map.set(arr[i], i)
    }
    return []
}

// Two Sum - Two Pointers Approach
// Time Complexity: O(n log n), Space Complexity: O(1)
// Note: This modifies the original array by sorting
function twoSumTwoPointers(arr, tar) {
    arr.sort((a, b) => a - b)
    let left = 0
    let right = arr.length - 1

    while (left < right) {
        let sum = arr[left] + arr[right]

        if (sum === tar) {
            return [arr[left], arr[right]]
        } else if (sum < tar) {
            left++
        } else {
            right--
        }
    }
    return []
}

// Test cases
console.log("Two Sum Brute Force:", twoSumBruteForce([3, 2, 4], 6))
console.log("Two Sum Hash Map:", twoSumHashMap([3, 2, 4], 6))
console.log("Two Sum Two Pointers:", twoSumTwoPointers([3, 2, 4], 6))