// Maximum Subarray Sum (Kadane's Algorithm)

// Brute Force Approach
// Time Complexity: O(n²), Space Complexity: O(1)
function maximumSubarraySumBruteForce(arr) {
    let maxSum = -Infinity
    let n = arr.length

    for (let i = 0; i < n; i++) {
        let currSum = 0;
        for (let j = i; j < n; j++) {
            currSum += arr[j]
            if (currSum > maxSum) {
                maxSum = currSum
            }
        }
    }
    return maxSum
}

// Kadane's Algorithm - Optimal Approach
// Time Complexity: O(n), Space Complexity: O(1)
function maximumSubarraySumKadane(arr) {
    let maxSum = -Infinity
    let currSum = 0
    let n = arr.length

    for (let i = 0; i < n; i++) {
        currSum += arr[i]

        maxSum = Math.max(currSum, maxSum)

        if (currSum < 0) {
            currSum = 0
        }
    }
    return maxSum
}

// Kadane's Algorithm with Subarray indices
// Returns the actual subarray with maximum sum
function maximumSubarrayWithIndices(arr) {
    let maxSum = -Infinity
    let currSum = 0

    let start = 0;
    let maxStart = 0;
    let maxEnd = 0;

    for (let i = 0; i < arr.length; i++) {
        currSum += arr[i]

        if (currSum > maxSum) {
            maxSum = currSum
            maxStart = start
            maxEnd = i
        }

        if (currSum < 0) {
            currSum = 0
            start = i + 1
        }
    }
    return arr.slice(maxStart, maxEnd + 1)
}

// Test cases
console.log("Maximum Subarray Sum - Brute Force:", maximumSubarraySumBruteForce([3, -4, 5, 4, -1, 7, -8]))
console.log("Maximum Subarray Sum - Kadane's:", maximumSubarraySumKadane([3, -4, 5, 4, -1, 7, -8]))
console.log("Maximum Subarray with Indices:", maximumSubarrayWithIndices([-2, 1, -3, 4, -1, 2, 1, -5, 4]))