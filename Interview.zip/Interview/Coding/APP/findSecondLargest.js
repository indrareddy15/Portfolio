// Find Second Largest Element in Array

// Optimal Single Pass Approach
// Time Complexity: O(n), Space Complexity: O(1)
function findSecondLargest(arr) {
    let n = arr.length

    if (n < 2) return null

    let first = -Infinity
    let second = -Infinity

    for (let a of arr) {
        if (a > first) {
            second = first
            first = a
        } else if (a > second && a !== first) {
            second = a
        }
    }
    return second === -Infinity ? null : second
}

// Alternative approach using sorting
// Time Complexity: O(n log n), Space Complexity: O(1)
function findSecondLargestSorting(arr) {
    if (arr.length < 2) return null

    // Remove duplicates and sort in descending order
    const uniqueArr = [...new Set(arr)].sort((a, b) => b - a)

    return uniqueArr.length > 1 ? uniqueArr[1] : null
}

// Test cases
console.log("Find Second Largest:", findSecondLargest([12, 35, 1, 10, 34, 1])); // 34
console.log("Find Second Largest:", findSecondLargest([10, 10, 10])); // null
console.log("Find Second Largest (Sorting):", findSecondLargestSorting([12, 35, 1, 10, 34, 1])); // 34