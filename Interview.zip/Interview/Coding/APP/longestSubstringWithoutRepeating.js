// Longest Substring Without Repeating Characters

// Brute Force Approach
// Time Complexity: O(n³), Space Complexity: O(k) where k is size of character set
function lengthOfLongestSubstringBruteForce(s) {
    let maxLength = 0;

    for (let i = 0; i < s.length; i++) {
        for (let j = i + 1; j <= s.length; j++) {
            const subStr = s.slice(i, j)
            if (allUnique(subStr)) {
                maxLength = Math.max(maxLength, subStr.length)
            }
        }
    }
    return maxLength
}

function allUnique(str) {
    let set = new Set()

    for (let ch of str) {
        if (set.has(ch)) return false
        set.add(ch)
    }
    return true
}

// Sliding Window Approach - Optimal
// Time Complexity: O(n), Space Complexity: O(k) where k is size of character set
function lengthOfLongestSubstringOptimal(s) {
    let maxLength = 0
    let left = 0
    let charSet = new Set()

    for (let right = 0; right < s.length; right++) {
        // If character is already in set, shrink window from left
        while (charSet.has(s[right])) {
            charSet.delete(s[left])
            left++
        }

        charSet.add(s[right])
        maxLength = Math.max(maxLength, right - left + 1)
    }

    return maxLength
}

// Hash Map Approach - Optimized Sliding Window
// Time Complexity: O(n), Space Complexity: O(k)
function lengthOfLongestSubstringHashMap(s) {
    let maxLength = 0
    let left = 0
    let charMap = new Map()

    for (let right = 0; right < s.length; right++) {
        if (charMap.has(s[right]) && charMap.get(s[right]) >= left) {
            left = charMap.get(s[right]) + 1
        }

        charMap.set(s[right], right)
        maxLength = Math.max(maxLength, right - left + 1)
    }

    return maxLength
}

// Test cases
console.log("Longest Substring - Brute Force:", lengthOfLongestSubstringBruteForce("abcabcbb")); // 3
console.log("Longest Substring - Optimal:", lengthOfLongestSubstringOptimal("bbbbb"));           // 1
console.log("Longest Substring - Hash Map:", lengthOfLongestSubstringHashMap("pwwkew"));         // 3