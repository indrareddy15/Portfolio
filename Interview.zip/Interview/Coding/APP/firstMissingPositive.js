// First Missing Positive

// Brute Force Approach
// Time Complexity: O(n²), Space Complexity: O(1)
function firstMissingPositiveBruteForce(nums) {
    let n = nums.length

    for (let i = 1; i <= n + 1; i++) {
        let found = false

        for (let j = 0; j < n; j++) {
            if (nums[j] === i) {
                found = true
                break;
            }
        }

        if (!found) return i
    }
    return n + 1
}

// Hash Set Approach
// Time Complexity: O(n), Space Complexity: O(n)
function firstMissingPositiveHashSet(nums) {
    let set = new Set(nums)
    let i = 1

    while (set.has(i)) {
        i++
    }

    return i
}

// Optimal Approach - Cyclic Sort / Index as Hash
// Time Complexity: O(n), Space Complexity: O(1)
function firstMissingPositiveOptimal(nums) {
    let n = nums.length

    // First pass: place each positive number at its correct position
    for (let i = 0; i < n; i++) {
        while (nums[i] > 0 && nums[i] <= n && nums[nums[i] - 1] !== nums[i]) {
            // Swap nums[i] with nums[nums[i] - 1]
            let temp = nums[nums[i] - 1]
            nums[nums[i] - 1] = nums[i]
            nums[i] = temp
        }
    }

    // Second pass: find the first missing positive
    for (let i = 0; i < n; i++) {
        if (nums[i] !== i + 1) {
            return i + 1
        }
    }

    return n + 1
}

// Alternative optimal approach using array modification
function firstMissingPositiveModification(nums) {
    let n = nums.length

    // Replace all non-positive numbers and numbers > n with n+1
    for (let i = 0; i < n; i++) {
        if (nums[i] <= 0 || nums[i] > n) {
            nums[i] = n + 1
        }
    }

    // Use array indices to mark presence of numbers
    for (let i = 0; i < n; i++) {
        let num = Math.abs(nums[i])
        if (num <= n) {
            nums[num - 1] = -Math.abs(nums[num - 1])
        }
    }

    // Find the first positive number
    for (let i = 0; i < n; i++) {
        if (nums[i] > 0) {
            return i + 1
        }
    }

    return n + 1
}

// Test cases
console.log("First Missing Positive - Brute Force:", firstMissingPositiveBruteForce([1, 2, 0]))      // Output: 3
console.log("First Missing Positive - Hash Set:", firstMissingPositiveHashSet([3, 4, -1, 1]))       // Output: 2
console.log("First Missing Positive - Optimal:", firstMissingPositiveOptimal([7, 8, 9, 11, 12]))    // Output: 1