// Container With Most Water

// Two Pointers Approach - Optimal
// Time Complexity: O(n), Space Complexity: O(1)
function maxArea(height) {
    let left = 0;
    let right = height.length - 1;
    let maxWater = 0

    while (left < right) {
        let width = right - left
        let currHeight = Math.min(height[left], height[right])
        let currWater = width * currHeight

        maxWater = Math.max(currWater, maxWater)

        if (height[left] <= height[right]) {
            left++
        } else {
            right--
        }
    }
    return maxWater
}

// Brute Force Approach (for comparison)
// Time Complexity: O(n²), Space Complexity: O(1)
function maxAreaBruteForce(height) {
    let maxWater = 0
    let n = height.length

    for (let i = 0; i < n; i++) {
        for (let j = i + 1; j < n; j++) {
            let width = j - i
            let currHeight = Math.min(height[i], height[j])
            let currWater = width * currHeight
            maxWater = Math.max(maxWater, currWater)
        }
    }
    return maxWater
}

// Test cases
console.log("Container With Most Water - Optimal:", maxArea([1, 8, 6, 2, 5, 4, 8, 3, 7]))
console.log("Container With Most Water - Brute Force:", maxAreaBruteForce([1, 8, 6, 2, 5, 4, 8, 3, 7]))