// Valid Palindrome

// Optimal Approach - Two Pointers
// Time Complexity: O(n), Space Complexity: O(1)
function isPalindrome(str) {
    let left = 0;
    let right = str.length - 1

    while (left < right) {
        if (str[left].toLowerCase() !== str[right].toLowerCase()) {
            return false
        }
        left++
        right--
    }
    return true
}

// Enhanced version that handles alphanumeric characters only
function isPalindromeAlphanumeric(s) {
    // Clean string: remove non-alphanumeric characters and convert to lowercase
    const cleaned = s.replace(/[^a-zA-Z0-9]/g, '').toLowerCase();

    let left = 0;
    let right = cleaned.length - 1;

    while (left < right) {
        if (cleaned[left] !== cleaned[right]) {
            return false;
        }
        left++;
        right--;
    }
    return true;
}

// Test cases
console.log("Valid Palindrome (basic):", isPalindrome("racecar"))
console.log("Valid Palindrome (alphanumeric):", isPalindromeAlphanumeric("A man, a plan, a canal: Panama"))
console.log("Valid Palindrome (alphanumeric):", isPalindromeAlphanumeric("race a car"))