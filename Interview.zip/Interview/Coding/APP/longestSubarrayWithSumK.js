// Longest Subarray With Sum K

// Brute Force Approach
// Time Complexity: O(n²), Space Complexity: O(1)
function longestSubarrayBruteForce(nums, k) {
    let maxLen = 0;
    let n = nums.length

    for (let i = 0; i < n; i++) {
        let sum = 0;
        for (let j = i; j < n; j++) {
            sum += nums[j]

            if (sum === k) {
                maxLen = Math.max(maxLen, j - i + 1)
            }
        }
    }
    return maxLen
}

// Optimal Approach using Hash Map (for arrays with negative numbers)
// Time Complexity: O(n), Space Complexity: O(n)
function longestSubarrayOptimal(nums, k) {
    let map = new Map()
    let maxLen = 0;
    let sum = 0
    let n = nums.length

    for (let i = 0; i < n; i++) {
        sum += nums[i]

        // Case 1: Exact sum from start
        if (sum === k) {
            maxLen = i + 1
        }

        // Case 2: Subarray found
        if (map.has(sum - k)) {
            maxLen = Math.max(maxLen, i - map.get(sum - k))
        }

        // Store the first occurrence of sum
        if (!map.has(sum)) {
            map.set(sum, i)
        }
    }
    return maxLen
}

// For arrays with only positive numbers - Two Pointers Approach
// Time Complexity: O(n), Space Complexity: O(1)
function longestSubarrayPositive(nums, k) {
    let left = 0, right = 0
    let sum = 0
    let maxLen = 0
    let n = nums.length

    while (right < n) {
        sum += nums[right]

        while (sum > k && left <= right) {
            sum -= nums[left]
            left++
        }

        if (sum === k) {
            maxLen = Math.max(maxLen, right - left + 1)
        }

        right++
    }
    return maxLen
}

// Test cases
console.log("Longest Subarray - Brute Force:", longestSubarrayBruteForce([1, 2, 3, 1, 1, 1, 1], 3))
console.log("Longest Subarray - Optimal:", longestSubarrayOptimal([1, -1, 5, -2, 3], 3))
console.log("Longest Subarray - Positive Only:", longestSubarrayPositive([1, 2, 3, 1, 1, 1, 1], 3))