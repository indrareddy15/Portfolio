// Maximum Product Subarray

// Brute Force Approach
// Time Complexity: O(n²), Space Complexity: O(1)
function maxProductBruteForce(nums) {
    let maxProduct = -Infinity
    let n = nums.length

    for (let i = 0; i < n; i++) {
        let prod = 1;
        for (let j = i; j < n; j++) {
            prod *= nums[j]
            maxProduct = Math.max(maxProduct, prod)
        }
    }
    return maxProduct
}

// Optimal Approach - Modified Kadane's Algorithm
// Time Complexity: O(n), Space Complexity: O(1)
function maxProductOptimal(nums) {
    let maxProduct = nums[0]
    let minProduct = nums[0]
    let result = nums[0]

    for (let i = 1; i < nums.length; i++) {
        // If current number is negative, swap max and min
        if (nums[i] < 0) {
            [maxProduct, minProduct] = [minProduct, maxProduct]
        }

        // Update max and min product ending at current position
        maxProduct = Math.max(nums[i], maxProduct * nums[i])
        minProduct = Math.min(nums[i], minProduct * nums[i])

        // Update global maximum
        result = Math.max(result, maxProduct)
    }

    return result
}

// Alternative approach keeping track of both positive and negative products
function maxProductAlternative(nums) {
    let maxSoFar = nums[0]
    let maxEndingHere = nums[0]
    let minEndingHere = nums[0]

    for (let i = 1; i < nums.length; i++) {
        let temp = maxEndingHere
        maxEndingHere = Math.max(nums[i], Math.max(maxEndingHere * nums[i], minEndingHere * nums[i]))
        minEndingHere = Math.min(nums[i], Math.min(temp * nums[i], minEndingHere * nums[i]))
        maxSoFar = Math.max(maxSoFar, maxEndingHere)
    }

    return maxSoFar
}

// Test cases
console.log("Maximum Product Subarray - Brute Force:", maxProductBruteForce([2, 3, -2, 4]))    // Output: 6
console.log("Maximum Product Subarray - Optimal:", maxProductOptimal([2, 3, -2, 4]))          // Output: 6
console.log("Maximum Product Subarray - Alternative:", maxProductAlternative([-2, 0, -1]))     // Output: 0