// Product of Array Except Self

// Optimal Approach using Left and Right Products
// Time Complexity: O(n), Space Complexity: O(1) excluding output array
function productExceptSelf(nums) {
    let n = nums.length
    let result = []

    // Calculate left products
    let left = 1
    for (let i = 0; i < n; i++) {
        result[i] = left
        left *= nums[i]
    }

    // Calculate right products and multiply with left products
    let right = 1
    for (let i = n - 1; i >= 0; i--) {
        result[i] *= right
        right *= nums[i]
    }
    return result
}

// Brute Force Approach (for comparison)
// Time Complexity: O(n²), Space Complexity: O(1) excluding output array
function productExceptSelfBruteForce(nums) {
    let n = nums.length
    let result = []

    for (let i = 0; i < n; i++) {
        let product = 1
        for (let j = 0; j < n; j++) {
            if (i !== j) {
                product *= nums[j]
            }
        }
        result[i] = product
    }
    return result
}

// Test cases
console.log("Product Except Self - Optimal:", productExceptSelf([1, 2, 3, 4]))
console.log("Product Except Self - Brute Force:", productExceptSelfBruteForce([1, 2, 3, 4]))