// Best Time to Buy and Sell Stock

// Brute Force Approach
// Time Complexity: O(n²), Space Complexity: O(1)
function bestTimeToBuyAndSellStockBruteForce(arr) {
    let n = arr.length
    let maxProfit = 0;

    for (let i = 0; i < n; i++) {
        for (let j = i + 1; j < n; j++) {
            const profit = arr[j] - arr[i]

            if (profit > maxProfit) {
                maxProfit = profit
            }
        }
    }
    return maxProfit
}

// Optimal Approach - Single Pass
// Time Complexity: O(n), Space Complexity: O(1)
function bestTimeToBuyAndSellStockOptimal(arr) {
    let minPrice = Infinity;
    let maxProfit = 0
    let n = arr.length

    for (let i = 0; i < n; i++) {
        if (arr[i] < minPrice) {
            minPrice = arr[i]
        } else {
            let profit = arr[i] - minPrice
            if (profit > maxProfit) {
                maxProfit = profit
            }
        }
    }
    return maxProfit
}

// Test cases
console.log("Best Time to Buy and Sell Stock - Brute Force:", bestTimeToBuyAndSellStockBruteForce([7, 1, 5, 3, 6, 4]))
console.log("Best Time to Buy and Sell Stock - Optimal:", bestTimeToBuyAndSellStockOptimal([7, 1, 5, 3, 6, 4]))