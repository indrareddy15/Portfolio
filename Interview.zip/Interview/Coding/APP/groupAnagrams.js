// Group Anagrams

// Hash Map with Sorted String as Key
// Time Complexity: O(n * k log k), Space Complexity: O(n * k)
// where n is number of strings and k is maximum length of string
function groupAnagrams(strs) {
    const map = new Map()

    for (let word of strs) {
        const sorted = word.split("").sort().join("")

        if (!map.has(sorted)) {
            map.set(sorted, [])
        }

        map.get(sorted).push(word)
    }
    return Array.from(map.values())
}

// Hash Map with Character Count as Key
// Time Complexity: O(n * k), Space Complexity: O(n * k)
function groupAnagramsCharCount(strs) {
    const map = new Map()

    for (let word of strs) {
        const count = new Array(26).fill(0)

        for (let char of word) {
            count[char.charCodeAt(0) - 'a'.charCodeAt(0)]++
        }

        const key = count.join(',')

        if (!map.has(key)) {
            map.set(key, [])
        }

        map.get(key).push(word)
    }

    return Array.from(map.values())
}

// Brute Force Approach (for comparison)
// Time Complexity: O(n² * k log k), Space Complexity: O(n * k)
function groupAnagramsBruteForce(strs) {
    const result = []
    const used = new Array(strs.length).fill(false)

    for (let i = 0; i < strs.length; i++) {
        if (used[i]) continue

        const group = [strs[i]]
        used[i] = true

        for (let j = i + 1; j < strs.length; j++) {
            if (!used[j] && areAnagrams(strs[i], strs[j])) {
                group.push(strs[j])
                used[j] = true
            }
        }

        result.push(group)
    }

    return result
}

function areAnagrams(str1, str2) {
    if (str1.length !== str2.length) return false
    return str1.split('').sort().join('') === str2.split('').sort().join('')
}

// Test cases
const testInput = ["eat", "tea", "tan", "ate", "nat", "bat"]
console.log("Group Anagrams - Sorted Key:", groupAnagrams(testInput))
console.log("Group Anagrams - Char Count:", groupAnagramsCharCount(testInput))
console.log("Group Anagrams - Brute Force:", groupAnagramsBruteForce(testInput))