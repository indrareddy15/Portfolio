// Subarray Sum Equals K

// Brute Force Approach
// Time Complexity: O(n²), Space Complexity: O(1)
function subarraySumBruteForce(nums, k) {
    let count = 0;
    let n = nums.length

    for (let i = 0; i < n; i++) {
        let currSum = 0
        for (let j = i; j < n; j++) {
            currSum += nums[j]

            if (currSum === k) {
                count++
            }
        }
    }
    return count
}

// Optimal Approach using Hash Map
// Time Complexity: O(n), Space Complexity: O(n)
function subarraySumOptimal(nums, k) {
    let count = 0
    let sum = 0
    let map = new Map()
    map.set(0, 1) // Initialize with sum 0 having frequency 1

    for (let num of nums) {
        sum += num

        if (map.has(sum - k)) {
            count += map.get(sum - k)
        }

        map.set(sum, (map.get(sum) || 0) + 1)
    }

    return count
}

// Test cases
console.log("Subarray Sum Equals K - Brute Force:", subarraySumBruteForce([1, 1, 1], 2))
console.log("Subarray Sum Equals K - Optimal:", subarraySumOptimal([1, 1, 1], 2))