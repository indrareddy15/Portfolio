# Coding Problems Collection

This folder contains organized coding problems with multiple solution approaches for each problem.

## Array Problems

### 1. Two Sum (`twoSum.js`)

- **Brute Force**: O(n²) time, O(1) space
- **Hash Map**: O(n) time, O(n) space
- **Two Pointers**: O(n log n) time, O(1) space

### 2. Three Sum (`threeSum.js`)

- **Brute Force**: O(n³) time, O(k) space
- **Hash Map**: O(n²) time, O(n) space

### 3. Best Time to Buy and Sell Stock (`bestTimeToBuyAndSellStock.js`)

- **Brute Force**: O(n²) time, O(1) space
- **Optimal**: O(n) time, O(1) space

### 4. Maximum Subarray Sum (`maximumSubarraySum.js`)

- **Brute Force**: O(n²) time, O(1) space
- **Kadane's Algorithm**: O(n) time, O(1) space
- **With Subarray Indices**: O(n) time, O(1) space

### 5. Find Second Largest (`findSecondLargest.js`)

- **Single Pass**: O(n) time, O(1) space
- **Sorting**: O(n log n) time, O(1) space

### 6. Product Except Self (`productExceptSelf.js`)

- **Optimal**: O(n) time, O(1) space (excluding output)
- **Brute Force**: O(n²) time, O(1) space

### 7. Container With Most Water (`containerWithMostWater.js`)

- **Two Pointers**: O(n) time, O(1) space
- **Brute Force**: O(n²) time, O(1) space

### 8. Contains Duplicate (`containsDuplicate.js`)

- **Hash Set**: O(n) time, O(n) space
- **Sorting**: O(n log n) time, O(1) space
- **Brute Force**: O(n²) time, O(1) space

### 9. Find Min in Rotated Sorted Array (`findMinInRotatedSortedArray.js`)

- **Binary Search**: O(log n) time, O(1) space
- **Linear Search**: O(n) time, O(1) space
- **With Duplicates**: O(log n) average, O(n) worst case

### 10. Maximum Product Subarray (`maximumProductSubarray.js`)

- **Brute Force**: O(n²) time, O(1) space
- **Optimal (Modified Kadane's)**: O(n) time, O(1) space

### 11. First Missing Positive (`firstMissingPositive.js`)

- **Brute Force**: O(n²) time, O(1) space
- **Hash Set**: O(n) time, O(n) space
- **Optimal (Cyclic Sort)**: O(n) time, O(1) space

## Subarray Problems

### 12. Subarray Sum Equals K (`subarraySumEqualsK.js`)

- **Brute Force**: O(n²) time, O(1) space
- **Hash Map**: O(n) time, O(n) space

### 13. Longest Subarray With Sum K (`longestSubarrayWithSumK.js`)

- **Brute Force**: O(n²) time, O(1) space
- **Hash Map**: O(n) time, O(n) space
- **Two Pointers** (positive numbers only): O(n) time, O(1) space

## String Problems

### 14. Valid Palindrome (`validPalindrome.js`)

- **Two Pointers**: O(n) time, O(1) space
- **Alphanumeric Version**: O(n) time, O(1) space

### 15. Longest Substring Without Repeating (`longestSubstringWithoutRepeating.js`)

- **Brute Force**: O(n³) time, O(k) space
- **Sliding Window**: O(n) time, O(k) space
- **Hash Map Optimized**: O(n) time, O(k) space

### 16. Group Anagrams (`groupAnagrams.js`)

- **Sorted Key**: O(n _ k log k) time, O(n _ k) space
- **Character Count**: O(n _ k) time, O(n _ k) space
- **Brute Force**: O(n² _ k log k) time, O(n _ k) space

### 17. Valid Parentheses (`validParentheses.js`)

- **Stack Approach**: O(n) time, O(n) space
- **Alternative Implementation**: O(n) time, O(n) space
- **Counter** (single type only): O(n) time, O(1) space

## Search Problems

### 18. Binary Search (`binarySearch.js`)

- **Standard Binary Search**: O(log n) time, O(1) space
- **Search in Rotated Array**: O(log n) time, O(1) space
- **With Duplicates**: O(log n) average, O(n) worst case

## How to Use

Each file contains:

- Multiple solution approaches with different time/space complexities
- Detailed comments explaining the approach
- Test cases to verify the solutions
- Time and space complexity analysis

Run any file using Node.js:

```bash
node filename.js
```

## Notes

- **Brute Force** solutions are included for learning and comparison purposes
- **Optimal** solutions focus on best time/space complexity
- **Alternative** approaches show different ways to solve the same problem
- All solutions include proper error handling and edge case considerations
