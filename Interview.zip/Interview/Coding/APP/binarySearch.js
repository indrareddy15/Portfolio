// Binary Search and Search in Rotated Sorted Array

// Standard Binary Search
// Time Complexity: O(log n), Space Complexity: O(1)
function binarySearch(nums, target) {
    let left = 0;
    let right = nums.length - 1

    while (left <= right) {
        const mid = Math.floor((left + right) / 2)

        if (nums[mid] === target) {
            return mid
        } else if (nums[mid] < target) {
            left = mid + 1
        } else {
            right = mid - 1
        }
    }
    return -1
}

// Search in Rotated Sorted Array
// Time Complexity: O(log n), Space Complexity: O(1)
function searchInRotatedSortedArray(nums, target) {
    let left = 0;
    let right = nums.length - 1;

    while (left <= right) {
        let mid = Math.floor((left + right) / 2);

        if (nums[mid] === target) {
            return mid;
        }

        // Check if left half is sorted
        if (nums[left] <= nums[mid]) {
            // Target is in left half
            if (nums[left] <= target && target < nums[mid]) {
                right = mid - 1;
            } else {
                left = mid + 1;
            }
        } else {
            // Right half is sorted
            // Target is in right half
            if (nums[mid] < target && target <= nums[right]) {
                left = mid + 1;
            } else {
                right = mid - 1;
            }
        }
    }
    return -1;
}

// Search in Rotated Sorted Array with Duplicates
// Time Complexity: O(log n) average, O(n) worst case
function searchInRotatedSortedArrayWithDuplicates(nums, target) {
    let left = 0;
    let right = nums.length - 1;

    while (left <= right) {
        let mid = Math.floor((left + right) / 2);

        if (nums[mid] === target) {
            return true;
        }

        // Handle duplicates
        if (nums[left] === nums[mid] && nums[mid] === nums[right]) {
            left++;
            right--;
        } else if (nums[left] <= nums[mid]) {
            // Left half is sorted
            if (nums[left] <= target && target < nums[mid]) {
                right = mid - 1;
            } else {
                left = mid + 1;
            }
        } else {
            // Right half is sorted
            if (nums[mid] < target && target <= nums[right]) {
                left = mid + 1;
            } else {
                right = mid - 1;
            }
        }
    }
    return false;
}

// Test cases
console.log("Binary Search:", binarySearch([1, 2, 3, 4, 5, 6], 4)); // Output: 3
console.log("Binary Search:", binarySearch([1, 3, 5, 7, 9], 2));    // Output: -1
console.log("Search in Rotated Array:", searchInRotatedSortedArray([4, 5, 6, 7, 0, 1, 2], 0)); // Output: 4
console.log("Search in Rotated Array:", searchInRotatedSortedArray([4, 5, 6, 7, 0, 1, 2], 3)); // Output: -1