// Contains Duplicate

// Hash Set Approach - Optimal
// Time Complexity: O(n), Space Complexity: O(n)
function containsDuplicate(nums) {
    let set = new Set()

    for (let num of nums) {
        if (set.has(num)) return true
        set.add(num)
    }
    return false
}

// Sorting Approach
// Time Complexity: O(n log n), Space Complexity: O(1)
function containsDuplicateSorting(nums) {
    let n = nums.length
    nums.sort((a, b) => a - b)
    for (let i = 1; i < n; i++) {
        if (nums[i] === nums[i - 1]) return true
    }
    return false
}

// Brute Force Approach (for comparison)
// Time Complexity: O(n²), Space Complexity: O(1)
function containsDuplicateBruteForce(nums) {
    let n = nums.length
    for (let i = 0; i < n; i++) {
        for (let j = i + 1; j < n; j++) {
            if (nums[i] === nums[j]) return true
        }
    }
    return false
}

// Test cases
console.log("Contains Duplicate - Hash Set:", containsDuplicate([1, 2, 3, 1]))
console.log("Contains Duplicate - Sorting:", containsDuplicateSorting([1, 2, 3, 4]))
console.log("Contains Duplicate - Brute Force:", containsDuplicateBruteForce([1, 1, 1, 3, 3, 4, 3, 2, 4, 2]))