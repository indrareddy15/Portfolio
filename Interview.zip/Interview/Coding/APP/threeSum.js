// Three Sum - Multiple Approaches

// Three Sum - Brute Force Approach
// Time Complexity: O(n³), Space Complexity: O(k) where k is number of unique triplets
function threeSumBruteForce(arr) {
    let res = new Set()
    let n = arr.length

    for (let i = 0; i < n; i++) {
        for (let j = i + 1; j < n; j++) {
            for (let k = j + 1; k < n; k++) {
                if (arr[i] + arr[j] + arr[k] === 0) {
                    const triplet = [arr[i], arr[j], arr[k]].sort((a, b) => a - b)
                    res.add(triplet.toString())
                }
            }
        }
    }
    return Array.from(res).map(s => s.split(",").map(Number))
}

// Three Sum - Hash Map Optimized Approach
// Time Complexity: O(n²), Space Complexity: O(n)
function threeSumHashMap(arr) {
    let set = new Set()
    let n = arr.length

    for (let i = 0; i < n; i++) {
        let tar = -arr[i]
        const seen = new Set()

        for (let j = i + 1; j < n; j++) {
            let comp = tar - arr[j]

            if (seen.has(comp)) {
                const triplet = [arr[i], arr[j], comp].sort((a, b) => a - b)
                set.add(triplet.toString())
            }
            seen.add(arr[j])
        }
    }
    return Array.from(set).map(s => s.split(",").map(Number))
}

// Test cases
console.log("Three Sum Brute Force:", threeSumBruteForce([-1, 0, 1, 2, -1, -4]))
console.log("Three Sum Hash Map:", threeSumHashMap([-1, 0, 1, 2, -1, -4]))