// Two Sum
// Brute Force
function twoSumB(arr, tar) {
    const n = arr.length
    for (let i = 0; i < n; i++) {
        for (let j = i + 1; j < n; j++) {
            if (arr[i] + arr[j] === tar) {
                return [arr[i], arr[j]]
            }
        }
    }
    return []
}

console.log("twoSumB", twoSumB([3, 2, 4], 6))

// Better Sol
function twoSumH(arr, tar) {
    let map = new Map()

    for (let i = 0; i < arr.length; i++) {
        let comp = tar - arr[i]

        if (map.has(comp)) {
            return [map.get(comp), i]
        }
        map.set(arr[i], i)
    }
    return []
}

console.log("twoSumH", twoSumH([3, 2, 4], 6))

// Two Sum with two pointers

function twoSumT(arr, tar) {
    arr.sort((a, b) => a - b)
    let left = 0
    let right = arr.length - 1

    while (left < right) {
        let sum = arr[left] + arr[right]

        if (sum === tar) {
            return [arr[left], arr[right]]
        } else if (sum < tar) {
            left++
        } else {
            right--
        }

    }
    return []
}

console.log("twoSumT", twoSumT([3, 2, 4], 6))


// Three Sum
// Brute force
function threeSumB(arr) {
    let res = new Set()
    let n = arr.length

    for (let i = 0; i < n; i++) {
        for (let j = i + 1; j < n; j++) {
            for (let k = j + 1; k < n; k++) {
                if (arr[i] + arr[j] + arr[k] === 0) {
                    const triplet = [arr[i], arr[j], arr[k]].sort((a, b) => a - b)
                    res.add(triplet.toString())
                }
            }
        }
    }
    return Array.from(res).map(s => s.split(",").map(Number))
}

console.log("threeSumB", threeSumB([-1, 0, 1, 2, -1, -4]))

// Optimized threeSum using Hash Map

function threeSumH(arr) {
    let set = new Set()
    let n = arr.length

    for (let i = 0; i < n; i++) {
        let tar = -arr[i]
        const seen = new Set()

        for (let j = i + 1; j < n; j++) {
            let comp = tar - arr[j]

            if (seen.has(comp)) {
                const triplet = [arr[i], arr[j], comp].sort((a, b) => a - b)
                set.add(triplet.toString())
            }
            seen.add(arr[j])
        }
    }
    return Array.from(set).map(s => s.split(",").map(Number))
}

console.log("threeSumHash", threeSumH([-1, 0, 1, 2, -1, -4]));

// Best time to buy and sell the Stock
// brute force
function bestTimeB(arr) {
    let n = arr.length
    let maxProfit = 0;

    for (let i = 0; i < n; i++) {
        for (let j = i + 1; j < n; j++) {
            const profit = arr[j] - arr[i]

            if (profit > maxProfit) {
                maxProfit = profit
            }
        }
    }
    return maxProfit
}

console.log("bestTimeB", bestTimeB([7, 1, 5, 3, 6, 4]));


// Best time to buy and sell the Stock
// Optimal Approach
function bestTimeO(arr) {
    let minPrice = -Infinity;
    let maxProfit = 0
    let n = arr.length

    for (let i = 0; i < n; i++) {
        if (arr[i] < minPrice) {
            minPrice = arr[i]
        } else {
            let profit = arr[i] - minPrice
            if (profit > maxProfit) {
                maxProfit = profit
            }
        }
    }
    return maxProfit
}

// Valid Palindrome
function isPalindromeO(str) {
    let left = 0;
    let right = str.length - 1

    while (left < right) {
        if (str[left].toLowerCase() !== str[right].toLowerCase()) {
            return false
        }
        left++
        right--
    }
    return true
}

// Maximum Subarray sum
// Brute Force
function maximumSubarraySum(arr) {
    let maxSum = -Infinity
    let n = arr.length

    for (let i = 0; i < n; i++) {
        let currSum = 0;
        for (j = i + 1; j < n; j++) {
            currSum += arr[j]
            if (currSum > maxSum) {
                maxSum = currSum
            }
        }
    }
    return maxSum
}
console.log("maximumSubarraySum", maximumSubarraySum([3, -4, 5, 4, -1, 7, -8]))

function maximumSubarraySumK(arr) {
    let maxSum = -Infinity
    let currSum = 0
    let n = arr.length

    for (let i = 0; i < n; i++) {
        currSum += arr[i]

        maxSum = Math.max(currSum, maxSum)

        if (currSum < 0) {
            currSum = 0
        }
    }
    return maxSum
}

console.log("maximumSubarraySumK", maximumSubarraySumK([3, -4, 5, 4, -1, 7, -8]))

// maximumSubarray
function maximumSubarraySumKS(str) {
    let maxSum = -Infinity
    let currSum = 0

    let start = 0;
    let maxStart = 0;
    let maxEnd = 0;

    for (let i = 0; i < str.length; i++) {
        currSum += str[i]

        if (currSum > maxSum) {
            maxSum = currSum
            maxStart = start
            maxEnd = i
        }

        if (currSum < 0) {
            currSum = 0
            start = i + 1
        }
    }
    return str.slice(maxStart, maxEnd + 1)
}

console.log("maximumSubarraySumKS", maximumSubarraySumKS([-2, 1, -3, 4, -1, 2, 1, -5, 4]))

// Find Second Largest Element in Array

function findSecondLargest(arr) {
    let n = arr.length

    if (n < 2) return null

    let first = -Infinity
    let second = -Infinity

    for (let a of arr) {
        if (a > arr) {
            second = first
            first = a
        } else if (a > second && a !== first) {
            second = a
        }
    }
    return second === -Infinity ? null : second
}

console.log("findSecondLargest", findSecondLargest([12, 35, 1, 10, 34, 1])); // 34
console.log("findSecondLargest", findSecondLargest([10, 10, 10])); // null

// Product of Array Except Self
// optimal

function productArray(arr) {
    let n = arr.length
    let ans = []

    let left = 1
    for (let i = 0; i < n; i++) {
        ans[i] = left
        left *= arr[i]
    }

    let right = 1
    for (let i = 0; i < n; i++) {
        ans *= right
        right *= arr[i]
    }
    return res
}

function maxArea(height) {
    let left = 0;
    let right = height.length - 1;
    let maxWater = 0

    while (left < right) {
        let width = right - left
        let currHeight = Math.min(height[left], height[right])
        let currWater = width * currHeight

        maxWater = Math.max(currWater, maxWater)

        if (height[left] <= height[right]) {
            left++
        } else {
            right--
        }
    }
    return maxWater
}

console.log("maxArea", maxArea([1, 8, 6, 2, 5, 4, 8, 3, 7]))


// Count Subarray sum Equals K

function maxSubArraySumK(arr, k) {
    let count = 0;
    let n = arr.length

    for (let i = 0; i < n; i++) {
        let currSum = 0
        for (let j = i; i < n; j++) {
            currSum += arr[j]

            if (currSum === k) {
                count++
            }
        }
    }
    return count
}

// Longest Subarray with sum K

function longestSubarrayBrute(nums, k) {
    let maxLen = 0;
    let n = nums.length

    for (let i = 0; i < n; i++) {
        let sum = 0;
        for (let j = i; j < n; j++) {
            sum += nums[i]

            if (sum === k) {
                maxLen = Math.max(maxLen, j - i + 1)
            }
        }
    }
    return maxLen
}

function longestSubarrayOptimal(nums, k) {
    let map = new Map()
    let maxLen = 0;
    let sum = 0
    let n = nums.length

    for (let i = 0; i < n; i++) {
        sum += nums[i]

        // case: 1 Exact sum start
        if (sum === k) {
            maxLen = i + 1
        }

        // case: 2 sub Array Found
        if (map.has(sum - k)) {
            maxLen = Math.maz(maxLen, i - map.get(sum - k))
        }

        if (!map.has(sum)) {
            map.set(sum, i)
        }
    }
    return maxLen
}

// Maximum Product Subarray

function maxProductBrute(arr) {
    let maxProduct = - Infinity
    let n = arr.length

    for (let i = 0; i < n; i++) {
        let prod = 1;
        for (let j = i; j < n; j++) {
            prod *= arr[j]
            maxProduct = Math.max(maxProduct, prod)
        }
    }
    return maxProduct
}

console.log("maxProductBrute", maxProductBrute([2, 3, -2, 4]));    // Output: 6
console.log("maxProductBrute", maxProductBrute([-2, 0, -1]));      // Output: 0
console.log("maxProductBrute", maxProductBrute([-2, 3, -4]));      // Output: 24

// Contains Duplicates array
function containsDup(nums) {
    let set = new Set()

    for (let num of nums) {
        if (set.has(num)) return true
        set.add(num)
    }
    return false
}
// O(N)

function containsDuplicate(nums) {
    let n = nums.length
    nums.sort((a, b) => a - b)
    for (let i = 1; i < n; i++) {
        if (nums[i] === nums[i - 1]) return ture
    }
    return false
}

// Minimum in Rotated Sorted Array
function findMin(arr) {
    let left = 0;
    let right = arr.length - 1

    while (left < right) {
        let mid = Math.floor((left + right) / 2)

        if (arr[mid] > arr[right]) {
            left = mid + 1
        } else {
            right = mid
        }
    }
    return arr[left]
}

console.log("findMin", findMin([3, 4, 5, 1, 2]));      // Output: 1
console.log("findMin", findMin([4, 5, 6, 7, 0, 1, 2])); // Output: 0
console.log("findMin", findMin([11, 13, 15, 17]));      // Output: 11
console.log("findMin", findMin([1]));


// Search Element in Rotated Sorted Array
function binarySearch(num, tar) {
    let left = 0;
    let right = num.length - 1

    while (left <= right) {
        const mid = Math.floor((left + right) / 2)

        if (num[mid] === tar) {
            return mid
        } else if (num[mid] < tar) {
            left = mid + 1
        } else {
            right = mid - 1
        }
    }
    return -1
}

console.log("binarySearch", binarySearch([1, 2, 3, 4, 5, 6], 4)); // Output: 3
console.log("binarySearch", binarySearch([1, 3, 5, 7, 9], 2));    // Output: -1

// Find the first Missing Postive integer
function firstMissingPositiveBrute(nums) {
    let n = nums.length

    for (let i = 0; i <= n; i++) {
        let found = false

        for (let j = 0; j < n; j++) {
            if (nums[j] === i) {
                found = true
                break;
            }
        }

        if (!found) return i
    }
}

//  Longest Substring Without Repeating Characters

function lengthOfLongestSubstring(s) {
    let maxLength = 0;

    for (let i = 0; i < s.length; i++) {
        for (let j = i + 1; j <= s.length; j++) {
            const subStr = s.slice(i, j)
            if (allUnique(subStr)) {
                maxLength = Math.max(maxLength, subStr.length)
            }
        }
    }
    return maxLength
}

function allUnique(str) {
    let set = new Set()

    for (let ch of str) {
        if (set.has(ch)) return false
        set.add(ch)
    }
    return true
}

console.log("lengthOfLongestSubstring", lengthOfLongestSubstring("abcabcbb")); // 3
console.log("lengthOfLongestSubstring", lengthOfLongestSubstring("bbbbb"));    // 1
console.log("lengthOfLongestSubstring", lengthOfLongestSubstring("pwwkew"));   // 3

// Valid Palindrome
function validPal(str) {
    let left = 0;
    let right = str.length - 1;

    while (left < right) {
        if (str[left].toLowerCase() !== str[right].toLowerCase()) {
            return false
        }
        left++
        right--
    }
    return true
}

console.log("validPal", validPal("A man, a plan, a canal: Panama")); // true
console.log("validPal", validPal("race a car"));

// Group Anagrams
function groupAnagrams(str) {
    const map = new Map()

    for (let word of str) {
        const sorted = word.split("").sort().join("")

        if (map.has(sorted)) {
            map.set(sorted, [])
        }

        map.get(sorted).push(word)
    }
    return Array.from(map.values())
}

function isValidPar(str) {
    let matched = {
        ")": "(",
        "}": "{",
        "]": "["
    }
    let stack = []

    for (let ch of str) {
        if (ch === "(" || ch === "{" || ch === "[") {
            stack.push(ch)
        } else {
            if (stack.length === 0 || stack.pop() !== matched[ch]) {
                return false
            }
        }
    }
    return stack.length === 0
}

console.log("isValidPar", isValidPar("()"));          // true
console.log("isValidPar", isValidPar("()[]{}"));      // true
console.log("isValidPar", isValidPar("(]"));          // false
console.log("isValidPar", isValidPar("([)]"));        // false
console.log("isValidPar", isValidPar("{[]}"));        // true
