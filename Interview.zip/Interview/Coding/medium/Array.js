// Find the Missing Number in an Array

function findMissingNumber(arr) {
    let n = arr.length

    let eSum = (n * (n + 1)) / 2
    let aSum = arr.reduce((sum, num) => sum + num, 0);
    return eSum - aSum
}

console.log(findMissingNumber([3, 0, 1]));     // Output: 2
console.log(findMissingNumber([0, 1]));        // Output: 2
console.log(findMissingNumber([9, 6, 4, 2, 3, 5, 7, 0, 1]));  // Output: 8

// Two Sum
function twoSum(nums, target) {
    for (let i = 0; i < nums.length; i++) {
        for (let j = i + 1; j < nums.length; j++) {
            if (nums[i] + nums[j] === target) {
                return [i, j]
            }
        }
    }
    return []
}

console.log(twoSum([3, 2, 4], 6));