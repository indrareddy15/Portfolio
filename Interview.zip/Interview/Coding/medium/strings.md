# Medium-Level String Questions for Node.js and JavaScript Interviews

1. **Reverse a String**
   - Write a function that takes a string as input and returns the string reversed.

2. **Check for Palindrome**
   - Create a function that checks if a given string is a palindrome (reads the same forwards and backwards).

3. **Count Vowels and Consonants**
   - Write a function that counts the number of vowels and consonants in a given string.

4. **Longest Substring Without Repeating Characters**
   - Given a string, find the length of the longest substring without repeating characters.

5. **String Compression**
   - Implement a function that compresses a string using the counts of repeated characters. For example, "aabcccccaaa" would become "a2b1c5a3".

6. **Find All Anagrams of a String**
   - Write a function that finds all anagrams of a given string from a list of words.

7. **First Non-Repeating Character**
   - Create a function that returns the first non-repeating character in a string. If there is no non-repeating character, return null.

8. **Implement strStr()**
   - Write a function that implements the strStr() method, which locates a substring within a string and returns its index.

9. **Group Anagrams**
   - Given an array of strings, group the anagrams together.

10. **Replace Spaces**
    - Write a function that replaces all spaces in a string with '%20'.