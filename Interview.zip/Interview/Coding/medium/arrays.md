# Medium-Level Array Questions for Node.js and JavaScript Interviews

1. **Find the Missing Number**
   - Given an array containing n distinct numbers taken from 0, 1, 2, ..., n, find the one number that is missing from the array.

2. **Rotate Array**
   - Given an array, rotate the array to the right by k steps, where k is non-negative.

3. **Two Sum**
   - Given an array of integers, return indices of the two numbers such that they add up to a specific target.

4. **Group Anagrams**
   - Given an array of strings, group the anagrams together.

5. **Product of Array Except Self**
   - Given an array of integers, return an array such that output[i] is equal to the product of all the numbers in the input array except input[i].

6. **Maximum Subarray**
   - Find the contiguous subarray (containing at least one number) which has the largest sum and return its sum.

7. **Longest Consecutive Sequence**
   - Given an unsorted array of integers, find the length of the longest consecutive elements sequence.

8. **3Sum**
   - Given an array of integers, find all the triplets [nums[i], nums[j], nums[k]] such that i != j, i != k, and j != k, and nums[i] + nums[j] + nums[k] == 0.

9. **Container With Most Water**
   - Given n non-negative integers a1, a2, ..., an, where each represents a point at coordinate (i, ai). n vertical lines are drawn such that the two endpoints of line i is at (i, ai) and (i, 0). Find two lines, which together with the x-axis forms a container, such that the container contains the most water.

10. **Find All Duplicates in an Array**
    - Given an integer array nums, you can assume each element in the array is between 1 and n (inclusive), where n is the size of the array. Find all the elements of nums that appear more than once.