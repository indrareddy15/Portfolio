# Easy String Questions for Node.js and JavaScript Interviews

1. **Reverse a String**
   - Write a function that takes a string as input and returns the string reversed.

2. **Check for Palindrome**
   - Create a function that checks if a given string is a palindrome (reads the same forwards and backwards).

3. **Count Vowels**
   - Write a function that counts the number of vowels in a given string.

4. **Remove Duplicates**
   - Implement a function that removes duplicate characters from a string.

5. **Find the First Non-Repeating Character**
   - Write a function that returns the first non-repeating character in a string.

6. **Convert to Title Case**
   - Create a function that converts a string to title case (the first letter of each word is capitalized).

7. **Check if Two Strings are Anagrams**
   - Write a function that checks if two strings are anagrams of each other.

8. **Count the Number of Words**
   - Implement a function that counts the number of words in a given string.

9. **String Compression**
   - Write a function that compresses a string using the counts of repeated characters.

10. **Find the Longest Substring Without Repeating Characters**
    - Create a function that finds the length of the longest substring without repeating characters.