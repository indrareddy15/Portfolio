// Reverse a String**

function rvsStr(str) {
    return str.split('').reverse().join("")
}

const input = "hello";
const reversed = rvsStr(input);
console.log(reversed);

function ReverseStr(str) {
    let rvsStr = ""
    for (let i = str.length - 1; i >= 0; i--) {
        rvsStr += str[i]
    }
    return rvsStr
}

const input1 = "Indra";
const reversed1 = ReverseStr(input1);
console.log(reversed1);

// isPalindrome

function isPalindrome(str) {
    let rStr = str.split("").reverse().join("")
    if (str === rStr) {
        return true
    } else {
        return false
    }
}

const input3 = "malayalam";
const result = isPalindrome(input3);
console.log(result);  // true

// 3. **Count Vowels**
function countVowels(str) {
    let v = "aeiouAEIOU"
    let count = 0;

    for (let i = 0; i < str.length; i++) {
        if (v.indexOf(str[i]) !== -1) {
            count++
        }
    }
    return count;
}

const input4 = "Hello, World!";
const result1 = countVowels(input4);
console.log("countVowels", result1);

function removeDuplicates(str) {
    let res = "";
    for (let i = 0; i < str.length; i++) {
        if (!res.includes(str[i])) {
            res += str[i]
        }
    }
    return res;
}

const strs = "aabbccddeeff";
const res = removeDuplicates(strs);
console.log("removeDuplicates", res);  // "abcdef"

// Convert to Title Case

function toTitleCase(str) {
    return str.toLowerCase().split(" ").map((item) => item.charAt(0).toUpperCase() + item.slice(1)).join(" ")
}

const rervs = "this is a sample STRING";
const title = toTitleCase(rervs);
console.log("toTitleCase", title);


// Check if Two Strings are Anagrams
function areAnagrams(str1, str2) {
    const Anagrams = (str) => {
        return str.toLowerCase().split("").sort().join("")
    }

    if (Anagrams(str1) === Anagrams(str2)) {
        return true
    } else {
        return false
    }
}

console.log(areAnagrams("Listen", "Silent"));       // true
console.log(areAnagrams("Hello", "Olelh"));         // true
console.log(areAnagrams("Apple", "Pabble"));

// Count the Number of Words
function countWords(str) {
    return str.trim().split(" ").filter((w) => w.length > 0).length
}

const sentence = "Hello, how are you doing today?";
console.log(countWords(sentence))

// String Compression
function compressString(str) {
    if (str.length === 0) return "";
    let commpresedStr = ""
    let count = 1

    for (let i = 1; i <= str.length; i++) {
        if (str[i] === str[i - 1]) {
            count++
        } else {
            commpresedStr += str[i - 1] + count
            count = 1
        }
    }
    return commpresedStr
}

console.log(compressString("aaabbc"));  // Output: "a3b2c1"
console.log(compressString("abcd")); 