# Easy Array Questions for Node.js and JavaScript Interviews

1. **Find the Maximum Element in an Array**
   - Write a function that takes an array of numbers and returns the maximum element.

2. **Reverse an Array**
   - Implement a function that reverses an array without using the built-in reverse method.

3. **Check if an Array Contains a Specific Element**
   - Create a function that checks if a given element exists in an array.

4. **Merge Two Arrays**
   - Write a function that merges two arrays into one, without duplicates.

5. **Find the Length of an Array**
   - Implement a function that returns the length of an array without using the built-in length property.

6. **Remove Duplicates from an Array**
   - Write a function that removes duplicate values from an array.

7. **Sum of All Elements in an Array**
   - Create a function that returns the sum of all elements in an array.

8. **Find the Index of an Element**
   - Implement a function that returns the index of a specific element in an array, or -1 if it does not exist.

9. **Rotate an Array**
   - Write a function that rotates an array to the right by a given number of steps.

10. **Flatten a Nested Array**
    - Create a function that flattens a nested array into a single-level array.