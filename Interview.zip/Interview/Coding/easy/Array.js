// Find the Maximum Element in an Array
function MaxEle(arr) {
    if (arr.length === 0) return undefined

    let maxEle = arr[0]
    for (let i = 0; i < arr.length; i++) {
        if (arr[i] > maxEle) {
            maxEle = arr[i]
        }
    }
    return maxEle;
}

const arr = [3, 5, 7, 2, 8, 4];
// const res = Math.max(...arr)
// console.log(res);

const result = MaxEle(arr);
console.log("Maximum element:", result);



// Reverse an Array


function reverseArray(arr) {
    return arr.reverse(); // This method reverses the array in place
}


function RevArr(arr) {
    let start = 0;
    let end = arr.length - 1

    while (start < end) {
        let temp = arr[start]
        arr[start] = arr[end]
        arr[end] = temp

        start++
        end--
    }
    return arr
}

const arr1 = [3, 5, 7, 2, 8, 4];
const reversedArr = RevArr(arr1);
console.log("Reversed array:", reversedArr);

// Check if an Array Contains a Specific Element

// using include
function containsElement(arr, element) {
    return arr.includes(element);
}

// using indexOf
function containsElement(arr, element) {
    return arr.indexOf(element) !== -1;
}

// using find()
function containsElement(arr, element) {
    return arr.find((item) => item === element) !== undefined
}

// MERGE two arrays
// Summary:
// concat() is the most straightforward and immutable approach for merging arrays.
// Spread operator (...) is a modern, clean way to merge arrays and also immutable.
// push() with spread operator modifies the first array in place.
// forEach() allows for more custom logic when merging arrays
function M1arr(arr1, arr2) {
    return arr1.concat(arr2)
}

function M1arr(arr1, arr2) {
    return [...arr1, arr2]
}

function M1arr(arr1, arr2) {
    arr1.push(arr2)
    return arr1
}

function M1arr(arr1, arr2) {
    arr2.forEach((item) => arr1.push(item))
    return arr1
}

// Remove Duplicates from an Array
function removeDuplicates(arr) {
    return [...new Set(arr)]
}


function removeDuplicates(arr) {
    const seen = new Set()
    const res = []

    for (let i = 0; i < arr.length; i++) {
        if (!seen.has(arr[i])) {
            res.push(arr[i])
            seen.add(arr[i])
        }
    }
    return res
}

const arr2 = [1, 2, 2, 3, 4, 4, 5];
const uniqueArr = removeDuplicates(arr2);
console.log("removeDuplicates", uniqueArr); // [1, 2, 3, 4, 5]

//Sum of All Elements in an Array

function SumEle(arr) {
    let sum = 0;
    for (let i = 0; i < arr.length; i++) {
        sum += arr[i]
    }
    return sum
}

function SumEle1(arr) {
    return arr.reduce((sum, curr) => sum + curr, 0)
}

const arr3 = [1, 2, 3, 4, 5];
const sum = SumEle(arr3);
const sum1 = SumEle1(arr3);
console.log("sumArray", sum1);

// Rotate an Array 
function rotateLeftByOne(arr) {
    const firstEle = arr.shift();
    arr.push(firstEle)
    return arr
}

const arr4 = [1, 2, 3, 4, 5];
const rotatedArr = rotateLeftByOne(arr4);
console.log("rotateLeftByOne", rotatedArr);

function rotateRightByOne(arr) {
    const lastEle = arr.pop()
    arr.unshift(lastEle)
    return arr
}
const arr5 = [1, 2, 3, 4, 5];
const rotatedArr1 = rotateRightByOne(arr5);
console.log("rotateLeftByOne", rotatedArr1);

// Flatten a Nested Array

function flattenArray(arr) {
    let res = []
    for (let i = 0; i < arr.length; i++) {
        if (Array.isArray(arr[i])) {
            res = res.concat(flattenArray(arr[i]))
        } else {
            res.push(arr[i])
        }
    }
    return res
}

const arr6 = [1, [2, 3], [4, [5, [6]]]];
const flattenedArr = flattenArray(arr6);
console.log("flattenArray", flattenedArr);