# Hard-Level Array Questions for Node.js and JavaScript Interviews

1. **Find the Longest Consecutive Sequence**
   - Given an unsorted array of integers, find the length of the longest consecutive elements sequence.

2. **Median of Two Sorted Arrays**
   - Given two sorted arrays, find the median of the two sorted arrays. The overall run time complexity should be O(log (m+n)).

3. **3Sum**
   - Given an array of integers, find all the triplets that sum up to zero.

4. **Container With Most Water**
   - Given n non-negative integers a1, a2, ..., an, where each represents a point at coordinate (i, ai). n vertical lines are drawn such that the two endpoints of line i is at (i, ai) and (i, 0). Find two lines, which together with the x-axis forms a container, such that the container contains the most water.

5. **Product of Array Except Self**
   - Given an array nums of n integers where n > 1, return an array output such that output[i] is equal to the product of all the elements of nums except nums[i].

6. **Maximum Product Subarray**
   - Given an integer array nums, find a contiguous non-empty subarray within the array which has the largest product, and return the product.

7. **Longest Substring with At Most K Distinct Characters**
   - Given a string, find the length of the longest substring T that contains at most k distinct characters.

8. **Kth Largest Element in an Array**
   - Find the kth largest element in an unsorted array. Note that it is the kth largest element in the sorted order, not the kth distinct element.

9. **Subarray Sum Equals K**
   - Given an array of integers and an integer k, you need to find the total number of continuous subarrays whose sum equals to k.

10. **Sliding Window Maximum**
    - Given an array nums and a sliding window size k, return the maximum value in each sliding window.