# Hard-Level String Questions for Node.js and JavaScript Interviews

1. **Longest Palindromic Substring**
   - Given a string, find the longest substring that is a palindrome.

2. **Group Anagrams**
   - Given an array of strings, group the anagrams together.

3. **Minimum Window Substring**
   - Given two strings, find the minimum window substring of `s` that contains all the characters of `t`.

4. **Valid Parentheses**
   - Given a string containing just the characters '(', ')', '{', '}', '[' and ']', determine if the input string is valid.

5. **String to Integer (atoi)**
   - Implement the `myAtoi(string s)` function, which converts a string to a 32-bit signed integer.

6. **Word Break II**
   - Given a string and a dictionary of words, return all possible sentences that can be formed by segmenting the string into words from the dictionary.

7. **Longest Repeating Character Replacement**
   - Given a string, you can replace any character with another character. Find the length of the longest substring that can be formed after performing at most `k` replacements.

8. **Count and Say**
   - The count-and-say sequence is a sequence of digit strings defined by the recursive formula. Given an integer `n`, generate the `n`th term of the count-and-say sequence.

9. **Regular Expression Matching**
   - Implement regular expression matching with support for `.` and `*`.

10. **Text Justification**
    - Given an array of strings and a maximum line width, format the text such that each line has exactly `maxWidth` characters.

These questions are designed to test your understanding of string manipulation and algorithmic problem-solving skills in JavaScript and Node.js.