# JavaScript Interview Questions & Answers - Part 3.1 (Basic Concepts)

_Fundamental JavaScript concepts essential for all developers_

---

## 🔷 **BASIC CONCEPTS**

### **33. What are the different data types in JavaScript?**

JavaScript has **8 data types** divided into two categories:

**Primitive Types (7):**

- Number, String, Boolean, Undefined, Null, Symbol, BigInt

**Non-Primitive Types (1):**

- Object (includes arrays, functions, dates, etc.)

```javascript
// PRIMITIVE TYPES

// 1. Number
let integer = 42;
let float = 3.14;
let negative = -10;
let infinity = Infinity;
let notANumber = NaN;

console.log(typeof 42); // 'number'
console.log(Number.MAX_VALUE); // 1.7976931348623157e+308
console.log(Number.MIN_VALUE); // 5e-324

// 2. String
let singleQuote = "Hello";
let doubleQuote = "World";
let templateLiteral = `Hello ${singleQuote}`;
let multiLine = `Line 1
Line 2`;

console.log(typeof "hello"); // 'string'

// 3. Boolean
let isTrue = true;
let isFalse = false;

console.log(typeof true); // 'boolean'

// 4. Undefined
let notDefined;
let explicitUndefined = undefined;

console.log(typeof undefined); // 'undefined'

// 5. Null
let emptyValue = null;

console.log(typeof null); // 'object' (known bug in JavaScript)

// 6. Symbol (ES6)
let symbol1 = Symbol("description");
let symbol2 = Symbol("description");

console.log(symbol1 === symbol2); // false (each symbol is unique)
console.log(typeof symbol1); // 'symbol'

// 7. BigInt (ES2020)
let bigNumber = 123456789012345678901234567890n;
let bigInt = BigInt("123456789012345678901234567890");

console.log(typeof bigNumber); // 'bigint'

// NON-PRIMITIVE TYPE

// Object
let person = { name: "John", age: 30 };
let array = [1, 2, 3, 4, 5];
let func = function () {
  return "Hello";
};
let date = new Date();
let regex = /pattern/;

console.log(typeof person); // 'object'
console.log(typeof array); // 'object'
console.log(typeof func); // 'function'
console.log(typeof date); // 'object'
console.log(typeof regex); // 'object'

// Checking specific object types
console.log(Array.isArray(array)); // true
console.log(date instanceof Date); // true
console.log(regex instanceof RegExp); // true
```

### **34. What are primitive and non-primitive data types?**

| **Primitive**   | **Non-Primitive**   |
| --------------- | ------------------- |
| Stored by value | Stored by reference |
| Immutable       | Mutable             |
| Fixed size      | Dynamic size        |
| Stack memory    | Heap memory         |

```javascript
// PRIMITIVE DATA TYPES (Pass by Value)
let a = 10;
let b = a; // Copy of value
a = 20;
console.log(a); // 20
console.log(b); // 10 (unchanged)

// String immutability
let str = "hello";
str[0] = "H"; // This doesn't change the string
console.log(str); // 'hello' (unchanged)

let newStr = str.toUpperCase(); // Returns new string
console.log(str); // 'hello' (original unchanged)
console.log(newStr); // 'HELLO'

// NON-PRIMITIVE DATA TYPES (Pass by Reference)
let obj1 = { name: "John" };
let obj2 = obj1; // Copy of reference, not value
obj1.name = "Jane";
console.log(obj1.name); // 'Jane'
console.log(obj2.name); // 'Jane' (both changed)

// Array mutability
let arr1 = [1, 2, 3];
let arr2 = arr1; // Reference copy
arr1.push(4);
console.log(arr1); // [1, 2, 3, 4]
console.log(arr2); // [1, 2, 3, 4] (both changed)

// Creating true copies
let originalObj = { name: "John", age: 30 };

// Shallow copy
let shallowCopy = { ...originalObj };
let shallowCopy2 = Object.assign({}, originalObj);

// Deep copy (for simple objects)
let deepCopy = JSON.parse(JSON.stringify(originalObj));

// Memory allocation differences
// Primitives: Stack (faster access, limited size)
// Objects: Heap (slower access, dynamic size)

// Type checking
function checkType(value) {
  if (value === null) return "null";
  if (Array.isArray(value)) return "array";
  if (value instanceof Date) return "date";
  if (value instanceof RegExp) return "regexp";
  return typeof value;
}

console.log(checkType(42)); // 'number'
console.log(checkType([])); // 'array'
console.log(checkType(null)); // 'null'
console.log(checkType(new Date())); // 'date'
```

### **35. What is the difference between == and === operators?**

| `==` (Loose Equality)            | `===` (Strict Equality) |
| -------------------------------- | ----------------------- |
| Performs type coercion           | No type coercion        |
| Compares values after conversion | Compares type and value |
| Can be unpredictable             | Predictable behavior    |

```javascript
// LOOSE EQUALITY (==) - Type Coercion
console.log(5 == "5"); // true (string converted to number)
console.log(true == 1); // true (boolean converted to number)
console.log(false == 0); // true (boolean converted to number)
console.log(null == undefined); // true (special case)
console.log("" == 0); // true (empty string converted to 0)
console.log(" " == 0); // true (whitespace string converted to 0)
console.log([] == 0); // true (empty array converted to 0)
console.log([1] == 1); // true (array with one element)

// STRICT EQUALITY (===) - No Type Coercion
console.log(5 === "5"); // false (different types)
console.log(true === 1); // false (different types)
console.log(false === 0); // false (different types)
console.log(null === undefined); // false (different types)
console.log("" === 0); // false (different types)
console.log([] === 0); // false (different types)

// Complex coercion examples with ==
console.log(0 == false); // true
console.log(0 == ""); // true
console.log(0 == []); // true
console.log(false == ""); // true
console.log(false == []); // true
console.log("" == []); // true

// Unexpected behavior with ==
console.log("0" == false); // true
console.log("0" == 0); // true
console.log(false == 0); // true
// But: false != '0' directly through ==

// Object comparison (both == and ===)
let obj1 = { name: "John" };
let obj2 = { name: "John" };
let obj3 = obj1;

console.log(obj1 == obj2); // false (different objects)
console.log(obj1 === obj2); // false (different objects)
console.log(obj1 == obj3); // true (same reference)
console.log(obj1 === obj3); // true (same reference)

// Array comparison
let arr1 = [1, 2, 3];
let arr2 = [1, 2, 3];
console.log(arr1 == arr2); // false (different arrays)
console.log(arr1 === arr2); // false (different arrays)

// NaN comparison (special case)
console.log(NaN == NaN); // false
console.log(NaN === NaN); // false
console.log(Number.isNaN(NaN)); // true (correct way to check)

// Best practices
function safeEqual(a, b) {
  // Handle NaN case
  if (Number.isNaN(a) && Number.isNaN(b)) {
    return true;
  }
  return a === b;
}

// When to use each:
// Use === (strict) in most cases
// Use == only when you specifically need type coercion
// Example: checking for null or undefined
function isNullOrUndefined(value) {
  return value == null; // Checks for both null and undefined
  // Equivalent to: value === null || value === undefined
}
```

### **36. What is the difference between null and undefined?**

| `null`                        | `undefined`                        |
| ----------------------------- | ---------------------------------- |
| Intentional absence of value  | Variable declared but not assigned |
| Explicitly assigned           | Default value                      |
| Primitive value               | Primitive value                    |
| typeof returns 'object' (bug) | typeof returns 'undefined'         |

```javascript
// UNDEFINED - Variable declared but not assigned
let notAssigned;
console.log(notAssigned); // undefined
console.log(typeof notAssigned); // 'undefined'

// Function with no return value
function noReturn() {
  // No return statement
}
console.log(noReturn()); // undefined

// Object property that doesn't exist
let obj = { name: "John" };
console.log(obj.age); // undefined

// Array element that doesn't exist
let arr = [1, 2, 3];
console.log(arr[10]); // undefined

// Function parameter not provided
function greet(name) {
  console.log(name); // undefined if not provided
}
greet(); // undefined

// NULL - Intentional absence of value
let intentionallyEmpty = null;
console.log(intentionallyEmpty); // null
console.log(typeof intentionallyEmpty); // 'object' (known JavaScript bug)

// Common use cases for null
let user = null; // No user logged in
let data = null; // No data loaded yet
let result = null; // Reset a variable

// Comparison behavior
console.log(null == undefined); // true (loose equality)
console.log(null === undefined); // false (strict equality)

console.log(null == 0); // false
console.log(null === 0); // false
console.log(undefined == 0); // false
console.log(undefined === 0); // false

// Falsy behavior
console.log(Boolean(null)); // false
console.log(Boolean(undefined)); // false

if (null) {
  console.log("This will not run");
}

if (undefined) {
  console.log("This will not run");
}

// Checking for null vs undefined
function checkValue(value) {
  if (value === null) {
    return "Value is null";
  } else if (value === undefined) {
    return "Value is undefined";
  } else if (value == null) {
    return "Value is null or undefined";
  } else {
    return "Value exists";
  }
}

// Practical examples
function processUser(user) {
  // Check if user exists
  if (user == null) {
    // Checks for both null and undefined
    return "No user provided";
  }

  // Check specific properties
  if (user.email === undefined) {
    return "Email not provided";
  }

  if (user.profile === null) {
    return "Profile explicitly removed";
  }

  return "User is valid";
}

// Default parameter handling
function createUser(name = "Anonymous", email = null) {
  return {
    name,
    email,
    id: Math.random(),
  };
}

// Nullish coalescing operator (??) - ES2020
let username = null;
let displayName = username ?? "Guest"; // 'Guest'

let userAge = undefined;
let age = userAge ?? 18; // 18

let userScore = 0;
let score = userScore ?? 100; // 0 (falsy but not nullish)

// Optional chaining with null/undefined
let userProfile = {
  name: "John",
  address: null,
};

console.log(userProfile?.address?.street); // undefined (safe access)
console.log(userProfile?.phone?.number); // undefined (safe access)
```

### **37. What is Object Destructuring?**

**Object destructuring** allows extracting properties from objects and binding them to variables.

```javascript
// BASIC OBJECT DESTRUCTURING
const person = {
  firstName: "John",
  lastName: "Doe",
  age: 30,
  city: "New York",
};

// Extract properties
const { firstName, lastName, age } = person;
console.log(firstName); // 'John'
console.log(lastName); // 'Doe'
console.log(age); // 30

// RENAMING VARIABLES
const { firstName: fName, lastName: lName } = person;
console.log(fName); // 'John'
console.log(lName); // 'Doe'

// DEFAULT VALUES
const { firstName, lastName, country = "USA" } = person;
console.log(country); // 'USA' (default value)

const { nonExistent = "Default" } = person;
console.log(nonExistent); // 'Default'

// NESTED DESTRUCTURING
const user = {
  id: 1,
  profile: {
    name: "Alice",
    contact: {
      email: "alice@example.com",
      phone: "123-456-7890",
    },
  },
  preferences: {
    theme: "dark",
    language: "en",
  },
};

const {
  profile: {
    name,
    contact: { email, phone },
  },
  preferences: { theme },
} = user;

console.log(name); // 'Alice'
console.log(email); // 'alice@example.com'
console.log(theme); // 'dark'

// ARRAY DESTRUCTURING
const numbers = [1, 2, 3, 4, 5];

// Basic array destructuring
const [first, second, third] = numbers;
console.log(first); // 1
console.log(second); // 2
console.log(third); // 3

// Skipping elements
const [a, , c, , e] = numbers;
console.log(a); // 1
console.log(c); // 3
console.log(e); // 5

// Rest operator in destructuring
const [head, ...tail] = numbers;
console.log(head); // 1
console.log(tail); // [2, 3, 4, 5]

// Default values in arrays
const [x, y, z = 0] = [1, 2];
console.log(z); // 0 (default value)

// FUNCTION PARAMETER DESTRUCTURING
function greetUser({ name, age, city = "Unknown" }) {
  return `Hello ${name}, you are ${age} years old from ${city}`;
}

const userInfo = { name: "Bob", age: 25 };
console.log(greetUser(userInfo)); // "Hello Bob, you are 25 years old from Unknown"

// Array parameter destructuring
function calculateSum([a, b, c = 0]) {
  return a + b + c;
}

console.log(calculateSum([10, 20])); // 30
console.log(calculateSum([10, 20, 30])); // 60

// MIXED DESTRUCTURING
const response = {
  data: [
    { id: 1, name: "Item 1" },
    { id: 2, name: "Item 2" },
  ],
  status: "success",
};

const {
  data: [firstItem, secondItem],
  status,
} = response;

console.log(firstItem.name); // 'Item 1'
console.log(status); // 'success'

// SWAPPING VARIABLES
let a1 = 1;
let b1 = 2;

[a1, b1] = [b1, a1]; // Swap using destructuring
console.log(a1); // 2
console.log(b1); // 1

// COMPUTED PROPERTY NAMES
const key = "dynamicKey";
const obj = { [key]: "value", otherProp: "other" };

const { [key]: dynamicValue, otherProp } = obj;
console.log(dynamicValue); // 'value'

// PRACTICAL EXAMPLES

// 1. API Response handling
async function fetchUserData(userId) {
  const response = await fetch(`/api/users/${userId}`);
  const {
    data: { user, preferences },
    status,
    message,
  } = await response.json();

  if (status === "success") {
    const {
      name,
      email,
      profile: { avatar },
    } = user;
    return { name, email, avatar, preferences };
  }

  throw new Error(message);
}

// 2. React props destructuring
function UserComponent({
  user: { name, email },
  isLoggedIn = false,
  onLogout,
}) {
  return isLoggedIn ? `Welcome ${name} (${email})` : "Please log in";
}

// 3. Module imports (similar syntax)
// import { useState, useEffect } from 'react';
// import { add, multiply } from './math.js';

// 4. Configuration objects
function createServer({
  port = 3000,
  host = "localhost",
  ssl: { enabled = false, cert, key } = {},
  middleware = [],
}) {
  return {
    port,
    host,
    ssl: enabled ? { cert, key } : null,
    middleware,
  };
}
```

### **38. What is the purpose of the array slice method?**

The **`slice()`** method returns a shallow copy of a portion of an array into a new array. It does **not** modify the original array.

```javascript
// BASIC SYNTAX: array.slice(start, end)
// start: Starting index (inclusive)
// end: Ending index (exclusive)

const fruits = ["apple", "banana", "orange", "grape", "mango"];

// Basic slice usage
console.log(fruits.slice(1, 3)); // ['banana', 'orange']
console.log(fruits.slice(2)); // ['orange', 'grape', 'mango'] (from index 2 to end)
console.log(fruits.slice()); // ['apple', 'banana', 'orange', 'grape', 'mango'] (full copy)

// Original array unchanged
console.log(fruits); // ['apple', 'banana', 'orange', 'grape', 'mango']

// NEGATIVE INDICES
console.log(fruits.slice(-2)); // ['grape', 'mango'] (last 2 elements)
console.log(fruits.slice(-3, -1)); // ['orange', 'grape'] (from 3rd last to 2nd last)
console.log(fruits.slice(1, -1)); // ['banana', 'orange', 'grape'] (exclude first and last)

// EDGE CASES
console.log(fruits.slice(10)); // [] (start beyond array length)
console.log(fruits.slice(-10)); // Full array (start before beginning)
console.log(fruits.slice(3, 1)); // [] (start > end)

// PRACTICAL USE CASES

// 1. Creating array copies
const originalArray = [1, 2, 3, 4, 5];
const copyArray = originalArray.slice();
copyArray.push(6);
console.log(originalArray); // [1, 2, 3, 4, 5] (unchanged)
console.log(copyArray); // [1, 2, 3, 4, 5, 6]

// 2. Converting array-like objects to arrays
function convertToArray() {
  const args = Array.prototype.slice.call(arguments);
  return args;
}

console.log(convertToArray(1, 2, 3)); // [1, 2, 3]

// Modern way with spread operator
function modernConvert(...args) {
  return args;
}

// Converting NodeList to Array
const divs = document.querySelectorAll("div");
const divArray = Array.prototype.slice.call(divs);
// Or: const divArray = [...divs];

// 3. Pagination
function paginate(array, page, pageSize) {
  const start = (page - 1) * pageSize;
  const end = start + pageSize;
  return array.slice(start, end);
}

const items = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10];
console.log(paginate(items, 1, 3)); // [1, 2, 3] (page 1)
console.log(paginate(items, 2, 3)); // [4, 5, 6] (page 2)
console.log(paginate(items, 3, 3)); // [7, 8, 9] (page 3)

// 4. Getting last N elements
function getLastN(array, n) {
  return array.slice(-n);
}

console.log(getLastN([1, 2, 3, 4, 5], 3)); // [3, 4, 5]

// 5. Removing elements from beginning/end without mutation
function removeFirst(array) {
  return array.slice(1);
}

function removeLast(array) {
  return array.slice(0, -1);
}

function removeFirstAndLast(array) {
  return array.slice(1, -1);
}

const numbers = [1, 2, 3, 4, 5];
console.log(removeFirst(numbers)); // [2, 3, 4, 5]
console.log(removeLast(numbers)); // [1, 2, 3, 4]
console.log(removeFirstAndLast(numbers)); // [2, 3, 4]

// 6. String slice (similar concept)
const text = "Hello World";
console.log(text.slice(0, 5)); // "Hello"
console.log(text.slice(6)); // "World"
console.log(text.slice(-5)); // "World"

// 7. Implementing array methods using slice
function customReverse(array) {
  const result = array.slice(); // Create copy
  return result.reverse(); // Reverse the copy
}

function customFilter(array, predicate) {
  const result = [];
  for (let i = 0; i < array.length; i++) {
    if (predicate(array[i], i, array)) {
      result.push(array[i]);
    }
  }
  return result;
}

// 8. Chunking arrays
function chunk(array, size) {
  const chunks = [];
  for (let i = 0; i < array.length; i += size) {
    chunks.push(array.slice(i, i + size));
  }
  return chunks;
}

console.log(chunk([1, 2, 3, 4, 5, 6, 7], 3)); // [[1, 2, 3], [4, 5, 6], [7]]

// PERFORMANCE CONSIDERATIONS
// slice() creates a new array, so it uses additional memory
// For large arrays, consider using views or other techniques
// slice() is O(n) time complexity where n is the number of elements copied
```

### **39. What is the purpose of the array splice method?**

The **`splice()`** method changes the array by removing, replacing, or adding elements. It **modifies** the original array.

```javascript
// BASIC SYNTAX: array.splice(start, deleteCount, item1, item2, ...)
// start: Starting index
// deleteCount: Number of elements to remove
// items: Elements to add at the start position

let fruits = ["apple", "banana", "orange", "grape"];

// REMOVING ELEMENTS
// Remove 2 elements starting from index 1
let removed = fruits.splice(1, 2);
console.log(removed); // ['banana', 'orange'] (removed elements)
console.log(fruits); // ['apple', 'grape'] (original array modified)

// ADDING ELEMENTS
fruits = ["apple", "banana", "orange", "grape"];
// Add elements at index 2 without removing any
fruits.splice(2, 0, "kiwi", "mango");
console.log(fruits); // ['apple', 'banana', 'kiwi', 'mango', 'orange', 'grape']

// REPLACING ELEMENTS
fruits = ["apple", "banana", "orange", "grape"];
// Replace 2 elements starting from index 1
fruits.splice(1, 2, "kiwi", "mango");
console.log(fruits); // ['apple', 'kiwi', 'mango', 'grape']

// NEGATIVE START INDEX
fruits = ["apple", "banana", "orange", "grape"];
// Remove last 2 elements
fruits.splice(-2, 2);
console.log(fruits); // ['apple', 'banana']

// PRACTICAL USE CASES

// 1. Remove specific element by value
function removeByValue(array, value) {
  const index = array.indexOf(value);
  if (index > -1) {
    array.splice(index, 1);
  }
  return array;
}

let colors = ["red", "green", "blue", "yellow"];
removeByValue(colors, "green");
console.log(colors); // ['red', 'blue', 'yellow']

// 2. Remove multiple elements by value
function removeAllByValue(array, value) {
  for (let i = array.length - 1; i >= 0; i--) {
    if (array[i] === value) {
      array.splice(i, 1);
    }
  }
  return array;
}

let numbers = [1, 2, 3, 2, 4, 2, 5];
removeAllByValue(numbers, 2);
console.log(numbers); // [1, 3, 4, 5]

// 3. Insert element at specific position
function insertAt(array, index, ...elements) {
  array.splice(index, 0, ...elements);
  return array;
}

let list = [1, 2, 4, 5];
insertAt(list, 2, 3);
console.log(list); // [1, 2, 3, 4, 5]

// 4. Replace element at specific position
function replaceAt(array, index, newElement) {
  if (index >= 0 && index < array.length) {
    array.splice(index, 1, newElement);
  }
  return array;
}

let items = ["a", "b", "c", "d"];
replaceAt(items, 2, "X");
console.log(items); // ['a', 'b', 'X', 'd']

// 5. Clear array (remove all elements)
function clearArray(array) {
  array.splice(0, array.length);
  return array;
}

let data = [1, 2, 3, 4, 5];
clearArray(data);
console.log(data); // []

// 6. Move element to different position
function moveElement(array, fromIndex, toIndex) {
  const element = array.splice(fromIndex, 1)[0];
  array.splice(toIndex, 0, element);
  return array;
}

let sequence = [1, 2, 3, 4, 5];
moveElement(sequence, 0, 3); // Move first element to index 3
console.log(sequence); // [2, 3, 4, 1, 5]

// 7. Implementing array methods with splice
function customPush(array, ...elements) {
  array.splice(array.length, 0, ...elements);
  return array.length;
}

function customPop(array) {
  return array.splice(-1, 1)[0];
}

function customShift(array) {
  return array.splice(0, 1)[0];
}

function customUnshift(array, ...elements) {
  array.splice(0, 0, ...elements);
  return array.length;
}

// 8. Batch operations
function batchUpdate(array, updates) {
  // updates: [{ index, deleteCount, items }]
  // Process in reverse order to maintain indices
  updates
    .sort((a, b) => b.index - a.index)
    .forEach(({ index, deleteCount = 0, items = [] }) => {
      array.splice(index, deleteCount, ...items);
    });
  return array;
}

let testArray = [1, 2, 3, 4, 5];
batchUpdate(testArray, [
  { index: 1, deleteCount: 1, items: ["a", "b"] },
  { index: 3, deleteCount: 0, items: ["x"] },
]);
console.log(testArray); // [1, 'a', 'b', 3, 'x', 4, 5]

// EDGE CASES
let edgeTest = [1, 2, 3];

// Start beyond array length
edgeTest.splice(10, 1, "new");
console.log(edgeTest); // [1, 2, 3, 'new']

// Negative deleteCount (treated as 0)
edgeTest = [1, 2, 3];
edgeTest.splice(1, -1, "inserted");
console.log(edgeTest); // [1, 'inserted', 2, 3]

// Very large deleteCount
edgeTest = [1, 2, 3];
edgeTest.splice(1, 1000);
console.log(edgeTest); // [1]

// PERFORMANCE CONSIDERATIONS
// splice() can be expensive for large arrays when inserting/removing at beginning
// Consider using different data structures for frequent insertions/deletions
// Time complexity: O(n) where n is the number of elements to shift
```

### **40. What is JSON and its common operations?**

**JSON (JavaScript Object Notation)** is a lightweight, text-based data interchange format that's easy for humans to read and write.

```javascript
// JSON SYNTAX RULES
// - Data is in name/value pairs
// - Data is separated by commas
// - Objects are enclosed in curly braces {}
// - Arrays are enclosed in square brackets []
// - Strings must use double quotes

// VALID JSON
const validJSON = `{
    "name": "John Doe",
    "age": 30,
    "isStudent": false,
    "address": {
        "street": "123 Main St",
        "city": "New York",
        "zipCode": "10001"
    },
    "hobbies": ["reading", "swimming", "coding"],
    "spouse": null
}`;

// JAVASCRIPT OBJECT TO JSON STRING
const person = {
  name: "John Doe",
  age: 30,
  isStudent: false,
  address: {
    street: "123 Main St",
    city: "New York",
    zipCode: "10001",
  },
  hobbies: ["reading", "swimming", "coding"],
  spouse: null,
  greet: function () {
    return "Hello!";
  }, // Functions are ignored in JSON
};

// JSON.stringify() - Convert object to JSON string
const jsonString = JSON.stringify(person);
console.log(jsonString);
// Result: {"name":"John Doe","age":30,"isStudent":false,"address":{"street":"123 Main St","city":"New York","zipCode":"10001"},"hobbies":["reading","swimming","coding"],"spouse":null}

// JSON.parse() - Convert JSON string to object
const parsedObject = JSON.parse(jsonString);
console.log(parsedObject);
console.log(parsedObject.name); // "John Doe"

// JSON.stringify() WITH PARAMETERS

// 1. Replacer function/array
const stringifyWithReplacer = JSON.stringify(person, (key, value) => {
  // Filter out age property
  if (key === "age") return undefined;
  return value;
});

// Replacer array (only include specific properties)
const stringifyWithArray = JSON.stringify(person, ["name", "hobbies"]);
console.log(stringifyWithArray); // {"name":"John Doe","hobbies":["reading","swimming","coding"]}

// 2. Space parameter (pretty printing)
const prettyJSON = JSON.stringify(person, null, 2);
console.log(prettyJSON);
/*
{
  "name": "John Doe",
  "age": 30,
  "isStudent": false,
  ...
}
*/

// HANDLING SPECIAL VALUES
const specialValues = {
  func: function () {}, // Ignored
  undef: undefined, // Ignored
  symbol: Symbol("id"), // Ignored
  date: new Date(), // Converted to string
  regex: /pattern/, // Converted to {}
  infinity: Infinity, // Converted to null
  nan: NaN, // Converted to null
};

console.log(JSON.stringify(specialValues));
// {"date":"2023-XX-XXTXX:XX:XX.XXXZ","regex":{},"infinity":null,"nan":null}

// TOOJSON METHOD
class User {
  constructor(name, email, password) {
    this.name = name;
    this.email = email;
    this.password = password;
  }

  toJSON() {
    // Custom JSON serialization (exclude password)
    return {
      name: this.name,
      email: this.email,
    };
  }
}

const user = new User("John", "john@example.com", "secret123");
console.log(JSON.stringify(user)); // {"name":"John","email":"john@example.com"}

// JSON PARSING WITH REVIVER
const jsonWithDates =
  '{"name":"John","birthDate":"2023-01-15T10:30:00.000Z","score":"95"}';

const parsed = JSON.parse(jsonWithDates, (key, value) => {
  // Convert date strings to Date objects
  if (key.includes("Date") && typeof value === "string") {
    return new Date(value);
  }
  // Convert score string to number
  if (key === "score") {
    return parseInt(value);
  }
  return value;
});

console.log(parsed.birthDate instanceof Date); // true
console.log(typeof parsed.score); // 'number'

// ERROR HANDLING
function safeJSONParse(jsonString, defaultValue = null) {
  try {
    return JSON.parse(jsonString);
  } catch (error) {
    console.error("Invalid JSON:", error.message);
    return defaultValue;
  }
}

function safeJSONStringify(obj, defaultValue = "{}") {
  try {
    return JSON.stringify(obj);
  } catch (error) {
    console.error("Stringify error:", error.message);
    return defaultValue;
  }
}

// CIRCULAR REFERENCE HANDLING
const objA = { name: "A" };
const objB = { name: "B" };
objA.ref = objB;
objB.ref = objA; // Circular reference

// This would throw: JSON.stringify(objA);

// Solution: Custom replacer
function handleCircular() {
  const seen = new WeakSet();
  return (key, value) => {
    if (typeof value === "object" && value !== null) {
      if (seen.has(value)) {
        return "[Circular]";
      }
      seen.add(value);
    }
    return value;
  };
}

const circularSafe = JSON.stringify(objA, handleCircular());
console.log(circularSafe);

// DEEP CLONING WITH JSON (with limitations)
function deepClone(obj) {
  return JSON.parse(JSON.stringify(obj));
}

const original = {
  name: "John",
  address: { city: "NYC" },
  hobbies: ["reading"],
};

const cloned = deepClone(original);
cloned.address.city = "LA";
console.log(original.address.city); // 'NYC' (unchanged)
console.log(cloned.address.city); // 'LA'

// PRACTICAL EXAMPLES

// 1. Local Storage operations
function saveToStorage(key, data) {
  localStorage.setItem(key, JSON.stringify(data));
}

function loadFromStorage(key, defaultValue = null) {
  const item = localStorage.getItem(key);
  return item ? JSON.parse(item) : defaultValue;
}

// 2. API data handling
async function fetchAndProcessData(url) {
  try {
    const response = await fetch(url);
    const data = await response.json(); // Built-in JSON parsing
    return data;
  } catch (error) {
    console.error("API error:", error);
    return null;
  }
}

// 3. Configuration files
const config = {
  apiUrl: "https://api.example.com",
  timeout: 5000,
  features: {
    analytics: true,
    notifications: false,
  },
};

// Export configuration
const configJSON = JSON.stringify(config, null, 2);

// 4. Data validation
function isValidJSON(str) {
  try {
    JSON.parse(str);
    return true;
  } catch {
    return false;
  }
}

// JSON LIMITATIONS
// - No comments allowed
// - No functions
// - No undefined, Symbol, or BigInt
// - No Date objects (converted to strings)
// - No Map, Set, or other built-in objects
// - Keys must be strings
// - No trailing commas
```

---

**Continue to IMP_README_3_2.md for Coding problems...**
