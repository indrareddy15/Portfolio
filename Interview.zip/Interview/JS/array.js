//1. Remove an element an array
let arr = [1, 2, 3, 4];
let idx = arr.indexOf(3);
// console.log(idx) is 2

if (idx !== 1) {
  arr.splice(idx, 1);
}

// console.log(arr) [1,2,4]

let newArr = arr.filter((item) => item !== 3);
console.log(newArr);

// what is the difference between debouncing and throttling

// Debouuncing is a technique of delaying the execution of a function until a certain amount of time has elapsed since the last time the function was called.

// This is particularly useful for situations like handling user input, where you may want to wait until the user has stopped typing before sending a request or performing an action.
function debounce(func, delay) {
  let timeoutId;

  return function (...args) {
    clearTimeout(timeoutId);
    timeoutId = setTimeout(() => func.apply(this, args), delay);
  };
}

// Throttling is a technique of limiting the number of times a function is called within a certain time interval.

// This is useful for scenarios where you want to limit the rate of function execution, such as handling scroll events or continuous button clicks.
function throttle(func, delay) {
  let lastCall = 0;
  return function (...args) {
    let now = new Date().getTime();
    if (now - lastCall >= delay) {
      func.apply(this, args);
      lastCall = now;
    }
  };
}

// SLICE - [creates a shallow copy and does not alter the original array]
// Def: The slice method in javascript is used to extract the section of an array,
// returing the new array contained the selected  elements
// it will not modify the original array

// SPLICE - [splice won't shallow copy and does alter the original array]
// Def: Splice method in js will help add, remove or replace ele in an array


const promise = new Promise((res, rej) => {
  let succ = true
  if (succ) {
    resolve("Success!");
  } else {
   reject("Error!");
  }
})