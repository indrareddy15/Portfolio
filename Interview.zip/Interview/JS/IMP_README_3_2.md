# JavaScript Interview Questions & Answers - Part 3.2 (Basic Concepts Continued & Coding Problems)

_Fundamental concepts and practical coding challenges_

---

## 🔷 **BASIC CONCEPTS (Continued)**

### **41. What is a conditional operator and can you apply chaining?**

The **conditional operator** (ternary operator) `? :` is a shorthand for if-else statements. It can be chained for multiple conditions.

```javascript
// BASIC SYNTAX: condition ? value1 : value2

const age = 20;
const status = age >= 18 ? "adult" : "minor";
console.log(status); // 'adult'

// CHAINING CONDITIONAL OPERATORS
const score = 85;
const grade =
  score >= 90
    ? "A"
    : score >= 80
    ? "B"
    : score >= 70
    ? "C"
    : score >= 60
    ? "D"
    : "F";
console.log(grade); // 'B'

// NESTED TERNARY OPERATORS
const weather = "sunny";
const temperature = 25;
const suggestion =
  weather === "sunny"
    ? temperature > 30
      ? "Stay hydrated!"
      : "Perfect weather!"
    : "Take an umbrella!";

// PRACTICAL EXAMPLES

// 1. Setting default values
function greet(name) {
  const displayName = name ? name : "Guest";
  // Or: const displayName = name || 'Guest';
  return `Hello, ${displayName}!`;
}

// 2. Conditional rendering (React-style)
function renderMessage(user) {
  return user.isLoggedIn ? `Welcome back, ${user.name}!` : "Please log in";
}

// 3. API response handling
function processResponse(response) {
  return response.success ? response.data : { error: response.message };
}

// 4. Complex chaining example
function getShippingCost(weight, distance, isPriority) {
  return weight <= 1
    ? distance <= 100
      ? 5
      : 8
    : weight <= 5
    ? distance <= 100
      ? 10
      : 15
    : isPriority
    ? distance <= 100
      ? 25
      : 35
    : distance <= 100
    ? 20
    : 30;
}

// 5. Form validation
function validateInput(input) {
  return input.length === 0
    ? "Required field"
    : input.length < 3
    ? "Too short"
    : input.length > 50
    ? "Too long"
    : "Valid";
}

// BEST PRACTICES

// Good: Simple conditions
const message = isError ? "Error occurred" : "Success";

// Good: Short chains
const priority = score > 90 ? "high" : score > 70 ? "medium" : "low";

// Avoid: Too complex (use if-else instead)
// Bad example:
const complexResult = condition1
  ? condition2
    ? condition3
      ? "A"
      : "B"
    : condition4
    ? "C"
    : "D"
  : condition5
  ? condition6
    ? "E"
    : "F"
  : "G";

// Better approach for complex logic:
function getComplexResult() {
  if (condition1) {
    if (condition2) {
      return condition3 ? "A" : "B";
    } else {
      return condition4 ? "C" : "D";
    }
  } else {
    if (condition5) {
      return condition6 ? "E" : "F";
    } else {
      return "G";
    }
  }
}

// ALTERNATIVE APPROACHES

// 1. Logical operators
const defaultValue = userInput || "default";
const safeValue = userInput ?? "fallback"; // Nullish coalescing

// 2. Switch statement for multiple discrete values
function getDayType(day) {
  switch (day) {
    case "saturday":
    case "sunday":
      return "weekend";
    default:
      return "weekday";
  }
}

// 3. Object lookup for mappings
const gradeMap = {
  90: "A",
  80: "B",
  70: "C",
  60: "D",
};
const getGrade = (score) => {
  const threshold = Object.keys(gradeMap)
    .reverse()
    .find((key) => score >= key);
  return gradeMap[threshold] || "F";
};
```

### **42. What are spread and rest operators?**

The **spread operator** (`...`) expands elements, while the **rest operator** (`...`) collects elements. Same syntax, different contexts.

```javascript
// SPREAD OPERATOR - Expands/spreads elements

// 1. Array spreading
const arr1 = [1, 2, 3];
const arr2 = [4, 5, 6];
const combined = [...arr1, ...arr2]; // [1, 2, 3, 4, 5, 6]
const withExtra = [0, ...arr1, 3.5, ...arr2, 7]; // [0, 1, 2, 3, 3.5, 4, 5, 6, 7]

// 2. Object spreading
const obj1 = { a: 1, b: 2 };
const obj2 = { c: 3, d: 4 };
const mergedObj = { ...obj1, ...obj2 }; // { a: 1, b: 2, c: 3, d: 4 }

// Overriding properties
const user = { name: "John", age: 30, city: "NYC" };
const updatedUser = { ...user, age: 31, country: "USA" };
// { name: 'John', age: 31, city: 'NYC', country: 'USA' }

// 3. Function calls
function sum(a, b, c) {
  return a + b + c;
}

const numbers = [1, 2, 3];
console.log(sum(...numbers)); // 6
// Equivalent to: sum(1, 2, 3)

// 4. Array/String to individual elements
const str = "hello";
const chars = [...str]; // ['h', 'e', 'l', 'l', 'o']

const nodeList = document.querySelectorAll("div");
const divArray = [...nodeList]; // Convert NodeList to Array

// REST OPERATOR - Collects elements

// 1. Function parameters
function restExample(first, second, ...remaining) {
  console.log(first); // 1
  console.log(second); // 2
  console.log(remaining); // [3, 4, 5]
}
restExample(1, 2, 3, 4, 5);

// 2. Array destructuring
const [head, ...tail] = [1, 2, 3, 4, 5];
console.log(head); // 1
console.log(tail); // [2, 3, 4, 5]

const [first, second, ...rest] = [1, 2, 3, 4, 5];
console.log(rest); // [3, 4, 5]

// 3. Object destructuring
const person = { name: "John", age: 30, city: "NYC", country: "USA" };
const { name, age, ...otherInfo } = person;
console.log(name); // 'John'
console.log(age); // 30
console.log(otherInfo); // { city: 'NYC', country: 'USA' }

// PRACTICAL EXAMPLES

// 1. Creating flexible functions
function flexibleSum(...numbers) {
  return numbers.reduce((total, num) => total + num, 0);
}

console.log(flexibleSum(1)); // 1
console.log(flexibleSum(1, 2)); // 3
console.log(flexibleSum(1, 2, 3, 4)); // 10

// 2. Array manipulation
function addToArray(array, ...newItems) {
  return [...array, ...newItems];
}

function removeFromArray(array, ...indicesToRemove) {
  return array.filter((_, index) => !indicesToRemove.includes(index));
}

// 3. Object updates (immutable)
function updateUser(user, updates) {
  return { ...user, ...updates };
}

const originalUser = { id: 1, name: "John", email: "john@example.com" };
const newUser = updateUser(originalUser, { email: "newemail@example.com" });

// 4. Function composition
function createLogger(prefix, ...messages) {
  return function (...args) {
    console.log(prefix, ...messages, ...args);
  };
}

const errorLogger = createLogger("[ERROR]");
errorLogger("Something went wrong", { code: 500 });

// 5. Cloning arrays and objects
function shallowCloneArray(arr) {
  return [...arr];
}

function shallowCloneObject(obj) {
  return { ...obj };
}

// 6. Converting arguments to array (older approach)
function oldWay() {
  const args = Array.prototype.slice.call(arguments);
  return args;
}

function modernWay(...args) {
  return args; // Already an array
}

// 7. Math operations
const numbersArray = [1, 5, 3, 9, 2];
console.log(Math.max(...numbersArray)); // 9
console.log(Math.min(...numbersArray)); // 1

// 8. Array concatenation (avoiding mutation)
function concatArrays(...arrays) {
  return arrays.flat(); // ES2019
  // Or: return [].concat(...arrays);
}

// 9. Removing specific properties
function omit(obj, ...keysToOmit) {
  const { [keysToOmit[0]]: omitted, ...rest } = obj;
  return keysToOmit.length > 1 ? omit(rest, ...keysToOmit.slice(1)) : rest;
}

// Better approach for omit:
function omitProperties(obj, ...keys) {
  const result = { ...obj };
  keys.forEach((key) => delete result[key]);
  return result;
}

// 10. Event handling with rest
function handleEvents(primaryHandler, ...additionalHandlers) {
  return function (event) {
    primaryHandler(event);
    additionalHandlers.forEach((handler) => handler(event));
  };
}

// ADVANCED PATTERNS

// 1. Conditional spreading
const shouldIncludeExtra = true;
const configObject = {
  name: "MyApp",
  version: "1.0.0",
  ...(shouldIncludeExtra && {
    description: "My application",
    author: "John Doe",
  }),
};

// 2. Deep merge (careful with objects)
function deepMerge(target, ...sources) {
  if (!sources.length) return target;
  const source = sources.shift();

  for (const key in source) {
    if (source[key] && typeof source[key] === "object") {
      if (!target[key]) target[key] = {};
      deepMerge(target[key], source[key]);
    } else {
      target[key] = source[key];
    }
  }

  return deepMerge(target, ...sources);
}

// 3. Pipeline functions
function pipe(value, ...functions) {
  return functions.reduce((acc, fn) => fn(acc), value);
}

const result = pipe(
  5,
  (x) => x * 2,
  (x) => x + 1,
  (x) => x * 3
); // ((5 * 2) + 1) * 3 = 33

// PERFORMANCE CONSIDERATIONS
// Spread creates shallow copies
// For large arrays/objects, consider performance implications
// Rest parameters create a new array each time
```

### **43. What is a Set, WeakSet, Map, and WeakMap?**

These are ES6 collection types that provide alternatives to arrays and objects.

```javascript
// SET - Collection of unique values
const set = new Set();

// Adding values
set.add(1);
set.add(2);
set.add(2); // Duplicate, ignored
set.add("hello");
set.add({ name: "John" });

console.log(set.size); // 4
console.log(set.has(1)); // true
console.log(set.has(3)); // false

// Iteration
for (const value of set) {
  console.log(value);
}

set.forEach((value) => console.log(value));

// Converting array to Set (removes duplicates)
const numbers = [1, 2, 2, 3, 3, 4, 5];
const uniqueNumbers = [...new Set(numbers)]; // [1, 2, 3, 4, 5]

// Set operations
const setA = new Set([1, 2, 3, 4]);
const setB = new Set([3, 4, 5, 6]);

// Union
const union = new Set([...setA, ...setB]); // {1, 2, 3, 4, 5, 6}

// Intersection
const intersection = new Set([...setA].filter((x) => setB.has(x))); // {3, 4}

// Difference
const difference = new Set([...setA].filter((x) => !setB.has(x))); // {1, 2}

// WEAKSET - Collection of objects only, weakly referenced
const weakSet = new WeakSet();
const obj1 = { name: "Object 1" };
const obj2 = { name: "Object 2" };

weakSet.add(obj1);
weakSet.add(obj2);
// weakSet.add(1); // TypeError: Invalid value used in weak set

console.log(weakSet.has(obj1)); // true

// When obj1 is garbage collected, it's automatically removed from WeakSet
// No size property, no iteration possible

// MAP - Key-value pairs with any type of keys
const map = new Map();

// Setting values
map.set("string", "String key");
map.set(1, "Number key");
map.set(true, "Boolean key");
map.set(obj1, "Object key");

console.log(map.get("string")); // 'String key'
console.log(map.get(1)); // 'Number key'
console.log(map.size); // 4

// Map with initial values
const initialMap = new Map([
  ["key1", "value1"],
  ["key2", "value2"],
  [obj1, "object value"],
]);

// Iteration
for (const [key, value] of map) {
  console.log(key, value);
}

map.forEach((value, key) => {
  console.log(key, value);
});

// Get all keys and values
console.log([...map.keys()]); // Array of keys
console.log([...map.values()]); // Array of values
console.log([...map.entries()]); // Array of [key, value] pairs

// WEAKMAP - Like Map but keys must be objects, weakly referenced
const weakMap = new WeakMap();
const keyObj = { id: 1 };

weakMap.set(keyObj, "associated value");
console.log(weakMap.get(keyObj)); // 'associated value'

// weakMap.set('string', 'value'); // TypeError: Invalid value used as weak map key

// PRACTICAL EXAMPLES

// 1. Using Set for unique values
function getUniqueWords(text) {
  return new Set(text.toLowerCase().split(/\s+/));
}

// 2. Using Map for caching
const cache = new Map();
function expensiveOperation(input) {
  if (cache.has(input)) {
    return cache.get(input);
  }

  const result = input * input; // Simulate expensive operation
  cache.set(input, result);
  return result;
}

// 3. Using WeakMap for private data
const privateData = new WeakMap();

class User {
  constructor(name, email) {
    this.name = name;
    privateData.set(this, { email, password: null });
  }

  setPassword(password) {
    const data = privateData.get(this);
    data.password = password;
  }

  getEmail() {
    return privateData.get(this).email;
  }
}

// 4. Using Set for tag management
class ArticleManager {
  constructor() {
    this.articles = [];
    this.allTags = new Set();
  }

  addArticle(title, content, tags) {
    const article = { title, content, tags: new Set(tags) };
    this.articles.push(article);

    // Add to global tags
    tags.forEach((tag) => this.allTags.add(tag));
  }

  getArticlesByTag(tag) {
    return this.articles.filter((article) => article.tags.has(tag));
  }

  getAllTags() {
    return [...this.allTags];
  }
}

// 5. Using Map for object property mapping
function groupBy(array, keyFn) {
  const grouped = new Map();

  for (const item of array) {
    const key = keyFn(item);
    if (!grouped.has(key)) {
      grouped.set(key, []);
    }
    grouped.get(key).push(item);
  }

  return grouped;
}

const people = [
  { name: "Alice", age: 25 },
  { name: "Bob", age: 30 },
  { name: "Charlie", age: 25 },
];

const groupedByAge = groupBy(people, (person) => person.age);

// COMPARISON TABLE
const comparison = {
  Set: {
    keys: "Values as keys",
    uniqueness: "Enforced",
    size: "Available",
    iteration: "Possible",
    weakRef: "No",
    garbageCollection: "Standard",
  },
  WeakSet: {
    keys: "Objects only",
    uniqueness: "Enforced",
    size: "Not available",
    iteration: "Not possible",
    weakRef: "Yes",
    garbageCollection: "Automatic cleanup",
  },
  Map: {
    keys: "Any type",
    uniqueness: "Keys are unique",
    size: "Available",
    iteration: "Possible",
    weakRef: "No",
    garbageCollection: "Standard",
  },
  WeakMap: {
    keys: "Objects only",
    uniqueness: "Keys are unique",
    size: "Not available",
    iteration: "Not possible",
    weakRef: "Yes",
    garbageCollection: "Automatic cleanup",
  },
};

// PERFORMANCE CONSIDERATIONS

// Set vs Array for uniqueness
const largeArray = Array.from({ length: 10000 }, (_, i) => i % 1000);

// Slow: Using array
console.time("Array includes");
const uniqueArray = largeArray.filter(
  (item, index) => largeArray.indexOf(item) === index
);
console.timeEnd("Array includes");

// Fast: Using Set
console.time("Set");
const uniqueSet = [...new Set(largeArray)];
console.timeEnd("Set");

// Map vs Object for dynamic keys
// Map is better when:
// - Keys are not strings
// - Frequent additions/deletions
// - Need to know size
// - Need to iterate in insertion order

// Object is better when:
// - Keys are strings/symbols
// - Need JSON serialization
// - Static structure
// - Need property access syntax
```

### **44. What are break and continue statements?**

**`break`** exits a loop completely, while **`continue`** skips the current iteration and moves to the next one.

```javascript
// BREAK STATEMENT - Exits loop completely

// 1. In for loop
for (let i = 0; i < 10; i++) {
  if (i === 5) {
    break; // Exit loop when i equals 5
  }
  console.log(i); // Prints: 0, 1, 2, 3, 4
}

// 2. In while loop
let count = 0;
while (true) {
  if (count === 3) {
    break; // Exit infinite loop
  }
  console.log(count); // Prints: 0, 1, 2
  count++;
}

// 3. In switch statement
function processDay(day) {
  switch (day) {
    case "monday":
      console.log("Start of work week");
      break; // Exit switch, don't fall through
    case "friday":
      console.log("TGIF!");
      break;
    case "saturday":
    case "sunday":
      console.log("Weekend!");
      break;
    default:
      console.log("Regular day");
      break;
  }
}

// CONTINUE STATEMENT - Skip current iteration

// 1. Skip even numbers
for (let i = 0; i < 10; i++) {
  if (i % 2 === 0) {
    continue; // Skip even numbers
  }
  console.log(i); // Prints: 1, 3, 5, 7, 9
}

// 2. Skip invalid data
const data = [1, null, 3, undefined, 5, "", 7];
for (const item of data) {
  if (!item) {
    continue; // Skip falsy values
  }
  console.log(item * 2); // Prints: 2, 6, 10, 14
}

// 3. In while loop
let num = 0;
while (num < 10) {
  num++;
  if (num % 3 === 0) {
    continue; // Skip multiples of 3
  }
  console.log(num); // Prints: 1, 2, 4, 5, 7, 8, 10
}

// LABELED STATEMENTS - Break/continue outer loops

// Break outer loop
outer: for (let i = 0; i < 3; i++) {
  for (let j = 0; j < 3; j++) {
    if (i === 1 && j === 1) {
      break outer; // Break out of both loops
    }
    console.log(`i: ${i}, j: ${j}`);
  }
}
// Output: i: 0, j: 0; i: 0, j: 1; i: 0, j: 2; i: 1, j: 0

// Continue outer loop
outer2: for (let i = 0; i < 3; i++) {
  for (let j = 0; j < 3; j++) {
    if (j === 1) {
      continue outer2; // Skip to next i iteration
    }
    console.log(`i: ${i}, j: ${j}`);
  }
}

// PRACTICAL EXAMPLES

// 1. Finding first match
function findFirst(array, condition) {
  for (const item of array) {
    if (condition(item)) {
      return item; // Found, break automatically with return
    }
  }
  return null; // Not found
}

// 2. Processing valid items only
function processValidItems(items) {
  const results = [];

  for (const item of items) {
    // Skip invalid items
    if (!item || typeof item !== "object") {
      continue;
    }

    // Skip items without required fields
    if (!item.id || !item.name) {
      continue;
    }

    // Process valid item
    results.push({
      id: item.id,
      name: item.name.toUpperCase(),
      processed: true,
    });
  }

  return results;
}

// 3. Menu system
function processMenu() {
  while (true) {
    const choice = prompt("Choose: 1-Add, 2-Remove, 3-List, 4-Exit");

    switch (choice) {
      case "1":
        addItem();
        break; // Break switch, continue while loop
      case "2":
        removeItem();
        break;
      case "3":
        listItems();
        break;
      case "4":
        console.log("Goodbye!");
        return; // Exit function completely
      default:
        console.log("Invalid choice");
        continue; // Skip to next iteration
    }
  }
}

// 4. Validation loop
function getValidInput(validator, errorMessage) {
  while (true) {
    const input = prompt("Enter value:");

    if (validator(input)) {
      return input; // Valid input, exit loop
    }

    console.log(errorMessage);
    // Continue to ask again
  }
}

// 5. Batch processing with error handling
function processBatch(items) {
  const results = [];
  const errors = [];

  for (let i = 0; i < items.length; i++) {
    try {
      // Skip null/undefined items
      if (items[i] == null) {
        continue;
      }

      const result = complexProcessing(items[i]);
      results.push(result);

      // Stop processing if critical error occurs
      if (result.isCriticalError) {
        console.log("Critical error encountered, stopping batch");
        break;
      }
    } catch (error) {
      errors.push({ index: i, error: error.message });
      continue; // Process next item despite error
    }
  }

  return { results, errors };
}

// ALTERNATIVE APPROACHES

// Instead of break/continue, consider:

// 1. Array methods
const evenNumbers = [1, 2, 3, 4, 5, 6].filter((n) => n % 2 === 0); // Instead of continue

const firstLarge = [1, 5, 10, 15, 20].find((n) => n > 10); // Instead of break

// 2. Early return
function processUser(user) {
  if (!user) return null; // Instead of continue in caller
  if (!user.isActive) return null;

  return {
    name: user.name,
    email: user.email,
  };
}

// 3. Separate functions
function isValidItem(item) {
  return item && item.id && item.name;
}

function processItems(items) {
  return items
    .filter(isValidItem) // Instead of continue
    .map((item) => processItem(item));
}

// 4. Generator functions for complex iteration control
function* processWithControl(items) {
  for (const item of items) {
    if (!isValid(item)) {
      continue; // Skip invalid
    }

    const result = process(item);
    yield result;

    if (shouldStop(result)) {
      break; // Stop processing
    }
  }
}

// BEST PRACTICES
// - Use break/continue sparingly
// - Consider array methods for simple cases
// - Use labeled statements only when necessary
// - Prefer early returns in functions
// - Keep loop logic simple and readable
```

---

## 💻 **CODING PROBLEMS**

### **45. Write a Program to reverse a string in JavaScript**

```javascript
// METHOD 1: Using built-in methods
function reverseString1(str) {
  return str.split("").reverse().join("");
}

// METHOD 2: Using for loop
function reverseString2(str) {
  let reversed = "";
  for (let i = str.length - 1; i >= 0; i--) {
    reversed += str[i];
  }
  return reversed;
}

// METHOD 3: Using recursion
function reverseString3(str) {
  if (str === "") {
    return "";
  }
  return reverseString3(str.substr(1)) + str.charAt(0);
}

// METHOD 4: Using reduce
function reverseString4(str) {
  return str.split("").reduce((reversed, char) => char + reversed, "");
}

// METHOD 5: Using while loop
function reverseString5(str) {
  let reversed = "";
  let i = str.length - 1;
  while (i >= 0) {
    reversed += str[i];
    i--;
  }
  return reversed;
}

// METHOD 6: Using Array.from and reverse
function reverseString6(str) {
  return Array.from(str).reverse().join("");
}

// METHOD 7: Using spread operator
function reverseString7(str) {
  return [...str].reverse().join("");
}

// TEST CASES
const testCases = [
  "hello",
  "JavaScript",
  "racecar",
  "A man a plan a canal Panama",
  "12345",
  "",
  "a",
];

console.log("Testing all methods:");
testCases.forEach((test) => {
  console.log(`Original: "${test}"`);
  console.log(`Reversed: "${reverseString1(test)}"`);
  console.log("---");
});

// PERFORMANCE COMPARISON
function performanceTest() {
  const longString = "a".repeat(100000);

  console.time("Method 1 (built-in)");
  reverseString1(longString);
  console.timeEnd("Method 1 (built-in)");

  console.time("Method 2 (for loop)");
  reverseString2(longString);
  console.timeEnd("Method 2 (for loop)");

  console.time("Method 4 (reduce)");
  reverseString4(longString);
  console.timeEnd("Method 4 (reduce)");
}

// Uncomment to run performance test
// performanceTest();
```

### **46. Write a Program to check whether a string is a palindrome**

```javascript
// METHOD 1: Simple comparison with built-in methods
function isPalindrome1(str) {
  const cleaned = str.toLowerCase();
  return cleaned === cleaned.split("").reverse().join("");
}

// METHOD 2: Two-pointer approach
function isPalindrome2(str) {
  const cleaned = str.toLowerCase();
  let left = 0;
  let right = cleaned.length - 1;

  while (left < right) {
    if (cleaned[left] !== cleaned[right]) {
      return false;
    }
    left++;
    right--;
  }
  return true;
}

// METHOD 3: With special character removal
function isPalindrome3(str) {
  // Remove non-alphanumeric characters and convert to lowercase
  const cleaned = str.replace(/[^a-zA-Z0-9]/g, "").toLowerCase();
  return cleaned === cleaned.split("").reverse().join("");
}

// METHOD 4: Recursive approach
function isPalindrome4(str) {
  const cleaned = str.toLowerCase().replace(/[^a-zA-Z0-9]/g, "");

  function checkPalindrome(s, start, end) {
    if (start >= end) return true;
    if (s[start] !== s[end]) return false;
    return checkPalindrome(s, start + 1, end - 1);
  }

  return checkPalindrome(cleaned, 0, cleaned.length - 1);
}

// METHOD 5: Using every method
function isPalindrome5(str) {
  const cleaned = str.toLowerCase().replace(/[^a-zA-Z0-9]/g, "");
  const chars = cleaned.split("");
  const length = chars.length;

  return chars.every((char, index) => {
    return char === chars[length - 1 - index];
  });
}

// METHOD 6: For loop with early exit
function isPalindrome6(str) {
  const cleaned = str.toLowerCase().replace(/[^a-zA-Z0-9]/g, "");
  const length = cleaned.length;

  for (let i = 0; i < length / 2; i++) {
    if (cleaned[i] !== cleaned[length - 1 - i]) {
      return false;
    }
  }
  return true;
}

// ADVANCED: Check palindrome ignoring case and special characters
function isPalindromeAdvanced(str) {
  if (typeof str !== "string") return false;
  if (str.length <= 1) return true;

  // Remove non-alphanumeric characters and convert to lowercase
  const cleaned = str.replace(/[^a-zA-Z0-9]/g, "").toLowerCase();

  // Use two pointers for efficient checking
  let left = 0;
  let right = cleaned.length - 1;

  while (left < right) {
    if (cleaned[left] !== cleaned[right]) {
      return false;
    }
    left++;
    right--;
  }

  return true;
}

// TEST CASES
const palindromeTests = [
  "racecar",
  "A man a plan a canal Panama",
  "race a car",
  "hello",
  "Madam",
  "Was it a car or a cat I saw?",
  "12321",
  "12345",
  "",
  "a",
  "Able was I ere I saw Elba",
];

console.log("Palindrome Tests:");
palindromeTests.forEach((test) => {
  const result = isPalindromeAdvanced(test);
  console.log(`"${test}" -> ${result}`);
});

// SPECIAL CASES HANDLER
function isPalindromeRobust(input) {
  // Handle null, undefined, non-string inputs
  if (input === null || input === undefined) {
    return false;
  }

  // Convert to string if not already
  const str = String(input);

  // Handle empty string
  if (str.length === 0) {
    return true; // Empty string is considered palindrome
  }

  // Clean and check
  const cleaned = str.replace(/[^a-zA-Z0-9]/g, "").toLowerCase();
  return cleaned === cleaned.split("").reverse().join("");
}

// PERFORMANCE OPTIMIZED VERSION
function isPalindromeFast(str) {
  if (!str || str.length <= 1) return true;

  let left = 0;
  let right = str.length - 1;

  while (left < right) {
    // Skip non-alphanumeric characters from left
    while (left < right && !/[a-zA-Z0-9]/.test(str[left])) {
      left++;
    }

    // Skip non-alphanumeric characters from right
    while (left < right && !/[a-zA-Z0-9]/.test(str[right])) {
      right--;
    }

    // Compare characters (case insensitive)
    if (str[left].toLowerCase() !== str[right].toLowerCase()) {
      return false;
    }

    left++;
    right--;
  }

  return true;
}
```

### **47. Find the largest number in an array**

```javascript
// METHOD 1: Using Math.max with spread operator
function findLargest1(arr) {
  if (arr.length === 0) return undefined;
  return Math.max(...arr);
}

// METHOD 2: Using for loop
function findLargest2(arr) {
  if (arr.length === 0) return undefined;

  let largest = arr[0];
  for (let i = 1; i < arr.length; i++) {
    if (arr[i] > largest) {
      largest = arr[i];
    }
  }
  return largest;
}

// METHOD 3: Using reduce
function findLargest3(arr) {
  if (arr.length === 0) return undefined;

  return arr.reduce((max, current) => {
    return current > max ? current : max;
  });
}

// METHOD 4: Using sort (modifies original array)
function findLargest4(arr) {
  if (arr.length === 0) return undefined;

  return arr.slice().sort((a, b) => b - a)[0];
}

// METHOD 5: Using forEach
function findLargest5(arr) {
  if (arr.length === 0) return undefined;

  let largest = arr[0];
  arr.forEach((num) => {
    if (num > largest) {
      largest = num;
    }
  });
  return largest;
}

// METHOD 6: Recursive approach
function findLargest6(arr, index = 0, currentMax = -Infinity) {
  if (index >= arr.length) {
    return currentMax === -Infinity ? undefined : currentMax;
  }

  const newMax = arr[index] > currentMax ? arr[index] : currentMax;
  return findLargest6(arr, index + 1, newMax);
}

// ADVANCED: Handle mixed data types
function findLargestRobust(arr) {
  if (!Array.isArray(arr) || arr.length === 0) {
    return undefined;
  }

  // Filter out non-numeric values
  const numbers = arr.filter(
    (item) => typeof item === "number" && !isNaN(item)
  );

  if (numbers.length === 0) {
    return undefined; // No valid numbers found
  }

  return Math.max(...numbers);
}

// FIND LARGEST WITH INDEX
function findLargestWithIndex(arr) {
  if (arr.length === 0) return { value: undefined, index: -1 };

  let largest = arr[0];
  let largestIndex = 0;

  for (let i = 1; i < arr.length; i++) {
    if (arr[i] > largest) {
      largest = arr[i];
      largestIndex = i;
    }
  }

  return { value: largest, index: largestIndex };
}

// FIND N LARGEST NUMBERS
function findNLargest(arr, n) {
  if (n >= arr.length) return arr.slice().sort((a, b) => b - a);

  return arr
    .slice()
    .sort((a, b) => b - a)
    .slice(0, n);
}

// OPTIMIZED FOR VERY LARGE ARRAYS
function findLargestOptimized(arr) {
  if (arr.length === 0) return undefined;
  if (arr.length === 1) return arr[0];

  let largest = arr[0];

  // Unroll loop for better performance
  for (let i = 1; i < arr.length - 3; i += 4) {
    if (arr[i] > largest) largest = arr[i];
    if (arr[i + 1] > largest) largest = arr[i + 1];
    if (arr[i + 2] > largest) largest = arr[i + 2];
    if (arr[i + 3] > largest) largest = arr[i + 3];
  }

  // Handle remaining elements
  for (let i = arr.length - (arr.length % 4); i < arr.length; i++) {
    if (arr[i] > largest) largest = arr[i];
  }

  return largest;
}

// TEST CASES
const testArrays = [
  [1, 5, 3, 9, 2],
  [-5, -1, -10, -3],
  [42],
  [],
  [1.5, 2.7, 3.14, 2.71],
  [1, "hello", 3, null, 5, undefined, 7],
  [Number.MAX_VALUE, 1000000, 999999],
  [0, 0, 0, 0],
  [Infinity, 100, 200],
  [-Infinity, -100, -50],
];

console.log("Testing findLargest methods:");
testArrays.forEach((arr, index) => {
  console.log(`Test ${index + 1}: [${arr}]`);
  console.log(`Result: ${findLargestRobust(arr)}`);
  console.log("---");
});

// PERFORMANCE COMPARISON
function performanceComparison() {
  const largeArray = Array.from(
    { length: 1000000 },
    () => Math.random() * 1000
  );

  console.time("Math.max with spread");
  findLargest1(largeArray);
  console.timeEnd("Math.max with spread");

  console.time("For loop");
  findLargest2(largeArray);
  console.timeEnd("For loop");

  console.time("Reduce");
  findLargest3(largeArray);
  console.timeEnd("Reduce");

  console.time("Optimized loop");
  findLargestOptimized(largeArray);
  console.timeEnd("Optimized loop");
}

// Uncomment to run performance test
// performanceComparison();

// PRACTICAL USAGE EXAMPLES
function findLargestSalary(employees) {
  return Math.max(...employees.map((emp) => emp.salary));
}

function findLargestScore(students) {
  const scores = students.map((student) => Math.max(...student.scores));
  return Math.max(...scores);
}

function findLargestInNestedArray(nestedArr) {
  const flattened = nestedArr.flat(Infinity);
  return findLargestRobust(flattened);
}
```

### **48. How to remove the first element from an array?**

```javascript
// METHOD 1: Using shift() - Modifies original array
function removeFirst1(arr) {
  return arr.shift(); // Returns removed element
}

// METHOD 2: Using slice() - Returns new array
function removeFirst2(arr) {
  return arr.slice(1);
}

// METHOD 3: Using destructuring - Returns new array
function removeFirst3(arr) {
  const [first, ...rest] = arr;
  return rest;
}

// METHOD 4: Using splice() - Modifies original array
function removeFirst4(arr) {
  return arr.splice(0, 1)[0]; // Returns removed element
}

// METHOD 5: Using filter() with index
function removeFirst5(arr) {
  return arr.filter((_, index) => index !== 0);
}

// METHOD 6: Manual loop approach
function removeFirst6(arr) {
  const newArr = [];
  for (let i = 1; i < arr.length; i++) {
    newArr.push(arr[i]);
  }
  return newArr;
}

// COMPARISON OF METHODS

const originalArray = [1, 2, 3, 4, 5];

console.log("Original array:", originalArray);

// Method 1: shift() - mutates original
const arr1 = [1, 2, 3, 4, 5];
const removed1 = removeFirst1(arr1);
console.log("After shift():", arr1); // [2, 3, 4, 5]
console.log("Removed element:", removed1); // 1

// Method 2: slice() - doesn't mutate
const arr2 = [1, 2, 3, 4, 5];
const newArr2 = removeFirst2(arr2);
console.log("Original after slice():", arr2); // [1, 2, 3, 4, 5]
console.log("New array from slice():", newArr2); // [2, 3, 4, 5]

// Method 3: destructuring - doesn't mutate
const arr3 = [1, 2, 3, 4, 5];
const newArr3 = removeFirst3(arr3);
console.log("Original after destructuring:", arr3); // [1, 2, 3, 4, 5]
console.log("New array from destructuring:", newArr3); // [2, 3, 4, 5]

// ADVANCED IMPLEMENTATIONS

// Safe removal that handles empty arrays
function removeFirstSafe(arr) {
  if (!Array.isArray(arr) || arr.length === 0) {
    return [];
  }
  return arr.slice(1);
}

// Remove first N elements
function removeFirstN(arr, n = 1) {
  if (n <= 0) return arr.slice();
  return arr.slice(n);
}

// Remove first element and get both removed element and new array
function removeFirstComplete(arr) {
  if (arr.length === 0) {
    return { removed: undefined, remaining: [] };
  }

  return {
    removed: arr[0],
    remaining: arr.slice(1),
  };
}

// Remove first element that matches condition
function removeFirstMatch(arr, condition) {
  const index = arr.findIndex(condition);
  if (index === -1) return arr.slice(); // No match found

  return arr.filter((_, i) => i !== index);
}

// Immutable removal with spread
function removeFirstImmutable(arr) {
  return [...arr.slice(1)];
}

// PRACTICAL EXAMPLES

// 1. Queue implementation (FIFO)
class SimpleQueue {
  constructor() {
    this.items = [];
  }

  enqueue(item) {
    this.items.push(item);
  }

  dequeue() {
    return this.items.shift(); // Remove first element
  }

  peek() {
    return this.items[0];
  }

  isEmpty() {
    return this.items.length === 0;
  }

  size() {
    return this.items.length;
  }
}

// 2. Processing a list of tasks
function processTasks(tasks) {
  const tasksCopy = [...tasks]; // Create copy to avoid mutation
  const completed = [];

  while (tasksCopy.length > 0) {
    const currentTask = tasksCopy.shift(); // Remove and get first task
    completed.push(processTask(currentTask));
  }

  return completed;
}

function processTask(task) {
  // Simulate task processing
  return { ...task, completed: true, timestamp: Date.now() };
}

// 3. Breadth-First Search implementation
function bfs(graph, startNode) {
  const visited = new Set();
  const queue = [startNode];
  const result = [];

  while (queue.length > 0) {
    const node = queue.shift(); // Remove first element (FIFO)

    if (!visited.has(node)) {
      visited.add(node);
      result.push(node);

      // Add neighbors to queue
      const neighbors = graph[node] || [];
      queue.push(...neighbors.filter((n) => !visited.has(n)));
    }
  }

  return result;
}

// TEST CASES
const testCases = [
  [1, 2, 3, 4, 5],
  ["a", "b", "c"],
  [42],
  [],
  [null, undefined, 0, false],
  [{ id: 1 }, { id: 2 }, { id: 3 }],
];

console.log("\nTesting removeFirstSafe:");
testCases.forEach((test, index) => {
  console.log(`Test ${index + 1}: [${test}] -> [${removeFirstSafe(test)}]`);
});

// PERFORMANCE CONSIDERATIONS
function performanceTest() {
  const largeArray = Array.from({ length: 100000 }, (_, i) => i);

  console.time("shift() - mutating");
  const arr1 = [...largeArray];
  while (arr1.length > 0) {
    arr1.shift();
  }
  console.timeEnd("shift() - mutating");

  console.time("slice(1) - immutable");
  let arr2 = [...largeArray];
  while (arr2.length > 0) {
    arr2 = arr2.slice(1);
  }
  console.timeEnd("slice(1) - immutable");
}

// Note: shift() is O(n) because it needs to reindex all elements
// slice(1) is also O(n) but creates new array each time
// For frequent first-element removal, consider using a deque data structure

// WHEN TO USE EACH METHOD:

// Use shift() when:
// - You want to mutate the original array
// - You need the removed element
// - Memory efficiency is important
// - You're implementing a queue

// Use slice(1) when:
// - You want to keep original array unchanged
// - Working with functional programming patterns
// - You don't need the removed element
// - Immutability is required

// Use destructuring when:
// - You want both first element and rest
// - Code readability is important
// - Working with small arrays
// - Functional programming style
```

---

**This concludes all the JavaScript interview questions and answers. The content is organized by complexity and covers fundamental concepts, intermediate topics, advanced concepts, and practical coding problems with multiple solution approaches.**
