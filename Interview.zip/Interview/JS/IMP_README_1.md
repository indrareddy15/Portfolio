# JavaScript Interview Questions & Answers - Part 1 (Advanced Concepts)

_Most complex and important concepts for senior JavaScript positions_

---

## 🔥 **ADVANCED CONCEPTS**

### **1. What is the event loop?**

The **event loop** is JavaScript's mechanism for handling asynchronous operations in a single-threaded environment. It continuously monitors the call stack and task queues to execute code.

**How it works:**

1. **Call Stack**: Executes synchronous code
2. **Web APIs**: Handle async operations (setTimeout, DOM events, HTTP requests)
3. **Task Queue**: Stores completed async operations
4. **Event Loop**: Moves tasks from queue to stack when stack is empty

```javascript
console.log("1");
setTimeout(() => console.log("2"), 0);
Promise.resolve().then(() => console.log("3"));
console.log("4");

// Output: 1, 4, 3, 2
// Microtasks (Promise) have higher priority than macrotasks (setTimeout)
```

### **2. What are tasks in event loop?**

**Tasks** are units of work scheduled to be performed by the event loop.

**Types:**

- **Macrotasks**: setTimeout, setInterval, DOM events, I/O operations
- **Microtasks**: Promise.then, queueMicrotask, MutationObserver

```javascript
// Macrotask
setTimeout(() => console.log("Macrotask 1"), 0);
setTimeout(() => console.log("Macrotask 2"), 0);

// Microtask
Promise.resolve().then(() => console.log("Microtask 1"));
Promise.resolve().then(() => console.log("Microtask 2"));

console.log("Synchronous");

// Output: Synchronous, Microtask 1, Microtask 2, Macrotask 1, Macrotask 2
```

### **3. What are different event loops?**

Different JavaScript environments have different event loop implementations:

**Browser Event Loop:**

- Main thread event loop
- Web Workers have separate event loops
- Service Workers have their own event loop

**Node.js Event Loop:**

- More complex with multiple phases
- Timer phase, Poll phase, Check phase, etc.

```javascript
// Browser vs Node.js differences
setImmediate(() => console.log("setImmediate")); // Node.js only
setTimeout(() => console.log("setTimeout"), 0);

// Node.js specific
process.nextTick(() => console.log("nextTick")); // Highest priority in Node.js
```

### **4. What is microtask and microtask queue?**

**Microtasks** are high-priority tasks that execute before the next macrotask.

**Microtask Queue** holds:

- Promise callbacks (.then, .catch, .finally)
- queueMicrotask callbacks
- MutationObserver callbacks

```javascript
console.log("Start");

setTimeout(() => console.log("Timer"), 0);

Promise.resolve().then(() => {
  console.log("Promise 1");
  Promise.resolve().then(() => console.log("Promise 2"));
});

queueMicrotask(() => console.log("Microtask"));

console.log("End");

// Output: Start, End, Promise 1, Microtask, Promise 2, Timer
```

### **5. What is the purpose of queueMicrotask?**

`queueMicrotask()` allows you to schedule a function to run in the microtask queue.

```javascript
function flushSync() {
  return new Promise((resolve) => {
    queueMicrotask(resolve);
  });
}

async function example() {
  console.log("Before");
  await flushSync(); // Yield to microtasks
  console.log("After");
}

// Use case: Yielding control while maintaining high priority
queueMicrotask(() => {
  // This runs before any setTimeout callbacks
  updateUIState();
});
```

### **6. What is the call stack?**

The **call stack** is a LIFO (Last In, First Out) data structure that tracks function calls.

```javascript
function first() {
  console.log("First");
  second();
  console.log("First end");
}

function second() {
  console.log("Second");
  third();
  console.log("Second end");
}

function third() {
  console.log("Third");
}

first();

// Call Stack trace:
// 1. [global]
// 2. [global, first]
// 3. [global, first, second]
// 4. [global, first, second, third]
// 5. [global, first, second] // third popped
// 6. [global, first] // second popped
// 7. [global] // first popped
```

### **7. What is the event queue?**

The **event queue** (task queue) holds callback functions waiting to be executed.

```javascript
// Event queue example
document.addEventListener("click", () => {
  console.log("Click event"); // Goes to event queue
});

fetch("/api/data").then((response) => {
  console.log("HTTP response"); // Microtask queue
});

setTimeout(() => {
  console.log("Timer"); // Macrotask queue
}, 0);

// Execution order: Microtasks → DOM events → Timers
```

### **8. What is global execution context?**

The **global execution context** is the default context where JavaScript code starts executing.

```javascript
// Global Execution Context contains:
// 1. Global Object (window in browser, global in Node.js)
// 2. 'this' keyword (points to global object)
// 3. Variable Environment
// 4. Lexical Environment

var globalVar = "I am global";
let blockScoped = "Block scoped";
const constant = "Constant";

function globalFunction() {
  console.log("Global function");
}

// In browser: window.globalVar === globalVar (true)
// In Node.js: global.globalVar === globalVar (true)
```

### **9. What is function execution context?**

A **function execution context** is created when a function is called.

```javascript
function createContext(param1, param2) {
  var localVar = "Local variable";
  let blockVar = "Block variable";

  function innerFunction() {
    console.log(localVar); // Accesses outer scope
  }

  return innerFunction;
}

// Function Execution Context contains:
// 1. Variable Environment (var, function declarations)
// 2. Lexical Environment (let, const, parameters)
// 3. 'this' binding
// 4. arguments object
// 5. Outer environment reference
```

### **10. What are the phases of execution context?**

Execution contexts have **two phases**:

**1. Creation Phase:**

- Variable Environment setup
- Lexical Environment setup
- `this` binding
- Hoisting occurs

**2. Execution Phase:**

- Code execution line by line
- Variable assignments
- Function calls

```javascript
function example() {
  // Creation Phase:
  // - var a = undefined (hoisted)
  // - function inner = <function object>
  // - let b = <uninitialized> (TDZ)

  console.log(a); // undefined (not error due to hoisting)
  // console.log(b); // ReferenceError: Cannot access 'b' before initialization

  var a = 10; // Execution Phase: assignment
  let b = 20; // Execution Phase: initialization and assignment

  function inner() {
    return "Inner function";
  }
}
```

### **11. What is a prototype chain?**

The **prototype chain** is JavaScript's inheritance mechanism where objects inherit properties and methods from their prototype.

```javascript
function Animal(name) {
  this.name = name;
}

Animal.prototype.speak = function () {
  return `${this.name} makes a sound`;
};

function Dog(name, breed) {
  Animal.call(this, name);
  this.breed = breed;
}

// Set up prototype chain
Dog.prototype = Object.create(Animal.prototype);
Dog.prototype.constructor = Dog;

Dog.prototype.bark = function () {
  return `${this.name} barks`;
};

const myDog = new Dog("Buddy", "Golden Retriever");
console.log(myDog.speak()); // Inherited from Animal.prototype
console.log(myDog.bark()); // Own method

// Prototype chain: myDog → Dog.prototype → Animal.prototype → Object.prototype → null
```

### **12. Difference between prototypal and classical inheritance**

| **Classical Inheritance**     | **Prototypal Inheritance**            |
| ----------------------------- | ------------------------------------- |
| Classes are blueprints        | Objects inherit directly from objects |
| Create instances from classes | Clone or extend existing objects      |
| Static inheritance hierarchy  | Dynamic inheritance                   |
| Found in Java, C#, C++        | Native to JavaScript                  |

```javascript
// Classical (ES6 Classes - syntactic sugar over prototypal)
class Vehicle {
  constructor(type) {
    this.type = type;
  }

  move() {
    return `${this.type} is moving`;
  }
}

class Car extends Vehicle {
  constructor(brand) {
    super("car");
    this.brand = brand;
  }
}

// Pure Prototypal (JavaScript way)
const vehicle = {
  type: "vehicle",
  move() {
    return `${this.type} is moving`;
  },
};

const car = Object.create(vehicle);
car.type = "car";
car.brand = "Toyota";
```

### **13. What is a Temporal Dead Zone?**

The **Temporal Dead Zone (TDZ)** is the time between entering a scope and the variable declaration being reached.

```javascript
function example() {
  console.log(typeof a); // undefined (var is hoisted and initialized)
  console.log(typeof b); // ReferenceError: Cannot access 'b' before initialization
  console.log(typeof c); // ReferenceError: Cannot access 'c' before initialization

  var a = 1;
  let b = 2;
  const c = 3;
}

// TDZ Examples:
function tdz() {
  // TDZ for 'x' starts here
  console.log(x); // ReferenceError

  let x = 10; // TDZ for 'x' ends here
  console.log(x); // 10
}

// Practical TDZ issue:
function hoistingProblem() {
  let x = 1;

  if (true) {
    console.log(x); // ReferenceError due to TDZ
    let x = 2; // This creates a new 'x' in block scope
  }
}
```

### **14. Explain Implicit Type Coercion in JavaScript**

**Type coercion** is JavaScript's automatic conversion of values from one type to another.

```javascript
// String Coercion
console.log("5" + 3); // '53' (number to string)
console.log(String(123)); // '123'
console.log(123 + ""); // '123'

// Number Coercion
console.log("5" - 3); // 2 (string to number)
console.log(+"42"); // 42 (unary plus)
console.log(Number("42")); // 42

// Boolean Coercion
console.log(Boolean("")); // false
console.log(Boolean("0")); // true (non-empty string)
console.log(!!"hello"); // true (double negation)

// Falsy values: false, 0, -0, 0n, '', null, undefined, NaN
console.log(Boolean(0)); // false
console.log(Boolean([])); // true (empty array is truthy)
console.log(Boolean({})); // true (empty object is truthy)

// Complex coercion examples
console.log([] + []); // '' (empty string)
console.log([] + {}); // '[object Object]'
console.log({} + []); // 0 (in some contexts)
console.log(true + false); // 1
console.log(2 + true); // 3
console.log("2" + true); // '2true'
```

### **15. What is the currying function?**

**Currying** transforms a function with multiple arguments into a sequence of functions, each taking a single argument.

```javascript
// Regular function
function add(a, b, c) {
  return a + b + c;
}

// Curried version
function curriedAdd(a) {
  return function (b) {
    return function (c) {
      return a + b + c;
    };
  };
}

// ES6 Arrow function currying
const curriedAddArrow = (a) => (b) => (c) => a + b + c;

// Usage
const add5 = curriedAdd(5);
const add5And3 = add5(3);
const result = add5And3(2); // 10

// Practical currying example
function createValidator(regex) {
  return function (message) {
    return function (value) {
      return regex.test(value) ? { valid: true } : { valid: false, message };
    };
  };
}

const emailValidator = createValidator(/^[^\s@]+@[^\s@]+\.[^\s@]+$/);
const validateEmail = emailValidator("Invalid email format");

console.log(validateEmail("test@example.com")); // { valid: true }
console.log(validateEmail("invalid")); // { valid: false, message: 'Invalid email format' }

// Partial application with currying
function multiply(a) {
  return function (b) {
    return a * b;
  };
}

const double = multiply(2);
const triple = multiply(3);

console.log(double(5)); // 10
console.log(triple(5)); // 15
```

### **16. What are the differences between pure and impure functions?**

**Pure Functions:**

- Same input always produces same output
- No side effects
- Don't modify external state
- Predictable and testable

**Impure Functions:**

- May produce different outputs for same input
- Have side effects
- Modify external state
- Harder to test and debug

```javascript
// PURE FUNCTIONS
function add(a, b) {
  return a + b; // Always returns same result for same inputs
}

function multiply(numbers) {
  return numbers.map((num) => num * 2); // Doesn't modify original array
}

function calculateArea(radius) {
  return Math.PI * radius * radius; // No external dependencies
}

// IMPURE FUNCTIONS
let counter = 0;
function incrementCounter() {
  counter++; // Modifies external state
  return counter;
}

function addToArray(arr, item) {
  arr.push(item); // Modifies the input array
  return arr;
}

function getCurrentTime() {
  return new Date().getTime(); // Different output each time
}

function logMessage(message) {
  console.log(message); // Side effect (I/O operation)
  return message;
}

// Converting impure to pure
// Impure
function updateUser(user, newData) {
  user.name = newData.name; // Mutates input
  user.email = newData.email;
  return user;
}

// Pure version
function updateUserPure(user, newData) {
  return {
    ...user,
    ...newData, // Returns new object, doesn't mutate input
  };
}

// Benefits of pure functions:
// 1. Easier testing
// 2. Predictable behavior
// 3. Cacheable (memoization)
// 4. Safer for concurrent execution
// 5. Easier debugging
```

### **17. What is memoization?**

**Memoization** is an optimization technique that stores expensive function call results in cache.

```javascript
// Basic memoization implementation
function memoize(fn) {
  const cache = new Map();

  return function (...args) {
    const key = JSON.stringify(args);

    if (cache.has(key)) {
      console.log("Cache hit");
      return cache.get(key);
    }

    console.log("Computing...");
    const result = fn.apply(this, args);
    cache.set(key, result);
    return result;
  };
}

// Expensive function example
function fibonacci(n) {
  if (n <= 1) return n;
  return fibonacci(n - 1) + fibonacci(n - 2);
}

const memoizedFib = memoize(fibonacci);

console.log(memoizedFib(10)); // Computing... 55
console.log(memoizedFib(10)); // Cache hit 55

// Advanced memoization with TTL (Time To Live)
function memoizeWithTTL(fn, ttl = 5000) {
  const cache = new Map();

  return function (...args) {
    const key = JSON.stringify(args);
    const cached = cache.get(key);

    if (cached && Date.now() - cached.timestamp < ttl) {
      return cached.value;
    }

    const result = fn.apply(this, args);
    cache.set(key, {
      value: result,
      timestamp: Date.now(),
    });

    return result;
  };
}

// Memoization with LRU (Least Recently Used) cache
function memoizeLRU(fn, maxSize = 100) {
  const cache = new Map();

  return function (...args) {
    const key = JSON.stringify(args);

    if (cache.has(key)) {
      const value = cache.get(key);
      cache.delete(key);
      cache.set(key, value); // Move to end (most recent)
      return value;
    }

    const result = fn.apply(this, args);

    if (cache.size >= maxSize) {
      const firstKey = cache.keys().next().value;
      cache.delete(firstKey);
    }

    cache.set(key, result);
    return result;
  };
}
```

### **18. What are closures and their uses?**

A **closure** gives inner functions access to outer function's variables even after the outer function has returned.

```javascript
// Basic closure
function outerFunction(x) {
  // Outer function's variable
  const outerVariable = x;

  return function innerFunction(y) {
    // Inner function has access to outerVariable
    return outerVariable + y;
  };
}

const add10 = outerFunction(10);
console.log(add10(5)); // 15

// Closure use cases:

// 1. Data Privacy
function createCounter() {
  let count = 0; // Private variable

  return {
    increment: () => ++count,
    decrement: () => --count,
    getCount: () => count,
  };
}

const counter = createCounter();
console.log(counter.getCount()); // 0
counter.increment();
console.log(counter.getCount()); // 1
// count is not accessible directly

// 2. Module Pattern
const mathModule = (function () {
  let result = 0;

  return {
    add: (x) => (result += x),
    multiply: (x) => (result *= x),
    getResult: () => result,
    reset: () => (result = 0),
  };
})();

// 3. Function Factories
function createMultiplier(multiplier) {
  return function (x) {
    return x * multiplier;
  };
}

const double = createMultiplier(2);
const triple = createMultiplier(3);

// 4. Event Handlers with State
function setupButton(name) {
  let clickCount = 0;

  return function () {
    clickCount++;
    console.log(`${name} clicked ${clickCount} times`);
  };
}

document
  .getElementById("btn")
  .addEventListener("click", setupButton("My Button"));

// 5. Partial Application
function partial(fn, ...args1) {
  return function (...args2) {
    return fn(...args1, ...args2);
  };
}

function greet(greeting, name) {
  return `${greeting}, ${name}!`;
}

const sayHello = partial(greet, "Hello");
console.log(sayHello("John")); // Hello, John!
```

### **19. What is debouncing and throttling?**

**Debouncing** delays function execution until after wait time has passed since last call.
**Throttling** limits function execution to once per specified time period.

```javascript
// DEBOUNCING - Wait for pause in activity
function debounce(func, wait) {
  let timeout;

  return function executedFunction(...args) {
    const later = () => {
      clearTimeout(timeout);
      func(...args);
    };

    clearTimeout(timeout);
    timeout = setTimeout(later, wait);
  };
}

// Use case: Search input
const searchAPI = (query) => {
  console.log("Searching for:", query);
  // API call here
};

const debouncedSearch = debounce(searchAPI, 300);

// Only calls API after user stops typing for 300ms
document.getElementById("search").addEventListener("input", (e) => {
  debouncedSearch(e.target.value);
});

// THROTTLING - Limit execution frequency
function throttle(func, limit) {
  let inThrottle;

  return function (...args) {
    if (!inThrottle) {
      func.apply(this, args);
      inThrottle = true;
      setTimeout(() => (inThrottle = false), limit);
    }
  };
}

// Use case: Scroll events
const handleScroll = () => {
  console.log("Scroll event");
  // Update scroll position, lazy load images, etc.
};

const throttledScroll = throttle(handleScroll, 100);
window.addEventListener("scroll", throttledScroll);

// Advanced debounce with immediate execution option
function debounceAdvanced(func, wait, immediate = false) {
  let timeout;

  return function executedFunction(...args) {
    const later = () => {
      timeout = null;
      if (!immediate) func(...args);
    };

    const callNow = immediate && !timeout;
    clearTimeout(timeout);
    timeout = setTimeout(later, wait);

    if (callNow) func(...args);
  };
}

// Advanced throttle with trailing execution
function throttleAdvanced(func, limit, trailing = true) {
  let inThrottle;
  let lastArgs;

  return function (...args) {
    lastArgs = args;

    if (!inThrottle) {
      func.apply(this, args);
      inThrottle = true;

      setTimeout(() => {
        inThrottle = false;
        if (trailing && lastArgs) {
          func.apply(this, lastArgs);
          lastArgs = null;
        }
      }, limit);
    }
  };
}
```

### **20. What is the difference between call, apply, and bind?**

All three methods control the `this` context of functions, but they work differently.

```javascript
const person = {
  firstName: "John",
  lastName: "Doe",
};

function greet(greeting, punctuation) {
  return `${greeting} ${this.firstName} ${this.lastName}${punctuation}`;
}

// CALL - Invokes immediately, arguments passed individually
const result1 = greet.call(person, "Hello", "!");
console.log(result1); // "Hello John Doe!"

// APPLY - Invokes immediately, arguments passed as array
const result2 = greet.apply(person, ["Hi", "?"]);
console.log(result2); // "Hi John Doe?"

// BIND - Returns new function, doesn't invoke immediately
const boundGreet = greet.bind(person);
const result3 = boundGreet("Hey", ".");
console.log(result3); // "Hey John Doe."

// Partial application with bind
const sayHello = greet.bind(person, "Hello");
console.log(sayHello("!")); // "Hello John Doe!"

// Practical examples:

// 1. Borrowing methods
const numbers = [1, 2, 3, 4, 5];
const max = Math.max.apply(null, numbers); // or Math.max(...numbers)
console.log(max); // 5

// 2. Converting NodeList to Array
const nodeList = document.querySelectorAll("div");
const arrayFromNodes = Array.prototype.slice.call(nodeList);

// 3. Function binding for event handlers
class Button {
  constructor(element) {
    this.element = element;
    this.clickCount = 0;

    // Without bind, 'this' would refer to the button element
    this.element.addEventListener("click", this.handleClick.bind(this));
  }

  handleClick(event) {
    this.clickCount++;
    console.log(`Button clicked ${this.clickCount} times`);
  }
}

// 4. Creating reusable functions
function multiply(a, b) {
  return a * b;
}

const double = multiply.bind(null, 2);
const triple = multiply.bind(null, 3);

console.log(double(5)); // 10
console.log(triple(5)); // 15

// Performance considerations:
// - call and apply are slightly faster than bind
// - bind creates a new function (memory overhead)
// - Use bind for event handlers and partial application
// - Use call/apply for immediate execution with different context
```

---

**Continue to IMP_README_2.md for Intermediate concepts...**
