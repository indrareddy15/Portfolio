//  In JavaScript, how many different methods can you make an object?
// What is Object Destructuring?
// Difference between prototypal and classical inheritance
// What is a prototype chain
// What is a Temporal Dead Zone?
//  Explain Implicit Type Coercion in javascript.
// What is the purpose of the this keyword in JavaScript?
// What is the Difference Between call, apply, and bind
// What is JSON and its common operations
// What is the purpose of the array slice method
// What is the purpose of the array splice method
// What is the difference between slice and splice
// What is the difference between == and === operators
// What are lambda expressions or arrow functions
// What is a first order function
// What is the currying function
// What are the differences between pure and impure functions? ****
// What is the purpose of the let keyword
// What is the difference between let and var
// How do you redeclare variables in a switch block without an error *****
// What is an IIFE (Immediately Invoked Function Expression) and How to invoke an IIFE without any extra brackets?
// What is memoization ***
// What is Hoisting
// What are closures and What are the uses of closures?
// What are Classes in ES6
// What are modules Why do you need modules
// What is a service worker *****
// How do you manipulate DOM using a service worker ****
// What is web storage and What is a Cookie
// What are the differences between cookie, local storage and session storage
// What is Promise in JavaScript and Why do you need a promise and What is promise chaining
// What is a callback function and Why do we need callbacks and What is a callback hell
// What are the pros and cons of promises over callbacks
// What do you mean by strict mode in javascript and characteristics of javascript strict-mode?
// What is the difference between null and undefined
// What is eval
// What is the difference between window and document ****
// What is isNaN and What is the difference between isNaN and Number.isNaN?
// What are the differences between undeclared and undefined variables
// What is event capturing
// What is event bubbling
// Is JavaScript a compiled or interpreted language
// Is JavaScript a case-sensitive language
// What is the use of preventDefault method and What is the use of stopPropagation method
// What is BOM
// What is the use of setTimeout and What is the use of setInterval
// What is an event delegation
// What are PWAs
// How do you make first letter of the string in an uppercase
//How do you display the current date in javascript
// What is a polyfill
// What are break and continue statements
//What is a Regular Expression
// What is a conditional operator in javascript and Can you apply chaining on conditional operator
// What is a spread operator and What is a rest operator and what is main difference between rest and spread operator
// What is a Set What is a WeakSet and What are the differences between WeakSet and Set
// What is a Map What is a WeakMap and What are the differences between WeakMap and Map
//What are the different data types present in javascript?
// What are primitive data types and non premitive datatypes
// What are the various statements in error handling
//What is babel
// What is the event loop
// What are tasks in event loop
// What are different event loops
// What is microtask
// What is microtask queue
// What is the purpose of queueMicrotask
// What is the call stack
// What is the event queue
// What is global execution context?
// What is function execution context?
// What are the phases of execution context?
// How do you sort elements in an array
// How do you reverse an array
// What is typescript
// What are the differences between javascript and typescript and What are the advantages of typescript over javascript
// What are the different methods to find HTML elements in DOM
// What is V8 JavaScript engine
// List down some of the features of ES6
// How do you swap variables in destructuring assignment
// What are typed arrays
// What is for...of statement and What are the differences between for...of and for...in statements
//What is the difference between a parameter and an argument
//What is the purpose of some method in arrays
// How do you combine two or more arrays
// What is the difference between Shallow and Deep copy
// How do you combine two or more arrays
// What is a thunk function and What are asynchronous thunks
// How do you remove falsy values from an array
// How do you get unique values of an array
// What is the easiest way to convert an array to an object
// What is AJAX and What are the different ways to deal with Asynchronous Code
// What is an async function
// How do you reverse an array without modifying original array?
// What is debouncing? with example and usecases
// What is throttling? with example and usecases
// What is optional chaining?
// What is pass by value and pass by reference?
// What are the examples of built-in higher order functions?
// How do you create polyfills for map, filter and reduce methods?
// What is the difference between map and forEach functions?
// What is Lexical Scope
// What are the array mutation methods?
// What are the string mutation methods?
// What do you mean by Self Invoking Functions?
// What are the types of errors in javascript?
// What is recursion in a programming language? example factoral in JS
//  What is the use of a constructor function in javascript?
// What is DOM?

//*** CODING */
// Write a Program to reverse a string in JavaScript.
// Write a Program to check whether a string is a palindrome string.
// Find the largest number in an array in JavaScript.
// How Remove the first element from an array in JavaScript?
// Write a Program to use a callback function?
// Write a Program to find a sum of an array?
// Write a Program to check if a number is prime or not?
// Write a Program to print Fibonacci sequence up to n terms?
// Write a Program to find factorial of a number?
// Write a Program to merge two arrays in JavaScript?
//Find the Intersection of Two Arrays in JavaScript?