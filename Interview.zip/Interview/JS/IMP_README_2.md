# JavaScript Interview Questions & Answers - Part 2 (Intermediate Concepts)

_Mid-level concepts essential for JavaScript development_

---

## 🔶 **INTERMEDIATE CONCEPTS**

### **21. What is Hoisting?**

**Hoisting** is JavaScript's behavior of moving variable and function declarations to the top of their scope during compilation phase.

```javascript
// What you write:
console.log(x); // undefined (not error)
var x = 5;
sayHello(); // "Hello!" (works)

function sayHello() {
  console.log("Hello!");
}

// What JavaScript interpreter sees:
var x; // hoisted declaration
function sayHello() {
  // hoisted function
  console.log("Hello!");
}
console.log(x); // undefined
x = 5; // assignment stays in place

// Different hoisting behaviors:
console.log(a); // undefined
console.log(b); // ReferenceError: Cannot access 'b' before initialization
console.log(c); // ReferenceError: Cannot access 'c' before initialization

var a = 1;
let b = 2;
const c = 3;

// Function hoisting differences:
// Function declaration - fully hoisted
console.log(declaration()); // "I'm hoisted!"
function declaration() {
  return "I'm hoisted!";
}

// Function expression - not hoisted
console.log(expression()); // TypeError: expression is not a function
var expression = function () {
  return "I'm not hoisted!";
};

// Arrow function - not hoisted
console.log(arrow()); // ReferenceError: Cannot access 'arrow' before initialization
const arrow = () => "I'm not hoisted!";
```

### **22. What is the purpose of the `this` keyword?**

`this` keyword refers to the object that is currently executing the function. Its value depends on how the function is called.

```javascript
// Global context
console.log(this); // window (browser) or global (Node.js)

// Object method
const person = {
  name: "John",
  greet: function () {
    return `Hello, I'm ${this.name}`; // this refers to person object
  },
};
console.log(person.greet()); // "Hello, I'm John"

// Function context
function regularFunction() {
  console.log(this); // window in non-strict mode, undefined in strict mode
}

// Arrow functions - lexical this
const obj = {
  name: "Alice",
  regularMethod: function () {
    console.log(this.name); // 'Alice'

    const arrowFunction = () => {
      console.log(this.name); // 'Alice' (inherits from regularMethod)
    };
    arrowFunction();

    function nestedFunction() {
      console.log(this.name); // undefined (this is window/global)
    }
    nestedFunction();
  },
};

// Constructor function
function Person(name) {
  this.name = name;
  this.greet = function () {
    return `Hello, I'm ${this.name}`;
  };
}
const john = new Person("John");
console.log(john.greet()); // "Hello, I'm John"

// Event handlers
document.getElementById("button").addEventListener("click", function () {
  console.log(this); // refers to the button element
});

// Explicit binding examples covered in call/apply/bind section
```

### **23. What are Promises and promise chaining?**

**Promises** represent the eventual completion or failure of an asynchronous operation.

```javascript
// Creating a Promise
const myPromise = new Promise((resolve, reject) => {
  const success = Math.random() > 0.5;

  setTimeout(() => {
    if (success) {
      resolve("Operation successful!");
    } else {
      reject(new Error("Operation failed!"));
    }
  }, 1000);
});

// Using Promises
myPromise
  .then((result) => {
    console.log(result);
    return "Next step";
  })
  .then((result) => {
    console.log(result);
    return "Final step";
  })
  .catch((error) => {
    console.error("Error:", error.message);
  })
  .finally(() => {
    console.log("Promise settled");
  });

// Promise chaining example
function fetchUser(id) {
  return fetch(`/api/users/${id}`).then((response) => {
    if (!response.ok) {
      throw new Error("User not found");
    }
    return response.json();
  });
}

function fetchPosts(userId) {
  return fetch(`/api/posts?userId=${userId}`).then((response) =>
    response.json()
  );
}

// Chaining promises
fetchUser(1)
  .then((user) => {
    console.log("User:", user);
    return fetchPosts(user.id);
  })
  .then((posts) => {
    console.log("Posts:", posts);
  })
  .catch((error) => {
    console.error("Error in chain:", error);
  });

// Promise utility methods
const promise1 = Promise.resolve(3);
const promise2 = new Promise((resolve) =>
  setTimeout(() => resolve("foo"), 1000)
);
const promise3 = Promise.resolve(42);

// Promise.all - waits for all promises
Promise.all([promise1, promise2, promise3]).then((values) =>
  console.log(values)
); // [3, 'foo', 42]

// Promise.race - resolves with first settled promise
Promise.race([promise1, promise2, promise3]).then((value) =>
  console.log(value)
); // 3

// Promise.allSettled - waits for all promises regardless of outcome
Promise.allSettled([promise1, Promise.reject("error"), promise3]).then(
  (results) => console.log(results)
);
// [{status: 'fulfilled', value: 3}, {status: 'rejected', reason: 'error'}, {status: 'fulfilled', value: 42}]
```

### **24. What is a callback function and callback hell?**

A **callback** is a function passed as an argument to another function, executed at a later time.

```javascript
// Basic callback example
function greet(name, callback) {
  console.log("Hello " + name);
  callback();
}

function sayGoodbye() {
  console.log("Goodbye!");
}

greet("John", sayGoodbye);

// Asynchronous callbacks
function fetchData(callback) {
  setTimeout(() => {
    const data = { id: 1, name: "John" };
    callback(null, data); // Node.js style: error-first callback
  }, 1000);
}

fetchData((error, data) => {
  if (error) {
    console.error("Error:", error);
  } else {
    console.log("Data:", data);
  }
});

// CALLBACK HELL - Nested callbacks that become hard to read and maintain
function getUserData(userId, callback) {
  setTimeout(() => callback(null, { id: userId, name: "John" }), 100);
}

function getUserPosts(userId, callback) {
  setTimeout(() => callback(null, [{ id: 1, title: "Post 1" }]), 100);
}

function getPostComments(postId, callback) {
  setTimeout(() => callback(null, [{ id: 1, text: "Comment 1" }]), 100);
}

// Callback hell example
getUserData(1, (err, user) => {
  if (err) return console.error(err);

  getUserPosts(user.id, (err, posts) => {
    if (err) return console.error(err);

    getPostComments(posts[0].id, (err, comments) => {
      if (err) return console.error(err);

      console.log("Final result:", { user, posts, comments });
      // This is callback hell - hard to read and maintain
    });
  });
});

// Solutions to callback hell:

// 1. Named functions
function handleComments(err, comments) {
  if (err) return console.error(err);
  console.log("Comments:", comments);
}

function handlePosts(err, posts) {
  if (err) return console.error(err);
  getPostComments(posts[0].id, handleComments);
}

function handleUser(err, user) {
  if (err) return console.error(err);
  getUserPosts(user.id, handlePosts);
}

getUserData(1, handleUser);

// 2. Promises (better solution)
function getUserDataPromise(userId) {
  return new Promise((resolve) => {
    setTimeout(() => resolve({ id: userId, name: "John" }), 100);
  });
}

// 3. Async/await (best solution)
async function fetchAllData(userId) {
  try {
    const user = await getUserDataPromise(userId);
    const posts = await getUserPostsPromise(user.id);
    const comments = await getPostCommentsPromise(posts[0].id);
    return { user, posts, comments };
  } catch (error) {
    console.error("Error:", error);
  }
}
```

### **25. What are the pros and cons of promises over callbacks?**

| **Promises** | **Callbacks** |
| ------------ | ------------- |

**Promises Pros:**

- Better error handling with `.catch()`
- Avoids callback hell
- Better composition with chaining
- Built-in with modern JavaScript
- Works well with async/await

**Promises Cons:**

- Additional learning curve
- Not supported in very old browsers
- Can be overkill for simple async operations

**Callbacks Pros:**

- Simple to understand
- Universal support
- Lower overhead
- Direct control flow

**Callbacks Cons:**

- Callback hell (pyramid of doom)
- Error handling becomes complex
- Hard to compose multiple async operations
- Inversion of control issues

```javascript
// Callback approach
function fetchUserCallback(id, callback) {
  setTimeout(() => {
    if (id <= 0) {
      callback(new Error("Invalid ID"), null);
    } else {
      callback(null, { id, name: "John" });
    }
  }, 1000);
}

// Error handling with callbacks
fetchUserCallback(1, (error, user) => {
  if (error) {
    console.error("Error:", error.message);
    return;
  }

  fetchUserPosts(user.id, (error, posts) => {
    if (error) {
      console.error("Error:", error.message);
      return;
    }

    // More nested callbacks...
  });
});

// Promise approach
function fetchUserPromise(id) {
  return new Promise((resolve, reject) => {
    setTimeout(() => {
      if (id <= 0) {
        reject(new Error("Invalid ID"));
      } else {
        resolve({ id, name: "John" });
      }
    }, 1000);
  });
}

// Better error handling and composition
fetchUserPromise(1)
  .then((user) => fetchUserPostsPromise(user.id))
  .then((posts) => fetchPostCommentsPromise(posts[0].id))
  .then((comments) => console.log("All data fetched"))
  .catch((error) => console.error("Any error in chain:", error));

// Async/await (best of both worlds)
async function fetchAllData(id) {
  try {
    const user = await fetchUserPromise(id);
    const posts = await fetchUserPostsPromise(user.id);
    const comments = await fetchPostCommentsPromise(posts[0].id);
    return { user, posts, comments };
  } catch (error) {
    console.error("Error:", error);
    throw error;
  }
}
```

### **26. What is an IIFE and how to invoke without extra brackets?**

**IIFE (Immediately Invoked Function Expression)** is a function that runs immediately after being defined.

```javascript
// Standard IIFE syntax
(function () {
  console.log("IIFE executed!");
})();

// Alternative with arrow function
(() => {
  console.log("Arrow IIFE executed!");
})();

// IIFE with parameters
(function (name, age) {
  console.log(`Hello ${name}, you are ${age} years old`);
})("John", 25);

// Ways to invoke IIFE without extra brackets:

// 1. Unary operators
!(function () {
  console.log("Using !");
})();
+(function () {
  console.log("Using +");
})();
-(function () {
  console.log("Using -");
})();
~(function () {
  console.log("Using ~");
})();

// 2. void operator
void (function () {
  console.log("Using void");
})();

// 3. typeof operator
typeof (function () {
  console.log("Using typeof");
})();

// 4. delete operator
delete (function () {
  console.log("Using delete");
})();

// 5. Assignment
var result = (function () {
  console.log("Using assignment");
  return "result";
})();

// 6. Logical operators
true &&
  (function () {
    console.log("Using &&");
  })();
false ||
  (function () {
    console.log("Using ||");
  })();

// Practical IIFE examples:

// 1. Module pattern
const myModule = (function () {
  let privateVariable = 0;

  return {
    increment: function () {
      privateVariable++;
    },
    getCount: function () {
      return privateVariable;
    },
  };
})();

// 2. Avoiding global pollution
(function () {
  // All variables here are private
  const config = { apiUrl: "https://api.example.com" };
  const helper = function () {
    /* helper function */
  };

  // Only expose what's needed
  window.MyApp = {
    init: function () {
      console.log("App initialized");
    },
  };
})();

// 3. Loop variable capture (classic problem)
// Problem:
for (var i = 0; i < 3; i++) {
  setTimeout(function () {
    console.log(i); // Prints 3, 3, 3
  }, 100);
}

// Solution with IIFE:
for (var i = 0; i < 3; i++) {
  (function (j) {
    setTimeout(function () {
      console.log(j); // Prints 0, 1, 2
    }, 100);
  })(i);
}
```

### **27. What are Classes in ES6?**

**ES6 Classes** provide a cleaner syntax for creating objects and implementing inheritance.

```javascript
// Basic class syntax
class Person {
  // Constructor method
  constructor(firstName, lastName, age) {
    this.firstName = firstName;
    this.lastName = lastName;
    this.age = age;
  }

  // Instance method
  getFullName() {
    return `${this.firstName} ${this.lastName}`;
  }

  // Getter
  get fullName() {
    return this.getFullName();
  }

  // Setter
  set fullName(value) {
    [this.firstName, this.lastName] = value.split(" ");
  }

  // Static method
  static species() {
    return "Homo sapiens";
  }

  // Static property (ES2022)
  static planet = "Earth";
}

// Creating instances
const person1 = new Person("John", "Doe", 30);
console.log(person1.fullName); // "John Doe"
console.log(Person.species()); // "Homo sapiens"

// Class inheritance
class Student extends Person {
  constructor(firstName, lastName, age, studentId) {
    super(firstName, lastName, age); // Call parent constructor
    this.studentId = studentId;
    this.courses = [];
  }

  // Override parent method
  getFullName() {
    return `Student: ${super.getFullName()}`;
  }

  // New method
  enrollInCourse(course) {
    this.courses.push(course);
    return this;
  }

  // Method chaining
  addGrade(course, grade) {
    const courseIndex = this.courses.findIndex((c) => c.name === course);
    if (courseIndex !== -1) {
      this.courses[courseIndex].grade = grade;
    }
    return this;
  }
}

const student = new Student("Alice", "Smith", 20, "S12345");
student
  .enrollInCourse({ name: "Math", grade: null })
  .addGrade("Math", "A")
  .enrollInCourse({ name: "Physics", grade: null });

// Private fields and methods (ES2022)
class BankAccount {
  #balance = 0; // Private field
  #accountNumber; // Private field

  constructor(initialBalance, accountNumber) {
    this.#balance = initialBalance;
    this.#accountNumber = accountNumber;
  }

  // Private method
  #validateAmount(amount) {
    return amount > 0 && typeof amount === "number";
  }

  // Public methods
  deposit(amount) {
    if (this.#validateAmount(amount)) {
      this.#balance += amount;
      return this;
    }
    throw new Error("Invalid amount");
  }

  withdraw(amount) {
    if (this.#validateAmount(amount) && amount <= this.#balance) {
      this.#balance -= amount;
      return this;
    }
    throw new Error("Invalid withdrawal");
  }

  getBalance() {
    return this.#balance;
  }
}

const account = new BankAccount(1000, "ACC123");
account.deposit(500).withdraw(200);
console.log(account.getBalance()); // 1300
// console.log(account.#balance); // SyntaxError: Private field '#balance' must be declared in an enclosing class
```

### **28. What are modules and why do you need them?**

**Modules** help organize code into separate files and control what's exported/imported.

```javascript
// math.js - Named exports
export function add(a, b) {
  return a + b;
}

export function subtract(a, b) {
  return a - b;
}

export const PI = 3.14159;

// calculator.js - Default export
class Calculator {
  constructor() {
    this.result = 0;
  }

  add(value) {
    this.result += value;
    return this;
  }

  multiply(value) {
    this.result *= value;
    return this;
  }

  getResult() {
    return this.result;
  }
}

export default Calculator;

// Mixed exports
export { Calculator as Calc };
export function square(x) {
  return x * x;
}

// utils.js - Re-exporting
export { add, subtract } from "./math.js";
export { default as Calculator } from "./calculator.js";

// main.js - Importing
import Calculator from "./calculator.js"; // Default import
import { add, subtract, PI } from "./math.js"; // Named imports
import { Calculator as Calc } from "./calculator.js"; // Aliased import
import * as MathUtils from "./math.js"; // Namespace import

// Dynamic imports
async function loadModule() {
  const { add } = await import("./math.js");
  console.log(add(2, 3)); // 5
}

// Why modules are needed:

// 1. Code Organization
// - Separate concerns
// - Easier maintenance
// - Better file structure

// 2. Namespace Management
// - Avoid global pollution
// - Prevent naming conflicts
// - Explicit dependencies

// 3. Reusability
// - Share code between projects
// - Create libraries
// - Better testing

// 4. Tree Shaking
// - Bundle only used code
// - Smaller bundle sizes
// - Better performance

// 5. Lazy Loading
// - Load modules on demand
// - Faster initial load
// - Better user experience

// Module patterns before ES6:

// 1. Revealing Module Pattern
const MyModule = (function () {
  let privateVar = 0;

  function privateMethod() {
    return privateVar;
  }

  return {
    publicMethod: function () {
      return privateMethod();
    },
    increment: function () {
      privateVar++;
    },
  };
})();

// 2. CommonJS (Node.js)
// module.exports = { add, subtract };
// const { add } = require('./math');

// 3. AMD (RequireJS)
// define(['dependency'], function(dep) {
//     return { add, subtract };
// });
```

### **29. What do you mean by strict mode and its characteristics?**

**Strict mode** is a way to opt into a restricted variant of JavaScript that eliminates silent errors and improves performance.

```javascript
"use strict"; // Global strict mode

// Strict mode characteristics:

// 1. Variables must be declared
function strictExample() {
  "use strict";
  // x = 10; // ReferenceError: x is not defined
  let x = 10; // Must use var, let, or const
}

// 2. Deleting variables, functions, or arguments is not allowed
("use strict");
var y = 10;
// delete y; // SyntaxError: Delete of an unqualified identifier in strict mode

function testFunc() {}
// delete testFunc; // SyntaxError

// 3. Duplicate parameter names are not allowed
// function duplicate(a, a) {} // SyntaxError in strict mode

// 4. Octal literals are not allowed
// var num = 010; // SyntaxError in strict mode
var num = 8; // Use decimal instead

// 5. Writing to read-only properties throws error
("use strict");
var obj = {};
Object.defineProperty(obj, "readOnly", {
  value: 42,
  writable: false,
});
// obj.readOnly = 43; // TypeError: Cannot assign to read only property

// 6. Deleting non-deletable properties throws error
// delete Object.prototype; // TypeError in strict mode

// 7. 'this' is undefined in functions (not global object)
function strictThis() {
  "use strict";
  console.log(this); // undefined (not window/global)
}

// 8. with statement is not allowed
// with (Math) { // SyntaxError in strict mode
//     x = cos(2);
// }

// 9. eval creates its own scope
("use strict");
eval("var evalVar = 10");
// console.log(evalVar); // ReferenceError: evalVar is not defined

// 10. Reserved words are truly reserved
// var implements = 10; // SyntaxError in strict mode
// var interface = 20;  // SyntaxError in strict mode

// Benefits of strict mode:
// 1. Catches common coding mistakes
// 2. Prevents accidental globals
// 3. Eliminates this coercion
// 4. Disallows duplicate property names
// 5. Makes eval safer
// 6. Reserves keywords for future versions
// 7. Better performance (engines can optimize better)

// Function-level strict mode
function mixedMode() {
  "use strict";
  // Strict mode only in this function
  let x = 10;
}

function normalMode() {
  // Normal JavaScript mode
  y = 20; // Creates global variable
}

// ES6 modules are automatically in strict mode
// export function autoStrict() {
//     // This is automatically in strict mode
// }

// Class bodies are automatically in strict mode
class AutoStrictClass {
  method() {
    // This is automatically in strict mode
    console.log(this); // 'this' behavior is strict
  }
}
```

### **30. What is the difference between let and var?**

| Feature                | `var`                                    | `let`                             |
| ---------------------- | ---------------------------------------- | --------------------------------- |
| **Scope**              | Function scoped                          | Block scoped                      |
| **Hoisting**           | Hoisted and initialized with `undefined` | Hoisted but not initialized (TDZ) |
| **Redeclaration**      | Allowed                                  | Not allowed in same scope         |
| **Global object**      | Added to global object                   | Not added to global object        |
| **Temporal Dead Zone** | No                                       | Yes                               |

```javascript
// 1. SCOPE DIFFERENCES
function scopeExample() {
  if (true) {
    var varVariable = "I am var";
    let letVariable = "I am let";
    const constVariable = "I am const";
  }

  console.log(varVariable); // 'I am var' (accessible)
  // console.log(letVariable); // ReferenceError: letVariable is not defined
  // console.log(constVariable); // ReferenceError: constVariable is not defined
}

// 2. HOISTING DIFFERENCES
console.log(hoistedVar); // undefined (hoisted and initialized)
// console.log(hoistedLet); // ReferenceError: Cannot access before initialization

var hoistedVar = "var value";
let hoistedLet = "let value";

// 3. REDECLARATION
var name = "John";
var name = "Jane"; // OK with var

let age = 25;
// let age = 30; // SyntaxError: Identifier 'age' has already been declared

// 4. GLOBAL OBJECT PROPERTY
var globalVar = "I am global var";
let globalLet = "I am global let";

console.log(window.globalVar); // 'I am global var' (in browser)
console.log(window.globalLet); // undefined

// 5. LOOP VARIABLE BEHAVIOR
// Problem with var:
for (var i = 0; i < 3; i++) {
  setTimeout(() => {
    console.log("var:", i); // Prints: 3, 3, 3
  }, 100);
}

// Solution with let:
for (let j = 0; j < 3; j++) {
  setTimeout(() => {
    console.log("let:", j); // Prints: 0, 1, 2
  }, 100);
}

// 6. TEMPORAL DEAD ZONE
function tdz() {
  console.log(typeof varTDZ); // 'undefined'
  // console.log(typeof letTDZ); // ReferenceError

  var varTDZ = "var";
  let letTDZ = "let";
}

// 7. FUNCTION DECLARATIONS IN BLOCKS
if (true) {
  // Function declaration behavior differs in strict vs non-strict mode
  function blockFunction() {
    return "I am in a block";
  }
}

// 8. PRACTICAL EXAMPLE - Event Listeners
const buttons = document.querySelectorAll("button");

// Problem with var:
for (var k = 0; k < buttons.length; k++) {
  buttons[k].addEventListener("click", function () {
    console.log("Button", k, "clicked"); // Always logs last value of k
  });
}

// Solution with let:
for (let m = 0; m < buttons.length; m++) {
  buttons[m].addEventListener("click", function () {
    console.log("Button", m, "clicked"); // Logs correct value
  });
}

// Alternative solutions for var:
// Using IIFE:
for (var n = 0; n < buttons.length; n++) {
  (function (index) {
    buttons[index].addEventListener("click", function () {
      console.log("Button", index, "clicked");
    });
  })(n);
}

// Using bind:
for (var p = 0; p < buttons.length; p++) {
  buttons[p].addEventListener(
    "click",
    function (index) {
      console.log("Button", index, "clicked");
    }.bind(null, p)
  );
}
```

### **31. What are arrow functions?**

**Arrow functions** provide a shorter syntax for writing functions and have different `this` binding behavior.

```javascript
// Traditional function vs Arrow function
function traditional(a, b) {
  return a + b;
}

const arrow = (a, b) => a + b;

// Different arrow function syntaxes:

// No parameters
const greet = () => "Hello World!";

// Single parameter (parentheses optional)
const square = (x) => x * x;
const squareWithParens = (x) => x * x;

// Multiple parameters
const add = (a, b) => a + b;

// Block body (must use return)
const multiply = (a, b) => {
  const result = a * b;
  return result;
};

// Returning object literal (wrap in parentheses)
const createUser = (name, age) => ({
  name: name,
  age: age,
  created: new Date(),
});

// KEY DIFFERENCES FROM REGULAR FUNCTIONS:

// 1. 'this' binding (lexical this)
const obj = {
  name: "John",

  regularMethod: function () {
    console.log("Regular:", this.name); // 'John'

    const innerRegular = function () {
      console.log("Inner regular:", this.name); // undefined (this is window/global)
    };

    const innerArrow = () => {
      console.log("Inner arrow:", this.name); // 'John' (inherits this)
    };

    innerRegular();
    innerArrow();
  },

  arrowMethod: () => {
    console.log("Arrow method:", this.name); // undefined (this is global)
  },
};

// 2. No 'arguments' object
function regularFunction() {
  console.log(arguments); // Arguments object available
}

const arrowFunction = (...args) => {
  console.log(args); // Must use rest parameters
};

// 3. Cannot be used as constructors
function RegularConstructor(name) {
  this.name = name;
}
const instance1 = new RegularConstructor("John"); // Works

const ArrowConstructor = (name) => {
  this.name = name;
};
// const instance2 = new ArrowConstructor('John'); // TypeError

// 4. No prototype property
console.log(RegularConstructor.prototype); // Object
console.log(ArrowConstructor.prototype); // undefined

// 5. Cannot be used as generators
function* regularGenerator() {
  yield 1;
  yield 2;
}

// const arrowGenerator = *() => { // SyntaxError
//     yield 1;
// };

// PRACTICAL USE CASES:

// 1. Array methods
const numbers = [1, 2, 3, 4, 5];

const doubled = numbers.map((x) => x * 2);
const evens = numbers.filter((x) => x % 2 === 0);
const sum = numbers.reduce((acc, x) => acc + x, 0);

// 2. Event handlers (when you need to preserve this)
class Button {
  constructor(element) {
    this.element = element;
    this.clickCount = 0;

    // Arrow function preserves 'this'
    this.element.addEventListener("click", () => {
      this.clickCount++;
      console.log(`Clicked ${this.clickCount} times`);
    });
  }
}

// 3. Async operations
const fetchData = async () => {
  try {
    const response = await fetch("/api/data");
    return await response.json();
  } catch (error) {
    console.error("Error:", error);
  }
};

// 4. Higher-order functions
const createMultiplier = (factor) => (number) => number * factor;
const double = createMultiplier(2);
const triple = createMultiplier(3);

// 5. Conditional rendering (React-style)
const renderMessage = (user) =>
  user.isAdmin ? "Welcome Admin!" : "Welcome User!";

// WHEN NOT TO USE ARROW FUNCTIONS:

// 1. Object methods (when you need 'this')
const user = {
  name: "John",
  greet: function () {
    // Use regular function
    return `Hello, I'm ${this.name}`;
  },
};

// 2. Event handlers (when you need event target)
document.getElementById("button").addEventListener("click", function () {
  this.style.color = "red"; // 'this' refers to button element
});

// 3. Prototype methods
Array.prototype.customMethod = function () {
  return this.length; // 'this' refers to array instance
};
```

### **32. What is event bubbling and capturing?**

**Event bubbling** and **capturing** are two phases of event propagation in the DOM.

```javascript
// HTML structure:
// <div id="outer">
//     <div id="middle">
//         <div id="inner">Click me!</div>
//     </div>
// </div>

// EVENT PHASES:
// 1. Capturing phase (top to bottom)
// 2. Target phase (at target element)
// 3. Bubbling phase (bottom to top)

const outer = document.getElementById("outer");
const middle = document.getElementById("middle");
const inner = document.getElementById("inner");

// BUBBLING (default behavior)
outer.addEventListener("click", () => console.log("Outer bubbling"));
middle.addEventListener("click", () => console.log("Middle bubbling"));
inner.addEventListener("click", () => console.log("Inner bubbling"));

// When clicking inner div, output:
// Inner bubbling
// Middle bubbling
// Outer bubbling

// CAPTURING (set third parameter to true)
outer.addEventListener("click", () => console.log("Outer capturing"), true);
middle.addEventListener("click", () => console.log("Middle capturing"), true);
inner.addEventListener("click", () => console.log("Inner capturing"), true);

// When clicking inner div with both bubbling and capturing:
// Outer capturing
// Middle capturing
// Inner capturing
// Inner bubbling
// Middle bubbling
// Outer bubbling

// STOPPING PROPAGATION
inner.addEventListener("click", (event) => {
  console.log("Inner clicked");
  event.stopPropagation(); // Stops bubbling
});

// stopImmediatePropagation() - stops all further event handlers
inner.addEventListener("click", (event) => {
  console.log("First handler");
  event.stopImmediatePropagation();
});

inner.addEventListener("click", () => {
  console.log("Second handler"); // Won't execute
});

// EVENT DELEGATION (practical use of bubbling)
const list = document.getElementById("todo-list");

// Instead of adding listener to each item
list.addEventListener("click", (event) => {
  if (event.target.tagName === "LI") {
    console.log("List item clicked:", event.target.textContent);
  }

  if (event.target.classList.contains("delete-btn")) {
    event.target.parentElement.remove();
  }
});

// Dynamic content works automatically
function addTodoItem(text) {
  const li = document.createElement("li");
  li.innerHTML = `
        ${text}
        <button class="delete-btn">Delete</button>
    `;
  list.appendChild(li);
}

// CUSTOM EVENTS WITH BUBBLING
const customEvent = new CustomEvent("customClick", {
  bubbles: true,
  cancelable: true,
  detail: { message: "Custom event data" },
});

inner.addEventListener("customClick", (event) => {
  console.log("Custom event:", event.detail.message);
});

// Dispatch custom event
inner.dispatchEvent(customEvent);

// PRACTICAL EXAMPLE: Modal handling
document.addEventListener("click", (event) => {
  const modal = document.querySelector(".modal");

  // Close modal when clicking outside
  if (modal && !modal.contains(event.target)) {
    modal.style.display = "none";
  }
});

// Prevent modal from closing when clicking inside
document.querySelector(".modal-content").addEventListener("click", (event) => {
  event.stopPropagation();
});

// PERFORMANCE CONSIDERATIONS
// Good: One event listener for many elements
const table = document.querySelector("table");
table.addEventListener("click", (event) => {
  if (event.target.tagName === "TD") {
    // Handle cell click
  }
});

// Bad: Many event listeners
// document.querySelectorAll('td').forEach(cell => {
//     cell.addEventListener('click', handler); // Memory intensive
// });
```

---

**Continue to IMP_README_3.md for Basic concepts and Coding problems...**
