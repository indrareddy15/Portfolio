// How many times to create an object

// 1. Object Literal Syntax:
const obj1 = {
  key1: "Value1",
  key2: "Value2",
};

// 2. Object Constructor Syntax:
const obj2 = new Object();
obj2.key1 = "Value1";
obj2.key2 = "Value2";

// 3. Object.create()
const obj3 = Object.create(null);
obj3.key1 = "Value1";
obj3.key2 = "Value2";

// console.log(obj3.key1);

// 4. Dynmically Created Objects

const obj11 = {};
obj11.key1 = "value";
obj11.key2 = "value";

// 5. Object.assign()
const obj4 = Object.assign({}, { key1: "value1" }, { key2: "value2" });
const obj51 = Object.assign({}, { name: "Indra" }, { Dep: "Tech" });

// 6.Constructor Function

function Obj5(key1, key2) {
  this.key1 = key1;
  this.key2 = key2;
}

let myObj5 = new Obj5("Value1", "Value2");

// ES6 Class
class Obj6 {
  constructor(key1, key2) {
    this.key1 = key1;
    this.key2 = key2;
  }
}
let myObj6 = new Obj6("Value1", "Value2");

// What is difference between Call , Apply and Bind
// Each and every function in javascript has a access to this keyword that this keyword is a reference to the object that is calling the function
// In call method we pass the first argument with the [reference of ]this keyword and other arguments seperatly with comma seperated

// Call
let eName1 = {
  firstName: "Indra",
  lastName: "Reddy",
};

// call method invokes the functio immediately by allowing you to specify the value of this and pass the arguments individually (comma-seperated)

let printFull = function () {
  // console.log(this.firstName + " " + this.lastName);
  // Here this refeer to the name object
};

printFull.call(eName1);

let eName2 = {
  firstName: "Raj",
  lastName: "Reddy",
};

printFull.call(eName2);

//  Invokes a function immediately with a specified this value and individual arguments.
// func.call(thisArg, arg1, arg2, ...)

// function boring
// we can use the function printaName from eName1 to print the name in eName2
// we can use call to call the function with the object that we want to use as this keyword




// Apply
// Apply is similar to call but it takes the arguments as an array
// Similar to call(), but takes an array of arguments instead of individual ones
// // In call method we pass the first argument with the [reference of ]this keyword and second arguments with array
// func.apply(thisArg, [argsArray])

let eName3 = {
  firstName: "Raj",
  lastName: "Reddy",
};

let printName = function (city, state) {
  // console.log(
  //   this.firstName + " " + this.lastName + " from " + city + " " + state,
  // );
};

// printName.call(eName3, "Chennai", "TN");
let boundPrintName = printName.bind(eName3, ["Chennai", "TN"]);
boundPrintName();

// Bind

// Bind is similar to call but it returns a new function that has the same body and scope as the original function
// func.bind(thisArg, arg1, arg2, ...)
// Bind method is used to keep a copy of the method and use it later
// the difference between call and bind is that call method is used to invoke the function immediately and bind method is used to bind and create a copy of the function to the object and use later
// const boundFunc = func.bind(thisArg, arg1, arg2, ...)

// Polyfill is the sort of browser fallback

// Polyfill for bind method
let bindPolyFill = {
  firstName: "Indra",
  lastName: "Reddy",
};

let printName1 = function () {
  console.log(this.firstName + " " + this.lastName);
};

let printMyName = printName1.bind(bindPolyFill);
printMyName();

// ----------------------------------------------------------------------------------------------------

// What is function.prototype in javaScript
// Function.prototype is a property of the Function object that is used to add new methods to the function object which is accessable to all functions

// -----------------------------------------------------------------------------------------------------

// What is differences between Arrow function and Normal function
// Arrow
// Arrow function is a shorter syntax of normal function
// Arrow function does not have its own this keyword
// Arrow function does not have its own arguments keyword To access arguments, you need to use rest parameters.
// Cannot be used as constructors and will throw an error if you try to use new with them.
const Preson = (name) => {
  this.name = name; // Error if used with 'new'
};

// Normal function
// Normal function Requires the function keyword.
// Normal function does have its own this keyword
// this' refers to the global object or undefined in strict mode
// Normal function does have its own arguments keyword
// Normal function can be used as constructors and will not throw an error if you try to use new with them.

a = 2;
console.log("a = " + a);
var a;

func();

function func() {
  console.log();
}

// Explain passed by value and passed by reference
// Pass by value
// All the primitive data types are passed by value
// It will make a copy of the value made and pass it to the function so thta the value of the variable will not change

// Pass by reference
// All the non-primitive data types are passed by reference
// A reference to the original object is passed to the function so that any changes made to the object will be reflected in the original object

// Imeditately Invoked Function Expression
(function () {
  // console.log("known as IIFE and pronounced as IIFY");
});

// function doSomething() {
//   console.log(this);
// }

// doSomething();

// -----------------------------------------------------------------------------------------------------

// What is currying in JavaScript?
// Currying is a technique of evaluating a function with multiple arguments, into a sequence of functions each with only one argument.
// By using the currying technique, we do not change the functionality of a function, we just change the way it is invoked.
function multiply(x) {
  return function (y) {
    return x * y;
  };
}
let multiplyByTwo = multiply(2)(3);
console.log(multiplyByTwo);

let muliti = function (x, y) {
  console.log(x * y);
};

let mul = muliti.bind(this, 2);
mul(3);

function factioral(n) {
  if (n === 0) {
    return 1;
  }
  return n * factioral(n - 1);
}

console.log(factioral(5));

function fibonacci(n) {
  if (n <= 1) {
    return n;
  }
  return fibonacci(n - 1) + fibonacci(n - 2);
}
console.log(fibonacci(6));

function sumArray(arr) {
  // Base case: if the array is empty
  if (arr.length === 0) {
    return 0;
  }
  // Recursive case: sum the first element and the sum of the rest
  return arr[0] + sumArray(arr.slice(1));
}

console.log(sumArray([1, 2, 3, 4, 5])); // Output: 15

// What is the rest parameter and spread operator?
// Rest parameter is used to collect all the arguments passed to a function into an array

// function example(...args) {
//   console.log(args);
// }

// const promise = new Promise((resizeBy, rej) => {
//   setTimeout(() => {
//     try {
//       let;
//     } catch (err) {
//       rej(err);
//     }
//   });
// });

// Object destrucring
const obj = {
  name: "Indra",
  age: 22,
  city: "Chennai",
};

// let nameI = obj.name;

const { name: nameI, age: ageI, city: cityI } = obj;
console, log(nameI);

// How Event loop works in JavaScript
// Event loop is a mechanism that allows JavaScript to execute code in a non-blocking manner.
// The event loop is a single-threaded model that is responsible for executing the code in a JavaScript program.
// The event loop is a loop that is executed in the background of a JavaScript program.
// The event loop is responsible for executing the code in a JavaScript program by scheduling tasks to be executed.

console.log("Start");

setTimeout(() => {
  console.log("Timeout1");
});

new Promise((res, rej) => {
  res("Promise1");
}).then((res) => console.log(res));

setTimeout(() => {
  console.log("Timeout2");
});

new Promise((res, rej) => {
  res("Promise2");
}).then((res) => console.log(res));

function middle() {
  console.log("middle function");
}
middle();

console.log("End");
// Explanation of the Example
// Synchronous Code: "Start" and "End" are logged immediately because they are synchronous.
// Promises: The two promises are resolved and pushed to the microtask queue. Their callbacks execute before any callbacks in the callback queue, so "Promise 1" and "Promise 2" are logged next.
// Timers: Finally, the two setTimeout callbacks are executed, as they were added to the callback queue after the timer expired.
