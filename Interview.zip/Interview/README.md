# Node.js Interview Questions

This README contains a list of commonly asked questions about Node.js, useful for interview preparation and self-study.

1. What is the difference between Node.js and JavaScript?  
2. Can you explain the working of Node.js?  
3. Why is Node.js single-threaded?  
4. Why is Node.js so popular these days?  
5. What is synchronous and asynchronous programming?  
6. How does Node.js achieve asynchronous programming?  
7. What is the event loop in Node.js, and how does it work?  
8. What is callback hell, and what are the methods to avoid it?  
9. What are promises in Node.js?  
10. How can you use Async/Await in Node.js?  
11. What are 5 built-in modules in Node.js?  
12. What is the purpose of Module Exports?  
13. Express.js vs Node.js.  
14. What is Event-Driven Programming?  
15. What is the role of the Event Module?  
16. What is the role of the Buffer Class in Node.js?  
17. SetImmediate() vs SetTimeout().  
18. What is Node.js Web Application Architecture?  
19. What are the types of Streams in Node.js?  
20. What is the purpose of the CreateServer() method?  
21. What are commonly used libraries in Node.js?