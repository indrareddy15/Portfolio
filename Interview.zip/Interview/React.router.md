# React Router - Complete Interview Guide

## Table of Contents

1. [Introduction](#introduction)
2. [Core Concepts](#core-concepts)
3. [React Router v7 (Latest)](#react-router-v7-latest)
4. [React Router v6](#react-router-v6)
5. [React Router v5 (Legacy)](#react-router-v5-legacy)
6. [Migration Guide](#migration-guide)
7. [Common Interview Questions](#common-interview-questions)
8. [Best Practices](#best-practices)

---

## Introduction

React Router is a declarative routing library for React applications. It enables navigation among views of various components in a React application, allows changing the browser URL, and keeps the UI in sync with the URL.

### Key Benefits

- **Declarative routing**: Define routes as JSX components
- **Dynamic routing**: Routes are rendered as components
- **Nested routing**: Support for complex UI hierarchies
- **Code splitting**: Lazy loading of route components
- **History management**: Browser history API integration

---

## Core Concepts

### 1. Router Types

- **BrowserRouter**: Uses HTML5 history API (most common)
- **HashRouter**: Uses hash portion of URL
- **MemoryRouter**: Keeps history in memory (testing)
- **StaticRouter**: Never changes location (SSR)

### 2. Route Matching

- **Exact matching**: Route must match exactly
- **Partial matching**: Route matches beginning of path
- **Dynamic segments**: Parameters in URL paths
- **Query parameters**: Key-value pairs in URL

### 3. Navigation Methods

- **Link**: Declarative navigation component
- **NavLink**: Link with active state styling
- **useNavigate**: Programmatic navigation hook
- **Navigate**: Component for redirects

---

## React Router v7 (Latest)

### Installation

```bash
npm install react-router@7
# or
npm install react-router-dom@7
```

### Key Features in v7

1. **Framework Mode**: Full-stack React framework capabilities
2. **Type Safety**: Better TypeScript support
3. **Pre-rendering**: Static site generation support
4. **Vite Integration**: Enhanced Vite plugin
5. **Server Components**: React Server Components support

### Basic Setup

```jsx
// main.jsx
import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import { BrowserRouter } from "react-router";
import App from "./App.jsx";

createRoot(document.getElementById("root")).render(
  <StrictMode>
    <BrowserRouter>
      <App />
    </BrowserRouter>
  </StrictMode>
);
```

### Route Configuration

```jsx
// App.jsx
import { Routes, Route } from "react-router";
import Home from "./components/Home";
import About from "./components/About";
import Contact from "./components/Contact";
import NotFound from "./components/NotFound";

function App() {
  return (
    <Routes>
      <Route path="/" element={<Home />} />
      <Route path="/about" element={<About />} />
      <Route path="/contact" element={<Contact />} />
      <Route path="*" element={<NotFound />} />
    </Routes>
  );
}

export default App;
```

### Advanced Features in v7

#### 1. Framework Mode with Vite

```js
// vite.config.js
import { defineConfig } from "vite";
import { reactRouter } from "@react-router/dev/vite";

export default defineConfig({
  plugins: [reactRouter()],
});
```

#### 2. Route Files Structure

```
app/
  routes/
    _index.tsx          // matches /
    about.tsx           // matches /about
    posts._index.tsx    // matches /posts
    posts.$slug.tsx     // matches /posts/:slug
    posts.new.tsx       // matches /posts/new
```

#### 3. Data Loading with Loaders

```jsx
// routes/posts.$slug.tsx
import { useLoaderData } from "react-router";

export async function loader({ params }) {
  const post = await getPost(params.slug);
  if (!post) {
    throw new Response("Not Found", { status: 404 });
  }
  return post;
}

export default function Post() {
  const post = useLoaderData();
  return (
    <div>
      <h1>{post.title}</h1>
      <p>{post.content}</p>
    </div>
  );
}
```

#### 4. Actions for Mutations

```jsx
// routes/posts.new.tsx
import { Form, redirect } from "react-router";

export async function action({ request }) {
  const formData = await request.formData();
  const post = await createPost({
    title: formData.get("title"),
    content: formData.get("content"),
  });
  return redirect(`/posts/${post.slug}`);
}

export default function NewPost() {
  return (
    <Form method="post">
      <input name="title" type="text" placeholder="Title" />
      <textarea name="content" placeholder="Content" />
      <button type="submit">Create Post</button>
    </Form>
  );
}
```

---

## React Router v6

### Installation

```bash
npm install react-router-dom@6
```

### Key Changes from v5

1. **Routes instead of Switch**: New `Routes` component
2. **element prop**: JSX elements instead of component prop
3. **useNavigate**: Replaces useHistory
4. **Nested routes**: Better support for route nesting
5. **Relative routing**: Automatic relative path resolution

### Basic Setup

```jsx
// index.js
import { BrowserRouter } from "react-router-dom";
import App from "./App";

root.render(
  <BrowserRouter>
    <App />
  </BrowserRouter>
);
```

### Route Configuration

```jsx
// App.js
import { Routes, Route } from "react-router-dom";
import Layout from "./components/Layout";
import Home from "./components/Home";
import About from "./components/About";
import Products from "./components/Products";
import Product from "./components/Product";

function App() {
  return (
    <Routes>
      <Route path="/" element={<Layout />}>
        <Route index element={<Home />} />
        <Route path="about" element={<About />} />
        <Route path="products" element={<Products />}>
          <Route path=":id" element={<Product />} />
        </Route>
        <Route path="*" element={<NoMatch />} />
      </Route>
    </Routes>
  );
}
```

### Hooks in v6

#### 1. useNavigate

```jsx
import { useNavigate } from "react-router-dom";

function LoginForm() {
  const navigate = useNavigate();

  const handleSubmit = (event) => {
    event.preventDefault();
    // Handle login logic
    navigate("/dashboard", { replace: true });
  };

  return <form onSubmit={handleSubmit}>...</form>;
}
```

#### 2. useParams

```jsx
import { useParams } from "react-router-dom";

function Product() {
  const { id } = useParams();

  return <div>Product ID: {id}</div>;
}
```

#### 3. useLocation

```jsx
import { useLocation } from "react-router-dom";

function Analytics() {
  const location = useLocation();

  useEffect(() => {
    // Track page view
    gtag("config", "GA_TRACKING_ID", {
      page_path: location.pathname,
    });
  }, [location]);

  return null;
}
```

#### 4. useSearchParams

```jsx
import { useSearchParams } from "react-router-dom";

function SearchResults() {
  const [searchParams, setSearchParams] = useSearchParams();
  const query = searchParams.get("q");

  return (
    <div>
      <input
        value={query || ""}
        onChange={(e) => setSearchParams({ q: e.target.value })}
      />
      <p>Searching for: {query}</p>
    </div>
  );
}
```

### Nested Routes and Outlet

```jsx
// Layout.js
import { Outlet, Link } from "react-router-dom";

function Layout() {
  return (
    <div>
      <nav>
        <Link to="/">Home</Link>
        <Link to="/about">About</Link>
        <Link to="/products">Products</Link>
      </nav>
      <main>
        <Outlet />
      </main>
    </div>
  );
}
```

### Protected Routes

```jsx
import { Navigate, useLocation } from "react-router-dom";

function RequireAuth({ children }) {
  const auth = useAuth();
  const location = useLocation();

  if (!auth.user) {
    return <Navigate to="/login" state={{ from: location }} replace />;
  }

  return children;
}

// Usage
<Route
  path="/dashboard"
  element={
    <RequireAuth>
      <Dashboard />
    </RequireAuth>
  }
/>;
```

---

## React Router v5 (Legacy)

### Installation

```bash
npm install react-router-dom@5
```

### Key Features

1. **Switch component**: Renders first matching route
2. **component prop**: Pass component reference
3. **useHistory**: Navigation hook
4. **Route render props**: Flexible rendering patterns

### Basic Setup

```jsx
// App.js
import { BrowserRouter, Switch, Route } from "react-router-dom";
import Home from "./components/Home";
import About from "./components/About";

function App() {
  return (
    <BrowserRouter>
      <Switch>
        <Route exact path="/" component={Home} />
        <Route path="/about" component={About} />
        <Route path="/users/:id" component={UserProfile} />
        <Route component={NotFound} />
      </Switch>
    </BrowserRouter>
  );
}
```

### Hooks in v5

#### 1. useHistory

```jsx
import { useHistory } from "react-router-dom";

function LoginButton() {
  const history = useHistory();

  const handleLogin = () => {
    // Login logic
    history.push("/dashboard");
  };

  return <button onClick={handleLogin}>Login</button>;
}
```

#### 2. useParams

```jsx
import { useParams } from "react-router-dom";

function UserProfile() {
  const { id } = useParams();

  return <div>User ID: {id}</div>;
}
```

#### 3. useLocation

```jsx
import { useLocation } from "react-router-dom";

function CurrentPath() {
  const location = useLocation();

  return <div>Current path: {location.pathname}</div>;
}
```

### Route Rendering Patterns

```jsx
// Component prop
<Route path="/home" component={Home} />

// Render prop
<Route path="/home" render={() => <Home />} />

// Children prop
<Route path="/home" children={<Home />} />

// With props
<Route
  path="/users/:id"
  render={(props) => <UserProfile {...props} extraProp="value" />}
/>
```

### Programmatic Navigation

```jsx
import { withRouter } from "react-router-dom";

function NavigationButton({ history }) {
  const handleClick = () => {
    history.push("/new-page");
  };

  return <button onClick={handleClick}>Navigate</button>;
}

export default withRouter(NavigationButton);
```

---

## Migration Guide

### From v5 to v6

#### 1. Update Route Definitions

```jsx
// v5
<Switch>
  <Route exact path="/" component={Home} />
  <Route path="/about" component={About} />
</Switch>

// v6
<Routes>
  <Route path="/" element={<Home />} />
  <Route path="/about" element={<About />} />
</Routes>
```

#### 2. Replace useHistory with useNavigate

```jsx
// v5
import { useHistory } from "react-router-dom";
const history = useHistory();
history.push("/path");

// v6
import { useNavigate } from "react-router-dom";
const navigate = useNavigate();
navigate("/path");
```

#### 3. Update withRouter Usage

```jsx
// v5
import { withRouter } from "react-router-dom";
export default withRouter(MyComponent);

// v6
import { useLocation, useNavigate, useParams } from "react-router-dom";
// Use hooks directly in component
```

### From v6 to v7

#### 1. Update Package Installation

```bash
# Remove old packages
npm uninstall react-router-dom

# Install new packages
npm install react-router@7
```

#### 2. Update Imports

```jsx
// v6
import { BrowserRouter } from "react-router-dom";

// v7
import { BrowserRouter } from "react-router";
```

#### 3. Adopt Framework Features (Optional)

```js
// Add Vite plugin for framework mode
// vite.config.js
import { reactRouter } from "@react-router/dev/vite";

export default defineConfig({
  plugins: [reactRouter()],
});
```

---

## Common Interview Questions

### 1. What is React Router and why is it needed?

**Answer**: React Router is a routing library for React applications that enables navigation between different views/components while keeping the UI in sync with the URL. It's needed because React is a SPA framework, and we need a way to handle client-side routing without full page refreshes.

### 2. Difference between BrowserRouter and HashRouter?

**Answer**:

- **BrowserRouter**: Uses HTML5 history API, creates clean URLs (e.g., `/about`)
- **HashRouter**: Uses hash portion of URL (e.g., `/#/about`), works with older browsers and static file servers

### 3. What are the main differences between React Router v5 and v6?

**Answer**:

- `Routes` instead of `Switch`
- `element` prop instead of `component`
- `useNavigate` instead of `useHistory`
- Better nested routing support
- Relative routing by default
- Removed `exact` prop (exact matching by default)

### 4. How do you implement protected routes?

**Answer**: Create a wrapper component that checks authentication status and redirects to login if not authenticated:

```jsx
function ProtectedRoute({ children }) {
  const isAuthenticated = useAuth();
  return isAuthenticated ? children : <Navigate to="/login" />;
}
```

### 5. How do you handle 404 pages?

**Answer**: Use a catch-all route with `*` path:

```jsx
<Routes>
  <Route path="/" element={<Home />} />
  <Route path="/about" element={<About />} />
  <Route path="*" element={<NotFound />} />
</Routes>
```

### 6. What is the difference between Link and NavLink?

**Answer**:

- **Link**: Basic navigation component
- **NavLink**: Link with additional props for styling active states (`activeClassName`, `activeStyle`)

### 7. How do you access URL parameters?

**Answer**: Use the `useParams` hook:

```jsx
// Route: /users/:id
function UserProfile() {
  const { id } = useParams();
  return <div>User ID: {id}</div>;
}
```

### 8. How do you programmatically navigate?

**Answer**: Use the `useNavigate` hook (v6/v7) or `useHistory` (v5):

```jsx
// v6/v7
const navigate = useNavigate();
navigate("/dashboard");

// v5
const history = useHistory();
history.push("/dashboard");
```

### 9. What are nested routes and how do you implement them?

**Answer**: Nested routes allow you to render child routes within parent components. Use `Outlet` in the parent component:

```jsx
function Layout() {
  return (
    <div>
      <nav>...</nav>
      <Outlet /> {/* Child routes render here */}
    </div>
  );
}
```

### 10. How do you handle query parameters?

**Answer**: Use `useSearchParams` hook (v6/v7) or `useLocation` (v5):

```jsx
// v6/v7
const [searchParams, setSearchParams] = useSearchParams();
const query = searchParams.get("q");

// v5
const location = useLocation();
const params = new URLSearchParams(location.search);
const query = params.get("q");
```

### 11. What is the difference between push and replace in navigation?

**Answer**:

- **push**: Adds a new entry to the history stack (user can go back)
- **replace**: Replaces the current entry in the history stack (user cannot go back to previous page)

```jsx
// v6/v7
navigate("/dashboard"); // push (default)
navigate("/dashboard", { replace: true }); // replace

// v5
history.push("/dashboard"); // push
history.replace("/dashboard"); // replace
```

### 12. How do you handle route-based code splitting?

**Answer**: Use React's `lazy()` function with dynamic imports and `Suspense`:

```jsx
import { lazy, Suspense } from "react";

const Dashboard = lazy(() => import("./Dashboard"));
const Profile = lazy(() => import("./Profile"));

function App() {
  return (
    <Routes>
      <Route
        path="/dashboard"
        element={
          <Suspense fallback={<div>Loading...</div>}>
            <Dashboard />
          </Suspense>
        }
      />
      <Route
        path="/profile"
        element={
          <Suspense fallback={<div>Loading...</div>}>
            <Profile />
          </Suspense>
        }
      />
    </Routes>
  );
}
```

### 13. What are loaders and actions in React Router v6/v7?

**Answer**:

- **Loaders**: Functions that fetch data before a route renders (v6.4+)
- **Actions**: Functions that handle form submissions and mutations

```jsx
// Loader example
export async function loader({ params }) {
  const user = await fetchUser(params.userId);
  if (!user) {
    throw new Response("User not found", { status: 404 });
  }
  return user;
}

// Action example
export async function action({ request, params }) {
  const formData = await request.formData();
  const updates = Object.fromEntries(formData);
  await updateUser(params.userId, updates);
  return redirect(`/users/${params.userId}`);
}

// Component using loader data
function UserProfile() {
  const user = useLoaderData();
  return <div>{user.name}</div>;
}
```

### 14. How do you implement role-based routing?

**Answer**: Create a higher-order component or hook to check user roles:

```jsx
function RoleGuard({ children, allowedRoles }) {
  const { user } = useAuth();

  if (!user) {
    return <Navigate to="/login" />;
  }

  if (!allowedRoles.some((role) => user.roles.includes(role))) {
    return <Navigate to="/unauthorized" />;
  }

  return children;
}

// Usage
<Route
  path="/admin"
  element={
    <RoleGuard allowedRoles={["admin", "super-admin"]}>
      <AdminPanel />
    </RoleGuard>
  }
/>;
```

### 15. What is the purpose of the `key` prop in routes?

**Answer**: The `key` prop forces React to remount a component when the key changes, useful for:

- Resetting component state when route parameters change
- Forcing re-execution of useEffect hooks
- Clearing form data when navigating between similar routes

```jsx
<Route path="/users/:id" element={<UserProfile key={location.pathname} />} />
```

### 16. How do you handle authentication redirects with state?

**Answer**: Use the `state` property to store the intended destination:

```jsx
// In ProtectedRoute component
function ProtectedRoute({ children }) {
  const location = useLocation();
  const isAuthenticated = useAuth();

  if (!isAuthenticated) {
    return <Navigate to="/login" state={{ from: location.pathname }} replace />;
  }

  return children;
}

// In Login component
function Login() {
  const navigate = useNavigate();
  const location = useLocation();
  const from = location.state?.from || "/";

  const handleLogin = async () => {
    await authenticate();
    navigate(from, { replace: true });
  };
}
```

### 17. What is the difference between relative and absolute paths in routing?

**Answer**:

- **Absolute paths**: Start with `/`, navigate from root
- **Relative paths**: Don't start with `/`, navigate relative to current route

```jsx
// Current route: /users/123
navigate("/dashboard"); // Absolute: goes to /dashboard
navigate("edit"); // Relative: goes to /users/123/edit
navigate("../profile"); // Relative: goes to /users/profile
navigate(".."); // Relative: goes to /users
```

### 18. How do you handle scroll restoration in React Router?

**Answer**: React Router automatically handles scroll restoration, but you can customize it:

```jsx
// Scroll to top on route change
function ScrollToTop() {
  const { pathname } = useLocation();

  useEffect(() => {
    window.scrollTo(0, 0);
  }, [pathname]);

  return null;
}

// Or use scrollRestoration in BrowserRouter
<BrowserRouter>
  <ScrollToTop />
  <Routes>...</Routes>
</BrowserRouter>;

// Manual scroll restoration
function useScrollRestoration() {
  const location = useLocation();

  useEffect(() => {
    if (location.state?.scrollY) {
      window.scrollTo(0, location.state.scrollY);
    }
  }, [location]);
}
```

### 19. How do you implement breadcrumbs with React Router?

**Answer**: Create a breadcrumb component that reads the current route:

```jsx
function Breadcrumbs() {
  const location = useLocation();
  const pathnames = location.pathname.split("/").filter((x) => x);

  return (
    <nav>
      <Link to="/">Home</Link>
      {pathnames.map((name, index) => {
        const routeTo = `/${pathnames.slice(0, index + 1).join("/")}`;
        const isLast = index === pathnames.length - 1;

        return isLast ? (
          <span key={name}> / {name}</span>
        ) : (
          <span key={name}>
            {" / "}
            <Link to={routeTo}>{name}</Link>
          </span>
        );
      })}
    </nav>
  );
}
```

### 20. What are some performance optimization techniques for React Router?

**Answer**:

1. **Code splitting**: Use `lazy()` and `Suspense`
2. **Route-based splitting**: Split at route level rather than component level
3. **Preloading**: Preload routes on hover or focus
4. **Avoid inline functions**: Define route elements outside render
5. **Use outlet context**: Share data between nested routes efficiently

```jsx
// Preloading example
function NavLink({ to, children, ...props }) {
  const handleMouseEnter = () => {
    // Preload the route component
    import(`./pages/${to.slice(1)}.jsx`);
  };

  return (
    <Link to={to} onMouseEnter={handleMouseEnter} {...props}>
      {children}
    </Link>
  );
}

// Outlet context for sharing data
function Layout() {
  const [user, setUser] = useState(null);

  return (
    <div>
      <nav>...</nav>
      <Outlet context={{ user, setUser }} />
    </div>
  );
}

function Profile() {
  const { user } = useOutletContext();
  return <div>{user.name}</div>;
}
```

### 21. How do you handle route transitions and animations?

**Answer**: Use libraries like `framer-motion` or CSS transitions:

```jsx
import { motion, AnimatePresence } from "framer-motion";

function AnimatedRoutes() {
  const location = useLocation();

  return (
    <AnimatePresence mode="wait">
      <Routes location={location} key={location.pathname}>
        <Route
          path="/"
          element={
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              transition={{ duration: 0.3 }}
            >
              <Home />
            </motion.div>
          }
        />
      </Routes>
    </AnimatePresence>
  );
}
```

### 22. What are the security considerations when using React Router?

**Answer**:

1. **XSS Prevention**: Always validate and sanitize URL parameters
2. **Route Protection**: Implement proper authentication and authorization
3. **Information Disclosure**: Don't expose sensitive data in URLs
4. **CSRF Protection**: Use proper CSRF tokens for forms
5. **Deep Link Security**: Validate that users can access deep-linked routes

```jsx
// Secure parameter handling
function UserProfile() {
  const { id } = useParams();

  // Validate and sanitize
  if (!/^\d+$/.test(id)) {
    return <Navigate to="/404" />;
  }

  // Additional authorization check
  if (!canAccessUser(id)) {
    return <Navigate to="/unauthorized" />;
  }

  return <div>User: {id}</div>;
}
```

### 23. How do you test React Router components?

**Answer**: Use `MemoryRouter` for testing and mock navigation:

```jsx
import { render, screen } from "@testing-library/react";
import { MemoryRouter } from "react-router-dom";
import { createMemoryHistory } from "history";

// Testing with MemoryRouter
test("renders user profile with ID", () => {
  render(
    <MemoryRouter initialEntries={["/users/123"]}>
      <Routes>
        <Route path="/users/:id" element={<UserProfile />} />
      </Routes>
    </MemoryRouter>
  );

  expect(screen.getByText("User ID: 123")).toBeInTheDocument();
});

// Testing navigation
test("navigates to dashboard on login", async () => {
  const history = createMemoryHistory();

  render(
    <Router location={history.location} navigator={history}>
      <Login />
    </Router>
  );

  await userEvent.click(screen.getByRole("button", { name: "Login" }));

  expect(history.location.pathname).toBe("/dashboard");
});

// Mock useNavigate for unit testing
jest.mock("react-router-dom", () => ({
  ...jest.requireActual("react-router-dom"),
  useNavigate: () => jest.fn(),
}));
```

---

## Best Practices

### 1. Route Organization

```jsx
// Organize routes in a separate file
// routes.js
export const routes = [
  {
    path: "/",
    element: <Layout />,
    children: [
      { index: true, element: <Home /> },
      { path: "about", element: <About /> },
      { path: "contact", element: <Contact /> },
    ],
  },
];
```

### 2. Lazy Loading

```jsx
import { lazy, Suspense } from 'react'

const LazyComponent = lazy(() => import('./LazyComponent'))

<Route
  path="/lazy"
  element={
    <Suspense fallback={<div>Loading...</div>}>
      <LazyComponent />
    </Suspense>
  }
/>
```

### 3. Error Boundaries

```jsx
import { ErrorBoundary } from "react-error-boundary";

function ErrorFallback({ error }) {
  return <div>Something went wrong: {error.message}</div>;
}

<Route
  path="/dashboard"
  element={
    <ErrorBoundary FallbackComponent={ErrorFallback}>
      <Dashboard />
    </ErrorBoundary>
  }
/>;
```

### 4. Route Guards

```jsx
function RoleBasedRoute({ children, requiredRole }) {
  const user = useAuth();

  if (!user) return <Navigate to="/login" />;
  if (!user.roles.includes(requiredRole)) {
    return <Navigate to="/unauthorized" />;
  }

  return children;
}
```

### 5. Dynamic Route Loading

```jsx
// For v7 with framework mode
export async function loader({ params }) {
  const data = await fetchData(params.id);
  if (!data) {
    throw new Response("Not Found", { status: 404 });
  }
  return data;
}
```

### 6. SEO Considerations

```jsx
import { Helmet } from "react-helmet-async";

function ProductPage() {
  const { product } = useLoaderData();

  return (
    <>
      <Helmet>
        <title>{product.name} - My Store</title>
        <meta name="description" content={product.description} />
      </Helmet>
      <div>{product.name}</div>
    </>
  );
}
```

### 7. Testing Routes

```jsx
import { render, screen } from "@testing-library/react";
import { MemoryRouter } from "react-router-dom";
import App from "./App";

test("renders home page", () => {
  render(
    <MemoryRouter initialEntries={["/"]}>
      <App />
    </MemoryRouter>
  );
  expect(screen.getByText("Home")).toBeInTheDocument();
});
```

---

## React Router Version Comparison Table

| Feature                | React Router v5       | React Router v6      | React Router v7     |
| ---------------------- | --------------------- | -------------------- | ------------------- |
| **Release Year**       | 2020                  | 2021                 | 2024                |
| **Current Status**     | Legacy/Maintenance    | Stable               | Latest              |
| **Package Name**       | `react-router-dom@5`  | `react-router-dom@6` | `react-router@7`    |
| **TypeScript Support** | External types needed | Built-in TypeScript  | Enhanced TypeScript |
| **Bundle Size**        | ~20KB gzipped         | ~13KB gzipped        | ~15KB gzipped       |

### **Core API Differences**

| Feature              | v5                                | v6                             | v7                             |
| -------------------- | --------------------------------- | ------------------------------ | ------------------------------ |
| **Route Container**  | `<Switch>`                        | `<Routes>`                     | `<Routes>`                     |
| **Route Definition** | `<Route component={Home} />`      | `<Route element={<Home />} />` | `<Route element={<Home />} />` |
| **Exact Matching**   | `<Route exact />`                 | Default behavior               | Default behavior               |
| **Route Props**      | `component`, `render`, `children` | `element` only                 | `element` only                 |
| **Nested Routes**    | Manual route configuration        | Declarative with `<Outlet>`    | Declarative + File-based       |

### **Navigation & Hooks**

| Feature               | v5                                    | v6                                        | v7                  |
| --------------------- | ------------------------------------- | ----------------------------------------- | ------------------- |
| **Navigation Hook**   | `useHistory()`                        | `useNavigate()`                           | `useNavigate()`     |
| **Navigation Method** | `history.push()`, `history.replace()` | `navigate()`, `navigate(path, {replace})` | Same as v6          |
| **Route Parameters**  | `useParams()`                         | `useParams()`                             | `useParams()`       |
| **Location Hook**     | `useLocation()`                       | `useLocation()`                           | `useLocation()`     |
| **Search Parameters** | Manual parsing                        | `useSearchParams()`                       | `useSearchParams()` |
| **Route Data**        | Props passing                         | `useLoaderData()` (v6.4+)                 | `useLoaderData()`   |
| **Form Handling**     | Manual                                | `useActionData()` (v6.4+)                 | `useActionData()`   |

### **Route Configuration**

| Feature                  | v5                      | v6                     | v7                       |
| ------------------------ | ----------------------- | ---------------------- | ------------------------ |
| **Route Definition**     | JSX in component        | JSX in component       | JSX + File-based routing |
| **Dynamic Imports**      | Manual with React.lazy  | Manual with React.lazy | Built-in support         |
| **Data Loading**         | useEffect in components | Loaders (v6.4+)        | Enhanced loaders         |
| **Form Actions**         | Manual handling         | Actions (v6.4+)        | Enhanced actions         |
| **Error Boundaries**     | Manual implementation   | `errorElement` prop    | Enhanced error handling  |
| **Suspense Integration** | Manual                  | Built-in (v6.4+)       | Enhanced                 |

### **Advanced Features**

| Feature                | v5                      | v6                      | v7                      |
| ---------------------- | ----------------------- | ----------------------- | ----------------------- |
| **Code Splitting**     | Manual with lazy()      | Manual with lazy()      | Framework-level support |
| **SSR Support**        | Basic                   | Improved                | Full framework support  |
| **Preloading**         | Manual                  | Manual                  | Framework-level         |
| **Data Mutations**     | Manual                  | Forms + Actions         | Enhanced forms          |
| **Route-level Guards** | HOCs/Wrapper components | HOCs/Wrapper components | Built-in + HOCs         |
| **Scroll Restoration** | Manual                  | Automatic               | Enhanced automatic      |

### **Developer Experience**

| Feature               | v5       | v6                       | v7                           |
| --------------------- | -------- | ------------------------ | ---------------------------- |
| **Learning Curve**    | Moderate | Steep (breaking changes) | Moderate (if coming from v6) |
| **Error Messages**    | Basic    | Improved                 | Enhanced                     |
| **DevTools**          | Basic    | Improved                 | Enhanced                     |
| **Hot Reloading**     | Basic    | Good                     | Excellent                    |
| **Build Integration** | Manual   | Manual                   | Framework-level              |

### **Framework Features (v7 Exclusive)**

| Feature                | Description                                    | Availability |
| ---------------------- | ---------------------------------------------- | ------------ |
| **Framework Mode**     | Full-stack React framework with Vite           | v7 only      |
| **File-based Routing** | Automatic route generation from file structure | v7 only      |
| **Server Components**  | React Server Components support                | v7 only      |
| **Static Generation**  | Pre-rendering for static sites                 | v7 only      |
| **Edge Functions**     | Serverless function support                    | v7 only      |

### **Migration Complexity**

| Migration Path | Difficulty | Key Changes                               | Time Estimate |
| -------------- | ---------- | ----------------------------------------- | ------------- |
| **v5 → v6**    | High       | Complete API rewrite                      | 2-4 weeks     |
| **v6 → v7**    | Low-Medium | Package name, optional framework features | 1-2 days      |
| **v5 → v7**    | High       | Complete rewrite + learning new patterns  | 3-5 weeks     |

### **Performance Comparison**

| Metric                   | v5      | v6        | v7                         |
| ------------------------ | ------- | --------- | -------------------------- |
| **Initial Bundle Size**  | ~20KB   | ~13KB     | ~15KB                      |
| **Route Matching Speed** | Good    | Excellent | Excellent                  |
| **Tree Shaking**         | Partial | Excellent | Excellent                  |
| **Code Splitting**       | Manual  | Manual    | Automatic (framework mode) |
| **Runtime Performance**  | Good    | Better    | Best                       |

### **Browser Support**

| Feature             | v5                   | v6  | v7  |
| ------------------- | -------------------- | --- | --- |
| **IE11**            | Yes (with polyfills) | No  | No  |
| **Modern Browsers** | Yes                  | Yes | Yes |
| **Mobile Browsers** | Yes                  | Yes | Yes |
| **Node.js Version** | 10+                  | 14+ | 16+ |

### **Community & Ecosystem**

| Aspect                     | v5             | v6         | v7            |
| -------------------------- | -------------- | ---------- | ------------- |
| **Documentation**          | Complete       | Excellent  | Growing       |
| **Community Size**         | Large (legacy) | Very Large | Growing       |
| **Third-party Libraries**  | Extensive      | Good       | Limited (new) |
| **Stack Overflow Support** | Extensive      | Good       | Limited       |
| **Tutorial Availability**  | Abundant       | Growing    | Limited       |

### **When to Choose Each Version**

| Version | Best For                                             | Avoid If                                        |
| ------- | ---------------------------------------------------- | ----------------------------------------------- |
| **v5**  | Legacy projects, IE11 support needed                 | New projects, modern features needed            |
| **v6**  | Most React applications, stable production apps      | Need framework features, heavy SSR requirements |
| **v7**  | New full-stack projects, framework-style development | Simple SPAs, prefer minimal setup               |

### **Code Example Comparison**

#### **Basic Route Setup**

```jsx
// v5
<BrowserRouter>
  <Switch>
    <Route exact path="/" component={Home} />
    <Route path="/about" component={About} />
    <Route path="/users/:id" component={UserProfile} />
  </Switch>
</BrowserRouter>

// v6
<BrowserRouter>
  <Routes>
    <Route path="/" element={<Home />} />
    <Route path="/about" element={<About />} />
    <Route path="/users/:id" element={<UserProfile />} />
  </Routes>
</BrowserRouter>

// v7 (JSX mode - same as v6)
<BrowserRouter>
  <Routes>
    <Route path="/" element={<Home />} />
    <Route path="/about" element={<About />} />
    <Route path="/users/:id" element={<UserProfile />} />
  </Routes>
</BrowserRouter>

// v7 (Framework mode - file-based)
// app/routes/_index.tsx -> /
// app/routes/about.tsx -> /about
// app/routes/users.$id.tsx -> /users/:id
```

#### **Navigation**

```jsx
// v5
import { useHistory } from "react-router-dom";
const history = useHistory();
history.push("/dashboard");

// v6 & v7
import { useNavigate } from "react-router-dom"; // v6
import { useNavigate } from "react-router"; // v7
const navigate = useNavigate();
navigate("/dashboard");
```

#### **Data Loading**

```jsx
// v5
function UserProfile() {
  const { id } = useParams();
  const [user, setUser] = useState(null);

  useEffect(() => {
    fetchUser(id).then(setUser);
  }, [id]);

  return <div>{user?.name}</div>;
}

// v6 (v6.4+)
export async function loader({ params }) {
  return fetchUser(params.id);
}

function UserProfile() {
  const user = useLoaderData();
  return <div>{user.name}</div>;
}

// v7 (Enhanced loaders)
export async function loader({ params }) {
  const user = await fetchUser(params.id);
  if (!user) {
    throw new Response("Not Found", { status: 404 });
  }
  return user;
}

function UserProfile() {
  const user = useLoaderData();
  return <div>{user.name}</div>;
}
```

---

## Conclusion

React Router is an essential library for building single-page applications with React. Understanding the differences between versions and knowing how to implement common routing patterns is crucial for React developers. The evolution from v5 to v7 shows a trend toward better developer experience, type safety, and full-stack capabilities.

Key takeaways for interviews:

- Understand the core concepts of client-side routing
- Know the differences between Router versions
- Be able to implement common patterns like protected routes and nested routing
- Understand hooks and their use cases
- Know best practices for performance and SEO

This comprehensive guide should help you confidently discuss React Router concepts in your interview!
