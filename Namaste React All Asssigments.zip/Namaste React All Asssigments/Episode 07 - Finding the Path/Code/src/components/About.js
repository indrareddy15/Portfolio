import React from 'react';

const About = () => {
  return (
    <div>
      <h1>About Us</h1>
      <h2>This is About Page</h2>
    </div>
  );
};

export default About;
