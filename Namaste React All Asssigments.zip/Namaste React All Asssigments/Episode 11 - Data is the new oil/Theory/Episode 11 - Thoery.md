## Namaste React Course by Akshay Saini

# Episode 11 - Data is the new oil

## Theory:

### Topics Covered:

- Seperation of a React Application into UI-Layer and Data-Layer
- Controlled and Uncontrolled Components
- Prop Driling
- Context API in React
