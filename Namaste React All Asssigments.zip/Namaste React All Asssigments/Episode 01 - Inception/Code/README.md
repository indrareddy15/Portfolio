## Namaste React Course by Akshay Saini

# _Episode 01 - Inception_

## Coding :

- Set up all the `tools in your laptop`
  - `VS Code`
  - `Chrome`
  - `Extensions of Chrome`
- Create a `new Git repo`
- Build your `first Hello World` program using,
  - Using `just HTML`
  - Using `JS to manipulate the DOM`
  - Using `React`
    - `use CDN Links`
    - `Create an Element`
    - `Create nested React Elements`
    - `Use root.render`
