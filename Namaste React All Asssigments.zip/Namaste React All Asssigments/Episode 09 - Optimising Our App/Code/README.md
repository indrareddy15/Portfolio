## Namaste React Course by Akshay Saini

# Episode 09 - Optimizing our App

## Coding Assignment:

- Create your `custom hooks`.
- Try out `lazy and suspense`
- Make your `code clean`.

## [Food App Optimizations](https://food-app-optimizations.netlify.app/)
